#[path = "generated/rejected_copy_logical.rs"] pub mod case_rejected_copy_logical;
#[path = "generated/rejected_logical.rs"] pub mod case_rejected_logical;
#[path = "generated/valid_null_copy_logical.rs"] pub mod case_valid_null_copy_logical;
#[path = "generated/valid_zero_copy_logical.rs"] pub mod case_valid_zero_copy_logical;
