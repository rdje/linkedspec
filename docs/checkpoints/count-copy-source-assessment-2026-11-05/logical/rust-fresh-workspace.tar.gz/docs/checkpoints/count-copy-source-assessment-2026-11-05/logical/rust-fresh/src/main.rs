fn main() {
let result = count_copy_source_logical_rust_fresh::case_rejected_copy_logical::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("COUNT_COPY_RUST_FRESH rejected_copy_logical {}", observed);
let result = count_copy_source_logical_rust_fresh::case_rejected_logical::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("COUNT_COPY_RUST_FRESH rejected_logical {}", observed);
let result = count_copy_source_logical_rust_fresh::case_valid_null_copy_logical::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("COUNT_COPY_RUST_FRESH valid_null_copy_logical {}", observed);
let result = count_copy_source_logical_rust_fresh::case_valid_zero_copy_logical::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("COUNT_COPY_RUST_FRESH valid_zero_copy_logical {}", observed);
}
