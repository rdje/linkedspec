//! Runtime engine — executes compiled rule specifications against input text.
//!
//! The engine:
//! 1. Builds regex alternations from compiled rule patterns
//! 2. Executes the lifecycle loop (I → LS → match → LE → IT → LX/EX → E)
//! 3. Dispatches to child rules recursively
//! 4. Interprets lifecycle code expression trees
//! 5. Returns parse results as JSON
//!
//! ## Lifecycle loop
//!
//! For non-REP (single-fire) rules:
//!   I → LS → match → (acode dispatch) → LE → E
//! If no match:
//!   I → LS → no match → LX → E
//!
//! For REP (repeating) rules:
//!   I → loop { LS → match → (acode dispatch) → LE → IT } → EX → E
//! If no match on first iteration:
//!   I → LS → no match → LX → E
//!
//! Capture-enabled action rules are the deliberate exception: they select the
//! local match and install the gap candidate before LS, then commit after LE
//! and install successful tail context before the terminal hook.
//!
//! ## Blind-call dispatch
//!
//! Blind-call rules (`=> child`) dispatch children from `bcode_dispatch`.
//! Explicit OR mode stops after the first truthy child return; AND mode invokes
//! each child sequentially, and repeated blind-call modes loop those choice or
//! sequence steps with the normal repetition bounds and progress guard.
//! Blind-call dispatch takes priority over regex + acode dispatch.
//!
//! ## Multi-entrypoint child dispatch
//!
//! When `-> child[N]` is used, `child_regex_idx` selects which regex of the
//! child rule to start with. The default (0) uses the first regex.

use crate::helpers::regex_engine::{CompiledAlternation, MatchResult};
use crate::runtime::{CallableCodeblockFailure, RuntimeContext, RuntimeVarKind};
use crate::source_emitter::{GeneratedRuleFamily, GeneratedRuleSpec};
use crate::{
    RuntimeDiagnostic, RuntimeDiagnosticOutputEvent, RuntimeDiagnosticOutputExecutionError,
    RuntimeDiagnosticOutputSink, RuntimeExecutionError, RuntimeExitNow,
    RuntimeSemanticObservationSink,
};
use linkedspec_core::ast::RuleMode;
use linkedspec_core::callable_contract::{CallableSurface, builtin_contract};
use linkedspec_core::compiler::{
    validate_compiled_regex_slot_identities, validate_nested_write_nodes,
    validate_receiver_mutation_nodes,
};
use linkedspec_core::entry_rule::{
    ENTRY_RULE_NOT_FOUND_CODE, EntryRuleSelectionBasis, NO_RULES_DEFINED_CODE,
    SELECT_ENTRY_RULE_STAGE, VALIDATE_SPEC_STAGE,
};
use linkedspec_core::expr::{
    AccessSegment, Arg, CodeBlock, Expr, ExpressionSpan, FluentCall, ReceiverMutationActionBlock,
    ReceiverMutationBindingReference, ReceiverMutationCall, ReceiverMutationContinuationCall,
    WritePathSegment,
};
use linkedspec_core::trace::{TraceConfig, TraceEmitter, TraceLevel};
use linkedspec_core::types::{
    BcodeEntry, CodeblockValue, CompiledRule, CompiledSpec, CompiledUserFunction, ParseMode,
    RuntimeValue,
};
use serde_json::{Value, json};
use std::fmt;

const LINKEDSPEC_WHILE_ITERATION_LIMIT: usize = 10_000;

#[derive(Debug, Clone)]
struct TreeCodeblockCallback {
    name: String,
    binding_name: Option<String>,
    value: CodeblockValue,
    pass_leaf_value: bool,
}

/// Internal invariant failure raised when ordered matching reports an identity
/// other than the structural slot the sequence already required.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct OrderedRegexSlotIdentityError {
    pub rule_label: String,
    pub target_rule: String,
    pub expected_regex_index: usize,
    pub actual_regex_index: usize,
}

impl fmt::Display for OrderedRegexSlotIdentityError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            formatter,
            "ordered_regex_slot_identity_lost stage=execute_rule rule_label={} target_rule={} expected_regex_index={} actual_regex_index={}",
            self.rule_label, self.target_rule, self.expected_regex_index, self.actual_regex_index
        )
    }
}

impl std::error::Error for OrderedRegexSlotIdentityError {}

/// Assert the portable ordered slot-identity invariant.
pub fn assert_ordered_regex_slot_identity(
    rule_label: &str,
    expected_target_rule: &str,
    expected_regex_index: usize,
    actual_target_rule: &str,
    actual_regex_index: usize,
) -> Result<(), OrderedRegexSlotIdentityError> {
    if expected_target_rule == actual_target_rule && expected_regex_index == actual_regex_index {
        return Ok(());
    }
    Err(OrderedRegexSlotIdentityError {
        rule_label: rule_label.to_string(),
        target_rule: expected_target_rule.to_string(),
        expected_regex_index,
        actual_regex_index,
    })
}

fn structural_slot_identity(rule: &CompiledRule, dispatch_index: usize) -> (&str, usize) {
    rule.acode_dispatch
        .iter()
        .find(|entry| entry.regex_idx == dispatch_index)
        .map(|entry| (entry.child_label.as_str(), entry.child_regex_idx))
        .unwrap_or((rule.label.as_str(), dispatch_index))
}

/// One required match in an AND sequence. Dependency order is independent of
/// both the regex catalog and the action table: repeated references to one
/// pattern must consume separate matches and dispatch separate actions.
#[derive(Clone, Copy)]
struct AndRequiredStep {
    regex_index: usize,
    action_index: Option<usize>,
}

impl AndRequiredStep {
    fn slot_identity(self, rule: &CompiledRule, matched_index: usize) -> (&str, usize) {
        self.action_index
            .and_then(|index| rule.acode_dispatch.get(index))
            .filter(|entry| entry.regex_idx == matched_index)
            .map(|entry| (entry.child_label.as_str(), entry.child_regex_idx))
            .unwrap_or_else(|| structural_slot_identity(rule, matched_index))
    }

    fn dispatches(self, action_index: usize) -> bool {
        self.action_index.is_none_or(|index| index == action_index)
    }
}

fn and_required_steps(rule: &CompiledRule) -> Vec<AndRequiredStep> {
    if !rule.mode.is_and() {
        return Vec::new();
    }

    // Parent-anchored and mixed rules retain their catalog-based matching and
    // dispatch. Only edge-only dependency sequences need an action per step.
    let has_parent_pattern = rule
        .acode_dispatch
        .iter()
        .any(|entry| entry.has_parent_regex);
    let local_slot_count = if rule.regex_slots.is_empty() {
        // Older compiled inputs may omit the optional authored-slot metadata.
        rule.regex_patterns.len()
    } else {
        rule.regex_slots.len()
    };
    let mut previous_index = None;
    let local_sparse_sequence = rule.acode_dispatch.iter().all(|entry| {
        let increasing = previous_index.is_none_or(|index| entry.child_regex_idx > index);
        previous_index = Some(entry.child_regex_idx);
        entry.child_label == rule.label
            && entry.child_regex_idx < local_slot_count
            && entry.regex_idx == entry.child_regex_idx
            && increasing
    });

    if !has_parent_pattern && !local_sparse_sequence {
        return rule
            .acode_dispatch
            .iter()
            .enumerate()
            .map(|(index, entry)| AndRequiredStep {
                regex_index: entry.regex_idx,
                action_index: Some(index),
            })
            .collect();
    }

    (0..rule.regex_patterns.len())
        .map(|regex_index| AndRequiredStep {
            regex_index,
            action_index: None,
        })
        .collect()
}

/// True only for the explicit choice-repetition action families admitted by
/// ADR 0048. The historical unadorned default handler and every AND/blind
/// family deliberately retain their existing return contract.
fn collects_explicit_action_iteration_values(rule: &CompiledRule) -> bool {
    !rule.acode_dispatch.is_empty()
        && matches!(
            rule.mode,
            RuleMode::Star
                | RuleMode::Plus
                | RuleMode::Optional
                | RuleMode::Or
                | RuleMode::OrPlus
                | RuleMode::OrBounded { .. }
        )
}

fn strict_decimal_text(value: &str) -> bool {
    let bytes = value.as_bytes();
    if bytes.is_empty() {
        return false;
    }
    let mut index = usize::from(bytes[0] == b'-');
    if index == bytes.len() {
        return false;
    }
    if bytes[index] == b'.' {
        index += 1;
        return index < bytes.len() && bytes[index..].iter().all(u8::is_ascii_digit);
    }
    let digits_start = index;
    while index < bytes.len() && bytes[index].is_ascii_digit() {
        index += 1;
    }
    if index == digits_start {
        return false;
    }
    if index == bytes.len() {
        return true;
    }
    if bytes[index] != b'.' {
        return false;
    }
    index += 1;
    index < bytes.len() && bytes[index..].iter().all(u8::is_ascii_digit)
}

fn scalar_numeric_value(value: &RuntimeValue) -> Option<f64> {
    let number = match value {
        RuntimeValue::Number(number) => *number,
        RuntimeValue::Scalar(text) if strict_decimal_text(text) => text.parse().ok()?,
        _ => return None,
    };
    number.is_finite().then_some(number)
}

fn finite_numeric_result(value: f64) -> RuntimeValue {
    if value.is_finite() {
        RuntimeValue::Number(if value == 0.0 { 0.0 } else { value })
    } else {
        RuntimeValue::Undef
    }
}

fn diagnostic_output_expected_arity(
    name: &str,
    raw_args: &[Arg],
    actual_arity: usize,
) -> Option<&'static str> {
    let positional_only =
        raw_args.is_empty() || raw_args.iter().all(|arg| matches!(arg, Arg::Positional(_)));
    match name {
        "print" | "say" if positional_only && actual_arity >= 1 => None,
        "print" | "say" => Some("at least 1 positional argument"),
        "print_each" if positional_only && matches!(actual_arity, 2 | 3) => None,
        "print_each" => Some("2 or 3 positional arguments"),
        _ => None,
    }
}

fn validate_diagnostic_output_arity(
    name: &str,
    raw_args: &[Arg],
    actual_arity: usize,
    ctx: &mut RuntimeContext,
    rule_label: &str,
) -> Result<(), String> {
    let Some(expected) = diagnostic_output_expected_arity(name, raw_args, actual_arity) else {
        return Ok(());
    };
    ctx.capture_diagnostic_failure(
        "helper_arity_mismatch",
        "Rust runtime helper arity mismatch",
        Some(rule_label),
    );
    Err(format!(
        "helper '{name}' expects {expected}, got {actual_arity} in rule '{rule_label}'"
    ))
}

fn logical_helper_expected_arity(
    name: &str,
    raw_args: &[Arg],
    actual_arity: usize,
) -> Option<&'static str> {
    let positional_only = raw_args.iter().all(|arg| matches!(arg, Arg::Positional(_)));
    match name {
        "and" | "or" if positional_only && actual_arity >= 1 => None,
        "and" | "or" => Some("at least 1 positional argument"),
        "not" if positional_only && actual_arity == 1 => None,
        "not" => Some("exactly 1 positional argument"),
        _ => None,
    }
}

fn validate_logical_helper_arity(
    name: &str,
    raw_args: &[Arg],
    actual_arity: usize,
    ctx: &mut RuntimeContext,
    rule_label: &str,
) -> Result<(), String> {
    let Some(expected) = logical_helper_expected_arity(name, raw_args, actual_arity) else {
        return Ok(());
    };
    ctx.capture_helper_arity_failure(name, actual_arity, expected, rule_label);
    Err(format!(
        "helper_arity_mismatch helper_name={name} actual_arity={actual_arity} expected_arity={expected:?} rule_label={rule_label:?}"
    ))
}

fn validate_eager_helper_arity(
    name: &str,
    raw_args: &[Arg],
    actual_arity: usize,
    ctx: &mut RuntimeContext,
    rule_label: &str,
) -> Result<(), String> {
    validate_diagnostic_output_arity(name, raw_args, actual_arity, ctx, rule_label)?;
    validate_logical_helper_arity(name, raw_args, actual_arity, ctx, rule_label)?;
    if matches!(
        name,
        "entry_slot"
            | "gap_span"
            | "gap_text"
            | "gap_kind"
            | "save_cursor"
            | "restore_cursor"
            | "rewind_entry_start"
            | "rewind_match_start"
    ) && (!raw_args.is_empty() || actual_arity != 0)
    {
        ctx.capture_helper_arity_failure(
            name,
            actual_arity,
            "exactly 0 positional arguments",
            rule_label,
        );
        return Err(format!(
            "helper_arity_mismatch helper_name={name} actual_arity={actual_arity} expected_arity=\"exactly 0 positional arguments\" rule_label={rule_label:?}"
        ));
    }
    Ok(())
}

/// Per-invocation controls for direct effective-entry value execution.
///
/// These options do not mutate the compiled specification. They select an
/// optional entry rule and optional typed semantic observation sink; every
/// entered rule retains its authored cursor policy.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct ExecutionOptions {
    entry_rule: Option<String>,
    semantic_observation_sink: Option<RuntimeSemanticObservationSink>,
    bounded_child_parse_authority:
        Option<crate::bounded_child_parse_authority::ProgressiveExecutionSeed>,
    staged_ast_enrichment: Option<crate::staged_ast_enrichment::StagedAstEnrichmentSeed>,
}

impl ExecutionOptions {
    /// Create default options that use authored default entry selection.
    pub fn new() -> Self {
        Self::default()
    }

    /// Select the rule entered first for this execution.
    pub fn with_entry_rule(mut self, label: impl Into<String>) -> Self {
        self.entry_rule = Some(label.into());
        self
    }

    /// Return the selected entry rule, if any.
    pub fn entry_rule(&self) -> Option<&str> {
        self.entry_rule.as_deref()
    }

    /// Install one caller-owned typed semantic sink for this invocation.
    pub fn with_semantic_observation_sink(mut self, sink: RuntimeSemanticObservationSink) -> Self {
        self.semantic_observation_sink = Some(sink);
        self
    }

    /// Return the invocation-local semantic sink, if one was selected.
    pub fn semantic_observation_sink(&self) -> Option<&RuntimeSemanticObservationSink> {
        self.semantic_observation_sink.as_ref()
    }

    /// Install one opaque host authority for private bounded child parsing.
    #[doc(hidden)]
    pub fn with_bounded_child_parse_authority(
        mut self,
        seed: crate::bounded_child_parse_authority::ProgressiveExecutionSeed,
    ) -> Self {
        self.bounded_child_parse_authority = Some(seed);
        self
    }

    pub(crate) fn bounded_child_parse_authority(
        &self,
    ) -> Option<&crate::bounded_child_parse_authority::ProgressiveExecutionSeed> {
        self.bounded_child_parse_authority.as_ref()
    }

    /// Install one opaque host recipe for private post-AST enrichment.
    #[doc(hidden)]
    pub fn with_staged_ast_enrichment(
        mut self,
        seed: crate::staged_ast_enrichment::StagedAstEnrichmentSeed,
    ) -> Self {
        self.staged_ast_enrichment = Some(seed);
        self
    }

    pub(crate) fn staged_ast_enrichment(
        &self,
    ) -> Option<&crate::staged_ast_enrichment::StagedAstEnrichmentSeed> {
        self.staged_ast_enrichment.as_ref()
    }
}

#[derive(Debug, Clone, PartialEq, Eq, serde::Serialize)]
#[serde(untagged)]
enum EvaluatedAccessSegment {
    Key(String),
    Index(usize),
    NegativeIndex(i128),
}

impl EvaluatedAccessSegment {
    fn expected_container_kind(&self) -> &'static str {
        match self {
            Self::Key(_) => "harray",
            Self::Index(_) | Self::NegativeIndex(_) => "array",
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
enum NestedWriteFailure {
    InvalidSegment {
        actual_kind: &'static str,
        reason: &'static str,
    },
    KindConflict {
        expected_kind: &'static str,
        actual_kind: &'static str,
    },
    ArrayGap {
        index: usize,
        length: usize,
    },
    ArrayUnderflow {
        index: i128,
        length: usize,
        resolved_index: i128,
    },
}

#[derive(serde::Serialize)]
#[serde(untagged)]
enum NestedWriteDiagnosticIndex {
    Unsigned(usize),
    Signed(i128),
}

#[derive(serde::Serialize)]
struct NestedWriteDiagnosticSpan {
    end: usize,
    provenance: &'static str,
    start: usize,
    unit: &'static str,
}

// Field order preserves the established canonical JSON spelling. Typed serde
// writes signed diagnostic integers exactly without a generic Value conversion.
#[derive(serde::Serialize)]
struct NestedWritePayload<'a> {
    #[serde(skip_serializing_if = "Option::is_none")]
    actual_kind: Option<&'static str>,
    binding: &'a str,
    code: &'static str,
    #[serde(skip_serializing_if = "Option::is_none")]
    expected_kind: Option<&'static str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    index: Option<NestedWriteDiagnosticIndex>,
    #[serde(skip_serializing_if = "Option::is_none")]
    length: Option<usize>,
    message: String,
    operation: &'static str,
    path: &'a [EvaluatedAccessSegment],
    #[serde(skip_serializing_if = "Option::is_none")]
    reason: Option<&'static str>,
    #[serde(skip_serializing_if = "Option::is_none")]
    resolved_index: Option<i128>,
    segment_index: usize,
    source_span: NestedWriteDiagnosticSpan,
}

/// Typed internal diagnostic for the neutral nested-write boundary.
///
/// The public engine still returns its established `String` error channel, so
/// `Display` emits one deterministic structured JSON object at that boundary.
#[derive(Debug, Clone, PartialEq, Eq)]
struct NestedWriteError {
    binding: String,
    segment_index: usize,
    path: Vec<EvaluatedAccessSegment>,
    source_span: ExpressionSpan,
    failure: NestedWriteFailure,
}

impl NestedWriteError {
    fn payload(&self) -> NestedWritePayload<'_> {
        let mut payload = NestedWritePayload {
            actual_kind: None,
            binding: &self.binding,
            code: "",
            expected_kind: None,
            index: None,
            length: None,
            message: String::new(),
            operation: "nested_write_vivification",
            path: &self.path,
            reason: None,
            resolved_index: None,
            segment_index: self.segment_index,
            source_span: NestedWriteDiagnosticSpan {
                end: self.source_span.end,
                provenance: "authored",
                start: self.source_span.start,
                unit: "unicode_scalar",
            },
        };
        match &self.failure {
            NestedWriteFailure::InvalidSegment {
                actual_kind,
                reason,
            } => {
                payload.code = "nested_write_segment_invalid";
                payload.actual_kind = Some(actual_kind);
                payload.reason = Some(reason);
                payload.message = format!(
                    "nested write segment {} for binding '{}' must evaluate to a string or nonnegative integer; got {} ({})",
                    self.segment_index, self.binding, actual_kind, reason,
                );
            }
            NestedWriteFailure::KindConflict {
                expected_kind,
                actual_kind,
            } => {
                payload.code = "nested_write_kind_conflict";
                payload.actual_kind = Some(actual_kind);
                payload.expected_kind = Some(expected_kind);
                payload.message = format!(
                    "nested write segment {} for binding '{}' requires {}; found {}",
                    self.segment_index, self.binding, expected_kind, actual_kind,
                );
            }
            NestedWriteFailure::ArrayGap { index, length } => {
                payload.code = "nested_write_array_gap";
                payload.index = Some(NestedWriteDiagnosticIndex::Unsigned(*index));
                payload.length = Some(*length);
                payload.message = format!(
                    "nested write segment {} for binding '{}' cannot create array index {} at length {}",
                    self.segment_index, self.binding, index, length,
                );
            }
            NestedWriteFailure::ArrayUnderflow {
                index,
                length,
                resolved_index,
            } => {
                payload.code = "nested_write_array_underflow";
                payload.index = Some(NestedWriteDiagnosticIndex::Signed(*index));
                payload.length = Some(*length);
                payload.resolved_index = Some(*resolved_index);
                payload.message = format!(
                    "nested write segment {} for binding '{}' cannot select array index {} at length {} (resolved index {})",
                    self.segment_index, self.binding, index, length, resolved_index,
                );
            }
        }
        payload
    }
}

impl std::fmt::Display for NestedWriteError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        let encoded = serde_json::to_string(&self.payload()).map_err(|_| std::fmt::Error)?;
        formatter.write_str(&encoded)
    }
}

impl std::error::Error for NestedWriteError {}

#[derive(Debug, Clone, PartialEq, Eq)]
enum ReceiverMutationFailure {
    Missing,
    KindMismatch { actual_kind: &'static str },
    Reentrant { attempt: String },
}

/// Typed runtime diagnostic for the frozen `map_leaves!` boundary.
#[derive(Debug, Clone, PartialEq, Eq)]
struct ReceiverMutationError {
    binding: String,
    source_span: ExpressionSpan,
    failure: ReceiverMutationFailure,
}

impl ReceiverMutationError {
    fn payload(&self) -> Value {
        let source_span = json!({
            "start": self.source_span.start,
            "end": self.source_span.end,
            "unit": "unicode_scalar",
            "provenance": "authored",
        });
        match &self.failure {
            ReceiverMutationFailure::Missing => json!({
                "code": "map_leaves_mutation_receiver_missing",
                "operation": "map_leaves_mutation",
                "binding": self.binding,
                "method": "map_leaves",
                "source_span": source_span,
                "message": format!(
                    "map_leaves! receiver binding '{}' does not exist",
                    self.binding,
                ),
            }),
            ReceiverMutationFailure::KindMismatch { actual_kind } => json!({
                "code": "map_leaves_mutation_receiver_kind_mismatch",
                "operation": "map_leaves_mutation",
                "binding": self.binding,
                "method": "map_leaves",
                "expected_kinds": ["harray", "array"],
                "actual_kind": actual_kind,
                "source_span": source_span,
                "message": format!(
                    "map_leaves! receiver '{}' must hold an harray or array, got {}",
                    self.binding, actual_kind,
                ),
            }),
            ReceiverMutationFailure::Reentrant { attempt } => json!({
                "code": "receiver_mutation_reentrant",
                "operation": "map_leaves_mutation",
                "binding": self.binding,
                "method": "map_leaves",
                "attempt": attempt,
                "source_span": source_span,
                "message": format!(
                    "cannot write active map_leaves! receiver binding '{}' from its callback",
                    self.binding,
                ),
            }),
        }
    }
}

impl std::fmt::Display for ReceiverMutationError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(formatter, "{}", self.payload())
    }
}

impl std::error::Error for ReceiverMutationError {}

/// The runtime engine executes CompiledRule nodes against input text.
pub struct Engine {
    /// The compiled spec being executed (needed for child rule lookup).
    spec: CompiledSpec,
    spec_name: Option<String>,
    spec_path: Option<String>,
}

/// Saved per-invocation entry/local match state.
///
/// In the Perl reference, the entry match (`IMATCH`) and the local match
/// (`LMATCH`) are per-handler `my` lexicals, so a child rule's matching can
/// never mutate the parent's match state. The Rust engine shares one
/// `RuntimeContext` across the whole parse, so `execute_rule` emulates that
/// lexical scoping: on entry it saves the caller's match state here, and on exit
/// it restores it — making nested dispatch transparent to the parent.
struct SavedMatchState {
    entry_groups: Vec<String>,
    entry_group_spans: Vec<(usize, usize)>,
    entry_named: std::collections::HashMap<String, String>,
    entry_match_present: bool,
    match_groups: Vec<String>,
    match_group_spans: Vec<(usize, usize)>,
    match_named: std::collections::HashMap<String, String>,
    match_present: bool,
    entry_start_byte: usize,
    entry_end_byte: usize,
    match_start_byte: usize,
    match_end_byte: usize,
    capture_start: Option<usize>,
}

/// Statement-form conditional state for lifecycle blocks.
///
/// This is deliberately separate from the expression-level `if(...)` helper:
/// `if(cond, then, else)` remains a lazy value expression, while
/// `if(cond); ... else(); ... endif()` gates subsequent statements in the block.
struct StatementIfFrame {
    parent_active: bool,
    current_active: bool,
    branch_taken: bool,
}

/// Statement-form switch state for lifecycle blocks.
///
/// `switch(expr); case(value); ... default(); ... endswitch()` is the statement
/// sibling of lazy value-form `switch(expr, case(...), default(...))`.
struct StatementSwitchFrame {
    parent_active: bool,
    current_active: bool,
    branch_taken: bool,
    switch_value: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum StatementBlockFlow {
    Continue,
    Returned,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
enum ActionEdgeFlow {
    Continue,
    Returned,
}

enum ValueBlockFlow {
    Continue,
    Returned(RuntimeValue),
}

impl SavedMatchState {
    /// Restore the saved caller match state onto the context (invocation exit).
    fn restore(self, ctx: &mut RuntimeContext) {
        ctx.entry_groups = self.entry_groups;
        ctx.entry_group_spans = self.entry_group_spans;
        ctx.entry_named = self.entry_named;
        ctx.entry_match_present = self.entry_match_present;
        ctx.match_groups = self.match_groups;
        ctx.match_group_spans = self.match_group_spans;
        ctx.match_named = self.match_named;
        ctx.match_present = self.match_present;
        ctx.entry_start_byte = self.entry_start_byte;
        ctx.entry_end_byte = self.entry_end_byte;
        ctx.match_start_byte = self.match_start_byte;
        ctx.match_end_byte = self.match_end_byte;
        ctx.capture_start = self.capture_start;
    }
}

/// Convert a **byte** offset into `input` to a **character** offset. Internal
/// positions (`ctx.pos`, marks, match spans, regex byte offsets) are byte-based,
/// but the Perl reference exposes char offsets (`pos()` is char-based), so every
/// position/length surfaced to the DSL goes through this.
fn byte_to_char_offset(input: &str, byte_off: usize) -> usize {
    let clamped = byte_off.min(input.len());
    input[..clamped].chars().count()
}

// Mirror the Perl public parser wrapper. Keep the full source and absolute byte
// coordinates; this boundary applies once per invocation, never on child entry.
fn public_input_start(input: &str) -> usize {
    let bytes = input.as_bytes();
    let mut start = 0;
    loop {
        let mut next = start;
        while matches!(bytes.get(next), Some(b' ' | b'\t')) {
            next += 1;
        }
        match bytes.get(next) {
            Some(b'\n') => start = next + 1,
            Some(b'#') => {
                while next < bytes.len() && bytes[next] != b'\n' {
                    next += 1;
                }
                start = if next < bytes.len() { next + 1 } else { next };
            }
            _ => return start,
        }
    }
}

/// `len` characters of `s` starting at character index `start` (Perl `substr`
/// semantics — char-based, never panics on a multibyte boundary).
fn char_substr(s: &str, start: usize, len: usize) -> String {
    s.chars().skip(start).take(len).collect()
}

/// The suffix of `s` from character index `start` (`substr($s, $start)`).
fn char_substr_from(s: &str, start: usize) -> String {
    s.chars().skip(start).collect()
}

fn next_char_boundary_after(input: &str, byte_off: usize) -> usize {
    if byte_off >= input.len() {
        return input.len();
    }
    input[byte_off..]
        .char_indices()
        .nth(1)
        .map(|(offset, _)| byte_off + offset)
        .unwrap_or(input.len())
}

fn regex_literal_arg(args: &[Arg], index: usize) -> Option<&str> {
    match args.get(index).map(Arg::value) {
        Some(Expr::RegexLiteral { pattern }) => Some(pattern.as_str()),
        _ => None,
    }
}

fn scalar_mutation_target_arg(arg: &Arg) -> Option<String> {
    match arg.value() {
        Expr::Variable { name } => Some(name.clone()),
        _ => None,
    }
}

fn regex_subst_call_parts(raw_args: &[Arg]) -> Option<(String, usize, usize, usize)> {
    if raw_args.len() >= 5
        && let Some(target) = scalar_mutation_target_arg(&raw_args[1])
    {
        return Some((target, 2, 3, 4));
    }
    if raw_args.len() >= 4
        && let Some(target) = scalar_mutation_target_arg(&raw_args[0])
    {
        return Some((target, 1, 2, 3));
    }
    None
}

fn array_mutation_target_arg(arg: &Arg) -> Option<String> {
    match arg.value() {
        Expr::Variable { name } => Some(name.clone()),
        _ => None,
    }
}

fn bare_variable_target_arg(arg: &Arg) -> Option<&str> {
    match arg.value() {
        Expr::Variable { name } => Some(name.as_str()),
        _ => None,
    }
}

fn split_statement_call_parts(raw_args: &[Arg]) -> Option<(String, usize, usize)> {
    if raw_args.len() >= 4
        && let Some(target) = array_mutation_target_arg(&raw_args[1])
    {
        return Some((target, 2, 3));
    }
    if raw_args.len() >= 3
        && let Some(target) = array_mutation_target_arg(&raw_args[0])
    {
        return Some((target, 1, 2));
    }
    None
}

fn literal_or_value_arg_text(raw_args: &[Arg], args: &[RuntimeValue], index: usize) -> String {
    match raw_args.get(index).map(Arg::value) {
        Some(Expr::StringLiteral { value }) | Some(Expr::RegexLiteral { pattern: value }) => {
            value.clone()
        }
        _ => args
            .get(index)
            .map(RuntimeValue::to_str)
            .unwrap_or_default(),
    }
}

fn regex_subst_flags_arg(raw_args: &[Arg], args: &[RuntimeValue], index: usize) -> String {
    match raw_args.get(index).map(Arg::value) {
        Some(Expr::Variable { name }) => name.clone(),
        Some(Expr::StringLiteral { value }) | Some(Expr::RegexLiteral { pattern: value }) => {
            value.clone()
        }
        _ => args
            .get(index)
            .map(RuntimeValue::to_str)
            .unwrap_or_default(),
    }
}

fn regex_subst_pattern_with_flags(pattern: &str, flags: &str) -> String {
    let mut inline_flags = String::new();
    for flag in ['i', 'm', 's', 'x'] {
        if flags.contains(flag) {
            inline_flags.push(flag);
        }
    }
    if inline_flags.is_empty() {
        pattern.to_string()
    } else {
        format!("(?{inline_flags}:{pattern})")
    }
}

fn split_string_literal(input: &str, delimiter: &str) -> Vec<RuntimeValue> {
    input
        .split(delimiter)
        .map(|part| RuntimeValue::Scalar(part.to_string()))
        .collect()
}

fn split_string_regex(input: &str, pattern: &str) -> Result<Vec<RuntimeValue>, String> {
    let alt = CompiledAlternation::compile(&[pattern.to_string()])?;
    let mut parts = Vec::new();
    let mut slice_start = 0usize;
    let mut search_start = 0usize;

    while search_start <= input.len() {
        let Some(matched) = alt.seek_match(input, search_start) else {
            break;
        };

        if matched.start < slice_start {
            break;
        }

        parts.push(RuntimeValue::Scalar(
            input[slice_start..matched.start].to_string(),
        ));
        slice_start = matched.end;

        if matched.start == matched.end {
            if matched.end >= input.len() {
                break;
            }
            search_start = next_char_boundary_after(input, matched.end);
        } else {
            search_start = matched.end;
        }
    }

    parts.push(RuntimeValue::Scalar(input[slice_start..].to_string()));
    Ok(parts)
}

fn split_string_for_arg(
    input: &str,
    raw_args: &[Arg],
    delimiter_index: usize,
    delimiter: &RuntimeValue,
) -> Result<Vec<RuntimeValue>, String> {
    if let Some(pattern) = regex_literal_arg(raw_args, delimiter_index) {
        split_string_regex(input, pattern)
    } else {
        Ok(split_string_literal(input, &delimiter.to_str()))
    }
}

fn trace_write_failed(err: impl std::fmt::Display) -> String {
    format!("trace write failed: {err}")
}

fn runtime_value_trace_kind(value: &RuntimeValue) -> &'static str {
    match value {
        RuntimeValue::Undef => "undef",
        RuntimeValue::Bool(_) => "bool",
        RuntimeValue::Number(_) => "number",
        RuntimeValue::Scalar(_) => "scalar",
        RuntimeValue::Array(_) => "array",
        RuntimeValue::Hash(_) => "hash",
        RuntimeValue::Codeblock(_) => "codeblock",
    }
}

fn child_result_is_match(ctx: &mut RuntimeContext, value: &RuntimeValue) -> bool {
    ctx.recognition_result_is_match(value.as_bool())
}

struct GeneratedPlanExecutor<'a> {
    engine: &'a Engine,
    generated_rules: &'a [GeneratedRuleSpec],
    source_identity: Option<&'a str>,
}

impl GeneratedPlanExecutor<'_> {
    fn execute_rule(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        self.execute_rule_with_entry_slot(label, entry_regex_idx, ctx, None)
    }

    fn execute_rule_with_entry_slot(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
        entry_slot: Option<crate::recognition_transaction::GapEntrySlot>,
    ) -> Result<RuntimeValue, String> {
        let entry_pos = ctx.pos;
        if let Some(source_identity) = self.source_identity {
            ctx.trace_mark(
                "generated_rule_enter",
                format!(
                    "source_identity={source_identity:?} rule={label} entry_regex_idx={entry_regex_idx} pos={entry_pos}"
                ),
                TraceLevel::LOW,
            );
        }
        ctx.trace_enter(
            "rust_runtime:generated_plan:rule",
            format!("label={label} entry_regex_idx={entry_regex_idx} pos={entry_pos}"),
            TraceLevel::LOW,
        );
        let result = (|| {
            let family = self.generated_rule_family(label)?;
            if let Some(source_identity) = self.source_identity {
                ctx.trace_mark(
                    "generated_family_decision",
                    format!(
                        "source_identity={source_identity:?} rule={label} family={}",
                        family.contract_name()
                    ),
                    TraceLevel::LOW,
                );
            }
            ctx.trace_decision(
                "rust_runtime:generated_plan:family_dispatch",
                true,
                format!("label={label} family={family:?} entry_regex_idx={entry_regex_idx}"),
                TraceLevel::MEDIUM,
            );
            match family {
                GeneratedRuleFamily::Default
                | GeneratedRuleFamily::OrAcode
                | GeneratedRuleFamily::AndSingleAcode
                | GeneratedRuleFamily::AndAcodeSeq => {
                    self.execute_direct_acode_rule(label, entry_regex_idx, family, ctx, entry_slot)
                }
                GeneratedRuleFamily::AndBcode | GeneratedRuleFamily::OrBcode => {
                    self.execute_direct_bcode_rule(label, entry_regex_idx, family, ctx, entry_slot)
                }
                GeneratedRuleFamily::RepAcode | GeneratedRuleFamily::RepAndAcode => {
                    self.execute_direct_acode_rule(label, entry_regex_idx, family, ctx, entry_slot)
                }
                GeneratedRuleFamily::RepBcode | GeneratedRuleFamily::RepAndBcode => {
                    self.execute_direct_bcode_rule(label, entry_regex_idx, family, ctx, entry_slot)
                }
            }
        })();
        let status = match &result {
            Ok(value) => format!("status=ok value_kind={}", runtime_value_trace_kind(value)),
            Err(err) => format!("status=error error={err}"),
        };
        ctx.trace_exit(
            "rust_runtime:generated_plan:rule",
            format!("{status} label={label} pos={}", ctx.pos),
            TraceLevel::LOW,
        );
        if let Some(source_identity) = self.source_identity {
            ctx.trace_mark(
                "generated_rule_exit",
                format!("source_identity={source_identity:?} rule={label} {status}"),
                TraceLevel::LOW,
            );
        }
        result
    }

    fn generated_rule_family(&self, label: &str) -> Result<GeneratedRuleFamily, String> {
        self.generated_rules
            .iter()
            .find(|rule| rule.label == label)
            .map(|rule| rule.family)
            .ok_or_else(|| format!("generated rule plan missing label '{label}'"))
    }

    fn prepare_selected_acode_match(
        &self,
        rule: &CompiledRule,
        label: &str,
        matched: &MatchResult,
        required_step: Option<AndRequiredStep>,
        ctx: &mut RuntimeContext,
    ) -> Result<(), String> {
        ctx.note_recognition_match(matched.start, matched.end);
        let (target_rule, target_regex_index) = required_step
            .map(|step| step.slot_identity(rule, step.regex_index))
            .unwrap_or_else(|| structural_slot_identity(rule, matched.index));
        let (actual_target_rule, actual_regex_index) = required_step
            .map(|step| step.slot_identity(rule, matched.index))
            .unwrap_or_else(|| structural_slot_identity(rule, matched.index));
        if required_step.is_some()
            && let Err(error) = assert_ordered_regex_slot_identity(
                label,
                target_rule,
                target_regex_index,
                actual_target_rule,
                actual_regex_index,
            )
        {
            ctx.capture_ordered_regex_slot_identity_lost(
                label,
                target_rule,
                target_regex_index,
                actual_regex_index,
            );
            return Err(error.to_string());
        }
        ctx.trace_decision(
            "rust_runtime:generated_plan:regex_slot_selected",
            true,
            format!(
                "rule_label={label} selection_role={} target_rule={target_rule} regex_index={target_regex_index}",
                if rule.mode.is_and() {
                    "ordered_required"
                } else {
                    "choice"
                }
            ),
            TraceLevel::MEDIUM,
        );

        let entry_was_empty = !ctx.entry_match_present;
        ctx.set_pos(matched.end);
        if ctx.semantic_observation_enabled() {
            ctx.emit_regex_slot_selected(
                label,
                target_rule,
                target_regex_index,
                byte_to_char_offset(&ctx.input, matched.end),
            );
        }
        ctx.match_groups = matched.captures.clone();
        ctx.match_group_spans = matched.capture_spans.clone();
        ctx.match_named = matched.named.clone();
        ctx.match_start_byte = matched.start;
        ctx.match_end_byte = matched.end;
        ctx.match_present = true;
        if entry_was_empty {
            ctx.entry_groups = matched.captures.clone();
            ctx.entry_group_spans = matched.capture_spans.clone();
            ctx.entry_named = matched.named.clone();
            ctx.entry_start_byte = matched.start;
            ctx.entry_end_byte = matched.end;
            ctx.entry_match_present = true;
        }
        Ok(())
    }

    fn execute_child_rule(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        self.execute_child_rule_with_entry_slot(label, entry_regex_idx, ctx, None)
    }

    fn execute_child_rule_with_entry_slot(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
        entry_slot: Option<crate::recognition_transaction::GapEntrySlot>,
    ) -> Result<RuntimeValue, String> {
        let accumulator_len = ctx.accumulator.len();
        ctx.trace_decision(
            "rust_runtime:generated_plan:child_dispatch",
            true,
            format!(
                "label={label} entry_regex_idx={entry_regex_idx} pos={} accumulator_len={accumulator_len}",
                ctx.pos
            ),
            TraceLevel::MEDIUM,
        );
        let child_result =
            self.execute_rule_with_entry_slot(label, entry_regex_idx, ctx, entry_slot);
        ctx.accumulator.truncate(accumulator_len);
        match &child_result {
            Ok(value) => {
                ctx.trace_decision(
                    "rust_runtime:generated_plan:child_dispatch_result",
                    value.as_bool(),
                    format!(
                        "label={label} value_kind={}",
                        runtime_value_trace_kind(value)
                    ),
                    TraceLevel::MEDIUM,
                );
            }
            Err(err) => {
                ctx.trace_decision(
                    "rust_runtime:generated_plan:child_dispatch_result",
                    false,
                    format!("label={label} error={err}"),
                    TraceLevel::MEDIUM,
                );
            }
        }
        child_result
    }

    fn execute_action_edge_child_entry(
        &self,
        entry: &linkedspec_core::types::AcodeEntry,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        if self.engine.is_passive_terminal_rule(&entry.child_label) {
            ctx.trace_decision(
                "rust_runtime:generated_plan:passive_terminal_dispatch",
                false,
                format!(
                    "label={} entry_regex_idx={} pos={}",
                    entry.child_label, entry.child_regex_idx, ctx.pos
                ),
                TraceLevel::MEDIUM,
            );
            return Ok(RuntimeValue::Undef);
        }
        let entry_slot = ctx.gap_entry_slot_for_edge(entry);
        self.execute_child_rule_with_entry_slot(
            &entry.child_label,
            entry.child_regex_idx,
            ctx,
            entry_slot,
        )
    }

    fn execute_direct_acode_rule(
        &self,
        label: &str,
        entry_regex_idx: usize,
        family: GeneratedRuleFamily,
        ctx: &mut RuntimeContext,
        entry_slot: Option<crate::recognition_transaction::GapEntrySlot>,
    ) -> Result<RuntimeValue, String> {
        let entry_pos = ctx.pos;
        if !ctx.enter_recursion(label, entry_pos) {
            ctx.trace_decision(
                "rust_runtime:generated_plan:recursion_guard",
                false,
                format!("label={label} entry_regex_idx={entry_regex_idx} pos={entry_pos}"),
                TraceLevel::MEDIUM,
            );
            if ctx.recursive_observation_expects(label) {
                return Err(ctx.reject_recursive_observation(label, entry_pos));
            }
            return Ok(RuntimeValue::Undef);
        }

        let capture_gaps = self
            .engine
            .spec
            .find(label)
            .and_then(|rule| rule.capture_gaps.as_ref())
            .is_some_and(|directive| directive.enabled);
        if let Err(error) = ctx.enter_recognition_invocation(label, capture_gaps, entry_slot) {
            ctx.exit_recursion(label, entry_pos);
            return Err(error);
        }
        ctx.note_recursive_observation_entry(label);

        ctx.enter_rule_variable_scope(label);
        ctx.trace_enter(
            "rust_runtime:generated_plan:direct_acode_rule",
            format!(
                "label={label} entry_regex_idx={entry_regex_idx} family={family:?} pos={entry_pos}"
            ),
            TraceLevel::MEDIUM,
        );
        let result = self.execute_direct_acode_rule_inner(label, entry_regex_idx, family, ctx);
        let status = match &result {
            Ok(value) => format!("status=ok value_kind={}", runtime_value_trace_kind(value)),
            Err(err) => format!("status=error error={err}"),
        };
        ctx.trace_exit(
            "rust_runtime:generated_plan:direct_acode_rule",
            format!("{status} label={label} pos={}", ctx.pos),
            TraceLevel::MEDIUM,
        );
        ctx.exit_rule_variable_scope();
        let result = match ctx.leave_recognition_invocation(label) {
            Err(error) if result.is_ok() => Err(error),
            _ => result,
        };
        ctx.exit_recursion(label, entry_pos);
        result
    }

    fn execute_direct_acode_rule_inner(
        &self,
        label: &str,
        entry_regex_idx: usize,
        family: GeneratedRuleFamily,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        let rule = self.engine.spec.find(label).ok_or_else(|| {
            format!(
                "rule '{}' (entry idx {}) not found in compiled spec",
                label, entry_regex_idx
            )
        })?;

        let caller_return = ctx.take_return_value();
        let saved_match = SavedMatchState {
            entry_groups: std::mem::take(&mut ctx.entry_groups),
            entry_group_spans: std::mem::take(&mut ctx.entry_group_spans),
            entry_named: std::mem::take(&mut ctx.entry_named),
            entry_match_present: ctx.entry_match_present,
            match_groups: std::mem::take(&mut ctx.match_groups),
            match_group_spans: std::mem::take(&mut ctx.match_group_spans),
            match_named: std::mem::take(&mut ctx.match_named),
            match_present: ctx.match_present,
            entry_start_byte: ctx.entry_start_byte,
            entry_end_byte: ctx.entry_end_byte,
            match_start_byte: ctx.match_start_byte,
            match_end_byte: ctx.match_end_byte,
            capture_start: ctx.capture_start,
        };
        ctx.entry_groups = saved_match.match_groups.clone();
        ctx.entry_group_spans = saved_match.match_group_spans.clone();
        ctx.entry_named = saved_match.match_named.clone();
        ctx.entry_match_present = saved_match.match_present;
        ctx.entry_start_byte = saved_match.match_start_byte;
        ctx.entry_end_byte = saved_match.match_end_byte;
        ctx.match_start_byte = 0;
        ctx.match_end_byte = 0;
        ctx.match_present = false;
        ctx.capture_start = Some(ctx.entry_end_byte);

        macro_rules! return_if_rule_returned {
            () => {
                if let Some(my_return) = ctx.take_return_value() {
                    ctx.restore_return_value(caller_return);
                    saved_match.restore(ctx);
                    return Ok(my_return);
                }
            };
        }

        let alt = if rule.regex_patterns.is_empty() {
            CompiledAlternation::compile(&[])?
        } else {
            CompiledAlternation::compile(&rule.regex_patterns)?
        };

        if let Some(ref preamble) = rule.preamble {
            self.engine
                .execute_lifecycle_block("I", preamble, ctx, label)?;
            return_if_rule_returned!();
        }

        if !rule.bcode_dispatch.is_empty() {
            ctx.restore_return_value(caller_return);
            saved_match.restore(ctx);
            return Err(format!(
                "generated direct acode executor received bcode rule '{label}'"
            ));
        }

        let is_rep = rule.rep_min.is_some();
        let rep_min = rule.rep_min.unwrap_or(0);
        let rep_max = rule.rep_max;
        let collects_action_values = collects_explicit_action_iteration_values(rule);
        // AND returns unwind the current group, unlike per-hit CHOICE values.
        // Keep its value separate from slot position and accepted-group count.
        let collects_and_groups = is_rep && rule.mode.is_and() && !rule.acode_dispatch.is_empty();
        let mut and_group_return = None;
        let mut action_iteration_values = Vec::new();

        macro_rules! collect_or_return_action_value {
            ($group_dispatch:lifetime) => {
                if let Some(value) = ctx.take_return_value() {
                    if collects_and_groups {
                        and_group_return = Some(value);
                        break $group_dispatch;
                    } else if collects_action_values {
                        action_iteration_values.push(value);
                    } else {
                        ctx.restore_return_value(caller_return);
                        saved_match.restore(ctx);
                        return Ok(value);
                    }
                }
            };
        }
        let and_steps = and_required_steps(rule);
        let is_and_acode_seq = and_steps.len() > 1
            || and_steps
                .first()
                .is_some_and(|step| step.action_index.is_some());
        let is_rep_and_acode_seq = is_rep && is_and_acode_seq;
        let and_acode_seq_len = and_steps.len();
        let mut matches: usize = 0;
        let mut and_acode_idx: usize = 0;
        let mut rep_and_start_pos = ctx.pos;
        let max_iter = 10_000;
        let capture_gaps = rule
            .capture_gaps
            .as_ref()
            .is_some_and(|directive| directive.enabled);
        let has_entry_idx = entry_regex_idx > 0 && entry_regex_idx < rule.regex_patterns.len();

        for _iter in 0..max_iter {
            if is_rep_and_acode_seq && and_acode_idx == 0 {
                rep_and_start_pos = ctx.pos;
            }
            if !is_rep && !is_and_acode_seq && matches > 0 && !capture_gaps {
                break;
            }
            if !is_rep && is_and_acode_seq && matches >= and_acode_seq_len {
                break;
            }
            if is_rep_and_acode_seq
                && let Some(max) = rep_max
                && matches >= max
            {
                break;
            }

            let pos_before = ctx.pos;
            // Generated-source v2 derives cursor spending from the validated
            // family row; no mutable/global cursor field crosses the artifact.
            let cursor_policy = family.cursor_policy();
            let required_step = is_and_acode_seq.then(|| {
                and_steps[if is_rep_and_acode_seq {
                    and_acode_idx
                } else {
                    matches
                }]
            });
            let required_and_idx = required_step.map(|step| step.regex_index);
            let match_result = if capture_gaps {
                Engine::select_native_match(
                    rule,
                    &alt,
                    &ctx.input,
                    ctx.pos,
                    cursor_policy,
                    required_and_idx,
                    has_entry_idx,
                    matches,
                    entry_regex_idx,
                )?
            } else {
                // Preserve historical generated-plan ordering for every
                // unflagged rule: LS runs before selection and local-match
                // installation.
                if let Some(ref lscode) = rule.lscode {
                    self.engine
                        .execute_lifecycle_block("LS", lscode, ctx, label)?;
                    return_if_rule_returned!();
                }
                Engine::select_native_match(
                    rule,
                    &alt,
                    &ctx.input,
                    ctx.pos,
                    cursor_policy,
                    required_and_idx,
                    has_entry_idx,
                    matches,
                    entry_regex_idx,
                )?
            };

            match &match_result {
                Some(m) => {
                    ctx.trace_decision(
                        "rust_runtime:generated_plan:regex_match",
                        true,
                        format!(
                            "rule={label} regex_idx={} start={} end={} pos_before={pos_before} cursor_policy={:?} entry_regex_idx={entry_regex_idx}",
                            m.index, m.start, m.end, cursor_policy
                        ),
                        TraceLevel::MEDIUM,
                    );
                }
                None => {
                    ctx.trace_decision(
                        "rust_runtime:generated_plan:regex_match",
                        false,
                        format!(
                            "rule={label} pos_before={pos_before} cursor_policy={:?} entry_regex_idx={entry_regex_idx}",
                            cursor_policy
                        ),
                        TraceLevel::MEDIUM,
                    );
                }
            }

            if let Some(matched) = &match_result {
                self.prepare_selected_acode_match(rule, label, matched, required_step, ctx)?;
                if capture_gaps {
                    ctx.install_gap_candidate(matched.start);
                }
            }

            if capture_gaps && match_result.is_some() {
                ctx.set_gap_phase("LS");
                if let Some(ref lscode) = rule.lscode {
                    self.engine
                        .execute_lifecycle_block("LS", lscode, ctx, label)?;
                    return_if_rule_returned!();
                }
            }

            if let Some(m) = match_result {
                ctx.set_gap_phase("edge");
                let mut dispatched_acode = false;
                'and_group_dispatch: for (action_index, entry) in
                    rule.acode_dispatch.iter().enumerate()
                {
                    if entry.regex_idx == m.index
                        && required_step.is_none_or(|step| step.dispatches(action_index))
                    {
                        dispatched_acode = true;
                        ctx.trace_decision(
                            "rust_runtime:generated_plan:acode_dispatch",
                            true,
                            format!(
                                "rule={label} regex_idx={} child={} child_regex_idx={} fluent_chain_len={} has_code={}",
                                entry.regex_idx,
                                entry.child_label,
                                entry.child_regex_idx,
                                entry.fluent_chain.len(),
                                entry.code.is_some()
                            ),
                            TraceLevel::MEDIUM,
                        );
                        if entry.fluent_chain.is_empty() {
                            if let Some(ref block) = entry.code {
                                let observes_child =
                                    Engine::block_observes_rule(block, &entry.child_label);
                                let calls_child =
                                    Engine::block_calls_rule(block, &entry.child_label);
                                let reads_retv = Engine::block_reads_retv(block);
                                if observes_child
                                    || (entry.child_label == label && !calls_child && !reads_retv)
                                {
                                    self.engine.execute_block(block, ctx, label)?;
                                    collect_or_return_action_value!('and_group_dispatch);
                                } else if calls_child || reads_retv {
                                    let child_retv =
                                        self.execute_action_edge_child_entry(entry, ctx)?;
                                    ctx.push_action_edge_call_result(
                                        &entry.child_label,
                                        child_retv.clone(),
                                    );
                                    ctx.set_retv(child_retv.clone());
                                    let block_result = self.engine.execute_block(block, ctx, label);
                                    ctx.pop_action_edge_call_result();
                                    block_result?;
                                    collect_or_return_action_value!('and_group_dispatch);
                                    ctx.set_retv(child_retv);
                                } else {
                                    self.engine.execute_block(block, ctx, label)?;
                                    collect_or_return_action_value!('and_group_dispatch);
                                    let child_retv =
                                        self.execute_action_edge_child_entry(entry, ctx)?;
                                    ctx.set_retv(child_retv);
                                }
                            } else {
                                let child_retv =
                                    self.execute_action_edge_child_entry(entry, ctx)?;
                                ctx.set_retv(child_retv);
                            }
                        } else if self
                            .engine
                            .execute_action_edge_fluent_chain(entry, ctx, label)?
                            == ActionEdgeFlow::Returned
                        {
                            collect_or_return_action_value!('and_group_dispatch);
                        }
                    }
                }
                if !dispatched_acode {
                    ctx.trace_decision(
                        "rust_runtime:generated_plan:acode_dispatch",
                        false,
                        format!("rule={label} regex_idx={} child=none", m.index),
                        TraceLevel::MEDIUM,
                    );
                }

                if and_group_return.is_none() {
                    ctx.set_gap_phase("LE");
                    if let Some(ref lecode) = rule.lecode {
                        self.engine
                            .execute_lifecycle_block("LE", lecode, ctx, label)?;
                        return_if_rule_returned!();
                    }
                }
                // Only a completed group/hit is a repetition iteration. In
                // AND, an intermediate zero-width slot can precede consuming
                // slots, and the last slot can itself be zero-width.
                if is_rep
                    && (!is_rep_and_acode_seq
                        || and_group_return.is_some()
                        || and_acode_idx + 1 == and_acode_seq_len)
                {
                    let iteration_start = if is_rep_and_acode_seq {
                        rep_and_start_pos
                    } else {
                        pos_before
                    };
                    ctx.assert_recognition_repetition_progress(label, iteration_start, ctx.pos)?;
                }
                // An accepted early group return skips its remaining slots,
                // then finalizes this candidate before the outer IT hook.
                ctx.commit_gap_candidate(label)?;

                if is_rep_and_acode_seq {
                    if and_group_return.is_none() {
                        and_acode_idx += 1;
                        if and_acode_idx < and_acode_seq_len {
                            continue;
                        }
                    }
                    and_acode_idx = 0;
                }
                matches += 1;
                if collects_and_groups {
                    let group_value = and_group_return
                        .take()
                        .unwrap_or_else(|| RuntimeValue::Array(Vec::new()));
                    // Authored IT replaces the reference's default push.
                    if rule.itcode.is_none() {
                        action_iteration_values.push(group_value);
                    }
                }

                ctx.set_gap_phase("IT");
                if let Some(ref itcode) = rule.itcode {
                    self.engine
                        .execute_lifecycle_block("IT", itcode, ctx, label)?;
                    return_if_rule_returned!();
                }
            } else {
                if !is_rep || matches >= rep_min {
                    ctx.install_gap_tail("LX");
                }
                ctx.set_gap_phase("LX");
                if let Some(ref lxcode) = rule.lxcode {
                    self.engine
                        .execute_lifecycle_block("LX", lxcode, ctx, label)?;
                    return_if_rule_returned!();
                }
                break;
            }

            if let Some(max) = rep_max
                && matches >= max
            {
                break;
            }

            let progress_start = if is_rep_and_acode_seq {
                rep_and_start_pos
            } else {
                pos_before
            };
            if is_rep && ctx.pos == progress_start {
                break;
            }
        }

        if is_rep && matches < rep_min {
            // A partial hit is not an accepted invocation when its minimum
            // fails. Keep the consumed cursor, but restore caller lexicals.
            ctx.note_recognition_outcome(false);
            ctx.restore_return_value(caller_return);
            saved_match.restore(ctx);
            return Ok(RuntimeValue::Undef);
        }

        if !is_rep && is_and_acode_seq && matches < and_acode_seq_len {
            ctx.restore_return_value(caller_return);
            saved_match.restore(ctx);
            return Ok(RuntimeValue::Undef);
        }

        if is_rep {
            ctx.install_gap_tail("EX");
        }
        ctx.set_gap_phase("EX");
        if let Some(ref excode) = rule.excode {
            self.engine
                .execute_lifecycle_block("EX", excode, ctx, label)?;
            return_if_rule_returned!();
        }

        if !is_rep {
            ctx.install_gap_tail("E");
        }
        ctx.set_gap_phase("E");
        if let Some(ref ecode) = rule.ecode {
            self.engine
                .execute_lifecycle_block("E", ecode, ctx, label)?;
            return_if_rule_returned!();
        }

        let my_return = ctx.take_return_value().unwrap_or_else(|| {
            if collects_action_values || collects_and_groups {
                RuntimeValue::Array(action_iteration_values)
            } else {
                RuntimeValue::Undef
            }
        });
        ctx.restore_return_value(caller_return);
        saved_match.restore(ctx);
        Ok(my_return)
    }

    fn execute_direct_bcode_rule(
        &self,
        label: &str,
        entry_regex_idx: usize,
        family: GeneratedRuleFamily,
        ctx: &mut RuntimeContext,
        entry_slot: Option<crate::recognition_transaction::GapEntrySlot>,
    ) -> Result<RuntimeValue, String> {
        let entry_pos = ctx.pos;
        if !ctx.enter_recursion(label, entry_pos) {
            ctx.trace_decision(
                "rust_runtime:generated_plan:recursion_guard",
                false,
                format!("label={label} entry_regex_idx={entry_regex_idx} pos={entry_pos}"),
                TraceLevel::MEDIUM,
            );
            if ctx.recursive_observation_expects(label) {
                return Err(ctx.reject_recursive_observation(label, entry_pos));
            }
            return Ok(RuntimeValue::Undef);
        }

        let capture_gaps = self
            .engine
            .spec
            .find(label)
            .and_then(|rule| rule.capture_gaps.as_ref())
            .is_some_and(|directive| directive.enabled);
        if let Err(error) = ctx.enter_recognition_invocation(label, capture_gaps, entry_slot) {
            ctx.exit_recursion(label, entry_pos);
            return Err(error);
        }
        ctx.note_recursive_observation_entry(label);

        ctx.enter_rule_variable_scope(label);
        ctx.trace_enter(
            "rust_runtime:generated_plan:direct_bcode_rule",
            format!(
                "label={label} entry_regex_idx={entry_regex_idx} family={family:?} pos={entry_pos}"
            ),
            TraceLevel::MEDIUM,
        );
        let result = self.execute_direct_bcode_rule_inner(label, entry_regex_idx, family, ctx);
        let status = match &result {
            Ok(value) => format!("status=ok value_kind={}", runtime_value_trace_kind(value)),
            Err(err) => format!("status=error error={err}"),
        };
        ctx.trace_exit(
            "rust_runtime:generated_plan:direct_bcode_rule",
            format!("{status} label={label} pos={}", ctx.pos),
            TraceLevel::MEDIUM,
        );
        ctx.exit_rule_variable_scope();
        let result = match ctx.leave_recognition_invocation(label) {
            Err(error) if result.is_ok() => Err(error),
            _ => result,
        };
        ctx.exit_recursion(label, entry_pos);
        result
    }

    fn execute_direct_bcode_rule_inner(
        &self,
        label: &str,
        entry_regex_idx: usize,
        family: GeneratedRuleFamily,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        let rule = self.engine.spec.find(label).ok_or_else(|| {
            format!(
                "rule '{}' (entry idx {}) not found in compiled spec",
                label, entry_regex_idx
            )
        })?;

        let caller_return = ctx.take_return_value();
        let saved_match = SavedMatchState {
            entry_groups: std::mem::take(&mut ctx.entry_groups),
            entry_group_spans: std::mem::take(&mut ctx.entry_group_spans),
            entry_named: std::mem::take(&mut ctx.entry_named),
            entry_match_present: ctx.entry_match_present,
            match_groups: std::mem::take(&mut ctx.match_groups),
            match_group_spans: std::mem::take(&mut ctx.match_group_spans),
            match_named: std::mem::take(&mut ctx.match_named),
            match_present: ctx.match_present,
            entry_start_byte: ctx.entry_start_byte,
            entry_end_byte: ctx.entry_end_byte,
            match_start_byte: ctx.match_start_byte,
            match_end_byte: ctx.match_end_byte,
            capture_start: ctx.capture_start,
        };
        ctx.entry_groups = saved_match.match_groups.clone();
        ctx.entry_group_spans = saved_match.match_group_spans.clone();
        ctx.entry_named = saved_match.match_named.clone();
        ctx.entry_match_present = saved_match.match_present;
        ctx.entry_start_byte = saved_match.match_start_byte;
        ctx.entry_end_byte = saved_match.match_end_byte;
        ctx.match_start_byte = 0;
        ctx.match_end_byte = 0;
        ctx.match_present = false;
        ctx.capture_start = Some(ctx.entry_end_byte);

        macro_rules! return_if_rule_returned {
            () => {
                if let Some(my_return) = ctx.take_return_value() {
                    ctx.restore_return_value(caller_return);
                    saved_match.restore(ctx);
                    return Ok(my_return);
                }
            };
        }

        if let Some(ref preamble) = rule.preamble {
            self.engine
                .execute_lifecycle_block("I", preamble, ctx, label)?;
            return_if_rule_returned!();
        }

        if !rule.acode_dispatch.is_empty() {
            ctx.restore_return_value(caller_return);
            saved_match.restore(ctx);
            return Err(format!(
                "generated direct bcode executor received acode rule '{label}'"
            ));
        }
        if rule.bcode_dispatch.is_empty() {
            ctx.restore_return_value(caller_return);
            saved_match.restore(ctx);
            return Err(format!(
                "generated direct bcode executor received rule '{label}' without bcode dispatch"
            ));
        }

        let mut implicit_bcode_result = Vec::new();
        let mut repeated_blind_matched = false;
        // Default and pipe share or_bcode in v2, but only Default repeats.
        let repeats_blind_calls = matches!(
            family,
            GeneratedRuleFamily::RepBcode | GeneratedRuleFamily::RepAndBcode
        ) || (matches!(family, GeneratedRuleFamily::OrBcode)
            && matches!(rule.mode, RuleMode::Default)
            && rule.rep_min.is_some());
        match family {
            _ if repeats_blind_calls => {
                let rep_min = rule.rep_min.unwrap_or(0);
                let rep_max = rule.rep_max;
                let mut matches = 0usize;

                for _iter in 0..LINKEDSPEC_WHILE_ITERATION_LIMIT {
                    if let Some(max) = rep_max
                        && matches >= max
                    {
                        break;
                    }

                    let pos_before = ctx.pos;

                    if let Some(ref lscode) = rule.lscode {
                        self.engine
                            .execute_lifecycle_block("LS", lscode, ctx, label)?;
                        return_if_rule_returned!();
                    }

                    let mut iteration_values = Vec::new();
                    // A post-call return completes this iteration, including undef.
                    let mut iteration_return = None;
                    let matched = if matches!(family, GeneratedRuleFamily::RepAndBcode) {
                        let mut completed_sequence = true;
                        for entry in &rule.bcode_dispatch {
                            let child_retv = self.execute_child_rule(&entry.child_label, 0, ctx)?;
                            let child_matched = child_result_is_match(ctx, &child_retv);
                            ctx.trace_decision(
                                "rust_runtime:generated_plan:bcode_dispatch",
                                child_matched,
                                format!(
                                    "rule={label} child={} family={family:?} mode=rep_and value_kind={}",
                                    entry.child_label,
                                    runtime_value_trace_kind(&child_retv)
                                ),
                                TraceLevel::MEDIUM,
                            );
                            if child_matched && rule.itcode.is_none() {
                                iteration_values.push(child_retv.clone());
                            }
                            ctx.set_retv(child_retv);
                            self.engine.execute_bcode_entry_tail(entry, ctx, label)?;
                            if let Some(value) = ctx.take_return_value() {
                                iteration_return = Some(value);
                                break;
                            }
                            if !child_matched {
                                completed_sequence = false;
                                break;
                            }
                        }
                        completed_sequence
                    } else {
                        let mut matched_choice = false;
                        for entry in &rule.bcode_dispatch {
                            let child_retv = self.execute_child_rule(&entry.child_label, 0, ctx)?;
                            let child_matched = child_result_is_match(ctx, &child_retv);
                            ctx.trace_decision(
                                "rust_runtime:generated_plan:bcode_dispatch",
                                child_matched,
                                format!(
                                    "rule={label} child={} family={family:?} mode=rep_or value_kind={}",
                                    entry.child_label,
                                    runtime_value_trace_kind(&child_retv)
                                ),
                                TraceLevel::MEDIUM,
                            );
                            if child_matched && rule.itcode.is_none() {
                                iteration_values.push(child_retv.clone());
                            }
                            ctx.set_retv(child_retv);
                            self.engine.execute_bcode_entry_tail(entry, ctx, label)?;
                            if let Some(value) = ctx.take_return_value() {
                                iteration_return = Some(value);
                                matched_choice = true;
                                break;
                            }
                            if child_matched {
                                matched_choice = true;
                                break;
                            }
                        }
                        matched_choice
                    };

                    if !matched {
                        if let Some(ref lxcode) = rule.lxcode {
                            self.engine
                                .execute_lifecycle_block("LX", lxcode, ctx, label)?;
                            return_if_rule_returned!();
                        }
                        break;
                    }

                    if iteration_return.is_none()
                        && let Some(ref lecode) = rule.lecode
                    {
                        self.engine
                            .execute_lifecycle_block("LE", lecode, ctx, label)?;
                        return_if_rule_returned!();
                    }

                    ctx.assert_recognition_repetition_progress(label, pos_before, ctx.pos)?;
                    // Returned non-consuming payloads do not count. Scoped
                    // recognition progress still rejects before this cutoff.
                    if iteration_return.is_some() && ctx.pos == pos_before {
                        break;
                    }
                    repeated_blind_matched = true;
                    if rule.itcode.is_none() {
                        if let Some(value) = iteration_return {
                            implicit_bcode_result.push(value);
                        } else if rule.mode.is_and() {
                            implicit_bcode_result.push(RuntimeValue::Array(iteration_values));
                        } else {
                            implicit_bcode_result.extend(iteration_values);
                        }
                    }
                    matches += 1;

                    if let Some(ref itcode) = rule.itcode {
                        self.engine
                            .execute_lifecycle_block("IT", itcode, ctx, label)?;
                        return_if_rule_returned!();
                    }

                    if ctx.pos == pos_before {
                        break;
                    }
                }

                if matches < rep_min {
                    ctx.note_recognition_outcome(false);
                    ctx.restore_return_value(caller_return);
                    saved_match.restore(ctx);
                    return Ok(RuntimeValue::Undef);
                }
                if matches > 0 {
                    // Blind parents have no local regex to publish their
                    // accepted child sequence/choice. Payload nullness does
                    // not determine this completed repetition's outcome.
                    ctx.note_recognition_outcome(true);
                }

                if let Some(ref excode) = rule.excode {
                    self.engine
                        .execute_lifecycle_block("EX", excode, ctx, label)?;
                    return_if_rule_returned!();
                }
            }
            GeneratedRuleFamily::AndBcode => {
                for entry in &rule.bcode_dispatch {
                    let child_retv = self.execute_child_rule(&entry.child_label, 0, ctx)?;
                    let child_matched = child_result_is_match(ctx, &child_retv);
                    ctx.trace_decision(
                        "rust_runtime:generated_plan:bcode_dispatch",
                        child_matched,
                        format!(
                            "rule={label} child={} family={family:?} mode=and value_kind={}",
                            entry.child_label,
                            runtime_value_trace_kind(&child_retv)
                        ),
                        TraceLevel::MEDIUM,
                    );
                    implicit_bcode_result.push(child_retv.clone());
                    ctx.set_retv(child_retv);
                    self.engine.execute_bcode_entry_tail(entry, ctx, label)?;
                    return_if_rule_returned!();
                }
            }
            GeneratedRuleFamily::OrBcode => {
                let mut matched = false;
                for entry in &rule.bcode_dispatch {
                    let child_retv = self.execute_child_rule(&entry.child_label, 0, ctx)?;
                    let child_matched = child_result_is_match(ctx, &child_retv);
                    ctx.trace_decision(
                        "rust_runtime:generated_plan:bcode_dispatch",
                        child_matched,
                        format!(
                            "rule={label} child={} family={family:?} mode=or value_kind={}",
                            entry.child_label,
                            runtime_value_trace_kind(&child_retv)
                        ),
                        TraceLevel::MEDIUM,
                    );
                    ctx.set_retv(child_retv);
                    self.engine.execute_bcode_entry_tail(entry, ctx, label)?;
                    return_if_rule_returned!();
                    if child_matched {
                        matched = true;
                        break;
                    }
                }
                if !matched && let Some(ref lxcode) = rule.lxcode {
                    self.engine
                        .execute_lifecycle_block("LX", lxcode, ctx, label)?;
                    return_if_rule_returned!();
                }
            }
            _ => {
                ctx.restore_return_value(caller_return);
                saved_match.restore(ctx);
                return Err(format!(
                    "generated direct bcode executor received non-bcode family {:?} for '{label}'",
                    family
                ));
            }
        }

        if let Some(ref ecode) = rule.ecode {
            self.engine
                .execute_lifecycle_block("E", ecode, ctx, label)?;
            return_if_rule_returned!();
        }

        // Historical Default retains null with no accepted iteration; explicit
        // repetition exposes an empty collection when its minimum permits it.
        let my_return = ctx.take_return_value().unwrap_or_else(|| {
            if matches!(family, GeneratedRuleFamily::AndBcode)
                || (repeats_blind_calls
                    && (repeated_blind_matched || !matches!(rule.mode, RuleMode::Default)))
            {
                RuntimeValue::Array(implicit_bcode_result)
            } else {
                RuntimeValue::Undef
            }
        });
        if ctx.is_effective_entry_rule(label) && !matches!(my_return, RuntimeValue::Undef) {
            ctx.push_accumulator(my_return.clone());
        }
        ctx.restore_return_value(caller_return);
        saved_match.restore(ctx);
        Ok(my_return)
    }
}

impl Engine {
    /// Create a new engine from a compiled spec.
    pub fn new(spec: CompiledSpec) -> Self {
        Self {
            spec,
            spec_name: None,
            spec_path: None,
        }
    }

    /// Attach a logical spec name to future structured diagnostics.
    pub fn with_spec_name(mut self, name: impl Into<String>) -> Self {
        self.spec_name = Some(name.into());
        self
    }

    /// Attach a resolved spec path to future structured diagnostics.
    pub fn with_spec_path(mut self, path: impl Into<String>) -> Self {
        self.spec_path = Some(path.into());
        self
    }

    /// Return the logical spec name used for diagnostic attribution.
    pub fn spec_name(&self) -> Option<&str> {
        self.spec_name.as_deref()
    }

    /// Return the resolved spec path used for diagnostic attribution.
    pub fn spec_path(&self) -> Option<&str> {
        self.spec_path.as_deref()
    }

    /// Execute the default effective entry rule against the given input.
    /// Returns the accumulator as a JSON array.
    pub fn execute(&self, input: &str) -> Result<Value, String> {
        self.execute_with_diagnostics(input)
            .map_err(RuntimeExecutionError::into_message)
    }

    /// Execute the default effective entry rule and return a structured failure.
    pub fn execute_with_diagnostics(&self, input: &str) -> Result<Value, RuntimeExecutionError> {
        let mut ctx = RuntimeContext::new(input);
        self.execute_with_context(&mut ctx)
            .map_err(|message| self.structured_runtime_error(&ctx, message))
    }

    /// Execute the default effective entry rule with a diagnostic-output sink.
    ///
    /// With no sink, diagnostic helpers remain quiet. The typed result keeps
    /// ordinary runtime failures, caller sink failures, and `exit_now` control
    /// distinct without routing any of them through process stderr.
    pub fn execute_with_diagnostic_output(
        &self,
        input: &str,
        sink: Option<&RuntimeDiagnosticOutputSink>,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        let mut ctx = RuntimeContext::new(input);
        ctx.install_diagnostic_output_sink(sink);
        let result = self.execute_with_context(&mut ctx);
        self.finish_diagnostic_output_execution(&mut ctx, result)
    }

    /// Execute an optionally selected entry rule and return that rule's value
    /// directly as JSON.
    ///
    /// Unlike the legacy [`execute`](Self::execute) API, this does not wrap the
    /// result in the engine accumulator. It matches LinkedSpec's public parser
    /// contract and is suitable for native embedding and primary CLI adapters.
    pub fn execute_value(&self, input: &str, options: &ExecutionOptions) -> Result<Value, String> {
        self.execute_value_with_diagnostics(input, options)
            .map_err(RuntimeExecutionError::into_message)
    }

    /// Execute a direct rule value and return a structured native runtime failure.
    pub fn execute_value_with_diagnostics(
        &self,
        input: &str,
        options: &ExecutionOptions,
    ) -> Result<Value, RuntimeExecutionError> {
        let mut ctx = RuntimeContext::new(input);
        self.execute_value_with_context(&mut ctx, options)
            .map_err(|message| self.structured_runtime_error(&ctx, message))
    }

    /// Execute a direct rule value with an optional diagnostic-output sink.
    pub fn execute_value_with_diagnostic_output(
        &self,
        input: &str,
        options: &ExecutionOptions,
        sink: Option<&RuntimeDiagnosticOutputSink>,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        let mut ctx = RuntimeContext::new(input);
        ctx.install_diagnostic_output_sink(sink);
        let result = self.execute_value_with_context(&mut ctx, options);
        self.finish_diagnostic_output_execution(&mut ctx, result)
    }

    /// Execute a direct rule value with explicit native trace configuration.
    pub fn execute_value_with_trace(
        &self,
        input: &str,
        options: &ExecutionOptions,
        trace_config: TraceConfig,
    ) -> Result<Value, String> {
        let mut trace =
            TraceEmitter::new(trace_config).map_err(|err| format!("trace setup failed: {err}"))?;
        self.execute_value_with_trace_emitter(input, options, &mut trace)
    }

    /// Execute a direct rule value with a caller-owned native trace emitter.
    pub fn execute_value_with_trace_emitter(
        &self,
        input: &str,
        options: &ExecutionOptions,
        trace: &mut TraceEmitter,
    ) -> Result<Value, String> {
        let scope = trace
            .enter_scope(
                "rust_runtime:engine:execute_value",
                format!(
                    "input_bytes={} input_chars={} entry_rule={}",
                    input.len(),
                    input.chars().count(),
                    options.entry_rule().unwrap_or("<default>")
                ),
                TraceLevel::LOW,
            )
            .map_err(trace_write_failed)?;
        let mut ctx = RuntimeContext::new(input);
        if trace.should_emit(TraceLevel::LOW) {
            ctx.enable_trace_events();
        }
        let result = self.execute_value_with_context(&mut ctx, options);
        ctx.replay_trace_events(trace).map_err(trace_write_failed)?;
        let exit_details = match &result {
            Ok(value) => format!("status=ok output={value}"),
            Err(err) => format!("status=error error={err}"),
        };
        trace
            .exit_scope(scope, exit_details)
            .map_err(trace_write_failed)?;
        result
    }

    /// Execute the default effective entry rule with explicit trace configuration.
    pub fn execute_with_trace(
        &self,
        input: &str,
        trace_config: TraceConfig,
    ) -> Result<Value, String> {
        let mut trace =
            TraceEmitter::new(trace_config).map_err(|err| format!("trace setup failed: {err}"))?;
        self.execute_with_trace_emitter(input, &mut trace)
    }

    /// Execute the default effective entry rule with a caller-owned trace emitter.
    pub fn execute_with_trace_emitter(
        &self,
        input: &str,
        trace: &mut TraceEmitter,
    ) -> Result<Value, String> {
        let scope = trace
            .enter_scope(
                "rust_runtime:engine:execute",
                format!(
                    "input_bytes={} input_chars={}",
                    input.len(),
                    input.chars().count()
                ),
                TraceLevel::LOW,
            )
            .map_err(trace_write_failed)?;
        let mut ctx = RuntimeContext::new(input);
        if trace.should_emit(TraceLevel::LOW) {
            ctx.enable_trace_events();
        }
        let result = self.execute_with_context(&mut ctx);
        ctx.replay_trace_events(trace).map_err(trace_write_failed)?;
        let exit_details = match &result {
            Ok(value) => format!("status=ok output={}", value),
            Err(err) => format!("status=error error={err}"),
        };
        trace
            .exit_scope(scope, exit_details)
            .map_err(trace_write_failed)?;
        result
    }

    /// Execute generated source through a validated rule-family plan.
    ///
    /// This path is separate from [`execute`](Self::execute): generated modules
    /// call it after `source_emitter` validates the static family table emitted
    /// beside the serialized `CompiledSpec`. `RUST-PARITY.8.4` routes both
    /// non-REP families and explicit REP subfamilies directly through the
    /// generated-plan executor.
    pub fn execute_generated_with_plan(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
    ) -> Result<Value, String> {
        self.execute_generated_with_plan_and_options(
            generated_rules,
            input,
            &ExecutionOptions::new(),
        )
    }

    /// Execute generated source with per-invocation entry selection.
    pub fn execute_generated_with_plan_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        let mut ctx = RuntimeContext::new(input);
        self.execute_generated_with_plan_context(generated_rules, &mut ctx, None, options)
    }

    /// Execute generated source and return the default effective-entry value.
    pub fn execute_generated_value_with_plan(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
    ) -> Result<Value, String> {
        self.execute_generated_value_with_plan_and_options(
            generated_rules,
            input,
            &ExecutionOptions::new(),
        )
    }

    /// Execute generated source's selected entry-rule value directly.
    pub fn execute_generated_value_with_plan_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        let mut ctx = RuntimeContext::new(input);
        self.execute_generated_value_with_plan_context(generated_rules, &mut ctx, None, options)
    }

    /// Execute generated source with an optional caller-owned diagnostic sink.
    pub fn execute_generated_with_plan_with_diagnostic_output(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        sink: Option<&RuntimeDiagnosticOutputSink>,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        self.execute_generated_with_plan_with_diagnostic_output_and_options(
            generated_rules,
            input,
            sink,
            &ExecutionOptions::new(),
        )
    }

    /// Execute the generated compatibility projection with invocation options
    /// and an optional caller-owned diagnostic sink.
    pub fn execute_generated_with_plan_with_diagnostic_output_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        sink: Option<&RuntimeDiagnosticOutputSink>,
        options: &ExecutionOptions,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        let mut ctx = RuntimeContext::new(input);
        ctx.install_diagnostic_output_sink(sink);
        let result =
            self.execute_generated_with_plan_context(generated_rules, &mut ctx, None, options);
        self.finish_diagnostic_output_execution(&mut ctx, result)
    }

    /// Execute generated source's direct value with an optional diagnostic sink.
    pub fn execute_generated_value_with_plan_with_diagnostic_output(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        sink: Option<&RuntimeDiagnosticOutputSink>,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        self.execute_generated_value_with_plan_with_diagnostic_output_and_options(
            generated_rules,
            input,
            sink,
            &ExecutionOptions::new(),
        )
    }

    /// Execute the selected generated entry-rule value with invocation options
    /// and an optional caller-owned diagnostic sink.
    pub fn execute_generated_value_with_plan_with_diagnostic_output_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        sink: Option<&RuntimeDiagnosticOutputSink>,
        options: &ExecutionOptions,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        let mut ctx = RuntimeContext::new(input);
        ctx.install_diagnostic_output_sink(sink);
        let result = self.execute_generated_value_with_plan_context(
            generated_rules,
            &mut ctx,
            None,
            options,
        );
        self.finish_diagnostic_output_execution(&mut ctx, result)
    }

    /// Execute generated source through a validated rule-family plan with
    /// explicit trace configuration.
    pub fn execute_generated_with_plan_with_trace(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
    ) -> Result<Value, String> {
        self.execute_generated_with_plan_with_trace_and_options(
            generated_rules,
            input,
            trace_config,
            &ExecutionOptions::new(),
        )
    }

    /// Execute generated source with trace and per-invocation entry selection.
    pub fn execute_generated_with_plan_with_trace_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        let mut trace =
            TraceEmitter::new(trace_config).map_err(|err| format!("trace setup failed: {err}"))?;
        self.execute_generated_with_plan_with_trace_emitter_and_options(
            generated_rules,
            input,
            &mut trace,
            options,
        )
    }

    /// Execute generated source with a caller-owned trace emitter.
    pub fn execute_generated_with_plan_with_trace_emitter(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace: &mut TraceEmitter,
    ) -> Result<Value, String> {
        self.execute_generated_with_plan_with_trace_emitter_and_options(
            generated_rules,
            input,
            trace,
            &ExecutionOptions::new(),
        )
    }

    /// Execute generated source with a caller-owned trace emitter and
    /// per-invocation entry selection.
    pub fn execute_generated_with_plan_with_trace_emitter_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace: &mut TraceEmitter,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        self.execute_generated_with_plan_with_trace_emitter_and_roles(
            generated_rules,
            input,
            trace,
            None,
            options,
        )
    }

    /// Execute generated source with portable generated-rule trace roles.
    pub fn execute_generated_with_plan_with_trace_roles(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
        source_identity: &str,
    ) -> Result<Value, String> {
        self.execute_generated_with_plan_with_trace_roles_and_options(
            generated_rules,
            input,
            trace_config,
            source_identity,
            &ExecutionOptions::new(),
        )
    }

    /// Execute a selected generated entry rule with portable trace roles.
    pub fn execute_generated_with_plan_with_trace_roles_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
        source_identity: &str,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        let mut trace =
            TraceEmitter::new(trace_config).map_err(|err| format!("trace setup failed: {err}"))?;
        self.execute_generated_with_plan_with_trace_emitter_and_roles(
            generated_rules,
            input,
            &mut trace,
            Some(source_identity),
            options,
        )
    }

    /// Execute a generated direct value with portable trace roles and a
    /// caller-owned diagnostic-output sink.
    pub fn execute_generated_value_with_plan_with_trace_roles_and_diagnostic_output(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
        source_identity: &str,
        sink: Option<&RuntimeDiagnosticOutputSink>,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        self.execute_generated_value_with_plan_with_trace_roles_and_diagnostic_output_and_options(
            generated_rules,
            input,
            trace_config,
            source_identity,
            sink,
            &ExecutionOptions::new(),
        )
    }

    /// Execute a selected generated entry-rule value with portable trace roles
    /// and a caller-owned diagnostic-output sink.
    pub fn execute_generated_value_with_plan_with_trace_roles_and_diagnostic_output_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
        source_identity: &str,
        sink: Option<&RuntimeDiagnosticOutputSink>,
        options: &ExecutionOptions,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        self.execute_generated_with_plan_with_trace_and_diagnostic_output_internal(
            generated_rules,
            input,
            trace_config,
            Some(source_identity),
            true,
            sink,
            options,
        )
    }

    /// Execute the compatibility generated accumulator with native trace and a
    /// caller-owned diagnostic-output sink.
    pub fn execute_generated_with_plan_with_trace_and_diagnostic_output(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
        sink: Option<&RuntimeDiagnosticOutputSink>,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        self.execute_generated_with_plan_with_trace_and_diagnostic_output_and_options(
            generated_rules,
            input,
            trace_config,
            sink,
            &ExecutionOptions::new(),
        )
    }

    /// Execute a selected generated compatibility projection with native trace
    /// and a caller-owned diagnostic-output sink.
    pub fn execute_generated_with_plan_with_trace_and_diagnostic_output_and_options(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
        sink: Option<&RuntimeDiagnosticOutputSink>,
        options: &ExecutionOptions,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        self.execute_generated_with_plan_with_trace_and_diagnostic_output_internal(
            generated_rules,
            input,
            trace_config,
            None,
            false,
            sink,
            options,
        )
    }

    // This internal seam carries every independently optional execution channel so
    // the public compatibility signatures can remain unchanged.
    #[allow(clippy::too_many_arguments)]
    fn execute_generated_with_plan_with_trace_and_diagnostic_output_internal(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace_config: TraceConfig,
        source_identity: Option<&str>,
        direct_value: bool,
        sink: Option<&RuntimeDiagnosticOutputSink>,
        options: &ExecutionOptions,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        let mut ctx = RuntimeContext::new(input);
        ctx.install_diagnostic_output_sink(sink);
        let mut trace = match TraceEmitter::new(trace_config) {
            Ok(trace) => trace,
            Err(error) => {
                return self.finish_diagnostic_output_execution(
                    &mut ctx,
                    Err(format!("trace setup failed: {error}")),
                );
            }
        };
        let scope = match trace.enter_scope(
            "rust_runtime:generated_plan:execute",
            format!(
                "input_bytes={} input_chars={} plan_rules={}",
                input.len(),
                input.chars().count(),
                generated_rules.len()
            ),
            TraceLevel::LOW,
        ) {
            Ok(scope) => scope,
            Err(error) => {
                return self
                    .finish_diagnostic_output_execution(&mut ctx, Err(trace_write_failed(error)));
            }
        };
        if trace.should_emit(TraceLevel::LOW) {
            ctx.enable_trace_events();
        }
        let raw_result = if direct_value {
            self.execute_generated_value_with_plan_context(
                generated_rules,
                &mut ctx,
                source_identity,
                options,
            )
        } else {
            self.execute_generated_with_plan_context(generated_rules, &mut ctx, None, options)
        };
        let exit_details = match &raw_result {
            Ok(value) => format!("status=ok output={value}"),
            Err(error) => format!("status=error error={error}"),
        };
        let execution = self.finish_diagnostic_output_execution(&mut ctx, raw_result);

        if let Err(error) = ctx.replay_trace_events(&mut trace) {
            return match execution {
                Err(RuntimeDiagnosticOutputExecutionError::Sink(_))
                | Err(RuntimeDiagnosticOutputExecutionError::Exit(_)) => execution,
                _ => self
                    .finish_diagnostic_output_execution(&mut ctx, Err(trace_write_failed(error))),
            };
        }
        if let Err(error) = trace.exit_scope(scope, exit_details) {
            return match execution {
                Err(RuntimeDiagnosticOutputExecutionError::Sink(_))
                | Err(RuntimeDiagnosticOutputExecutionError::Exit(_)) => execution,
                _ => self
                    .finish_diagnostic_output_execution(&mut ctx, Err(trace_write_failed(error))),
            };
        }
        execution
    }

    fn execute_generated_with_plan_with_trace_emitter_and_roles(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        input: &str,
        trace: &mut TraceEmitter,
        source_identity: Option<&str>,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        let scope = trace
            .enter_scope(
                "rust_runtime:generated_plan:execute",
                format!(
                    "input_bytes={} input_chars={} plan_rules={}",
                    input.len(),
                    input.chars().count(),
                    generated_rules.len()
                ),
                TraceLevel::LOW,
            )
            .map_err(trace_write_failed)?;
        let mut ctx = RuntimeContext::new(input);
        if trace.should_emit(TraceLevel::LOW) {
            ctx.enable_trace_events();
        }
        let result = if source_identity.is_some() {
            self.execute_generated_value_with_plan_context(
                generated_rules,
                &mut ctx,
                source_identity,
                options,
            )
        } else {
            self.execute_generated_with_plan_context(generated_rules, &mut ctx, None, options)
        };
        ctx.replay_trace_events(trace).map_err(trace_write_failed)?;
        let exit_details = match &result {
            Ok(value) => format!("status=ok output={}", value),
            Err(err) => format!("status=error error={err}"),
        };
        trace
            .exit_scope(scope, exit_details)
            .map_err(trace_write_failed)?;
        result
    }

    fn structured_runtime_error(
        &self,
        ctx: &RuntimeContext,
        message: String,
    ) -> RuntimeExecutionError {
        let failure = ctx.diagnostic_failure();
        let progress_record = ctx
            .recognition_progress_failure()
            .map(|error| error.as_record());
        let stage = failure
            .map(|context| context.stage)
            .unwrap_or("runtime_execution");
        let summary = failure
            .map(|context| context.summary)
            .unwrap_or("Rust runtime interpreter failed");
        let rule_label = failure
            .and_then(|context| context.rule_label.clone())
            .or_else(|| {
                progress_record
                    .as_ref()
                    .and_then(|record| record.get("rule"))
                    .and_then(Value::as_str)
                    .map(str::to_string)
            });
        let effective_rule = rule_label.as_deref().or_else(|| ctx.diagnostic_top_rule());
        let entry_rule = failure
            .filter(|context| context.code == Some(ENTRY_RULE_NOT_FOUND_CODE))
            .and_then(|_| ctx.diagnostic_top_rule())
            .map(str::to_string);
        let handler_source_label = Some(match effective_rule {
            Some(label) => format!("rust_runtime:rule:{label}"),
            None => "rust_runtime".to_string(),
        });
        RuntimeExecutionError::new(
            message.clone(),
            RuntimeDiagnostic {
                diagnostic_type: "runtime_parser".to_string(),
                stage: stage.to_string(),
                code: failure
                    .and_then(|context| context.code.map(str::to_string))
                    .or_else(|| {
                        progress_record
                            .as_ref()
                            .and_then(|record| record.get("code"))
                            .and_then(Value::as_str)
                            .map(str::to_string)
                    }),
                owner_stage: Some("rust_runtime".to_string()),
                summary: summary.to_string(),
                detail: message,
                spec_name: self.spec_name.clone(),
                spec_path: self.spec_path.clone(),
                top_rule: ctx.diagnostic_top_rule().map(str::to_string),
                entry_rule,
                rule_label,
                helper_name: failure.and_then(|context| context.helper_name.clone()),
                actual_arity: failure.and_then(|context| context.actual_arity),
                expected_arity: failure
                    .and_then(|context| context.expected_arity.map(str::to_string)),
                target_rule: failure.and_then(|context| context.target_rule.clone()),
                regex_index: failure.and_then(|context| context.regex_index),
                expected_regex_index: failure.and_then(|context| context.expected_regex_index),
                actual_regex_index: failure.and_then(|context| context.actual_regex_index),
                callable_name: failure.and_then(|context| context.callable_name.clone()),
                expected: failure.and_then(|context| context.expected.clone()),
                got: failure.and_then(|context| context.got),
                value_kind: failure.and_then(|context| context.value_kind.map(str::to_string)),
                name: failure.and_then(|context| context.name.clone()),
                cycle: failure.and_then(|context| context.cycle.clone()),
                handler_source_label,
            },
        )
    }

    fn finish_diagnostic_output_execution(
        &self,
        ctx: &mut RuntimeContext,
        result: Result<Value, String>,
    ) -> Result<Value, RuntimeDiagnosticOutputExecutionError> {
        match result {
            Ok(value) => Ok(value),
            Err(message) => {
                if let Some(failure) = ctx.take_diagnostic_output_sink_failure() {
                    return Err(RuntimeDiagnosticOutputExecutionError::Sink(failure));
                }
                if let Some(status) = ctx.exit_status {
                    return Err(RuntimeDiagnosticOutputExecutionError::Exit(
                        RuntimeExitNow { status },
                    ));
                }
                Err(RuntimeDiagnosticOutputExecutionError::Runtime(
                    self.structured_runtime_error(ctx, message),
                ))
            }
        }
    }

    fn resolve_entry_rule_label(
        &self,
        ctx: &mut RuntimeContext,
        explicit_selector: Option<&str>,
    ) -> Result<(String, EntryRuleSelectionBasis), String> {
        match self.spec.resolve_entry_rule(explicit_selector) {
            Ok(selection) => {
                let label = selection.rule.label.clone();
                ctx.set_diagnostic_top_rule(label.clone());
                Ok((label, selection.basis))
            }
            Err(diagnostic) if diagnostic.code == NO_RULES_DEFINED_CODE => {
                ctx.capture_portable_diagnostic_failure(
                    VALIDATE_SPEC_STAGE,
                    NO_RULES_DEFINED_CODE,
                    "Rust runtime spec validation failed",
                    None,
                );
                Err(diagnostic.message)
            }
            Err(diagnostic) if diagnostic.code == ENTRY_RULE_NOT_FOUND_CODE => {
                let requested = diagnostic
                    .field("entry_rule")
                    .and_then(Value::as_str)
                    .or(explicit_selector);
                if let Some(label) = requested {
                    ctx.set_diagnostic_top_rule(label);
                }
                ctx.capture_portable_diagnostic_failure(
                    SELECT_ENTRY_RULE_STAGE,
                    ENTRY_RULE_NOT_FOUND_CODE,
                    "Rust runtime entry-rule selection failed",
                    requested,
                );
                Err(diagnostic.message)
            }
            Err(diagnostic) => {
                ctx.capture_diagnostic_failure(
                    "entry_rule_selection",
                    "Rust runtime entry-rule selection failed",
                    explicit_selector,
                );
                Err(diagnostic.message)
            }
        }
    }

    fn validate_compiled_slot_identities(&self, ctx: &mut RuntimeContext) -> Result<(), String> {
        validate_compiled_regex_slot_identities(&self.spec).map_err(|error| {
            if let Some(diagnostic) = error.diagnostic() {
                let target_rule = diagnostic
                    .field("target_rule")
                    .and_then(Value::as_str)
                    .unwrap_or("");
                let regex_index = diagnostic
                    .field("regex_index")
                    .and_then(Value::as_u64)
                    .and_then(|index| usize::try_from(index).ok())
                    .unwrap_or(0);
                ctx.capture_regex_slot_identity_invalid(
                    diagnostic.field("rule_label").and_then(Value::as_str),
                    target_rule,
                    regex_index,
                );
            }
            error.to_string()
        })
    }

    fn validate_typed_write_state(&self) -> Result<(), String> {
        validate_nested_write_nodes(&self.spec)
            .map_err(|error| error.to_string())
            .and_then(|()| {
                validate_receiver_mutation_nodes(&self.spec).map_err(|error| error.to_string())
            })
    }

    fn execute_with_context(&self, ctx: &mut RuntimeContext) -> Result<Value, String> {
        self.validate_typed_write_state()?;
        self.validate_compiled_slot_identities(ctx)?;
        let (label, basis) = self.resolve_entry_rule_label(ctx, None)?;
        ctx.set_pos(public_input_start(&ctx.input));
        ctx.trace_decision(
            "rust_runtime:engine:top_rule",
            true,
            format!(
                "label={label} basis={basis} input_bytes={}",
                ctx.input.len()
            ),
            TraceLevel::LOW,
        );
        self.execute_rule(&label, 0, ctx)?;
        Ok(RuntimeValue::Array(ctx.accumulator.clone()).to_json())
    }

    fn execute_value_with_context(
        &self,
        ctx: &mut RuntimeContext,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        let staged = options
            .staged_ast_enrichment()
            .map(crate::staged_ast_enrichment::StagedAstEnrichmentSeed::start)
            .transpose()
            .map_err(|error| error.to_string())?;
        ctx.install_semantic_observation_sink(options.semantic_observation_sink());
        ctx.install_bounded_child_parse_authority(options.bounded_child_parse_authority())?;
        self.validate_typed_write_state()?;
        self.validate_compiled_slot_identities(ctx)?;
        let (label, basis) = self.resolve_entry_rule_label(ctx, options.entry_rule())?;
        ctx.set_pos(public_input_start(&ctx.input));
        ctx.trace_decision(
            "rust_runtime:engine:entry_rule",
            true,
            format!(
                "label={label} basis={basis} input_bytes={}",
                ctx.input.len()
            ),
            TraceLevel::LOW,
        );
        let value = self.execute_rule(&label, 0, ctx)?;
        if ctx.semantic_observation_enabled() {
            ctx.emit_rule_result(&label, byte_to_char_offset(&ctx.input, ctx.pos));
        }
        self.complete_staged_ast_enrichment(ctx, staged.as_ref(), value.to_json())
    }

    fn execute_generated_with_plan_context(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        ctx: &mut RuntimeContext,
        source_identity: Option<&str>,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        let staged = options
            .staged_ast_enrichment()
            .map(crate::staged_ast_enrichment::StagedAstEnrichmentSeed::start)
            .transpose()
            .map_err(|error| error.to_string())?;
        ctx.install_semantic_observation_sink(options.semantic_observation_sink());
        ctx.install_bounded_child_parse_authority(options.bounded_child_parse_authority())?;
        self.validate_compiled_slot_identities(ctx)?;
        let (label, basis) = self.resolve_entry_rule_label(ctx, options.entry_rule())?;
        ctx.set_pos(public_input_start(&ctx.input));
        ctx.trace_decision(
            "rust_runtime:generated_plan:top_rule",
            true,
            format!(
                "label={label} basis={basis} input_bytes={} plan_rules={}",
                ctx.input.len(),
                generated_rules.len()
            ),
            TraceLevel::LOW,
        );
        let generated = GeneratedPlanExecutor {
            engine: self,
            generated_rules,
            source_identity,
        };
        generated.execute_rule(&label, 0, ctx)?;
        if ctx.semantic_observation_enabled() {
            ctx.emit_rule_result(&label, byte_to_char_offset(&ctx.input, ctx.pos));
        }
        self.complete_staged_ast_enrichment(
            ctx,
            staged.as_ref(),
            RuntimeValue::Array(ctx.accumulator.clone()).to_json(),
        )
    }

    fn execute_generated_value_with_plan_context(
        &self,
        generated_rules: &[GeneratedRuleSpec],
        ctx: &mut RuntimeContext,
        source_identity: Option<&str>,
        options: &ExecutionOptions,
    ) -> Result<Value, String> {
        let staged = options
            .staged_ast_enrichment()
            .map(crate::staged_ast_enrichment::StagedAstEnrichmentSeed::start)
            .transpose()
            .map_err(|error| error.to_string())?;
        ctx.install_semantic_observation_sink(options.semantic_observation_sink());
        ctx.install_bounded_child_parse_authority(options.bounded_child_parse_authority())?;
        self.validate_compiled_slot_identities(ctx)?;
        let (label, basis) = self.resolve_entry_rule_label(ctx, options.entry_rule())?;
        ctx.set_pos(public_input_start(&ctx.input));
        ctx.trace_decision(
            "rust_runtime:generated_plan:top_rule",
            true,
            format!(
                "label={label} basis={basis} input_bytes={} plan_rules={} result_projection=direct",
                ctx.input.len(),
                generated_rules.len()
            ),
            TraceLevel::LOW,
        );
        let generated = GeneratedPlanExecutor {
            engine: self,
            generated_rules,
            source_identity,
        };
        let value = generated.execute_rule(&label, 0, ctx)?;
        if ctx.semantic_observation_enabled() {
            ctx.emit_rule_result(&label, byte_to_char_offset(&ctx.input, ctx.pos));
        }
        self.complete_staged_ast_enrichment(ctx, staged.as_ref(), value.to_json())
    }

    fn complete_staged_ast_enrichment(
        &self,
        ctx: &mut RuntimeContext,
        invocation: Option<&crate::staged_ast_enrichment::StagedAstEnrichmentInvocation>,
        ast: Value,
    ) -> Result<Value, String> {
        let Some(invocation) = invocation else {
            return Ok(ast);
        };
        invocation
            .complete(&ast, ctx.recognition_transaction_active())
            .map_err(|error| {
                let top_rule = ctx.diagnostic_top_rule().map(str::to_owned);
                ctx.capture_diagnostic_failure(
                    "staged_ast_enrichment",
                    "Rust staged-AST enrichment failed",
                    top_rule.as_deref(),
                );
                error.to_string()
            })
    }

    /// Execute a specific rule by label, entering at the given regex index
    /// (0 = first regex, N = Nth regex for `-> rule[N]` multi-entrypoint).
    ///
    /// This is the single re-entry seam for every cross-rule call, action edge,
    /// blind-call edge, and `call(rule)` helper — the Rust analogue of the Perl
    /// reference's `SpecEntry::_build_runtime_handler` closure. It wraps the rule
    /// body with the **forward-progress / consume-before-recurse termination
    /// guard** (TOP-RULE-AS-NORMAL.3.1, ADR 0010; mirror of the Perl `.2.1`
    /// `(rule,pos)` cutoff): a rule re-entered at an input position already active
    /// on its own recursion stack consumed no input since that enclosing entry —
    /// a non-progressing cycle that would otherwise overflow the native stack — so
    /// the branch is cut by returning `undef`. Legitimate consume-before-recurse
    /// recursion advances `ctx.pos` first, so the cutoff never fires for a
    /// terminating grammar.
    fn execute_rule(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        self.execute_rule_with_entry_slot(label, entry_regex_idx, ctx, None)
    }

    fn execute_rule_with_entry_slot(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
        entry_slot: Option<crate::recognition_transaction::GapEntrySlot>,
    ) -> Result<RuntimeValue, String> {
        let entry_pos = ctx.pos;
        ctx.trace_enter(
            "rust_runtime:engine:rule",
            format!("label={label} entry_regex_idx={entry_regex_idx} pos={entry_pos}"),
            TraceLevel::LOW,
        );
        if !ctx.enter_recursion(label, entry_pos) {
            // Non-progressing recursive re-entry at this exact position: cut the
            // cycle so it terminates instead of recursing forever.
            ctx.trace_decision(
                "rust_runtime:engine:recursion_guard",
                false,
                format!("label={label} entry_regex_idx={entry_regex_idx} pos={entry_pos}"),
                TraceLevel::MEDIUM,
            );
            ctx.trace_exit(
                "rust_runtime:engine:rule",
                format!("status=cut label={label} pos={}", ctx.pos),
                TraceLevel::LOW,
            );
            if ctx.recursive_observation_expects(label) {
                return Err(ctx.reject_recursive_observation(label, entry_pos));
            }
            return Ok(RuntimeValue::Undef);
        }
        let capture_gaps = self
            .spec
            .find(label)
            .and_then(|rule| rule.capture_gaps.as_ref())
            .is_some_and(|directive| directive.enabled);
        if let Err(error) = ctx.enter_recognition_invocation(label, capture_gaps, entry_slot) {
            ctx.exit_recursion(label, entry_pos);
            return Err(error);
        }
        ctx.note_recursive_observation_entry(label);
        // Run the body, then leave the frame on BOTH the Ok and Err paths so the
        // active set stays balanced (empty between top-level parses).
        ctx.enter_rule_variable_scope(label);
        let result = self.execute_rule_inner(label, entry_regex_idx, ctx);
        if result.is_err() {
            ctx.capture_diagnostic_failure(
                "runtime_execution",
                "Rust runtime interpreter failed",
                Some(label),
            );
        }
        ctx.exit_rule_variable_scope();
        let result = match ctx.leave_recognition_invocation(label) {
            Err(error) if result.is_ok() => Err(error),
            _ => result,
        };
        ctx.exit_recursion(label, entry_pos);
        let status = match &result {
            Ok(value) => format!("status=ok value_kind={}", runtime_value_trace_kind(value)),
            Err(err) => format!("status=error error={err}"),
        };
        ctx.trace_exit(
            "rust_runtime:engine:rule",
            format!("{status} label={label} pos={}", ctx.pos),
            TraceLevel::LOW,
        );
        result
    }

    fn execute_child_rule(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        self.execute_child_rule_with_entry_slot(label, entry_regex_idx, ctx, None)
    }

    fn execute_child_rule_with_entry_slot(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
        entry_slot: Option<crate::recognition_transaction::GapEntrySlot>,
    ) -> Result<RuntimeValue, String> {
        let accumulator_len = ctx.accumulator.len();
        ctx.trace_decision(
            "rust_runtime:engine:child_dispatch",
            true,
            format!(
                "label={label} entry_regex_idx={entry_regex_idx} pos={} accumulator_len={accumulator_len}",
                ctx.pos
            ),
            TraceLevel::MEDIUM,
        );
        let child_result =
            self.execute_rule_with_entry_slot(label, entry_regex_idx, ctx, entry_slot);
        ctx.accumulator.truncate(accumulator_len);
        match &child_result {
            Ok(value) => {
                ctx.trace_decision(
                    "rust_runtime:engine:child_dispatch_result",
                    value.as_bool(),
                    format!(
                        "label={label} value_kind={}",
                        runtime_value_trace_kind(value)
                    ),
                    TraceLevel::MEDIUM,
                );
            }
            Err(err) => {
                ctx.trace_decision(
                    "rust_runtime:engine:child_dispatch_result",
                    false,
                    format!("label={label} error={err}"),
                    TraceLevel::MEDIUM,
                );
            }
        }
        child_result
    }

    fn execute_action_edge_child_rule(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        if self.is_passive_terminal_rule(label) {
            ctx.trace_decision(
                "rust_runtime:engine:passive_terminal_dispatch",
                false,
                format!(
                    "label={label} entry_regex_idx={entry_regex_idx} pos={}",
                    ctx.pos
                ),
                TraceLevel::MEDIUM,
            );
            return Ok(RuntimeValue::Undef);
        }
        self.execute_child_rule(label, entry_regex_idx, ctx)
    }

    fn execute_action_edge_child_entry(
        &self,
        entry: &linkedspec_core::types::AcodeEntry,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        if self.is_passive_terminal_rule(&entry.child_label) {
            return Ok(RuntimeValue::Undef);
        }
        let entry_slot = ctx.gap_entry_slot_for_edge(entry);
        self.execute_child_rule_with_entry_slot(
            &entry.child_label,
            entry.child_regex_idx,
            ctx,
            entry_slot,
        )
    }

    /// A passive terminal handler has no executable body in the Perl reference:
    /// the parent edge regex has already consumed its match, and calling the
    /// child only exposes that entry match before returning undef.
    fn is_passive_terminal_rule(&self, label: &str) -> bool {
        let Some(rule) = self.spec.find(label) else {
            return false;
        };
        rule.preamble.is_none()
            && rule.lxcode.is_none()
            && rule.lscode.is_none()
            && rule.lecode.is_none()
            && rule.ecode.is_none()
            && rule.excode.is_none()
            && rule.itcode.is_none()
            && rule.acode_dispatch.is_empty()
            && rule.bcode_dispatch.is_empty()
    }

    fn execute_bcode_entry_tail(
        &self,
        entry: &BcodeEntry,
        ctx: &mut RuntimeContext,
        label: &str,
    ) -> Result<(), String> {
        if let Some(ref block) = entry.code {
            self.execute_block(block, ctx, label)?;
        }

        for (method, args_str) in &entry.fluent_chain {
            if method == "push" {
                // Blind fluent syntax injects the parent rule, preserving
                // push(rule[, target[, index]]) and ordinary recursion guards.
                let mut args = Self::parse_action_edge_fluent_call_args(method, args_str)?;
                args.insert(
                    0,
                    Arg::Positional(Expr::Variable {
                        name: label.to_string(),
                    }),
                );
                self.execute_block_statement_expr(
                    &Expr::Call {
                        name: method.clone(),
                        args,
                    },
                    ctx,
                    label,
                )?;
                continue;
            }
            if method == "return" {
                let args = Self::parse_action_edge_fluent_call_args(method, args_str)?;
                let value = if args.is_empty() {
                    RuntimeValue::Array(ctx.get_array(label))
                } else if Self::blind_fluent_return_uses_general_payload(args_str) {
                    self.eval_action_edge_fluent_return(args_str, ctx, label)?
                } else {
                    // Bare-name forms retain the reference's implicit scope
                    // label. Evaluate each payload once, in authored order.
                    let mut values = vec![RuntimeValue::Scalar(format!("?{label}:"))];
                    for arg in &args {
                        values.push(self.eval_expr(arg.value(), ctx, label)?);
                    }
                    RuntimeValue::Array(values)
                };
                if ctx.is_effective_entry_rule(label) {
                    ctx.push_accumulator(value.clone());
                }
                ctx.set_return_value(value);
                return Ok(());
            }
            if method == "return_undef" {
                ctx.set_return_value(RuntimeValue::Undef);
                return Ok(());
            }
            let args_val: Vec<RuntimeValue> = if args_str.is_empty() {
                vec![]
            } else {
                vec![RuntimeValue::Scalar(args_str.clone())]
            };
            let empty_raw: &[linkedspec_core::expr::Arg] = &[];
            self.call_helper(method, empty_raw, &args_val, ctx, label)?;
        }

        Ok(())
    }

    /// Keep the existing reference distinction between general payloads and
    /// scope-injected bare-name forms. This is a lexical surface contract;
    /// evaluation still belongs to the ordinary typed expression evaluator.
    fn blind_fluent_return_uses_general_payload(args: &str) -> bool {
        let payload = args.trim();
        let bytes = payload.as_bytes();
        if matches!(
            bytes.first(),
            Some(b'[' | b'{' | b'"' | b'\'' | b'0'..=b'9')
        ) || (bytes.first() == Some(&b'-') && bytes.get(1).is_some_and(u8::is_ascii_digit))
        {
            return true;
        }
        let Some((name, _)) = payload.split_once('(') else {
            return false;
        };
        // Mirrors BootstrapSpec::Core::_method_chain_return_uses_general_payload.
        const GENERAL_RETURN_HELPERS: &[&str] = &[
            "array",
            "hash",
            "trim",
            "lowercase",
            "uppercase",
            "length",
            "replace_substr",
            "rm_prefix",
            "rm_suffix",
            "cat",
            "num_abs",
            "num_floor",
            "num_ceil",
            "num_round",
            "num_sum",
            "num_avg",
            "num_median",
            "num_range",
            "num_add",
            "num_sub",
            "num_mul",
            "num_div",
            "num_mod",
            "num_clamp",
            "num_min",
            "num_max",
            "abs",
            "floor",
            "ceil",
            "round",
            "sum",
            "avg",
            "median",
            "range",
            "add",
            "sub",
            "mul",
            "div",
            "mod",
            "clamp",
            "min",
            "max",
            "starts_with",
            "ends_with",
            "contains_substr",
            "matches",
            "coalesce_nonempty",
            "is_empty",
            "is_nonempty",
            "count",
            "first",
            "last",
            "take",
            "slice",
            "take_last",
            "drop_back",
            "drop_front",
            "concat_arrays",
            "split_tagged_records",
            "sorted",
            "reversed",
            "contains",
            "index_of",
            "count_keys",
            "sorted_keys",
            "sorted_values",
            "has_key",
            "merge_hash",
            "set_key",
            "rename_key",
            "drop_keys",
            "pick_keys",
            "join_values",
            "coalesce",
            "copy",
            "flat_array",
            "flat_hash",
            "flat",
            "capture_slice",
            "capture_slice_len",
            "capture_slice_length",
            "capture_slice_until_cursor",
            "capture_slice_until_cursor_len",
            "capture_take_until_cursor",
            "capture_take_until_cursor_len",
            "capture_take_rest",
            "capture_take_rest_len",
            "capture_take",
            "capture_take_len",
            "capture_rest",
            "capture_rest_len",
            "capture_rest_length",
            "capture_slice_pos",
            "capture_slice_line",
            "capture_slice_col",
            "capture_from_rule_start",
            "capture_len_from_rule_start",
            "capture_from",
            "capture_len_from",
            "capture_until_cursor_from",
            "capture_until_cursor_len_from",
            "capture_take_until_cursor_from",
            "capture_take_until_cursor_len_from",
            "capture_take_rest_from",
            "capture_take_rest_len_from",
            "capture_take_len_from",
            "capture_rest_from",
            "capture_rest_len_from",
            "capture_between",
            "capture_len_between",
            "capture_take_between",
            "capture_take_between_len",
            "entry_text",
            "match_text",
            "entry_group",
            "match_group",
            "entry_groups",
            "match_groups",
            "input_text",
            "input_len",
            "input_slice",
        ];
        GENERAL_RETURN_HELPERS.contains(&name.trim())
    }

    fn prepare_native_selected_match(
        &self,
        rule: &CompiledRule,
        label: &str,
        matched: &MatchResult,
        required_step: Option<AndRequiredStep>,
        ctx: &mut RuntimeContext,
    ) -> Result<(), String> {
        ctx.note_recognition_match(matched.start, matched.end);
        let (target_rule, target_regex_index) = required_step
            .map(|step| step.slot_identity(rule, step.regex_index))
            .unwrap_or_else(|| structural_slot_identity(rule, matched.index));
        let (actual_target_rule, actual_regex_index) = required_step
            .map(|step| step.slot_identity(rule, matched.index))
            .unwrap_or_else(|| structural_slot_identity(rule, matched.index));
        if required_step.is_some()
            && let Err(error) = assert_ordered_regex_slot_identity(
                label,
                target_rule,
                target_regex_index,
                actual_target_rule,
                actual_regex_index,
            )
        {
            ctx.capture_ordered_regex_slot_identity_lost(
                label,
                target_rule,
                target_regex_index,
                actual_regex_index,
            );
            return Err(error.to_string());
        }
        ctx.trace_decision(
            "rust_runtime:engine:regex_slot_selected",
            true,
            format!(
                "rule_label={label} selection_role={} target_rule={target_rule} regex_index={target_regex_index}",
                if rule.mode.is_and() {
                    "ordered_required"
                } else {
                    "choice"
                }
            ),
            TraceLevel::MEDIUM,
        );

        let entry_was_empty = !ctx.entry_match_present;
        ctx.set_pos(matched.end);
        if ctx.semantic_observation_enabled() {
            ctx.emit_regex_slot_selected(
                label,
                target_rule,
                target_regex_index,
                byte_to_char_offset(&ctx.input, matched.end),
            );
        }
        ctx.match_groups = matched.captures.clone();
        ctx.match_group_spans = matched.capture_spans.clone();
        ctx.match_named = matched.named.clone();
        ctx.match_start_byte = matched.start;
        ctx.match_end_byte = matched.end;
        ctx.match_present = true;
        if entry_was_empty {
            ctx.entry_groups = matched.captures.clone();
            ctx.entry_group_spans = matched.capture_spans.clone();
            ctx.entry_named = matched.named.clone();
            ctx.entry_start_byte = matched.start;
            ctx.entry_end_byte = matched.end;
            ctx.entry_match_present = true;
        }
        Ok(())
    }

    fn select_native_match(
        rule: &CompiledRule,
        alt: &CompiledAlternation,
        input: &str,
        position: usize,
        parse_mode: ParseMode,
        required_and_idx: Option<usize>,
        has_entry_idx: bool,
        matches: usize,
        entry_regex_idx: usize,
    ) -> Result<Option<MatchResult>, String> {
        // The caller already consumed the incoming entry match. An AND body
        // now owns its required sequence; the inherited selector cannot replace
        // the next structural/dependency step. Choice entry priority stays below.
        if let Some(required_index) = required_and_idx {
            return Ok(match parse_mode {
                ParseMode::Consume => alt.consume_slot_match(input, position, required_index),
                ParseMode::Seek => alt.seek_slot_match(input, position, required_index),
            });
        }
        if has_entry_idx && matches == 0 {
            let entry_pat = &rule.regex_patterns[entry_regex_idx];
            let entry_alt = CompiledAlternation::compile(std::slice::from_ref(entry_pat))?;
            return Ok(match parse_mode {
                ParseMode::Consume => entry_alt.consume_match(input, position),
                ParseMode::Seek => entry_alt.seek_match(input, position),
            }
            .map(|mut matched| {
                matched.index = entry_regex_idx;
                matched
            }));
        }
        if !rule.mode.is_and() && !rule.acode_dispatch.is_empty() {
            // The full catalog also serves incoming selectors and boundary
            // lookahead. Only outgoing edges participate in body choice, in
            // authored edge order rather than numeric catalog order.
            let mut selected: Option<MatchResult> = None;
            for edge in &rule.acode_dispatch {
                let candidate = match parse_mode {
                    ParseMode::Consume => alt.consume_slot_match(input, position, edge.regex_idx),
                    ParseMode::Seek => alt.seek_slot_match(input, position, edge.regex_idx),
                };
                if let Some(candidate) = candidate {
                    // No later edge can start earlier than the current cursor;
                    // an equal start must retain this first-authored edge.
                    if candidate.start == position {
                        return Ok(Some(candidate));
                    }
                    if selected
                        .as_ref()
                        .is_none_or(|best| candidate.start < best.start)
                    {
                        selected = Some(candidate);
                    }
                }
            }
            return Ok(selected);
        }
        Ok(match parse_mode {
            ParseMode::Consume => alt.consume_match(input, position),
            ParseMode::Seek => alt.seek_match(input, position),
        })
    }

    /// The rule body, wrapped by [`execute_rule`] (which adds the recursion
    /// termination guard). All recursive dispatch goes through `execute_rule`,
    /// never directly through this method.
    fn execute_rule_inner(
        &self,
        label: &str,
        entry_regex_idx: usize,
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        let Some(rule) = self.spec.find(label) else {
            ctx.capture_diagnostic_failure(
                "rule_lookup",
                "Rust runtime rule lookup failed",
                Some(label),
            );
            return Err(format!(
                "rule '{}' (entry idx {}) not found in compiled spec",
                label, entry_regex_idx
            ));
        };

        // Each rule invocation reports its own return value (the value of the
        // last `return(...)` in its blocks — Runtime Semantics §5.4). Save the
        // caller's pending return, then start this invocation with a clean
        // channel so a dispatched child cannot leak its return into ours.
        let caller_return = ctx.take_return_value();

        // ── Emulate the Perl per-handler IMATCH/LMATCH lexicals ──
        // The dispatcher passes its own local match as the child's `$info`
        // (`MethodLowering.pm:332` calls the child handler with `$minfo`), and
        // the child's preamble sets `IMATCH = $$info{match}`
        // (`SpecEntry::_build_handler_preamble`). The rule's own regex match
        // sets `LMATCH` (`HandlerVariantEmitter::_build_lmatch_extraction`). So
        // this invocation's ENTRY match is the dispatcher's current LOCAL match,
        // and the rule's own matches only update the LOCAL match. Save the
        // caller's lexicals and restore them on exit so a child's matching never
        // mutates the parent's entry/local match.
        let saved_match = SavedMatchState {
            entry_groups: std::mem::take(&mut ctx.entry_groups),
            entry_group_spans: std::mem::take(&mut ctx.entry_group_spans),
            entry_named: std::mem::take(&mut ctx.entry_named),
            entry_match_present: ctx.entry_match_present,
            match_groups: std::mem::take(&mut ctx.match_groups),
            match_group_spans: std::mem::take(&mut ctx.match_group_spans),
            match_named: std::mem::take(&mut ctx.match_named),
            match_present: ctx.match_present,
            entry_start_byte: ctx.entry_start_byte,
            entry_end_byte: ctx.entry_end_byte,
            match_start_byte: ctx.match_start_byte,
            match_end_byte: ctx.match_end_byte,
            capture_start: ctx.capture_start,
        };
        // ENTRY match (`IMATCH`) = the dispatcher's local match (`$$info{match}`).
        // For the top rule the caller has no local match, so this starts empty
        // and is seeded from the rule's own first match below (mirroring the
        // framework passing the top rule's own match as `$info`).
        ctx.entry_groups = saved_match.match_groups.clone();
        ctx.entry_group_spans = saved_match.match_group_spans.clone();
        ctx.entry_named = saved_match.match_named.clone();
        ctx.entry_match_present = saved_match.match_present;
        ctx.entry_start_byte = saved_match.match_start_byte;
        ctx.entry_end_byte = saved_match.match_end_byte;
        // LOCAL match (`LMATCH`) starts empty until this rule matches its regex.
        ctx.match_start_byte = 0;
        ctx.match_end_byte = 0;
        ctx.match_present = false;
        ctx.capture_start = Some(ctx.entry_end_byte);

        macro_rules! return_if_rule_returned {
            () => {
                if let Some(my_return) = ctx.take_return_value() {
                    ctx.restore_return_value(caller_return);
                    saved_match.restore(ctx);
                    return Ok(my_return);
                }
            };
        }

        // Build regex alternation (or fallback for edge-only rules)
        let alt = if rule.regex_patterns.is_empty() {
            CompiledAlternation::compile(&[])?
        } else {
            CompiledAlternation::compile(&rule.regex_patterns)?
        };

        // ── I-block (preamble, once per rule entry) ──
        if let Some(ref preamble) = rule.preamble {
            self.execute_lifecycle_block("I", preamble, ctx, label)?;
            return_if_rule_returned!();
        }

        let is_rep = rule.rep_min.is_some();
        let rep_min = rule.rep_min.unwrap_or(0);
        let rep_max = rule.rep_max;

        // ── Blind-call dispatch ──
        if !rule.bcode_dispatch.is_empty() {
            let mut implicit_bcode_result = Vec::new();
            let mut repeated_blind_matched = false;
            if is_rep {
                let mut matches = 0usize;
                for _iter in 0..LINKEDSPEC_WHILE_ITERATION_LIMIT {
                    if let Some(max) = rep_max
                        && matches >= max
                    {
                        break;
                    }

                    let pos_before = ctx.pos;

                    if let Some(ref lscode) = rule.lscode {
                        self.execute_lifecycle_block("LS", lscode, ctx, label)?;
                        return_if_rule_returned!();
                    }

                    let mut iteration_values = Vec::new();
                    // A post-call return completes this iteration, including undef.
                    let mut iteration_return = None;
                    let matched = if rule.mode.is_and() {
                        let mut completed_sequence = true;
                        for entry in &rule.bcode_dispatch {
                            let child_retv = self.execute_child_rule(&entry.child_label, 0, ctx)?;
                            let child_matched = child_result_is_match(ctx, &child_retv);
                            ctx.trace_decision(
                                "rust_runtime:engine:bcode_dispatch",
                                child_matched,
                                format!(
                                    "rule={label} child={} mode=rep_and value_kind={}",
                                    entry.child_label,
                                    runtime_value_trace_kind(&child_retv)
                                ),
                                TraceLevel::MEDIUM,
                            );
                            if child_matched && rule.itcode.is_none() {
                                iteration_values.push(child_retv.clone());
                            }
                            ctx.set_retv(child_retv);
                            self.execute_bcode_entry_tail(entry, ctx, label)?;
                            if let Some(value) = ctx.take_return_value() {
                                iteration_return = Some(value);
                                break;
                            }
                            if !child_matched {
                                completed_sequence = false;
                                break;
                            }
                        }
                        completed_sequence
                    } else {
                        let mut matched_choice = false;
                        for entry in &rule.bcode_dispatch {
                            let child_retv = self.execute_child_rule(&entry.child_label, 0, ctx)?;
                            let child_matched = child_result_is_match(ctx, &child_retv);
                            ctx.trace_decision(
                                "rust_runtime:engine:bcode_dispatch",
                                child_matched,
                                format!(
                                    "rule={label} child={} mode=rep_or value_kind={}",
                                    entry.child_label,
                                    runtime_value_trace_kind(&child_retv)
                                ),
                                TraceLevel::MEDIUM,
                            );
                            if child_matched && rule.itcode.is_none() {
                                iteration_values.push(child_retv.clone());
                            }
                            ctx.set_retv(child_retv);
                            self.execute_bcode_entry_tail(entry, ctx, label)?;
                            if let Some(value) = ctx.take_return_value() {
                                iteration_return = Some(value);
                                matched_choice = true;
                                break;
                            }
                            if child_matched {
                                matched_choice = true;
                                break;
                            }
                        }
                        matched_choice
                    };

                    if !matched {
                        if let Some(ref lxcode) = rule.lxcode {
                            self.execute_lifecycle_block("LX", lxcode, ctx, label)?;
                            return_if_rule_returned!();
                        }
                        break;
                    }

                    if iteration_return.is_none()
                        && let Some(ref lecode) = rule.lecode
                    {
                        self.execute_lifecycle_block("LE", lecode, ctx, label)?;
                        return_if_rule_returned!();
                    }

                    ctx.assert_recognition_repetition_progress(label, pos_before, ctx.pos)?;
                    // Returned non-consuming payloads do not count. Scoped
                    // recognition progress still rejects before this cutoff.
                    if iteration_return.is_some() && ctx.pos == pos_before {
                        break;
                    }
                    repeated_blind_matched = true;
                    if rule.itcode.is_none() {
                        if let Some(value) = iteration_return {
                            implicit_bcode_result.push(value);
                        } else if rule.mode.is_and() {
                            implicit_bcode_result.push(RuntimeValue::Array(iteration_values));
                        } else {
                            implicit_bcode_result.extend(iteration_values);
                        }
                    }
                    matches += 1;

                    if let Some(ref itcode) = rule.itcode {
                        self.execute_lifecycle_block("IT", itcode, ctx, label)?;
                        return_if_rule_returned!();
                    }

                    if ctx.pos == pos_before {
                        break;
                    }
                }

                if matches < rep_min {
                    ctx.note_recognition_outcome(false);
                    ctx.restore_return_value(caller_return);
                    saved_match.restore(ctx);
                    return Ok(RuntimeValue::Undef);
                }
                if matches > 0 {
                    // Blind parents have no local regex to publish their
                    // accepted child sequence/choice. Payload nullness does
                    // not determine this completed repetition's outcome.
                    ctx.note_recognition_outcome(true);
                }

                if let Some(ref excode) = rule.excode {
                    self.execute_lifecycle_block("EX", excode, ctx, label)?;
                    return_if_rule_returned!();
                }
            } else if rule.mode.is_and() {
                for entry in &rule.bcode_dispatch {
                    // Execute child rule; its return value becomes the parent's
                    // `retv` (Runtime Semantics §6.2), readable by the attached
                    // code, fluent chain, and the E-block below.
                    let child_retv = self.execute_child_rule(&entry.child_label, 0, ctx)?;
                    let child_matched = child_result_is_match(ctx, &child_retv);
                    ctx.trace_decision(
                        "rust_runtime:engine:bcode_dispatch",
                        child_matched,
                        format!(
                            "rule={label} child={} mode=and value_kind={}",
                            entry.child_label,
                            runtime_value_trace_kind(&child_retv)
                        ),
                        TraceLevel::MEDIUM,
                    );
                    implicit_bcode_result.push(child_retv.clone());
                    ctx.set_retv(child_retv);
                    self.execute_bcode_entry_tail(entry, ctx, label)?;
                    return_if_rule_returned!();
                }
            } else {
                let mut matched = false;
                for entry in &rule.bcode_dispatch {
                    let child_retv = self.execute_child_rule(&entry.child_label, 0, ctx)?;
                    let child_matched = child_result_is_match(ctx, &child_retv);
                    ctx.trace_decision(
                        "rust_runtime:engine:bcode_dispatch",
                        child_matched,
                        format!(
                            "rule={label} child={} mode=or value_kind={}",
                            entry.child_label,
                            runtime_value_trace_kind(&child_retv)
                        ),
                        TraceLevel::MEDIUM,
                    );
                    ctx.set_retv(child_retv);
                    self.execute_bcode_entry_tail(entry, ctx, label)?;
                    return_if_rule_returned!();
                    if child_matched {
                        matched = true;
                        break;
                    }
                }
                if !matched && let Some(ref lxcode) = rule.lxcode {
                    self.execute_lifecycle_block("LX", lxcode, ctx, label)?;
                    return_if_rule_returned!();
                }
            }
            // After blind-call dispatch, fire E-block and exit
            if let Some(ref ecode) = rule.ecode {
                self.execute_lifecycle_block("E", ecode, ctx, label)?;
                return_if_rule_returned!();
            }
            // Historical Default retains null with no accepted iteration;
            // explicit zero-min repetition exposes an empty collection.
            let my_return = ctx.take_return_value().unwrap_or_else(|| {
                if rule.mode.is_and()
                    || (is_rep
                        && (repeated_blind_matched || !matches!(rule.mode, RuleMode::Default)))
                {
                    RuntimeValue::Array(implicit_bcode_result)
                } else {
                    RuntimeValue::Undef
                }
            });
            if ctx.is_effective_entry_rule(label) && !matches!(my_return, RuntimeValue::Undef) {
                ctx.push_accumulator(my_return.clone());
            }
            ctx.restore_return_value(caller_return);
            saved_match.restore(ctx);
            return Ok(my_return);
        }

        // ── Regex-based matching loop ──
        let collects_action_values = collects_explicit_action_iteration_values(rule);
        // AND returns unwind the current group, unlike per-hit CHOICE values.
        // Keep its value separate from slot position and accepted-group count.
        let collects_and_groups = is_rep && rule.mode.is_and() && !rule.acode_dispatch.is_empty();
        let mut and_group_return = None;
        let mut action_iteration_values = Vec::new();

        macro_rules! collect_or_return_action_value {
            ($group_dispatch:lifetime) => {
                if let Some(value) = ctx.take_return_value() {
                    if collects_and_groups {
                        and_group_return = Some(value);
                        break $group_dispatch;
                    } else if collects_action_values {
                        action_iteration_values.push(value);
                    } else {
                        ctx.restore_return_value(caller_return);
                        saved_match.restore(ctx);
                        return Ok(value);
                    }
                }
            };
        }
        let and_steps = and_required_steps(rule);
        let is_and_acode_seq = and_steps.len() > 1
            || and_steps
                .first()
                .is_some_and(|step| step.action_index.is_some());
        let is_rep_and_acode_seq = is_rep && is_and_acode_seq;
        let and_acode_seq_len = and_steps.len();
        let mut matches: usize = 0;
        let mut and_acode_idx: usize = 0;
        let mut rep_and_start_pos = ctx.pos;
        let max_iter = 10_000;
        let capture_gaps = rule
            .capture_gaps
            .as_ref()
            .is_some_and(|value| value.enabled);

        // For non-REP entry-specific dispatch: if entry_regex_idx > 0,
        // try only that specific regex first (for self-recursive rules).
        let has_entry_idx = entry_regex_idx > 0 && entry_regex_idx < rule.regex_patterns.len();

        for _iter in 0..max_iter {
            if is_rep_and_acode_seq && and_acode_idx == 0 {
                rep_and_start_pos = ctx.pos;
            }
            // Non-REP rules execute once
            if !is_rep && !is_and_acode_seq && matches > 0 && !capture_gaps {
                break;
            }
            if !is_rep && is_and_acode_seq && matches >= and_acode_seq_len {
                break;
            }
            if is_rep_and_acode_seq
                && let Some(max) = rep_max
                && matches >= max
            {
                break;
            }

            // Cursor position at the start of this iteration — the zero-progress
            // guard below compares it against the position after the iteration
            // (Perl: `loop_start_pos`).
            let pos_before = ctx.pos;

            // ── Match ──
            let parse_mode = rule.cursor_policy();
            let required_step = is_and_acode_seq.then(|| {
                and_steps[if is_rep_and_acode_seq {
                    and_acode_idx
                } else {
                    matches
                }]
            });
            let required_and_idx = required_step.map(|step| step.regex_index);
            let match_result;

            if capture_gaps {
                match_result = Self::select_native_match(
                    rule,
                    &alt,
                    &ctx.input,
                    ctx.pos,
                    parse_mode,
                    required_and_idx,
                    has_entry_idx,
                    matches,
                    entry_regex_idx,
                )?;
                match &match_result {
                    Some(m) => {
                        ctx.trace_decision(
                            "rust_runtime:engine:regex_match",
                            true,
                            format!(
                                "rule={label} regex_idx={} start={} end={} pos_before={pos_before} parse_mode={:?} entry_regex_idx={entry_regex_idx}",
                                m.index, m.start, m.end, parse_mode
                            ),
                            TraceLevel::MEDIUM,
                        );
                        self.prepare_native_selected_match(rule, label, m, required_step, ctx)?;
                        ctx.install_gap_candidate(m.start);
                    }
                    None => {
                        ctx.trace_decision(
                            "rust_runtime:engine:regex_match",
                            false,
                            format!(
                                "rule={label} pos_before={pos_before} parse_mode={:?} entry_regex_idx={entry_regex_idx}",
                                parse_mode
                            ),
                            TraceLevel::MEDIUM,
                        );
                    }
                }
                if match_result.is_some() {
                    ctx.set_gap_phase("LS");
                    if let Some(ref lscode) = rule.lscode {
                        self.execute_lifecycle_block("LS", lscode, ctx, label)?;
                        return_if_rule_returned!();
                    }
                }
            } else {
                // Preserve the historical unflagged order exactly: LS runs
                // before matcher selection and local-match installation.
                if let Some(ref lscode) = rule.lscode {
                    self.execute_lifecycle_block("LS", lscode, ctx, label)?;
                    return_if_rule_returned!();
                }
                match_result = Self::select_native_match(
                    rule,
                    &alt,
                    &ctx.input,
                    ctx.pos,
                    parse_mode,
                    required_and_idx,
                    has_entry_idx,
                    matches,
                    entry_regex_idx,
                )?;
                match &match_result {
                    Some(m) => {
                        ctx.trace_decision(
                            "rust_runtime:engine:regex_match",
                            true,
                            format!(
                                "rule={label} regex_idx={} start={} end={} pos_before={pos_before} parse_mode={:?} entry_regex_idx={entry_regex_idx}",
                                m.index, m.start, m.end, parse_mode
                            ),
                            TraceLevel::MEDIUM,
                        );
                        self.prepare_native_selected_match(rule, label, m, required_step, ctx)?;
                    }
                    None => {
                        ctx.trace_decision(
                            "rust_runtime:engine:regex_match",
                            false,
                            format!(
                                "rule={label} pos_before={pos_before} parse_mode={:?} entry_regex_idx={entry_regex_idx}",
                                parse_mode
                            ),
                            TraceLevel::MEDIUM,
                        );
                    }
                }
            }

            if let Some(m) = match_result {
                // ── Action-edge dispatch ──
                ctx.set_gap_phase("edge");
                let mut dispatched_acode = false;
                'and_group_dispatch: for (action_index, entry) in
                    rule.acode_dispatch.iter().enumerate()
                {
                    if entry.regex_idx == m.index
                        && required_step.is_none_or(|step| step.dispatches(action_index))
                    {
                        dispatched_acode = true;
                        ctx.trace_decision(
                            "rust_runtime:engine:acode_dispatch",
                            true,
                            format!(
                                "rule={label} regex_idx={} child={} child_regex_idx={} fluent_chain_len={} has_code={}",
                                entry.regex_idx,
                                entry.child_label,
                                entry.child_regex_idx,
                                entry.fluent_chain.len(),
                                entry.code.is_some()
                            ),
                            TraceLevel::MEDIUM,
                        );
                        if entry.fluent_chain.is_empty() {
                            if let Some(ref block) = entry.code {
                                let observes_child =
                                    Self::block_observes_rule(block, &entry.child_label);
                                let calls_child = Self::block_calls_rule(block, &entry.child_label);
                                let reads_retv = Self::block_reads_retv(block);
                                if observes_child
                                    || (entry.child_label == label && !calls_child && !reads_retv)
                                {
                                    self.execute_block(block, ctx, label)?;
                                    collect_or_return_action_value!('and_group_dispatch);
                                } else if calls_child || reads_retv {
                                    // Perl lowers `call(child)` inside the edge
                                    // block to the already matched edge child.
                                    // A bare `retv` read has the same dependency:
                                    // pre-dispatch once, then let helper
                                    // evaluation read the scoped child result.
                                    let child_retv =
                                        self.execute_action_edge_child_entry(entry, ctx)?;
                                    ctx.push_action_edge_call_result(
                                        &entry.child_label,
                                        child_retv.clone(),
                                    );
                                    ctx.set_retv(child_retv.clone());
                                    let block_result = self.execute_block(block, ctx, label);
                                    ctx.pop_action_edge_call_result();
                                    block_result?;
                                    collect_or_return_action_value!('and_group_dispatch);
                                    ctx.set_retv(child_retv);
                                } else {
                                    // Blocks that do not call the child run before
                                    // the generated Perl handler dispatches that
                                    // child. The child return then seeds `retv`
                                    // for later edges / lifecycle blocks.
                                    self.execute_block(block, ctx, label)?;
                                    collect_or_return_action_value!('and_group_dispatch);
                                    let child_retv =
                                        self.execute_action_edge_child_entry(entry, ctx)?;
                                    ctx.set_retv(child_retv);
                                }
                            } else {
                                let child_retv =
                                    self.execute_action_edge_child_entry(entry, ctx)?;
                                ctx.set_retv(child_retv);
                            }
                        } else if self.execute_action_edge_fluent_chain(entry, ctx, label)?
                            == ActionEdgeFlow::Returned
                        {
                            collect_or_return_action_value!('and_group_dispatch);
                        }
                    }
                }
                if !dispatched_acode {
                    ctx.trace_decision(
                        "rust_runtime:engine:acode_dispatch",
                        false,
                        format!("rule={label} regex_idx={} child=none", m.index),
                        TraceLevel::MEDIUM,
                    );
                }

                // ── LE-block (loop end, after successful match) ──
                if and_group_return.is_none() {
                    ctx.set_gap_phase("LE");
                    if let Some(ref lecode) = rule.lecode {
                        self.execute_lifecycle_block("LE", lecode, ctx, label)?;
                        return_if_rule_returned!();
                    }
                }
                // Only a completed group/hit is a repetition iteration. In
                // AND, an intermediate zero-width slot can precede consuming
                // slots, and the last slot can itself be zero-width.
                if is_rep
                    && (!is_rep_and_acode_seq
                        || and_group_return.is_some()
                        || and_acode_idx + 1 == and_acode_seq_len)
                {
                    let iteration_start = if is_rep_and_acode_seq {
                        rep_and_start_pos
                    } else {
                        pos_before
                    };
                    ctx.assert_recognition_repetition_progress(label, iteration_start, ctx.pos)?;
                }
                // An accepted early group return skips its remaining slots,
                // then finalizes this candidate before the outer IT hook.
                ctx.commit_gap_candidate(label)?;

                if is_rep_and_acode_seq {
                    if and_group_return.is_none() {
                        and_acode_idx += 1;
                        if and_acode_idx < and_acode_seq_len {
                            continue;
                        }
                    }
                    and_acode_idx = 0;
                }
                matches += 1;
                if collects_and_groups {
                    let group_value = and_group_return
                        .take()
                        .unwrap_or_else(|| RuntimeValue::Array(Vec::new()));
                    // Authored IT replaces the reference's default push.
                    if rule.itcode.is_none() {
                        action_iteration_values.push(group_value);
                    }
                }

                // ── IT-block (per-iteration, REP only) ──
                ctx.set_gap_phase("IT");
                if let Some(ref itcode) = rule.itcode {
                    self.execute_lifecycle_block("IT", itcode, ctx, label)?;
                    return_if_rule_returned!();
                }
            } else {
                // No match — exit the matching loop
                // ── LX-block (no-match exit, fires when loop ends without match) ──
                if !is_rep || matches >= rep_min {
                    ctx.install_gap_tail("LX");
                }
                ctx.set_gap_phase("LX");
                if let Some(ref lxcode) = rule.lxcode {
                    self.execute_lifecycle_block("LX", lxcode, ctx, label)?;
                    return_if_rule_returned!();
                }
                break;
            }

            // Check max bound (REP rules)
            if let Some(max) = rep_max
                && matches >= max
            {
                break;
            }

            // Zero-progress guard: a REP iteration that left the cursor
            // unchanged (e.g. a zero-width match with no consuming child
            // dispatch) would loop forever. Break when the iteration made no
            // progress (Perl: `loop_end_pos == loop_start_pos`); the min-bound
            // check below then fails the rule if we are still under `rep_min`.
            let progress_start = if is_rep_and_acode_seq {
                rep_and_start_pos
            } else {
                pos_before
            };
            if is_rep && ctx.pos == progress_start {
                break;
            }
        }

        // Check min bound for REP variants (not for non-REP with no matches)
        if is_rep && matches < rep_min {
            // A partial hit is not an accepted invocation when its minimum
            // fails. Keep the consumed cursor, but restore caller lexicals.
            ctx.note_recognition_outcome(false);
            ctx.restore_return_value(caller_return);
            saved_match.restore(ctx);
            return Ok(RuntimeValue::Undef);
        }

        if !is_rep && is_and_acode_seq && matches < and_acode_seq_len {
            ctx.restore_return_value(caller_return);
            saved_match.restore(ctx);
            return Ok(RuntimeValue::Undef);
        }

        // ── EX-block (REP exhaustion, fires after loop completes normally) ──
        if is_rep {
            ctx.install_gap_tail("EX");
        }
        ctx.set_gap_phase("EX");
        if let Some(ref excode) = rule.excode {
            self.execute_lifecycle_block("EX", excode, ctx, label)?;
            return_if_rule_returned!();
        }

        // ── E-block (exit, fires once after all matching/repetition is done) ──
        if !is_rep {
            ctx.install_gap_tail("E");
        }
        ctx.set_gap_phase("E");
        if let Some(ref ecode) = rule.ecode {
            self.execute_lifecycle_block("E", ecode, ctx, label)?;
            return_if_rule_returned!();
        }

        // This invocation's return value is whatever its blocks last returned;
        // restore the caller's pending return and match lexicals so nested
        // dispatch is transparent to the parent.
        let my_return = ctx.take_return_value().unwrap_or_else(|| {
            if collects_action_values || collects_and_groups {
                RuntimeValue::Array(action_iteration_values)
            } else {
                RuntimeValue::Undef
            }
        });
        ctx.restore_return_value(caller_return);
        saved_match.restore(ctx);
        Ok(my_return)
    }

    fn block_calls_rule(block: &CodeBlock, rule_label: &str) -> bool {
        block
            .statements
            .iter()
            .any(|stmt| Self::expr_calls_rule(&stmt.expr, rule_label))
    }

    fn block_observes_rule(block: &CodeBlock, rule_label: &str) -> bool {
        block.statements.iter().any(|statement| {
            matches!(
                &statement.expr,
                Expr::AssignScalar { value, .. }
                    if matches!(
                        value.as_ref(),
                        Expr::ObserveRecognition { rule, .. } if rule == rule_label
                    )
            )
        })
    }

    fn expr_calls_rule(expr: &Expr, rule_label: &str) -> bool {
        match expr {
            Expr::Call { name, args } => {
                (name == "call" && Self::call_names_rule(args, rule_label))
                    || args.iter().any(|arg| Self::arg_calls_rule(arg, rule_label))
            }
            Expr::RecognizeOnce { rule, .. } | Expr::ObserveRecognition { rule, .. } => {
                rule == rule_label
            }
            Expr::RecognitionCheckpoint
            | Expr::ProgressiveDispatchSpan { .. }
            | Expr::StagedParseJobMarker { .. }
            | Expr::RecognitionCommit { .. }
            | Expr::RecognitionRollback { .. } => false,
            Expr::AssignScalar { value, .. } => Self::expr_calls_rule(value, rule_label),
            Expr::AssignArrayAppend { value, .. } => Self::expr_calls_rule(value, rule_label),
            Expr::AssignHashIndex { key, value, .. } => {
                Self::expr_calls_rule(key, rule_label) || Self::expr_calls_rule(value, rule_label)
            }
            Expr::AssignNestedAccess {
                segments, value, ..
            } => {
                segments
                    .iter()
                    .any(|segment| Self::expr_calls_rule(&segment.expression, rule_label))
                    || Self::expr_calls_rule(value, rule_label)
            }
            Expr::ReceiverMutationChain {
                mutation,
                continuation,
                ..
            } => {
                mutation
                    .callback
                    .body
                    .statements
                    .iter()
                    .any(|statement| Self::expr_calls_rule(&statement.expr, rule_label))
                    || continuation.iter().any(|call| {
                        call.args
                            .iter()
                            .any(|argument| Self::arg_calls_rule(argument, rule_label))
                    })
            }
            Expr::IndexedVar { index, .. } => Self::expr_calls_rule(index, rule_label),
            Expr::NestedAccess { segments, .. } => segments.iter().any(|segment| match segment {
                AccessSegment::Key { .. } => false,
                AccessSegment::Index { expr } => Self::expr_calls_rule(expr, rule_label),
            }),
            Expr::ValueAccess { receiver, segments } => {
                Self::expr_calls_rule(receiver, rule_label)
                    || segments.iter().any(|segment| match segment {
                        AccessSegment::Key { .. } => false,
                        AccessSegment::Index { expr } => Self::expr_calls_rule(expr, rule_label),
                    })
            }
            Expr::ArrayLiteral { items } => items
                .iter()
                .any(|item| Self::expr_calls_rule(item, rule_label)),
            Expr::HashLiteral { entries } => entries.iter().any(|entry| {
                Self::expr_calls_rule(&entry.key, rule_label)
                    || Self::expr_calls_rule(&entry.value, rule_label)
            }),
            Expr::BlockValue { block } => Self::block_calls_rule(block, rule_label),
            // Construction is inert. A call inside the retained body is not an
            // eager dependency of the expression that creates the codeblock.
            Expr::ContextualCodeblockCandidate(_) | Expr::CodeblockLiteral(_) => false,
            Expr::CodeblockArgument(argument) => argument
                .body_ast
                .statements
                .iter()
                .any(|statement| Self::expr_calls_rule(&statement.expr, rule_label)),
            Expr::FluentChain { receiver, calls } => {
                Self::expr_calls_rule(receiver, rule_label)
                    || calls.iter().any(|call| {
                        call.args
                            .iter()
                            .any(|arg| Self::arg_calls_rule(arg, rule_label))
                    })
            }
            Expr::Variable { .. }
            | Expr::StringLiteral { .. }
            | Expr::NumberLiteral { .. }
            | Expr::BooleanLiteral { .. }
            | Expr::RegexLiteral { .. }
            | Expr::Undef => false,
        }
    }

    fn block_reads_retv(block: &CodeBlock) -> bool {
        block
            .statements
            .iter()
            .any(|stmt| Self::expr_reads_retv(&stmt.expr))
    }

    fn expr_reads_retv(expr: &Expr) -> bool {
        match expr {
            Expr::Call { args, .. } => args.iter().any(Self::arg_reads_retv),
            Expr::RecognitionCheckpoint
            | Expr::ProgressiveDispatchSpan { .. }
            | Expr::StagedParseJobMarker { .. }
            | Expr::RecognizeOnce { .. }
            | Expr::ObserveRecognition { .. }
            | Expr::RecognitionCommit { .. }
            | Expr::RecognitionRollback { .. } => false,
            Expr::AssignScalar { value, .. } => Self::expr_reads_retv(value),
            Expr::AssignArrayAppend { value, .. } => Self::expr_reads_retv(value),
            Expr::AssignHashIndex { key, value, .. } => {
                Self::expr_reads_retv(key) || Self::expr_reads_retv(value)
            }
            Expr::AssignNestedAccess {
                base,
                segments,
                value,
                ..
            } => {
                base == "retv"
                    || segments
                        .iter()
                        .any(|segment| Self::expr_reads_retv(&segment.expression))
                    || Self::expr_reads_retv(value)
            }
            Expr::ReceiverMutationChain {
                receiver,
                mutation,
                continuation,
                ..
            } => {
                receiver.name == "retv"
                    || mutation
                        .callback
                        .body
                        .statements
                        .iter()
                        .any(|statement| Self::expr_reads_retv(&statement.expr))
                    || continuation
                        .iter()
                        .any(|call| call.args.iter().any(Self::arg_reads_retv))
            }
            Expr::Variable { name } => name == "retv",
            Expr::IndexedVar { name, index } => name == "retv" || Self::expr_reads_retv(index),
            Expr::NestedAccess { base, segments } => {
                base == "retv"
                    || segments.iter().any(|segment| match segment {
                        AccessSegment::Key { .. } => false,
                        AccessSegment::Index { expr } => Self::expr_reads_retv(expr),
                    })
            }
            Expr::ValueAccess { receiver, segments } => {
                Self::expr_reads_retv(receiver)
                    || segments.iter().any(|segment| match segment {
                        AccessSegment::Key { .. } => false,
                        AccessSegment::Index { expr } => Self::expr_reads_retv(expr),
                    })
            }
            Expr::ArrayLiteral { items } => items.iter().any(Self::expr_reads_retv),
            Expr::HashLiteral { entries } => entries.iter().any(|entry| {
                Self::expr_reads_retv(&entry.key) || Self::expr_reads_retv(&entry.value)
            }),
            Expr::BlockValue { block } => Self::block_reads_retv(block),
            // Construction is inert. A retv read inside the retained body does
            // not make the creating expression depend on an action-edge child.
            Expr::ContextualCodeblockCandidate(_) | Expr::CodeblockLiteral(_) => false,
            Expr::CodeblockArgument(argument) => argument
                .body_ast
                .statements
                .iter()
                .any(|statement| Self::expr_reads_retv(&statement.expr)),
            Expr::FluentChain { receiver, calls } => {
                Self::expr_reads_retv(receiver)
                    || calls
                        .iter()
                        .any(|call| call.args.iter().any(Self::arg_reads_retv))
            }
            Expr::StringLiteral { .. }
            | Expr::NumberLiteral { .. }
            | Expr::BooleanLiteral { .. }
            | Expr::RegexLiteral { .. }
            | Expr::Undef => false,
        }
    }

    fn arg_calls_rule(arg: &Arg, rule_label: &str) -> bool {
        Self::expr_calls_rule(arg.value(), rule_label)
    }

    fn arg_reads_retv(arg: &Arg) -> bool {
        Self::expr_reads_retv(arg.value())
    }

    fn call_names_rule(args: &[Arg], rule_label: &str) -> bool {
        match args.first().map(Arg::value) {
            Some(Expr::Variable { name }) | Some(Expr::StringLiteral { value: name }) => {
                name == rule_label
            }
            _ => false,
        }
    }

    fn execute_action_edge_fluent_chain(
        &self,
        entry: &linkedspec_core::types::AcodeEntry,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<ActionEdgeFlow, String> {
        let mut if_stack: Vec<StatementIfFrame> = Vec::new();
        let mut switch_stack: Vec<StatementSwitchFrame> = Vec::new();

        for (method, args) in &entry.fluent_chain {
            let call_args = Self::parse_action_edge_fluent_call_args(method, args)?;
            let call_expr = linkedspec_core::expr::Expr::Call {
                name: method.clone(),
                args: call_args.clone(),
            };
            let parent_active = Self::statement_controls_active(&if_stack, &switch_stack);
            if self.handle_statement_if_control(
                &call_expr,
                &mut if_stack,
                parent_active,
                ctx,
                rule_label,
            )? {
                continue;
            }
            if self.handle_statement_switch_control(
                &call_expr,
                &mut switch_stack,
                parent_active,
                ctx,
                rule_label,
            )? {
                continue;
            }

            if !Self::statement_controls_active(&if_stack, &switch_stack) {
                continue;
            }

            match method.as_str() {
                "push" => {
                    self.execute_action_edge_fluent_push(entry, &call_args, ctx, rule_label)?;
                }
                "return" => {
                    let value = self.eval_action_edge_fluent_return(args, ctx, rule_label)?;
                    if ctx.is_effective_entry_rule(rule_label) {
                        ctx.push_accumulator(value.clone());
                    }
                    ctx.set_return_value(value);
                    return Ok(ActionEdgeFlow::Returned);
                }
                "return_undef" => {
                    ctx.set_return_value(RuntimeValue::Undef);
                    return Ok(ActionEdgeFlow::Returned);
                }
                other => {
                    self.eval_expr(&call_expr, ctx, rule_label).map_err(|err| {
                        format!("action-edge fluent method '.{other}' failed: {err}")
                    })?;
                }
            }
        }
        Ok(ActionEdgeFlow::Continue)
    }

    fn parse_action_edge_fluent_call_args(
        method: &str,
        args: &str,
    ) -> Result<Vec<linkedspec_core::expr::Arg>, String> {
        let code = if args.trim().is_empty() {
            format!("{method}()")
        } else {
            format!("{method}({args})")
        };
        let block = linkedspec_core::expr::CodeBlock::parse(&code)
            .map_err(|err| format!("failed to parse action-edge fluent call '.{method}': {err}"))?;
        let Some(stmt) = block.statements.first() else {
            return Ok(Vec::new());
        };
        match &stmt.expr {
            Expr::Call { name, args } if name == method => Ok(args.clone()),
            _ => Err(format!(
                "failed to parse action-edge fluent call '.{method}' from {code}"
            )),
        }
    }

    fn execute_action_edge_fluent_push(
        &self,
        entry: &linkedspec_core::types::AcodeEntry,
        args: &[linkedspec_core::expr::Arg],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(), String> {
        let (child_label, child_regex_idx, target_label, bare_target) = match args.len() {
            0 => (
                entry.child_label.clone(),
                entry.child_regex_idx,
                rule_label.to_string(),
                false,
            ),
            1 => {
                let target_value = self.eval_expr(args[0].value(), ctx, rule_label)?;
                (
                    entry.child_label.clone(),
                    entry.child_regex_idx,
                    self.resolve_array_target(args, &target_value, true),
                    bare_variable_target_arg(&args[0]).is_some(),
                )
            }
            _ => {
                let child_value = self.eval_expr(args[0].value(), ctx, rule_label)?;
                let child_label = self.resolve_rule_name(args, Some(&child_value));
                let target_value = self.eval_expr(args[1].value(), ctx, rule_label)?;
                let child_regex_idx = if child_label == entry.child_label {
                    entry.child_regex_idx
                } else {
                    0
                };
                (
                    child_label,
                    child_regex_idx,
                    self.resolve_array_target(&args[1..], &target_value, true),
                    bare_variable_target_arg(&args[1]).is_some(),
                )
            }
        };

        let child_retv =
            if child_label == entry.child_label && child_regex_idx == entry.child_regex_idx {
                self.execute_action_edge_child_entry(entry, ctx)?
            } else {
                self.execute_action_edge_child_rule(&child_label, child_regex_idx, ctx)?
            };
        ctx.set_retv(child_retv.clone());
        if bare_target {
            let _ = ctx.push_bare_array_value(&target_label, child_retv)?;
        } else {
            ctx.push_array_value(&target_label, child_retv);
        }
        Ok(())
    }

    fn eval_action_edge_fluent_return(
        &self,
        args: &str,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let code = if args.trim().is_empty() {
            "return()".to_string()
        } else {
            format!("return({args})")
        };
        let block = linkedspec_core::expr::CodeBlock::parse(&code)?;
        let Some(stmt) = block.statements.first() else {
            return Ok(RuntimeValue::Undef);
        };
        match Self::return_call_payload(&stmt.expr) {
            Some(Some(expr)) => self.eval_expr(expr, ctx, rule_label),
            Some(None) => Ok(RuntimeValue::Undef),
            None => Err(format!("failed to parse action-edge fluent return: {code}")),
        }
    }

    /// Execute a lifecycle code block (parsed expression tree).
    fn execute_lifecycle_block(
        &self,
        phase: &str,
        block: &linkedspec_core::expr::CodeBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(), String> {
        ctx.trace_decision(
            "rust_runtime:engine:lifecycle_block",
            true,
            format!("rule={rule_label} phase={phase} pos={}", ctx.pos),
            TraceLevel::MEDIUM,
        );
        if phase == "I" {
            for statement in &block.statements {
                if let linkedspec_core::expr::Expr::AssignScalar { name, .. } = &statement.expr {
                    ctx.record_rule_local_binding(name);
                }
                if let linkedspec_core::expr::Expr::Call { name, args } = &statement.expr
                    && name == "set"
                    && let Some(linkedspec_core::expr::Arg::Positional(
                        linkedspec_core::expr::Expr::Variable { name },
                    )) = args.first()
                {
                    ctx.record_rule_local_binding(name);
                }
            }
        }
        let result = self.execute_block(block, ctx, rule_label);
        match &result {
            Ok(()) => {
                ctx.trace_decision(
                    "rust_runtime:engine:lifecycle_block_result",
                    true,
                    format!("rule={rule_label} phase={phase} pos={}", ctx.pos),
                    TraceLevel::MEDIUM,
                );
            }
            Err(err) => {
                ctx.trace_decision(
                    "rust_runtime:engine:lifecycle_block_result",
                    false,
                    format!("rule={rule_label} phase={phase} error={err}"),
                    TraceLevel::MEDIUM,
                );
            }
        }
        result
    }

    /// Execute a lifecycle code block (parsed expression tree).
    fn execute_block(
        &self,
        block: &linkedspec_core::expr::CodeBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(), String> {
        self.execute_block_statements(block, ctx, rule_label, true)?;
        Ok(())
    }

    fn execute_block_statements(
        &self,
        block: &linkedspec_core::expr::CodeBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
        stop_on_return_call: bool,
    ) -> Result<StatementBlockFlow, String> {
        let mut if_stack: Vec<StatementIfFrame> = Vec::new();
        let mut switch_stack: Vec<StatementSwitchFrame> = Vec::new();
        for stmt in &block.statements {
            let parent_active = Self::statement_controls_active(&if_stack, &switch_stack);
            if self.handle_statement_if_control(
                &stmt.expr,
                &mut if_stack,
                parent_active,
                ctx,
                rule_label,
            )? {
                continue;
            }
            let parent_active = Self::statement_controls_active(&if_stack, &switch_stack);
            if self.handle_statement_switch_control(
                &stmt.expr,
                &mut switch_stack,
                parent_active,
                ctx,
                rule_label,
            )? {
                continue;
            }
            if !Self::statement_controls_active(&if_stack, &switch_stack) {
                continue;
            }
            self.assert_receiver_write_expr(&stmt.expr, ctx)?;
            if let Some(flow) = self.execute_statement_while_loop(&stmt.expr, ctx, rule_label)? {
                if flow == StatementBlockFlow::Returned {
                    return Ok(flow);
                }
                continue;
            }
            if stop_on_return_call && Self::return_call_payload(&stmt.expr).is_some() {
                self.eval_expr(&stmt.expr, ctx, rule_label)?;
                return Ok(StatementBlockFlow::Returned);
            }
            if self.execute_scalar_assignment_operator_statement(&stmt.expr, ctx, rule_label)? {
                continue;
            }
            if self.execute_array_append_operator_statement(&stmt.expr, ctx, rule_label)? {
                continue;
            }
            if self.execute_array_end_mutation_method_statement(&stmt.expr, ctx, rule_label)? {
                continue;
            }
            if self.execute_hash_index_assignment_operator_statement(&stmt.expr, ctx, rule_label)? {
                continue;
            }
            if self
                .execute_nested_access_assignment_operator_statement(&stmt.expr, ctx, rule_label)?
            {
                continue;
            }
            if self.execute_set_key_statement(&stmt.expr, ctx, rule_label)? {
                continue;
            }
            self.execute_block_statement_expr(&stmt.expr, ctx, rule_label)?;
        }
        Ok(StatementBlockFlow::Continue)
    }

    fn execute_block_statement_expr(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(), String> {
        self.assert_receiver_write_expr(expr, ctx)?;
        if self.execute_scalar_assignment_operator_statement(expr, ctx, rule_label)? {
            return Ok(());
        }
        if self.execute_array_append_operator_statement(expr, ctx, rule_label)? {
            return Ok(());
        }
        if self.execute_array_end_mutation_method_statement(expr, ctx, rule_label)? {
            return Ok(());
        }
        if self.execute_hash_index_assignment_operator_statement(expr, ctx, rule_label)? {
            return Ok(());
        }
        if self.execute_nested_access_assignment_operator_statement(expr, ctx, rule_label)? {
            return Ok(());
        }
        if self.execute_set_key_statement(expr, ctx, rule_label)? {
            return Ok(());
        }
        if self.execute_push_child_call_statement(expr, ctx, rule_label)? {
            return Ok(());
        }
        if self.execute_array_string_transform_statement(expr, ctx, rule_label)? {
            return Ok(());
        }
        self.eval_expr(expr, ctx, rule_label)?;
        Ok(())
    }

    fn execute_array_string_transform_statement(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        use linkedspec_core::expr::{Arg, Expr};

        let Expr::Call { name, args } = expr else {
            return Ok(false);
        };
        let arity = match name.as_str() {
            "split_each" | "filter_match" => 2,
            "trim_each" | "filter_nonempty" | "lowercase_each" | "uppercase_each" | "uniq" => 1,
            _ => return Ok(false),
        };
        if args.len() != arity || args.iter().any(|arg| !matches!(arg, Arg::Positional(_))) {
            return Ok(false);
        }
        let (target, bare_target) = match args.first() {
            Some(Arg::Positional(Expr::Variable { name })) => (name.as_str(), true),
            Some(Arg::Positional(Expr::Call {
                name: wrapper,
                args: wrapper_args,
            })) if wrapper == "array" => {
                let [Arg::Positional(Expr::Variable { name })] = wrapper_args.as_slice() else {
                    return Ok(false);
                };
                (name.as_str(), false)
            }
            _ => return Ok(false),
        };

        let source = if bare_target {
            match ctx.get_bare_value(target) {
                RuntimeValue::Array(values) => values,
                RuntimeValue::Undef if ctx.bare_kind(target).is_none() => Vec::new(),
                actual => {
                    return Err(format!(
                        "binding_kind_mismatch identifier={target} expected_kind=array actual_kind={}",
                        match actual {
                            RuntimeValue::Hash(_) => "harray",
                            RuntimeValue::Array(_) => "array",
                            _ => "scalar",
                        }
                    ));
                }
            }
        } else {
            ctx.get_array(target)
        };
        let transformed = if matches!(name.as_str(), "split_each" | "filter_match" | "uniq") {
            let mut values = vec![RuntimeValue::Array(source)];
            for arg in args.iter().skip(1) {
                values.push(self.eval_expr(arg.value(), ctx, rule_label)?);
            }
            let RuntimeValue::Array(transformed) =
                self.call_helper(name, args, &values, ctx, rule_label)?
            else {
                return Err(format!("array transform '{name}' did not return an array"));
            };
            transformed
        } else if name == "filter_nonempty" {
            source
                .into_iter()
                .filter(RuntimeValue::is_nonempty)
                .collect()
        } else {
            source
                .iter()
                .map(|value| {
                    let value = value.to_str();
                    RuntimeValue::Scalar(match name.as_str() {
                        "trim_each" => value.trim().to_string(),
                        "lowercase_each" => crate::unicode_case_mapping::lowercase(&value),
                        "uppercase_each" => crate::unicode_case_mapping::uppercase(&value),
                        _ => unreachable!(),
                    })
                })
                .collect()
        };
        if bare_target {
            let _ = ctx.replace_bare_array(target, transformed)?;
        } else {
            ctx.set_array(target, transformed);
        }
        ctx.trace_decision(
            "rust_runtime:engine:array_string_transform_statement",
            true,
            format!("rule={rule_label} helper={name} target={target}"),
            TraceLevel::FULL,
        );
        Ok(true)
    }

    fn execute_statement_while_loop(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Option<StatementBlockFlow>, String> {
        let Some((condition, body)) = Self::while_call_parts(expr) else {
            return Ok(None);
        };

        let mut iterations = 0usize;
        while self.eval_expr(condition, ctx, rule_label)?.as_bool() {
            iterations += 1;
            if iterations > LINKEDSPEC_WHILE_ITERATION_LIMIT {
                return Err(Self::while_iteration_limit_message());
            }
            if self.execute_block_statements(body, ctx, rule_label, true)?
                == StatementBlockFlow::Returned
            {
                return Ok(Some(StatementBlockFlow::Returned));
            }
        }

        Ok(Some(StatementBlockFlow::Continue))
    }

    fn statement_controls_active(
        if_stack: &[StatementIfFrame],
        switch_stack: &[StatementSwitchFrame],
    ) -> bool {
        if_stack.iter().all(|frame| frame.current_active)
            && switch_stack.iter().all(|frame| frame.current_active)
    }

    /// Handle statement-form `if(cond); elseif(cond); else(); endif()` controls.
    ///
    /// Only one-argument `if`/`elseif` and zero-argument `else`/`endif` are
    /// statement controls. Multi-argument `if(cond, then, else)` remains the
    /// value helper implemented by `call_helper_lazy`.
    fn handle_statement_if_control(
        &self,
        expr: &linkedspec_core::expr::Expr,
        if_stack: &mut Vec<StatementIfFrame>,
        parent_active: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        use linkedspec_core::expr::Expr;

        let Expr::Call { name, args } = expr else {
            return Ok(false);
        };

        match name.as_str() {
            "if" | "i" if args.len() == 1 => {
                let cond = if parent_active {
                    self.eval_expr(args[0].value(), ctx, rule_label)?.as_bool()
                } else {
                    false
                };
                ctx.trace_decision(
                    "rust_runtime:engine:statement_if",
                    parent_active && cond,
                    format!("rule={rule_label} branch=if parent_active={parent_active}"),
                    TraceLevel::FULL,
                );
                if_stack.push(StatementIfFrame {
                    parent_active,
                    current_active: parent_active && cond,
                    branch_taken: cond,
                });
                Ok(true)
            }
            "elseif" | "elif" if args.len() == 1 => {
                let Some(frame) = if_stack.last_mut() else {
                    return Ok(true);
                };
                if frame.parent_active && !frame.branch_taken {
                    let cond = self.eval_expr(args[0].value(), ctx, rule_label)?.as_bool();
                    frame.current_active = cond;
                    frame.branch_taken = cond;
                    ctx.trace_decision(
                        "rust_runtime:engine:statement_if",
                        cond,
                        format!("rule={rule_label} branch=elseif parent_active=true"),
                        TraceLevel::FULL,
                    );
                } else {
                    frame.current_active = false;
                    ctx.trace_decision(
                        "rust_runtime:engine:statement_if",
                        false,
                        format!(
                            "rule={rule_label} branch=elseif parent_active={} prior_branch_taken={}",
                            frame.parent_active, frame.branch_taken
                        ),
                        TraceLevel::FULL,
                    );
                }
                Ok(true)
            }
            "else" if args.is_empty() => {
                let Some(frame) = if_stack.last_mut() else {
                    return Ok(true);
                };
                frame.current_active = frame.parent_active && !frame.branch_taken;
                ctx.trace_decision(
                    "rust_runtime:engine:statement_if",
                    frame.current_active,
                    format!(
                        "rule={rule_label} branch=else parent_active={} prior_branch_taken={}",
                        frame.parent_active, frame.branch_taken
                    ),
                    TraceLevel::FULL,
                );
                frame.branch_taken = true;
                Ok(true)
            }
            "endif" if args.is_empty() => {
                if_stack.pop();
                Ok(true)
            }
            _ => Ok(false),
        }
    }

    /// Handle statement-form `switch(expr); case(value); default(); endswitch()` controls.
    ///
    /// Only one-argument `switch` / `case` and zero-argument `default` /
    /// `endswitch` are statement controls. Multi-argument lazy value-form
    /// `switch(expr, case(...), default(...))` remains in `call_helper_lazy`.
    fn handle_statement_switch_control(
        &self,
        expr: &linkedspec_core::expr::Expr,
        switch_stack: &mut Vec<StatementSwitchFrame>,
        parent_active: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        use linkedspec_core::expr::Expr;

        let Expr::Call { name, args } = expr else {
            return Ok(false);
        };

        match name.as_str() {
            "switch" if args.len() == 1 => {
                let switch_value = if parent_active {
                    self.eval_expr(args[0].value(), ctx, rule_label)?.to_str()
                } else {
                    String::new()
                };
                ctx.trace_decision(
                    "rust_runtime:engine:statement_switch",
                    parent_active,
                    format!("rule={rule_label} branch=switch parent_active={parent_active}"),
                    TraceLevel::FULL,
                );
                switch_stack.push(StatementSwitchFrame {
                    parent_active,
                    current_active: false,
                    branch_taken: false,
                    switch_value,
                });
                Ok(true)
            }
            "case" if args.len() == 1 => {
                let Some(frame) = switch_stack.last_mut() else {
                    return Ok(true);
                };
                if frame.parent_active && !frame.branch_taken {
                    let case_value =
                        self.eval_switch_case_value(args[0].value(), ctx, rule_label)?;
                    let matches = case_value == frame.switch_value;
                    frame.current_active = matches;
                    frame.branch_taken = matches;
                    ctx.trace_decision(
                        "rust_runtime:engine:statement_switch",
                        matches,
                        format!("rule={rule_label} branch=case parent_active=true"),
                        TraceLevel::FULL,
                    );
                } else {
                    frame.current_active = false;
                    ctx.trace_decision(
                        "rust_runtime:engine:statement_switch",
                        false,
                        format!(
                            "rule={rule_label} branch=case parent_active={} prior_branch_taken={}",
                            frame.parent_active, frame.branch_taken
                        ),
                        TraceLevel::FULL,
                    );
                }
                Ok(true)
            }
            "default" if args.is_empty() => {
                let Some(frame) = switch_stack.last_mut() else {
                    return Ok(true);
                };
                frame.current_active = frame.parent_active && !frame.branch_taken;
                ctx.trace_decision(
                    "rust_runtime:engine:statement_switch",
                    frame.current_active,
                    format!(
                        "rule={rule_label} branch=default parent_active={} prior_branch_taken={}",
                        frame.parent_active, frame.branch_taken
                    ),
                    TraceLevel::FULL,
                );
                frame.branch_taken = true;
                Ok(true)
            }
            "endswitch" if args.is_empty() => {
                switch_stack.pop();
                Ok(true)
            }
            _ => Ok(false),
        }
    }

    fn eval_switch_case_value(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<String, String> {
        match expr {
            linkedspec_core::expr::Expr::Variable { name } => Ok(name.clone()),
            other => Ok(self.eval_expr(other, ctx, rule_label)?.to_str()),
        }
    }

    /// Execute the statement-only scalar assignment operator `name = value`.
    fn execute_scalar_assignment_operator_statement(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        use linkedspec_core::expr::Expr;
        let Expr::AssignScalar { name, value } = expr else {
            return Ok(false);
        };
        if matches!(value.as_ref(), Expr::RecognitionCheckpoint) {
            ctx.recognition_checkpoint(rule_label, name)?;
            ctx.set_scalar(name, RuntimeValue::Undef);
            return Ok(true);
        }
        let evaluated = self.eval_expr(value, ctx, rule_label)?;
        ctx.set_scalar(name, evaluated);
        Ok(true)
    }

    /// Execute the statement-level array append operator `items += value`.
    fn execute_array_append_operator_statement(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        use linkedspec_core::expr::Expr;
        let Expr::AssignArrayAppend { name, value } = expr else {
            return Ok(false);
        };
        let _ = self.eval_array_append_expression(name, value, ctx, rule_label)?;
        Ok(true)
    }

    /// Execute the statement-level hash-index assignment operator `meta["key"] = value`.
    fn execute_hash_index_assignment_operator_statement(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        use linkedspec_core::expr::Expr;
        let Expr::AssignHashIndex { name, key, value } = expr else {
            return Ok(false);
        };
        self.eval_hash_index_assignment_expression(name, key, value, ctx, rule_label)?;
        Ok(true)
    }

    /// Execute the statement-level nested value-path assignment
    /// `payload["items"][0]["name"] = value`.
    fn execute_nested_access_assignment_operator_statement(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        use linkedspec_core::expr::Expr;
        let Expr::AssignNestedAccess {
            base,
            segments,
            value,
            ..
        } = expr
        else {
            return Ok(false);
        };
        self.eval_nested_access_assignment_expression(base, segments, value, ctx, rule_label)?;
        Ok(true)
    }

    fn eval_array_append_expression(
        &self,
        name: &str,
        value: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let evaluated = self.eval_expr(value, ctx, rule_label)?;
        ctx.push_bare_array_value(name, evaluated)
    }

    fn eval_hash_index_assignment_expression(
        &self,
        name: &str,
        key: &linkedspec_core::expr::Expr,
        value: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        if matches!(ctx.bare_kind(name), Some(RuntimeVarKind::Scalar))
            && matches!(ctx.get_scalar(name), RuntimeValue::Array(_))
        {
            let RuntimeValue::Array(mut items) = ctx.get_scalar(name) else {
                unreachable!("scalar-held array kind checked before indexed mutation");
            };
            if matches!(key, linkedspec_core::expr::Expr::StringLiteral { .. }) {
                return Ok(RuntimeValue::Undef);
            }
            let idx_val = self.eval_expr(key, ctx, rule_label)?;
            let idx_number = idx_val.as_number().unwrap_or(0.0);
            let idx = if idx_number.is_finite() && idx_number >= 0.0 {
                idx_number as usize
            } else {
                usize::MAX
            };
            let evaluated_value = self.eval_expr(value, ctx, rule_label)?;
            if idx < items.len() {
                items[idx] = evaluated_value;
            } else if idx == items.len() {
                items.push(evaluated_value);
            } else {
                return Ok(RuntimeValue::Undef);
            }
            let updated = RuntimeValue::Array(items);
            ctx.set_scalar(name, updated.clone());
            return Ok(updated);
        }
        let evaluated_key = self.eval_expr(key, ctx, rule_label)?.to_str();
        let evaluated_value = self.eval_expr(value, ctx, rule_label)?;
        ctx.set_bare_hash_entry(name, evaluated_key, evaluated_value)
    }

    fn eval_nested_access_assignment_expression(
        &self,
        base: &str,
        segments: &[WritePathSegment],
        value: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        if segments.is_empty() {
            return Err(
                "nested_write_serialized_state_invalid reason=segments_empty operation=nested_write_vivification"
                    .to_string(),
            );
        }
        let evaluated_values = self.eval_write_path_segments(segments, ctx, rule_label)?;
        let evaluated_value = self.eval_expr(value, ctx, rule_label)?;
        let evaluated_segments =
            Self::classify_write_path_segments(base, segments, &evaluated_values)
                .map_err(|error| error.to_string())?;

        let root_was_present = ctx.has_bare_binding(base);
        let original_kind = ctx.bare_kind(base);
        let mut root = if root_was_present {
            ctx.get_bare_value(base)
        } else {
            Self::empty_container_for(base, &evaluated_segments[0], &segments[0], 0, &[])
                .map_err(|error| error.to_string())?
        };
        let mut path = Vec::new();
        Self::assign_nested_runtime_value(
            base,
            &mut root,
            &evaluated_segments,
            segments,
            0,
            &mut path,
            evaluated_value,
        )
        .map_err(|error| error.to_string())?;

        match (original_kind, &root) {
            (Some(RuntimeVarKind::Array), RuntimeValue::Array(values)) => {
                ctx.set_array(base, values.clone())
            }
            (Some(RuntimeVarKind::Hash), RuntimeValue::Hash(values)) => {
                ctx.set_hash(base, values.clone())
            }
            _ => ctx.set_scalar(base, root.clone()),
        }
        Ok(root)
    }

    fn eval_write_path_segments(
        &self,
        segments: &[WritePathSegment],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Vec<RuntimeValue>, String> {
        let mut evaluated = Vec::with_capacity(segments.len());
        for segment in segments {
            evaluated.push(self.eval_expr(&segment.expression, ctx, rule_label)?);
        }
        Ok(evaluated)
    }

    fn negative_array_index(number: f64) -> Option<i128> {
        if !number.is_finite()
            || number >= 0.0
            || number.fract() != 0.0
            || number < -(usize::MAX as f64)
        {
            return None;
        }
        // The float guard bounds conversion well inside i128. Recheck the exact
        // platform bound after conversion because usize::MAX may round upward.
        let index = number as i128;
        (index >= -(usize::MAX as i128)).then_some(index)
    }

    fn classify_write_path_segments(
        base: &str,
        authored: &[WritePathSegment],
        values: &[RuntimeValue],
    ) -> Result<Vec<EvaluatedAccessSegment>, NestedWriteError> {
        debug_assert_eq!(authored.len(), values.len());
        let mut evaluated = Vec::with_capacity(values.len());
        for (segment_index, (segment, value)) in authored.iter().zip(values).enumerate() {
            let classified = match value {
                RuntimeValue::Scalar(key) => EvaluatedAccessSegment::Key(key.clone()),
                RuntimeValue::Number(number) => {
                    if let Some(index) =
                        linkedspec_core::numeric::nonnegative_integer_to_usize(*number)
                    {
                        evaluated.push(EvaluatedAccessSegment::Index(index));
                        continue;
                    }
                    if let Some(index) = Self::negative_array_index(*number) {
                        evaluated.push(EvaluatedAccessSegment::NegativeIndex(index));
                        continue;
                    }
                    let (actual_kind, reason) =
                        if number.is_finite() && number.fract() == 0.0 && *number < 0.0 {
                            ("integer", "negative_integer")
                        } else if number.is_finite() && number.fract() != 0.0 {
                            ("number", "fractional_number")
                        } else {
                            ("number", "kind_not_path_selector")
                        };
                    return Err(NestedWriteError {
                        binding: base.to_string(),
                        segment_index,
                        path: evaluated,
                        source_span: segment.source_span,
                        failure: NestedWriteFailure::InvalidSegment {
                            actual_kind,
                            reason,
                        },
                    });
                }
                other => {
                    return Err(NestedWriteError {
                        binding: base.to_string(),
                        segment_index,
                        path: evaluated,
                        source_span: segment.source_span,
                        failure: NestedWriteFailure::InvalidSegment {
                            actual_kind: Self::nested_write_value_kind(other),
                            reason: "kind_not_path_selector",
                        },
                    });
                }
            };
            evaluated.push(classified);
        }
        Ok(evaluated)
    }

    fn nested_write_value_kind(value: &RuntimeValue) -> &'static str {
        match value {
            RuntimeValue::Undef => "null",
            RuntimeValue::Scalar(_) => "string",
            RuntimeValue::Number(number) if number.is_finite() && number.fract() == 0.0 => {
                "integer"
            }
            RuntimeValue::Number(_) => "number",
            RuntimeValue::Bool(_) => "boolean",
            RuntimeValue::Array(_) => "array",
            RuntimeValue::Hash(_) => "harray",
            RuntimeValue::Codeblock(_) => "codeblock",
        }
    }

    fn empty_container_for(
        base: &str,
        segment: &EvaluatedAccessSegment,
        authored: &WritePathSegment,
        segment_index: usize,
        path: &[EvaluatedAccessSegment],
    ) -> Result<RuntimeValue, NestedWriteError> {
        match segment {
            EvaluatedAccessSegment::Key(_) => Ok(RuntimeValue::Hash(Vec::new())),
            EvaluatedAccessSegment::Index(_) => Ok(RuntimeValue::Array(Vec::new())),
            EvaluatedAccessSegment::NegativeIndex(_) => Err(NestedWriteError {
                binding: base.to_string(),
                segment_index,
                path: path.to_vec(),
                source_span: authored.source_span,
                failure: NestedWriteFailure::InvalidSegment {
                    actual_kind: "integer",
                    reason: "negative_integer",
                },
            }),
        }
    }

    fn assign_nested_runtime_value(
        base: &str,
        current: &mut RuntimeValue,
        segments: &[EvaluatedAccessSegment],
        authored: &[WritePathSegment],
        segment_index: usize,
        path: &mut Vec<EvaluatedAccessSegment>,
        value: RuntimeValue,
    ) -> Result<(), NestedWriteError> {
        let segment = &segments[segment_index];
        let source_span = authored[segment_index].source_span;
        let last = segment_index + 1 == segments.len();

        match segment {
            EvaluatedAccessSegment::Key(key) => {
                let RuntimeValue::Hash(entries) = current else {
                    return Err(NestedWriteError {
                        binding: base.to_string(),
                        segment_index,
                        path: path.clone(),
                        source_span,
                        failure: NestedWriteFailure::KindConflict {
                            expected_kind: segment.expected_container_kind(),
                            actual_kind: Self::nested_write_value_kind(current),
                        },
                    });
                };
                if last {
                    if let Some((_, existing)) =
                        entries.iter_mut().find(|(candidate, _)| candidate == key)
                    {
                        *existing = value;
                    } else {
                        entries.push((key.clone(), value));
                    }
                    return Ok(());
                }

                let child_index = entries.iter().position(|(candidate, _)| candidate == key);
                if child_index.is_none() {
                    let mut child_path = path.clone();
                    child_path.push(segment.clone());
                    let child = Self::empty_container_for(
                        base,
                        &segments[segment_index + 1],
                        &authored[segment_index + 1],
                        segment_index + 1,
                        &child_path,
                    )?;
                    entries.push((key.clone(), child));
                }
                let child_index = child_index.unwrap_or(entries.len() - 1);
                path.push(segment.clone());
                let result = Self::assign_nested_runtime_value(
                    base,
                    &mut entries[child_index].1,
                    segments,
                    authored,
                    segment_index + 1,
                    path,
                    value,
                );
                path.pop();
                result
            }
            EvaluatedAccessSegment::Index(_) | EvaluatedAccessSegment::NegativeIndex(_) => {
                let RuntimeValue::Array(items) = current else {
                    return Err(NestedWriteError {
                        binding: base.to_string(),
                        segment_index,
                        path: path.clone(),
                        source_span,
                        failure: NestedWriteFailure::KindConflict {
                            expected_kind: segment.expected_container_kind(),
                            actual_kind: Self::nested_write_value_kind(current),
                        },
                    });
                };
                let index = match segment {
                    EvaluatedAccessSegment::Index(index) => *index,
                    EvaluatedAccessSegment::NegativeIndex(index) => {
                        let resolved = usize::try_from(index.unsigned_abs())
                            .ok()
                            .and_then(|distance| items.len().checked_sub(distance));
                        let Some(resolved) = resolved else {
                            return Err(NestedWriteError {
                                binding: base.to_string(),
                                segment_index,
                                path: path.clone(),
                                source_span,
                                failure: NestedWriteFailure::ArrayUnderflow {
                                    index: *index,
                                    length: items.len(),
                                    resolved_index: items.len() as i128 + index,
                                },
                            });
                        };
                        resolved
                    }
                    EvaluatedAccessSegment::Key(_) => unreachable!("array selector branch"),
                };
                if index > items.len() {
                    return Err(NestedWriteError {
                        binding: base.to_string(),
                        segment_index,
                        path: path.clone(),
                        source_span,
                        failure: NestedWriteFailure::ArrayGap {
                            index,
                            length: items.len(),
                        },
                    });
                }
                if last {
                    if index == items.len() {
                        items.push(value);
                    } else {
                        items[index] = value;
                    }
                    return Ok(());
                }

                if index == items.len() {
                    let mut child_path = path.clone();
                    child_path.push(segment.clone());
                    items.push(Self::empty_container_for(
                        base,
                        &segments[segment_index + 1],
                        &authored[segment_index + 1],
                        segment_index + 1,
                        &child_path,
                    )?);
                }
                path.push(segment.clone());
                let result = Self::assign_nested_runtime_value(
                    base,
                    &mut items[index],
                    segments,
                    authored,
                    segment_index + 1,
                    path,
                    value,
                );
                path.pop();
                result
            }
        }
    }

    /// Execute statement-level receiver-dot array end mutations.
    ///
    /// `items.push_back(value)` names the working array on the receiver side;
    /// this is not a value-returning fluent expression in this slice.
    fn execute_array_end_mutation_method_statement(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        Ok(self
            .eval_array_end_mutation_method(expr, ctx, rule_label)?
            .is_some())
    }

    fn eval_array_end_mutation_method(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Option<RuntimeValue>, String> {
        use linkedspec_core::expr::Expr;
        let Expr::FluentChain { receiver, calls } = expr else {
            return Ok(None);
        };
        let [call] = calls.as_slice() else {
            return Ok(None);
        };
        self.eval_array_end_mutation_call(receiver, call, ctx, rule_label)
    }

    fn eval_array_end_mutation_call(
        &self,
        receiver: &linkedspec_core::expr::Expr,
        call: &linkedspec_core::expr::FluentCall,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Option<RuntimeValue>, String> {
        use linkedspec_core::expr::Expr;

        let Some(target) = Self::array_receiver_target(receiver) else {
            return Ok(None);
        };
        let bare_target = matches!(receiver, Expr::Variable { .. });

        let updated = match call.method.as_str() {
            "push_back" if call.args.len() == 1 => {
                let value = self.eval_expr(call.args[0].value(), ctx, rule_label)?;
                if bare_target {
                    ctx.push_bare_array_value(&target, value)?
                } else {
                    ctx.push_array_value(&target, value);
                    RuntimeValue::Array(ctx.get_array(&target))
                }
            }
            "push_front" if call.args.len() == 1 => {
                let value = self.eval_expr(call.args[0].value(), ctx, rule_label)?;
                if bare_target {
                    ctx.push_front_bare_array_value(&target, value)?
                } else {
                    ctx.push_front_value(&target, value);
                    RuntimeValue::Array(ctx.get_array(&target))
                }
            }
            "pop_back" if call.args.is_empty() => {
                if bare_target {
                    ctx.pop_back_bare_array_value(&target)?
                } else {
                    let _ = ctx.pop_back_value(&target);
                    RuntimeValue::Array(ctx.get_array(&target))
                }
            }
            "pop_front" if call.args.is_empty() => {
                if bare_target {
                    ctx.pop_front_bare_array_value(&target)?
                } else {
                    let _ = ctx.pop_front_value(&target);
                    RuntimeValue::Array(ctx.get_array(&target))
                }
            }
            _ => return Ok(None),
        };
        Ok(Some(updated))
    }

    fn array_receiver_target(receiver: &linkedspec_core::expr::Expr) -> Option<String> {
        use linkedspec_core::expr::Expr;
        match receiver {
            Expr::Variable { name } => Some(name.clone()),
            _ => None,
        }
    }

    /// Execute the top-level mutation form `set_key(target, key, value)`.
    ///
    /// Nested `set_key(hash_expr, key, value)` remains a pure hash-valued
    /// expression in `call_helper`; only a lifecycle statement whose first
    /// argument names a hash target mutates the runtime hash.
    fn execute_set_key_statement(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        use linkedspec_core::expr::{Arg, Expr};
        let Expr::Call { name, args } = expr else {
            return Ok(false);
        };
        if name != "set_key" {
            return Ok(false);
        }

        let effective_args: &[Arg] = if args.len() == 4 {
            match args.first() {
                Some(Arg::Positional(Expr::Variable { .. })) => &args[1..],
                _ => args,
            }
        } else {
            args
        };
        if effective_args.len() != 3 {
            return Ok(false);
        }

        let hash_name = self.resolve_hash_target(effective_args, &RuntimeValue::Undef, true);
        if hash_name.is_empty() {
            return Ok(false);
        }

        let key = self
            .eval_expr(effective_args[1].value(), ctx, rule_label)?
            .to_str();
        let value = self.eval_expr(effective_args[2].value(), ctx, rule_label)?;
        if bare_variable_target_arg(&effective_args[0]).is_some() {
            let _ = ctx.set_bare_hash_entry(&hash_name, key, value)?;
        } else {
            ctx.set_hash_entry(&hash_name, &key, value);
        }
        Ok(true)
    }

    fn execute_push_child_call_statement(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<bool, String> {
        Ok(self.eval_push_child_call(expr, ctx, rule_label)?.is_some())
    }

    fn eval_push_child_call(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Option<RuntimeValue>, String> {
        use linkedspec_core::expr::{Arg, Expr};

        let Expr::Call { name, args } = expr else {
            return Ok(None);
        };
        if name != "push" || args.is_empty() || args.len() > 3 {
            return Ok(None);
        }

        let Some(child_label) = args.first().and_then(|arg| match arg {
            Arg::Positional(Expr::Variable { name }) if self.spec.find(name).is_some() => {
                Some(name.as_str())
            }
            _ => None,
        }) else {
            return Ok(None);
        };

        if matches!(args.as_slice(), [_child, _target, index_arg] if Self::literal_usize_arg(index_arg).is_none())
        {
            return Ok(None);
        }

        let child_value = if let Some(value) = ctx.action_edge_call_result(child_label) {
            value
        } else {
            self.execute_child_rule(child_label, 0, ctx)?
        };

        let updated = match args.as_slice() {
            [_child] => {
                ctx.push_array_value(rule_label, child_value);
                RuntimeValue::Array(ctx.get_array(rule_label))
            }
            [_child, second] => {
                if let Some(index) = Self::literal_usize_arg(second) {
                    ctx.push_array_value(rule_label, Self::array_index_value(&child_value, index));
                    RuntimeValue::Array(ctx.get_array(rule_label))
                } else {
                    let target_value = self.eval_expr(second.value(), ctx, rule_label)?;
                    let target = self.resolve_array_target(
                        std::slice::from_ref(second),
                        &target_value,
                        true,
                    );
                    if bare_variable_target_arg(second).is_some() {
                        ctx.push_bare_array_value(&target, child_value)?
                    } else {
                        ctx.push_array_value(&target, child_value);
                        RuntimeValue::Array(ctx.get_array(&target))
                    }
                }
            }
            [_child, target_arg, index_arg] => {
                let index = Self::literal_usize_arg(index_arg)
                    .expect("push(child, target, index) shape validated before child dispatch");
                let target_value = self.eval_expr(target_arg.value(), ctx, rule_label)?;
                let target = self.resolve_array_target(
                    std::slice::from_ref(target_arg),
                    &target_value,
                    true,
                );
                let value = Self::array_index_value(&child_value, index);
                if bare_variable_target_arg(target_arg).is_some() {
                    ctx.push_bare_array_value(&target, value)?
                } else {
                    ctx.push_array_value(&target, value);
                    RuntimeValue::Array(ctx.get_array(&target))
                }
            }
            _ => return Ok(None),
        };

        Ok(Some(updated))
    }

    fn literal_usize_arg(arg: &linkedspec_core::expr::Arg) -> Option<usize> {
        match arg.value() {
            linkedspec_core::expr::Expr::NumberLiteral { value }
                if value.is_finite() && *value >= 0.0 && value.fract() == 0.0 =>
            {
                Some(*value as usize)
            }
            _ => None,
        }
    }

    fn array_index_value(value: &RuntimeValue, index: usize) -> RuntimeValue {
        match value {
            RuntimeValue::Array(values) => {
                values.get(index).cloned().unwrap_or(RuntimeValue::Undef)
            }
            _ => RuntimeValue::Undef,
        }
    }

    fn array_selector_value(value: &RuntimeValue, selector: &RuntimeValue) -> RuntimeValue {
        let RuntimeValue::Array(values) = value else {
            return RuntimeValue::Undef;
        };
        let index = match selector {
            RuntimeValue::Number(number)
                if number.is_finite() && *number < 0.0 && number.fract() == 0.0 =>
            {
                Self::negative_array_index(*number)
                    .and_then(|index| usize::try_from(index.unsigned_abs()).ok())
                    .and_then(|distance| values.len().checked_sub(distance))
            }
            _ => Some(selector.as_number().unwrap_or(0.0) as usize),
        };
        index
            .and_then(|index| values.get(index))
            .cloned()
            .unwrap_or(RuntimeValue::Undef)
    }

    fn scalar_held_array_snapshot(ctx: &RuntimeContext, name: &str) -> Option<Vec<RuntimeValue>> {
        if ctx.descriptor_scalar_bare_read(name) {
            return None;
        }
        if !matches!(ctx.bare_kind(name), Some(RuntimeVarKind::Scalar)) {
            return None;
        }
        match ctx.get_scalar(name) {
            RuntimeValue::Array(values) => Some(values),
            _ => None,
        }
    }

    fn scalar_held_hash_snapshot(
        ctx: &RuntimeContext,
        name: &str,
    ) -> Option<Vec<(String, RuntimeValue)>> {
        if ctx.descriptor_scalar_bare_read(name) {
            return None;
        }
        if !matches!(ctx.bare_kind(name), Some(RuntimeVarKind::Scalar)) {
            return None;
        }
        match ctx.get_scalar(name) {
            RuntimeValue::Hash(values) => Some(values),
            _ => None,
        }
    }

    fn eval_access_value(
        &self,
        mut current: RuntimeValue,
        segments: &[AccessSegment],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        for segment in segments {
            current = match segment {
                AccessSegment::Key { value } => match current {
                    RuntimeValue::Hash(entries) => entries
                        .into_iter()
                        .find(|(key, _)| key == value)
                        .map(|(_, value)| value)
                        .unwrap_or(RuntimeValue::Undef),
                    _ => RuntimeValue::Undef,
                },
                AccessSegment::Index { expr } => {
                    let index = self.eval_expr(expr, ctx, rule_label)?;
                    Self::array_selector_value(&current, &index)
                }
            };
        }
        Ok(current)
    }

    fn receiver_mutation_value_kind(value: &RuntimeValue) -> &'static str {
        match value {
            RuntimeValue::Hash(_) => "harray",
            RuntimeValue::Array(_) => "array",
            RuntimeValue::Undef => "null",
            RuntimeValue::Scalar(_) => "string",
            RuntimeValue::Number(_) => "number",
            RuntimeValue::Bool(_) => "boolean",
            RuntimeValue::Codeblock(_) => "codeblock",
        }
    }

    fn receiver_write_attempt(expr: &Expr) -> Option<(&str, String, Option<ExpressionSpan>)> {
        match expr {
            Expr::AssignScalar { name, .. } => Some((name, "assign".to_string(), None)),
            Expr::AssignArrayAppend { name, .. } => Some((name, "append".to_string(), None)),
            Expr::AssignHashIndex { name, .. } => Some((name, "nested_write".to_string(), None)),
            Expr::AssignNestedAccess {
                source_span, base, ..
            } => Some((
                base,
                "nested_write".to_string(),
                Some(ExpressionSpan {
                    start: source_span.start,
                    end: source_span.start + base.chars().count(),
                }),
            )),
            Expr::ReceiverMutationChain { receiver, .. } => Some((
                receiver.name.as_str(),
                "map_leaves!".to_string(),
                Some(receiver.source_span),
            )),
            Expr::FluentChain { receiver, calls } => {
                let Expr::Variable { name } = receiver.as_ref() else {
                    return None;
                };
                let call = calls.first()?;
                Self::is_statement_only_array_end_mutation_method(&call.method)
                    .then(|| (name.as_str(), call.method.clone(), None))
            }
            Expr::Call { name, args } => {
                let target = match args.first()?.value() {
                    Expr::Variable { name } => name.as_str(),
                    _ => return None,
                };
                let attempt = match name.as_str() {
                    "set" | "=" if args.len() >= 2 => "helper:set".to_string(),
                    "set_key" if args.len() >= 3 => "helper:set_key".to_string(),
                    "push" if args.len() >= 2 => "helper:push".to_string(),
                    "split" if args.len() == 3 => "helper:split".to_string(),
                    "split_each" | "trim_each" | "filter_nonempty" | "filter_match"
                    | "lowercase_each" | "uppercase_each" | "uniq" => {
                        format!("helper:{name}")
                    }
                    _ => return None,
                };
                Some((target, attempt, None))
            }
            _ => None,
        }
    }

    fn assert_receiver_write_expr(&self, expr: &Expr, ctx: &RuntimeContext) -> Result<(), String> {
        let Some((target, attempt, explicit_span)) = Self::receiver_write_attempt(expr) else {
            return Ok(());
        };
        let Some((binding, site_span)) = ctx.active_receiver_write(target, &attempt) else {
            return Ok(());
        };
        Err(ReceiverMutationError {
            binding: binding.to_string(),
            source_span: explicit_span
                .or(site_span)
                .unwrap_or(ExpressionSpan { start: 0, end: 0 }),
            failure: ReceiverMutationFailure::Reentrant { attempt },
        }
        .to_string())
    }

    fn receiver_mutation_write_sites(
        binding: &str,
        body: &ReceiverMutationActionBlock,
    ) -> std::collections::HashMap<String, ExpressionSpan> {
        let source = body.source.as_str();
        let bytes = source.as_bytes();
        let mut sites = std::collections::HashMap::new();
        let mut pos = 0usize;
        while pos < bytes.len() {
            if matches!(bytes[pos], b'"' | b'\'') {
                let quote = bytes[pos];
                pos += 1;
                while pos < bytes.len() {
                    if bytes[pos] == b'\\' {
                        pos = (pos + 2).min(bytes.len());
                    } else if bytes[pos] == quote {
                        pos += 1;
                        break;
                    } else {
                        pos += 1;
                    }
                }
                continue;
            }
            if !(bytes[pos].is_ascii_alphabetic() || bytes[pos] == b'_') {
                pos += 1;
                continue;
            }
            let token_start = pos;
            pos += 1;
            while pos < bytes.len() && (bytes[pos].is_ascii_alphanumeric() || bytes[pos] == b'_') {
                pos += 1;
            }
            let token = &source[token_start..pos];
            let mut after = pos;
            while bytes
                .get(after)
                .is_some_and(|byte| byte.is_ascii_whitespace())
            {
                after += 1;
            }
            let span_for = |start: usize, end: usize| ExpressionSpan {
                start: body.source_span.start + source[..start].chars().count(),
                end: body.source_span.start + source[..end].chars().count(),
            };

            if token == binding {
                if source[after..].starts_with("+=") {
                    sites
                        .entry("append".to_string())
                        .or_insert_with(|| span_for(token_start, pos));
                } else if source[after..].starts_with('=') && !source[after..].starts_with("==") {
                    sites
                        .entry("assign".to_string())
                        .or_insert_with(|| span_for(token_start, pos));
                } else if source[after..].starts_with('[') {
                    let statement_end = source[after..]
                        .find([';', '\n', '\r'])
                        .map_or(source.len(), |offset| after + offset);
                    if source[after..statement_end].contains('=') {
                        sites
                            .entry("nested_write".to_string())
                            .or_insert_with(|| span_for(token_start, pos));
                    }
                } else if source[after..].starts_with('.') {
                    let mut method_start = after + 1;
                    while bytes
                        .get(method_start)
                        .is_some_and(|byte| byte.is_ascii_whitespace())
                    {
                        method_start += 1;
                    }
                    let mut method_end = method_start;
                    while bytes
                        .get(method_end)
                        .is_some_and(|byte| byte.is_ascii_alphanumeric() || *byte == b'_')
                    {
                        method_end += 1;
                    }
                    let method = &source[method_start..method_end];
                    let attempt = if method == "map_leaves" && bytes.get(method_end) == Some(&b'!')
                    {
                        Some("map_leaves!")
                    } else if matches!(
                        method,
                        "push_back" | "push_front" | "pop_back" | "pop_front"
                    ) {
                        Some(method)
                    } else {
                        None
                    };
                    if let Some(attempt) = attempt {
                        sites
                            .entry(attempt.to_string())
                            .or_insert_with(|| span_for(token_start, pos));
                    }
                }
            }

            let helper_attempt = match token {
                "set" | "=" => Some("helper:set".to_string()),
                "set_key" | "push" | "split" | "split_each" | "trim_each" | "filter_nonempty"
                | "filter_match" | "lowercase_each" | "uppercase_each" | "uniq" => {
                    Some(format!("helper:{token}"))
                }
                _ => None,
            };
            if let Some(attempt) = helper_attempt
                && bytes.get(after) == Some(&b'(')
                && let Some(close) = Self::matching_runtime_parenthesis(source, after)
            {
                let first_arg = source[after + 1..close]
                    .split(',')
                    .next()
                    .unwrap_or_default()
                    .trim();
                if first_arg == binding {
                    sites
                        .entry(attempt)
                        .or_insert_with(|| span_for(token_start, close + 1));
                }
            }
        }
        sites
    }

    fn matching_runtime_parenthesis(source: &str, open: usize) -> Option<usize> {
        let bytes = source.as_bytes();
        let mut pos = open;
        let mut depth = 0usize;
        while pos < bytes.len() {
            if matches!(bytes[pos], b'"' | b'\'') {
                let quote = bytes[pos];
                pos += 1;
                while pos < bytes.len() {
                    if bytes[pos] == b'\\' {
                        pos = (pos + 2).min(bytes.len());
                    } else if bytes[pos] == quote {
                        break;
                    }
                    pos += 1;
                }
            } else if bytes[pos] == b'(' {
                depth += 1;
            } else if bytes[pos] == b')' {
                depth = depth.checked_sub(1)?;
                if depth == 0 {
                    return Some(pos);
                }
            }
            pos += 1;
        }
        None
    }

    /// Evaluate an expression tree against the runtime context.
    fn eval_expr(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        use linkedspec_core::expr::Expr;
        self.assert_receiver_write_expr(expr, ctx)?;
        match expr {
            Expr::Call { name, args } => {
                if ctx.in_user_function() && Self::is_parser_state_helper(name) {
                    return Err(format!(
                        "parser-state helper '{name}' is not supported in user functions"
                    ));
                }
                if name == "dispatch_span" {
                    return Err(
                        "LINKEDSPEC_PROGRESSIVE_SPAN_DISPATCH_ERROR:progressive_span_binding_required"
                            .to_owned(),
                    );
                }
                validate_eager_helper_arity(name, args, args.len(), ctx, rule_label)?;
                // Branch bodies and default-selection operands evaluate only
                // the prefix required by the selected control helper.
                let is_lazy = matches!(
                    name.as_str(),
                    "if" | "switch"
                        | "while"
                        | "with"
                        | "elseif"
                        | "else"
                        | "case"
                        | "default"
                        | "coalesce"
                        | "coalesce_nonempty"
                );
                if is_lazy {
                    return self.call_helper_lazy(name, args, ctx, rule_label);
                }
                if name == "push"
                    && let Some(value) = self.eval_push_child_call(expr, ctx, rule_label)?
                {
                    return Ok(value);
                }
                if let Some(function) = self.spec.find_function(name) {
                    let keyword_count = args
                        .iter()
                        .filter(|arg| matches!(arg, Arg::Keyword { .. }))
                        .count();
                    if keyword_count > 0 {
                        ctx.capture_portable_diagnostic_failure(
                            "user_function_invocation",
                            "user_function_keyword_arguments_unsupported",
                            "Rust user function invocation failed",
                            Some(rule_label),
                        );
                        return Err(format!(
                            "user function '{}' accepts positional arguments only, got {} keyword argument(s) in rule '{}'",
                            function.name, keyword_count, rule_label
                        ));
                    }
                    if let Some(signature) = &function.signature {
                        if args.len() < signature.min_arity {
                            return Err(format!(
                                "user function '{}' expects at least {} argument(s), got {} in rule '{}'",
                                function.name,
                                signature.min_arity,
                                args.len(),
                                rule_label
                            ));
                        }
                    } else if args.len() != function.arity {
                        return Err(format!(
                            "user function '{}' expects {} argument(s), got {} in rule '{}'",
                            function.name,
                            function.arity,
                            args.len(),
                            rule_label
                        ));
                    }
                    let evaluated: Vec<RuntimeValue> = args
                        .iter()
                        .map(|a| self.eval_expr(a.value(), ctx, rule_label))
                        .collect::<Result<Vec<_>, _>>()?;
                    if let Some(final_name) = function.params.last()
                        && function.parameter_kinds.get(final_name).map(String::as_str)
                            == Some("codeblock")
                    {
                        let final_value = evaluated.last().expect(
                            "typed final-codeblock function arity was validated before evaluation",
                        );
                        self.require_final_codeblock_value(
                            &function.name,
                            final_value,
                            ctx,
                            rule_label,
                        )?;
                    }
                    return self.execute_user_function(function, &evaluated, ctx);
                }
                // Normal eager evaluation for all other helpers
                let evaluated: Vec<RuntimeValue> = args
                    .iter()
                    .map(|a| self.eval_expr(a.value(), ctx, rule_label))
                    .collect::<Result<Vec<_>, _>>()?;
                self.call_helper_with_args(name, args, &evaluated, ctx, rule_label)
            }
            Expr::ProgressiveDispatchSpan {
                target,
                parser_id,
                top_rule,
                span,
            } => ctx.dispatch_bounded_child_parse(target, parser_id, top_rule, span, rule_label),
            Expr::StagedParseJobMarker {
                target,
                text_plan,
                options,
                ..
            } => {
                let marker =
                    ctx.construct_staged_parse_job_marker(rule_label, text_plan, options)?;
                ctx.set_scalar(target, marker.clone());
                Ok(marker)
            }
            Expr::RecognitionCheckpoint => Err(format!(
                "recognition_checkpoint must be assigned to a rule-local token in rule '{rule_label}'"
            )),
            Expr::RecognizeOnce { token, rule } => {
                let completion_base = ctx.begin_recognition_scope(rule_label);
                let payload = match self.execute_rule(rule, 0, ctx) {
                    Ok(payload) => payload,
                    Err(error) => {
                        ctx.cancel_recognition_scope(completion_base);
                        return Err(error);
                    }
                };
                let matched = ctx.finish_recognition_scope(completion_base, rule)?;
                ctx.recognition_attempt(rule_label, token, matched, payload)?;
                Ok(RuntimeValue::Bool(matched))
            }
            Expr::ObserveRecognition { target, rule } => {
                let has_recognition_structure = self
                    .spec
                    .find(rule)
                    .map(|child| {
                        !child.regex_patterns.is_empty() || !child.dependency_refs.is_empty()
                    })
                    .ok_or_else(|| {
                        "LINKEDSPEC_SOURCE_LOCATION_ERROR:source_location_recursive_observation_operand"
                            .to_owned()
                    })?;
                let completion_base = ctx.begin_recursive_observation(rule_label, rule);
                let result = self.execute_rule(rule, 0, ctx);
                let observation = ctx.finish_recursive_observation(
                    completion_base,
                    rule,
                    result.is_ok(),
                    has_recognition_structure,
                )?;
                let RuntimeValue::Hash(entries) = observation else {
                    unreachable!("recursive observation always projects one detached harray");
                };
                ctx.record_rule_local_binding(target);
                ctx.set_hash(target, entries);
                result
            }
            Expr::RecognitionCommit { token } => ctx.recognition_commit(rule_label, token),
            Expr::RecognitionRollback { token } => {
                ctx.recognition_rollback(rule_label, token)?;
                Ok(RuntimeValue::Undef)
            }
            Expr::AssignScalar { name, value } => {
                if matches!(value.as_ref(), Expr::RecognitionCheckpoint) {
                    ctx.recognition_checkpoint(rule_label, name)?;
                    ctx.set_scalar(name, RuntimeValue::Undef);
                    return Ok(RuntimeValue::Undef);
                }
                let evaluated = self.eval_expr(value, ctx, rule_label)?;
                ctx.set_scalar(name, evaluated.clone());
                Ok(evaluated)
            }
            Expr::AssignArrayAppend { name, value } => {
                self.eval_array_append_expression(name, value, ctx, rule_label)
            }
            Expr::AssignHashIndex { name, key, value } => {
                self.eval_hash_index_assignment_expression(name, key, value, ctx, rule_label)
            }
            Expr::AssignNestedAccess {
                base,
                segments,
                value,
                ..
            } => self
                .eval_nested_access_assignment_expression(base, segments, value, ctx, rule_label),
            Expr::ReceiverMutationChain {
                receiver,
                mutation,
                continuation,
                ..
            } => {
                self.eval_receiver_mutation_chain(receiver, mutation, continuation, ctx, rule_label)
            }
            Expr::Variable { name } => Ok(ctx.get_bare_value(name)),
            Expr::IndexedVar { name, index } => {
                let idx_val = self.eval_expr(index, ctx, rule_label)?;
                Ok(Self::array_selector_value(
                    &ctx.get_bare_value(name),
                    &idx_val,
                ))
            }
            Expr::NestedAccess { base, segments } => {
                self.eval_access_value(ctx.get_bare_value(base), segments, ctx, rule_label)
            }
            Expr::ValueAccess { receiver, segments } => {
                let current = self.eval_expr(receiver, ctx, rule_label)?;
                self.eval_access_value(current, segments, ctx, rule_label)
            }
            Expr::ArrayLiteral { items } => {
                let mut values = Vec::new();
                for item in items {
                    let value = self.eval_expr(item, ctx, rule_label)?;
                    if matches!(
                        item,
                        Expr::Call { name, .. }
                            if matches!(name.as_str(), "flat" | "flat_array" | "flat_hash")
                    ) {
                        Self::push_list_context_values(&mut values, &value);
                    } else {
                        values.push(value);
                    }
                }
                Ok(RuntimeValue::Array(values))
            }
            Expr::HashLiteral { entries } => {
                let mut values = Vec::new();
                for entry in entries {
                    let key = self.eval_expr(&entry.key, ctx, rule_label)?.to_str();
                    let value = self.eval_expr(&entry.value, ctx, rule_label)?;
                    values.push((key, value));
                }
                Ok(RuntimeValue::Hash(values))
            }
            Expr::BlockValue { block } => self.eval_block_value(block, ctx, rule_label),
            Expr::ContextualCodeblockCandidate(_) => Err(format!(
                "unnormalized contextual codeblock candidate reached runtime in rule '{rule_label}'"
            )),
            Expr::CodeblockArgument(literal) | Expr::CodeblockLiteral(literal) => {
                Ok(RuntimeValue::Codeblock(
                    linkedspec_core::types::CodeblockValue::new(literal.clone()),
                ))
            }
            Expr::StringLiteral { value } => Ok(RuntimeValue::Scalar(value.clone())),
            Expr::NumberLiteral { value } => Ok(RuntimeValue::Number(*value)),
            Expr::BooleanLiteral { value } => Ok(RuntimeValue::Bool(*value)),
            Expr::RegexLiteral { pattern } => Ok(RuntimeValue::Scalar(pattern.clone())),
            Expr::Undef => Ok(RuntimeValue::Undef),
            Expr::FluentChain { receiver, calls } => {
                // Reject invalid receiver arities before source/operand effects.
                if calls.iter().any(|call| match call.method.as_str() {
                    "first" | "last" | "copy" | "count" | "count_keys" | "length" | "sum"
                    | "avg" | "median" | "range" | "is_empty" | "is_nonempty" | "is_defined"
                    | "is_undefined" | "abs" | "floor" | "ceil" | "round" | "trim"
                    | "lowercase" | "uppercase" | "not" => !call.args.is_empty(),
                    "join_values" | "contains" | "index_of" | "has_key" | "starts_with"
                    | "ends_with" | "contains_substr" | "matches" | "str_eq" | "str_ne"
                    | "str_gt" | "str_ge" | "str_lt" | "str_le" | "eq" | "ne" | "gt" | "ge"
                    | "lt" | "le" | "sub" | "div" | "mod" | "rm_prefix" | "rm_suffix" => {
                        call.args.len() != 1
                    }
                    "clamp" | "replace_substr" => call.args.len() != 2,
                    "substr" => !(1..=2).contains(&call.args.len()),
                    "split_tagged_records" => call.args.len() < 2,
                    "add" | "mul" | "coalesce" | "cat" | "and" | "or" => call.args.is_empty(),
                    _ => false,
                }) {
                    return Ok(RuntimeValue::Undef);
                }
                if let Some(first) = calls.first()
                    && Self::is_statement_only_array_end_mutation_method(&first.method)
                {
                    let Some(current) =
                        self.eval_array_end_mutation_call(receiver, first, ctx, rule_label)?
                    else {
                        return Ok(RuntimeValue::Undef);
                    };
                    return self.eval_selected_receiver_value_chain(
                        current,
                        &calls[1..],
                        false,
                        ctx,
                        rule_label,
                    );
                }
                if calls
                    .iter()
                    .skip(1)
                    .any(|call| Self::is_statement_only_array_end_mutation_method(&call.method))
                {
                    return Ok(RuntimeValue::Undef);
                }
                if calls
                    .iter()
                    .any(Self::is_receiver_trailing_block_surface_call)
                {
                    return self
                        .eval_receiver_with_trailing_block_chain(receiver, calls, ctx, rule_label);
                }
                if matches!(receiver.as_ref(), Expr::Call { name, .. }
                    if matches!(name.as_str(), "and" | "or" | "not"))
                {
                    let current = self.eval_expr(receiver, ctx, rule_label)?;
                    return self
                        .eval_selected_receiver_value_chain(current, calls, true, ctx, rule_label);
                }
                let mut kind_guarded_source = self.is_ordinary_computed_read(receiver)
                    || self.is_explicit_push_result_source(receiver)
                    || Self::is_explicit_set_result_source(receiver)
                    || Self::is_free_default_result_source(receiver)
                    || Self::is_constructor_result_source(receiver)
                    || Self::is_free_string_result_source(receiver)
                    || Self::is_ordinary_string_receiver_prefix(calls)
                    || Self::is_ordinary_numeric_result_chain(receiver, calls)
                    || Self::is_ordinary_lexical_result_chain(receiver, calls)
                    || Self::is_ordinary_definedness_result_chain(receiver, calls)
                    || Self::is_ordinary_emptiness_result_chain(receiver, calls)
                    || Self::is_ordinary_string_predicate_result_chain(receiver, calls)
                    || Self::is_ordinary_contains_result_chain(receiver, calls)
                    || Self::is_ordinary_index_result_chain(receiver, calls)
                    || Self::is_ordinary_has_key_result_chain(receiver, calls)
                    || Self::is_ordinary_length_result_chain(receiver, calls)
                    || Self::is_input_cursor_value_source(receiver)
                    || matches!(receiver.as_ref(), Expr::Call { name, .. } if matches!(name.as_str(), "copy" | "with"));
                let hash_value_chain = self.is_ordinary_hash_value_result_chain(receiver, calls);
                let hash_value_source_prefix = hash_value_chain
                    && !kind_guarded_source
                    && !Self::is_ordinary_count_result_chain(receiver, &[])
                    && !Self::is_ordinary_key_count_result_chain(receiver, &[])
                    && !self.is_ordinary_hash_view_result_chain(receiver, &[])
                    && !self.is_ordinary_hash_value_result_chain(receiver, &[])
                    && calls.first().is_some_and(|first| {
                        Self::is_ordinary_hash_value_result_call(&first.method, &first.args, true)
                    });
                // The first helper keeps its producer policy. Its actual result
                // owns later guards, without reviving an earlier rejected value.
                kind_guarded_source |= hash_value_chain;
                let hash_view_chain = self.is_ordinary_hash_view_result_chain(receiver, calls);
                let hash_view_source_prefix = hash_view_chain
                    && !kind_guarded_source
                    && !Self::is_ordinary_count_result_chain(receiver, &[])
                    && !Self::is_ordinary_key_count_result_chain(receiver, &[])
                    && !self.is_ordinary_hash_view_result_chain(receiver, &[])
                    && calls.first().is_some_and(|first| {
                        matches!(first.method.as_str(), "sorted_keys" | "sorted_values")
                            && first.args.is_empty()
                    });
                // Initial views retain their source fallback; the produced Array
                // owns every continuation before later size-source permissions.
                kind_guarded_source |= hash_view_chain;
                let key_count_chain = Self::is_ordinary_key_count_result_chain(receiver, calls);
                let key_count_source_prefix = key_count_chain
                    && !kind_guarded_source
                    && !Self::is_ordinary_count_result_chain(receiver, &[])
                    && !Self::is_ordinary_key_count_result_chain(receiver, &[])
                    && calls
                        .first()
                        .is_some_and(|first| first.method == "count_keys" && first.args.is_empty());
                // Produced key counts own their Number before Count source fallback.
                kind_guarded_source |= key_count_chain;
                let count_chain = Self::is_ordinary_count_result_chain(receiver, calls);
                if kind_guarded_source || count_chain {
                    let mut current = self.eval_expr(receiver, ctx, rule_label)?;
                    let mut remaining = calls.as_slice();
                    // Initial size sources retain their existing zero fallback.
                    // Already produced/selected/copied results keep their kind guard.
                    if hash_value_source_prefix
                        || hash_view_source_prefix
                        || key_count_source_prefix
                        || (count_chain
                            && !kind_guarded_source
                            && !Self::is_ordinary_count_result_chain(receiver, &[])
                            && calls.first().is_some_and(|first| {
                                first.method == "count" && first.args.is_empty()
                            }))
                    {
                        current = self.eval_receiver_dynamic_value_chain_call(
                            current,
                            &calls[0],
                            calls.len() == 1,
                            ctx,
                            rule_label,
                        )?;
                        remaining = &calls[1..];
                    }
                    // A leading presence receiver accepts null and evaluates its key.
                    // Its numeric result then enters the persistent kind guard.
                    if Self::is_ordinary_has_key_result_chain(receiver, calls)
                        && calls
                            .first()
                            .is_some_and(|first| first.method == "has_key" && first.args.len() == 1)
                    {
                        if !matches!(current, RuntimeValue::Hash(_) | RuntimeValue::Undef) {
                            return Ok(RuntimeValue::Undef);
                        }
                        current = self.eval_receiver_dynamic_value_chain_call(
                            current,
                            &calls[0],
                            calls.len() == 1,
                            ctx,
                            rule_label,
                        )?;
                        remaining = &calls[1..];
                    }
                    return self.eval_kind_guarded_receiver_value_chain(
                        current, remaining, ctx, rule_label,
                    );
                }
                if calls
                    .first()
                    .is_some_and(|call| Self::is_generic_receiver_value_method(&call.method))
                {
                    let current = self.eval_expr(receiver, ctx, rule_label)?;
                    return self.eval_selected_receiver_value_chain(
                        current, calls, false, ctx, rule_label,
                    );
                }
                if calls
                    .first()
                    .is_some_and(|call| Self::is_hash_receiver_value_chain_method(&call.method))
                {
                    return self.eval_hash_receiver_value_chain(receiver, calls, ctx, rule_label);
                }
                if calls
                    .first()
                    .is_some_and(|call| Self::is_array_receiver_value_chain_method(&call.method))
                {
                    return self.eval_array_receiver_value_chain(receiver, calls, ctx, rule_label);
                }
                if calls
                    .first()
                    .is_some_and(|call| Self::is_string_receiver_value_chain_method(&call.method))
                {
                    return self.eval_string_receiver_value_chain(receiver, calls, ctx, rule_label);
                }
                if calls
                    .first()
                    .is_some_and(|call| Self::is_number_receiver_value_chain_method(&call.method))
                {
                    return self.eval_number_receiver_value_chain(receiver, calls, ctx, rule_label);
                }
                self.eval_expr(receiver, ctx, rule_label)?;
                for call in calls {
                    validate_eager_helper_arity(
                        &call.method,
                        &call.args,
                        call.args.len(),
                        ctx,
                        rule_label,
                    )?;
                    let evaluated: Vec<RuntimeValue> = call
                        .args
                        .iter()
                        .map(|a| self.eval_expr(a.value(), ctx, rule_label))
                        .collect::<Result<Vec<_>, _>>()?;
                    self.call_helper_with_args(
                        &call.method,
                        &call.args,
                        &evaluated,
                        ctx,
                        rule_label,
                    )?;
                }
                Ok(RuntimeValue::Undef)
            }
        }
    }

    fn execute_user_function(
        &self,
        function: &CompiledUserFunction,
        args: &[RuntimeValue],
        ctx: &mut RuntimeContext,
    ) -> Result<RuntimeValue, String> {
        if !ctx.enter_user_function(&function.name) {
            return Err(format!(
                "recursive user function call '{}' is not supported",
                function.name
            ));
        }

        let caller_stores = ctx.take_variable_stores();
        for (param, value) in function.params.iter().zip(args.iter().cloned()) {
            ctx.set_scalar(param, value.clone());
            match value {
                RuntimeValue::Array(values) => ctx.set_array(param, values),
                RuntimeValue::Hash(values) => ctx.set_hash(param, values),
                _ => {}
            }
        }
        if let Some(signature) = &function.signature {
            let values = args[signature.min_arity..].to_vec();
            let rest = RuntimeValue::Array(values.clone());
            let rest_param = signature
                .rest_param
                .as_deref()
                .expect("variadic user-function signature must retain its rest parameter");
            ctx.set_scalar(rest_param, rest);
            ctx.set_array(rest_param, values);
        }

        let function_label = format!("function '{}'", function.name);
        ctx.suspend_rule_declaration_tracking();
        let result = self.eval_block_value(&function.body, ctx, &function_label);
        ctx.resume_rule_declaration_tracking();
        ctx.restore_variable_stores(caller_stores);
        ctx.exit_user_function(&function.name);
        result.map_err(|err| format!("user function '{}': {}", function.name, err))
    }

    fn require_final_codeblock_value(
        &self,
        callable_name: &str,
        value: &RuntimeValue,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<CodeblockValue, String> {
        let RuntimeValue::Codeblock(codeblock) = value else {
            let value_kind = RuntimeContext::binding_value_kind(value);
            ctx.capture_callable_codeblock_failure(
                rule_label,
                CallableCodeblockFailure::FinalArgumentNotCodeblock {
                    callable_name: callable_name.to_string(),
                    value_kind,
                },
            );
            return Err(format!(
                "final_argument_not_codeblock callable_name={callable_name:?} value_kind={value_kind:?} rule_label={rule_label:?}"
            ));
        };
        Ok(codeblock.clone())
    }

    fn execute_bound_codeblock_call(
        &self,
        name: &str,
        raw_args: &[Arg],
        args: &[RuntimeValue],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Option<Result<RuntimeValue, String>> {
        if !ctx.has_bare_binding(name) {
            return None;
        }
        let value = ctx.get_bare_value(name);
        let RuntimeValue::Codeblock(codeblock) = value else {
            let value_kind = RuntimeContext::binding_value_kind(&value);
            ctx.capture_callable_codeblock_failure(
                rule_label,
                CallableCodeblockFailure::ValueNotCallable {
                    callable_name: name.to_string(),
                    value_kind,
                },
            );
            return Some(Err(format!(
                "value_not_callable callable_name={name:?} value_kind={value_kind:?} rule_label={rule_label:?}"
            )));
        };

        let keyword_count = raw_args
            .iter()
            .filter(|arg| matches!(arg, Arg::Keyword { .. }))
            .count();
        if keyword_count > 0 {
            ctx.capture_callable_codeblock_failure(
                rule_label,
                CallableCodeblockFailure::KeywordArguments {
                    callable_name: name.to_string(),
                    got: keyword_count,
                },
            );
            return Some(Err(format!(
                "codeblock_keyword_arguments_unsupported callable_name={name:?} expected={:?} got={keyword_count} rule_label={rule_label:?}",
                "positional arguments"
            )));
        }

        Some(self.execute_codeblock_value(name, Some(name), &codeblock, args, ctx, rule_label))
    }

    fn execute_codeblock_value(
        &self,
        name: &str,
        binding_name: Option<&str>,
        codeblock: &CodeblockValue,
        args: &[RuntimeValue],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let literal = codeblock.literal();
        let signature = &literal.signature;
        let arity_matches = args.len() >= signature.min_arity
            && signature
                .max_arity
                .is_none_or(|maximum| args.len() <= maximum);
        if !arity_matches {
            let expected = match signature.max_arity {
                Some(maximum) if maximum == signature.min_arity => {
                    format!("exactly {}", signature.min_arity)
                }
                _ => format!("at least {}", signature.min_arity),
            };
            ctx.capture_callable_codeblock_failure(
                rule_label,
                CallableCodeblockFailure::Arity {
                    callable_name: name.to_string(),
                    expected: expected.clone(),
                    got: args.len(),
                },
            );
            return Err(format!(
                "codeblock_arity_mismatch callable_name={name:?} expected={expected:?} got={} rule_label={rule_label:?}",
                args.len()
            ));
        }

        if let Err((identity, cycle)) = ctx.enter_codeblock(name, binding_name, codeblock) {
            ctx.capture_callable_codeblock_failure(
                rule_label,
                CallableCodeblockFailure::Recursion {
                    callable_name: identity.clone(),
                    cycle: cycle.clone(),
                },
            );
            return Err(format!(
                "codeblock_recursion_unsupported callable_name={identity:?} cycle={cycle:?} rule_label={rule_label:?}"
            ));
        }

        let mut bindings = Vec::with_capacity(
            signature.positional_params.len() + usize::from(signature.rest_param.is_some()),
        );
        for (param, value) in signature.positional_params.iter().zip(args.iter()) {
            bindings.push(ctx.enter_scoped_scalar_binding(param, value.clone()));
        }
        if let Some(rest_param) = signature.rest_param.as_deref() {
            let rest = RuntimeValue::Array(args[signature.min_arity..].to_vec());
            bindings.push(ctx.enter_scoped_scalar_binding(rest_param, rest));
        }

        let body = linkedspec_core::expr::CodeBlock {
            statements: literal.body_ast.statements.clone(),
        };
        // Callback identity belongs in diagnostics; parser state uses the caller's rule.
        let result = self.eval_block_value(&body, ctx, rule_label);
        for binding in bindings.into_iter().rev() {
            ctx.exit_scoped_variable_binding(binding);
        }
        ctx.exit_codeblock();
        result.map_err(|error| format!("codeblock '{name}': {error}"))
    }

    fn is_statement_only_array_end_mutation_method(method: &str) -> bool {
        matches!(
            method,
            "push_back" | "push_front" | "pop_back" | "pop_front"
        )
    }

    fn is_array_receiver_value_chain_method(method: &str) -> bool {
        matches!(
            method,
            "copy"
                | "sorted"
                | "reversed"
                | "take"
                | "take_last"
                | "drop_front"
                | "drop_back"
                | "slice"
                | "concat_arrays"
                | "split_each"
                | "trim_each"
                | "filter_nonempty"
                | "lowercase_each"
                | "uppercase_each"
                | "uniq"
                | "filter_match"
                | "count"
                | "first"
                | "last"
                | "contains"
                | "index_of"
                | "is_empty"
                | "is_nonempty"
                | "join_values"
                | "sum"
                | "avg"
                | "median"
                | "range"
                | "min"
                | "max"
        )
    }

    fn is_array_receiver_array_returning_method(method: &str) -> bool {
        matches!(
            method,
            "copy"
                | "sorted"
                | "reversed"
                | "take"
                | "take_last"
                | "drop_front"
                | "drop_back"
                | "slice"
                | "concat_arrays"
                | "split_each"
                | "trim_each"
                | "filter_nonempty"
                | "lowercase_each"
                | "uppercase_each"
                | "uniq"
                | "filter_match"
        )
    }

    fn is_hash_receiver_value_chain_method(method: &str) -> bool {
        Self::is_hash_receiver_hash_returning_method(method)
            || Self::is_hash_receiver_array_returning_method(method)
            || Self::is_hash_receiver_terminal_method(method)
    }

    fn is_hash_receiver_hash_returning_method(method: &str) -> bool {
        matches!(
            method,
            "copy"
                | "merge_hash"
                | "set_key"
                | "rename_key"
                | "drop_keys"
                | "pick_keys"
                | "flat_hash"
                | "walk_leaves"
                | "map_leaves"
        )
    }

    fn is_hash_receiver_array_returning_method(method: &str) -> bool {
        matches!(method, "sorted_keys" | "sorted_values")
    }

    fn is_hash_receiver_terminal_method(method: &str) -> bool {
        matches!(method, "count_keys" | "has_key" | "reduce_leaves")
    }

    fn is_string_receiver_value_chain_method(method: &str) -> bool {
        Self::is_string_receiver_string_returning_method(method)
            || Self::is_string_receiver_array_returning_method(method)
            || Self::is_string_receiver_terminal_method(method)
    }

    fn is_string_receiver_string_returning_method(method: &str) -> bool {
        matches!(
            method,
            "trim"
                | "lowercase"
                | "uppercase"
                | "replace_substr"
                | "rm_prefix"
                | "rm_suffix"
                | "substr"
                | "cat"
                | "coalesce"
                | "coalesce_nonempty"
        )
    }

    fn is_string_receiver_array_returning_method(method: &str) -> bool {
        matches!(method, "split" | "split_tagged_records")
    }

    fn is_string_receiver_terminal_method(method: &str) -> bool {
        matches!(
            method,
            "length"
                | "starts_with"
                | "ends_with"
                | "contains_substr"
                | "matches"
                | "str_eq"
                | "str_ne"
                | "str_gt"
                | "str_ge"
                | "str_lt"
                | "str_le"
        )
    }

    fn number_receiver_helper_name(method: &str) -> Option<&'static str> {
        match method {
            "abs" => Some("num_abs"),
            "floor" => Some("num_floor"),
            "ceil" => Some("num_ceil"),
            "round" => Some("num_round"),
            "add" => Some("num_add"),
            "sub" => Some("num_sub"),
            "mul" => Some("num_mul"),
            "div" => Some("num_div"),
            "mod" => Some("num_mod"),
            "min" => Some("num_min"),
            "max" => Some("num_max"),
            "clamp" => Some("num_clamp"),
            "eq" => Some("num_eq"),
            "ne" => Some("num_ne"),
            "gt" => Some("num_gt"),
            "ge" => Some("num_ge"),
            "lt" => Some("num_lt"),
            "le" => Some("num_le"),
            _ => None,
        }
    }

    fn numeric_word_helper_name(method: &str) -> Option<&'static str> {
        match method {
            "+" => Some("num_add"),
            "-" => Some("num_sub"),
            "*" => Some("num_mul"),
            "/" => Some("num_div"),
            "%" => Some("num_mod"),
            "==" => Some("num_eq"),
            "!=" => Some("num_ne"),
            ">" => Some("num_gt"),
            ">=" => Some("num_ge"),
            "<" => Some("num_lt"),
            "<=" => Some("num_le"),
            "abs" => Some("num_abs"),
            "floor" => Some("num_floor"),
            "ceil" => Some("num_ceil"),
            "round" => Some("num_round"),
            "sum" => Some("num_sum"),
            "avg" => Some("num_avg"),
            "median" => Some("num_median"),
            "range" => Some("num_range"),
            "add" => Some("num_add"),
            "sub" => Some("num_sub"),
            "mul" => Some("num_mul"),
            "div" => Some("num_div"),
            "mod" => Some("num_mod"),
            "clamp" => Some("num_clamp"),
            "min" => Some("num_min"),
            "max" => Some("num_max"),
            "eq" => Some("num_eq"),
            "ne" => Some("num_ne"),
            "gt" => Some("num_gt"),
            "ge" => Some("num_ge"),
            "lt" => Some("num_lt"),
            "le" => Some("num_le"),
            _ => None,
        }
    }

    // Match existing parser-state helper roles, not arbitrary name prefixes.
    // Arguments are still caller expressions until execute_user_function enters
    // its local scope; explicit reader values therefore remain valid arguments.
    fn is_parser_state_helper(name: &str) -> bool {
        matches!(
            name,
            "call" | "entry_slot" | "gap_span" | "gap_text" | "gap_kind"
        ) || Self::is_mark_capture_helper(name)
            || matches!(
                name,
                "entry_col"
                    | "entry_end_col"
                    | "entry_end_line"
                    | "entry_end_pos"
                    | "entry_group"
                    | "entry_groups"
                    | "entry_has"
                    | "entry_len"
                    | "entry_line"
                    | "entry_map"
                    | "entry_named"
                    | "entry_named_map"
                    | "entry_start_col"
                    | "entry_start_line"
                    | "entry_start_pos"
                    | "entry_text"
                    | "match_col"
                    | "match_end_col"
                    | "match_end_line"
                    | "match_end_pos"
                    | "match_group"
                    | "match_groups"
                    | "match_has"
                    | "match_len"
                    | "match_line"
                    | "match_map"
                    | "match_named"
                    | "match_named_map"
                    | "match_start_col"
                    | "match_start_line"
                    | "match_start_pos"
                    | "match_text"
                    | "input_text"
                    | "input_len"
                    | "input_end_pos"
                    | "input_end_line"
                    | "input_end_col"
                    | "input_slice"
                    | "cursor_pos"
                    | "cursor_line"
                    | "cursor_col"
                    | "cursor_rest"
                    | "cursor_rest_len"
                    | "save_cursor"
                    | "restore_cursor"
                    | "rewind_entry_start"
                    | "rewind_match_start"
            )
    }

    fn is_mark_capture_helper(name: &str) -> bool {
        matches!(
            name,
            "start_capture_slice"
                | "capture_slice_here"
                | "start_capture_slice_from"
                | "capture_slice"
                | "capture_from_rule_start"
                | "capture_slice_len"
                | "capture_slice_length"
                | "capture_len_from_rule_start"
                | "capture_slice_line"
                | "capture_slice_pos"
                | "capture_slice_col"
                | "capture_slice_until_cursor"
                | "capture_slice_until_cursor_len"
                | "capture_until_boundary"
                | "capture_take_until_cursor"
                | "capture_take_until_cursor_len"
                | "capture_take"
                | "capture_take_len"
                | "capture_rest"
                | "capture_rest_len"
                | "capture_rest_length"
                | "capture_take_rest"
                | "capture_take_rest_len"
                | "mark_here"
                | "mark_pos"
                | "mark_exists"
                | "mark_input_start"
                | "mark_input_end"
                | "mark_entry_start"
                | "mark_entry_end"
                | "mark_match_start"
                | "mark_match_end"
                | "mark_copy"
                | "mark_capture_slice"
                | "mark_line"
                | "mark_col"
                | "clear_mark"
                | "capture_from"
                | "capture_len_from"
                | "capture_until_cursor_from"
                | "capture_until_cursor_len_from"
                | "capture_take_until_cursor_from"
                | "capture_take_until_cursor_len_from"
                | "capture_take_len_from"
                | "capture_rest_from"
                | "capture_rest_len_from"
                | "capture_take_rest_from"
                | "capture_take_rest_len_from"
                | "capture_between"
                | "capture_len_between"
                | "capture_take_between"
                | "capture_take_between_len"
        )
    }

    fn is_number_receiver_value_chain_method(method: &str) -> bool {
        Self::is_number_receiver_number_returning_method(method)
            || Self::is_number_receiver_comparison_method(method)
    }

    fn is_number_receiver_number_returning_method(method: &str) -> bool {
        matches!(
            method,
            "abs"
                | "floor"
                | "ceil"
                | "round"
                | "add"
                | "sub"
                | "mul"
                | "div"
                | "mod"
                | "min"
                | "max"
                | "clamp"
        )
    }

    fn is_number_receiver_comparison_method(method: &str) -> bool {
        matches!(method, "eq" | "ne" | "gt" | "ge" | "lt" | "le")
    }

    fn is_receiver_with_trailing_block_call(call: &linkedspec_core::expr::FluentCall) -> bool {
        call.method == "with" && call.args.len() == 1
    }

    fn is_tree_traversal_receiver_method(method: &str) -> bool {
        matches!(method, "walk_leaves" | "map_leaves" | "reduce_leaves")
    }

    fn is_receiver_trailing_block_surface_call(call: &linkedspec_core::expr::FluentCall) -> bool {
        Self::is_receiver_with_trailing_block_call(call)
            || Self::is_tree_traversal_receiver_method(&call.method)
    }

    fn eval_receiver_with_trailing_block_chain(
        &self,
        receiver: &linkedspec_core::expr::Expr,
        calls: &[linkedspec_core::expr::FluentCall],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let mut current = self.eval_expr(receiver, ctx, rule_label)?;
        let mut reduced_value = false;
        let mut logical_prefix = false;
        let mut kind_guarded_value = self.is_ordinary_computed_read(receiver)
            || self.is_explicit_push_result_source(receiver)
            || Self::is_explicit_set_result_source(receiver)
            || Self::is_free_default_result_source(receiver)
            || Self::is_constructor_result_source(receiver)
            || Self::is_free_string_result_source(receiver)
            || Self::is_ordinary_string_receiver_prefix(calls)
            || Self::is_ordinary_numeric_result_chain(receiver, calls)
            || Self::is_ordinary_lexical_result_chain(receiver, calls)
            || Self::is_ordinary_definedness_result_chain(receiver, calls)
            || Self::is_ordinary_emptiness_result_chain(receiver, calls)
            || Self::is_ordinary_string_predicate_result_chain(receiver, calls)
            || Self::is_ordinary_contains_result_chain(receiver, calls)
            || Self::is_ordinary_index_result_chain(receiver, calls)
            || Self::is_ordinary_has_key_result_chain(receiver, calls)
            || Self::is_ordinary_length_result_chain(receiver, calls)
            || Self::is_ordinary_logical_result_chain(receiver, calls)
            || Self::is_input_cursor_value_source(receiver)
            || matches!(receiver, Expr::Call { name, .. } if name == "copy");
        let hash_value_chain = self.is_ordinary_hash_value_result_chain(receiver, calls);
        let hash_value_source_prefix = hash_value_chain
            && !kind_guarded_value
            && !Self::is_ordinary_count_result_chain(receiver, &[])
            && !Self::is_ordinary_key_count_result_chain(receiver, &[])
            && !self.is_ordinary_hash_view_result_chain(receiver, &[])
            && !self.is_ordinary_hash_value_result_chain(receiver, &[])
            && calls.first().is_some_and(|first| {
                Self::is_ordinary_hash_value_result_call(&first.method, &first.args, true)
            });
        kind_guarded_value |= hash_value_chain;
        let hash_view_chain = self.is_ordinary_hash_view_result_chain(receiver, calls);
        let hash_view_source_prefix = hash_view_chain
            && !kind_guarded_value
            && !Self::is_ordinary_count_result_chain(receiver, &[])
            && !Self::is_ordinary_key_count_result_chain(receiver, &[])
            && !self.is_ordinary_hash_view_result_chain(receiver, &[])
            && calls.first().is_some_and(|first| {
                matches!(first.method.as_str(), "sorted_keys" | "sorted_values")
                    && first.args.is_empty()
            });
        kind_guarded_value |= hash_view_chain;
        let key_count_chain = Self::is_ordinary_key_count_result_chain(receiver, calls);
        let key_count_source_prefix = key_count_chain
            && !kind_guarded_value
            && !Self::is_ordinary_count_result_chain(receiver, &[])
            && !Self::is_ordinary_key_count_result_chain(receiver, &[])
            && calls
                .first()
                .is_some_and(|first| first.method == "count_keys" && first.args.is_empty());
        kind_guarded_value |= key_count_chain;
        let count_chain = Self::is_ordinary_count_result_chain(receiver, calls);
        let count_source_prefix = count_chain
            && !kind_guarded_value
            && !Self::is_ordinary_count_result_chain(receiver, &[])
            && calls
                .first()
                .is_some_and(|first| first.method == "count" && first.args.is_empty());
        kind_guarded_value |= count_chain;

        for (index, call) in calls.iter().enumerate() {
            if Self::is_receiver_with_trailing_block_call(call)
                || Self::is_tree_traversal_receiver_method(&call.method)
            {
                current =
                    self.eval_receiver_with_trailing_block_call(current, call, ctx, rule_label)?;
                reduced_value |= call.method == "reduce_leaves";
                // An immediate with yields a new value, independent of its source kind.
                kind_guarded_value |= call.method == "with";
                continue;
            }

            // Guard actual selected/copied kinds and scalar producers before
            // incompatible container operands, preserving the completed prefix.
            if (reduced_value || logical_prefix || kind_guarded_value)
                && !(index == 0
                    && (count_source_prefix
                        || key_count_source_prefix
                        || hash_view_source_prefix
                        || hash_value_source_prefix))
                && call.method != "copy"
                && !Self::is_generic_receiver_value_method(&call.method)
            {
                let method = call.method.as_str();
                let array_only = Self::is_array_receiver_value_chain_method(method)
                    && !Self::is_string_receiver_value_chain_method(method)
                    && !(matches!(method, "min" | "max") && !call.args.is_empty());
                let hash_only = Self::is_hash_receiver_value_chain_method(method);
                // A valid null source keeps has_key's eager key evaluation.
                // Earlier incompatible consumers have already returned.
                let nullable_presence = matches!(current, RuntimeValue::Undef)
                    && Self::is_ordinary_has_key_result_chain(
                        &Expr::Undef,
                        std::slice::from_ref(call),
                    );
                // Copy preserves legitimate null; earlier rejection has
                // already returned before this canonical membership consumer.
                let nullable_membership = matches!(current, RuntimeValue::Undef)
                    && Self::is_ordinary_contains_result_chain(
                        &Expr::Undef,
                        std::slice::from_ref(call),
                    );
                // Copy preserves legitimate null; earlier rejection has
                // already returned before this canonical index consumer.
                let nullable_index = matches!(current, RuntimeValue::Undef)
                    && Self::is_ordinary_index_result_chain(
                        &Expr::Undef,
                        std::slice::from_ref(call),
                    );
                if (array_only
                    && !matches!(current, RuntimeValue::Array(_))
                    && !nullable_membership
                    && !nullable_index)
                    || (hash_only
                        && !matches!(current, RuntimeValue::Hash(_))
                        && !nullable_presence)
                {
                    return Ok(RuntimeValue::Undef);
                }
            }

            current = self.eval_receiver_dynamic_value_chain_call(
                current,
                call,
                index + 1 == calls.len(),
                ctx,
                rule_label,
            )?;
            logical_prefix |= matches!(call.method.as_str(), "and" | "or" | "not");
            kind_guarded_value |= matches!(
                call.method.as_str(),
                "copy" | "coalesce" | "coalesce_nonempty"
            );
        }

        Ok(current)
    }

    fn eval_receiver_with_trailing_block_call(
        &self,
        current: RuntimeValue,
        call: &linkedspec_core::expr::FluentCall,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        if Self::is_tree_traversal_receiver_method(&call.method) {
            return self.eval_tree_receiver_trailing_block_call(current, call, ctx, rule_label);
        }

        if call.args.len() != 1 {
            return Err(format!(
                "LINKEDSPEC_UNSUPPORTED_ACTIONIR_HELPER:with: receiver `.with() {{ ... }}` expects no parenthesized arguments in rule '{rule_label}'"
            ));
        }
        let callback_expr = call.args[0].value();
        let pass_receiver = !matches!(
            callback_expr,
            linkedspec_core::expr::Expr::CodeblockArgument(_)
        );
        // Final arguments observe caller bindings before scoped value shadows them.
        let callback = self.eval_expr(callback_expr, ctx, rule_label)?;
        let callback = self.require_final_codeblock_value("with", &callback, ctx, rule_label)?;
        let binding = ctx.enter_scoped_scalar_binding("value", current.clone());
        let args = if pass_receiver {
            vec![current]
        } else {
            Vec::new()
        };
        let result = self.execute_codeblock_value(
            "with",
            bare_variable_target_arg(&call.args[0]),
            &callback,
            &args,
            ctx,
            rule_label,
        );
        ctx.exit_scoped_variable_binding(binding);
        result
    }

    fn eval_tree_receiver_trailing_block_call(
        &self,
        current: RuntimeValue,
        call: &linkedspec_core::expr::FluentCall,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let method = call.method.as_str();
        let Some(block_arg) = call.args.last() else {
            return Err(Self::tree_receiver_malformed_message(method, rule_label));
        };

        match method {
            "walk_leaves" | "map_leaves" if call.args.len() != 1 => {
                return Err(Self::tree_receiver_malformed_message(method, rule_label));
            }
            "reduce_leaves" if call.args.len() != 2 => {
                return Err(Self::tree_receiver_malformed_message(method, rule_label));
            }
            "walk_leaves" | "map_leaves" | "reduce_leaves" => {}
            _ => return Ok(RuntimeValue::Undef),
        }

        if method == "reduce_leaves"
            && !matches!(current, RuntimeValue::Array(_) | RuntimeValue::Hash(_))
        {
            return Ok(RuntimeValue::Undef);
        }

        let initial_acc = if method == "reduce_leaves" {
            Some(self.eval_expr(call.args[0].value(), ctx, rule_label)?)
        } else {
            None
        };

        let pass_leaf_value = !matches!(
            block_arg.value(),
            linkedspec_core::expr::Expr::CodeblockArgument(_)
        );
        let callback = self.eval_expr(block_arg.value(), ctx, rule_label)?;
        let callback = TreeCodeblockCallback {
            name: method.to_string(),
            binding_name: bare_variable_target_arg(block_arg).map(str::to_string),
            value: self.require_final_codeblock_value(method, &callback, ctx, rule_label)?,
            pass_leaf_value,
        };

        match current {
            RuntimeValue::Hash(entries) => match method {
                "walk_leaves" => {
                    let mut path = Vec::new();
                    self.walk_hash_tree_entries(&entries, &mut path, &callback, ctx, rule_label)?;
                    Ok(RuntimeValue::Hash(entries))
                }
                "map_leaves" => {
                    let mut path = Vec::new();
                    let mapped = self
                        .map_hash_tree_entries(&entries, &mut path, &callback, ctx, rule_label)?;
                    Ok(RuntimeValue::Hash(mapped))
                }
                "reduce_leaves" => {
                    let mut acc = initial_acc
                        .clone()
                        .expect("reduce_leaves arity was checked before evaluation");
                    let mut path = Vec::new();
                    self.reduce_hash_tree_entries(
                        &entries, &mut path, &callback, &mut acc, ctx, rule_label,
                    )?;
                    Ok(acc)
                }
                _ => Ok(RuntimeValue::Undef),
            },
            RuntimeValue::Array(items) => match method {
                "walk_leaves" => {
                    let mut path = Vec::new();
                    self.walk_array_tree_items(&items, &mut path, &callback, ctx, rule_label)?;
                    Ok(RuntimeValue::Array(items))
                }
                "map_leaves" => {
                    let mut path = Vec::new();
                    let mapped =
                        self.map_array_tree_items(&items, &mut path, &callback, ctx, rule_label)?;
                    Ok(RuntimeValue::Array(mapped))
                }
                "reduce_leaves" => {
                    let mut acc =
                        initial_acc.expect("reduce_leaves arity was checked before evaluation");
                    let mut path = Vec::new();
                    self.reduce_array_tree_items(
                        &items, &mut path, &callback, &mut acc, ctx, rule_label,
                    )?;
                    Ok(acc)
                }
                _ => Ok(RuntimeValue::Undef),
            },
            _ => Ok(RuntimeValue::Undef),
        }
    }

    fn tree_receiver_malformed_message(method: &str, rule_label: &str) -> String {
        let signature = match method {
            "reduce_leaves" => ".reduce_leaves(initial) { ... }",
            "walk_leaves" => ".walk_leaves() { ... }",
            "map_leaves" => ".map_leaves() { ... }",
            _ => ".<tree-traversal-method>() { ... }",
        };
        format!(
            "LINKEDSPEC_UNSUPPORTED_ACTIONIR_HELPER:{method}: receiver `{signature}` requires the accepted tree traversal trailing-block arity in rule '{rule_label}'"
        )
    }

    fn eval_receiver_mutation_chain(
        &self,
        receiver: &ReceiverMutationBindingReference,
        mutation: &ReceiverMutationCall,
        continuation: &[ReceiverMutationContinuationCall],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        if !ctx.has_bare_binding(&receiver.name) {
            return Err(ReceiverMutationError {
                binding: receiver.name.clone(),
                source_span: receiver.source_span,
                failure: ReceiverMutationFailure::Missing,
            }
            .to_string());
        }

        let original_kind = ctx.bare_kind(&receiver.name);
        let snapshot = ctx.get_bare_value(&receiver.name);
        if !matches!(snapshot, RuntimeValue::Hash(_) | RuntimeValue::Array(_)) {
            return Err(ReceiverMutationError {
                binding: receiver.name.clone(),
                source_span: receiver.source_span,
                failure: ReceiverMutationFailure::KindMismatch {
                    actual_kind: Self::receiver_mutation_value_kind(&snapshot),
                },
            }
            .to_string());
        }

        let write_sites =
            Self::receiver_mutation_write_sites(&receiver.name, &mutation.callback.body);
        let Some(identity) = ctx.activate_receiver_mutation(&receiver.name, write_sites) else {
            return Err(ReceiverMutationError {
                binding: receiver.name.clone(),
                source_span: receiver.source_span,
                failure: ReceiverMutationFailure::Reentrant {
                    attempt: "map_leaves!".to_string(),
                },
            }
            .to_string());
        };

        let rebuilt = match snapshot {
            RuntimeValue::Hash(entries) => {
                let mut path = Vec::new();
                self.map_receiver_mutation_hash_entries(
                    &entries,
                    &mut path,
                    &mutation.callback.body,
                    ctx,
                    rule_label,
                )
                .map(RuntimeValue::Hash)
            }
            RuntimeValue::Array(items) => {
                let mut path = Vec::new();
                self.map_receiver_mutation_array_items(
                    &items,
                    &mut path,
                    &mutation.callback.body,
                    ctx,
                    rule_label,
                )
                .map(RuntimeValue::Array)
            }
            _ => unreachable!("receiver kind was checked before guard activation"),
        };

        let rebuilt = match rebuilt {
            Ok(value) => value,
            Err(error) => {
                ctx.deactivate_receiver_mutation(identity);
                return Err(error);
            }
        };
        match (original_kind, &rebuilt) {
            (Some(RuntimeVarKind::Array), RuntimeValue::Array(values)) => {
                ctx.set_array(&receiver.name, values.clone());
            }
            (Some(RuntimeVarKind::Hash), RuntimeValue::Hash(values)) => {
                ctx.set_hash(&receiver.name, values.clone());
            }
            _ => ctx.set_scalar(&receiver.name, rebuilt.clone()),
        }
        ctx.deactivate_receiver_mutation(identity);

        let calls = continuation
            .iter()
            .map(|call| FluentCall {
                method: call.method.clone(),
                args: call.args.clone(),
            })
            .collect::<Vec<_>>();
        let mut current = rebuilt.clone();
        for (index, call) in calls.iter().enumerate() {
            if Self::is_receiver_trailing_block_surface_call(call) {
                current =
                    self.eval_receiver_with_trailing_block_call(current, call, ctx, rule_label)?;
            } else {
                current = self.eval_receiver_dynamic_value_chain_call(
                    current,
                    call,
                    index + 1 == calls.len(),
                    ctx,
                    rule_label,
                )?;
            }
        }
        Ok(current)
    }

    fn map_receiver_mutation_hash_entries(
        &self,
        entries: &[(String, RuntimeValue)],
        path: &mut Vec<String>,
        body: &ReceiverMutationActionBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Vec<(String, RuntimeValue)>, String> {
        let mut mapped = Vec::new();
        for (key, value) in Self::sorted_hash_tree_entries(entries) {
            path.push(key.clone());
            let next_value = match value {
                RuntimeValue::Hash(children) => self
                    .map_receiver_mutation_hash_entries(&children, path, body, ctx, rule_label)
                    .map(RuntimeValue::Hash),
                leaf => {
                    self.eval_receiver_mutation_hash_leaf(leaf, &key, path, body, ctx, rule_label)
                }
            };
            path.pop();
            mapped.push((key, next_value?));
        }
        Ok(mapped)
    }

    fn map_receiver_mutation_array_items(
        &self,
        items: &[RuntimeValue],
        path: &mut Vec<usize>,
        body: &ReceiverMutationActionBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Vec<RuntimeValue>, String> {
        let mut mapped = Vec::new();
        for (index, value) in items.iter().enumerate() {
            path.push(index);
            let next_value = match value {
                RuntimeValue::Array(children) => self
                    .map_receiver_mutation_array_items(children, path, body, ctx, rule_label)
                    .map(RuntimeValue::Array),
                leaf => self.eval_receiver_mutation_array_leaf(
                    leaf.clone(),
                    index,
                    path,
                    body,
                    ctx,
                    rule_label,
                ),
            };
            path.pop();
            mapped.push(next_value?);
        }
        Ok(mapped)
    }

    fn eval_receiver_mutation_hash_leaf(
        &self,
        value: RuntimeValue,
        key: &str,
        path: &[String],
        body: &ReceiverMutationActionBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let mut bindings = vec![
            ctx.enter_scoped_scalar_binding("value", value),
            ctx.enter_scoped_scalar_binding("key", RuntimeValue::Scalar(key.to_string())),
            ctx.enter_scoped_scalar_binding(
                "path",
                RuntimeValue::Array(
                    path.iter()
                        .map(|part| RuntimeValue::Scalar(part.clone()))
                        .collect(),
                ),
            ),
            ctx.enter_scoped_scalar_binding("depth", RuntimeValue::Number(path.len() as f64)),
        ];
        let callback = CodeBlock {
            statements: body.statements.clone(),
        };
        let result = self.eval_block_value(&callback, ctx, rule_label);
        while let Some(binding) = bindings.pop() {
            ctx.exit_scoped_variable_binding(binding);
        }
        result
    }

    fn eval_receiver_mutation_array_leaf(
        &self,
        value: RuntimeValue,
        index: usize,
        path: &[usize],
        body: &ReceiverMutationActionBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let mut bindings = vec![
            ctx.enter_scoped_scalar_binding("value", value),
            ctx.enter_scoped_scalar_binding("index", RuntimeValue::Number(index as f64)),
            ctx.enter_scoped_scalar_binding(
                "path",
                RuntimeValue::Array(
                    path.iter()
                        .map(|part| RuntimeValue::Number(*part as f64))
                        .collect(),
                ),
            ),
            ctx.enter_scoped_scalar_binding("depth", RuntimeValue::Number(path.len() as f64)),
        ];
        let callback = CodeBlock {
            statements: body.statements.clone(),
        };
        let result = self.eval_block_value(&callback, ctx, rule_label);
        while let Some(binding) = bindings.pop() {
            ctx.exit_scoped_variable_binding(binding);
        }
        result
    }

    fn sorted_hash_tree_entries(entries: &[(String, RuntimeValue)]) -> Vec<(String, RuntimeValue)> {
        let mut sorted = entries.to_vec();
        sorted.sort_by(|(left, _), (right, _)| left.cmp(right));
        sorted
    }

    fn walk_hash_tree_entries(
        &self,
        entries: &[(String, RuntimeValue)],
        path: &mut Vec<String>,
        callback: &TreeCodeblockCallback,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(), String> {
        for (key, value) in Self::sorted_hash_tree_entries(entries) {
            path.push(key.clone());
            let result = match value {
                RuntimeValue::Hash(child_entries) => {
                    self.walk_hash_tree_entries(&child_entries, path, callback, ctx, rule_label)
                }
                leaf => self
                    .eval_hash_tree_leaf_block(callback, leaf, &key, path, None, ctx, rule_label)
                    .map(|_| ()),
            };
            path.pop();
            result?;
        }
        Ok(())
    }

    fn map_hash_tree_entries(
        &self,
        entries: &[(String, RuntimeValue)],
        path: &mut Vec<String>,
        callback: &TreeCodeblockCallback,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Vec<(String, RuntimeValue)>, String> {
        let mut mapped = Vec::new();
        for (key, value) in Self::sorted_hash_tree_entries(entries) {
            path.push(key.clone());
            let next_value = match value {
                RuntimeValue::Hash(child_entries) => self
                    .map_hash_tree_entries(&child_entries, path, callback, ctx, rule_label)
                    .map(RuntimeValue::Hash),
                leaf => self
                    .eval_hash_tree_leaf_block(callback, leaf, &key, path, None, ctx, rule_label),
            };
            path.pop();
            mapped.push((key, next_value?));
        }
        Ok(mapped)
    }

    fn reduce_hash_tree_entries(
        &self,
        entries: &[(String, RuntimeValue)],
        path: &mut Vec<String>,
        callback: &TreeCodeblockCallback,
        acc: &mut RuntimeValue,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(), String> {
        for (key, value) in Self::sorted_hash_tree_entries(entries) {
            path.push(key.clone());
            let result = match value {
                RuntimeValue::Hash(child_entries) => self.reduce_hash_tree_entries(
                    &child_entries,
                    path,
                    callback,
                    acc,
                    ctx,
                    rule_label,
                ),
                leaf => {
                    *acc = self.eval_hash_tree_leaf_block(
                        callback,
                        leaf,
                        &key,
                        path,
                        Some(acc.clone()),
                        ctx,
                        rule_label,
                    )?;
                    Ok(())
                }
            };
            path.pop();
            result?;
        }
        Ok(())
    }

    fn eval_hash_tree_leaf_block(
        &self,
        callback: &TreeCodeblockCallback,
        value: RuntimeValue,
        key: &str,
        path: &[String],
        acc: Option<RuntimeValue>,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let mut bindings = Vec::new();
        if let Some(acc_value) = acc {
            bindings.push(ctx.enter_scoped_scalar_binding("acc", acc_value));
        }
        bindings.push(ctx.enter_scoped_scalar_binding("value", value.clone()));
        bindings
            .push(ctx.enter_scoped_scalar_binding("key", RuntimeValue::Scalar(key.to_string())));
        bindings.push(
            ctx.enter_scoped_scalar_binding(
                "path",
                RuntimeValue::Array(
                    path.iter()
                        .map(|part| RuntimeValue::Scalar(part.clone()))
                        .collect(),
                ),
            ),
        );
        bindings.push(
            ctx.enter_scoped_scalar_binding("depth", RuntimeValue::Number(path.len() as f64)),
        );

        let args = if callback.pass_leaf_value {
            vec![value]
        } else {
            Vec::new()
        };
        let result = self.execute_codeblock_value(
            &callback.name,
            callback.binding_name.as_deref(),
            &callback.value,
            &args,
            ctx,
            rule_label,
        );
        while let Some(binding) = bindings.pop() {
            ctx.exit_scoped_variable_binding(binding);
        }
        result
    }

    fn walk_array_tree_items(
        &self,
        items: &[RuntimeValue],
        path: &mut Vec<usize>,
        callback: &TreeCodeblockCallback,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(), String> {
        for (index, value) in items.iter().enumerate() {
            path.push(index);
            let result = match value {
                RuntimeValue::Array(child_items) => {
                    self.walk_array_tree_items(child_items, path, callback, ctx, rule_label)
                }
                leaf => self
                    .eval_array_tree_leaf_block(
                        callback,
                        leaf.clone(),
                        index,
                        path,
                        None,
                        ctx,
                        rule_label,
                    )
                    .map(|_| ()),
            };
            path.pop();
            result?;
        }
        Ok(())
    }

    fn map_array_tree_items(
        &self,
        items: &[RuntimeValue],
        path: &mut Vec<usize>,
        callback: &TreeCodeblockCallback,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Vec<RuntimeValue>, String> {
        let mut mapped = Vec::new();
        for (index, value) in items.iter().enumerate() {
            path.push(index);
            let next_value = match value {
                RuntimeValue::Array(child_items) => self
                    .map_array_tree_items(child_items, path, callback, ctx, rule_label)
                    .map(RuntimeValue::Array),
                leaf => self.eval_array_tree_leaf_block(
                    callback,
                    leaf.clone(),
                    index,
                    path,
                    None,
                    ctx,
                    rule_label,
                ),
            };
            path.pop();
            mapped.push(next_value?);
        }
        Ok(mapped)
    }

    fn reduce_array_tree_items(
        &self,
        items: &[RuntimeValue],
        path: &mut Vec<usize>,
        callback: &TreeCodeblockCallback,
        acc: &mut RuntimeValue,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(), String> {
        for (index, value) in items.iter().enumerate() {
            path.push(index);
            let result = match value {
                RuntimeValue::Array(child_items) => {
                    self.reduce_array_tree_items(child_items, path, callback, acc, ctx, rule_label)
                }
                leaf => {
                    *acc = self.eval_array_tree_leaf_block(
                        callback,
                        leaf.clone(),
                        index,
                        path,
                        Some(acc.clone()),
                        ctx,
                        rule_label,
                    )?;
                    Ok(())
                }
            };
            path.pop();
            result?;
        }
        Ok(())
    }

    fn eval_array_tree_leaf_block(
        &self,
        callback: &TreeCodeblockCallback,
        value: RuntimeValue,
        index: usize,
        path: &[usize],
        acc: Option<RuntimeValue>,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let mut bindings = Vec::new();
        if let Some(acc_value) = acc {
            bindings.push(ctx.enter_scoped_scalar_binding("acc", acc_value));
        }
        bindings.push(ctx.enter_scoped_scalar_binding("value", value.clone()));
        bindings.push(ctx.enter_scoped_scalar_binding("index", RuntimeValue::Number(index as f64)));
        bindings.push(
            ctx.enter_scoped_scalar_binding(
                "path",
                RuntimeValue::Array(
                    path.iter()
                        .map(|part| RuntimeValue::Number(*part as f64))
                        .collect(),
                ),
            ),
        );
        bindings.push(
            ctx.enter_scoped_scalar_binding("depth", RuntimeValue::Number(path.len() as f64)),
        );

        let args = if callback.pass_leaf_value {
            vec![value]
        } else {
            Vec::new()
        };
        let result = self.execute_codeblock_value(
            &callback.name,
            callback.binding_name.as_deref(),
            &callback.value,
            &args,
            ctx,
            rule_label,
        );
        while let Some(binding) = bindings.pop() {
            ctx.exit_scoped_variable_binding(binding);
        }
        result
    }

    fn eval_receiver_dynamic_value_chain_call(
        &self,
        current: RuntimeValue,
        call: &linkedspec_core::expr::FluentCall,
        is_last: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let method = call.method.as_str();

        if Self::is_generic_receiver_value_method(method) {
            let (raw_args, values) = self.receiver_call_args(current, call, ctx, rule_label)?;
            return self.call_helper_with_args(method, &raw_args, &values, ctx, rule_label);
        }

        if Self::is_hash_receiver_value_chain_method(method) {
            return self
                .eval_hash_receiver_dynamic_value_call(current, call, is_last, ctx, rule_label);
        }
        if Self::is_array_receiver_value_chain_method(method)
            && (!matches!(method, "min" | "max") || matches!(current, RuntimeValue::Array(_)))
        {
            return self
                .eval_array_receiver_dynamic_value_call(current, call, is_last, ctx, rule_label);
        }
        if Self::is_string_receiver_value_chain_method(method) {
            return self
                .eval_string_receiver_dynamic_value_call(current, call, is_last, ctx, rule_label);
        }
        if Self::is_number_receiver_value_chain_method(method) {
            return self
                .eval_number_receiver_dynamic_value_call(current, call, is_last, ctx, rule_label);
        }

        Ok(RuntimeValue::Undef)
    }

    fn receiver_call_args(
        &self,
        current: RuntimeValue,
        call: &linkedspec_core::expr::FluentCall,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<(Vec<linkedspec_core::expr::Arg>, Vec<RuntimeValue>), String> {
        use linkedspec_core::expr::{Arg, Expr};

        let evaluated_call_args: Vec<RuntimeValue> = call
            .args
            .iter()
            .map(|arg| self.eval_expr(arg.value(), ctx, rule_label))
            .collect::<Result<Vec<_>, _>>()?;

        let receiver_arg = Arg::Positional(Expr::Undef);
        if call.method == "join_values" {
            let mut raw = call.args.clone();
            raw.push(receiver_arg);
            let mut vals = evaluated_call_args;
            vals.push(current);
            return Ok((raw, vals));
        }

        let mut raw = Vec::with_capacity(call.args.len() + 1);
        raw.push(receiver_arg);
        raw.extend(call.args.clone());
        let mut vals = Vec::with_capacity(evaluated_call_args.len() + 1);
        vals.push(current);
        vals.extend(evaluated_call_args);
        Ok((raw, vals))
    }

    fn eval_array_receiver_dynamic_value_call(
        &self,
        current: RuntimeValue,
        call: &linkedspec_core::expr::FluentCall,
        is_last: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        if Self::is_statement_only_array_end_mutation_method(&call.method)
            || (!Self::is_array_receiver_value_chain_method(&call.method)
                && call.method != "length")
        {
            return Ok(RuntimeValue::Undef);
        }

        let (raw_args, evaluated) = self.receiver_call_args(current, call, ctx, rule_label)?;
        let next =
            self.call_helper_with_args(&call.method, &raw_args, &evaluated, ctx, rule_label)?;
        if !Self::is_array_receiver_array_returning_method(&call.method)
            && !Self::is_selected_receiver_result_method(&call.method)
            && !is_last
        {
            return Ok(RuntimeValue::Undef);
        }
        Ok(next)
    }

    fn eval_hash_receiver_dynamic_value_call(
        &self,
        current: RuntimeValue,
        call: &linkedspec_core::expr::FluentCall,
        is_last: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        if !Self::is_hash_receiver_value_chain_method(&call.method) {
            return Ok(RuntimeValue::Undef);
        }

        let (raw_args, evaluated) = self.receiver_call_args(current, call, ctx, rule_label)?;
        let next =
            self.call_helper_with_args(&call.method, &raw_args, &evaluated, ctx, rule_label)?;
        if Self::is_hash_receiver_terminal_method(&call.method)
            && !Self::is_selected_receiver_result_method(&call.method)
            && !is_last
        {
            return Ok(RuntimeValue::Undef);
        }
        Ok(next)
    }

    fn eval_string_receiver_dynamic_value_call(
        &self,
        current: RuntimeValue,
        call: &linkedspec_core::expr::FluentCall,
        is_last: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        if !Self::is_string_receiver_value_chain_method(&call.method) {
            return Ok(RuntimeValue::Undef);
        }

        if matches!(call.method.as_str(), "coalesce" | "coalesce_nonempty") {
            let skip_empty = call.method == "coalesce_nonempty";
            if Self::coalesce_accepts(&current, skip_empty) {
                return Ok(current);
            }
            return self.eval_coalesce_args(&call.args, skip_empty, ctx, rule_label);
        }

        let (raw_args, evaluated) = self.receiver_call_args(current, call, ctx, rule_label)?;
        let next =
            self.call_helper_with_args(&call.method, &raw_args, &evaluated, ctx, rule_label)?;
        if Self::is_string_receiver_terminal_method(&call.method)
            && !Self::is_selected_receiver_result_method(&call.method)
            && !is_last
        {
            return Ok(RuntimeValue::Undef);
        }
        Ok(next)
    }

    fn eval_number_receiver_dynamic_value_call(
        &self,
        current: RuntimeValue,
        call: &linkedspec_core::expr::FluentCall,
        _is_last: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        use linkedspec_core::expr::{Arg, Expr};

        if !Self::is_number_receiver_value_chain_method(&call.method) {
            return Ok(RuntimeValue::Undef);
        }
        let valid_arity = match call.method.as_str() {
            "abs" | "floor" | "ceil" | "round" => call.args.is_empty(),
            "sub" | "div" | "mod" | "eq" | "ne" | "gt" | "ge" | "lt" | "le" => call.args.len() == 1,
            "clamp" => call.args.len() == 2,
            "add" | "mul" | "min" | "max" => !call.args.is_empty(),
            _ => false,
        };
        if !valid_arity {
            return Ok(RuntimeValue::Undef);
        }

        let Some(helper_name) = Self::number_receiver_helper_name(&call.method) else {
            return Ok(RuntimeValue::Undef);
        };
        let evaluated_call_args: Vec<RuntimeValue> = call
            .args
            .iter()
            .map(|arg| self.eval_expr(arg.value(), ctx, rule_label))
            .collect::<Result<Vec<_>, _>>()?;

        let mut raw_args = Vec::with_capacity(call.args.len() + 1);
        raw_args.push(Arg::Positional(Expr::Undef));
        raw_args.extend(call.args.clone());
        let mut evaluated = Vec::with_capacity(evaluated_call_args.len() + 1);
        evaluated.push(current);
        evaluated.extend(evaluated_call_args);

        let next =
            self.call_helper_with_args(helper_name, &raw_args, &evaluated, ctx, rule_label)?;
        Ok(next)
    }

    fn is_selected_receiver_result_method(method: &str) -> bool {
        matches!(method, "first" | "last" | "count" | "count_keys" | "length")
            || Self::is_scalar_result_receiver_method(method)
    }

    fn is_generic_receiver_value_method(method: &str) -> bool {
        matches!(
            method,
            "is_empty"
                | "is_nonempty"
                | "is_defined"
                | "is_undefined"
                | "and"
                | "or"
                | "not"
                | "copy"
        )
    }

    fn is_scalar_result_receiver_method(method: &str) -> bool {
        matches!(
            method,
            "and"
                | "or"
                | "not"
                | "sum"
                | "avg"
                | "median"
                | "range"
                | "min"
                | "max"
                | "join_values"
                | "coalesce"
                | "trim"
                | "lowercase"
                | "uppercase"
                | "replace_substr"
                | "rm_prefix"
                | "rm_suffix"
                | "substr"
                | "cat"
                | "contains"
                | "index_of"
                | "has_key"
                | "is_empty"
                | "is_nonempty"
                | "is_defined"
                | "is_undefined"
                | "starts_with"
                | "ends_with"
                | "contains_substr"
                | "matches"
                | "str_eq"
                | "str_ne"
                | "str_gt"
                | "str_ge"
                | "str_lt"
                | "str_le"
        ) || Self::is_number_receiver_value_chain_method(method)
    }

    // Producer continuations consume the actual result value
    // through the existing dynamic dispatcher, not the original receiver family.
    fn eval_selected_receiver_value_chain(
        &self,
        mut current: RuntimeValue,
        calls: &[linkedspec_core::expr::FluentCall],
        mut scalar_result: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        for (index, call) in calls.iter().enumerate() {
            if call.method == "copy" {
                return self.eval_kind_guarded_receiver_value_chain(
                    current,
                    &calls[index..],
                    ctx,
                    rule_label,
                );
            }
            // Scalar producers retain the incompatible-array boundary
            // until a compatible helper explicitly returns a container.
            if scalar_result
                && !Self::is_generic_receiver_value_method(&call.method)
                && !Self::is_string_receiver_value_chain_method(&call.method)
                && !Self::is_number_receiver_value_chain_method(&call.method)
            {
                return Ok(RuntimeValue::Undef);
            }
            current = self.eval_receiver_dynamic_value_chain_call(
                current,
                call,
                index + 1 == calls.len(),
                ctx,
                rule_label,
            )?;
            // Default selection gives a container its actual consumer family.
            if matches!(call.method.as_str(), "coalesce" | "coalesce_nonempty")
                && matches!(current, RuntimeValue::Array(_) | RuntimeValue::Hash(_))
            {
                return self.eval_kind_guarded_receiver_value_chain(
                    current,
                    &calls[index + 1..],
                    ctx,
                    rule_label,
                );
            }
            scalar_result = (scalar_result || Self::is_scalar_result_receiver_method(&call.method))
                && !matches!(current, RuntimeValue::Array(_) | RuntimeValue::Hash(_));
        }
        Ok(current)
    }

    // Only ordinary parser-reader result signatures enable guards. Malformed
    // free calls retain their own producer and legacy continuation policies.
    fn is_input_cursor_value_source(expr: &Expr) -> bool {
        let Expr::Call { name, args } = expr else {
            return false;
        };
        if name == "input_slice" {
            return args.len() == 2;
        }
        args.is_empty()
            && matches!(
                name.as_str(),
                "input_text"
                    | "input_len"
                    | "input_end_pos"
                    | "input_end_line"
                    | "input_end_col"
                    | "cursor_pos"
                    | "cursor_line"
                    | "cursor_col"
                    | "cursor_rest"
                    | "cursor_rest_len"
                    | "gap_text"
                    | "gap_kind"
                    | "rewind_entry_start"
                    | "rewind_match_start"
            )
    }

    // Preserve the lazy producer and legacy arities; guard ordinary free results.
    fn is_free_default_result_source(expr: &Expr) -> bool {
        use linkedspec_core::expr::Arg;

        let Expr::Call { name, args } = expr else {
            return false;
        };
        matches!(name.as_str(), "coalesce" | "coalesce_nonempty")
            && args.len() >= 2
            && args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
    }

    // Preserve String producers and domains; only canonical ordinary calls gain guards.
    fn is_free_string_result_source(expr: &Expr) -> bool {
        use linkedspec_core::expr::Arg;

        let Expr::Call { name, args } = expr else {
            return false;
        };
        let valid_arity = match name.as_str() {
            "trim" | "lowercase" | "uppercase" => args.len() == 1,
            "replace_substr" => args.len() == 3,
            "rm_prefix" | "rm_suffix" => args.len() == 2,
            "substr" => matches!(args.len(), 2 | 3),
            "cat" => args.len() >= 2,
            _ => false,
        };
        valid_arity
            && args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
    }

    // Existing arity preflight owns malformed calls; retain kind guards for
    // canonical String receiver prefixes through their intermediate results.
    fn is_ordinary_string_receiver_prefix(calls: &[linkedspec_core::expr::FluentCall]) -> bool {
        use linkedspec_core::expr::Arg;

        let Some(first) = calls.first() else {
            return false;
        };
        if !matches!(
            first.method.as_str(),
            "trim"
                | "lowercase"
                | "uppercase"
                | "replace_substr"
                | "rm_prefix"
                | "rm_suffix"
                | "substr"
                | "cat"
        ) || calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        first.args.iter().all(|arg| {
            matches!(
                arg,
                Arg::Positional(
                    Expr::Variable { .. }
                        | Expr::NumberLiteral { .. }
                        | Expr::StringLiteral { .. }
                        | Expr::BooleanLiteral { .. }
                        | Expr::Undef
                        | Expr::ArrayLiteral { .. }
                        | Expr::HashLiteral { .. }
                        | Expr::BlockValue { .. }
                        | Expr::Call { .. }
                        | Expr::FluentChain { .. }
                        | Expr::ReceiverMutationChain { .. }
                        | Expr::IndexedVar { .. }
                        | Expr::NestedAccess { .. }
                        | Expr::ValueAccess { .. }
                        | Expr::AssignScalar { .. }
                        | Expr::AssignArrayAppend { .. }
                        | Expr::AssignHashIndex { .. }
                        | Expr::AssignNestedAccess { .. }
                        | Expr::CodeblockLiteral(_)
                )
            )
        })
    }

    // Numeric producers and arity preflight stay unchanged. Retain kind
    // guards for canonical scalar calls and ordinary short Number prefixes.
    fn is_ordinary_numeric_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |args: &[Arg]| {
            args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
        };
        if let Expr::Call { name, args } = receiver {
            let valid_arity = match name.as_str() {
                "num_abs" | "num_floor" | "num_ceil" | "num_round" => args.len() == 1,
                "num_sub" | "num_div" | "num_mod" | "num_eq" | "num_ne" | "num_gt" | "num_ge"
                | "num_lt" | "num_le" => args.len() == 2,
                "num_clamp" => args.len() == 3,
                "num_add" | "num_mul" | "num_min" | "num_max" => args.len() >= 2,
                _ => false,
            };
            if valid_arity && ordinary_args(args) {
                return true;
            }
        }
        let Some(first) = calls.first() else {
            return false;
        };
        matches!(first.method.as_str(),
            "abs" | "floor" | "ceil" | "round" | "add" | "sub" |
            "mul" | "div" | "mod" | "clamp" | "min" | "max" | "eq" | "ne" | "gt" | "ge" | "lt" | "le")
            // Zero-extra min/max belongs to the existing Array reducer.
            && !(matches!(first.method.as_str(), "min" | "max") && first.args.is_empty())
            && ordinary_args(&first.args)
    }

    // Free logical results keep eager evaluation and actual Bool values.
    // Retain the existing kind guard before later immediate with bodies.
    fn is_ordinary_logical_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |args: &[Arg]| {
            args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
        };
        let Expr::Call { name, args } = receiver else {
            return false;
        };
        let valid_arity = match name.as_str() {
            "and" | "or" => !args.is_empty(),
            "not" => args.len() == 1,
            _ => false,
        };
        valid_arity && ordinary_args(args)
    }

    // Lexical comparisons preserve their existing Bool and null policies.
    // Canonical free calls and ordinary prefixes retain result-kind guards.
    fn is_ordinary_lexical_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |args: &[Arg]| {
            args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
        };
        if let Expr::Call { name, args } = receiver {
            let valid_arity = matches!(
                name.as_str(),
                "str_eq" | "str_ne" | "str_gt" | "str_ge" | "str_lt" | "str_le"
            ) && args.len() == 2;
            if valid_arity && ordinary_args(args) {
                return true;
            }
        }
        let Some(first) = calls.first() else {
            return false;
        };
        matches!(
            first.method.as_str(),
            "str_eq" | "str_ne" | "str_gt" | "str_ge" | "str_lt" | "str_le"
        ) && first.args.len() == 1
            && ordinary_args(&first.args)
    }

    // Definedness keeps Bool identity and the existing null-versus-defined domain.
    // Canonical free calls and zero-operand prefixes retain result-kind guards.
    fn is_ordinary_definedness_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |args: &[Arg]| {
            args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
        };
        if let Expr::Call { name, args } = receiver {
            let valid_arity =
                matches!(name.as_str(), "is_defined" | "is_undefined") && args.len() == 1;
            if valid_arity && ordinary_args(args) {
                return true;
            }
        }
        calls.first().is_some_and(|first| {
            matches!(first.method.as_str(), "is_defined" | "is_undefined") && first.args.is_empty()
        })
    }

    // Emptiness keeps Bool identity and the existing empty-value domain.
    // Canonical free calls and zero-operand prefixes retain result-kind guards.
    fn is_ordinary_emptiness_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |args: &[Arg]| {
            args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
        };
        if let Expr::Call { name, args } = receiver {
            let valid_arity =
                matches!(name.as_str(), "is_empty" | "is_nonempty") && args.len() == 1;
            if valid_arity && ordinary_args(args) {
                return true;
            }
        }
        calls.first().is_some_and(|first| {
            matches!(first.method.as_str(), "is_empty" | "is_nonempty") && first.args.is_empty()
        })
    }

    // Presence flags keep their numeric producer and existing source/key domains.
    // Canonical free calls and one-key prefixes retain result-kind guards.
    fn is_ordinary_has_key_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |args: &[Arg]| {
            args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
        };
        if let Expr::Call { name, args } = receiver {
            if name == "has_key" && args.len() == 2 && ordinary_args(args) {
                return true;
            }
        }
        calls.first().is_some_and(|first| {
            first.method == "has_key" && first.args.len() == 1 && ordinary_args(&first.args)
        })
    }

    // String predicates retain numeric text flags, Bool matches and regex policy.
    // Canonical free-two calls and one-operand prefixes join existing kind guards.
    fn is_ordinary_string_predicate_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |method: &str, args: &[Arg]| {
            args.iter().enumerate().all(|(index, arg)| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                ) || (method == "matches"
                    && index + 1 == args.len()
                    && matches!(arg, Arg::Positional(Expr::RegexLiteral { .. })))
            })
        };
        if let Expr::Call { name, args } = receiver {
            let valid_arity = matches!(
                name.as_str(),
                "starts_with" | "ends_with" | "contains_substr" | "matches"
            ) && args.len() == 2;
            if valid_arity && ordinary_args(name, args) {
                return true;
            }
        }
        let Some(first) = calls.first() else {
            return false;
        };
        matches!(
            first.method.as_str(),
            "starts_with" | "ends_with" | "contains_substr" | "matches"
        ) && first.args.len() == 1
            && ordinary_args(&first.method, &first.args)
    }

    // Count retains its source domain while its numeric result joins kind guards.
    // Only canonical free-one calls and zero-operand prefixes qualify.
    fn is_ordinary_count_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        if let Expr::Call { name, args } = receiver
            && name == "count"
            && args.len() == 1
            && matches!(
                &args[0],
                Arg::Positional(
                    Expr::Variable { .. }
                        | Expr::NumberLiteral { .. }
                        | Expr::StringLiteral { .. }
                        | Expr::BooleanLiteral { .. }
                        | Expr::Undef
                        | Expr::ArrayLiteral { .. }
                        | Expr::HashLiteral { .. }
                        | Expr::BlockValue { .. }
                        | Expr::Call { .. }
                        | Expr::FluentChain { .. }
                        | Expr::ReceiverMutationChain { .. }
                        | Expr::IndexedVar { .. }
                        | Expr::NestedAccess { .. }
                        | Expr::ValueAccess { .. }
                        | Expr::AssignScalar { .. }
                        | Expr::AssignArrayAppend { .. }
                        | Expr::AssignHashIndex { .. }
                        | Expr::AssignNestedAccess { .. }
                        | Expr::CodeblockLiteral(_)
                )
            )
        {
            return true;
        }
        calls
            .first()
            .is_some_and(|first| first.method == "count" && first.args.is_empty())
    }

    // Length retains scalar/Array sources and its nullable numeric result.
    // Only canonical free-one calls and zero-operand prefixes qualify.
    fn is_ordinary_length_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        if let Expr::Call { name, args } = receiver
            && name == "length"
            && args.len() == 1
            && matches!(
                &args[0],
                Arg::Positional(
                    Expr::Variable { .. }
                        | Expr::NumberLiteral { .. }
                        | Expr::StringLiteral { .. }
                        | Expr::BooleanLiteral { .. }
                        | Expr::Undef
                        | Expr::ArrayLiteral { .. }
                        | Expr::HashLiteral { .. }
                        | Expr::BlockValue { .. }
                        | Expr::Call { .. }
                        | Expr::FluentChain { .. }
                        | Expr::ReceiverMutationChain { .. }
                        | Expr::IndexedVar { .. }
                        | Expr::NestedAccess { .. }
                        | Expr::ValueAccess { .. }
                        | Expr::AssignScalar { .. }
                        | Expr::AssignArrayAppend { .. }
                        | Expr::AssignHashIndex { .. }
                        | Expr::AssignNestedAccess { .. }
                        | Expr::CodeblockLiteral(_)
                )
            )
        {
            return true;
        }
        calls
            .first()
            .is_some_and(|first| first.method == "length" && first.args.is_empty())
    }

    // CountKeys retains Hash/non-Hash source policy while guarding numeric results.
    // Only canonical free-one calls and zero-operand prefixes qualify.
    fn is_ordinary_key_count_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        if let Expr::Call { name, args } = receiver
            && name == "count_keys"
            && args.len() == 1
            && matches!(
                &args[0],
                Arg::Positional(
                    Expr::Variable { .. }
                        | Expr::NumberLiteral { .. }
                        | Expr::StringLiteral { .. }
                        | Expr::BooleanLiteral { .. }
                        | Expr::Undef
                        | Expr::ArrayLiteral { .. }
                        | Expr::HashLiteral { .. }
                        | Expr::BlockValue { .. }
                        | Expr::Call { .. }
                        | Expr::FluentChain { .. }
                        | Expr::ReceiverMutationChain { .. }
                        | Expr::IndexedVar { .. }
                        | Expr::NestedAccess { .. }
                        | Expr::ValueAccess { .. }
                        | Expr::AssignScalar { .. }
                        | Expr::AssignArrayAppend { .. }
                        | Expr::AssignHashIndex { .. }
                        | Expr::AssignNestedAccess { .. }
                        | Expr::CodeblockLiteral(_)
                )
            )
        {
            return true;
        }
        calls
            .first()
            .is_some_and(|first| first.method == "count_keys" && first.args.is_empty())
    }

    fn is_ordinary_hash_value_operand(expr: &Expr) -> bool {
        matches!(
            expr,
            Expr::Variable { .. }
                | Expr::NumberLiteral { .. }
                | Expr::StringLiteral { .. }
                | Expr::BooleanLiteral { .. }
                | Expr::Undef
                | Expr::ArrayLiteral { .. }
                | Expr::HashLiteral { .. }
                | Expr::BlockValue { .. }
                | Expr::Call { .. }
                | Expr::FluentChain { .. }
                | Expr::ReceiverMutationChain { .. }
                | Expr::IndexedVar { .. }
                | Expr::NestedAccess { .. }
                | Expr::ValueAccess { .. }
                | Expr::AssignScalar { .. }
                | Expr::AssignArrayAppend { .. }
                | Expr::AssignHashIndex { .. }
                | Expr::AssignNestedAccess { .. }
        )
    }

    fn is_ordinary_hash_value_result_call(
        name: &str,
        args: &[linkedspec_core::expr::Arg],
        receiver: bool,
    ) -> bool {
        use linkedspec_core::expr::Arg;

        let count = args.len() + usize::from(receiver);
        let canonical_arity = match name {
            "merge_hash" => count == 2,
            "set_key" | "rename_key" => count == 3,
            "drop_keys" | "pick_keys" => count >= 2,
            _ => false,
        };
        canonical_arity
            && args.iter().all(|arg| {
                matches!(arg, Arg::Positional(value) if Self::is_ordinary_hash_value_operand(value))
            })
    }

    // Pure Hash helpers retain their source/arity policies. Only ordinary value
    // results and canonical first prefixes enter the existing persistent guards.
    fn is_ordinary_hash_value_result_chain(
        &self,
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls.iter().any(|call| {
            Self::is_tree_traversal_receiver_method(&call.method)
                || call.args.iter().any(|arg| match arg {
                    Arg::Keyword { .. } => true,
                    Arg::Positional(value) => {
                        call.method != "with" && !Self::is_ordinary_hash_value_operand(value)
                    }
                })
                || !(Self::is_generic_receiver_value_method(&call.method)
                    || Self::is_array_receiver_value_chain_method(&call.method)
                    || Self::is_hash_receiver_value_chain_method(&call.method)
                    || Self::is_string_receiver_value_chain_method(&call.method)
                    || Self::is_number_receiver_value_chain_method(&call.method)
                    || Self::is_receiver_with_trailing_block_call(call))
        }) {
            return false;
        }
        if let Expr::Call { name, args } = receiver {
            if self.spec.find_function(name).is_some() {
                return false;
            }
            if Self::is_ordinary_hash_value_result_call(name, args, false) {
                return true;
            }
        }
        Self::is_ordinary_hash_value_operand(receiver)
            && calls.len() > 1
            && calls.first().is_some_and(|first| {
                Self::is_ordinary_hash_value_result_call(&first.method, &first.args, true)
            })
    }

    // Ordered Hash-view producers retain their input policy. Only canonical
    // ordinary calls and zero-extra prefixes gain result-kind ownership.
    fn is_ordinary_hash_view_result_chain(
        &self,
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls.iter().any(|call| {
            Self::is_tree_traversal_receiver_method(&call.method)
                || call
                    .args
                    .iter()
                    .any(|arg| matches!(arg, Arg::Keyword { .. }))
                || !(Self::is_generic_receiver_value_method(&call.method)
                    || Self::is_array_receiver_value_chain_method(&call.method)
                    || Self::is_hash_receiver_value_chain_method(&call.method)
                    || Self::is_string_receiver_value_chain_method(&call.method)
                    || Self::is_number_receiver_value_chain_method(&call.method)
                    || Self::is_receiver_with_trailing_block_call(call))
        }) {
            return false;
        }
        // Registered-function receiver compatibility remains on its existing route.
        if let Expr::Call { name, args } = receiver {
            if self.spec.find_function(name).is_some() {
                return false;
            }
            if matches!(name.as_str(), "sorted_keys" | "sorted_values")
                && args.len() == 1
                && matches!(
                    &args[0],
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            {
                return true;
            }
        }
        calls.first().is_some_and(|first| {
            matches!(first.method.as_str(), "sorted_keys" | "sorted_values")
                && first.args.is_empty()
        })
    }

    // Membership retains numeric flags, equality and nullable-source behavior.
    // Canonical free-two calls and one-needle prefixes join result-kind guards.
    fn is_ordinary_contains_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |args: &[Arg]| {
            args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
        };
        if let Expr::Call { name, args } = receiver {
            if name == "contains" && args.len() == 2 && ordinary_args(args) {
                return true;
            }
        }
        calls.first().is_some_and(|first| {
            first.method == "contains" && first.args.len() == 1 && ordinary_args(&first.args)
        })
    }

    // Index lookups retain numeric zero, missing results and source snapshots.
    // Only canonical free-two calls and ordinary one-needle prefixes qualify.
    fn is_ordinary_index_result_chain(
        receiver: &Expr,
        calls: &[linkedspec_core::expr::FluentCall],
    ) -> bool {
        use linkedspec_core::expr::Arg;

        if calls
            .iter()
            .any(|call| Self::is_tree_traversal_receiver_method(&call.method))
        {
            return false;
        }
        let ordinary_args = |args: &[Arg]| {
            args.iter().all(|arg| {
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
        };
        if let Expr::Call { name, args } = receiver {
            if name == "index_of" && args.len() == 2 && ordinary_args(args) {
                return true;
            }
        }
        calls.first().is_some_and(|first| {
            first.method == "index_of" && first.args.len() == 1 && ordinary_args(&first.args)
        })
    }

    // Keep constructor payload/pair/splice policy on its original producer.
    // Only retained ordinary boxed forms join the existing result guards.
    fn is_constructor_result_source(expr: &Expr) -> bool {
        use linkedspec_core::expr::Arg;

        let Expr::Call { name, args } = expr else {
            return false;
        };
        matches!(name.as_str(), "array" | "hash")
            && (name != "hash" || args.len() % 2 == 0)
            && !matches!(args.as_slice(), [Arg::Positional(Expr::Variable { .. })])
            && args.iter().all(|arg| {
                if Self::is_list_context_splice_arg(arg) {
                    return false;
                }
                if let Arg::Positional(Expr::FluentChain { calls, .. }) = arg
                    && calls.last().is_some_and(|call| {
                        matches!(call.method.as_str(), "flat" | "flat_array" | "flat_hash")
                    })
                {
                    return false;
                }
                matches!(
                    arg,
                    Arg::Positional(
                        Expr::Variable { .. }
                            | Expr::NumberLiteral { .. }
                            | Expr::StringLiteral { .. }
                            | Expr::BooleanLiteral { .. }
                            | Expr::Undef
                            | Expr::ArrayLiteral { .. }
                            | Expr::HashLiteral { .. }
                            | Expr::BlockValue { .. }
                            | Expr::Call { .. }
                            | Expr::FluentChain { .. }
                            | Expr::ReceiverMutationChain { .. }
                            | Expr::IndexedVar { .. }
                            | Expr::NestedAccess { .. }
                            | Expr::ValueAccess { .. }
                            | Expr::AssignScalar { .. }
                            | Expr::AssignArrayAppend { .. }
                            | Expr::AssignHashIndex { .. }
                            | Expr::AssignNestedAccess { .. }
                            | Expr::CodeblockLiteral(_)
                    )
                )
            })
    }

    // Assignment keeps its existing stored-value ABI; only canonical calls gain
    // result guards. Operator aliases and malformed target/argument shapes stay separate.
    fn is_explicit_set_result_source(expr: &Expr) -> bool {
        use linkedspec_core::expr::Arg;

        let Expr::Call { name, args } = expr else {
            return false;
        };
        let [
            Arg::Positional(Expr::Variable { .. }),
            Arg::Positional(value),
        ] = args.as_slice()
        else {
            return false;
        };
        name == "set"
            && matches!(
                value,
                Expr::Variable { .. }
                    | Expr::NumberLiteral { .. }
                    | Expr::StringLiteral { .. }
                    | Expr::BooleanLiteral { .. }
                    | Expr::Undef
                    | Expr::ArrayLiteral { .. }
                    | Expr::HashLiteral { .. }
                    | Expr::BlockValue { .. }
                    | Expr::Call { .. }
                    | Expr::FluentChain { .. }
                    | Expr::ReceiverMutationChain { .. }
                    | Expr::IndexedVar { .. }
                    | Expr::NestedAccess { .. }
                    | Expr::ValueAccess { .. }
                    | Expr::AssignScalar { .. }
                    | Expr::AssignArrayAppend { .. }
                    | Expr::AssignHashIndex { .. }
                    | Expr::AssignNestedAccess { .. }
                    | Expr::CodeblockLiteral(_)
            )
    }

    // Only unambiguous explicit-value push snapshots gain ordinary result guards.
    // Static child rules retain priority even when a local binding shares their name.
    fn is_explicit_push_result_source(&self, expr: &Expr) -> bool {
        use linkedspec_core::expr::Arg;

        let Expr::Call { name, args } = expr else {
            return false;
        };
        let [
            Arg::Positional(Expr::Variable { name: target }),
            Arg::Positional(value),
        ] = args.as_slice()
        else {
            return false;
        };
        name == "push"
            && self.spec.find(target).is_none()
            && matches!(
                value,
                Expr::StringLiteral { .. }
                    | Expr::BooleanLiteral { .. }
                    | Expr::Undef
                    | Expr::ArrayLiteral { .. }
                    | Expr::HashLiteral { .. }
                    | Expr::BlockValue { .. }
                    | Expr::Call { .. }
                    | Expr::FluentChain { .. }
                    | Expr::ReceiverMutationChain { .. }
                    | Expr::IndexedVar { .. }
                    | Expr::NestedAccess { .. }
                    | Expr::ValueAccess { .. }
                    | Expr::AssignScalar { .. }
                    | Expr::AssignArrayAppend { .. }
                    | Expr::AssignHashIndex { .. }
                    | Expr::AssignNestedAccess { .. }
                    | Expr::CodeblockLiteral(_)
            )
    }

    // Static source ownership keeps legacy bound-call result guards intact.
    // Do not infer callable ownership from the returned value or a binding.
    fn is_ordinary_computed_read(&self, expr: &Expr) -> bool {
        let Expr::ValueAccess { receiver, .. } = expr else {
            return false;
        };
        match receiver.as_ref() {
            Expr::Call { name, args } => {
                if self.spec.find_function(name).is_some() {
                    return true;
                }
                if name == "push" {
                    return self.is_explicit_push_result_source(receiver);
                }
                if name == "set" {
                    return Self::is_explicit_set_result_source(receiver);
                }
                if matches!(name.as_str(), "rewind_entry_start" | "rewind_match_start") {
                    return args.is_empty();
                }
                // Readonly gap/slot values share ordinary selected-value guards.
                if matches!(
                    name.as_str(),
                    "entry_slot" | "gap_span" | "gap_text" | "gap_kind"
                ) {
                    return args.is_empty();
                }
                // Static child returns use ordinary selected-value guards.
                // Preserve quoted/dynamic calls and legacy bound-call policies.
                if name == "call" {
                    return matches!(
                        args.as_slice(),
                        [linkedspec_core::expr::Arg::Positional(
                            Expr::Variable { .. }
                        )]
                    );
                }
                // Inline value calls have payload operands; one-operand
                // statement headers retain their legacy result policies.
                if matches!(name.as_str(), "if" | "switch") {
                    return args.len() >= 2;
                }
                // Only metadata-approved immediate contextual with bodies join
                // ordinary selected-value guards. Explicit/bound final callbacks
                // retain their existing first-consumer policy.
                if name == "with" {
                    let Some(before_count) = args.len().checked_sub(1) else {
                        return false;
                    };
                    return args
                        .last()
                        .is_some_and(|arg| matches!(arg.value(), Expr::CodeblockArgument(_)))
                        && builtin_contract(CallableSurface::Helper, name).is_some_and(
                            |contract| {
                                (contract.min_before_codeblock..=contract.max_before_codeblock)
                                    .contains(&before_count)
                            },
                        );
                }
                if matches!(
                    name.as_str(),
                    "flat"
                        | "flat_array"
                        | "flat_hash"
                        | "walk_leaves"
                        | "map_leaves"
                        | "reduce_leaves"
                ) {
                    return false;
                }
                Self::is_array_receiver_value_chain_method(name)
                    || Self::is_hash_receiver_value_chain_method(name)
                    || Self::is_string_receiver_value_chain_method(name)
                    || Self::is_generic_receiver_value_method(name)
                    || Self::numeric_word_helper_name(name.strip_prefix("num_").unwrap_or(name))
                        .is_some()
                    || matches!(
                        name.as_str(),
                        "array"
                            | "hash"
                            | "entry_groups"
                            | "entry_map"
                            | "entry_named_map"
                            | "match_groups"
                            | "match_map"
                            | "match_named_map"
                    )
            }
            Expr::ValueAccess { .. } => self.is_ordinary_computed_read(receiver),
            _ => true,
        }
    }

    // Selected and copied results retain their actual kind. Validate it before
    // evaluating container-only operands, including after
    // a later scalar/default/container bridge changes the value again.
    fn eval_kind_guarded_receiver_value_chain(
        &self,
        mut current: RuntimeValue,
        calls: &[linkedspec_core::expr::FluentCall],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        for (index, call) in calls.iter().enumerate() {
            let method = call.method.as_str();
            if !Self::is_generic_receiver_value_method(method) {
                let array_only = Self::is_array_receiver_value_chain_method(method)
                    && !Self::is_string_receiver_value_chain_method(method)
                    && !(matches!(method, "min" | "max") && !call.args.is_empty());
                let hash_only = Self::is_hash_receiver_value_chain_method(method);
                // Copy preserves legitimate null; rejection exits this loop.
                let nullable_presence = matches!(current, RuntimeValue::Undef)
                    && Self::is_ordinary_has_key_result_chain(
                        &Expr::Undef,
                        std::slice::from_ref(call),
                    );
                // Copy preserves legitimate null; earlier rejection has
                // already returned before this canonical membership consumer.
                let nullable_membership = matches!(current, RuntimeValue::Undef)
                    && Self::is_ordinary_contains_result_chain(
                        &Expr::Undef,
                        std::slice::from_ref(call),
                    );
                // Copy preserves legitimate null; earlier rejection has
                // already returned before this canonical index consumer.
                let nullable_index = matches!(current, RuntimeValue::Undef)
                    && Self::is_ordinary_index_result_chain(
                        &Expr::Undef,
                        std::slice::from_ref(call),
                    );
                if (array_only
                    && !matches!(current, RuntimeValue::Array(_))
                    && !nullable_membership
                    && !nullable_index)
                    || (hash_only
                        && !matches!(current, RuntimeValue::Hash(_))
                        && !nullable_presence)
                {
                    return Ok(RuntimeValue::Undef);
                }
            }
            current = self.eval_receiver_dynamic_value_chain_call(
                current,
                call,
                index + 1 == calls.len(),
                ctx,
                rule_label,
            )?;
        }
        Ok(current)
    }

    fn eval_array_receiver_value_chain(
        &self,
        receiver: &linkedspec_core::expr::Expr,
        calls: &[linkedspec_core::expr::FluentCall],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        use linkedspec_core::expr::{Arg, Expr};

        #[derive(Clone, Copy, Eq, PartialEq)]
        enum ReceiverFamily {
            Array,
            Terminal,
        }

        let mut current = match receiver {
            Expr::Variable { name } => Self::scalar_held_array_snapshot(ctx, name)
                .map(RuntimeValue::Array)
                .unwrap_or_else(|| RuntimeValue::Array(ctx.array_snapshot(name))),
            _ => self.eval_expr(receiver, ctx, rule_label)?,
        };
        let mut family = ReceiverFamily::Array;

        for (index, call) in calls.iter().enumerate() {
            if family == ReceiverFamily::Terminal {
                return Ok(RuntimeValue::Undef);
            }
            if Self::is_generic_receiver_value_method(&call.method) {
                return self.eval_selected_receiver_value_chain(
                    current,
                    &calls[index..],
                    false,
                    ctx,
                    rule_label,
                );
            }
            if Self::is_statement_only_array_end_mutation_method(&call.method)
                || (!Self::is_array_receiver_value_chain_method(&call.method)
                    && call.method != "length")
            {
                return Ok(RuntimeValue::Undef);
            }

            let evaluated_call_args: Vec<RuntimeValue> = call
                .args
                .iter()
                .map(|arg| self.eval_expr(arg.value(), ctx, rule_label))
                .collect::<Result<Vec<_>, _>>()?;

            let receiver_arg = Arg::Positional(Expr::Undef);
            let (raw_args, evaluated) = if call.method == "join_values" {
                let mut raw = call.args.clone();
                raw.push(receiver_arg);
                let mut vals = evaluated_call_args;
                vals.push(current);
                (raw, vals)
            } else {
                let mut raw = Vec::with_capacity(call.args.len() + 1);
                raw.push(receiver_arg);
                raw.extend(call.args.clone());
                let mut vals = Vec::with_capacity(evaluated_call_args.len() + 1);
                vals.push(current);
                vals.extend(evaluated_call_args);
                (raw, vals)
            };

            current =
                self.call_helper_with_args(&call.method, &raw_args, &evaluated, ctx, rule_label)?;
            if Self::is_selected_receiver_result_method(&call.method) {
                return self.eval_selected_receiver_value_chain(
                    current,
                    &calls[index + 1..],
                    Self::is_scalar_result_receiver_method(&call.method),
                    ctx,
                    rule_label,
                );
            }
            family = match call.method.as_str() {
                "copy" | "sorted" | "reversed" | "take" | "take_last" | "drop_front"
                | "drop_back" | "slice" | "concat_arrays" | "split_each" | "trim_each"
                | "filter_nonempty" | "lowercase_each" | "uppercase_each" | "uniq"
                | "filter_match" => ReceiverFamily::Array,
                _ => {
                    if index + 1 != calls.len() {
                        return Ok(RuntimeValue::Undef);
                    }
                    ReceiverFamily::Terminal
                }
            };
        }

        Ok(current)
    }

    fn eval_hash_receiver_value_chain(
        &self,
        receiver: &linkedspec_core::expr::Expr,
        calls: &[linkedspec_core::expr::FluentCall],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        use linkedspec_core::expr::{Arg, Expr};

        #[derive(Clone, Copy, Eq, PartialEq)]
        enum ReceiverFamily {
            Hash,
            Array,
            Terminal,
        }

        let mut current = match receiver {
            Expr::Variable { name } => Self::scalar_held_hash_snapshot(ctx, name)
                .map(RuntimeValue::Hash)
                .unwrap_or_else(|| RuntimeValue::Hash(ctx.hash_snapshot(name))),
            _ => self.eval_expr(receiver, ctx, rule_label)?,
        };
        let mut family = ReceiverFamily::Hash;

        for (index, call) in calls.iter().enumerate() {
            if family == ReceiverFamily::Terminal {
                return Ok(RuntimeValue::Undef);
            }
            if Self::is_generic_receiver_value_method(&call.method) {
                return self.eval_selected_receiver_value_chain(
                    current,
                    &calls[index..],
                    false,
                    ctx,
                    rule_label,
                );
            }

            let evaluated_call_args: Vec<RuntimeValue> = call
                .args
                .iter()
                .map(|arg| self.eval_expr(arg.value(), ctx, rule_label))
                .collect::<Result<Vec<_>, _>>()?;

            let receiver_arg = Arg::Positional(Expr::Undef);
            let (raw_args, evaluated) =
                if family == ReceiverFamily::Array && call.method == "join_values" {
                    let mut raw = call.args.clone();
                    raw.push(receiver_arg);
                    let mut vals = evaluated_call_args;
                    vals.push(current);
                    (raw, vals)
                } else {
                    let mut raw = Vec::with_capacity(call.args.len() + 1);
                    raw.push(receiver_arg);
                    raw.extend(call.args.clone());
                    let mut vals = Vec::with_capacity(evaluated_call_args.len() + 1);
                    vals.push(current);
                    vals.extend(evaluated_call_args);
                    (raw, vals)
                };

            match family {
                ReceiverFamily::Hash => {
                    if !Self::is_hash_receiver_value_chain_method(&call.method) {
                        return Ok(RuntimeValue::Undef);
                    }
                    current = self.call_helper_with_args(
                        &call.method,
                        &raw_args,
                        &evaluated,
                        ctx,
                        rule_label,
                    )?;
                    if Self::is_selected_receiver_result_method(&call.method) {
                        return self.eval_selected_receiver_value_chain(
                            current,
                            &calls[index + 1..],
                            Self::is_scalar_result_receiver_method(&call.method),
                            ctx,
                            rule_label,
                        );
                    }
                    if Self::is_hash_receiver_hash_returning_method(&call.method) {
                        family = ReceiverFamily::Hash;
                    } else if Self::is_hash_receiver_array_returning_method(&call.method) {
                        family = ReceiverFamily::Array;
                    } else {
                        if index + 1 != calls.len() {
                            return Ok(RuntimeValue::Undef);
                        }
                        family = ReceiverFamily::Terminal;
                    }
                }
                ReceiverFamily::Array => {
                    if Self::is_statement_only_array_end_mutation_method(&call.method)
                        || (!Self::is_array_receiver_value_chain_method(&call.method)
                            && call.method != "length")
                    {
                        return Ok(RuntimeValue::Undef);
                    }
                    current = self.call_helper_with_args(
                        &call.method,
                        &raw_args,
                        &evaluated,
                        ctx,
                        rule_label,
                    )?;
                    if Self::is_selected_receiver_result_method(&call.method) {
                        return self.eval_selected_receiver_value_chain(
                            current,
                            &calls[index + 1..],
                            Self::is_scalar_result_receiver_method(&call.method),
                            ctx,
                            rule_label,
                        );
                    }
                    family = match call.method.as_str() {
                        "copy" | "sorted" | "reversed" | "take" | "take_last" | "drop_front"
                        | "drop_back" | "slice" | "concat_arrays" | "split_each" | "trim_each"
                        | "filter_nonempty" | "lowercase_each" | "uppercase_each" | "uniq"
                        | "filter_match" => ReceiverFamily::Array,
                        _ => ReceiverFamily::Terminal,
                    };
                }
                ReceiverFamily::Terminal => return Ok(RuntimeValue::Undef),
            }
        }

        Ok(current)
    }

    fn eval_string_receiver_value_chain(
        &self,
        receiver: &linkedspec_core::expr::Expr,
        calls: &[linkedspec_core::expr::FluentCall],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        use linkedspec_core::expr::{Arg, Expr};

        #[derive(Clone, Copy, Eq, PartialEq)]
        enum ReceiverFamily {
            String,
            Array,
            Terminal,
        }

        let mut current = self.eval_expr(receiver, ctx, rule_label)?;
        let mut family = ReceiverFamily::String;

        for (index, call) in calls.iter().enumerate() {
            if family == ReceiverFamily::Terminal {
                return Ok(RuntimeValue::Undef);
            }
            let numeric_method = family == ReceiverFamily::String
                && Self::is_number_receiver_value_chain_method(&call.method);
            if Self::is_generic_receiver_value_method(&call.method) || numeric_method {
                return self.eval_selected_receiver_value_chain(
                    current,
                    &calls[index..],
                    numeric_method,
                    ctx,
                    rule_label,
                );
            }

            if family == ReceiverFamily::String
                && matches!(call.method.as_str(), "coalesce" | "coalesce_nonempty")
            {
                current = self.eval_string_receiver_dynamic_value_call(
                    current,
                    call,
                    index + 1 == calls.len(),
                    ctx,
                    rule_label,
                )?;
                let scalar_result =
                    !matches!(current, RuntimeValue::Array(_) | RuntimeValue::Hash(_));
                if !scalar_result {
                    return self.eval_kind_guarded_receiver_value_chain(
                        current,
                        &calls[index + 1..],
                        ctx,
                        rule_label,
                    );
                }
                return self.eval_selected_receiver_value_chain(
                    current,
                    &calls[index + 1..],
                    scalar_result,
                    ctx,
                    rule_label,
                );
            }

            let evaluated_call_args: Vec<RuntimeValue> = call
                .args
                .iter()
                .map(|arg| self.eval_expr(arg.value(), ctx, rule_label))
                .collect::<Result<Vec<_>, _>>()?;

            let receiver_arg = Arg::Positional(Expr::Undef);
            let (raw_args, evaluated) =
                if family == ReceiverFamily::Array && call.method == "join_values" {
                    let mut raw = call.args.clone();
                    raw.push(receiver_arg);
                    let mut vals = evaluated_call_args;
                    vals.push(current);
                    (raw, vals)
                } else {
                    let mut raw = Vec::with_capacity(call.args.len() + 1);
                    raw.push(receiver_arg);
                    raw.extend(call.args.clone());
                    let mut vals = Vec::with_capacity(evaluated_call_args.len() + 1);
                    vals.push(current);
                    vals.extend(evaluated_call_args);
                    (raw, vals)
                };

            match family {
                ReceiverFamily::String => {
                    if !Self::is_string_receiver_value_chain_method(&call.method) {
                        return Ok(RuntimeValue::Undef);
                    }
                    current = self.call_helper_with_args(
                        &call.method,
                        &raw_args,
                        &evaluated,
                        ctx,
                        rule_label,
                    )?;
                    if Self::is_selected_receiver_result_method(&call.method) {
                        return self.eval_selected_receiver_value_chain(
                            current,
                            &calls[index + 1..],
                            Self::is_scalar_result_receiver_method(&call.method),
                            ctx,
                            rule_label,
                        );
                    }
                    if Self::is_string_receiver_string_returning_method(&call.method) {
                        family = ReceiverFamily::String;
                    } else if Self::is_string_receiver_array_returning_method(&call.method) {
                        family = ReceiverFamily::Array;
                    } else {
                        if index + 1 != calls.len() {
                            return Ok(RuntimeValue::Undef);
                        }
                        family = ReceiverFamily::Terminal;
                    }
                }
                ReceiverFamily::Array => {
                    if Self::is_statement_only_array_end_mutation_method(&call.method)
                        || (!Self::is_array_receiver_value_chain_method(&call.method)
                            && call.method != "length")
                    {
                        return Ok(RuntimeValue::Undef);
                    }
                    current = self.call_helper_with_args(
                        &call.method,
                        &raw_args,
                        &evaluated,
                        ctx,
                        rule_label,
                    )?;
                    if Self::is_selected_receiver_result_method(&call.method) {
                        return self.eval_selected_receiver_value_chain(
                            current,
                            &calls[index + 1..],
                            Self::is_scalar_result_receiver_method(&call.method),
                            ctx,
                            rule_label,
                        );
                    }
                    family = match call.method.as_str() {
                        "copy" | "sorted" | "reversed" | "take" | "take_last" | "drop_front"
                        | "drop_back" | "slice" | "concat_arrays" | "split_each" | "trim_each"
                        | "filter_nonempty" | "lowercase_each" | "uppercase_each" | "uniq"
                        | "filter_match" => ReceiverFamily::Array,
                        _ => ReceiverFamily::Terminal,
                    };
                }
                ReceiverFamily::Terminal => return Ok(RuntimeValue::Undef),
            }
        }

        Ok(current)
    }

    fn eval_number_receiver_value_chain(
        &self,
        receiver: &linkedspec_core::expr::Expr,
        calls: &[linkedspec_core::expr::FluentCall],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let current = self.eval_expr(receiver, ctx, rule_label)?;
        self.eval_selected_receiver_value_chain(current, calls, true, ctx, rule_label)
    }

    fn eval_block_value(
        &self,
        block: &linkedspec_core::expr::CodeBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let Some(last_index) = block.statements.len().checked_sub(1) else {
            return Ok(RuntimeValue::Undef);
        };

        let mut if_stack: Vec<StatementIfFrame> = Vec::new();
        let mut switch_stack: Vec<StatementSwitchFrame> = Vec::new();
        for (index, stmt) in block.statements.iter().enumerate() {
            let parent_active = Self::statement_controls_active(&if_stack, &switch_stack);
            if self.handle_statement_if_control(
                &stmt.expr,
                &mut if_stack,
                parent_active,
                ctx,
                rule_label,
            )? {
                continue;
            }
            let parent_active = Self::statement_controls_active(&if_stack, &switch_stack);
            if self.handle_statement_switch_control(
                &stmt.expr,
                &mut switch_stack,
                parent_active,
                ctx,
                rule_label,
            )? {
                continue;
            }
            if !Self::statement_controls_active(&if_stack, &switch_stack) {
                continue;
            }
            if let Some(flow) = self.eval_value_while_loop(&stmt.expr, ctx, rule_label)? {
                match flow {
                    ValueBlockFlow::Continue => {
                        if index == last_index {
                            return Ok(RuntimeValue::Undef);
                        }
                        continue;
                    }
                    ValueBlockFlow::Returned(value) => return Ok(value),
                }
            }
            if let Some(payload) = Self::return_call_payload(&stmt.expr) {
                return match payload {
                    Some(value) => self.eval_expr(value, ctx, rule_label),
                    None => Ok(RuntimeValue::Undef),
                };
            }
            if index == last_index {
                return self.eval_block_final_expr(&stmt.expr, ctx, rule_label);
            }
            self.execute_block_statement_expr(&stmt.expr, ctx, rule_label)?;
        }
        Ok(RuntimeValue::Undef)
    }

    fn execute_value_block_side_effects(
        &self,
        block: &linkedspec_core::expr::CodeBlock,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<ValueBlockFlow, String> {
        let mut if_stack: Vec<StatementIfFrame> = Vec::new();
        let mut switch_stack: Vec<StatementSwitchFrame> = Vec::new();
        for stmt in &block.statements {
            let parent_active = Self::statement_controls_active(&if_stack, &switch_stack);
            if self.handle_statement_if_control(
                &stmt.expr,
                &mut if_stack,
                parent_active,
                ctx,
                rule_label,
            )? {
                continue;
            }
            let parent_active = Self::statement_controls_active(&if_stack, &switch_stack);
            if self.handle_statement_switch_control(
                &stmt.expr,
                &mut switch_stack,
                parent_active,
                ctx,
                rule_label,
            )? {
                continue;
            }
            if !Self::statement_controls_active(&if_stack, &switch_stack) {
                continue;
            }
            if let Some(flow) = self.eval_value_while_loop(&stmt.expr, ctx, rule_label)? {
                match flow {
                    ValueBlockFlow::Continue => continue,
                    ValueBlockFlow::Returned(value) => return Ok(ValueBlockFlow::Returned(value)),
                }
            }
            if let Some(payload) = Self::return_call_payload(&stmt.expr) {
                return match payload {
                    Some(value) => self
                        .eval_expr(value, ctx, rule_label)
                        .map(ValueBlockFlow::Returned),
                    None => Ok(ValueBlockFlow::Returned(RuntimeValue::Undef)),
                };
            }
            self.execute_block_statement_expr(&stmt.expr, ctx, rule_label)?;
        }
        Ok(ValueBlockFlow::Continue)
    }

    fn eval_value_while_loop(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<Option<ValueBlockFlow>, String> {
        let Some((condition, body)) = Self::while_call_parts(expr) else {
            return Ok(None);
        };

        let mut iterations = 0usize;
        while self.eval_expr(condition, ctx, rule_label)?.as_bool() {
            iterations += 1;
            if iterations > LINKEDSPEC_WHILE_ITERATION_LIMIT {
                return Err(Self::while_iteration_limit_message());
            }
            match self.execute_value_block_side_effects(body, ctx, rule_label)? {
                ValueBlockFlow::Continue => {}
                ValueBlockFlow::Returned(value) => {
                    return Ok(Some(ValueBlockFlow::Returned(value)));
                }
            }
        }

        Ok(Some(ValueBlockFlow::Continue))
    }

    fn eval_block_final_expr(
        &self,
        expr: &linkedspec_core::expr::Expr,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        use linkedspec_core::expr::Expr;
        if let Some(payload) = Self::return_call_payload(expr) {
            return match payload {
                Some(value) => self.eval_expr(value, ctx, rule_label),
                None => Ok(RuntimeValue::Undef),
            };
        }

        match expr {
            Expr::AssignScalar { name, value } => {
                let evaluated = self.eval_expr(value, ctx, rule_label)?;
                ctx.set_scalar(name, evaluated.clone());
                Ok(evaluated)
            }
            Expr::AssignArrayAppend { name, value } => {
                self.eval_array_append_expression(name, value, ctx, rule_label)
            }
            Expr::AssignHashIndex { name, key, value } => {
                self.eval_hash_index_assignment_expression(name, key, value, ctx, rule_label)
            }
            Expr::AssignNestedAccess {
                base,
                segments,
                value,
                ..
            } => self
                .eval_nested_access_assignment_expression(base, segments, value, ctx, rule_label),
            _ => self.eval_expr(expr, ctx, rule_label),
        }
    }

    fn return_call_payload(
        expr: &linkedspec_core::expr::Expr,
    ) -> Option<Option<&linkedspec_core::expr::Expr>> {
        use linkedspec_core::expr::Expr;
        match expr {
            Expr::Call { name, args } if name == "return" => {
                Some(args.first().map(|arg| arg.value()))
            }
            Expr::Call { name, args } if name == "return_undef" && args.is_empty() => Some(None),
            _ => None,
        }
    }

    fn while_call_parts(
        expr: &linkedspec_core::expr::Expr,
    ) -> Option<(
        &linkedspec_core::expr::Expr,
        &linkedspec_core::expr::CodeBlock,
    )> {
        use linkedspec_core::expr::Expr;
        let Expr::Call { name, args } = expr else {
            return None;
        };
        if name != "while" || args.len() != 2 {
            return None;
        }
        let Expr::BlockValue { block } = args[1].value() else {
            return None;
        };
        Some((args[0].value(), block))
    }

    fn eval_with_trailing_block(
        &self,
        raw_args: &[linkedspec_core::expr::Arg],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        if raw_args.is_empty() || raw_args.len() > 2 {
            return Err(format!(
                "LINKEDSPEC_UNSUPPORTED_ACTIONIR_HELPER:with: helper `with(...) {{ ... }}` expects zero or one value argument plus a trailing block in rule '{rule_label}'"
            ));
        }

        let Some(block_arg) = raw_args.last() else {
            unreachable!("raw_args.is_empty() was checked above");
        };
        let scoped_value = if raw_args.len() == 2 {
            self.eval_expr(raw_args[0].value(), ctx, rule_label)?
        } else {
            RuntimeValue::Undef
        };
        let pass_scoped_value = !matches!(
            block_arg.value(),
            linkedspec_core::expr::Expr::CodeblockArgument(_)
        );
        // Evaluate the value argument first, then snapshot the callback in the caller.
        let callback = self.eval_expr(block_arg.value(), ctx, rule_label)?;
        let callback = self.require_final_codeblock_value("with", &callback, ctx, rule_label)?;
        let binding = ctx.enter_scoped_scalar_binding("value", scoped_value.clone());
        let args = if pass_scoped_value {
            vec![scoped_value]
        } else {
            Vec::new()
        };
        let result = self.execute_codeblock_value(
            "with",
            bare_variable_target_arg(block_arg),
            &callback,
            &args,
            ctx,
            rule_label,
        );
        ctx.exit_scoped_variable_binding(binding);
        result
    }

    fn while_iteration_limit_message() -> String {
        format!(
            "LinkedSpec while iteration safety limit exceeded after {} iterations",
            LINKEDSPEC_WHILE_ITERATION_LIMIT
        )
    }

    /// Resolve a scalar target name from an evaluated value.
    ///
    /// A bare target name in scalar-target position names the working variable
    /// itself.
    fn resolve_scalar_target(
        &self,
        raw_args: &[linkedspec_core::expr::Arg],
        val: &RuntimeValue,
    ) -> String {
        use linkedspec_core::expr::{Arg, Expr};
        // SPEC-FORMAT-TERSE.1.2.1 Channel 1 (Rust parity, .1.2.2): a BARE
        // (un-wrapped) name in the scalar-target position (e.g. v = ...) IS
        // the working variable itself — mirrors the Perl reference's `^(\w+)$`
        // fallback in ValueExpr::_extract_scalar_symbol_name. The per-parse
        // RuntimeContext HashMap auto-vivifies on set_scalar, so it auto-exists
        // without a separate declaration step and never leaks across parses
        // (fresh ctx per execute).
        if let Some(Arg::Positional(Expr::Variable { name: var_name })) = raw_args.first() {
            return var_name.clone();
        }
        val.to_str()
    }

    /// Resolve an array target name from the first arg of a helper call.
    fn resolve_array_target(
        &self,
        raw_args: &[linkedspec_core::expr::Arg],
        val: &RuntimeValue,
        allow_bare: bool,
    ) -> String {
        use linkedspec_core::expr::{Arg, Expr};
        // SPEC-FORMAT-TERSE.1.2.1 Channel 1 (Rust parity, .1.2.2): in a type-implying
        // array-TARGET position (`push`), a BARE (un-wrapped) name
        // IS the working array — mirrors the Perl reference's `^(\w+)$` fallback in
        // ValueExpr::_extract_array_symbol_name. SPEC-FORMAT-TERSE.1.2.3.2 extends
        // the same narrow aggregate-target interpretation to array snapshot reads
        // (array-first `copy(NAME)`). Scalar-like bare reads and bare direct-access
        // path atoms remain owned by later Channel 2 leaves.
        if let (true, Some(Arg::Positional(Expr::Variable { name: var_name }))) =
            (allow_bare, raw_args.first())
        {
            return var_name.clone();
        }
        val.to_str()
    }

    /// Resolve a hash target name from the first arg of a helper call.
    fn resolve_hash_target(
        &self,
        raw_args: &[linkedspec_core::expr::Arg],
        val: &RuntimeValue,
        allow_bare: bool,
    ) -> String {
        use linkedspec_core::expr::{Arg, Expr};
        if let (true, Some(Arg::Positional(Expr::Variable { name: var_name }))) =
            (allow_bare, raw_args.first())
        {
            return var_name.clone();
        }
        val.to_str()
    }

    fn hash_consuming_arg(
        &self,
        raw_args: &[linkedspec_core::expr::Arg],
        args: &[RuntimeValue],
        index: usize,
        _ctx: &RuntimeContext,
    ) -> RuntimeValue {
        use linkedspec_core::expr::{Arg, Expr};

        // Typed arguments were captured before later operand effects. Keep the
        // existing named wrong-kind/absent fallback without reading live bindings.
        let evaluated = args.get(index).cloned().unwrap_or(RuntimeValue::Undef);
        if matches!(
            raw_args.get(index),
            Some(Arg::Positional(Expr::Variable { .. }))
        ) && !matches!(evaluated, RuntimeValue::Hash(_))
        {
            return RuntimeValue::Hash(Vec::new());
        }
        evaluated
    }

    fn array_consuming_arg(
        &self,
        raw_args: &[linkedspec_core::expr::Arg],
        args: &[RuntimeValue],
        index: usize,
        _ctx: &RuntimeContext,
    ) -> RuntimeValue {
        use linkedspec_core::expr::{Arg, Expr};

        // Typed arguments were captured before later operand effects. Keep the
        // existing named wrong-kind/absent fallback without reading live bindings.
        let evaluated = args.get(index).cloned().unwrap_or(RuntimeValue::Undef);
        if matches!(
            raw_args.get(index),
            Some(Arg::Positional(Expr::Variable { .. }))
        ) && !matches!(evaluated, RuntimeValue::Array(_))
        {
            return RuntimeValue::Array(Vec::new());
        }
        evaluated
    }

    fn array_scalar_key(value: &RuntimeValue) -> Option<String> {
        match value {
            RuntimeValue::Undef => None,
            _ => Some(value.to_str()),
        }
    }

    fn is_list_context_splice_arg(raw_arg: &linkedspec_core::expr::Arg) -> bool {
        use linkedspec_core::expr::{Arg, Expr};

        matches!(
            raw_arg,
            Arg::Positional(Expr::Call { name, .. })
                if matches!(name.as_str(), "flat" | "flat_array" | "flat_hash")
        )
    }

    fn is_hash_context_splice_arg(raw_arg: &linkedspec_core::expr::Arg) -> bool {
        use linkedspec_core::expr::{Arg, Expr};

        matches!(
            raw_arg,
            Arg::Positional(Expr::Call { name, .. })
                if matches!(name.as_str(), "flat" | "flat_hash")
        )
    }

    fn push_list_context_values(target: &mut Vec<RuntimeValue>, value: &RuntimeValue) {
        match value {
            RuntimeValue::Array(items) => target.extend(items.iter().cloned()),
            RuntimeValue::Hash(entries) => {
                for (key, item) in entries {
                    target.push(RuntimeValue::Scalar(key.clone()));
                    target.push(item.clone());
                }
            }
            other => target.push(other.clone()),
        }
    }

    /// Resolve a child rule name from the first arg of a `call(...)` helper.
    ///
    /// A bare `call(RuleName)` names the target rule directly — its evaluated
    /// value would be undef (a rule label is not a scalar variable), so the name
    /// must come from the raw AST. Falls back to the evaluated value's
    /// `to_str()` for the quoted form `call("RuleName")`.
    fn resolve_rule_name(
        &self,
        raw_args: &[linkedspec_core::expr::Arg],
        val: Option<&RuntimeValue>,
    ) -> String {
        self.resolve_bare_identifier_at(raw_args, val, 0)
    }

    /// Preserve a bare identifier used as a symbolic helper argument.
    ///
    /// Rule labels, capture boundaries, and named marks are identifiers rather
    /// than scalar-variable reads. Quoted/dynamic forms still use the evaluated
    /// argument value.
    fn resolve_bare_identifier_at(
        &self,
        raw_args: &[linkedspec_core::expr::Arg],
        val: Option<&RuntimeValue>,
        index: usize,
    ) -> String {
        use linkedspec_core::expr::{Arg, Expr};
        if let Some(Arg::Positional(Expr::Variable { name })) = raw_args.get(index) {
            return name.clone();
        }
        val.map(|v| v.to_str()).unwrap_or_default()
    }

    fn resolve_named_capture_key(
        raw_args: &[linkedspec_core::expr::Arg],
        args: &[RuntimeValue],
    ) -> Option<String> {
        use linkedspec_core::expr::{Arg, Expr};
        if let Some(Arg::Positional(Expr::Variable { name })) = raw_args.first() {
            return Some(name.clone());
        }
        args.first().map(RuntimeValue::to_str)
    }

    fn coalesce_accepts(value: &RuntimeValue, require_nonempty: bool) -> bool {
        match value {
            RuntimeValue::Undef => false,
            RuntimeValue::Scalar(text) if require_nonempty => !text.is_empty(),
            _ => true,
        }
    }

    fn eval_coalesce_args(
        &self,
        args: &[linkedspec_core::expr::Arg],
        require_nonempty: bool,
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        for arg in args {
            let value = self.eval_expr(arg.value(), ctx, rule_label)?;
            if Self::coalesce_accepts(&value, require_nonempty) {
                return Ok(value);
            }
        }
        Ok(RuntimeValue::Undef)
    }

    /// Dispatch a lazy control or default-selection call.
    ///
    /// These calls receive unevaluated arg AST nodes; the handler evaluates
    /// conditions and branch bodies lazily via `self.eval_expr()`.
    fn call_helper_lazy(
        &self,
        name: &str,
        args: &[linkedspec_core::expr::Arg],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        ctx.trace_decision(
            "rust_runtime:engine:lazy_helper",
            true,
            format!("rule={rule_label} helper={name} arity={}", args.len()),
            TraceLevel::FULL,
        );
        if matches!(name, "coalesce" | "coalesce_nonempty") {
            return self.eval_coalesce_args(args, name == "coalesce_nonempty", ctx, rule_label);
        }
        let empty_vals: Vec<RuntimeValue> = Vec::new();
        self.call_helper(name, args, &empty_vals, ctx, rule_label)
    }

    /// Dispatch a helper call with keyword argument awareness.
    ///
    /// Extracts keyword arg names from the original `Arg` list and passes both
    /// original args and evaluated values to `call_helper`.
    fn call_helper_with_args(
        &self,
        name: &str,
        raw_args: &[linkedspec_core::expr::Arg],
        evaluated: &[RuntimeValue],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        self.call_helper(name, raw_args, evaluated, ctx, rule_label)
    }

    /// Dispatch a helper call by name with original args and evaluated args.
    fn call_helper(
        &self,
        name: &str,
        raw_args: &[linkedspec_core::expr::Arg],
        args: &[RuntimeValue],
        ctx: &mut RuntimeContext,
        rule_label: &str,
    ) -> Result<RuntimeValue, String> {
        let name = Self::numeric_word_helper_name(name).unwrap_or(name);
        validate_eager_helper_arity(name, raw_args, args.len(), ctx, rule_label)?;
        if Self::is_mark_capture_helper(name) {
            ctx.trace_mark(
                "rust_runtime:engine:mark_capture",
                format!(
                    "rule={rule_label} helper={name} arity={} pos={} match_start={} match_end={} capture_start={:?}",
                    args.len(),
                    ctx.pos,
                    ctx.match_start_byte,
                    ctx.match_end_byte,
                    ctx.capture_start
                ),
                TraceLevel::FULL,
            );
        }
        match name {
            "set" | "=" => {
                if args.len() >= 2 {
                    let target = self.resolve_scalar_target(raw_args, &args[0]);
                    ctx.set_scalar(&target, args[1].clone());
                    return Ok(args[1].clone());
                }
                Ok(RuntimeValue::Undef)
            }
            // ── Array constructors ──
            "array" => {
                // General constructor: `array(val1, val2, ...)`. Explicit
                // flattening helpers are list-context splices in the Perl
                // lowering, so `array(flat_array(items))` opens `items` into
                // this constructor while `array(copy(items))` stays nested.
                let mut values = Vec::new();
                for (raw_arg, value) in raw_args.iter().zip(args.iter()) {
                    if Self::is_list_context_splice_arg(raw_arg) {
                        Self::push_list_context_values(&mut values, value);
                    } else {
                        values.push(value.clone());
                    }
                }
                Ok(RuntimeValue::Array(values))
            }
            "copy" => {
                if let Some(arg) = args.first() {
                    match arg {
                        RuntimeValue::Array(a) => Ok(RuntimeValue::Array(a.clone())),
                        RuntimeValue::Hash(h) => Ok(RuntimeValue::Hash(h.clone())),
                        RuntimeValue::Bool(_)
                        | RuntimeValue::Number(_)
                        | RuntimeValue::Scalar(_)
                        | RuntimeValue::Undef
                            if args.len() == 1 =>
                        {
                            Ok(arg.clone())
                        }
                        _ => {
                            let arr_name = self.resolve_array_target(raw_args, arg, true);
                            if !arr_name.is_empty() {
                                if let Some(values) =
                                    Self::scalar_held_array_snapshot(ctx, &arr_name)
                                {
                                    return Ok(RuntimeValue::Array(values));
                                }
                                Ok(RuntimeValue::Array(ctx.array_snapshot(&arr_name)))
                            } else {
                                let hash_name = self.resolve_hash_target(raw_args, arg, true);
                                if !hash_name.is_empty() {
                                    if let Some(values) =
                                        Self::scalar_held_hash_snapshot(ctx, &hash_name)
                                    {
                                        return Ok(RuntimeValue::Hash(values));
                                    }
                                    Ok(RuntimeValue::Hash(ctx.hash_snapshot(&hash_name)))
                                } else {
                                    Ok(RuntimeValue::Array(Vec::new()))
                                }
                            }
                        }
                    }
                } else {
                    Ok(RuntimeValue::Array(Vec::new()))
                }
            }
            // ── Accumulator ──
            "push" => {
                if args.len() >= 2 {
                    let arr_name = self.resolve_array_target(raw_args, &args[0], true);
                    if raw_args
                        .first()
                        .and_then(bare_variable_target_arg)
                        .is_some()
                    {
                        return ctx.push_bare_array_value(&arr_name, args[1].clone());
                    }
                    ctx.push_array_value(&arr_name, args[1].clone());
                    return Ok(RuntimeValue::Array(ctx.get_array(&arr_name)));
                }
                Ok(RuntimeValue::Undef)
            }
            "return" => {
                if let Some(val) = args.first() {
                    // Preserve the accumulator contract (execute() returns it)…
                    ctx.push_accumulator(val.clone());
                    // …and record this rule's return value so a parent can read
                    // it as `retv` after dispatch (Runtime Semantics §5.4).
                    ctx.set_return_value(val.clone());
                }
                Ok(RuntimeValue::Undef)
            }
            "return_undef" => {
                ctx.set_return_value(RuntimeValue::Undef);
                Ok(RuntimeValue::Undef)
            }
            "call" => {
                // `call(child)` evaluates to the child's return value, so
                // `retv = call(child)` captures it — the Perl
                // reference pattern (see specs/tablegrep.spec). The child rule
                // name comes from the raw arg (a bare label is not a scalar).
                let child = self.resolve_rule_name(raw_args, args.first());
                if !child.is_empty() {
                    ctx.trace_decision(
                        "rust_runtime:engine:helper_call_dispatch",
                        true,
                        format!("rule={rule_label} child={child} pos={}", ctx.pos),
                        TraceLevel::MEDIUM,
                    );
                    if let Some(value) = ctx.action_edge_call_result(&child) {
                        return Ok(value);
                    }
                    let child_retv = self.execute_child_rule(&child, 0, ctx)?;
                    return Ok(child_retv);
                }
                Ok(RuntimeValue::Undef)
            }
            // ── Scalar/string ──
            "cat" => {
                let Some(parts) = args
                    .iter()
                    .map(RuntimeValue::to_scalar_text)
                    .collect::<Option<Vec<_>>>()
                else {
                    return Ok(RuntimeValue::Undef);
                };
                Ok(RuntimeValue::Scalar(parts.concat()))
            }
            "coalesce" => {
                for a in args {
                    if Self::coalesce_accepts(a, false) {
                        return Ok(a.clone());
                    }
                }
                Ok(RuntimeValue::Undef)
            }
            "count" => {
                if let Some(RuntimeValue::Array(array)) = args.first() {
                    Ok(RuntimeValue::Number(array.len() as f64))
                } else {
                    Ok(RuntimeValue::Number(0.0))
                }
            }
            "first" => {
                if let RuntimeValue::Array(arr) = self.array_consuming_arg(raw_args, args, 0, ctx) {
                    Ok(arr.first().cloned().unwrap_or(RuntimeValue::Undef))
                } else if let Some(arg) = args.first() {
                    let arr_name = arg.to_str();
                    let arr = ctx.get_array(&arr_name);
                    Ok(arr.first().cloned().unwrap_or(RuntimeValue::Undef))
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "last" => {
                if let RuntimeValue::Array(arr) = self.array_consuming_arg(raw_args, args, 0, ctx) {
                    Ok(arr.last().cloned().unwrap_or(RuntimeValue::Undef))
                } else if let Some(arg) = args.first() {
                    let arr_name = arg.to_str();
                    let arr = ctx.get_array(&arr_name);
                    Ok(arr.last().cloned().unwrap_or(RuntimeValue::Undef))
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            // ── Entry/match ──
            "entry_slot" => Ok(ctx.gap_entry_slot_value()),
            "gap_span" => match ctx.gap_span_value(name) {
                Ok(value) => Ok(value),
                Err(error) => {
                    ctx.capture_portable_diagnostic_failure(
                        "access_gap_context",
                        "gap_capture_context_unavailable",
                        "Rust inter-match gap context is unavailable",
                        Some(rule_label),
                    );
                    Err(error)
                }
            },
            "gap_text" => match ctx.gap_text_value(name) {
                Ok(value) => Ok(value),
                Err(error) => {
                    ctx.capture_portable_diagnostic_failure(
                        "access_gap_context",
                        "gap_capture_context_unavailable",
                        "Rust inter-match gap context is unavailable",
                        Some(rule_label),
                    );
                    Err(error)
                }
            },
            "gap_kind" => match ctx.gap_kind_value(name) {
                Ok(value) => Ok(value),
                Err(error) => {
                    ctx.capture_portable_diagnostic_failure(
                        "access_gap_context",
                        "gap_capture_context_unavailable",
                        "Rust inter-match gap context is unavailable",
                        Some(rule_label),
                    );
                    Err(error)
                }
            },
            "entry_text" => Ok(RuntimeValue::Scalar(
                ctx.typed_span_text_from_bytes(
                    ctx.entry_start_byte,
                    ctx.entry_end_byte,
                    rule_label,
                    name,
                )
                .unwrap_or_default(),
            )),
            "entry_group" => {
                if let Some(arg) = args.first() {
                    let idx = arg.as_number().unwrap_or(0.0) as usize;
                    Ok(RuntimeContext::project_capture_group_text(
                        ctx.entry_groups.get(idx),
                    ))
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "entry_groups" => Ok(RuntimeContext::project_capture_group_list(
                &ctx.entry_groups,
            )),
            // Named-capture readers for the ENTRY match — the regex capture that
            // triggered this rule's code (Helper Contract Catalog §8). They read
            // the populated `ctx.entry_named` map. `entry_named_map` is a retired
            // alias of `entry_map`: identical behavior, accepted for legacy specs.
            "entry_named" => Ok(match Self::resolve_named_capture_key(raw_args, args) {
                Some(name) => {
                    RuntimeContext::project_capture_group_text(ctx.entry_named.get(&name))
                }
                None => RuntimeValue::Undef,
            }),
            "entry_has" => Ok(RuntimeContext::project_capture_group_exists(
                Self::resolve_named_capture_key(raw_args, args)
                    .map(|name| ctx.entry_named.contains_key(&name))
                    .unwrap_or(false),
            )),
            "entry_map" | "entry_named_map" => {
                Ok(RuntimeContext::project_capture_group_map(&ctx.entry_named))
            }
            "match_text" => Ok(if ctx.match_present {
                RuntimeValue::Scalar(
                    ctx.typed_span_text_from_bytes(
                        ctx.match_start_byte,
                        ctx.match_end_byte,
                        rule_label,
                        name,
                    )
                    .unwrap_or_default(),
                )
            } else {
                RuntimeValue::Undef
            }),
            "exit_now" => {
                let status = args.first().and_then(|a| a.as_number()).unwrap_or(1.0) as i32;
                ctx.exit_status = Some(status);
                Err(format!("exit_now({status})"))
            }
            // `print` is handled by the consolidated `say | print | print_each`
            // arm below. (RUST-PARITY.5.4 removed earlier shadowing duplicates
            // so the more complete hash behavior remains in the current arms.)
            // ── String/array index ──
            "substr" | "regex_subst" => {
                if let Some((target, pattern_idx, replacement_idx, flags_idx)) =
                    regex_subst_call_parts(raw_args)
                {
                    let pattern = literal_or_value_arg_text(raw_args, args, pattern_idx);
                    let replacement = literal_or_value_arg_text(raw_args, args, replacement_idx);
                    let flags = regex_subst_flags_arg(raw_args, args, flags_idx);
                    let effective_pattern = regex_subst_pattern_with_flags(&pattern, &flags);
                    let re = rgx_core::Regex::compile(&effective_pattern).map_err(|e| {
                        format!(
                            "regex_subst({target}) in rule '{rule_label}' has invalid pattern /{pattern}/: {e}"
                        )
                    })?;
                    let current = ctx.get_scalar(&target).to_str();
                    let updated = if flags.contains('g') {
                        re.replace_all(&current, replacement.as_str()).into_owned()
                    } else {
                        re.replace(&current, replacement.as_str()).into_owned()
                    };
                    ctx.set_scalar(&target, RuntimeValue::Scalar(updated));
                    return Ok(RuntimeValue::Undef);
                }
                if name == "regex_subst" {
                    return Ok(RuntimeValue::Undef);
                }
                // Explicit null operands belong to ordinary value slicing;
                // the dedicated named-target mutation route has already returned.
                if matches!(args.len(), 2 | 3)
                    && args
                        .iter()
                        .any(|value| matches!(value, RuntimeValue::Undef))
                {
                    return Ok(RuntimeValue::Undef);
                }
                let offset = |value: &RuntimeValue| {
                    value
                        .as_number()
                        .filter(|number| {
                            number.is_finite() && *number >= 0.0 && number.fract() == 0.0
                        })
                        .unwrap_or(0.0) as usize
                };
                // Char-based (Perl `substr`): start/len are character offsets, so
                // byte-slicing would panic on a multibyte boundary and diverge.
                if args.len() >= 3 {
                    let s = args[0].to_str();
                    let start = offset(&args[1]);
                    let len = offset(&args[2]);
                    Ok(RuntimeValue::Scalar(char_substr(&s, start, len)))
                } else if args.len() == 2 {
                    let s = args[0].to_str();
                    let start = offset(&args[1]);
                    Ok(RuntimeValue::Scalar(char_substr_from(&s, start)))
                } else {
                    Ok(RuntimeValue::Scalar(
                        args.first().map(|a| a.to_str()).unwrap_or_default(),
                    ))
                }
            }
            "join_values" => {
                if args.len() >= 2 {
                    let delim = args[0].to_str();
                    let arr = &args[1];
                    let parts: Vec<String> = match arr {
                        RuntimeValue::Array(items) => items.iter().map(|v| v.to_str()).collect(),
                        _ => vec![arr.to_str()],
                    };
                    Ok(RuntimeValue::Scalar(parts.join(&delim)))
                } else {
                    Ok(RuntimeValue::Scalar(String::new()))
                }
            }
            "split" => {
                if let Some((target, source_idx, delimiter_idx)) =
                    split_statement_call_parts(raw_args)
                {
                    let source = args
                        .get(source_idx)
                        .map(RuntimeValue::to_str)
                        .unwrap_or_default();
                    let delimiter = args
                        .get(delimiter_idx)
                        .cloned()
                        .unwrap_or(RuntimeValue::Undef);
                    let parts = split_string_for_arg(&source, raw_args, delimiter_idx, &delimiter)?;
                    if raw_args
                        .get(source_idx.saturating_sub(1))
                        .and_then(bare_variable_target_arg)
                        .is_some()
                    {
                        return ctx.replace_bare_array(&target, parts);
                    }
                    ctx.set_array(&target, parts.clone());
                    return Ok(RuntimeValue::Array(parts));
                }
                if args.len() >= 2 {
                    let s = args[0].to_str();
                    Ok(RuntimeValue::Array(split_string_for_arg(
                        &s, raw_args, 1, &args[1],
                    )?))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "split_tagged_records" => {
                if args.len() < 3 {
                    return Ok(RuntimeValue::Undef);
                }
                // Arguments are already owned, eager snapshots. Reuse pure
                // split's literal/regex and boundary policy before making rows.
                let source = args[0].to_str();
                let items = split_string_for_arg(&source, raw_args, 1, &args[1])?;
                let tag = RuntimeValue::Scalar(args[2].to_str());
                let records = items
                    .into_iter()
                    .map(|item| {
                        let mut record = Vec::with_capacity(args.len() - 1);
                        record.push(tag.clone());
                        record.push(item);
                        record.extend_from_slice(&args[3..]);
                        RuntimeValue::Array(record)
                    })
                    .collect();
                Ok(RuntimeValue::Array(records))
            }
            "split_each" => {
                if let Some(arr) = args.first() {
                    match arr {
                        RuntimeValue::Array(items) => {
                            let delimiter = args.get(1).cloned().unwrap_or(RuntimeValue::Undef);
                            let mut result = Vec::new();
                            for item in items {
                                let value = item.to_str();
                                result
                                    .extend(split_string_for_arg(&value, raw_args, 1, &delimiter)?);
                            }
                            Ok(RuntimeValue::Array(result))
                        }
                        _ => Ok(RuntimeValue::Array(vec![])),
                    }
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "trim_each" | "lowercase_each" | "uppercase_each" => {
                if let Some(RuntimeValue::Array(items)) = args.first() {
                    let transformed: Vec<RuntimeValue> = items
                        .iter()
                        .map(|v| {
                            let s = v.to_str();
                            let s = match name {
                                "trim_each" => s.trim().to_string(),
                                "lowercase_each" => crate::unicode_case_mapping::lowercase(&s),
                                "uppercase_each" => crate::unicode_case_mapping::uppercase(&s),
                                _ => s,
                            };
                            RuntimeValue::Scalar(s)
                        })
                        .collect();
                    Ok(RuntimeValue::Array(transformed))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "filter_nonempty" => {
                if let Some(RuntimeValue::Array(items)) = args.first() {
                    Ok(RuntimeValue::Array(
                        items.iter().filter(|v| v.is_nonempty()).cloned().collect(),
                    ))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "filter_match" => {
                if let Some(RuntimeValue::Array(items)) = args.first() {
                    let pattern = args.get(1).map(|a| a.to_str()).unwrap_or_default();
                    let re = rgx_core::Regex::compile(&pattern);
                    match re {
                        Ok(re) => Ok(RuntimeValue::Array(
                            items
                                .iter()
                                .filter(|v| re.is_match(&v.to_str()))
                                .cloned()
                                .collect(),
                        )),
                        Err(e) => {
                            eprintln!(
                                "warning: filter_match: invalid regex '/{}/': {} — returning empty",
                                pattern, e
                            );
                            Ok(RuntimeValue::Array(vec![]))
                        }
                    }
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "uniq" => {
                if let Some(RuntimeValue::Array(items)) = args.first() {
                    let mut seen = std::collections::HashSet::new();
                    let uniq: Vec<RuntimeValue> = items
                        .iter()
                        .filter(|v| seen.insert(Self::array_scalar_key(v)))
                        .cloned()
                        .collect();
                    Ok(RuntimeValue::Array(uniq))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "say" | "print" | "print_each" => {
                if name == "print_each" {
                    if let Some(RuntimeValue::Array(items)) = args.first() {
                        let prefix = args.get(1).map(RuntimeValue::to_str).unwrap_or_default();
                        let suffix = args.get(2).map(RuntimeValue::to_str).unwrap_or_default();
                        for item in items {
                            ctx.emit_diagnostic_output(RuntimeDiagnosticOutputEvent {
                                helper_name: name.to_string(),
                                rule_label: rule_label.to_string(),
                                message: format!("{prefix}{}{suffix}", item.to_str()),
                            })?;
                        }
                    }
                } else {
                    let mut message = args.iter().map(RuntimeValue::to_str).collect::<String>();
                    if name == "say" {
                        message.push('\n');
                    }
                    ctx.emit_diagnostic_output(RuntimeDiagnosticOutputEvent {
                        helper_name: name.to_string(),
                        rule_label: rule_label.to_string(),
                        message,
                    })?;
                }
                Ok(RuntimeValue::Undef)
            }
            // ── Position/cursor ── (DSL-facing positions/lengths are char-based)
            "cursor_pos" => Ok(ctx
                .typed_position_offset_from_byte(ctx.pos, rule_label, name)
                .map(|offset| RuntimeValue::Number(offset as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "cursor_line" => Ok(ctx
                .typed_position_line_from_byte(ctx.pos, rule_label, name)
                .map(|line| RuntimeValue::Number(line as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "cursor_col" => Ok(ctx
                .typed_position_column_from_byte(ctx.pos, rule_label, name)
                .map(|column| RuntimeValue::Number(column as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "cursor_rest" => Ok(ctx
                .typed_span_text_from_bytes(ctx.pos, ctx.input.len(), rule_label, name)
                .map(RuntimeValue::Scalar)
                .unwrap_or(RuntimeValue::Undef)),
            "cursor_rest_len" => Ok(ctx
                .typed_span_length_from_bytes(ctx.pos, ctx.input.len(), rule_label, name)
                .map(|length| RuntimeValue::Number(length as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "input_text" => Ok(ctx
                .typed_source_text(rule_label, name)
                .map(RuntimeValue::Scalar)
                .unwrap_or(RuntimeValue::Undef)),
            "input_len" => Ok(ctx
                .typed_source_length()
                .map(|length| RuntimeValue::Number(length as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "input_slice" => {
                // start/width are char offsets (Perl parity); char-slice, no panic.
                if args.len() >= 2 {
                    let start = args[0].as_number().unwrap_or(0.0) as usize;
                    let width = args[1].as_number().unwrap_or(0.0) as usize;
                    Ok(ctx
                        .typed_source_slice(start, width, rule_label, name)
                        .map(RuntimeValue::Scalar)
                        .unwrap_or(RuntimeValue::Undef))
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "input_end_pos" => Ok(ctx
                .typed_position_offset_from_byte(ctx.input.len(), rule_label, name)
                .map(|offset| RuntimeValue::Number(offset as f64))
                .unwrap_or(RuntimeValue::Undef)),
            // RUST-PARITY.5.5.2 — whole-input right-edge location, char-based, no stored mark.
            // Perl reference: `input_end_line()` lowers to `1 + (newline count over the whole
            // input)` (Contracts.pm INPUT_END_LINE_READ); `input_end_col()` lowers to the column
            // at `length($$STRING)` via `_build_column_read_expr` — char distance past the last
            // newline, or `length + 1` when the input has none. Newline counts are byte/char
            // identical, so line uses a plain `'\n'` count; the column is char-based.
            "input_end_line" => Ok(ctx
                .typed_position_line_from_byte(ctx.input.len(), rule_label, name)
                .map(|line| RuntimeValue::Number(line as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "input_end_col" => Ok(ctx
                .typed_position_column_from_byte(ctx.input.len(), rule_label, name)
                .map(|column| RuntimeValue::Number(column as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "start_capture_slice" | "capture_slice_here" => {
                if ctx.typed_position_is_valid_byte(ctx.pos, rule_label, name) {
                    ctx.capture_start = Some(ctx.pos);
                }
                Ok(RuntimeValue::Undef)
            }
            "start_capture_slice_from" => {
                let name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                if let Some(mark) =
                    ctx.typed_mark_byte(rule_label, &name, "start_capture_slice_from")
                {
                    ctx.capture_start = Some(mark);
                }
                Ok(RuntimeValue::Undef)
            }
            "capture_slice" | "capture_from_rule_start" => {
                // RUST-PARITY.5.5.4: ends at the START of the current local match
                // (`ctx.match_start_byte`, Perl `$LSPOS - length $LMATCH`), not the
                // cursor as before this leaf — `capture_slice` is the anonymous
                // counterpart of the mark-based `capture_from` (.5.5.3), so the
                // captured text is everything between `capture_start` and the match.
                // Offset zero alone cannot distinguish absence from an empty match.
                if !ctx.match_present {
                    return Ok(RuntimeValue::Undef);
                }
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_text_from_bytes(start, ctx.match_start_byte, rule_label, name)
                    .map(RuntimeValue::Scalar)
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_slice_len" | "capture_slice_length" | "capture_len_from_rule_start" => {
                if !ctx.match_present {
                    return Ok(RuntimeValue::Undef);
                }
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_length_from_bytes(start, ctx.match_start_byte, rule_label, name)
                    .map(|n| RuntimeValue::Number(n as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_slice_line" => {
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_start_line_from_bytes(start, start, rule_label, name)
                    .map(|line| RuntimeValue::Number(line as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_slice_pos" => {
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_start_offset_from_bytes(start, start, rule_label, name)
                    .map(|offset| RuntimeValue::Number(offset as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_slice_col" => {
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_start_column_from_bytes(start, start, rule_label, name)
                    .map(|column| RuntimeValue::Number(column as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            // ── RUST-PARITY.5.5.4: anonymous capture-slice family ──
            // These read the anonymous capture start `ctx.capture_start` (Perl
            // `$IPOS`, set by `start_capture_slice()`), not a named mark — the
            // anonymous counterparts of the mark-based `.5.5.3` family.
            // Authoritative contract: `perl/LinkedSpec/ActionIR/Contracts.pm`
            // ~366–656. Endpoints (byte offsets): the START of the current local
            // match (`$LSPOS - length $LMATCH` = `ctx.match_start_byte`) for
            // `capture_take`(+`_len`); the cursor (`pos` = `ctx.pos`) for
            // `_until_cursor`; end-of-input for `_rest`. `_take_*` advance
            // `capture_start` to the cursor (Perl `$IPOS = pos $$STRING`), or to
            // end-of-input for `_take_rest` (`$IPOS = length $$STRING`). Text is
            // the raw byte slice (correct chars); `_len` results are char counts
            // (.5.3). A degenerate (reversed / out-of-range) span yields `undef`
            // through the typed projection boundary; the `_until_cursor`/`_rest`
            // Perl readers carry the same `defined`/`>=` guard, and `_take_*`
            // mutate only on a valid span (identical to Perl on every realistic
            // `capture_start ≤ match-start ≤ cursor ≤ end` input).
            "capture_slice_until_cursor" => {
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_text_from_bytes(start, ctx.pos, rule_label, name)
                    .map(RuntimeValue::Scalar)
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_slice_until_cursor_len" => {
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_length_from_bytes(start, ctx.pos, rule_label, name)
                    .map(|n| RuntimeValue::Number(n as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_until_boundary" => {
                let mut saw_valid_boundary = false;
                let mut boundary_start: Option<usize> = None;
                for index in 0..raw_args.len() {
                    let target = self.resolve_bare_identifier_at(raw_args, args.get(index), index);
                    if target.is_empty() {
                        continue;
                    }
                    let Some(boundary_rule) = self.spec.find(&target) else {
                        continue;
                    };
                    if boundary_rule.regex_patterns.is_empty() {
                        continue;
                    }
                    saw_valid_boundary = true;
                    let boundary_alt = CompiledAlternation::compile(&boundary_rule.regex_patterns)?;
                    if let Some(candidate) = boundary_alt.seek_match(&ctx.input, ctx.pos) {
                        if boundary_start.is_none_or(|current| candidate.start < current) {
                            boundary_start = Some(candidate.start);
                        }
                    }
                }
                if !saw_valid_boundary {
                    return Ok(RuntimeValue::Undef);
                }
                let boundary_start = boundary_start.unwrap_or(ctx.input.len());
                let start = ctx.pos;
                match ctx.typed_span_text_from_bytes(start, boundary_start, rule_label, name) {
                    Some(text) => {
                        ctx.set_pos(boundary_start);
                        Ok(RuntimeValue::Scalar(text))
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take_until_cursor" => {
                let start = ctx.capture_start.unwrap_or(0);
                let cursor = ctx.pos;
                match ctx.typed_span_text_from_bytes(start, cursor, rule_label, name) {
                    Some(text) => {
                        ctx.capture_start = Some(cursor);
                        Ok(RuntimeValue::Scalar(text))
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take_until_cursor_len" => {
                let start = ctx.capture_start.unwrap_or(0);
                let cursor = ctx.pos;
                match ctx.typed_span_length_from_bytes(start, cursor, rule_label, name) {
                    Some(n) => {
                        ctx.capture_start = Some(cursor);
                        Ok(RuntimeValue::Number(n as f64))
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take" => {
                if args.len() == 1 {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    if !ctx.match_present {
                        return Ok(RuntimeValue::Undef);
                    }
                    let cursor = ctx.pos;
                    return Ok(match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                        Some(mark) => match ctx.typed_span_text_from_bytes(
                            mark,
                            ctx.match_start_byte,
                            rule_label,
                            name,
                        ) {
                            Some(text) => {
                                ctx.typed_mark_set(rule_label, mark_name, cursor, name);
                                RuntimeValue::Scalar(text)
                            }
                            None => RuntimeValue::Undef,
                        },
                        None => RuntimeValue::Undef,
                    });
                }
                // text capture_start→match-START; advance capture_start to the
                // cursor (Contracts.pm CAPTURE_SLICE_TAKE, `$IPOS = pos $$STRING`).
                if !ctx.match_present {
                    return Ok(RuntimeValue::Undef);
                }
                let start = ctx.capture_start.unwrap_or(0);
                match ctx.typed_span_text_from_bytes(start, ctx.match_start_byte, rule_label, name)
                {
                    Some(text) => {
                        ctx.capture_start = Some(ctx.pos);
                        Ok(RuntimeValue::Scalar(text))
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take_len" => {
                // length capture_start→match-START; advance capture_start to the
                // cursor (Contracts.pm CAPTURE_SLICE_TAKE_LEN).
                if !ctx.match_present {
                    return Ok(RuntimeValue::Undef);
                }
                let start = ctx.capture_start.unwrap_or(0);
                match ctx.typed_span_length_from_bytes(
                    start,
                    ctx.match_start_byte,
                    rule_label,
                    name,
                ) {
                    Some(n) => {
                        ctx.capture_start = Some(ctx.pos);
                        Ok(RuntimeValue::Number(n as f64))
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_rest" => {
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_text_from_bytes(start, ctx.input.len(), rule_label, name)
                    .map(RuntimeValue::Scalar)
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_rest_len" | "capture_rest_length" => {
                let start = ctx.capture_start.unwrap_or(0);
                Ok(ctx
                    .typed_span_length_from_bytes(start, ctx.input.len(), rule_label, name)
                    .map(|n| RuntimeValue::Number(n as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_take_rest" => {
                let start = ctx.capture_start.unwrap_or(0);
                let end = ctx.input.len();
                match ctx.typed_span_text_from_bytes(start, end, rule_label, name) {
                    Some(text) => {
                        ctx.capture_start = Some(end);
                        Ok(RuntimeValue::Scalar(text))
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take_rest_len" => {
                let start = ctx.capture_start.unwrap_or(0);
                let end = ctx.input.len();
                match ctx.typed_span_length_from_bytes(start, end, rule_label, name) {
                    Some(n) => {
                        ctx.capture_start = Some(end);
                        Ok(RuntimeValue::Number(n as f64))
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "mark_here" => {
                if !args.is_empty() {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    ctx.typed_mark_set(rule_label, mark_name, ctx.pos, name);
                }
                Ok(RuntimeValue::Undef)
            }
            "mark_pos" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                Ok(ctx
                    .typed_mark_offset(rule_label, &mark_name, name)
                    .map(|offset| RuntimeValue::Number(offset as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "mark_exists" => {
                let name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                Ok(RuntimeValue::Number(
                    if ctx.mark_exists(rule_label, &name) {
                        1.0
                    } else {
                        0.0
                    },
                ))
            }
            // ── RUST-PARITY.5.5.3: mark-based capture family ──
            // Authoritative contract: `perl/LinkedSpec/ActionIR/Contracts.pm`
            // ~690–1047. Endpoints (byte offsets): the start of the current local
            // match (`$LSPOS - length $LMATCH` = `ctx.match_start_byte`) for the
            // non-cursor `*_from`/`*_len_from` readers; the cursor (`pos` =
            // `ctx.pos`) for `_until_cursor_`; end-of-input for `_rest_`. `_take_`
            // variants advance the named mark to the read's end (the cursor, or
            // end-of-input for `_rest_`). Marks are stored byte offsets; text is the
            // raw slice (correct chars); `_len_` results are char counts (DSL
            // lengths are char-based, .5.3). A missing mark, or a degenerate
            // (reversed / out-of-range) span, yields `undef` — matching the Perl
            // readers' `defined`/`>=` guards; `_take_` mutates only when the span
            // is valid.
            "mark_input_start" => {
                // Store the absolute start-of-input position (0) under the mark.
                if !args.is_empty() {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    ctx.typed_mark_set(rule_label, mark_name, 0, name);
                }
                Ok(RuntimeValue::Undef)
            }
            "mark_input_end" => {
                // Store the absolute end-of-input position (byte length) under the mark.
                if !args.is_empty() {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    let end = ctx.input.len();
                    ctx.typed_mark_set(rule_label, mark_name, end, name);
                }
                Ok(RuntimeValue::Undef)
            }
            "mark_entry_start" => {
                if !args.is_empty() {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    ctx.typed_mark_set(rule_label, mark_name, ctx.entry_start_byte, name);
                }
                Ok(RuntimeValue::Undef)
            }
            "mark_entry_end" => {
                if !args.is_empty() {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    ctx.typed_mark_set(rule_label, mark_name, ctx.entry_end_byte, name);
                }
                Ok(RuntimeValue::Undef)
            }
            "mark_match_start" => {
                if !args.is_empty() {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    if !ctx.match_present {
                        return Ok(RuntimeValue::Undef);
                    }
                    ctx.typed_mark_set(rule_label, mark_name, ctx.match_start_byte, name);
                }
                Ok(RuntimeValue::Undef)
            }
            "mark_match_end" => {
                if !args.is_empty() {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    if !ctx.match_present {
                        return Ok(RuntimeValue::Undef);
                    }
                    ctx.typed_mark_set(rule_label, mark_name, ctx.match_end_byte, name);
                }
                Ok(RuntimeValue::Undef)
            }
            "mark_copy" => {
                // 2-arg `mark_copy(target, source)`: copy source's position to
                // target when source is present, else delete target (Contracts.pm
                // MARK_COPY). The book catalog's 1-arg form was an imprecision,
                // corrected in .5.5.3.
                let target = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let source = self.resolve_bare_identifier_at(raw_args, args.get(1), 1);
                match ctx.typed_mark_byte(rule_label, &source, name) {
                    Some(pos) => {
                        ctx.typed_mark_set(rule_label, target, pos, name);
                    }
                    None => {
                        ctx.mark_remove(rule_label, &target);
                    }
                }
                Ok(RuntimeValue::Undef)
            }
            "mark_capture_slice" => {
                if !args.is_empty() {
                    let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                    ctx.typed_mark_set(rule_label, mark_name, ctx.capture_start.unwrap_or(0), name);
                }
                Ok(RuntimeValue::Undef)
            }
            "clear_mark" => {
                let name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                ctx.mark_remove(rule_label, &name);
                Ok(RuntimeValue::Undef)
            }
            "mark_line" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                Ok(ctx
                    .typed_mark_line(rule_label, &mark_name, name)
                    .map(|line| RuntimeValue::Number(line as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "mark_col" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                Ok(ctx
                    .typed_mark_column(rule_label, &mark_name, name)
                    .map(|column| RuntimeValue::Number(column as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "capture_from" => {
                // mark → match-START (was match-END before .5.5.3; fixed for Perl
                // parity — `capture_from` is a non-cursor reader).
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                if !ctx.match_present {
                    return Ok(RuntimeValue::Undef);
                }
                Ok(match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => ctx
                        .typed_span_text_from_bytes(mark, ctx.match_start_byte, rule_label, name)
                        .map(RuntimeValue::Scalar)
                        .unwrap_or(RuntimeValue::Undef),
                    None => RuntimeValue::Undef,
                })
            }
            "capture_len_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                if !ctx.match_present {
                    return Ok(RuntimeValue::Undef);
                }
                Ok(match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => ctx
                        .typed_span_length_from_bytes(mark, ctx.match_start_byte, rule_label, name)
                        .map(|n| RuntimeValue::Number(n as f64))
                        .unwrap_or(RuntimeValue::Undef),
                    None => RuntimeValue::Undef,
                })
            }
            "capture_until_cursor_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let cursor = ctx.pos;
                Ok(match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => ctx
                        .typed_span_text_from_bytes(mark, cursor, rule_label, name)
                        .map(RuntimeValue::Scalar)
                        .unwrap_or(RuntimeValue::Undef),
                    None => RuntimeValue::Undef,
                })
            }
            "capture_until_cursor_len_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let cursor = ctx.pos;
                Ok(match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => ctx
                        .typed_span_length_from_bytes(mark, cursor, rule_label, name)
                        .map(|n| RuntimeValue::Number(n as f64))
                        .unwrap_or(RuntimeValue::Undef),
                    None => RuntimeValue::Undef,
                })
            }
            "capture_take_until_cursor_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let cursor = ctx.pos;
                match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => {
                        match ctx.typed_span_text_from_bytes(mark, cursor, rule_label, name) {
                            Some(text) => {
                                ctx.typed_mark_set(rule_label, mark_name, cursor, name);
                                Ok(RuntimeValue::Scalar(text))
                            }
                            None => Ok(RuntimeValue::Undef),
                        }
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take_until_cursor_len_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let cursor = ctx.pos;
                match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => {
                        match ctx.typed_span_length_from_bytes(mark, cursor, rule_label, name) {
                            Some(n) => {
                                ctx.typed_mark_set(rule_label, mark_name, cursor, name);
                                Ok(RuntimeValue::Number(n as f64))
                            }
                            None => Ok(RuntimeValue::Undef),
                        }
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take_len_from" => {
                // length mark→match-START; advances the mark to the cursor
                // (Contracts.pm CAPTURE_TAKE_LEN_FROM_MARK).
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                if !ctx.match_present {
                    return Ok(RuntimeValue::Undef);
                }
                let cursor = ctx.pos;
                let end = ctx.match_start_byte;
                match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => {
                        match ctx.typed_span_length_from_bytes(mark, end, rule_label, name) {
                            Some(n) => {
                                ctx.typed_mark_set(rule_label, mark_name, cursor, name);
                                Ok(RuntimeValue::Number(n as f64))
                            }
                            None => Ok(RuntimeValue::Undef),
                        }
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_rest_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let end = ctx.input.len();
                Ok(match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => ctx
                        .typed_span_text_from_bytes(mark, end, rule_label, name)
                        .map(RuntimeValue::Scalar)
                        .unwrap_or(RuntimeValue::Undef),
                    None => RuntimeValue::Undef,
                })
            }
            "capture_rest_len_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let end = ctx.input.len();
                Ok(match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => ctx
                        .typed_span_length_from_bytes(mark, end, rule_label, name)
                        .map(|n| RuntimeValue::Number(n as f64))
                        .unwrap_or(RuntimeValue::Undef),
                    None => RuntimeValue::Undef,
                })
            }
            "capture_take_rest_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let end = ctx.input.len();
                match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => match ctx.typed_span_text_from_bytes(mark, end, rule_label, name)
                    {
                        Some(text) => {
                            ctx.typed_mark_set(rule_label, mark_name, end, name);
                            Ok(RuntimeValue::Scalar(text))
                        }
                        None => Ok(RuntimeValue::Undef),
                    },
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take_rest_len_from" => {
                let mark_name = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let end = ctx.input.len();
                match ctx.typed_mark_byte(rule_label, &mark_name, name) {
                    Some(mark) => {
                        match ctx.typed_span_length_from_bytes(mark, end, rule_label, name) {
                            Some(n) => {
                                ctx.typed_mark_set(rule_label, mark_name, end, name);
                                Ok(RuntimeValue::Number(n as f64))
                            }
                            None => Ok(RuntimeValue::Undef),
                        }
                    }
                    None => Ok(RuntimeValue::Undef),
                }
            }
            "capture_between" => {
                let a = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let b = self.resolve_bare_identifier_at(raw_args, args.get(1), 1);
                let start = ctx.typed_mark_byte(rule_label, &a, name);
                let end = ctx.typed_mark_byte(rule_label, &b, name);
                Ok(match (start, end) {
                    (Some(s), Some(e)) => ctx
                        .typed_span_text_from_bytes(s, e, rule_label, name)
                        .map(RuntimeValue::Scalar)
                        .unwrap_or(RuntimeValue::Undef),
                    _ => RuntimeValue::Undef,
                })
            }
            "capture_len_between" => {
                let a = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let b = self.resolve_bare_identifier_at(raw_args, args.get(1), 1);
                let start = ctx.typed_mark_byte(rule_label, &a, name);
                let end = ctx.typed_mark_byte(rule_label, &b, name);
                Ok(match (start, end) {
                    (Some(s), Some(e)) => ctx
                        .typed_span_length_from_bytes(s, e, rule_label, name)
                        .map(|n| RuntimeValue::Number(n as f64))
                        .unwrap_or(RuntimeValue::Undef),
                    _ => RuntimeValue::Undef,
                })
            }
            "capture_take_between" => {
                let a = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let b = self.resolve_bare_identifier_at(raw_args, args.get(1), 1);
                let start = ctx.typed_mark_byte(rule_label, &a, name);
                let end = ctx.typed_mark_byte(rule_label, &b, name);
                match (start, end) {
                    (Some(s), Some(e)) => {
                        match ctx.typed_span_text_from_bytes(s, e, rule_label, name) {
                            Some(text) => {
                                ctx.typed_mark_set(rule_label, a, e, name);
                                Ok(RuntimeValue::Scalar(text))
                            }
                            None => Ok(RuntimeValue::Undef),
                        }
                    }
                    _ => Ok(RuntimeValue::Undef),
                }
            }
            "capture_take_between_len" => {
                let a = self.resolve_bare_identifier_at(raw_args, args.first(), 0);
                let b = self.resolve_bare_identifier_at(raw_args, args.get(1), 1);
                let start = ctx.typed_mark_byte(rule_label, &a, name);
                let end = ctx.typed_mark_byte(rule_label, &b, name);
                match (start, end) {
                    (Some(s), Some(e)) => {
                        match ctx.typed_span_length_from_bytes(s, e, rule_label, name) {
                            Some(n) => {
                                ctx.typed_mark_set(rule_label, a, e, name);
                                Ok(RuntimeValue::Number(n as f64))
                            }
                            None => Ok(RuntimeValue::Undef),
                        }
                    }
                    _ => Ok(RuntimeValue::Undef),
                }
            }
            // ── Entry/match detail ──
            "entry_line" | "entry_start_line" => {
                let offset = args
                    .first()
                    .and_then(RuntimeValue::as_number)
                    .map(|value| value.max(0.0) as usize);
                Ok(ctx
                    .typed_position_line_from_optional_scalar(
                        offset,
                        ctx.entry_start_byte,
                        rule_label,
                        name,
                    )
                    .map(|line| RuntimeValue::Number(line as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "entry_col" | "entry_start_col" => {
                let offset = args
                    .first()
                    .and_then(RuntimeValue::as_number)
                    .map(|value| value.max(0.0) as usize);
                Ok(ctx
                    .typed_position_column_from_optional_scalar(
                        offset,
                        ctx.entry_start_byte,
                        rule_label,
                        name,
                    )
                    .map(|column| RuntimeValue::Number(column as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "entry_end_line" => {
                let offset = args
                    .first()
                    .and_then(RuntimeValue::as_number)
                    .map(|value| value.max(0.0) as usize);
                Ok(ctx
                    .typed_position_line_from_optional_scalar(
                        offset,
                        ctx.entry_end_byte,
                        rule_label,
                        name,
                    )
                    .map(|line| RuntimeValue::Number(line as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "entry_end_col" => {
                let offset = args
                    .first()
                    .and_then(RuntimeValue::as_number)
                    .map(|value| value.max(0.0) as usize);
                Ok(ctx
                    .typed_position_column_from_optional_scalar(
                        offset,
                        ctx.entry_end_byte,
                        rule_label,
                        name,
                    )
                    .map(|column| RuntimeValue::Number(column as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "entry_len" => Ok(ctx
                .typed_span_length_from_bytes(
                    ctx.entry_start_byte,
                    ctx.entry_end_byte,
                    rule_label,
                    name,
                )
                .map(|length| RuntimeValue::Number(length as f64))
                .unwrap_or(RuntimeValue::Number(0.0))),
            "entry_start_pos" => Ok(ctx
                .typed_span_start_offset_from_bytes(
                    ctx.entry_start_byte,
                    ctx.entry_end_byte,
                    rule_label,
                    name,
                )
                .map(|offset| RuntimeValue::Number(offset as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "entry_end_pos" => Ok(ctx
                .typed_position_offset_from_byte(ctx.entry_end_byte, rule_label, name)
                .map(|offset| RuntimeValue::Number(offset as f64))
                .unwrap_or(RuntimeValue::Undef)),
            "match_line" | "match_start_line" => {
                let offset = args
                    .first()
                    .and_then(RuntimeValue::as_number)
                    .map(|value| value.max(0.0) as usize);
                Ok(ctx
                    .typed_position_line_from_optional_scalar(
                        offset,
                        ctx.match_start_byte,
                        rule_label,
                        name,
                    )
                    .map(|line| RuntimeValue::Number(line as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "match_col" | "match_start_col" => {
                let offset = args
                    .first()
                    .and_then(RuntimeValue::as_number)
                    .map(|value| value.max(0.0) as usize);
                Ok(ctx
                    .typed_position_column_from_optional_scalar(
                        offset,
                        ctx.match_start_byte,
                        rule_label,
                        name,
                    )
                    .map(|column| RuntimeValue::Number(column as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "match_end_line" => {
                let offset = args
                    .first()
                    .and_then(RuntimeValue::as_number)
                    .map(|value| value.max(0.0) as usize);
                Ok(ctx
                    .typed_position_line_from_optional_scalar(
                        offset,
                        ctx.match_end_byte,
                        rule_label,
                        name,
                    )
                    .map(|line| RuntimeValue::Number(line as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "match_end_col" => {
                let offset = args
                    .first()
                    .and_then(RuntimeValue::as_number)
                    .map(|value| value.max(0.0) as usize);
                Ok(ctx
                    .typed_position_column_from_optional_scalar(
                        offset,
                        ctx.match_end_byte,
                        rule_label,
                        name,
                    )
                    .map(|column| RuntimeValue::Number(column as f64))
                    .unwrap_or(RuntimeValue::Undef))
            }
            "match_len" => Ok(if ctx.match_present {
                ctx.typed_span_length_from_bytes(
                    ctx.match_start_byte,
                    ctx.match_end_byte,
                    rule_label,
                    name,
                )
                .map(|length| RuntimeValue::Number(length as f64))
                .unwrap_or(RuntimeValue::Undef)
            } else {
                RuntimeValue::Undef
            }),
            "match_start_pos" => Ok(if ctx.match_present {
                ctx.typed_span_start_offset_from_bytes(
                    ctx.match_start_byte,
                    ctx.match_end_byte,
                    rule_label,
                    name,
                )
                .map(|offset| RuntimeValue::Number(offset as f64))
                .unwrap_or(RuntimeValue::Undef)
            } else {
                RuntimeValue::Undef
            }),
            "match_end_pos" => Ok(if ctx.match_present {
                ctx.typed_position_offset_from_byte(ctx.match_end_byte, rule_label, name)
                    .map(|offset| RuntimeValue::Number(offset as f64))
                    .unwrap_or(RuntimeValue::Undef)
            } else {
                RuntimeValue::Undef
            }),
            "match_group" => {
                if !ctx.match_present {
                    Ok(RuntimeValue::Undef)
                } else if let Some(arg) = args.first() {
                    let idx = arg.as_number().unwrap_or(0.0) as usize;
                    Ok(RuntimeContext::project_capture_group_text(
                        ctx.match_groups.get(idx),
                    ))
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "match_groups" => Ok(RuntimeContext::project_capture_group_list(
                &ctx.match_groups,
            )),
            // Named-capture readers for the LOCAL match — the immediate regex
            // match inside this code block, which can diverge from the entry match
            // in nested/dispatched contexts (Helper Contract Catalog §8). They read
            // the populated `ctx.match_named` map. `match_named_map` is a retired
            // alias of `match_map`.
            "match_named" => Ok(match Self::resolve_named_capture_key(raw_args, args) {
                Some(name) => {
                    RuntimeContext::project_capture_group_text(ctx.match_named.get(&name))
                }
                None => RuntimeValue::Undef,
            }),
            "match_has" => Ok(RuntimeContext::project_capture_group_exists(
                Self::resolve_named_capture_key(raw_args, args)
                    .map(|name| ctx.match_named.contains_key(&name))
                    .unwrap_or(false),
            )),
            "match_map" | "match_named_map" => {
                Ok(RuntimeContext::project_capture_group_map(&ctx.match_named))
            }
            // ── Scalar transforms ──
            // Reject undefined scalar operands before text coercion.
            // Arguments have already been evaluated, preserving their effects.
            "length" | "trim" | "lowercase" | "uppercase"
                if matches!(args.first(), Some(RuntimeValue::Undef)) =>
            {
                Ok(RuntimeValue::Undef)
            }
            "replace_substr" | "rm_prefix" | "rm_suffix"
                if args.iter().any(|arg| matches!(arg, RuntimeValue::Undef)) =>
            {
                Ok(RuntimeValue::Undef)
            }
            "starts_with" | "ends_with" | "contains_substr"
                if args.iter().any(|arg| matches!(arg, RuntimeValue::Undef)) =>
            {
                Ok(RuntimeValue::Number(0.0))
            }
            "matches" if matches!(args.first(), Some(RuntimeValue::Undef)) => {
                Ok(RuntimeValue::Bool(false))
            }
            "length" => {
                if let Some(arg) = args.first() {
                    let length = match arg {
                        RuntimeValue::Array(items) => items.len(),
                        // Scalar text uses character count (Perl `length`), not
                        // UTF-8 byte count.
                        value => value.to_str().chars().count(),
                    };
                    Ok(RuntimeValue::Number(length as f64))
                } else {
                    Ok(RuntimeValue::Number(0.0))
                }
            }
            "trim" => Ok(match args.first() {
                None | Some(RuntimeValue::Undef) => RuntimeValue::Undef,
                Some(value) => RuntimeValue::Scalar(value.to_str().trim().to_string()),
            }),
            "lowercase" => Ok(RuntimeValue::Scalar(
                args.first()
                    .map(|a| crate::unicode_case_mapping::lowercase(&a.to_str()))
                    .unwrap_or_default(),
            )),
            "uppercase" => Ok(RuntimeValue::Scalar(
                args.first()
                    .map(|a| crate::unicode_case_mapping::uppercase(&a.to_str()))
                    .unwrap_or_default(),
            )),
            "replace_substr" => {
                if args.len() >= 3 {
                    let s = args[0].to_str();
                    let from = args[1].to_str();
                    let to = args[2].to_str();
                    Ok(if from.is_empty() {
                        args[0].clone()
                    } else {
                        RuntimeValue::Scalar(s.replace(&from, &to))
                    })
                } else {
                    Ok(args.first().cloned().unwrap_or(RuntimeValue::Undef))
                }
            }
            "rm_prefix" => {
                if args.len() >= 2 {
                    let s = args[0].to_str();
                    let prefix = args[1].to_str();
                    Ok(match s.strip_prefix(&prefix) {
                        Some(stripped) if !prefix.is_empty() => {
                            RuntimeValue::Scalar(stripped.to_string())
                        }
                        _ => args[0].clone(),
                    })
                } else {
                    Ok(args.first().cloned().unwrap_or(RuntimeValue::Undef))
                }
            }
            "rm_suffix" => {
                if args.len() >= 2 {
                    let s = args[0].to_str();
                    let suffix = args[1].to_str();
                    Ok(match s.strip_suffix(&suffix) {
                        Some(stripped) if !suffix.is_empty() => {
                            RuntimeValue::Scalar(stripped.to_string())
                        }
                        _ => args[0].clone(),
                    })
                } else {
                    Ok(args.first().cloned().unwrap_or(RuntimeValue::Undef))
                }
            }
            "starts_with" => {
                if args.len() >= 2 {
                    let s = args[0].to_str();
                    let prefix = args[1].to_str();
                    Ok(RuntimeValue::Number(if s.starts_with(&prefix) {
                        1.0
                    } else {
                        0.0
                    }))
                } else {
                    Ok(RuntimeValue::Number(0.0))
                }
            }
            "ends_with" => {
                if args.len() >= 2 {
                    let s = args[0].to_str();
                    let suffix = args[1].to_str();
                    Ok(RuntimeValue::Number(if s.ends_with(&suffix) {
                        1.0
                    } else {
                        0.0
                    }))
                } else {
                    Ok(RuntimeValue::Number(0.0))
                }
            }
            "contains_substr" => {
                if args.len() >= 2 {
                    let s = args[0].to_str();
                    let sub = args[1].to_str();
                    Ok(RuntimeValue::Number(if s.contains(&sub) {
                        1.0
                    } else {
                        0.0
                    }))
                } else {
                    Ok(RuntimeValue::Number(0.0))
                }
            }
            "str_eq" | "str_ne" | "str_gt" | "str_ge" | "str_lt" | "str_le" => {
                if args.len() >= 2 {
                    let lhs = args[0].to_str();
                    let rhs = args[1].to_str();
                    let result = match name {
                        "str_eq" => lhs == rhs,
                        "str_ne" => lhs != rhs,
                        "str_gt" => lhs > rhs,
                        "str_ge" => lhs >= rhs,
                        "str_lt" => lhs < rhs,
                        "str_le" => lhs <= rhs,
                        _ => false,
                    };
                    Ok(RuntimeValue::Bool(result))
                } else {
                    Ok(RuntimeValue::Bool(false))
                }
            }
            "matches" => {
                if args.len() >= 2 {
                    let s = args[0].to_str();
                    let pat = args[1].to_str();
                    match rgx_core::Regex::compile(&pat) {
                        Ok(re) => Ok(RuntimeValue::Bool(re.is_match(&s))),
                        Err(e) => {
                            eprintln!(
                                "warning: matches: invalid regex '/{}/': {} — returning false",
                                pat, e
                            );
                            Ok(RuntimeValue::Bool(false))
                        }
                    }
                } else {
                    Ok(RuntimeValue::Bool(false))
                }
            }
            "or" => Ok(RuntimeValue::Bool(args.iter().any(RuntimeValue::as_bool))),
            "and" => Ok(RuntimeValue::Bool(args.iter().all(RuntimeValue::as_bool))),
            "not" => Ok(RuntimeValue::Bool(!args[0].as_bool())),
            // ── Coalesce ──
            "coalesce_nonempty" => {
                for a in args {
                    if Self::coalesce_accepts(a, true) {
                        return Ok(a.clone());
                    }
                }
                Ok(RuntimeValue::Undef)
            }
            // ── Scalar arithmetic ──
            "num_add" | "num_mul" => {
                if args.len() >= 2 {
                    let nums: Option<Vec<f64>> = args.iter().map(scalar_numeric_value).collect();
                    match nums {
                        Some(nums) if name == "num_add" => {
                            Ok(finite_numeric_result(nums.iter().sum()))
                        }
                        Some(nums) => Ok(finite_numeric_result(nums.iter().product())),
                        None => Ok(RuntimeValue::Undef),
                    }
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "num_sub" | "num_div" | "num_mod" => {
                if args.len() == 2 {
                    let a = scalar_numeric_value(&args[0]);
                    let b = scalar_numeric_value(&args[1]);
                    match (a, b) {
                        (Some(a), Some(b)) => {
                            let result = match name {
                                "num_sub" => a - b,
                                "num_div" if b != 0.0 => a / b,
                                "num_mod" if b != 0.0 && a.fract() == 0.0 && b.fract() == 0.0 => {
                                    a - (a / b).floor() * b
                                }
                                _ => return Ok(RuntimeValue::Undef),
                            };
                            Ok(finite_numeric_result(result))
                        }
                        _ => Ok(RuntimeValue::Undef),
                    }
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "num_eq" | "num_ne" | "num_gt" | "num_ge" | "num_lt" | "num_le" => {
                if args.len() == 2 {
                    match (
                        scalar_numeric_value(&args[0]),
                        scalar_numeric_value(&args[1]),
                    ) {
                        (Some(a), Some(b)) => {
                            let result = match name {
                                "num_eq" => a == b,
                                "num_ne" => a != b,
                                "num_gt" => a > b,
                                "num_ge" => a >= b,
                                "num_lt" => a < b,
                                "num_le" => a <= b,
                                _ => false,
                            };
                            Ok(RuntimeValue::Number(if result { 1.0 } else { 0.0 }))
                        }
                        _ => Ok(RuntimeValue::Undef),
                    }
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "num_abs" | "num_floor" | "num_ceil" | "num_round" => {
                if args.len() != 1 {
                    return Ok(RuntimeValue::Undef);
                }
                let Some(value) = scalar_numeric_value(&args[0]) else {
                    return Ok(RuntimeValue::Undef);
                };
                let result = match name {
                    "num_abs" => value.abs(),
                    "num_floor" => value.floor(),
                    "num_ceil" => value.ceil(),
                    "num_round" => value.round(),
                    _ => unreachable!(),
                };
                Ok(finite_numeric_result(result))
            }
            "num_min" => {
                let values: Vec<f64> = if args.len() == 1 {
                    match self.array_consuming_arg(raw_args, args, 0, ctx) {
                        RuntimeValue::Array(items) => match items
                            .iter()
                            .map(scalar_numeric_value)
                            .collect::<Option<Vec<_>>>()
                        {
                            Some(values) => values,
                            None => return Ok(RuntimeValue::Undef),
                        },
                        _ => Vec::new(),
                    }
                } else {
                    match args
                        .iter()
                        .map(scalar_numeric_value)
                        .collect::<Option<Vec<_>>>()
                    {
                        Some(values) if values.len() >= 2 => values,
                        _ => return Ok(RuntimeValue::Undef),
                    }
                };
                let min = values.iter().copied().fold(f64::INFINITY, |a, b| a.min(b));
                if min.is_finite() {
                    Ok(RuntimeValue::Number(min))
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "num_max" => {
                let values: Vec<f64> = if args.len() == 1 {
                    match self.array_consuming_arg(raw_args, args, 0, ctx) {
                        RuntimeValue::Array(items) => match items
                            .iter()
                            .map(scalar_numeric_value)
                            .collect::<Option<Vec<_>>>()
                        {
                            Some(values) => values,
                            None => return Ok(RuntimeValue::Undef),
                        },
                        _ => Vec::new(),
                    }
                } else {
                    match args
                        .iter()
                        .map(scalar_numeric_value)
                        .collect::<Option<Vec<_>>>()
                    {
                        Some(values) if values.len() >= 2 => values,
                        _ => return Ok(RuntimeValue::Undef),
                    }
                };
                let max = values
                    .iter()
                    .copied()
                    .fold(f64::NEG_INFINITY, |a, b| a.max(b));
                if max.is_finite() {
                    Ok(RuntimeValue::Number(max))
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "num_clamp" => {
                if args.len() == 3 {
                    let v = scalar_numeric_value(&args[0]);
                    let lo = scalar_numeric_value(&args[1]);
                    let hi = scalar_numeric_value(&args[2]);
                    match (v, lo, hi) {
                        (Some(v), Some(lo), Some(hi)) if lo <= hi => {
                            Ok(RuntimeValue::Number(v.clamp(lo, hi)))
                        }
                        _ => Ok(RuntimeValue::Undef),
                    }
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "num_sum" | "num_avg" | "num_median" | "num_range" => {
                if let RuntimeValue::Array(items) = self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    if name == "num_sum" && items.is_empty() {
                        return Ok(RuntimeValue::Number(0.0));
                    }
                    let nums: Vec<f64> = items.iter().filter_map(|v| v.as_number()).collect();
                    if nums.is_empty() {
                        return Ok(RuntimeValue::Undef);
                    }
                    match name {
                        "num_sum" => Ok(RuntimeValue::Number(nums.iter().sum())),
                        "num_avg" => Ok(RuntimeValue::Number(
                            nums.iter().sum::<f64>() / nums.len() as f64,
                        )),
                        "num_median" => {
                            let mut sorted = nums.clone();
                            sorted.sort_by(|a, b| {
                                a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal)
                            });
                            let mid = sorted.len() / 2;
                            if sorted.len() % 2 == 0 {
                                Ok(RuntimeValue::Number((sorted[mid - 1] + sorted[mid]) / 2.0))
                            } else {
                                Ok(RuntimeValue::Number(sorted[mid]))
                            }
                        }
                        "num_range" => {
                            let min = nums.iter().fold(f64::INFINITY, |a, &b| a.min(b));
                            let max = nums.iter().fold(f64::NEG_INFINITY, |a, &b| a.max(b));
                            Ok(RuntimeValue::Number(max - min))
                        }
                        _ => Ok(RuntimeValue::Undef),
                    }
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            // ── Array helpers ──
            "sorted" => {
                if let RuntimeValue::Array(mut items) =
                    self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    items.sort_by(|a, b| a.to_str().cmp(&b.to_str()));
                    Ok(RuntimeValue::Array(items))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "reversed" => {
                if let RuntimeValue::Array(mut items) =
                    self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    items.reverse();
                    Ok(RuntimeValue::Array(items))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "take" => {
                if let RuntimeValue::Array(items) = self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    let n = args.get(1).and_then(|a| a.as_number()).unwrap_or(1.0) as usize;
                    Ok(RuntimeValue::Array(items.iter().take(n).cloned().collect()))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "take_last" => {
                if let RuntimeValue::Array(items) = self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    let n = args.get(1).and_then(|a| a.as_number()).unwrap_or(1.0) as usize;
                    let start = if n > items.len() { 0 } else { items.len() - n };
                    Ok(RuntimeValue::Array(items[start..].to_vec()))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "drop_front" => {
                if let RuntimeValue::Array(items) = self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    let n = args.get(1).and_then(|a| a.as_number()).unwrap_or(1.0) as usize;
                    Ok(RuntimeValue::Array(items.iter().skip(n).cloned().collect()))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "drop_back" => {
                if let RuntimeValue::Array(items) = self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    let n = args.get(1).and_then(|a| a.as_number()).unwrap_or(1.0) as usize;
                    let end = if n > items.len() { 0 } else { items.len() - n };
                    Ok(RuntimeValue::Array(items[..end].to_vec()))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "slice" => {
                if let RuntimeValue::Array(items) = self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    let start = args.get(1).and_then(|a| a.as_number()).unwrap_or(0.0) as usize;
                    let n = args
                        .get(2)
                        .and_then(|a| a.as_number())
                        .unwrap_or(items.len() as f64) as usize;
                    let end = (start + n).min(items.len());
                    Ok(RuntimeValue::Array(items[start..end].to_vec()))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "contains" => {
                // Arguments already capture typed values before later operand effects.
                if let Some(RuntimeValue::Array(items)) = args.first() {
                    let needle = args.get(1).map(Self::array_scalar_key);
                    let present = items.iter().any(|value| match &needle {
                        Some(key) => Self::array_scalar_key(value) == *key,
                        // Keep the legacy default for an absent free-helper needle.
                        None => value.to_str().is_empty(),
                    });
                    Ok(RuntimeValue::Number(if present { 1.0 } else { 0.0 }))
                } else {
                    Ok(RuntimeValue::Number(0.0))
                }
            }
            "index_of" => {
                if let RuntimeValue::Array(items) = self.array_consuming_arg(raw_args, args, 0, ctx)
                {
                    let needle = args.get(1).map(Self::array_scalar_key);
                    match items.iter().position(|value| match &needle {
                        Some(key) => Self::array_scalar_key(value) == *key,
                        None => value.to_str().is_empty(),
                    }) {
                        Some(i) => Ok(RuntimeValue::Number(i as f64)),
                        None => Ok(RuntimeValue::Undef),
                    }
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "is_empty" => {
                let val = args.first().cloned().unwrap_or(RuntimeValue::Undef);
                Ok(RuntimeValue::Bool(!val.is_nonempty()))
            }
            "is_nonempty" => {
                let val = args.first().cloned().unwrap_or(RuntimeValue::Undef);
                Ok(RuntimeValue::Bool(val.is_nonempty()))
            }
            "is_defined" => Ok(RuntimeValue::Bool(
                args.first().is_some_and(|a| a.is_defined()),
            )),
            "is_undefined" => Ok(RuntimeValue::Bool(
                args.first().is_none_or(|a| !a.is_defined()),
            )),
            "flat_array" => Ok(RuntimeValue::Array(
                args.iter()
                    .enumerate()
                    .flat_map(|(index, _)| {
                        match self.array_consuming_arg(raw_args, args, index, ctx) {
                            RuntimeValue::Array(items) => items,
                            other => vec![other],
                        }
                    })
                    .collect(),
            )),
            // RUST-PARITY.5.5.2 — generic list-context splice (Perl `flat(container)`,
            // MethodLowering.pm:199): an array container splices its elements, a hash
            // container splices its key/value entries, any other value becomes a
            // single-element list. Consistent with `flat_array` (Array→Array) and
            // `flat_hash` (Hash→Hash) so a parent `array(...)`/`hash(...)` consumes it the
            // same way. The retired Perl aliases `flatten`/`tail`/`drop_last` are
            // intentionally NOT added — the Perl reference no longer recognizes them
            // (COMPAT-ALIAS-RETIREMENT.1), so adding them in Rust would diverge from the
            // reference's recognized surface rather than match it.
            "flat" => {
                let arg = args.first().cloned().unwrap_or(RuntimeValue::Undef);
                match arg {
                    RuntimeValue::Hash(entries) => Ok(RuntimeValue::Hash(entries)),
                    RuntimeValue::Array(items) => Ok(RuntimeValue::Array(items)),
                    other => Ok(RuntimeValue::Array(vec![other])),
                }
            }
            "concat_arrays" => Ok(RuntimeValue::Array(
                args.iter()
                    .flat_map(|a| match a {
                        RuntimeValue::Array(items) => items.clone(),
                        other => vec![other.clone()],
                    })
                    .collect(),
            )),
            // ── Hash helpers ──
            "hash" => {
                let mut entries = Vec::new();
                let mut i = 0;
                while i + 1 < args.len() {
                    let key = args[i].to_str();
                    let val = args[i + 1].clone();
                    entries.push((key, val));
                    i += 2;
                }
                // Only explicit flat/flat_hash arguments splice entries. An
                // ordinary hash in a value slot remains one nested value.
                for (raw_arg, arg) in raw_args.iter().zip(args.iter()) {
                    if Self::is_hash_context_splice_arg(raw_arg)
                        && let RuntimeValue::Hash(h_entries) = arg
                    {
                        for (k, v) in h_entries {
                            entries.push((k.clone(), v.clone()));
                        }
                    }
                }
                Ok(RuntimeValue::Hash(entries))
            }
            "merge_hash" => {
                let mut merged = Vec::new();
                for index in 0..args.len() {
                    let arg = self.hash_consuming_arg(raw_args, args, index, ctx);
                    if let RuntimeValue::Hash(entries) = arg {
                        for (k, v) in &entries {
                            if let Some((_, existing_value)) = merged
                                .iter_mut()
                                .find(|(existing_key, _)| existing_key == k)
                            {
                                *existing_value = v.clone();
                            } else {
                                merged.push((k.clone(), v.clone()));
                            }
                        }
                    }
                }
                Ok(RuntimeValue::Hash(merged))
            }
            "set_key" => {
                if args.len() >= 3 {
                    if let RuntimeValue::Hash(mut entries) =
                        self.hash_consuming_arg(raw_args, args, 0, ctx)
                    {
                        let key = args[1].to_str();
                        let val = args[2].clone();
                        if let Some(existing) = entries.iter_mut().find(|(k, _)| k == &key) {
                            existing.1 = val;
                        } else {
                            entries.push((key, val));
                        }
                        Ok(RuntimeValue::Hash(entries))
                    } else {
                        Ok(args[0].clone())
                    }
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "rename_key" => {
                if args.len() >= 3 {
                    if let RuntimeValue::Hash(entries) =
                        self.hash_consuming_arg(raw_args, args, 0, ctx)
                    {
                        let old_key = args[1].to_str();
                        let new_key = args[2].to_str();
                        let renamed: Vec<_> = entries
                            .into_iter()
                            .map(|(k, v)| {
                                if k == old_key {
                                    (new_key.clone(), v)
                                } else {
                                    (k, v)
                                }
                            })
                            .collect();
                        Ok(RuntimeValue::Hash(renamed))
                    } else {
                        Ok(args[0].clone())
                    }
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "drop_keys" => {
                if let RuntimeValue::Hash(entries) = self.hash_consuming_arg(raw_args, args, 0, ctx)
                {
                    let keys_to_drop: std::collections::HashSet<String> =
                        args[1..].iter().map(|a| a.to_str()).collect();
                    Ok(RuntimeValue::Hash(
                        entries
                            .into_iter()
                            .filter(|(k, _)| !keys_to_drop.contains(k))
                            .collect(),
                    ))
                } else {
                    Ok(args.first().cloned().unwrap_or(RuntimeValue::Undef))
                }
            }
            "pick_keys" => {
                if let RuntimeValue::Hash(entries) = self.hash_consuming_arg(raw_args, args, 0, ctx)
                {
                    let keys_to_keep: std::collections::HashSet<String> =
                        args[1..].iter().map(|a| a.to_str()).collect();
                    Ok(RuntimeValue::Hash(
                        entries
                            .into_iter()
                            .filter(|(k, _)| keys_to_keep.contains(k))
                            .collect(),
                    ))
                } else {
                    Ok(RuntimeValue::Undef)
                }
            }
            "sorted_keys" => {
                if let RuntimeValue::Hash(entries) = self.hash_consuming_arg(raw_args, args, 0, ctx)
                {
                    let mut keys: Vec<RuntimeValue> = entries
                        .iter()
                        .map(|(k, _)| RuntimeValue::Scalar(k.clone()))
                        .collect();
                    keys.sort_by(|a, b| a.to_str().cmp(&b.to_str()));
                    Ok(RuntimeValue::Array(keys))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "sorted_values" => {
                if let RuntimeValue::Hash(entries) = self.hash_consuming_arg(raw_args, args, 0, ctx)
                {
                    let mut items: Vec<(String, RuntimeValue)> = entries;
                    items.sort_by(|(ak, _), (bk, _)| ak.cmp(bk));
                    Ok(RuntimeValue::Array(
                        items.into_iter().map(|(_, v)| v).collect(),
                    ))
                } else {
                    Ok(RuntimeValue::Array(vec![]))
                }
            }
            "count_keys" => {
                if let RuntimeValue::Hash(entries) = self.hash_consuming_arg(raw_args, args, 0, ctx)
                {
                    Ok(RuntimeValue::Number(entries.len() as f64))
                } else {
                    Ok(RuntimeValue::Number(0.0))
                }
            }
            "has_key" => {
                if let RuntimeValue::Hash(entries) = self.hash_consuming_arg(raw_args, args, 0, ctx)
                {
                    let key = args.get(1).map(|a| a.to_str()).unwrap_or_default();
                    Ok(RuntimeValue::Number(
                        if entries.iter().any(|(k, _)| k == &key) {
                            1.0
                        } else {
                            0.0
                        },
                    ))
                } else {
                    Ok(RuntimeValue::Number(0.0))
                }
            }
            "flat_hash" => {
                let mut entries = Vec::new();
                for index in 0..args.len() {
                    let arg = self.hash_consuming_arg(raw_args, args, index, ctx);
                    match arg {
                        RuntimeValue::Hash(h_entries) => {
                            for (k, v) in &h_entries {
                                entries.push((k.clone(), v.clone()));
                            }
                        }
                        _ => {}
                    }
                }
                Ok(RuntimeValue::Hash(entries))
            }
            "next" => {
                // flow skip — equivalent to "continue matching"
                Ok(RuntimeValue::Undef)
            }
            // ── Explicit cursor controls ──
            "save_cursor" => {
                ctx.typed_save_cursor(rule_label, name);
                Ok(RuntimeValue::Undef)
            }
            "restore_cursor" => {
                ctx.typed_restore_cursor(rule_label, name);
                Ok(RuntimeValue::Undef)
            }
            "rewind_match_start" | "rewind_entry_start" => {
                let rewound = if name == "rewind_match_start" {
                    ctx.typed_rewind_match_start(rule_label, name)
                } else {
                    ctx.typed_rewind_entry_start(rule_label, name)
                };
                // Successful zero-argument rewinds expose the validated position.
                Ok(if rewound && raw_args.is_empty() {
                    ctx.typed_position_offset_from_byte(ctx.pos, rule_label, name)
                        .map(|offset| RuntimeValue::Number(offset as f64))
                        .unwrap_or(RuntimeValue::Undef)
                } else {
                    RuntimeValue::Undef
                })
            }
            // ── Conditional flow: if/elseif/else/endif ──
            "if" => {
                // Inline composite: if(cond, then, elseif(cond2, then2), else(else_body))
                // Lazy evaluation — branch bodies NOT evaluated unless their condition
                // matches. raw_args provides AST nodes; eval_expr evaluates conditionally.
                if raw_args.is_empty() {
                    return Ok(RuntimeValue::Undef);
                }
                let cond = self.eval_expr(raw_args[0].value(), ctx, rule_label)?;
                if cond.as_bool() {
                    if raw_args.len() >= 2 {
                        return self.eval_expr(raw_args[1].value(), ctx, rule_label);
                    }
                    return Ok(RuntimeValue::Undef);
                }
                let mut i = 2;
                while i < raw_args.len() {
                    if let linkedspec_core::expr::Arg::Positional(
                        linkedspec_core::expr::Expr::Call {
                            name: branch_name,
                            args: branch_args,
                        },
                    ) = &raw_args[i]
                    {
                        if branch_name == "elseif" && !branch_args.is_empty() {
                            let elseif_cond =
                                self.eval_expr(branch_args[0].value(), ctx, rule_label)?;
                            if elseif_cond.as_bool() {
                                if branch_args.len() >= 2 {
                                    return self.eval_expr(branch_args[1].value(), ctx, rule_label);
                                }
                                return Ok(RuntimeValue::Undef);
                            }
                            i += 1;
                            continue;
                        }
                        if branch_name == "else" && !branch_args.is_empty() {
                            return self.eval_expr(branch_args[0].value(), ctx, rule_label);
                        }
                    }
                    return self.eval_expr(raw_args[i].value(), ctx, rule_label);
                }
                Ok(RuntimeValue::Undef)
            }
            "elseif" => {
                if raw_args.len() >= 2 {
                    let cond = self.eval_expr(raw_args[0].value(), ctx, rule_label)?;
                    if cond.as_bool() {
                        return self.eval_expr(raw_args[1].value(), ctx, rule_label);
                    }
                } else if !raw_args.is_empty() {
                    let _ = self.eval_expr(raw_args[0].value(), ctx, rule_label)?;
                }
                Ok(RuntimeValue::Undef)
            }
            "else" => {
                if let Some(raw) = raw_args.first() {
                    return self.eval_expr(raw.value(), ctx, rule_label);
                }
                Ok(RuntimeValue::Undef)
            }
            "endif" => Ok(RuntimeValue::Undef),
            // ── Conditional flow: switch/case/default/endswitch ──
            "switch" => {
                if raw_args.is_empty() {
                    return Ok(RuntimeValue::Undef);
                }
                let switch_val = self.eval_expr(raw_args[0].value(), ctx, rule_label)?;
                let switch_str = switch_val.to_str();
                let mut i = 1;
                while i < raw_args.len() {
                    if let linkedspec_core::expr::Arg::Positional(
                        linkedspec_core::expr::Expr::Call {
                            name: branch_name,
                            args: branch_args,
                        },
                    ) = &raw_args[i]
                    {
                        if branch_name == "case" && !branch_args.is_empty() {
                            let case_val = self.eval_switch_case_value(
                                branch_args[0].value(),
                                ctx,
                                rule_label,
                            )?;
                            if case_val == switch_str {
                                if branch_args.len() >= 2 {
                                    return self.eval_expr(branch_args[1].value(), ctx, rule_label);
                                }
                                return Ok(RuntimeValue::Undef);
                            }
                            i += 1;
                            continue;
                        }
                        if branch_name == "default" && !branch_args.is_empty() {
                            return self.eval_expr(branch_args[0].value(), ctx, rule_label);
                        }
                    }
                    return self.eval_expr(raw_args[i].value(), ctx, rule_label);
                }
                Ok(RuntimeValue::Undef)
            }
            "while" => {
                if raw_args.len() != 2 {
                    return Ok(RuntimeValue::Undef);
                }
                let linkedspec_core::expr::Expr::BlockValue { block } = raw_args[1].value() else {
                    return Ok(RuntimeValue::Undef);
                };

                let mut iterations = 0usize;
                while self
                    .eval_expr(raw_args[0].value(), ctx, rule_label)?
                    .as_bool()
                {
                    iterations += 1;
                    if iterations > LINKEDSPEC_WHILE_ITERATION_LIMIT {
                        return Err(Self::while_iteration_limit_message());
                    }
                    match self.execute_value_block_side_effects(block, ctx, rule_label)? {
                        ValueBlockFlow::Continue => {}
                        ValueBlockFlow::Returned(value) => return Ok(value),
                    }
                }
                Ok(RuntimeValue::Undef)
            }
            "with" => self.eval_with_trailing_block(raw_args, ctx, rule_label),
            "case" => {
                if raw_args.len() >= 2 {
                    let _ = self.eval_expr(raw_args[0].value(), ctx, rule_label)?;
                    return self.eval_expr(raw_args[1].value(), ctx, rule_label);
                }
                Ok(RuntimeValue::Undef)
            }
            "default" => {
                if let Some(raw) = raw_args.first() {
                    return self.eval_expr(raw.value(), ctx, rule_label);
                }
                Ok(RuntimeValue::Undef)
            }
            "endswitch" | "endcase" => Ok(RuntimeValue::Undef),
            _ => {
                if let Some(result) =
                    self.execute_bound_codeblock_call(name, raw_args, args, ctx, rule_label)
                {
                    return result;
                }
                if ctx.has_active_codeblock() {
                    ctx.capture_callable_codeblock_failure(
                        rule_label,
                        CallableCodeblockFailure::UnknownHelper {
                            name: name.to_string(),
                        },
                    );
                    return Err(format!(
                        "unknown_helper name={name:?} rule_label={rule_label:?}"
                    ));
                }
                eprintln!(
                    "warning: unknown helper '{}' in rule '{}' — returning undef",
                    name, rule_label
                );
                Ok(RuntimeValue::Undef)
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use linkedspec_core::compiler::compile;
    use linkedspec_core::parser::parse_spec;
    use linkedspec_core::validation::validate;

    #[test]
    fn minimum_miss_restores_caller_match_and_return_without_rollback() {
        fn capture_fields(ctx: &RuntimeContext) -> Value {
            serde_json::json!({
                "entry_groups":ctx.entry_groups,"entry_spans":ctx.entry_group_spans,
                "entry_named":ctx.entry_named,"entry_present":ctx.entry_match_present,
                "match_groups":ctx.match_groups,"match_spans":ctx.match_group_spans,
                "match_named":ctx.match_named,"match_present":ctx.match_present,
                "entry_start":ctx.entry_start_byte,"entry_end":ctx.entry_end_byte,
                "match_start":ctx.match_start_byte,"match_end":ctx.match_end_byte,
                "capture_start":ctx.capture_start
            })
        }
        for kind in ["regex", "blind"] {
            for mode in ["OR{2}", "AND{2}"] {
                let body = if kind == "regex" {
                    "/a/\n"
                } else {
                    "=> Part\n"
                };
                let child = if kind == "blind" {
                    "Part:|\n /a/ -> Part[0] {return(1)}\n"
                } else {
                    ""
                };
                let source = format!(
                    "Value::{mode}\n {body} EX {{return(\"EXIT\")}}\n E {{return(\"EXIT\")}}\n{child}"
                );
                let parsed = crate::spec_parser::parse_spec_with_user_functions(&source).unwrap();
                validate(&parsed).unwrap();
                let compiled = compile(&parsed).unwrap();
                let rules: Vec<_> = compiled
                    .rules
                    .iter()
                    .map(|rule| GeneratedRuleSpec {
                        label: match rule.label.as_str() {
                            "Value" => "Value",
                            "Part" => "Part",
                            _ => unreachable!(),
                        },
                        family: crate::source_emitter::classify_generated_rule_family(rule),
                    })
                    .collect();
                let engine = Engine::new(compiled);
                for generated in [false, true] {
                    let mut ctx = RuntimeContext::new("EPa");
                    ctx.pos = 2;
                    ctx.entry_groups = vec!["E".into()];
                    ctx.entry_group_spans = vec![(0, 1)];
                    ctx.entry_named.insert("entry".into(), "E".into());
                    ctx.entry_match_present = true;
                    ctx.entry_start_byte = 0;
                    ctx.entry_end_byte = 1;
                    ctx.match_groups = vec!["P".into()];
                    ctx.match_group_spans = vec![(1, 2)];
                    ctx.match_named.insert("local".into(), "P".into());
                    ctx.match_present = true;
                    ctx.match_start_byte = 1;
                    ctx.match_end_byte = 2;
                    ctx.capture_start = Some(1);
                    ctx.set_return_value(RuntimeValue::Scalar("CALLER".into()));
                    let before = capture_fields(&ctx);
                    let result = if generated {
                        GeneratedPlanExecutor {
                            engine: &engine,
                            generated_rules: &rules,
                            source_identity: None,
                        }
                        .execute_rule("Value", 0, &mut ctx)
                    } else {
                        engine.execute_rule("Value", 0, &mut ctx)
                    }
                    .unwrap();
                    let after = capture_fields(&ctx);
                    let caller = ctx.take_return_value().unwrap().to_json();
                    eprintln!(
                        "RUST_MINIMUM_PRIVATE_RESTORE {kind}_{mode}_{generated} {}",
                        serde_json::json!({"source":source,"before":before,"after":after,"caller":caller,"result":result.to_json(),"cursor":ctx.pos})
                    );
                    assert_eq!(result.to_json(), Value::Null);
                    assert_eq!(ctx.pos, 3, "minimum miss must keep consumed cursor");
                    assert_eq!(after, before);
                    assert_eq!(caller, serde_json::json!("CALLER"));
                }
            }
        }
    }

    #[test]
    fn minimum_miss_direct_generated_recognition_separates_null_and_match() {
        for kind in ["acode", "bcode"] {
            for mode in ["OR{2}", "AND{2}"] {
                let (body, child) = if kind == "acode" {
                    ("/a/ -> Value[0] {return(1)}", "")
                } else {
                    ("=> Part", "Part:|\n /a/ -> Part[0] {return(1)}\n")
                };
                let source = format!(
                    "Value::{mode}\n {body}\n EX {{return(undef)}}\n E {{return(undef)}}\n{child}"
                );
                let parsed = crate::spec_parser::parse_spec_with_user_functions(&source).unwrap();
                validate(&parsed).unwrap();
                let compiled = compile(&parsed).unwrap();
                let rules: Vec<_> = compiled
                    .rules
                    .iter()
                    .map(|rule| GeneratedRuleSpec {
                        label: match rule.label.as_str() {
                            "Value" => "Value",
                            "Part" => "Part",
                            _ => unreachable!(),
                        },
                        family: crate::source_emitter::classify_generated_rule_family(rule),
                    })
                    .collect();
                let engine = Engine::new(compiled);
                for (input, accepted, cursor) in [("aa", true, 2), ("a", false, 1), ("", false, 0)]
                {
                    let mut ctx = RuntimeContext::new(input);
                    let base = ctx.begin_recognition_scope("Observer");
                    let result = GeneratedPlanExecutor {
                        engine: &engine,
                        generated_rules: &rules,
                        source_identity: None,
                    }
                    .execute_rule("Value", 0, &mut ctx)
                    .unwrap()
                    .to_json();
                    let matched = ctx.finish_recognition_scope(base, "Value").unwrap();
                    eprintln!(
                        "RUST_MINIMUM_PRIVATE_GENERATED {kind}_{mode} {}",
                        serde_json::json!({"source":source,"input":input,"result":result,"matched":matched,"cursor":ctx.pos})
                    );
                    assert_eq!(result, Value::Null);
                    assert_eq!(matched, accepted);
                    assert_eq!(ctx.pos, cursor);
                }
            }
        }
    }

    #[test]
    fn live_recognition_progress_keeps_provenance_and_cleans_scope() {
        for (name, source, input, offset) in [
            (
                "entry_zero",
                "Top::\n I {tx=recognition_checkpoint();matched=recognize_once(tx,call(Guard));recognition_commit(tx);return(matched)}\n /never/\nGuard:+\n /(?=a)/ -> Guard[0] {return(0)}\n",
                "a",
                0,
            ),
            (
                "after_prefix",
                "Top::AND\n /x/ -> Top[0] {tx=recognition_checkpoint();matched=recognize_once(tx,call(Guard));recognition_commit(tx);return(matched)}\nGuard:OR{1}\n /(?=a)/ -> Guard[0] {return(0)}\n",
                "xa",
                1,
            ),
        ] {
            let parsed = crate::spec_parser::parse_spec_with_user_functions(source).unwrap();
            validate(&parsed).unwrap();
            let engine = Engine::new(compile(&parsed).unwrap());
            let mut ctx = RuntimeContext::new(input);
            let message = engine
                .execute_value_with_context(&mut ctx, &ExecutionOptions::new())
                .expect_err("live guard");
            let record = ctx.recognition_progress_failure().unwrap().as_record();
            eprintln!(
                "RUST_LIVE_PROGRESS_PRIVATE {name} {}",
                serde_json::json!({"source":source,"input":input,"record":record,"message":message})
            );
            assert_eq!(
                record,
                serde_json::json!({"code":"recognition_zero_progress_repetition","rule":"Guard","origin":"Top:recognize_once","start_offset":offset,"end_offset":offset})
            );
            let projected = engine.structured_runtime_error(&ctx, message);
            assert_eq!(
                projected.diagnostic().code.as_deref(),
                Some("recognition_zero_progress_repetition")
            );
            assert_eq!(projected.diagnostic().rule_label.as_deref(), Some("Guard"));
            // The actual RecognizeOnce error path canceled its scope. A later
            // ordinary loop must not inherit strict recognition behavior.
            assert!(
                ctx.assert_recognition_repetition_progress(
                    "After",
                    offset as usize,
                    offset as usize
                )
                .is_ok()
            );
        }
    }

    #[test]
    fn live_recognition_progress_direct_generated_loops_reject_and_clean() {
        for (name, source) in [
            (
                "acode_choice",
                "Guard::OR{1}\n /(?=a)/ -> Guard[0] {return(0)}\n",
            ),
            (
                "acode_and",
                "Guard::AND{1}\n /(?=a)/ -> Guard[0] {return(0)}\n",
            ),
            (
                "bcode_choice",
                "Guard::OR{1}\n => Atom\nAtom:|\n /(?=a)/ -> Atom[0] {return(0)}\n",
            ),
            (
                "bcode_and",
                "Guard::AND{1}\n => Atom\nAtom:|\n /(?=a)/ -> Atom[0] {return(0)}\n",
            ),
            (
                "bcode_default",
                "Guard::\n => Atom\nAtom:|\n /(?=a)/ -> Atom[0] {return(0)}\n",
            ),
        ] {
            let parsed = crate::spec_parser::parse_spec_with_user_functions(source).unwrap();
            validate(&parsed).unwrap();
            let compiled = compile(&parsed).unwrap();
            let rules: Vec<_> = compiled
                .rules
                .iter()
                .map(|rule| GeneratedRuleSpec {
                    label: match rule.label.as_str() {
                        "Guard" => "Guard",
                        "Atom" => "Atom",
                        _ => unreachable!(),
                    },
                    family: crate::source_emitter::classify_generated_rule_family(rule),
                })
                .collect();
            let engine = Engine::new(compiled);
            let mut ctx = RuntimeContext::new("a");
            // Exercise the existing lower-level generated-loop entrypoint in
            // an active caller scope, independently of shared expression
            // callbacks that dispatch their recognize_once callee natively.
            let base = ctx.begin_recognition_scope("Observer");
            let message = engine
                .execute_generated_value_with_plan_context(
                    &rules,
                    &mut ctx,
                    Some("direct-live-progress.spec"),
                    &ExecutionOptions::new(),
                )
                .expect_err("generated live guard");
            let record = ctx.recognition_progress_failure().unwrap().as_record();
            eprintln!(
                "RUST_LIVE_PROGRESS_DIRECT {name} {}",
                serde_json::json!({"source":source,"record":record,"message":message})
            );
            assert_eq!(
                record,
                serde_json::json!({"code":"recognition_zero_progress_repetition","rule":"Guard","origin":"Observer:recognize_once","start_offset":0,"end_offset":0})
            );
            ctx.cancel_recognition_scope(base);
            assert!(
                ctx.assert_recognition_repetition_progress("After", 0, 0)
                    .is_ok()
            );
        }
    }

    #[test]
    fn live_recognition_progress_direct_generated_groups_measure_whole_cursor() {
        for (name, source, input) in [
            (
                "leading_zero",
                "Guard::AND{1}\n /(?=a)/\n /a/ -> Guard[1] {return(0)}\n",
                "a",
            ),
            (
                "trailing_zero",
                "Guard::AND{1}\n /a/\n /(?=b)/ -> Guard[1] {return(0)}\n",
                "ab",
            ),
        ] {
            let parsed = crate::spec_parser::parse_spec_with_user_functions(source).unwrap();
            validate(&parsed).unwrap();
            let compiled = compile(&parsed).unwrap();
            let rules = [GeneratedRuleSpec {
                label: "Guard",
                family: crate::source_emitter::classify_generated_rule_family(&compiled.rules[0]),
            }];
            let engine = Engine::new(compiled);
            let mut ctx = RuntimeContext::new(input);
            let base = ctx.begin_recognition_scope("Observer");
            let value = engine
                .execute_generated_value_with_plan_context(
                    &rules,
                    &mut ctx,
                    Some("direct-live-progress.spec"),
                    &ExecutionOptions::new(),
                )
                .unwrap();
            eprintln!(
                "RUST_LIVE_PROGRESS_DIRECT_POSITIVE {name} {}",
                serde_json::json!({"source":source,"input":input,"value":value,"cursor":ctx.pos})
            );
            assert_eq!(value, serde_json::json!([0]));
            assert_eq!(ctx.pos, 1);
            assert!(ctx.recognition_progress_failure().is_none());
            assert!(ctx.finish_recognition_scope(base, "Guard").unwrap());
        }
    }

    #[test]
    fn indexed_var_observes_current_binding_instead_of_stale_private_array() {
        let engine = Engine::new(compile(&parse_spec("Top:\n").unwrap()).unwrap());
        let mut ctx = RuntimeContext::new("");
        let read = Expr::IndexedVar {
            name: "items".into(),
            index: Box::new(Expr::NumberLiteral { value: 0.0 }),
        };
        ctx.set_array("items", vec![RuntimeValue::Scalar("old".into())]);
        assert_eq!(
            engine.eval_expr(&read, &mut ctx, "Top").unwrap().to_json(),
            serde_json::json!("old")
        );
        for (value, expected) in [
            (
                RuntimeValue::Array(vec![RuntimeValue::Scalar("new".into())]),
                serde_json::json!("new"),
            ),
            (RuntimeValue::Array(vec![]), Value::Null),
            (RuntimeValue::Scalar("text".into()), Value::Null),
            (
                RuntimeValue::Hash(vec![("0".into(), RuntimeValue::Number(7.0))]),
                Value::Null,
            ),
            (RuntimeValue::Undef, Value::Null),
        ] {
            ctx.set_scalar("items", value);
            assert_eq!(
                engine.eval_expr(&read, &mut ctx, "Top").unwrap().to_json(),
                expected
            );
        }
        let mut absent = RuntimeContext::new("");
        assert_eq!(
            engine
                .eval_expr(&read, &mut absent, "Top")
                .unwrap()
                .to_json(),
            Value::Null
        );
        assert!(
            !absent.has_bare_binding("items"),
            "reads do not create bindings"
        );
    }

    #[test]
    fn indexed_var_preserves_existing_read_index_coercion() {
        let engine = Engine::new(compile(&parse_spec("Top:\n").unwrap()).unwrap());
        // Whole negative numbers select from the tail; other existing read
        // coercions remain distinct from the stricter write selectors.
        for (index, expected) in [
            (RuntimeValue::Number(0.0), serde_json::json!("a")),
            (RuntimeValue::Number(1.0), serde_json::json!("b")),
            (RuntimeValue::Number(9.0), Value::Null),
            (RuntimeValue::Number(-1.0), serde_json::json!("b")),
            (RuntimeValue::Number(-2.0), serde_json::json!("a")),
            (RuntimeValue::Number(-3.0), Value::Null),
            (RuntimeValue::Number(-1.5), serde_json::json!("a")),
            (RuntimeValue::Number(1.9), serde_json::json!("b")),
            (RuntimeValue::Scalar("1".into()), serde_json::json!("b")),
            (RuntimeValue::Scalar("-1".into()), serde_json::json!("a")),
            (RuntimeValue::Scalar("bad".into()), serde_json::json!("a")),
            (RuntimeValue::Undef, serde_json::json!("a")),
        ] {
            for scalar_storage in [false, true] {
                let mut ctx = RuntimeContext::new("");
                let items = vec![
                    RuntimeValue::Scalar("a".into()),
                    RuntimeValue::Scalar("b".into()),
                ];
                if scalar_storage {
                    ctx.set_scalar("items", RuntimeValue::Array(items));
                } else {
                    ctx.set_array("items", items);
                }
                ctx.set_scalar("index", index.clone());
                let read = Expr::IndexedVar {
                    name: "items".into(),
                    index: Box::new(Expr::Variable {
                        name: "index".into(),
                    }),
                };
                assert_eq!(
                    engine.eval_expr(&read, &mut ctx, "Top").unwrap().to_json(),
                    expected,
                    "{index:?}, scalar storage {scalar_storage}"
                );
            }
        }
    }

    #[test]
    fn indexed_var_resolves_binding_after_index_expression_effects() {
        let engine = Engine::new(compile(&parse_spec("Top:\n").unwrap()).unwrap());
        let mut ctx = RuntimeContext::new("");
        ctx.set_array("items", vec![RuntimeValue::Scalar("old".into())]);
        let read = Expr::IndexedVar {
            name: "items".into(),
            index: Box::new(Expr::AssignScalar {
                name: "items".into(),
                value: Box::new(Expr::ArrayLiteral {
                    items: vec![Expr::StringLiteral {
                        value: "new".into(),
                    }],
                }),
            }),
        };
        assert_eq!(
            engine.eval_expr(&read, &mut ctx, "Top").unwrap().to_json(),
            serde_json::json!("new")
        );
        assert_eq!(
            ctx.get_bare_value("items").to_json(),
            serde_json::json!(["new"])
        );
    }

    const SIMPLE_GRAMMAR: &str = r#"DemoParser::
 /pattern1/ -> Child
 I { set(results, []) }
 LE { push(results, retv) }
 E { return(array("?results:", copy(results))) }

Child::
 /hello[ \t]+(\w+)/
 I { name = entry_group(0) }
 E { return(name) }
"#;

    #[test]
    fn engine_executes_simple_grammar() {
        let spec = parse_spec(SIMPLE_GRAMMAR).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("pattern1 hello world").unwrap();
        assert!(result.is_array());
    }

    #[test]
    fn engine_empty_input() {
        let spec = parse_spec(SIMPLE_GRAMMAR).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("no match here").unwrap();
        assert!(result.is_array());
    }

    #[test]
    fn recursive_observation_binds_aborted_record_before_propagating_child_error() {
        let source = r#"Top:
AbortChild:
 I { recognition_commit(missing) }
"#;
        let spec = parse_spec(source).unwrap();
        validate(&spec).unwrap();
        let engine = Engine::new(compile(&spec).unwrap());
        let mut ctx = RuntimeContext::new("");
        ctx.enter_recognition_invocation("Top", false, None)
            .unwrap();
        let observation_expr = Expr::ObserveRecognition {
            target: "observation".to_owned(),
            rule: "AbortChild".to_owned(),
        };

        let error = engine
            .eval_expr(&observation_expr, &mut ctx, "Top")
            .expect_err("child error must propagate");
        assert!(error.contains("recognition_token_expected"), "{error}");
        let observation = RuntimeValue::Hash(ctx.get_hash("observation")).to_json();
        assert_eq!(observation["rule_label"], "AbortChild");
        assert_eq!(observation["outcome"], "aborted");
        assert_eq!(observation["accepted_exit"], Value::Null);
        assert_eq!(observation["diagnostic"], Value::Null);
        ctx.leave_recognition_invocation("Top").unwrap();
    }

    #[test]
    fn engine_json_output_roundtrip() {
        let spec = parse_spec(SIMPLE_GRAMMAR).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("pattern1 hello world").unwrap();
        let json_str = serde_json::to_string(&result).unwrap();
        let _parsed: Value = serde_json::from_str(&json_str).unwrap();
    }

    #[test]
    fn execute_value_returns_direct_rule_value_without_legacy_wrapper() {
        let grammar = r#"Top::
 /x/
 E { return("direct") }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let engine = Engine::new(compile(&spec).unwrap());
        assert_eq!(engine.execute("x").unwrap(), serde_json::json!(["direct"]));
        assert_eq!(
            engine.execute_value("x", &ExecutionOptions::new()).unwrap(),
            serde_json::json!("direct")
        );
    }

    #[test]
    fn execute_value_selects_entry_rule_without_cursor_override_state() {
        let grammar = r#"Top::
 /x/ -> Done { return("top") }

Alternate:
 /x/ -> Done { return("alternate") }

Done::
 /x/
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let engine = Engine::new(compile(&spec).unwrap());
        let alternate = ExecutionOptions::new().with_entry_rule("Alternate");
        assert_eq!(
            engine.execute_value("prefix x", &alternate).unwrap(),
            serde_json::json!("alternate"),
            "Alternate retains its authored seek policy"
        );
        assert!(
            engine
                .execute_value("x", &ExecutionOptions::new().with_entry_rule("Missing"))
                .unwrap_err()
                .contains("entry rule 'Missing' is not defined")
        );
    }

    // ── Lifecycle order tests ──

    #[test]
    fn lifecycle_all_markers_fire_in_order() {
        // Grammar that exercises all 7 lifecycle markers with REP (* mode).
        let grammar = r#"Top::*
 /hello/
 I { set(log, []); push(log, "I") }
 LS { push(log, "LS") }
 LE { push(log, "LE") }
 IT { push(log, "IT") }
 LX { push(log, "LX") }
 EX { push(log, "EX") }
 E { push(log, "E"); return(copy(log)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // "hello hello" → REP matches twice → I, LS, LE, IT, LS, LE, IT, EX, E
        let result = engine.execute("hello hello").unwrap();
        // Result is [["I","LS","LE","IT","LS","LE","IT","EX","E"]]
        let outer: &Vec<Value> = result.as_array().unwrap();
        let inner: &Vec<Value> = outer[0].as_array().unwrap();
        let strs: Vec<&str> = inner.iter().map(|v| v.as_str().unwrap()).collect();
        assert_eq!(strs[0], "I");
        assert!(strs.contains(&"LS"));
        assert!(strs.contains(&"LE"));
        assert!(strs.contains(&"IT"));
        assert!(strs.contains(&"EX"));
        assert_eq!(strs[strs.len() - 1], "E");
        // LX fires on loop exhaustion (when REP runs out of matches)
        assert!(strs.contains(&"LX"), "LX should fire on REP exhaustion");
    }

    #[test]
    fn lifecycle_lx_fires_on_no_match() {
        // Use * (0 or more) so that zero matches is valid; LX fires on first no-match.
        let grammar = r#"Top::*
 /hello/
 I { set(log, []); push(log, "I") }
 LS { push(log, "LS") }
 LX { push(log, "LX") }
 E { push(log, "E"); return(copy(log)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("no match").unwrap();
        let outer: &Vec<Value> = result.as_array().unwrap();
        let inner: &Vec<Value> = outer[0].as_array().unwrap();
        let strs: Vec<&str> = inner.iter().map(|v| v.as_str().unwrap()).collect();
        assert_eq!(strs[0], "I");
        assert_eq!(strs[1], "LS");
        assert_eq!(strs[2], "LX");
        assert_eq!(strs[3], "E");
    }

    #[test]
    fn default_mode_repeats_action_edge_choices_and_allows_zero_matches() {
        let grammar = r#"Top::
 -> Item .push
 LX.return(array("top", copy(Top)))

Item: /x/ I.return("x")
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);

        let repeated = engine.execute("xx").unwrap();
        assert_eq!(repeated, serde_json::json!([["top", ["x", "x"]]]));

        let empty = engine.execute("").unwrap();
        assert_eq!(empty, serde_json::json!([["top", []]]));
    }

    // ── REP bounds tests ──

    #[test]
    fn rep_min_not_met_returns_an_ordinary_miss() {
        // OR{2,} — minimum 2 matches required
        let grammar = r#"Top::OR{2,}
 /hello/
 E { return(1) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // Compatibility correction: an input miss is a null direct value
        // and contributes no value to the legacy accumulator envelope.
        assert_eq!(
            engine
                .execute_value("hello world", &ExecutionOptions::new())
                .unwrap(),
            Value::Null
        );
        assert_eq!(
            engine.execute("hello world").unwrap(),
            serde_json::json!([])
        );
    }

    #[test]
    fn rep_max_stops_at_bound() {
        // OR{,1} — at most 1 match
        let grammar = r#"Top::OR{,1}
 /hello/
 I { set(log, []) }
 LE { push(log, "match") }
 E { return(copy(log)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // "hello hello" → should match only once due to max=1
        let result = engine.execute("hello hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(
            arr.len(),
            1,
            "expected 1 match due to max bound, got {:?}",
            arr
        );
    }

    #[test]
    fn rep_zero_or_more_matches_nothing() {
        // * — zero or more, should succeed with zero matches
        let grammar = r#"Top::*
 /hello/
 E { return(1) }
"#;
        let spec = parse_spec(grammar).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("no match").unwrap();
        assert!(result.is_array());
    }

    // ── Blind-call dispatch tests ──

    #[test]
    fn blind_call_and_rule_dispatches_children() {
        // Child dispatch is still allowed to mutate caller-visible working
        // variables when the child does not bind the same name locally.
        let grammar = r#"Top::AND
 I { set(log, []) }
 => ChildA
 => ChildB
 E { return(copy(log)) }

ChildA:
 /a/
 I { push(log, "A") }

ChildB:
 /b/
 I { push(log, "B") }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("a b").unwrap();
        let outer: &Vec<Value> = result.as_array().unwrap();
        assert!(!outer.is_empty());
        let inner: &Vec<Value> = outer[0].as_array().unwrap();
        assert_eq!(
            inner.len(),
            2,
            "expected 2 children in log, got {:?}",
            inner
        );
        assert_eq!(inner[0].as_str().unwrap(), "A");
        assert_eq!(inner[1].as_str().unwrap(), "B");
    }

    // ── Self-recursive / multi-entrypoint tests ──

    #[test]
    fn self_recursive_rule_uses_different_entrypoints() {
        // Rule enters itself at different regex slots
        let grammar = r#"A::
 /[A-Za-z_]\w*/
 /"(?:[^"\\]|\\.)*"/
 /\d+/
 I { set(results, []) }
 -> A
 -> A[1]
 -> A[2]
 E { return(copy(results)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // Matches identifier, then identifier fallback
        let result = engine.execute(r#"hello"#).unwrap();
        assert!(result.is_array());
    }

    // ── Accumulator tests ──

    #[test]
    fn accumulator_collects_child_results() {
        let grammar = r#"DemoParser::
 /pattern1/ -> ChildA
 /pattern2/ -> ChildB
 I { set(results, []) }
 LE { push(results, retv) }
 E { return(array("?results:", copy(results))) }

ChildA:
 /hello/
 I { retv = entry_text() }
 E { return(retv) }

ChildB:
 /world/
 I { retv = entry_text() }
 E { return(retv) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("pattern1 hello pattern2 world").unwrap();
        let arr = result.as_array().unwrap();
        assert!(!arr.is_empty());
    }

    // ── Keyword argument tests ──

    #[test]
    fn declare_with_keyword_arg_initializer() {
        // Declare in I, populate in E (entry_text() is valid AFTER match)
        let grammar = r#"Top::
 /hello/
 I { name = undef }
 E { name = entry_text(); return(name) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let outer: &Vec<Value> = result.as_array().unwrap();
        assert_eq!(outer[0].as_str().unwrap(), "hello");
    }

    // ── .5.1 Declaration and array helper tests ──

    #[test]
    fn helpers_5_1_declare_scalar_with_default() {
        let grammar = r#"Top::
 /hello/
 I { name = undef }
 E { return(name) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        // scalar declared without initializer returns undef → JSON null
        let arr = result.as_array().unwrap();
        assert!(arr[0].is_null(), "expected null, got {:?}", arr[0]);
    }

    #[test]
    fn helpers_5_1_declare_scalar_with_initializer() {
        // entry_group is only available AFTER match, so use LE to assign
        let grammar = r#"Top::
 /(\w+)/
 I { word = undef }
 LE { word = entry_group(0) }
 E { return(word) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello");
    }

    #[test]
    fn helpers_5_1_assign_scalar() {
        let grammar = r#"Top::
 /(\w+)/
 I { word = undef }
 E { word = entry_group(0); return(word) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello");
    }

    #[test]
    fn helpers_5_1_declare_array_push_value_copy() {
        let grammar = r#"Top::
 /(\w+)/
 I { set(results, []) }
 LE { push(results, entry_group(0)) }
 E { return(copy(results)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let outer: &Vec<Value> = result.as_array().unwrap();
        let inner: &Vec<Value> = outer[0].as_array().unwrap();
        assert_eq!(inner[0].as_str().unwrap(), "hello");
    }

    #[test]
    fn helpers_5_1_return_value_and_count() {
        let grammar = r#"Top::
 /(\w+)/
 I { set(items, []); item_count = undef }
 LE { push(items, entry_group(0)) }
 E { item_count = count(items); return(item_count) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert!(arr[0].is_number(), "expected number, got {:?}", arr[0]);
        assert_eq!(arr[0].as_f64().unwrap(), 1.0);
    }

    #[test]
    fn helpers_5_1_explicit_nonempty_guarded_push() {
        let grammar = r#"Top::
 /(\w+)/
 I { set(items, []) }
 LE { if(is_nonempty(entry_group(0)), push(items, entry_group(0))) }
 E { return(copy(items)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let outer: &Vec<Value> = result.as_array().unwrap();
        let inner: &Vec<Value> = outer[0].as_array().unwrap();
        assert!(!inner.is_empty());
    }

    #[test]
    fn helpers_5_1_hash_roundtrip() {
        // Use hash() constructor and copy() for roundtrip
        let grammar = r#"Top::
 /(\w+)=(\d+)/
 I { set(config, hash()) }
 LE { set_key(config, entry_group(0), entry_group(1)) }
 E { return(entry_group(0)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("key=42").unwrap();
        let arr = result.as_array().unwrap();
        // Returns the matched key
        assert_eq!(arr[0].as_str().unwrap(), "key");
    }

    #[test]
    fn helpers_5_1_unknown_helper_spellings_use_generic_unknown_helper_path() {
        fn execute_snippet(snippet: &str) -> Value {
            let grammar = format!("Top::\n /x/\n E {{ {snippet} }}\n");
            let spec = parse_spec(&grammar).expect("parse unknown-helper fixture");
            validate(&spec).expect("validate unknown-helper fixture");
            let compiled = compile(&spec).expect("compile unknown-helper fixture");
            Engine::new(compiled)
                .execute("x")
                .expect("generic unknown helper should return undef instead of failing")
        }

        let cases = [
            (
                "unknown_decl_helper(v); return(v)",
                serde_json::json!([null]),
            ),
            (
                "return(unknown_array_copy_helper(items))",
                serde_json::json!([null]),
            ),
            (
                "return(unknown_hash_copy_helper(meta))",
                serde_json::json!([null]),
            ),
            (
                "return(unknown_concat_helper(\"a\", \"b\"))",
                serde_json::json!([null]),
            ),
            (
                "unknown_push_value_helper(items, \"a\"); return(copy(items))",
                serde_json::json!([[]]),
            ),
            (
                "unknown_push_nonempty_helper(items, \"a\"); return(copy(items))",
                serde_json::json!([[]]),
            ),
            (
                "return(unknown_array_wrapper(items))",
                serde_json::json!([null]),
            ),
            (
                "return(unknown_hash_wrapper(meta))",
                serde_json::json!([null]),
            ),
        ];

        for (snippet, expected) in cases {
            assert_eq!(
                execute_snippet(snippet),
                expected,
                "unknown helper spelling should follow generic unknown-helper behavior: {snippet}"
            );
        }
    }

    // ── .5.2 Scalar and capture helper tests ──

    #[test]
    fn helpers_5_2_entry_text_and_entry_group() {
        let grammar = r#"Top::
 /hello[ \t]+(\w+)/
 E { return(cat(entry_text(), " ", entry_group(0))) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello world").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello world world");
    }

    #[test]
    fn helpers_5_2_absent_entry_group_is_undef() {
        let grammar = r#"Top::
 /([A-Za-z]+)(?:\[(\d+)\])?/
 E { return(hash("target", entry_group(0), "index", entry_group(1))) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);

        assert_eq!(
            engine.execute("Name").unwrap(),
            serde_json::json!([{"index": null, "target": "Name"}])
        );
        assert_eq!(
            engine.execute("Name[2]").unwrap(),
            serde_json::json!([{"index": "2", "target": "Name"}])
        );
    }

    #[test]
    fn helpers_5_2_entry_groups_array() {
        let grammar = r#"Top::
 /(\w+)=(\d+)/
 E { return(entry_groups()) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("key=42").unwrap();
        let outer: &Vec<Value> = result.as_array().unwrap();
        let groups: &Vec<Value> = outer[0].as_array().unwrap();
        assert_eq!(
            groups,
            &vec![serde_json::json!("key"), serde_json::json!("42")]
        );
    }

    #[test]
    fn helpers_5_2_scalar_accessor() {
        // varname returns the declared variable's value
        let grammar = r#"Top::
 /(\w+)/
 I { word = undef }
 LE { word = entry_group(0) }
 E { return(word) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello");
    }

    #[test]
    fn helpers_5_2_coalesce_first_defined() {
        let grammar = r#"Top::
 /(\w+)/
 I { first = undef; second = undef }
 E { return(coalesce(first, second, "default")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // Both first and second are undef, so coalesce falls back to "default"
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "default");
    }

    #[test]
    fn helpers_5_2_coalesce_short_circuits() {
        let grammar = r#"Top::
 /(\w+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(coalesce(val, "fallback")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello");
    }

    #[test]
    fn helpers_5_2_concat_strings() {
        let grammar = r#"Top::
 /(\w+) (\w+)/
 E { return(cat(entry_group(0), "+", entry_group(1))) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello world").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello+world");
    }

    #[test]
    fn helpers_5_2_capture_slice_basic() {
        // RUST-PARITY.5.5.4: `capture_slice()` now ends at the START of the current
        // local match (Perl `$LSPOS - $IPOS - length $LMATCH`), not the cursor. The
        // I-block starts the capture at pos 0; over "hello" the match also starts at
        // 0, so nothing precedes the match → "" (parity-correct; see
        // helpers_5_5_4_capture_slice_reads_pre_match_text for the non-empty case).
        let grammar = r#"Top::
 /(\w+)/
 I { start_capture_slice() }
 LE { return(capture_slice()) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "");
    }

    #[test]
    fn helpers_5_2_capture_slice_len() {
        // RUST-PARITY.5.5.4: capture started at the match start (pos 0) → length 0.
        let grammar = r#"Top::
 /(\w+)/
 I { start_capture_slice() }
 LE { return(capture_slice_len()) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_f64().unwrap(), 0.0);
    }

    #[test]
    fn helpers_5_2_mark_and_capture_from() {
        // RUST-PARITY.5.5.3: `capture_from(mark)` now ends at the **start** of the
        // current local match (Perl parity: `$LSPOS - length $LMATCH`), not the
        // cursor / match-end. The mark is set at pos 0 (I-block) and the match
        // "hello" also starts at byte 0, so the span mark→match-start is empty.
        // (Before .5.5.3 this wrongly read to match-end and returned "hello".)
        let grammar = r#"Top::
 /(\w+)/
 I { mark_here("start") }
 LE { return(capture_from("start")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "");
    }

    #[test]
    fn helpers_5_2_mark_pos() {
        let grammar = r#"Top::
 /(\w+)/
 I { mark_here("pos") }
 LE { return(mark_pos("pos")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_f64().unwrap(), 0.0); // mark at start of input (pos 0 in I-block)
    }

    // ── .5.3 Control flow helper tests ──

    #[test]
    fn helpers_5_3_return_undef_skips_accumulator() {
        let grammar = r#"Top::
 /(\w+)/
 I { set(items, []) }
 LE { push(items, entry_group(0)) }
 E { return(copy(items)); return_undef() }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        // return_undef after return — doesn't add to accumulator
        assert!(!arr.is_empty());
    }

    #[test]
    fn helpers_5_3_exit_now_terminates() {
        let grammar = r#"Top::
 /bye/
 I { exit_now(1) }
 E { return("never_reached") }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("bye");
        assert!(result.is_err(), "exit_now should terminate with error");
        assert!(result.unwrap_err().contains("exit_now(1)"));
    }

    #[test]
    fn helpers_5_3_next_skips() {
        // next() returns undef — used as control flow skip in loops
        let grammar = r#"Top::
 /(\w+)/
 I { retv = next() }
 E { return(retv) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        // next() returns undef
        assert!(
            arr[0].is_null(),
            "next() should return null, got {:?}",
            arr[0]
        );
    }

    #[test]
    fn helpers_5_3_coalesce_nonempty_skips_empty() {
        // coalesce_nonempty skips undef and "" but keeps "0" and other defined values
        let grammar = r#"Top::
 /(\d+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(coalesce_nonempty("", val, "final")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("42").unwrap();
        let arr = result.as_array().unwrap();
        // "" is nonempty? Actually "" returns Scalar("") which IS empty
        // coalesce_nonempty skips empty strings, picks "42"
        assert_eq!(arr[0].as_str().unwrap(), "42");
    }

    // ═══════════════════════════════════════════════════════════
    // Conditional flow tests — if/elseif/else/switch/case/default
    // ═══════════════════════════════════════════════════════════

    #[test]
    fn cond_if_basic_then_branch() {
        let grammar = r#"Top::
 /(\w+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(if(is_nonempty(val), "found", "empty")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "found");
    }

    #[test]
    fn cond_if_falsy_falls_through_to_else() {
        // Undef variable → condition falsy → else branch
        let grammar = r#"Top::
 /(\w+)/
 I { val = undef }
 E { return(if(is_defined(val), "defined", "undefined")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        // val declared but never assigned → undef → is_defined false → "undefined"
        assert_eq!(arr[0].as_str().unwrap(), "undefined");
    }

    #[test]
    fn cond_if_three_arg_else_fallback() {
        // if(cond, then, else) — 3 positional args
        let grammar = r#"Top::
 /(\w+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(if(is_defined(val), entry_text(), "fallback")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // val IS defined (we assigned it in LE), so then-branch returns entry_text
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello");
    }

    #[test]
    fn cond_if_with_elseif_chain() {
        // 0 is falsy, 1 is truthy — tests if/elseif chain with literal conditions
        let grammar = r#"Top::
 /(\w+)/
 E { return(if(0, "then",
               elseif(1, "elseif_ok"),
               "none")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // 0 is falsy → skip then. 1 is truthy → "elseif_ok"
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "elseif_ok");
    }

    #[test]
    fn cond_if_all_falsy_falls_to_else() {
        let grammar = r#"Top::
 /(\w+)/
 I { a = undef; b = undef; c = undef }
 E { return(if(is_nonempty(a), "a",
               elseif(is_nonempty(b), "b"),
               else("none"))) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // None of a, b assigned → all empty/undef → "none"
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "none");
    }

    #[test]
    fn cond_switch_basic_case_match() {
        let grammar = r#"Top::
 /(\w+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(switch(val,
               case("hello", "greeting"),
               case("world", "planet"),
               default("unknown"))) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "greeting");
    }

    #[test]
    fn cond_switch_no_match_falls_to_default() {
        let grammar = r#"Top::
 /(\w+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(switch(val,
               case("red", "color"),
               default("not_a_color"))) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "not_a_color");
    }

    #[test]
    fn cond_switch_multiple_cases() {
        let grammar = r#"Top::
 /(\d+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(switch(val,
               case("1", "one"),
               case("2", "two"),
               case("3", "three"),
               default("many"))) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("3").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "three");
    }

    #[test]
    fn cond_endif_and_endswitch_are_noops() {
        let grammar = r#"Top::
 /(\w+)/
 E { endif(); endswitch(); endcase(); return("ok") }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "ok");
    }

    #[test]
    fn cond_if_with_lazy_evaluation_side_effects() {
        // The else branch contains exit_now(1) — if lazy evaluation works,
        // it should NOT be called when condition is truthy.
        let grammar = r#"Top::
 /(\w+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(if(is_defined(val), entry_text(), exit_now(1))) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // val IS defined, so else branch (exit_now) should NOT execute
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello");
    }

    #[test]
    fn cond_if_lazy_evaluation_elseif() {
        // elseif branch contains exit_now(1) — if lazy evaluation works,
        // it should NOT be called when the if-condition is truthy.
        let grammar = r#"Top::
 /(\w+)/
 I { val = undef }
 LE { val = entry_group(0) }
 E { return(if(is_defined(val), "ok",
               elseif(is_empty(val), exit_now(1)),
               "fallback")) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // val IS defined, so elseif branch should NOT execute
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "ok");
    }

    // ═══════════════════════════════════════════════════════════
    // Explicit cursor-control tests
    // ═══════════════════════════════════════════════════════════

    #[test]
    fn cursor_stack_save_and_restore_cursor() {
        let grammar = r#"Top::
 /hello/
 I { save_cursor() }
 E { return(restore_cursor()) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        // restore_cursor returns undef, save_cursor saves position
        let result = engine.execute("hello");
        assert!(result.is_ok(), "expected ok, got {:?}", result);
        let val = result.unwrap();
        let arr = val.as_array().unwrap();
        assert!(arr[0].is_null());
    }

    #[test]
    fn cursor_stack_restores_position_for_retry() {
        // Save position before match, restore on no-match via LX
        let grammar = r#"Top::OR{1}
 /hello/
 I { save_cursor() }
 E { return() }
 LX { restore_cursor() }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello");
        assert!(
            result.is_ok(),
            "cursor restore should succeed, got {:?}",
            result
        );
    }

    #[test]
    fn cursor_stack_empty_restore_no_op() {
        // restore_cursor with empty stack should not crash
        let grammar = r#"Top::
 /(\w+)/
 E { restore_cursor(); return(entry_group(0)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello").unwrap();
        let arr = result.as_array().unwrap();
        assert_eq!(arr[0].as_str().unwrap(), "hello");
    }

    #[test]
    fn cursor_stack_multiple_save_restore() {
        // save_cursor saves position; restore_cursor restores it
        let grammar = r#"Top::
 /(hello) (world)/
 I { set(log, []); save_cursor() }
 LE { push(log, cursor_pos()) }
 E { push(log, cursor_pos());
      restore_cursor(); push(log, cursor_pos());
      return(copy(log)) }
"#;
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        let result = engine.execute("hello world");
        assert!(
            result.is_ok(),
            "cursor save/restore should work, got {:?}",
            result
        );
    }

    #[test]
    fn cursor_rewinds_to_entry_or_match_start() {
        let entry_grammar = r#"Top::AND
 I { set(log, []) }
 /ab/ -> Top[0] { push(log, hash("slot", 0, "cursor", cursor_pos(), "entry_start", entry_start_pos(), "match_start", match_start_pos())) }
 /cd/ -> Top[1] {
   before = cursor_pos();
   rewind_entry_start();
   push(log, hash("slot", 1, "before", before, "after", cursor_pos(), "entry_start", entry_start_pos(), "match_start", match_start_pos(), "rest", cursor_rest()))
 }
 E { return(copy(log)) }
"#;
        let match_grammar = r#"Top::AND
 I { set(log, []) }
 /ab/ -> Top[0] { push(log, hash("slot", 0, "cursor", cursor_pos(), "entry_start", entry_start_pos(), "match_start", match_start_pos())) }
 /cd/ -> Top[1] {
   before = cursor_pos();
   rewind_match_start();
   push(log, hash("slot", 1, "before", before, "after", cursor_pos(), "entry_start", entry_start_pos(), "match_start", match_start_pos(), "rest", cursor_rest()))
 }
 E { return(copy(log)) }
"#;
        let entry_engine = Engine::new(compile(&parse_spec(entry_grammar).unwrap()).unwrap());
        let match_engine = Engine::new(compile(&parse_spec(match_grammar).unwrap()).unwrap());
        let entry_json = entry_engine.execute("abcd").unwrap();
        let match_json = match_engine.execute("abcd").unwrap();
        let entry_outer = entry_json.as_array().unwrap();
        let match_outer = match_json.as_array().unwrap();
        let entry_arr = entry_outer[0].as_array().unwrap();
        let match_arr = match_outer[0].as_array().unwrap();
        assert_eq!(
            entry_arr[0].get("cursor").and_then(|v| v.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            entry_arr[1].get("after").and_then(|v| v.as_f64()),
            Some(0.0)
        );
        assert_eq!(
            entry_arr[1].get("rest").and_then(|v| v.as_str()),
            Some("abcd")
        );
        assert_eq!(
            match_arr[0].get("cursor").and_then(|v| v.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            match_arr[1].get("after").and_then(|v| v.as_f64()),
            Some(2.0)
        );
        assert_eq!(
            match_arr[1].get("rest").and_then(|v| v.as_str()),
            Some("cd")
        );
    }

    // ── RUST-PARITY.5.3 — char-based (not byte) offsets/slicing ──
    //
    // Internal positions (`ctx.pos`, marks, match spans, regex offsets) are byte
    // offsets, but the Perl reference exposes char offsets (`pos()`/`length`/
    // `substr` are char-based). These tests use multibyte UTF-8 input ('é' is two
    // bytes), where byte-based slicing would panic on a char boundary and every
    // position/length would diverge from Perl by the number of multibyte chars.

    // Helper: parse → validate → compile → execute, return the accumulator JSON.
    fn run_5_3(grammar: &str, input: &str) -> Vec<serde_json::Value> {
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        let engine = Engine::new(compiled);
        engine.execute(input).unwrap().as_array().unwrap().clone()
    }

    #[test]
    fn helpers_5_3_split_accepts_regex_literal_delimiter() {
        let grammar = r#"Top::
 /x/
 E { return("left , right,third".split(/\s*,\s*/).trim_each()) }
"#;
        let acc = run_5_3(grammar, "x");
        assert_eq!(
            acc.last().unwrap(),
            &serde_json::json!(["left", "right", "third"])
        );
    }

    #[test]
    fn helpers_5_3_split_each_accepts_regex_literal_delimiter() {
        let grammar = r#"Top::
 /x/
 E { return(["a, b", "c ,d"].split_each(/\s*,\s*/).trim_each()) }
"#;
        let acc = run_5_3(grammar, "x");
        assert_eq!(
            acc.last().unwrap(),
            &serde_json::json!(["a", "b", "c", "d"])
        );
    }

    #[test]
    fn chars_5_3_substr_is_char_based_no_panic() {
        // substr(café, 3, 1) = "é" (char index 3). Byte-slicing s[3..4] would
        // panic — byte 3 is the first of the two bytes of 'é'.
        let grammar = r#"Top::
 /café/
 E { return(substr(entry_text(), 3, 1)) }
"#;
        let acc = run_5_3(grammar, "café");
        assert_eq!(acc.last().unwrap().as_str().unwrap(), "é");
    }

    #[test]
    fn chars_5_3_input_slice_is_char_based() {
        // input_slice(start=3, width=1) over "café" = "é" (char offsets).
        let grammar = r#"Top::
 /café/
 E { return(input_slice(3, 1)) }
"#;
        let acc = run_5_3(grammar, "café");
        assert_eq!(acc.last().unwrap().as_str().unwrap(), "é");
    }

    #[test]
    fn chars_5_3_cursor_pos_is_char_offset() {
        // After matching "café" the cursor is at byte 5 but char offset 4.
        let grammar = r#"Top::
 /café/
 E { return(cursor_pos()) }
"#;
        let acc = run_5_3(grammar, "café x");
        assert_eq!(acc.last().unwrap().as_f64().unwrap(), 4.0);
    }

    #[test]
    fn chars_5_3_cursor_col_is_char_based() {
        // "héllo" is 6 bytes / 5 chars; column after it = 5 + 1 = 6 (char-based).
        let grammar = r#"Top::
 /héllo/
 E { return(cursor_col()) }
"#;
        let acc = run_5_3(grammar, "héllo");
        assert_eq!(acc.last().unwrap().as_f64().unwrap(), 6.0);
    }

    #[test]
    fn chars_5_3_match_start_pos_not_hardcoded_zero() {
        // "world" seek-matches after "héllo " (6 chars / 7 bytes): char start 6.
        // Previously match_start_pos was hardcoded to 0.0.
        let grammar = r#"Top::
 /world/
 E { return(match_start_pos()) }
"#;
        let acc = run_5_3(grammar, "héllo world");
        assert_eq!(acc.last().unwrap().as_f64().unwrap(), 6.0);
    }

    #[test]
    fn chars_5_3_entry_start_pos_not_hardcoded_zero() {
        // Top rule's entry match = its own match; "world" starts at char 3 after
        // "hi " — entry_start_pos must be 3, not the old hardcoded 0.0.
        let grammar = r#"Top::
 /world/
 E { return(entry_start_pos()) }
"#;
        let acc = run_5_3(grammar, "hi world");
        assert_eq!(acc.last().unwrap().as_f64().unwrap(), 3.0);
    }

    #[test]
    fn chars_5_3_length_is_char_count() {
        // length("café") = 4 chars (not 5 bytes).
        let grammar = r#"Top::
 /café/
 E { return(length(entry_text())) }
"#;
        let acc = run_5_3(grammar, "café");
        assert_eq!(acc.last().unwrap().as_f64().unwrap(), 4.0);
    }

    // ── RUST-PARITY.5.4 — dedup shadowed arms + REP zero-progress guard ──

    #[test]
    fn rep_5_4_zero_progress_guard_terminates() {
        // A REP rule whose regex matches zero-width (`/x*/` on input with no
        // 'x' matches the empty string at the cursor) makes no progress. The
        // guard must break after one no-progress iteration; the old guard only
        // broke after 100 iterations, so it would have collected 100+ entries.
        let grammar = r#"Top::OR+
 /x*/
 I { set(iters, []) }
 LE { push(iters, "i") }
 E { return(copy(iters)) }
"#;
        let acc = run_5_3(grammar, "abc");
        let iters = acc.last().unwrap().as_array().unwrap();
        assert_eq!(
            iters.len(),
            1,
            "zero-width REP must stop after one no-progress iteration, got {iters:?}"
        );
    }

    #[test]
    fn hash_constructor_only_splices_explicit_flat_hash_args() {
        // Ordinary hash-valued pair values stay nested. Explicit flat_hash is
        // the list-context splice operation.
        let grammar = r#"Top:: /(\w+)/
 E { return(array(hash("nested", hash("a", "1")), hash("b", "2", flat_hash(hash("a", "1"))))) }
"#;
        let acc = run_5_3(grammar, "x");
        assert_eq!(
            acc.last(),
            Some(&serde_json::json!([
                {"nested": {"a": "1"}},
                {"a": "1", "b": "2"}
            ]))
        );
    }

    // ── RUST-PARITY.5.5.1 — named-group readers (entry/match _named/_has/_map) ──

    /// Parse → validate → compile → execute, returning the accumulator array.
    fn run_5_5_1(grammar: &str, input: &str) -> Vec<Value> {
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        Engine::new(compiled)
            .execute(input)
            .unwrap()
            .as_array()
            .unwrap()
            .clone()
    }

    #[test]
    fn helpers_5_5_1_entry_named_reads_named_group() {
        // entry_named(name) returns the named capture's value as a string.
        let present = r#"Top::
 /(?P<year>\d+)-(?P<month>\d+)/
 E { return(entry_named("year")) }
"#;
        let acc = run_5_5_1(present, "2024-03");
        assert_eq!(acc.last().unwrap().as_str().unwrap(), "2024");

        let bare_name = r#"Top::
 /(?P<year>\d+)-(?P<month>\d+)/
 E { return(entry_named(year)) }
"#;
        let acc = run_5_5_1(bare_name, "2024-03");
        assert_eq!(acc.last().unwrap().as_str().unwrap(), "2024");

        // An absent name returns undef (JSON null), per the catalog.
        let absent = r#"Top::
 /(?P<year>\d+)/
 E { return(entry_named("nope")) }
"#;
        let acc = run_5_5_1(absent, "2024");
        assert!(
            acc.last().unwrap().is_null(),
            "absent named group must be undef, got {:?}",
            acc.last()
        );
    }

    #[test]
    fn helpers_5_5_1_entry_has_presence() {
        // entry_has(name) returns Perl-compatible numeric 1/0 presence.
        let g_present = r#"Top::
 /(?P<word>\w+)/
 E { return(entry_has("word")) }
"#;
        assert_eq!(
            run_5_5_1(g_present, "hi").last().unwrap().as_f64(),
            Some(1.0)
        );

        let g_present_bare = r#"Top::
 /(?P<word>\w+)/
 E { return(entry_has(word)) }
"#;
        assert_eq!(
            run_5_5_1(g_present_bare, "hi").last().unwrap().as_f64(),
            Some(1.0)
        );

        let g_absent = r#"Top::
 /(?P<word>\w+)/
 E { return(entry_has("missing")) }
"#;
        assert_eq!(
            run_5_5_1(g_absent, "hi").last().unwrap().as_f64(),
            Some(0.0)
        );
    }

    #[test]
    fn helpers_5_5_1_entry_map_and_alias() {
        // entry_map() returns all named groups as a hash; entry_named_map() is a
        // retired alias that must behave identically.
        let g_map = r#"Top::
 /(?P<a>\w+)-(?P<b>\w+)/
 E { return(entry_map()) }
"#;
        let acc = run_5_5_1(g_map, "hello-world");
        let obj = acc.last().unwrap().as_object().unwrap();
        assert_eq!(obj.get("a").and_then(|v| v.as_str()), Some("hello"));
        assert_eq!(obj.get("b").and_then(|v| v.as_str()), Some("world"));
        assert_eq!(obj.len(), 2);

        let g_alias = r#"Top::
 /(?P<a>\w+)-(?P<b>\w+)/
 E { return(entry_named_map()) }
"#;
        let acc = run_5_5_1(g_alias, "hello-world");
        let obj = acc.last().unwrap().as_object().unwrap();
        assert_eq!(obj.get("a").and_then(|v| v.as_str()), Some("hello"));
        assert_eq!(obj.get("b").and_then(|v| v.as_str()), Some("world"));
    }

    #[test]
    fn helpers_5_5_1_match_named_reads_named_group() {
        // match_named reads the LOCAL match's named groups. On a top rule the
        // entry and local match coincide, so the value is readable here.
        let present = r#"Top::
 /(?P<year>\d+)-(?P<month>\d+)/
 E { return(match_named("month")) }
"#;
        let acc = run_5_5_1(present, "2024-03");
        assert_eq!(acc.last().unwrap().as_str().unwrap(), "03");

        let bare_name = r#"Top::
 /(?P<year>\d+)-(?P<month>\d+)/
 E { return(match_named(month)) }
"#;
        let acc = run_5_5_1(bare_name, "2024-03");
        assert_eq!(acc.last().unwrap().as_str().unwrap(), "03");

        let absent = r#"Top::
 /(?P<year>\d+)/
 E { return(match_named("nope")) }
"#;
        assert!(run_5_5_1(absent, "2024").last().unwrap().is_null());
    }

    #[test]
    fn helpers_5_5_1_match_has_presence() {
        let g_present = r#"Top::
 /(?P<word>\w+)/
 E { return(match_has("word")) }
"#;
        assert_eq!(
            run_5_5_1(g_present, "hi").last().unwrap().as_f64(),
            Some(1.0)
        );

        let g_present_bare = r#"Top::
 /(?P<word>\w+)/
 E { return(match_has(word)) }
"#;
        assert_eq!(
            run_5_5_1(g_present_bare, "hi").last().unwrap().as_f64(),
            Some(1.0)
        );

        let g_absent = r#"Top::
 /(?P<word>\w+)/
 E { return(match_has("missing")) }
"#;
        assert_eq!(
            run_5_5_1(g_absent, "hi").last().unwrap().as_f64(),
            Some(0.0)
        );
    }

    #[test]
    fn helpers_5_5_1_match_map_and_alias() {
        // match_map() and its retired alias match_named_map() both return the
        // local match's named groups as a hash.
        let g_map = r#"Top::
 /(?P<a>\w+)-(?P<b>\w+)/
 E { return(match_map()) }
"#;
        let acc = run_5_5_1(g_map, "foo-bar");
        let obj = acc.last().unwrap().as_object().unwrap();
        assert_eq!(obj.get("a").and_then(|v| v.as_str()), Some("foo"));
        assert_eq!(obj.get("b").and_then(|v| v.as_str()), Some("bar"));

        let g_alias = r#"Top::
 /(?P<a>\w+)-(?P<b>\w+)/
 E { return(match_named_map()) }
"#;
        let acc = run_5_5_1(g_alias, "foo-bar");
        let obj = acc.last().unwrap().as_object().unwrap();
        assert_eq!(obj.get("a").and_then(|v| v.as_str()), Some("foo"));
        assert_eq!(obj.get("b").and_then(|v| v.as_str()), Some("bar"));
    }

    // ── RUST-PARITY.5.5.2 — input-boundary helpers + the `flat` splice ──

    /// Parse → validate → compile → execute, returning the accumulator array.
    fn run_5_5_2(grammar: &str, input: &str) -> Vec<Value> {
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        Engine::new(compiled)
            .execute(input)
            .unwrap()
            .as_array()
            .unwrap()
            .clone()
    }

    #[test]
    fn helpers_5_5_2_input_end_line_counts_newlines() {
        // input_end_line() = 1 + newline count over the WHOLE input (not the cursor).
        let g = r#"Top::
 /\w/
 E { return(input_end_line()) }
"#;
        assert_eq!(run_5_5_2(g, "abc").last().unwrap().as_f64().unwrap(), 1.0); // no newline
        assert_eq!(
            run_5_5_2(g, "a\nb\nc").last().unwrap().as_f64().unwrap(),
            3.0
        ); // 2 newlines
        assert_eq!(
            run_5_5_2(g, "a\nb\n").last().unwrap().as_f64().unwrap(),
            3.0
        ); // trailing newline
    }

    #[test]
    fn helpers_5_5_2_input_end_col_is_char_based() {
        // input_end_col(): char distance past the last newline, +1 when none.
        let g = r#"Top::
 /\w/
 E { return(input_end_col()) }
"#;
        assert_eq!(run_5_5_2(g, "abc").last().unwrap().as_f64().unwrap(), 4.0); // len 3, no nl → 4
        assert_eq!(
            run_5_5_2(g, "ab\ncde").last().unwrap().as_f64().unwrap(),
            4.0
        ); // "cde" past nl → 4
        assert_eq!(run_5_5_2(g, "ab\n").last().unwrap().as_f64().unwrap(), 1.0); // empty final line → 1
        // Char-based, not byte-based: 'é' is 2 bytes but 1 column → "héllo" = 5 chars → 6.
        assert_eq!(run_5_5_2(g, "héllo").last().unwrap().as_f64().unwrap(), 6.0);
    }

    #[test]
    fn helpers_5_5_2_flat_array_and_hash() {
        // flat(array) yields the array's elements as a list value.
        let g_arr = r#"Top::
 /\w/
 E { return(flat(array("a", "b"))) }
"#;
        let acc = run_5_5_2(g_arr, "x");
        let arr = acc.last().unwrap().as_array().unwrap();
        assert_eq!(arr.len(), 2);
        assert_eq!(arr[0].as_str().unwrap(), "a");
        assert_eq!(arr[1].as_str().unwrap(), "b");

        // flat(hash) splices key/value entries into a parent hash(...).
        let g_hash = r#"Top::
 /\w/
 E { return(hash("a", "1", flat(hash("b", "2")))) }
"#;
        let acc = run_5_5_2(g_hash, "x");
        let obj = acc.last().unwrap().as_object().unwrap();
        assert_eq!(obj.get("a").and_then(|v| v.as_str()), Some("1"));
        assert_eq!(obj.get("b").and_then(|v| v.as_str()), Some("2"));
        assert_eq!(obj.len(), 2);
    }

    // ── RUST-PARITY.5.5.3: mark-based capture family ──
    // Use explicit `OR{1,1}` so these tests stay focused on capture/mark
    // endpoints around one seek match. Bare default rules are repeated-choice
    // loops, so a later word in the input would intentionally move the cursor.
    // `mark_input_start` pins a mark at 0, `mark_input_end` at the byte length,
    // giving deterministic spans independent of the match.
    fn run_5_5_3(grammar: &str, input: &str) -> Vec<Value> {
        let spec = parse_spec(grammar).unwrap();
        validate(&spec).unwrap();
        let compiled = compile(&spec).unwrap();
        Engine::new(compiled)
            .execute(input)
            .unwrap()
            .as_array()
            .unwrap()
            .clone()
    }

    #[test]
    fn helpers_5_5_3_capture_from_reads_to_match_start() {
        // mark at 0, match "hi" starts at byte 2 → the pre-match text "  ".
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(capture_from("a")) }
"#;
        let acc = run_5_5_3(g, "  hi");
        assert_eq!(acc[0].as_str().unwrap(), "  ");
    }

    #[test]
    fn helpers_5_5_3_capture_from_undef_on_missing_mark() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { return(capture_from("nope")) }
"#;
        let acc = run_5_5_3(g, "hi");
        assert!(acc[0].is_null(), "missing mark → undef, got {:?}", acc[0]);
    }

    #[test]
    fn helpers_5_5_3_capture_len_from_is_char_count() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(capture_len_from("a")) }
"#;
        let acc = run_5_5_3(g, "  hi");
        assert_eq!(acc[0].as_f64().unwrap(), 2.0); // "  " before the match
    }

    #[test]
    fn helpers_5_5_3_capture_until_cursor_from() {
        // mark 0 → cursor (match-end of "ab" = byte 2).
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(capture_until_cursor_from("a")) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        assert_eq!(acc[0].as_str().unwrap(), "ab");
    }

    #[test]
    fn helpers_5_5_3_capture_until_cursor_len_from() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(capture_until_cursor_len_from("a")) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        assert_eq!(acc[0].as_f64().unwrap(), 2.0);
    }

    #[test]
    fn helpers_5_5_3_capture_rest_from_reads_to_end() {
        // mark 0 → end-of-input (past the cursor at byte 2).
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(capture_rest_from("a")) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        assert_eq!(acc[0].as_str().unwrap(), "ab cd");
    }

    #[test]
    fn helpers_5_5_3_capture_rest_len_from() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(capture_rest_len_from("a")) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        assert_eq!(acc[0].as_f64().unwrap(), 5.0);
    }

    #[test]
    fn helpers_5_5_3_capture_between_and_len_multibyte() {
        // mark_input_start(a)=0, mark_input_end(b)=byte len; the span is the whole
        // multibyte input. capture_between returns the text; capture_len_between
        // returns the CHAR count (5), not the byte count (6) — char-based parity.
        let g = r#"Top::OR{1,1}
 /\w/
 E { mark_input_start("a"); mark_input_end("b"); return(array(capture_between("a", "b"), capture_len_between("a", "b"))) }
"#;
        let acc = run_5_5_3(g, "héllo");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "héllo");
        assert_eq!(acc[1].as_f64().unwrap(), 5.0);
    }

    #[test]
    fn helpers_5_5_3_capture_between_undef_when_reversed() {
        // a = end-of-input, b = start-of-input → reversed span → undef.
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_end("a"); mark_input_start("b"); return(capture_between("a", "b")) }
"#;
        let acc = run_5_5_3(g, "hi");
        assert!(acc[0].is_null(), "reversed span → undef, got {:?}", acc[0]);
    }

    #[test]
    fn helpers_5_5_3_mark_copy_copies_position() {
        // copy a (=0) into b, then read until cursor from b → "ab".
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); mark_copy("b", "a"); return(capture_until_cursor_from("b")) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        assert_eq!(acc[0].as_str().unwrap(), "ab");
    }

    #[test]
    fn helpers_5_5_3_mark_copy_deletes_target_when_source_missing() {
        // b is set, then mark_copy(b, <missing>) deletes b → capture_from(b) undef.
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("b"); mark_copy("b", "nope"); return(capture_from("b")) }
"#;
        let acc = run_5_5_3(g, "hi");
        assert!(acc[0].is_null(), "deleted target → undef, got {:?}", acc[0]);
    }

    #[test]
    fn helpers_5_5_3_capture_take_until_cursor_from_advances_mark() {
        // First take reads mark→cursor ("ab") and advances the mark to the cursor;
        // the second read (mark now == cursor) is therefore empty.
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(array(capture_take_until_cursor_from("a"), capture_until_cursor_from("a"))) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "ab");
        assert_eq!(acc[1].as_str().unwrap(), "");
    }

    #[test]
    fn helpers_5_5_3_capture_take_until_cursor_len_from_advances_mark() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(array(capture_take_until_cursor_len_from("a"), capture_until_cursor_len_from("a"))) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_f64().unwrap(), 2.0);
        assert_eq!(acc[1].as_f64().unwrap(), 0.0);
    }

    #[test]
    fn helpers_5_5_3_capture_take_len_from_advances_mark_to_cursor() {
        // len is mark→match-START ("  " = 2); the mark then advances to the CURSOR
        // (match-end, byte 4), so capture_rest_from is empty afterwards.
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(array(capture_take_len_from("a"), capture_rest_from("a"))) }
"#;
        let acc = run_5_5_3(g, "  hi");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_f64().unwrap(), 2.0);
        assert_eq!(acc[1].as_str().unwrap(), "");
    }

    #[test]
    fn helpers_5_5_3_capture_take_rest_from_advances_mark_to_end() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(array(capture_take_rest_from("a"), capture_rest_from("a"))) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "ab cd");
        assert_eq!(acc[1].as_str().unwrap(), "");
    }

    #[test]
    fn helpers_5_5_3_capture_take_rest_len_from_advances_mark_to_end() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 E { mark_input_start("a"); return(array(capture_take_rest_len_from("a"), capture_rest_len_from("a"))) }
"#;
        let acc = run_5_5_3(g, "ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_f64().unwrap(), 5.0);
        assert_eq!(acc[1].as_f64().unwrap(), 0.0);
    }

    // ── RUST-PARITY.5.5.4: anonymous capture-slice family ──
    // `I { start_capture_slice() }` records the anonymous capture start at the
    // pre-seek cursor (pos 0 for the top rule). `OR{1,1}` keeps the test grammar
    // to one seek match, so over "  ab cd" the `/(\w+)/` match is "ab" at bytes
    // 2..4 (match-start 2, cursor 4), end-of-input 7. That fixes the three
    // endpoints the family reads: match-start (2), cursor (4), end (7). Reuses
    // the run_5_5_3 pipeline harness.

    #[test]
    fn helpers_5_5_4_capture_slice_reads_pre_match_text() {
        // capture_slice ends at match-START → the "  " skipped before the match.
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_slice(), capture_slice_len())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "  ");
        assert_eq!(acc[1].as_f64().unwrap(), 2.0);
    }

    #[test]
    fn helpers_5_5_4_capture_slice_until_cursor() {
        // ends at the CURSOR (match-end, byte 4) → "  ab".
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_slice_until_cursor(), capture_slice_until_cursor_len())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "  ab");
        assert_eq!(acc[1].as_f64().unwrap(), 4.0);
    }

    #[test]
    fn helpers_capture_until_boundary_captures_without_consuming_boundary() {
        let g = r#"Top::
 I { set(out, []) }
 -> Annotation.push(out)
 LX { return(copy(out)) }

Annotation: /@(\w+):[ \t]*/
 I { body = capture_until_boundary(Annotation, Boundary); return(hash("kind", "annotation", "name", entry_group(0), "body", trim(body), "cursor", cursor_pos(), "rest", cursor_rest())) }

Boundary: /END/
"#;
        let acc = run_5_5_3(g, "@a: first @b: second END");
        let entries = acc[0].as_array().unwrap();
        let obj = entries[0].as_object().unwrap();
        let second = entries[1].as_object().unwrap();

        assert_eq!(obj.get("kind").and_then(|v| v.as_str()), Some("annotation"));
        assert_eq!(obj.get("name").and_then(|v| v.as_str()), Some("a"));
        assert_eq!(obj.get("body").and_then(|v| v.as_str()), Some("first"));
        assert_eq!(obj.get("cursor").and_then(|v| v.as_f64()), Some(10.0));
        assert_eq!(
            obj.get("rest").and_then(|v| v.as_str()),
            Some("@b: second END")
        );
        assert_eq!(second.get("name").and_then(|v| v.as_str()), Some("b"));
        assert_eq!(second.get("body").and_then(|v| v.as_str()), Some("second"));
    }

    #[test]
    fn helpers_5_5_4_capture_rest_reads_to_end() {
        // ends at END-of-input (byte 7), past the cursor → the whole input.
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_rest(), capture_rest_len())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "  ab cd");
        assert_eq!(acc[1].as_f64().unwrap(), 7.0);
    }

    #[test]
    fn helpers_5_5_4_capture_take_advances_to_cursor() {
        // capture_take reads to match-START ("  ") and advances capture_start to
        // the CURSOR (byte 4); the following capture_rest is then 4→end = " cd".
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_take(), capture_rest())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "  ");
        assert_eq!(acc[1].as_str().unwrap(), " cd");
    }

    #[test]
    fn helpers_5_5_4_capture_take_len_advances_to_cursor() {
        // len is capture_start→match-START (2); capture_start then advances to the
        // CURSOR (byte 4), so capture_rest_len afterward is 3 (" cd").
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_take_len(), capture_rest_len())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_f64().unwrap(), 2.0);
        assert_eq!(acc[1].as_f64().unwrap(), 3.0);
    }

    #[test]
    fn helpers_5_5_4_capture_take_until_cursor_advances() {
        // reads capture_start→cursor ("  ab") and advances capture_start to the
        // cursor, so the second until-cursor read (start == cursor) is empty.
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_take_until_cursor(), capture_slice_until_cursor())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "  ab");
        assert_eq!(acc[1].as_str().unwrap(), "");
    }

    #[test]
    fn helpers_5_5_4_capture_take_until_cursor_len_advances() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_take_until_cursor_len(), capture_slice_until_cursor_len())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_f64().unwrap(), 4.0);
        assert_eq!(acc[1].as_f64().unwrap(), 0.0);
    }

    #[test]
    fn helpers_5_5_4_capture_take_rest_advances_to_end() {
        // reads capture_start→end ("  ab cd") and advances capture_start to end, so
        // the second capture_rest read is empty.
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_take_rest(), capture_rest())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "  ab cd");
        assert_eq!(acc[1].as_str().unwrap(), "");
    }

    #[test]
    fn helpers_5_5_4_capture_take_rest_len_advances_to_end() {
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_take_rest_len(), capture_rest_len())) }
"#;
        let acc = run_5_5_3(g, "  ab cd");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_f64().unwrap(), 7.0);
        assert_eq!(acc[1].as_f64().unwrap(), 0.0);
    }

    #[test]
    fn helpers_5_5_4_capture_rest_len_is_char_count() {
        // Multibyte parity: over "ab,héllo" the match is "ab" (bytes 0..2), so
        // capture_rest spans capture_start 0 → end-of-input. The text is the raw
        // slice; capture_rest_len is the CHAR count (8: a b , h é l l o), not the
        // byte count (9) — DSL lengths are char-based (.5.3).
        let g = r#"Top::OR{1,1}
 /(\w+)/
 I { start_capture_slice() }
 E { return(array(capture_rest(), capture_rest_len())) }
"#;
        let acc = run_5_5_3(g, "ab,héllo");
        let acc = acc[0].as_array().unwrap();
        assert_eq!(acc[0].as_str().unwrap(), "ab,héllo");
        assert_eq!(acc[1].as_f64().unwrap(), 8.0);
    }

    #[test]
    fn callable_codeblock_restores_parameters_and_active_identity_after_body_failure() {
        let parsed = parse_spec("Top::\n /x/\n").unwrap();
        validate(&parsed).unwrap();
        let engine = Engine::new(compile(&parsed).unwrap());
        let block = CodeBlock::parse(r#"cb = {|value| missing() }"#).unwrap();
        let Expr::AssignScalar { value, .. } = &block.statements[0].expr else {
            panic!("expected callable assignment");
        };
        let Expr::CodeblockLiteral(literal) = value.as_ref() else {
            panic!("expected callable literal");
        };

        let mut ctx = RuntimeContext::new("x");
        ctx.set_scalar("value", RuntimeValue::Scalar("outer".into()));
        ctx.set_scalar(
            "cb",
            RuntimeValue::Codeblock(linkedspec_core::types::CodeblockValue::new(literal.clone())),
        );
        let raw_args = [Arg::Positional(Expr::StringLiteral {
            value: "inner".into(),
        })];
        let evaluated = [RuntimeValue::Scalar("inner".into())];
        let error = engine
            .execute_bound_codeblock_call("cb", &raw_args, &evaluated, &mut ctx, "Top")
            .expect("bound callable")
            .unwrap_err();
        assert!(error.contains("unknown_helper"), "{error}");
        assert!(error.starts_with("codeblock 'cb': "), "{error}");
        assert!(error.contains("rule_label=\"Top\""), "{error}");
        assert_eq!(
            ctx.get_scalar("value"),
            RuntimeValue::Scalar("outer".into())
        );
        assert!(!ctx.has_active_codeblock());

        // Anonymous helper callbacks retain error context and cleanup as well.
        let RuntimeValue::Codeblock(codeblock) = ctx.get_bare_value("cb") else {
            panic!("expected preserved callback binding");
        };
        let error = engine
            .execute_codeblock_value("with", None, &codeblock, &evaluated, &mut ctx, "Top")
            .unwrap_err();
        assert!(error.contains("unknown_helper"), "{error}");
        assert!(error.starts_with("codeblock 'with': "), "{error}");
        assert!(error.contains("rule_label=\"Top\""), "{error}");
        assert_eq!(
            ctx.get_scalar("value"),
            RuntimeValue::Scalar("outer".into())
        );
        assert!(!ctx.has_active_codeblock());
    }

    #[test]
    fn with_callback_snapshot_preserves_argument_effects_and_failed_body_scope() {
        let engine = nested_write_test_engine();
        let mut ctx = RuntimeContext::new("x");
        ctx.set_scalar("value", RuntimeValue::Scalar("outer".into()));
        let argument_failure = CodeBlock::parse(r#"with("scoped", set(value,"changed"))"#).unwrap();
        let Expr::Call { args, .. } = &argument_failure.statements[0].expr else {
            panic!("expected helper with call");
        };
        let error = engine
            .eval_with_trailing_block(args, &mut ctx, "Top")
            .unwrap_err();
        assert!(error.contains("final_argument_not_codeblock"), "{error}");
        assert_eq!(
            ctx.get_scalar("value"),
            RuntimeValue::Scalar("changed".into())
        );
        assert!(!ctx.has_active_codeblock());

        let body_failure =
            CodeBlock::parse(r#"with("scoped", {|item| value="body";missing()})"#).unwrap();
        let Expr::Call { args, .. } = &body_failure.statements[0].expr else {
            panic!("expected helper with call");
        };
        let error = engine
            .eval_with_trailing_block(args, &mut ctx, "Top")
            .unwrap_err();
        assert!(error.contains("unknown_helper"), "{error}");
        assert_eq!(
            ctx.get_scalar("value"),
            RuntimeValue::Scalar("changed".into())
        );
        assert!(!ctx.has_bare_binding("item"));
        assert!(!ctx.has_active_codeblock());
    }

    fn nested_write_test_engine() -> Engine {
        let parsed = parse_spec("Top::\n -> Done\n\nDone::\n /x/\n").unwrap();
        validate(&parsed).unwrap();
        Engine::new(compile(&parsed).unwrap())
    }

    #[test]
    fn nested_write_evaluates_segments_then_rhs_before_one_isolated_commit() {
        let engine = nested_write_test_engine();
        let block = CodeBlock::parse(
            r#"document[{ push(audit, "segment-0"); "items" }][{ push(audit, "segment-1"); 0 }] = { push(audit, "rhs"); "value" }"#,
        )
        .unwrap();
        let Expr::AssignNestedAccess {
            base,
            segments,
            value,
            ..
        } = &block.statements[0].expr
        else {
            panic!("expected nested write");
        };
        let mut ctx = RuntimeContext::new("x");
        let result = engine
            .eval_nested_access_assignment_expression(base, segments, value, &mut ctx, "Top")
            .unwrap();
        assert_eq!(
            ctx.get_bare_value("audit"),
            RuntimeValue::Array(vec![
                RuntimeValue::Scalar("segment-0".into()),
                RuntimeValue::Scalar("segment-1".into()),
                RuntimeValue::Scalar("rhs".into()),
            ])
        );
        let expected = RuntimeValue::Hash(vec![(
            "items".into(),
            RuntimeValue::Array(vec![RuntimeValue::Scalar("value".into())]),
        )]);
        assert_eq!(ctx.get_bare_value("document"), expected);
        assert_eq!(result, ctx.get_bare_value("document"));
    }

    #[test]
    fn nested_write_structural_failure_preserves_only_completed_expression_state() {
        let engine = nested_write_test_engine();
        let block = CodeBlock::parse(
            r#"document["created"][2] = { document = { "after" : "rhs" }; "value" }"#,
        )
        .unwrap();
        let Expr::AssignNestedAccess {
            base,
            segments,
            value,
            ..
        } = &block.statements[0].expr
        else {
            panic!("expected nested write");
        };
        let mut ctx = RuntimeContext::new("x");
        ctx.set_scalar(
            "document",
            RuntimeValue::Hash(vec![(
                "before".into(),
                RuntimeValue::Scalar("original".into()),
            )]),
        );
        let error = engine
            .eval_nested_access_assignment_expression(base, segments, value, &mut ctx, "Top")
            .unwrap_err();
        let payload: Value = serde_json::from_str(&error).unwrap();
        assert_eq!(payload["code"], "nested_write_array_gap");
        assert_eq!(payload["segment_index"], 1);
        assert_eq!(payload["path"], json!(["created"]));
        assert_eq!(payload["index"], 2);
        assert_eq!(payload["length"], 0);
        assert_eq!(
            ctx.get_bare_value("document"),
            RuntimeValue::Hash(vec![("after".into(), RuntimeValue::Scalar("rhs".into()))]),
            "the RHS assignment remains, but the isolated 'created' path never commits"
        );
    }

    #[test]
    fn nested_write_detaches_initial_rhs_binding_and_result_values() {
        let engine = nested_write_test_engine();
        let block = CodeBlock::parse(r#"document["payload"] = rhs"#).unwrap();
        let Expr::AssignNestedAccess {
            base,
            segments,
            value,
            ..
        } = &block.statements[0].expr
        else {
            panic!("expected nested write");
        };
        let mut initial = RuntimeValue::Hash(vec![(
            "existing".into(),
            RuntimeValue::Array(vec![RuntimeValue::Scalar("keep".into())]),
        )]);
        let mut rhs = RuntimeValue::Array(vec![RuntimeValue::Scalar("a".into())]);
        let mut ctx = RuntimeContext::new("x");
        ctx.set_scalar("document", initial.clone());
        ctx.set_scalar("rhs", rhs.clone());
        let mut result = engine
            .eval_nested_access_assignment_expression(base, segments, value, &mut ctx, "Top")
            .unwrap();

        let RuntimeValue::Array(rhs_items) = &mut rhs else {
            panic!("expected aggregate RHS");
        };
        rhs_items[0] = RuntimeValue::Scalar("rhs-mutated".into());

        let RuntimeValue::Hash(result_entries) = &mut result else {
            panic!("expected harray result");
        };
        let RuntimeValue::Array(result_payload) = &mut result_entries
            .iter_mut()
            .find(|(key, _)| key == "payload")
            .expect("result payload")
            .1
        else {
            panic!("expected result payload array");
        };
        result_payload[0] = RuntimeValue::Scalar("result-mutated".into());

        let mut binding = ctx.get_bare_value("document");
        let RuntimeValue::Hash(binding_entries) = &mut binding else {
            panic!("expected harray binding");
        };
        let RuntimeValue::Array(binding_existing) = &mut binding_entries
            .iter_mut()
            .find(|(key, _)| key == "existing")
            .expect("binding existing")
            .1
        else {
            panic!("expected binding existing array");
        };
        binding_existing[0] = RuntimeValue::Scalar("binding-mutated".into());
        ctx.set_scalar("document", binding);

        let RuntimeValue::Hash(initial_entries) = &mut initial else {
            panic!("expected initial harray");
        };
        let RuntimeValue::Array(initial_existing) = &mut initial_entries
            .iter_mut()
            .find(|(key, _)| key == "existing")
            .expect("initial existing")
            .1
        else {
            panic!("expected initial existing array");
        };
        initial_existing[0] = RuntimeValue::Scalar("initial-mutated".into());

        assert_eq!(
            initial,
            RuntimeValue::Hash(vec![(
                "existing".into(),
                RuntimeValue::Array(vec![RuntimeValue::Scalar("initial-mutated".into())]),
            )])
        );
        assert_eq!(
            rhs,
            RuntimeValue::Array(vec![RuntimeValue::Scalar("rhs-mutated".into())])
        );
        assert_eq!(
            ctx.get_bare_value("document"),
            RuntimeValue::Hash(vec![
                (
                    "existing".into(),
                    RuntimeValue::Array(vec![RuntimeValue::Scalar("binding-mutated".into())]),
                ),
                (
                    "payload".into(),
                    RuntimeValue::Array(vec![RuntimeValue::Scalar("a".into())]),
                ),
            ])
        );
        assert_eq!(
            result,
            RuntimeValue::Hash(vec![
                (
                    "existing".into(),
                    RuntimeValue::Array(vec![RuntimeValue::Scalar("keep".into())]),
                ),
                (
                    "payload".into(),
                    RuntimeValue::Array(vec![RuntimeValue::Scalar("result-mutated".into())]),
                ),
            ])
        );
    }

    #[test]
    fn nested_write_expression_failure_stops_later_segment_and_rhs_evaluation() {
        let engine = nested_write_test_engine();
        let cases = [
            (
                r#"document[{ push(audit, "segment-0"); dispatch_span() }][{ push(audit, "segment-1"); 0 }] = { push(audit, "rhs"); "value" }"#,
                &[RuntimeValue::Scalar("segment-0".into())][..],
            ),
            (
                r#"document[{ push(audit, "segment-0"); "first" }][{ push(audit, "segment-1"); dispatch_span() }] = { push(audit, "rhs"); "value" }"#,
                &[
                    RuntimeValue::Scalar("segment-0".into()),
                    RuntimeValue::Scalar("segment-1".into()),
                ][..],
            ),
            (
                r#"document[{ push(audit, "segment-0"); "key" }] = { push(audit, "rhs"); dispatch_span() }"#,
                &[
                    RuntimeValue::Scalar("segment-0".into()),
                    RuntimeValue::Scalar("rhs".into()),
                ][..],
            ),
        ];
        for (source, expected_audit) in cases {
            let block = CodeBlock::parse(source).unwrap();
            let Expr::AssignNestedAccess {
                base,
                segments,
                value,
                ..
            } = &block.statements[0].expr
            else {
                panic!("expected nested write");
            };
            let mut ctx = RuntimeContext::new("x");
            ctx.set_scalar("document", RuntimeValue::Hash(Vec::new()));
            let error = engine
                .eval_nested_access_assignment_expression(base, segments, value, &mut ctx, "Top")
                .unwrap_err();
            assert!(
                error.contains("progressive_span_binding_required"),
                "{error}"
            );
            assert_eq!(
                ctx.get_bare_value("audit"),
                RuntimeValue::Array(expected_audit.to_vec())
            );
            assert_eq!(
                ctx.get_bare_value("document"),
                RuntimeValue::Hash(Vec::new())
            );
        }
    }

    #[test]
    fn signed_array_frozen_arithmetic_read_and_write_boundaries() {
        let authority: Value = serde_json::from_str(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../capability_conformance/signed_array_selector_contract.json"
        )))
        .unwrap();
        let engine = nested_write_test_engine();
        for case in authority["arithmetic_cases"].as_array().unwrap() {
            let length = case["length"].as_u64().unwrap() as usize;
            let index = case["index"].as_i64().unwrap();
            let original = RuntimeValue::Array(
                (0..length)
                    .map(|index| RuntimeValue::Number(index as f64))
                    .collect(),
            );
            let mut ctx = RuntimeContext::new("x");
            ctx.set_scalar("tree", original.clone());
            let read = receiver_mutation_expr(&format!("tree[{index}]"));
            let actual = engine.eval_expr(&read, &mut ctx, "Top").unwrap();
            let expected = if case["expected"]["readable"] == true {
                RuntimeValue::Number(case["expected"]["resolved_index"].as_f64().unwrap())
            } else {
                RuntimeValue::Undef
            };
            assert_eq!(actual, expected, "{} read", case["id"]);
            assert_eq!(ctx.get_bare_value("tree"), original, "read is pure");
            let write = receiver_mutation_expr(&format!("tree[{index}] = 99"));
            let result = engine.eval_expr(&write, &mut ctx, "Top");
            if case["expected"]["writable"] == true {
                let mut expected = original.clone();
                let RuntimeValue::Array(values) = &mut expected else {
                    unreachable!()
                };
                let resolved = case["expected"]["resolved_index"].as_u64().unwrap() as usize;
                if resolved == length {
                    values.push(RuntimeValue::Number(99.0));
                } else {
                    values[resolved] = RuntimeValue::Number(99.0);
                }
                assert_eq!(result.unwrap(), expected, "{} write", case["id"]);
                assert_eq!(ctx.get_bare_value("tree"), expected);
            } else {
                let payload: Value = serde_json::from_str(&result.unwrap_err()).unwrap();
                assert_eq!(payload["index"], index);
                assert_eq!(payload["length"], length);
                assert_eq!(
                    payload["code"],
                    if index < 0 {
                        "nested_write_array_underflow"
                    } else {
                        "nested_write_array_gap"
                    }
                );
                assert_eq!(ctx.get_bare_value("tree"), original);
            }
        }
    }

    #[test]
    fn signed_write_unicode_diagnostic_is_exact() {
        let engine = nested_write_test_engine();
        let mut ctx = RuntimeContext::new("x");
        ctx.set_hash(
            "tree",
            vec![(
                "é".into(),
                RuntimeValue::Array(vec![RuntimeValue::Number(1.0)]),
            )],
        );
        let error = engine
            .eval_expr(
                &receiver_mutation_expr(r#"tree["é"][-2] = 99"#),
                &mut ctx,
                "Top",
            )
            .unwrap_err();
        let payload: Value = serde_json::from_str(&error).unwrap();
        assert_eq!(
            payload,
            json!({
                "code": "nested_write_array_underflow", "operation": "nested_write_vivification",
                "binding": "tree", "segment_index": 1, "path": ["é"], "index": -2,
                "length": 1, "resolved_index": -1,
                "source_span": {"start": 10, "end": 12, "unit": "unicode_scalar", "provenance": "authored"},
                "message": "nested write segment 1 for binding 'tree' cannot select array index -2 at length 1 (resolved index -1)"
            })
        );
    }

    #[test]
    #[cfg(target_pointer_width = "64")]
    fn signed_write_invalid_later_segment_retains_exact_wide_authored_prefix() {
        #[derive(serde::Deserialize)]
        struct Diagnostic {
            code: String,
            path: Vec<i128>,
            segment_index: usize,
        }
        let engine = nested_write_test_engine();
        let mut ctx = RuntimeContext::new("x");
        ctx.set_array("tree", vec![RuntimeValue::Number(10.0)]);
        let error = engine
            .eval_expr(
                &receiver_mutation_expr("tree[-18446744073709549568][true] = 99"),
                &mut ctx,
                "Top",
            )
            .unwrap_err();
        let diagnostic: Diagnostic = serde_json::from_str(&error).unwrap();
        assert_eq!(diagnostic.code, "nested_write_segment_invalid");
        assert_eq!(diagnostic.segment_index, 1);
        assert_eq!(diagnostic.path, vec![-18446744073709549568i128]);
        assert_eq!(ctx.get_bare_value("tree").to_json(), json!([10]));
    }

    #[test]
    fn signed_write_failures_keep_effects_without_partial_paths() {
        let engine = nested_write_test_engine();
        for (source, expected_audit, expected_tree, code) in [
            (
                r#"tree[{ push(audit,"first"); dispatch_span() }][{ push(audit,"later"); -1 }] = { push(audit,"rhs"); 99 }"#,
                json!(["first"]),
                json!([10]),
                "progressive_span_binding_required",
            ),
            (
                r#"tree[{ push(audit,"first"); -1 }] = { push(audit,"rhs"); dispatch_span() }"#,
                json!(["first", "rhs"]),
                json!([10]),
                "progressive_span_binding_required",
            ),
            (
                r#"tree[-1]["new"][-1] = { push(audit,"rhs"); tree=[{}]; 99 }"#,
                json!(["rhs"]),
                json!([{}]),
                "nested_write_segment_invalid",
            ),
            (
                r#"tree[-3] = { push(audit,"rhs"); tree=[10,20]; 99 }"#,
                json!(["rhs"]),
                json!([10, 20]),
                "nested_write_array_underflow",
            ),
        ] {
            let mut ctx = RuntimeContext::new("x");
            ctx.set_array("tree", vec![RuntimeValue::Number(10.0)]);
            let error = engine
                .eval_expr(&receiver_mutation_expr(source), &mut ctx, "Top")
                .unwrap_err();
            assert!(error.contains(code), "{source}: {error}");
            assert_eq!(ctx.get_bare_value("audit").to_json(), expected_audit);
            assert_eq!(ctx.get_bare_value("tree").to_json(), expected_tree);
        }
    }

    #[test]
    fn signed_write_guard_precedes_selector_and_rhs_effects() {
        let engine = nested_write_test_engine();
        let mut ctx = RuntimeContext::new("x");
        ctx.set_array("tree", vec![RuntimeValue::Number(10.0)]);
        let error = engine.eval_expr(&receiver_mutation_expr(
            r#"tree.map_leaves!() { tree[{ push(audit,"selector"); -1 }] = { push(audit,"rhs"); 99 }; return(value) }"#,
        ), &mut ctx, "Top").unwrap_err();
        let payload: Value = serde_json::from_str(&error).unwrap();
        assert_eq!(payload["code"], "receiver_mutation_reentrant");
        assert_eq!(payload["attempt"], "nested_write");
        assert!(!ctx.has_bare_binding("audit"));
        assert_eq!(ctx.get_bare_value("tree").to_json(), json!([10]));
    }

    #[test]
    fn signed_write_all_aggregate_boundaries_are_independently_detached() {
        let engine = nested_write_test_engine();
        let mut initial =
            RuntimeValue::Array(vec![RuntimeValue::Array(vec![RuntimeValue::Number(1.0)])]);
        let mut rhs = RuntimeValue::Array(vec![RuntimeValue::Number(2.0)]);
        let mut ctx = RuntimeContext::new("x");
        ctx.set_scalar("tree", initial.clone());
        ctx.set_scalar("payload", rhs.clone());
        let mut result = engine
            .eval_expr(
                &receiver_mutation_expr("tree[-1] = payload"),
                &mut ctx,
                "Top",
            )
            .unwrap();
        fn replace_nested(value: &mut RuntimeValue, replacement: f64) {
            let RuntimeValue::Array(outer) = value else {
                panic!("outer array")
            };
            let RuntimeValue::Array(inner) = &mut outer[0] else {
                panic!("inner array")
            };
            inner[0] = RuntimeValue::Number(replacement);
        }
        replace_nested(&mut initial, 11.0);
        let RuntimeValue::Array(values) = &mut rhs else {
            panic!("RHS array")
        };
        values[0] = RuntimeValue::Number(22.0);
        ctx.set_scalar("payload", rhs.clone());
        replace_nested(&mut result, 33.0);
        let mut committed = ctx.get_bare_value("tree");
        replace_nested(&mut committed, 44.0);
        ctx.set_scalar("tree", committed);
        assert_eq!(initial.to_json(), json!([[11]]));
        assert_eq!(ctx.get_bare_value("payload").to_json(), json!([22]));
        assert_eq!(result.to_json(), json!([[33]]));
        assert_eq!(ctx.get_bare_value("tree").to_json(), json!([[44]]));
    }

    #[test]
    fn nested_reads_remain_non_creating_across_absent_missing_and_wrong_kinds() {
        let engine = nested_write_test_engine();
        let read_expr = |source: &str| {
            let block = CodeBlock::parse(&format!("return({source})")).unwrap();
            let Expr::Call { args, .. } = &block.statements[0].expr else {
                panic!("expected return call");
            };
            args[0].value().clone()
        };

        let mut absent = RuntimeContext::new("x");
        assert_eq!(
            engine
                .eval_expr(&read_expr(r#"document["key"]"#), &mut absent, "Top")
                .unwrap(),
            RuntimeValue::Undef
        );
        assert!(!absent.has_bare_binding("document"));

        let mut missing = RuntimeContext::new("x");
        missing.set_scalar("document", RuntimeValue::Hash(Vec::new()));
        assert_eq!(
            engine
                .eval_expr(&read_expr(r#"document["key"][0]"#), &mut missing, "Top",)
                .unwrap(),
            RuntimeValue::Undef
        );
        assert_eq!(
            missing.get_bare_value("document"),
            RuntimeValue::Hash(Vec::new())
        );

        let mut wrong = RuntimeContext::new("x");
        wrong.set_scalar(
            "document",
            RuntimeValue::Hash(vec![("key".into(), RuntimeValue::Scalar("scalar".into()))]),
        );
        assert_eq!(
            engine
                .eval_expr(
                    &read_expr(r#"document["key"]["nested"]"#),
                    &mut wrong,
                    "Top",
                )
                .unwrap(),
            RuntimeValue::Undef
        );
        assert_eq!(
            wrong.get_bare_value("document"),
            RuntimeValue::Hash(vec![("key".into(), RuntimeValue::Scalar("scalar".into()),)])
        );
    }

    fn receiver_mutation_expr(source: &str) -> Expr {
        CodeBlock::parse(source).unwrap().statements[0].expr.clone()
    }

    #[test]
    fn receiver_mutation_callback_failure_is_atomic_and_releases_the_guard() {
        let engine = nested_write_test_engine();
        let original = vec![
            ("a".into(), RuntimeValue::Scalar("A".into())),
            ("b".into(), RuntimeValue::Scalar("B".into())),
        ];
        let mut ctx = RuntimeContext::new("x");
        ctx.set_hash("tree", original.clone());
        ctx.set_array("audit", Vec::new());
        ctx.set_array("journal", Vec::new());

        let failing = receiver_mutation_expr(
            r#"tree.map_leaves!() { audit += path; journal[0] = path; return(if(str_eq(key, "b"), dispatch_span(), else(cat(value, "!")))) }"#,
        );
        let error = engine
            .eval_expr(&failing, &mut ctx, "Top")
            .expect_err("second callback must fail");
        assert!(
            error.contains("progressive_span_binding_required"),
            "{error}"
        );
        assert_eq!(ctx.get_bare_value("tree"), RuntimeValue::Hash(original));
        assert_eq!(
            ctx.get_bare_value("audit"),
            RuntimeValue::Array(vec![
                RuntimeValue::Array(vec![RuntimeValue::Scalar("a".into())]),
                RuntimeValue::Array(vec![RuntimeValue::Scalar("b".into())]),
            ])
        );
        assert_eq!(
            ctx.get_bare_value("journal"),
            RuntimeValue::Array(vec![RuntimeValue::Array(vec![RuntimeValue::Scalar(
                "b".into()
            )])])
        );

        let succeeding =
            receiver_mutation_expr(r#"tree.map_leaves!() { return(cat(value, "!")) }"#);
        let result = engine
            .eval_expr(&succeeding, &mut ctx, "Top")
            .expect("a later invocation proves that the failed guard was released");
        let expected = RuntimeValue::Hash(vec![
            ("a".into(), RuntimeValue::Scalar("A!".into())),
            ("b".into(), RuntimeValue::Scalar("B!".into())),
        ]);
        assert_eq!(result, expected);
        assert_eq!(ctx.get_bare_value("tree"), expected);
    }

    #[test]
    fn receiver_mutation_continuation_failure_preserves_the_completed_commit() {
        let engine = nested_write_test_engine();
        let mut ctx = RuntimeContext::new("x");
        ctx.set_hash("tree", vec![("a".into(), RuntimeValue::Scalar("A".into()))]);
        let expr = receiver_mutation_expr(
            r#"tree.map_leaves!() { return(cat(value, "!")) }.with() { tree["extra"][2] = "X"; return(value) }"#,
        );
        let error = engine
            .eval_expr(&expr, &mut ctx, "Top")
            .expect_err("continuation nested write must fail after publication");
        assert!(error.contains("nested_write_array_gap"), "{error}");
        assert_eq!(
            ctx.get_bare_value("tree"),
            RuntimeValue::Hash(vec![("a".into(), RuntimeValue::Scalar("A!".into()),)])
        );
    }

    #[test]
    fn receiver_mutation_guard_covers_array_end_and_binding_target_pipelines() {
        let engine = nested_write_test_engine();
        let cases = [
            (
                r#"items.map_leaves!() { items += "x"; return(value) }"#,
                "append",
            ),
            (
                r#"items.map_leaves!() { items.push_back("x"); return(value) }"#,
                "push_back",
            ),
            (
                r#"items.map_leaves!() { split_each(items, ","); return(value) }"#,
                "helper:split_each",
            ),
        ];
        for (source, attempt) in cases {
            let mut ctx = RuntimeContext::new("x");
            ctx.set_array("items", vec![RuntimeValue::Scalar("A".into())]);
            let error = engine
                .eval_expr(&receiver_mutation_expr(source), &mut ctx, "Top")
                .expect_err(attempt);
            let payload: Value = serde_json::from_str(&error).unwrap();
            assert_eq!(payload["code"], "receiver_mutation_reentrant");
            assert_eq!(payload["attempt"], attempt);
            assert_eq!(
                ctx.get_bare_value("items"),
                RuntimeValue::Array(vec![RuntimeValue::Scalar("A".into())])
            );
        }

        let mut ctx = RuntimeContext::new("x");
        ctx.set_hash("tree", vec![("a".into(), RuntimeValue::Scalar("A".into()))]);
        let expr = receiver_mutation_expr(
            r#"tree.map_leaves!() { set(tree, { audit += "rhs"; return({}) }); return(value) }"#,
        );
        let error = engine
            .eval_expr(&expr, &mut ctx, "Top")
            .expect_err("helper target guard must precede operand evaluation");
        let payload: Value = serde_json::from_str(&error).unwrap();
        assert_eq!(payload["attempt"], "helper:set");
        assert!(!ctx.has_bare_binding("audit"));

        let mut ctx = RuntimeContext::new("x");
        ctx.set_hash("tree", vec![("a".into(), RuntimeValue::Scalar("A".into()))]);
        let error = engine
            .eval_expr(
                &receiver_mutation_expr(
                    r#"tree.map_leaves!() { tree[dispatch_span()] = dispatch_span(); return(value) }"#,
                ),
                &mut ctx,
                "Top",
            )
            .expect_err("nested-write guard must precede selector and RHS evaluation");
        let payload: Value = serde_json::from_str(&error).unwrap();
        assert_eq!(payload["code"], "receiver_mutation_reentrant");
        assert_eq!(payload["attempt"], "nested_write");

        let mut ctx = RuntimeContext::new("x");
        ctx.set_hash("tree", vec![("a".into(), RuntimeValue::Scalar("A".into()))]);
        ctx.set_array("other", Vec::new());
        let error = engine
            .eval_expr(
                &receiver_mutation_expr(
                    r#"tree.map_leaves!() { other[2] = push(other, "rhs"); return(value) }"#,
                ),
                &mut ctx,
                "Top",
            )
            .expect_err("failed unrelated write must abort receiver publication");
        assert!(error.contains("nested_write_array_gap"), "{error}");
        assert_eq!(
            ctx.get_bare_value("tree"),
            RuntimeValue::Hash(vec![("a".into(), RuntimeValue::Scalar("A".into()))])
        );
        assert_eq!(
            ctx.get_bare_value("other"),
            RuntimeValue::Array(vec![RuntimeValue::Scalar("rhs".into())])
        );
    }
}
