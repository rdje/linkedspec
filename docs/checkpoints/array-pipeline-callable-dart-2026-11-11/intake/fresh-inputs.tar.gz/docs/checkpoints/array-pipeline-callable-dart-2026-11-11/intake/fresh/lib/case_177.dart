// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-pipeline-callable-result-guard/own_signature_variadic_multi_composed.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1waXBlbGluZS1jYWxsYWJsZS1yZXN1bHQtZ3VhcmQvb3duX3NpZ25hdHVyZV92YXJpYWRpY19tdWx0aV9jb21wb3NlZC5zcGVjIiwiZnVuY3Rpb25zIjpbeyJuYW1lIjoiYWxsX3ZhbHVlcyIsInNpZ25hdHVyZSI6eyJraW5kIjoiY2FsbGFibGVfc2lnbmF0dXJlIiwidmVyc2lvbiI6MSwicG9zaXRpb25hbF9wYXJhbXMiOltdLCJyZXN0X3BhcmFtIjoidmFsdWVzIiwibWluX2FyaXR5IjowLCJtYXhfYXJpdHkiOm51bGx9LCJib2R5X3NvdXJjZSI6InJldHVybih2YWx1ZXMpIiwiYm9keV9wYXlsb2FkIjp7ImtpbmQiOiJzdGFnZWRfcGF5bG9hZCIsInZlcnNpb24iOjEsIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJmdW5jdGlvbl9uYW1lIjoiYWxsX3ZhbHVlcyIsInNpZ25hdHVyZSI6eyJraW5kIjoiY2FsbGFibGVfc2lnbmF0dXJlIiwidmVyc2lvbiI6MSwicG9zaXRpb25hbF9wYXJhbXMiOltdLCJyZXN0X3BhcmFtIjoidmFsdWVzIiwibWluX2FyaXR5IjowLCJtYXhfYXJpdHkiOm51bGx9LCJ0ZXh0IjoicmV0dXJuKHZhbHVlcykiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjYsImVuZCI6NDAsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicHJvdmVuYW5jZSI6W3sia2luZCI6InNvdXJjZV9zbGljZSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyNiwiZW5kIjo0MCwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV19LCJib2R5X3BhcnNlX2pvYiI6eyJraW5kIjoicGFyc2Vfam9iIiwidmVyc2lvbiI6MSwiam9iX2lkIjoicGFyc2Vfam9iOmZ1bmN0aW9uX2JvZHk6ZnVuY3Rpb25zLjAuYm9keV9zb3VyY2U6YWN0aW9uaXItYm9keS5zcGVjOmFjdGlvbl9ibG9jazoyNi00MCIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJmdW5jdGlvbl9uYW1lIjoiYWxsX3ZhbHVlcyIsInNpZ25hdHVyZSI6eyJraW5kIjoiY2FsbGFibGVfc2lnbmF0dXJlIiwidmVyc2lvbiI6MSwicG9zaXRpb25hbF9wYXJhbXMiOltdLCJyZXN0X3BhcmFtIjoidmFsdWVzIiwibWluX2FyaXR5IjowLCJtYXhfYXJpdHkiOm51bGx9LCJ0ZXh0IjoicmV0dXJuKHZhbHVlcykiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjYsImVuZCI6NDAsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicGFyc2VyX3NwZWNfaWQiOiJhY3Rpb25pci1ib2R5LnNwZWMiLCJ0b3BfcnVsZSI6ImFjdGlvbl9ibG9jayIsInJlc3VsdF9wb2xpY3kiOiJyZXBsYWNlX2ZpZWxkIiwicmVzdWx0X2ZpZWxkIjoiYm9keV9hc3QiLCJmYWlsdXJlX3BvbGljeSI6ImZhaWwiLCJkaWFnbm9zdGljX293bmVyIjoiZnVuY3Rpb25fYm9keSJ9LCJib2R5X2FzdCI6eyJraW5kIjoiYWN0aW9uX2Jsb2NrIiwic291cmNlIjoicmV0dXJuKHZhbHVlcykiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxNH0sInN0YXRlbWVudHMiOlt7ImtpbmQiOiJhY3Rpb25fc3RtdCIsInNvdXJjZSI6InJldHVybih2YWx1ZXMpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTR9LCJleHByIjp7ImtpbmQiOiJjYWxsIiwic291cmNlIjoicmV0dXJuKHZhbHVlcykiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxNH0sIm5hbWUiOiJyZXR1cm4iLCJzb3VyY2VfbWV0aG9kIjoicmV0dXJuIiwiYXJncyI6W3sia2luZCI6InZhcmlhYmxlIiwic291cmNlIjoidmFsdWVzIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MTN9LCJuYW1lIjoidmFsdWVzIn1dfSwiZHJvcHNfdmFsdWUiOnRydWV9XX0sInNvdXJjZSI6ImZuIGFsbF92YWx1ZXMoLi4udmFsdWVzKSB7cmV0dXJuKHZhbHVlcyl9Iiwic291cmNlX3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJib2R5X3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV0sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7b3JkZXI9XCJcIjtvdXQ9YWxsX3ZhbHVlcyh7b3JkZXI9Y2F0KG9yZGVyLFwiU1wiKTtcIiBoZWFkIFwifSxcIiB0YWlsIFwiKS50cmltX2VhY2goKS5zZXRfa2V5KHtvcmRlcj1jYXQob3JkZXIsXCJLXCIpO1wia1wifSx7b3JkZXI9Y2F0KG9yZGVyLFwiVlwiKTsxfSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKFwicmFuXCIpfTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJvcmRlcj1cIlwiO291dD1hbGxfdmFsdWVzKHtvcmRlcj1jYXQob3JkZXIsXCJTXCIpO1wiIGhlYWQgXCJ9LFwiIHRhaWwgXCIpLnRyaW1fZWFjaCgpLnNldF9rZXkoe29yZGVyPWNhdChvcmRlcixcIktcIik7XCJrXCJ9LHtvcmRlcj1jYXQob3JkZXIsXCJWXCIpOzF9KS53aXRoKCl7b3JkZXI9Y2F0KG9yZGVyLFwiV1wiKTtyZXR1cm4oXCJyYW5cIil9O3JldHVybihbb3V0LG9yZGVyXSkifSwic291cmNlIjoiSSB7b3JkZXI9XCJcIjtvdXQ9YWxsX3ZhbHVlcyh7b3JkZXI9Y2F0KG9yZGVyLFwiU1wiKTtcIiBoZWFkIFwifSxcIiB0YWlsIFwiKS50cmltX2VhY2goKS5zZXRfa2V5KHtvcmRlcj1jYXQob3JkZXIsXCJLXCIpO1wia1wifSx7b3JkZXI9Y2F0KG9yZGVyLFwiVlwiKTsxfSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKFwicmFuXCIpfTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
