// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-pipeline-callable-result-guard/own_signature_fixed_missing_terminal.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1waXBlbGluZS1jYWxsYWJsZS1yZXN1bHQtZ3VhcmQvb3duX3NpZ25hdHVyZV9maXhlZF9taXNzaW5nX3Rlcm1pbmFsLnNwZWMiLCJmdW5jdGlvbnMiOlt7Im5hbWUiOiJwYWlyIiwicGFyYW1zIjpbImxlZnQiLCJyaWdodCJdLCJhcml0eSI6MiwiYm9keV9zb3VyY2UiOiJyZXR1cm4oW2xlZnQscmlnaHRdKSIsImJvZHlfcGF5bG9hZCI6eyJraW5kIjoic3RhZ2VkX3BheWxvYWQiLCJ2ZXJzaW9uIjoxLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwiZnVuY3Rpb25fbmFtZSI6InBhaXIiLCJwYXJhbXMiOlsibGVmdCIsInJpZ2h0Il0sImFyaXR5IjoyLCJ0ZXh0IjoicmV0dXJuKFtsZWZ0LHJpZ2h0XSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjEsImVuZCI6NDEsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicHJvdmVuYW5jZSI6W3sia2luZCI6InNvdXJjZV9zbGljZSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyMSwiZW5kIjo0MSwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV19LCJib2R5X3BhcnNlX2pvYiI6eyJraW5kIjoicGFyc2Vfam9iIiwidmVyc2lvbiI6MSwiam9iX2lkIjoicGFyc2Vfam9iOmZ1bmN0aW9uX2JvZHk6ZnVuY3Rpb25zLjAuYm9keV9zb3VyY2U6YWN0aW9uaXItYm9keS5zcGVjOmFjdGlvbl9ibG9jazoyMS00MSIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJmdW5jdGlvbl9uYW1lIjoicGFpciIsInBhcmFtcyI6WyJsZWZ0IiwicmlnaHQiXSwiYXJpdHkiOjIsInRleHQiOiJyZXR1cm4oW2xlZnQscmlnaHRdKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyMSwiZW5kIjo0MSwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwYXJzZXJfc3BlY19pZCI6ImFjdGlvbmlyLWJvZHkuc3BlYyIsInRvcF9ydWxlIjoiYWN0aW9uX2Jsb2NrIiwicmVzdWx0X3BvbGljeSI6InJlcGxhY2VfZmllbGQiLCJyZXN1bHRfZmllbGQiOiJib2R5X2FzdCIsImZhaWx1cmVfcG9saWN5IjoiZmFpbCIsImRpYWdub3N0aWNfb3duZXIiOiJmdW5jdGlvbl9ib2R5In0sImJvZHlfYXN0Ijp7ImtpbmQiOiJhY3Rpb25fYmxvY2siLCJzb3VyY2UiOiJyZXR1cm4oW2xlZnQscmlnaHRdKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjIwfSwic3RhdGVtZW50cyI6W3sia2luZCI6ImFjdGlvbl9zdG10Iiwic291cmNlIjoicmV0dXJuKFtsZWZ0LHJpZ2h0XSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoyMH0sImV4cHIiOnsia2luZCI6ImNhbGwiLCJzb3VyY2UiOiJyZXR1cm4oW2xlZnQscmlnaHRdKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjIwfSwibmFtZSI6InJldHVybiIsInNvdXJjZV9tZXRob2QiOiJyZXR1cm4iLCJhcmdzIjpbeyJraW5kIjoiYXJyYXlfbGl0ZXJhbCIsInNvdXJjZSI6IltsZWZ0LHJpZ2h0XSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0Ijo3LCJlbmQiOjE5fSwiaXRlbXMiOlt7ImtpbmQiOiJ2YXJpYWJsZSIsInNvdXJjZSI6ImxlZnQiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6OCwiZW5kIjoxMn0sIm5hbWUiOiJsZWZ0In0seyJraW5kIjoidmFyaWFibGUiLCJzb3VyY2UiOiJyaWdodCIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxMywiZW5kIjoxOH0sIm5hbWUiOiJyaWdodCJ9XX1dfSwiZHJvcHNfdmFsdWUiOnRydWV9XX0sInNvdXJjZSI6ImZuIHBhaXIobGVmdCxyaWdodCkge3JldHVybihbbGVmdCxyaWdodF0pfSIsInNvdXJjZV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwiYm9keV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge29yZGVyPVwiXCI7b3V0PXBhaXIoe29yZGVyPWNhdChvcmRlcixcIlNcIik7XCJoZWFkXCJ9KS50cmltX2VhY2goKTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJvcmRlcj1cIlwiO291dD1wYWlyKHtvcmRlcj1jYXQob3JkZXIsXCJTXCIpO1wiaGVhZFwifSkudHJpbV9lYWNoKCk7cmV0dXJuKFtvdXQsb3JkZXJdKSJ9LCJzb3VyY2UiOiJJIHtvcmRlcj1cIlwiO291dD1wYWlyKHtvcmRlcj1jYXQob3JkZXIsXCJTXCIpO1wiaGVhZFwifSkudHJpbV9lYWNoKCk7cmV0dXJuKFtvdXQsb3JkZXJdKX0iLCJsaW5lIjozfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
