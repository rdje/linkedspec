// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "key-count-source/explicit_bridges.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJrZXktY291bnQtc291cmNlL2V4cGxpY2l0X2JyaWRnZXMuc3BlYyIsImZ1bmN0aW9ucyI6W10sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7cmV0dXJuKFtjb3VudF9rZXlzKHtcImFcIjoxLFwiYlwiOjJ9KS5jYXQoXCIsdGFpbFwiKS5zcGxpdChcIixcIikubGFzdCgpLnVwcGVyY2FzZSgpLHtcImFcIjoxLFwiYlwiOjJ9LmNvdW50X2tleXMoKS5jYXQoXCIsdGFpbFwiKS5zcGxpdChcIixcIikubGFzdCgpLnVwcGVyY2FzZSgpLGNvdW50X2tleXMoe30pLndpdGgoKXtyZXR1cm4oWzEsMl0pfS5jb3VudCgpLGNvdW50X2tleXMoe30pLndpdGgoKXtyZXR1cm4oe1wieFwiOjF9KX0uY291bnRfa2V5cygpXSl9IiwibGluZSI6MX0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6InJldHVybihbY291bnRfa2V5cyh7XCJhXCI6MSxcImJcIjoyfSkuY2F0KFwiLHRhaWxcIikuc3BsaXQoXCIsXCIpLmxhc3QoKS51cHBlcmNhc2UoKSx7XCJhXCI6MSxcImJcIjoyfS5jb3VudF9rZXlzKCkuY2F0KFwiLHRhaWxcIikuc3BsaXQoXCIsXCIpLmxhc3QoKS51cHBlcmNhc2UoKSxjb3VudF9rZXlzKHt9KS53aXRoKCl7cmV0dXJuKFsxLDJdKX0uY291bnQoKSxjb3VudF9rZXlzKHt9KS53aXRoKCl7cmV0dXJuKHtcInhcIjoxfSl9LmNvdW50X2tleXMoKV0pIn0sInNvdXJjZSI6Ikkge3JldHVybihbY291bnRfa2V5cyh7XCJhXCI6MSxcImJcIjoyfSkuY2F0KFwiLHRhaWxcIikuc3BsaXQoXCIsXCIpLmxhc3QoKS51cHBlcmNhc2UoKSx7XCJhXCI6MSxcImJcIjoyfS5jb3VudF9rZXlzKCkuY2F0KFwiLHRhaWxcIikuc3BsaXQoXCIsXCIpLmxhc3QoKS51cHBlcmNhc2UoKSxjb3VudF9rZXlzKHt9KS53aXRoKCl7cmV0dXJuKFsxLDJdKX0uY291bnQoKSxjb3VudF9rZXlzKHt9KS53aXRoKCl7cmV0dXJuKHtcInhcIjoxfSl9LmNvdW50X2tleXMoKV0pfSIsImxpbmUiOjF9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
