// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "key-count-source/source_domain.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJrZXktY291bnQtc291cmNlL3NvdXJjZV9kb21haW4uc3BlYyIsImZ1bmN0aW9ucyI6W10sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7cmV0dXJuKFtjb3VudF9rZXlzKHVuZGVmKSxjb3VudF9rZXlzKDQpLGNvdW50X2tleXMoZmFsc2UpLGNvdW50X2tleXMoXCJ0ZXh0XCIpLGNvdW50X2tleXMoW10pLGNvdW50X2tleXMoe30pLGNvdW50X2tleXMoe1wiYVwiOjEsXCJiXCI6Mn0pLHVuZGVmLmNvdW50X2tleXMoKSw0LmNvdW50X2tleXMoKSxmYWxzZS5jb3VudF9rZXlzKCksXCJ0ZXh0XCIuY291bnRfa2V5cygpLFtdLmNvdW50X2tleXMoKSx7fS5jb3VudF9rZXlzKCkse1wiYVwiOjEsXCJiXCI6Mn0uY291bnRfa2V5cygpXSl9IiwibGluZSI6MX0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6InJldHVybihbY291bnRfa2V5cyh1bmRlZiksY291bnRfa2V5cyg0KSxjb3VudF9rZXlzKGZhbHNlKSxjb3VudF9rZXlzKFwidGV4dFwiKSxjb3VudF9rZXlzKFtdKSxjb3VudF9rZXlzKHt9KSxjb3VudF9rZXlzKHtcImFcIjoxLFwiYlwiOjJ9KSx1bmRlZi5jb3VudF9rZXlzKCksNC5jb3VudF9rZXlzKCksZmFsc2UuY291bnRfa2V5cygpLFwidGV4dFwiLmNvdW50X2tleXMoKSxbXS5jb3VudF9rZXlzKCkse30uY291bnRfa2V5cygpLHtcImFcIjoxLFwiYlwiOjJ9LmNvdW50X2tleXMoKV0pIn0sInNvdXJjZSI6Ikkge3JldHVybihbY291bnRfa2V5cyh1bmRlZiksY291bnRfa2V5cyg0KSxjb3VudF9rZXlzKGZhbHNlKSxjb3VudF9rZXlzKFwidGV4dFwiKSxjb3VudF9rZXlzKFtdKSxjb3VudF9rZXlzKHt9KSxjb3VudF9rZXlzKHtcImFcIjoxLFwiYlwiOjJ9KSx1bmRlZi5jb3VudF9rZXlzKCksNC5jb3VudF9rZXlzKCksZmFsc2UuY291bnRfa2V5cygpLFwidGV4dFwiLmNvdW50X2tleXMoKSxbXS5jb3VudF9rZXlzKCkse30uY291bnRfa2V5cygpLHtcImFcIjoxLFwiYlwiOjJ9LmNvdW50X2tleXMoKV0pfSIsImxpbmUiOjF9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
