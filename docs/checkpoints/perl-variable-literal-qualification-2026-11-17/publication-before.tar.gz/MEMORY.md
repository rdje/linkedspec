# MEMORY

- activation_commit: `9a6c66131dfe13140f8d637ca294a2a3c49be97a` — clean variable-literal activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.36` — closed staged-task capacity and parent-link repair.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.1.1.1.1` (active); task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: PNT; continue after each clean leaf.
- next_action: Freeze the original145 and named-support source population, qualify adjacent literal-variable open bindings with static PPI controls and retain every unmatched/other IO route.
- in_flight_uncommitted: Variable-literal source qualification; no background job.
- evidence: docs/checkpoints/task-headroom-staged-2026-11-17/REVIEW.md; readonly review.py/optional --current, parent_links.py and public epoch reader. All15 IDs/CORE/two bodies/tail19108/13 pointers/16 queries/ten controls/current identity;43523 to31551 bytes.
- findings: 11972 current text bytes renewed under unchanged tools/limits. Parent35 link was absent despite its existing completed node;35/36 now pass three public queries/two controls. Old source/SDK facts remain historical; no new runtime/admission proof.
- limits: Full145 variable literals1/other IO2, constructed/helper/support/generated-inline, excluded/computed/transitive/independent semantics, generated Dart/frozen-input and registration remain open. Native/PPI/Perl/outer-first-use/per-read/source-origin/physical4.2/SESSION5 and original Lua reader gap remain.
- publication: Activation/cached4683555e estimate1,496,425,185 bytes/129 ahead/3,574,815-byte margin to director1.5GB excludes this slice. Reuse hash-gated source images; native4.2/independent size30 gaps and all prerequisites remain.
- preceding_normal: .linkedspec-data/task-headroom-staged-commit.log is the complete all10/post-pointer PASS for9a6c6613; earlier literal first/retry attempts remain distinct.
- locality: Only this repository writable; submodules black boxes. Same-volume serial jobs/shared24GB/director90-percent rising trend policy. Last cleanup November16 10:59UTC remains under24h; nothing removed. Normal hooks mandatory.
