Value:: I {order="";out=["head","tail"].take_last(1).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
