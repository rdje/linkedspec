Value:: I {order="";source=["head","tail"];out=source.drop_back(1,{order=cat(order,"E");2});return([out,order])}
