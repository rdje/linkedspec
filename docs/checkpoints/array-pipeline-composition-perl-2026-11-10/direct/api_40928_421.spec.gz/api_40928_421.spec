Value:: I {source=["head","tail","end"];return(slice(source,1))}
