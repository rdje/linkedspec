Value:: I {items=[false,0,undef,{"k":"tail"}];out=reversed(items);return([out,items])}
