Value:: I {return(take().with(){return(value)})}
