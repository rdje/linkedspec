Value:: I {order="";return(split_each(["head:tail"],{items="bad";items+=1;":"}).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).coalesce("masked"))}
