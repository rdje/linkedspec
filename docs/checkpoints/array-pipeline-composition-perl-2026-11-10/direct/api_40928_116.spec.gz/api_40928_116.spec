Value:: I {order="";out=concat_arrays(["head"],["tail"]).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
