Value:: I {source=undef;return(source.take_last(1))}
