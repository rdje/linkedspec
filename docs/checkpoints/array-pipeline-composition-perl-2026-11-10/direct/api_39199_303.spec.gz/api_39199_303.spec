Value:: I {return(undef.lowercase_each())}
