Value:: I {source=3;return(source.drop_back(1).with(){return(value)})}
