Value:: I {return({"k":"tail"}.reversed().with(){return(value)})}
