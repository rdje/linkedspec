Value:: I {return([trim_each([" tail "]).last().uppercase(),filter_match(["head","other"],/^h/).join_values(",")])}
