Value:: I {return({"k":"tail"}.slice(1,1).with(){return(value)})}
