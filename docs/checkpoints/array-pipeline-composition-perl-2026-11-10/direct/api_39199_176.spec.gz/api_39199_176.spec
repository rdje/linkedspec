Value:: I {return(trim_each(undef))}
