Value:: I {source=["head","tail","end"];return(take(source))}
