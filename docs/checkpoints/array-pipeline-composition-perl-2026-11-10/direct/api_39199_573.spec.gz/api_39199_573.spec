Value:: I {items=[3];return([trim_each(items),filter_nonempty(items),uniq(items),items])}
