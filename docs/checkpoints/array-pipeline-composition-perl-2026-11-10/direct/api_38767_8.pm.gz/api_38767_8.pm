# LinkedSpec generated parser source.
# contract_id: linkedspec-generated-source-v2
# format_version: 2
# source_identity: LINKEDSPEC_GENERATED_SOURCE_IDENTITY
no strict;
no warnings 'void';
use re 'eval';
use LinkedSpec::GeneratedSource ();
use LinkedSpec::Runtime ();
use LinkedSpec::Trace ();
use LinkedSpec::EntryRuleSelection ();
use LinkedSpec::RuntimeDiagnosticOutput ();
use LinkedSpec::RuntimeSemanticObservation ();
use LinkedSpec::Numeric ();
use LinkedSpec::UnicodeCaseMapping ();
use LinkedSpec::RecognitionTransactionRuntime ();
use LinkedSpec::InterMatchGapRuntime ();
use LinkedSpec::ProgressiveSpanDispatchRuntime ();
use LinkedSpec::StagedASTEnrichmentRuntime ();
sub _trace_runtime_mark_event { return LinkedSpec::GeneratedSource::trace_mark_event(@_) }
our $LINKEDSPEC_GENERATED_SOURCE_CONTRACT = 'linkedspec-generated-source-v2';
our $LINKEDSPEC_GENERATED_SOURCE_FORMAT = 2;
our $LINKEDSPEC_GENERATED_SOURCE_IDENTITY = 'array-pipeline-value.spec';

my $descr = {
 spec => {

 Top => sub {
my ($descr, $STRING, $info) = @_;
$info = {} unless ref($info) eq "HASH";
require LinkedSpec::SourceLocation;
LinkedSpec::SourceLocation::Runtime::ensure_authority($info, $STRING);
my $IMATCH      = $$info{match};
my @IMATCH_LIST = @{$$info{match_list} // []};
my %IMATCH_HASH = %{$$info{match_hash} // {}};
my $IINDEX      = $$info{index};
# I and blind handlers have no selected local match. Bind their registers here
# so they cannot resolve to package globals outside a matching branch.
my ($LMATCH, $LINDEX, $LSPOS);
my (@LMATCH_LIST, %LMATCH_HASH);
my $IPOS        = LinkedSpec::SourceLocation::Runtime::capture_boundary_write_position(
 $info, $STRING, pos $$STRING, "handler_entry"
);
$$info{marks} = {} unless ref($$info{marks}) eq "HASH";
my $__ls_recognition_invocation = LinkedSpec::RecognitionTransactionRuntime::enter_invocation(
 $descr, $STRING, $info, \$IPOS, "Top"
);


my @Top;

my $source;
my $parts_source;
my $statement_computed;
my $statement_unique;
my $trimmed;
my $nonempty;
my $lower;
my $upper;
my $unique;
my $parts;
my $saved;
my $dynamic;
my $dynamic_receiver;
my $dynamic_nested;
my $dynamic_function;
my $dynamic_computed;
my $dynamic_empty;
my $delimiter_effects;
my $order;
my $regex_parts;
my $statement_dynamic;
my $statement_saved;
my $statement_empty;
my $statement_absent;
my $statement_effects;
my $statement_function;
my $letters;
my $nested;
my $filtered;
my $receiver;
my $function;
my $computed;
my $effects;
my $typed;
my $typed_result;
my $typed_index;
my $typed_filtered;
my $filtered_index;
my $typed_nonempty;
my $nonempty_index;
my $indexed;
my $mut;
my $statement_unique_saved;
my $statement_filter;
my $statement_nonempty;
my $statement_indexed;
my %__ls_binding_presence;
  do { $source = [do { my @__ls_evaluated_values = (" a:A "); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (""); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (" B:B "); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (" a:A "); @__ls_evaluated_values }]; $__ls_binding_presence{"source"} = 1; scalar($source) }; do { $saved = do { my $__ls_copy_value = $source; ref($__ls_copy_value) eq 'ARRAY' ? [@{$__ls_copy_value}] : ref($__ls_copy_value) eq 'HASH' ? { %{$__ls_copy_value} } : !ref($__ls_copy_value) ? $__ls_copy_value : do { require JSON::PP; JSON::PP::is_bool($__ls_copy_value) ? $__ls_copy_value : [] } }; $__ls_binding_presence{"saved"} = 1; scalar($saved) };
 do { $trimmed = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $source; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { my $__ls_array_pipeline_item = defined($_) ? $_ : ''; $__ls_array_pipeline_item =~ s/^\s+|\s+$//g; $__ls_array_pipeline_item } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"trimmed"} = 1; scalar($trimmed) }; do { $nonempty = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $source; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [grep { my $__ls_array_pipeline_candidate = $_; defined($__ls_array_pipeline_candidate) && length($__ls_array_pipeline_candidate) } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"nonempty"} = 1; scalar($nonempty) };
 do { $lower = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $source; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { defined($_) ? LinkedSpec::UnicodeCaseMapping::lowercase($_) : undef } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"lower"} = 1; scalar($lower) }; do { $upper = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $source; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { defined($_) ? LinkedSpec::UnicodeCaseMapping::uppercase($_) : undef } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"upper"} = 1; scalar($upper) }; do { $unique = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $source; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; if (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') { my %__ls_array_pipeline_seen; [grep { my $__ls_array_pipeline_candidate = $_; my $__ls_array_pipeline_key = defined($__ls_array_pipeline_candidate) ? "S$__ls_array_pipeline_candidate" : "U"; !$__ls_array_pipeline_seen{$__ls_array_pipeline_key}++ } @{$__ls_array_pipeline_source}] } else { [] } }; $__ls_binding_presence{"unique"} = 1; scalar($unique) };
 do { $parts_source = [do { my @__ls_evaluated_values = ("a:b"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("c:d"); @__ls_evaluated_values }]; $__ls_binding_presence{"parts_source"} = 1; scalar($parts_source) }; do { $parts = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $parts_source; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { split /\:/, (defined($_) ? $_ : '') } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"parts"} = 1; scalar($parts) };
 do { $delimiter = ":"; $__ls_binding_presence{"delimiter"} = 1; scalar($delimiter) }; do { $dynamic = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $parts_source; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; my $__ls_array_pipeline_delimiter = $delimiter; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY' && defined($__ls_array_pipeline_delimiter)) ? [map { split /\Q$__ls_array_pipeline_delimiter\E/, (defined($_) ? $_ : '') } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"dynamic"} = 1; scalar($dynamic) };
 do { $dynamic_receiver = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = do { my $__ls_array_value = $parts_source; (defined($__ls_array_value) && ref($__ls_array_value) eq 'ARRAY') ? [@{$__ls_array_value}] : [] }; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; my $__ls_array_pipeline_delimiter = $delimiter; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY' && defined($__ls_array_pipeline_delimiter)) ? [map { split /\Q$__ls_array_pipeline_delimiter\E/, (defined($_) ? $_ : '') } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"dynamic_receiver"} = 1; scalar($dynamic_receiver) }; do { $dynamic_nested = do { my $__ls_count = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $parts_source; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; my $__ls_array_pipeline_delimiter = $delimiter; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY' && defined($__ls_array_pipeline_delimiter)) ? [map { split /\Q$__ls_array_pipeline_delimiter\E/, (defined($_) ? $_ : '') } @{$__ls_array_pipeline_source}] : [] }; ref($__ls_count) eq 'ARRAY' ? scalar(@{$__ls_count}) : 0 }; $__ls_binding_presence{"dynamic_nested"} = 1; scalar($dynamic_nested) };
 do { $dynamic_function = do { my %__ls_binding_presence = ("values" => 1, "delimiter" => 1); my $__ls_user_fn_arg_0 = $parts_source; my $__ls_user_fn_arg_1 = $delimiter; my $values = $__ls_user_fn_arg_0; my $delimiter = $__ls_user_fn_arg_1; my $__ls_user_fn_codeblock_bindings = {"delimiter" => \$delimiter, "values" => \$values}; do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $values; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; my $__ls_array_pipeline_delimiter = $delimiter; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY' && defined($__ls_array_pipeline_delimiter)) ? [map { split /\Q$__ls_array_pipeline_delimiter\E/, (defined($_) ? $_ : '') } @{$__ls_array_pipeline_source}] : [] } }; $__ls_binding_presence{"dynamic_function"} = 1; scalar($dynamic_function) }; do { $delimiter_effects = 0; $__ls_binding_presence{"delimiter_effects"} = 1; scalar($delimiter_effects) }; do { $order = ""; $__ls_binding_presence{"order"} = 1; scalar($order) };
 do { $dynamic_computed = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = do { do { $order = do { my @__ls_cat_parts = ($order, "S"); my $__ls_cat_ok = 1; for my $__ls_cat_part (@__ls_cat_parts) { if (!defined($__ls_cat_part)) { $__ls_cat_ok = 0; last; } if (ref($__ls_cat_part)) { if (ref($__ls_cat_part) eq 'JSON::PP::Boolean') { $__ls_cat_part = $__ls_cat_part ? '1' : '0'; } else { $__ls_cat_ok = 0; last; } } else { $__ls_cat_part = "$__ls_cat_part"; $__ls_cat_part = '0' if $__ls_cat_part =~ /\A-0(?:\.0+)?\z/; } } $__ls_cat_ok ? join('', @__ls_cat_parts) : undef }; $__ls_binding_presence{"order"} = 1; scalar($order) }; [do { my @__ls_evaluated_values = ("x.y"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("z."); @__ls_evaluated_values }] }; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; my $__ls_array_pipeline_delimiter = do { do { $order = do { my @__ls_cat_parts = ($order, "D"); my $__ls_cat_ok = 1; for my $__ls_cat_part (@__ls_cat_parts) { if (!defined($__ls_cat_part)) { $__ls_cat_ok = 0; last; } if (ref($__ls_cat_part)) { if (ref($__ls_cat_part) eq 'JSON::PP::Boolean') { $__ls_cat_part = $__ls_cat_part ? '1' : '0'; } else { $__ls_cat_ok = 0; last; } } else { $__ls_cat_part = "$__ls_cat_part"; $__ls_cat_part = '0' if $__ls_cat_part =~ /\A-0(?:\.0+)?\z/; } } $__ls_cat_ok ? join('', @__ls_cat_parts) : undef }; $__ls_binding_presence{"order"} = 1; scalar($order) }; do { $delimiter_effects = do { my @__ls_num_add_terms = (do { my @__ls_evaluated_values = ($delimiter_effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (1); @__ls_evaluated_values }); LinkedSpec::Numeric::evaluate('num_add', @__ls_num_add_terms) }; $__ls_binding_presence{"delimiter_effects"} = 1; scalar($delimiter_effects) }; "." }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY' && defined($__ls_array_pipeline_delimiter)) ? [map { split /\Q$__ls_array_pipeline_delimiter\E/, (defined($_) ? $_ : '') } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"dynamic_computed"} = 1; scalar($dynamic_computed) };
 do { $dynamic_empty = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = []; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; my $__ls_array_pipeline_delimiter = do { do { $delimiter_effects = do { my @__ls_num_add_terms = (do { my @__ls_evaluated_values = ($delimiter_effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (1); @__ls_evaluated_values }); LinkedSpec::Numeric::evaluate('num_add', @__ls_num_add_terms) }; $__ls_binding_presence{"delimiter_effects"} = 1; scalar($delimiter_effects) }; ":" }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY' && defined($__ls_array_pipeline_delimiter)) ? [map { split /\Q$__ls_array_pipeline_delimiter\E/, (defined($_) ? $_ : '') } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"dynamic_empty"} = 1; scalar($dynamic_empty) };
 do { $regex_parts = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = [do { my @__ls_evaluated_values = ("aXb"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("cxd"); @__ls_evaluated_values }]; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { split /x/i, (defined($_) ? $_ : '') } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"regex_parts"} = 1; scalar($regex_parts) };
 do { $statement_dynamic = do { my $__ls_copy_value = $parts_source; ref($__ls_copy_value) eq 'ARRAY' ? [@{$__ls_copy_value}] : ref($__ls_copy_value) eq 'HASH' ? { %{$__ls_copy_value} } : !ref($__ls_copy_value) ? $__ls_copy_value : do { require JSON::PP; JSON::PP::is_bool($__ls_copy_value) ? $__ls_copy_value : [] } }; $__ls_binding_presence{"statement_dynamic"} = 1; scalar($statement_dynamic) }; do { require LinkedSpec::BindingRuntime; $statement_dynamic = do { my $__ls_split_each_source = LinkedSpec::BindingRuntime::array_snapshot($statement_dynamic, "statement_dynamic"); LinkedSpec::BindingRuntime::array_transform($__ls_split_each_source, "statement_dynamic", "split_each", do { my $__ls_split_each_delimiter = $delimiter; qr/\Q$__ls_split_each_delimiter\E/ }) }; $statement_dynamic };
 do { $statement_effects = 0; $__ls_binding_presence{"statement_effects"} = 1; scalar($statement_effects) }; do { $statement_computed = [do { my @__ls_evaluated_values = ("a.b"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("c."); @__ls_evaluated_values }]; $__ls_binding_presence{"statement_computed"} = 1; scalar($statement_computed) }; do { $statement_saved = do { my $__ls_copy_value = $statement_computed; ref($__ls_copy_value) eq 'ARRAY' ? [@{$__ls_copy_value}] : ref($__ls_copy_value) eq 'HASH' ? { %{$__ls_copy_value} } : !ref($__ls_copy_value) ? $__ls_copy_value : do { require JSON::PP; JSON::PP::is_bool($__ls_copy_value) ? $__ls_copy_value : [] } }; $__ls_binding_presence{"statement_saved"} = 1; scalar($statement_saved) };
 do { require LinkedSpec::BindingRuntime; $statement_computed = do { my $__ls_split_each_source = LinkedSpec::BindingRuntime::array_snapshot($statement_computed, "statement_computed"); LinkedSpec::BindingRuntime::array_transform($__ls_split_each_source, "statement_computed", "split_each", do { my $__ls_split_each_delimiter = do { do { $statement_effects = do { my @__ls_num_add_terms = (do { my @__ls_evaluated_values = ($statement_effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (1); @__ls_evaluated_values }); LinkedSpec::Numeric::evaluate('num_add', @__ls_num_add_terms) }; $__ls_binding_presence{"statement_effects"} = 1; scalar($statement_effects) }; "." }; qr/\Q$__ls_split_each_delimiter\E/ }) }; $statement_computed };
 do { $statement_empty = []; $__ls_binding_presence{"statement_empty"} = 1; scalar($statement_empty) }; do { require LinkedSpec::BindingRuntime; $statement_empty = do { my $__ls_split_each_source = LinkedSpec::BindingRuntime::array_snapshot($statement_empty, "statement_empty"); LinkedSpec::BindingRuntime::array_transform($__ls_split_each_source, "statement_empty", "split_each", do { my $__ls_split_each_delimiter = do { do { $statement_effects = do { my @__ls_num_add_terms = (do { my @__ls_evaluated_values = ($statement_effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (1); @__ls_evaluated_values }); LinkedSpec::Numeric::evaluate('num_add', @__ls_num_add_terms) }; $__ls_binding_presence{"statement_effects"} = 1; scalar($statement_effects) }; ":" }; qr/\Q$__ls_split_each_delimiter\E/ }) }; $statement_empty };
 do { require LinkedSpec::BindingRuntime; $statement_absent = do { my $__ls_split_each_source = LinkedSpec::BindingRuntime::array_snapshot($statement_absent, "statement_absent"); LinkedSpec::BindingRuntime::array_transform($__ls_split_each_source, "statement_absent", "split_each", do { my $__ls_split_each_delimiter = do { do { $statement_effects = do { my @__ls_num_add_terms = (do { my @__ls_evaluated_values = ($statement_effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (1); @__ls_evaluated_values }); LinkedSpec::Numeric::evaluate('num_add', @__ls_num_add_terms) }; $__ls_binding_presence{"statement_effects"} = 1; scalar($statement_effects) }; ":" }; qr/\Q$__ls_split_each_delimiter\E/ }) }; $statement_absent };
 do { $statement_function = do { my %__ls_binding_presence = ("values" => 1, "delimiter" => 1); my $__ls_user_fn_arg_0 = $parts_source; my $__ls_user_fn_arg_1 = $delimiter; my $values = $__ls_user_fn_arg_0; my $delimiter = $__ls_user_fn_arg_1; my $__ls_user_fn_codeblock_bindings = {"delimiter" => \$delimiter, "values" => \$values}; do { require LinkedSpec::BindingRuntime; $values = do { my $__ls_split_each_source = LinkedSpec::BindingRuntime::array_snapshot($values, "values"); LinkedSpec::BindingRuntime::array_transform($__ls_split_each_source, "values", "split_each", do { my $__ls_split_each_delimiter = $delimiter; qr/\Q$__ls_split_each_delimiter\E/ }) }; $values }; $values }; $__ls_binding_presence{"statement_function"} = 1; scalar($statement_function) };
 do { $letters = [do { my @__ls_evaluated_values = ("a"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("b"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("a"); @__ls_evaluated_values }]; $__ls_binding_presence{"letters"} = 1; scalar($letters) };
 do { $nested = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $letters; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { defined($_) ? LinkedSpec::UnicodeCaseMapping::uppercase($_) : undef } @{$__ls_array_pipeline_source}] : [] }; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; if (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') { my %__ls_array_pipeline_seen; [grep { my $__ls_array_pipeline_candidate = $_; my $__ls_array_pipeline_key = defined($__ls_array_pipeline_candidate) ? "S$__ls_array_pipeline_candidate" : "U"; !$__ls_array_pipeline_seen{$__ls_array_pipeline_key}++ } @{$__ls_array_pipeline_source}] } else { [] } }; $__ls_binding_presence{"nested"} = 1; scalar($nested) };
 do { $filtered = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $letters; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { defined($_) ? LinkedSpec::UnicodeCaseMapping::uppercase($_) : undef } @{$__ls_array_pipeline_source}] : [] }; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; if (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') { my %__ls_array_pipeline_seen; [grep { my $__ls_array_pipeline_candidate = $_; my $__ls_array_pipeline_key = defined($__ls_array_pipeline_candidate) ? "S$__ls_array_pipeline_candidate" : "U"; !$__ls_array_pipeline_seen{$__ls_array_pipeline_key}++ } @{$__ls_array_pipeline_source}] } else { [] } }; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [grep { my $__ls_array_pipeline_candidate = $_; defined($__ls_array_pipeline_candidate) && $__ls_array_pipeline_candidate =~ /^A/ } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"filtered"} = 1; scalar($filtered) };
 do { $receiver = do { my $__ls_free_default_rejected = 0; my $__ls_free_default_value = do { my $__ls_scalar_source = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = do { my $__ls_array_value = $letters; (defined($__ls_array_value) && ref($__ls_array_value) eq 'ARRAY') ? [@{$__ls_array_value}] : [] }; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { defined($_) ? LinkedSpec::UnicodeCaseMapping::uppercase($_) : undef } @{$__ls_array_pipeline_source}] : [] }; $__ls_scalar_source }; $__ls_free_default_value = $__ls_free_default_rejected ? undef : (do { my $__ls_selected_default = $__ls_free_default_value; ref($__ls_selected_default) eq 'ARRAY' ? (do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $__ls_selected_default; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; if (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') { my %__ls_array_pipeline_seen; [grep { my $__ls_array_pipeline_candidate = $_; my $__ls_array_pipeline_key = defined($__ls_array_pipeline_candidate) ? "S$__ls_array_pipeline_candidate" : "U"; !$__ls_array_pipeline_seen{$__ls_array_pipeline_key}++ } @{$__ls_array_pipeline_source}] } else { [] } }) : do { $__ls_free_default_rejected = 1; undef } }); $__ls_free_default_value }; $__ls_binding_presence{"receiver"} = 1; scalar($receiver) };
 do { $function = do { my %__ls_binding_presence = ("values" => 1); my $__ls_user_fn_arg_0 = $source; my $values = $__ls_user_fn_arg_0; my $__ls_user_fn_codeblock_bindings = {"values" => \$values}; do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $values; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [map { my $__ls_array_pipeline_item = defined($_) ? $_ : ''; $__ls_array_pipeline_item =~ s/^\s+|\s+$//g; $__ls_array_pipeline_item } @{$__ls_array_pipeline_source}] : [] }; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; if (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') { my %__ls_array_pipeline_seen; [grep { my $__ls_array_pipeline_candidate = $_; my $__ls_array_pipeline_key = defined($__ls_array_pipeline_candidate) ? "S$__ls_array_pipeline_candidate" : "U"; !$__ls_array_pipeline_seen{$__ls_array_pipeline_key}++ } @{$__ls_array_pipeline_source}] } else { [] } } }; $__ls_binding_presence{"function"} = 1; scalar($function) }; do { $effects = 0; $__ls_binding_presence{"effects"} = 1; scalar($effects) };
 do { $computed = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = do { do { $effects = do { my @__ls_num_add_terms = (do { my @__ls_evaluated_values = ($effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (1); @__ls_evaluated_values }); LinkedSpec::Numeric::evaluate('num_add', @__ls_num_add_terms) }; $__ls_binding_presence{"effects"} = 1; scalar($effects) }; [do { my @__ls_evaluated_values = ("z"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("z"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("y"); @__ls_evaluated_values }] }; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; if (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') { my %__ls_array_pipeline_seen; [grep { my $__ls_array_pipeline_candidate = $_; my $__ls_array_pipeline_key = defined($__ls_array_pipeline_candidate) ? "S$__ls_array_pipeline_candidate" : "U"; !$__ls_array_pipeline_seen{$__ls_array_pipeline_key}++ } @{$__ls_array_pipeline_source}] } else { [] } }; $__ls_binding_presence{"computed"} = 1; scalar($computed) };
 do { $typed = [do { my @__ls_evaluated_values = (2); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("2"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("x"); @__ls_evaluated_values }]; $__ls_binding_presence{"typed"} = 1; scalar($typed) }; do { $typed_result = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $typed; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; if (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') { my %__ls_array_pipeline_seen; [grep { my $__ls_array_pipeline_candidate = $_; my $__ls_array_pipeline_key = defined($__ls_array_pipeline_candidate) ? "S$__ls_array_pipeline_candidate" : "U"; !$__ls_array_pipeline_seen{$__ls_array_pipeline_key}++ } @{$__ls_array_pipeline_source}] } else { [] } }; $__ls_binding_presence{"typed_result"} = 1; scalar($typed_result) }; do { $typed_index = do { my $__ls_first = $typed_result; ref($__ls_first) eq 'ARRAY' && @{$__ls_first} ? $__ls_first->[0] : undef }; $__ls_binding_presence{"typed_index"} = 1; scalar($typed_index) };
 do { $typed_filtered = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = $typed; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [grep { my $__ls_array_pipeline_candidate = $_; defined($__ls_array_pipeline_candidate) && $__ls_array_pipeline_candidate =~ /^2$/ } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"typed_filtered"} = 1; scalar($typed_filtered) }; do { $filtered_index = do { my $__ls_first = $typed_filtered; ref($__ls_first) eq 'ARRAY' && @{$__ls_first} ? $__ls_first->[0] : undef }; $__ls_binding_presence{"filtered_index"} = 1; scalar($filtered_index) };
 do { $typed_nonempty = do { my $__ls_array_pipeline_source = do { my $__ls_array_value_source = [do { my @__ls_evaluated_values = (2); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (""); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (undef); @__ls_evaluated_values }]; (defined($__ls_array_value_source) && ref($__ls_array_value_source) eq 'ARRAY') ? [@{$__ls_array_value_source}] : [] }; (defined($__ls_array_pipeline_source) && ref($__ls_array_pipeline_source) eq 'ARRAY') ? [grep { my $__ls_array_pipeline_candidate = $_; defined($__ls_array_pipeline_candidate) && length($__ls_array_pipeline_candidate) } @{$__ls_array_pipeline_source}] : [] }; $__ls_binding_presence{"typed_nonempty"} = 1; scalar($typed_nonempty) }; do { $nonempty_index = do { my $__ls_first = $typed_nonempty; ref($__ls_first) eq 'ARRAY' && @{$__ls_first} ? $__ls_first->[0] : undef }; $__ls_binding_presence{"nonempty_index"} = 1; scalar($nonempty_index) };
 do { $statement_unique = [do { my @__ls_evaluated_values = (2); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("2"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (undef); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (""); @__ls_evaluated_values }]; $__ls_binding_presence{"statement_unique"} = 1; scalar($statement_unique) }; do { $statement_unique_saved = do { my $__ls_copy_value = $statement_unique; ref($__ls_copy_value) eq 'ARRAY' ? [@{$__ls_copy_value}] : ref($__ls_copy_value) eq 'HASH' ? { %{$__ls_copy_value} } : !ref($__ls_copy_value) ? $__ls_copy_value : do { require JSON::PP; JSON::PP::is_bool($__ls_copy_value) ? $__ls_copy_value : [] } }; $__ls_binding_presence{"statement_unique_saved"} = 1; scalar($statement_unique_saved) }; do { require LinkedSpec::BindingRuntime; $statement_unique = LinkedSpec::BindingRuntime::array_transform($statement_unique, "statement_unique", "uniq"); $statement_unique };
 do { $statement_filter = [do { my @__ls_evaluated_values = (2); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("2"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("x"); @__ls_evaluated_values }]; $__ls_binding_presence{"statement_filter"} = 1; scalar($statement_filter) }; do { require LinkedSpec::BindingRuntime; $statement_filter = LinkedSpec::BindingRuntime::array_transform($statement_filter, "statement_filter", "filter_match", qr/^2$/); $statement_filter };
 do { $statement_nonempty = [do { my @__ls_evaluated_values = (2); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (""); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (undef); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("0"); @__ls_evaluated_values }]; $__ls_binding_presence{"statement_nonempty"} = 1; scalar($statement_nonempty) }; do { require LinkedSpec::BindingRuntime; $statement_nonempty = LinkedSpec::BindingRuntime::array_transform($statement_nonempty, "statement_nonempty", "filter_nonempty"); $statement_nonempty };
 do { $statement_indexed = [do { my @__ls_evaluated_values = ("zero"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("one"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("two"); @__ls_evaluated_values }]; $__ls_binding_presence{"statement_indexed"} = 1; scalar($statement_indexed) };
 do { my $__ls_path_segment_0 = do { my $__ls_first = $statement_unique; ref($__ls_first) eq 'ARRAY' && @{$__ls_first} ? $__ls_first->[0] : undef }; my $__ls_path_value = "unique"; my $__ls_path_present = (defined($statement_indexed) || $__ls_binding_presence{"statement_indexed"}) ? 1 : 0; require LinkedSpec::BindingRuntime; my ($__ls_path_updated, $__ls_path_result) = LinkedSpec::BindingRuntime::nested_write($statement_indexed, $__ls_path_present, "statement_indexed", [{ value => $__ls_path_segment_0, kind_hint => "dynamic", source_span => { source_id => "action:Top", start => 18, end => 41, unit => "unicode_scalar", provenance => "authored" } }], $__ls_path_value); $statement_indexed = $__ls_path_updated; $__ls_binding_presence{"statement_indexed"} = 1; $__ls_path_result };
 do { my $__ls_path_segment_0 = do { my $__ls_first = $statement_filter; ref($__ls_first) eq 'ARRAY' && @{$__ls_first} ? $__ls_first->[0] : undef }; my $__ls_path_value = "filtered"; my $__ls_path_present = (defined($statement_indexed) || $__ls_binding_presence{"statement_indexed"}) ? 1 : 0; require LinkedSpec::BindingRuntime; my ($__ls_path_updated, $__ls_path_result) = LinkedSpec::BindingRuntime::nested_write($statement_indexed, $__ls_path_present, "statement_indexed", [{ value => $__ls_path_segment_0, kind_hint => "dynamic", source_span => { source_id => "action:Top", start => 18, end => 41, unit => "unicode_scalar", provenance => "authored" } }], $__ls_path_value); $statement_indexed = $__ls_path_updated; $__ls_binding_presence{"statement_indexed"} = 1; $__ls_path_result };
 do { my $__ls_path_segment_0 = do { my $__ls_first = $statement_nonempty; ref($__ls_first) eq 'ARRAY' && @{$__ls_first} ? $__ls_first->[0] : undef }; my $__ls_path_value = "selected"; my $__ls_path_present = (defined($statement_indexed) || $__ls_binding_presence{"statement_indexed"}) ? 1 : 0; require LinkedSpec::BindingRuntime; my ($__ls_path_updated, $__ls_path_result) = LinkedSpec::BindingRuntime::nested_write($statement_indexed, $__ls_path_present, "statement_indexed", [{ value => $__ls_path_segment_0, kind_hint => "dynamic", source_span => { source_id => "action:Top", start => 18, end => 43, unit => "unicode_scalar", provenance => "authored" } }], $__ls_path_value); $statement_indexed = $__ls_path_updated; $__ls_binding_presence{"statement_indexed"} = 1; $__ls_path_result };
 do { $indexed = [do { my @__ls_evaluated_values = ("zero"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("one"); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ("two"); @__ls_evaluated_values }]; $__ls_binding_presence{"indexed"} = 1; scalar($indexed) }; do { my $__ls_path_segment_0 = $typed_index; my $__ls_path_value = "unique"; my $__ls_path_present = (defined($indexed) || $__ls_binding_presence{"indexed"}) ? 1 : 0; require LinkedSpec::BindingRuntime; my ($__ls_path_updated, $__ls_path_result) = LinkedSpec::BindingRuntime::nested_write($indexed, $__ls_path_present, "indexed", [{ value => $__ls_path_segment_0, kind_hint => "dynamic", source_span => { source_id => "action:Top", start => 8, end => 19, unit => "unicode_scalar", provenance => "authored" } }], $__ls_path_value); $indexed = $__ls_path_updated; $__ls_binding_presence{"indexed"} = 1; $__ls_path_result };
 do { my $__ls_path_segment_0 = $filtered_index; my $__ls_path_value = "filtered"; my $__ls_path_present = (defined($indexed) || $__ls_binding_presence{"indexed"}) ? 1 : 0; require LinkedSpec::BindingRuntime; my ($__ls_path_updated, $__ls_path_result) = LinkedSpec::BindingRuntime::nested_write($indexed, $__ls_path_present, "indexed", [{ value => $__ls_path_segment_0, kind_hint => "dynamic", source_span => { source_id => "action:Top", start => 8, end => 22, unit => "unicode_scalar", provenance => "authored" } }], $__ls_path_value); $indexed = $__ls_path_updated; $__ls_binding_presence{"indexed"} = 1; $__ls_path_result }; do { my $__ls_path_segment_0 = $nonempty_index; my $__ls_path_value = "selected"; my $__ls_path_present = (defined($indexed) || $__ls_binding_presence{"indexed"}) ? 1 : 0; require LinkedSpec::BindingRuntime; my ($__ls_path_updated, $__ls_path_result) = LinkedSpec::BindingRuntime::nested_write($indexed, $__ls_path_present, "indexed", [{ value => $__ls_path_segment_0, kind_hint => "dynamic", source_span => { source_id => "action:Top", start => 8, end => 22, unit => "unicode_scalar", provenance => "authored" } }], $__ls_path_value); $indexed = $__ls_path_updated; $__ls_binding_presence{"indexed"} = 1; $__ls_path_result }; do { my $__ls_path_segment_0 = 0; my $__ls_path_value = 9; my $__ls_path_present = (defined($typed_result) || $__ls_binding_presence{"typed_result"}) ? 1 : 0; require LinkedSpec::BindingRuntime; my ($__ls_path_updated, $__ls_path_result) = LinkedSpec::BindingRuntime::nested_write($typed_result, $__ls_path_present, "typed_result", [{ value => $__ls_path_segment_0, kind_hint => "integer", source_span => { source_id => "action:Top", start => 13, end => 14, unit => "unicode_scalar", provenance => "authored" } }], $__ls_path_value); $typed_result = $__ls_path_updated; $__ls_binding_presence{"typed_result"} = 1; $__ls_path_result };
 do { my $__ls_path_segment_0 = 0; my $__ls_path_value = "changed"; my $__ls_path_present = (defined($trimmed) || $__ls_binding_presence{"trimmed"}) ? 1 : 0; require LinkedSpec::BindingRuntime; my ($__ls_path_updated, $__ls_path_result) = LinkedSpec::BindingRuntime::nested_write($trimmed, $__ls_path_present, "trimmed", [{ value => $__ls_path_segment_0, kind_hint => "integer", source_span => { source_id => "action:Top", start => 8, end => 9, unit => "unicode_scalar", provenance => "authored" } }], $__ls_path_value); $trimmed = $__ls_path_updated; $__ls_binding_presence{"trimmed"} = 1; $__ls_path_result };
 do { $mut = [do { my @__ls_evaluated_values = (" a:A "); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (""); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (" b:B "); @__ls_evaluated_values }, do { my @__ls_evaluated_values = (" a:A "); @__ls_evaluated_values }]; $__ls_binding_presence{"mut"} = 1; scalar($mut) };
 do { require LinkedSpec::BindingRuntime; $mut = LinkedSpec::BindingRuntime::array_transform($mut, "mut", "trim_each"); $mut }; do { require LinkedSpec::BindingRuntime; $mut = LinkedSpec::BindingRuntime::array_transform($mut, "mut", "filter_nonempty"); $mut }; do { require LinkedSpec::BindingRuntime; $mut = LinkedSpec::BindingRuntime::array_transform($mut, "mut", "split_each", qr/\:/); $mut };
 do { require LinkedSpec::BindingRuntime; $mut = LinkedSpec::BindingRuntime::array_transform($mut, "mut", "lowercase_each"); $mut }; do { require LinkedSpec::BindingRuntime; $mut = LinkedSpec::BindingRuntime::array_transform($mut, "mut", "uppercase_each"); $mut }; do { require LinkedSpec::BindingRuntime; $mut = LinkedSpec::BindingRuntime::array_transform($mut, "mut", "uniq"); $mut };
 return [do { my @__ls_evaluated_values = ($trimmed); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($nonempty); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($lower); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($upper); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($unique); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($parts); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($source); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($saved); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($parts_source); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($dynamic); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($dynamic_receiver); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($dynamic_nested); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($dynamic_function); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($dynamic_computed); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($dynamic_empty); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($delimiter_effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($order); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($regex_parts); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_dynamic); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_computed); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_saved); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_empty); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_absent); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_function); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($letters); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($nested); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($filtered); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($receiver); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($function); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($computed); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($effects); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($typed); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($typed_result); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($typed_index); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($typed_filtered); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($filtered_index); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($typed_nonempty); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($nonempty_index); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($indexed); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($mut); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_unique); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_unique_saved); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_filter); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_nonempty); @__ls_evaluated_values }, do { my @__ls_evaluated_values = ($statement_indexed); @__ls_evaluated_values }];
 },
 },
 dependency_regex_map => {

 },
 dependency_slot_map => {

 },
 recognition_regex_map => {
 Top => []
 }
};

for my $linkedspec_rule_label (sort keys %{$descr->{spec}}) {
 $descr->{spec}{$linkedspec_rule_label} =
  LinkedSpec::RecognitionTransactionRuntime::guard_rule_handler(
   $linkedspec_rule_label, $descr->{spec}{$linkedspec_rule_label},
  );
}

my $LINKEDSPEC_GENERATED_EXPECTED_PLAN = [
 { label => 'Top', family => 'default' },
];
my $LINKEDSPEC_GENERATED_ACTIVE_PLAN = LinkedSpec::GeneratedSource::clone_plan($LINKEDSPEC_GENERATED_EXPECTED_PLAN);
my $LINKEDSPEC_GENERATED_ENTRY_RULES = [
 { label => 'Top', is_top => 1 },
];
my $LINKEDSPEC_GENERATED_CONFIGURED_ENTRY_RULE = undef;

sub LinkedSpecGeneratedMetadata {
 return {
  contract_id => $LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
  format_version => $LINKEDSPEC_GENERATED_SOURCE_FORMAT,
  source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
  plan => LinkedSpec::GeneratedSource::clone_plan($LINKEDSPEC_GENERATED_EXPECTED_PLAN),
  entry_rule_contract => $LinkedSpec::EntryRuleSelection::CONTRACT_ID,
  entry_rules => LinkedSpec::GeneratedSource::clone_entry_rules($LINKEDSPEC_GENERATED_ENTRY_RULES),
 }
}

sub LinkedSpecGeneratedPlan {
 return LinkedSpec::GeneratedSource::clone_plan($LINKEDSPEC_GENERATED_EXPECTED_PLAN)
}

sub ValidateGeneratedPlan {
 my ($plan, $actual_contract) = @_;
 $plan = $LINKEDSPEC_GENERATED_ACTIVE_PLAN unless defined $plan;
 $actual_contract = $LINKEDSPEC_GENERATED_SOURCE_CONTRACT unless defined $actual_contract;
 return LinkedSpec::GeneratedSource::validate_plan(
  expected => $LINKEDSPEC_GENERATED_EXPECTED_PLAN,
  actual => $plan,
  source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
  expected_contract => 'linkedspec-generated-source-v2',
  actual_contract => $actual_contract,
 )
}

sub Execute {
 my ($input_ref, $invocation_options) = @_;
 ValidateGeneratedPlan();
 LinkedSpec::Runtime::_prepare_public_input($input_ref);
 my $diagnostic_sink = LinkedSpec::RuntimeDiagnosticOutput::validate_invocation_options(
  $invocation_options,
 );
 my $semantic_observation_sink = LinkedSpec::RuntimeSemanticObservation::validate_invocation_options(
  $invocation_options,
 );
 my $progressive_dispatch_state = LinkedSpec::ProgressiveSpanDispatchRuntime::begin_invocation(
  $input_ref,
  $invocation_options,
 );
 my $staged_enrichment_state = LinkedSpec::StagedASTEnrichmentRuntime::begin_invocation(
  $input_ref,
  $invocation_options,
 );
 my $explicit_entry_rule = $LINKEDSPEC_GENERATED_CONFIGURED_ENTRY_RULE;
 if (ref($invocation_options) eq 'HASH'
  && defined($invocation_options->{top_rule})
  && length($invocation_options->{top_rule})) {
  $explicit_entry_rule = $invocation_options->{top_rule};
 }
 my $entry_selection = LinkedSpec::EntryRuleSelection::select_entry_rule(
  $LINKEDSPEC_GENERATED_ENTRY_RULES,
  $explicit_entry_rule,
 );
 unless ($entry_selection->{ok}) {
  my $entry_rule = $entry_selection->{entry_rule};
  LinkedSpec::GeneratedSource::trace_role(
   role => 'generated_entry_selection',
   source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
   rule_label => defined($entry_rule) ? $entry_rule : '',
   status => 'error',
  );
  die LinkedSpec::GeneratedSource::new_error(
   stage => $entry_selection->{stage},
   code => $entry_selection->{code},
   summary => 'Generated parser entry-rule selection failed',
   source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
   defined($entry_rule) ? (entry_rule => $entry_rule, rule_label => $entry_rule) : (),
   detail => defined($entry_rule)
    ? "No declared rule matches explicit entry selector '$entry_rule'"
    : 'Generated parser source has no declared entry rule',
  )
 }
 my $entry_rule = $entry_selection->{entry_rule};
 my $entry_family = LinkedSpec::GeneratedSource::family_for_rule(
  $LINKEDSPEC_GENERATED_EXPECTED_PLAN,
  $entry_rule,
 );
 my $sink_slot = LinkedSpec::RuntimeDiagnosticOutput::sink_slot_name();
 my $control_error_slot = LinkedSpec::RuntimeDiagnosticOutput::control_error_slot_name();
 my $semantic_sink_slot = LinkedSpec::RuntimeSemanticObservation::sink_slot_name();
 my $semantic_control_error_slot = LinkedSpec::RuntimeSemanticObservation::control_error_slot_name();
 my $progressive_dispatch_slot = LinkedSpec::ProgressiveSpanDispatchRuntime::descriptor_slot_name();
 local $descr->{$sink_slot} = $diagnostic_sink;
 local $descr->{$control_error_slot} = undef;
 local $descr->{$semantic_sink_slot} = $semantic_observation_sink;
 local $descr->{$semantic_control_error_slot} = undef;
 local $descr->{$progressive_dispatch_slot} = $progressive_dispatch_state;
 my $semantic_input_identity = defined($semantic_observation_sink)
  ? LinkedSpec::RuntimeSemanticObservation::input_identity($input_ref)
  : undef;
 LinkedSpec::GeneratedSource::trace_role(
  role => 'generated_entry_selection',
  source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
  rule_label => $entry_rule,
  handler_family => $entry_family,
  selection_basis => $entry_selection->{basis},
  status => 'ok',
 );
 LinkedSpec::GeneratedSource::trace_role(
  role => 'generated_rule_enter',
  source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
  rule_label => $entry_rule,
  handler_family => $entry_family,
 );
 LinkedSpec::GeneratedSource::trace_role(
  role => 'generated_family_decision',
  source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
  rule_label => $entry_rule,
  handler_family => $entry_family,
 );
 my ($result, $execution_error);
 my $ok = eval {
  $result = &{$descr->{spec}{$entry_rule}}($descr, $input_ref);
  $result = LinkedSpec::StagedASTEnrichmentRuntime::complete_invocation(
   $staged_enrichment_state,
   $descr,
   $input_ref,
   $result,
  );
  1
 };
 $execution_error = $@;
 LinkedSpec::GeneratedSource::trace_role(
  role => 'generated_rule_exit',
  source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
  rule_label => $entry_rule,
  handler_family => $entry_family,
  status => $ok ? 'ok' : 'error',
 );
 die $execution_error
  if !$ok && (
   LinkedSpec::RuntimeDiagnosticOutput::is_marked_control_error(
    $descr,
    $execution_error,
   )
   || LinkedSpec::RuntimeSemanticObservation::is_marked_control_error(
    $descr,
    $execution_error,
   )
  );
 die $execution_error
  if !$ok && (
   LinkedSpec::RecognitionTransactionRuntime::is_error($execution_error)
   || LinkedSpec::RecognitionTransactionRuntime::is_recursive_observation_error($execution_error)
   || LinkedSpec::InterMatchGapRuntime::is_error($execution_error)
   || LinkedSpec::ProgressiveSpanDispatchRuntime::is_error($execution_error)
   || LinkedSpec::StagedASTEnrichmentRuntime::is_error($execution_error)
  );
 die LinkedSpec::GeneratedSource::new_error(
  stage => 'execute_generated',
  code => 'generated_execution_failed',
  summary => 'Generated parser execution failed',
  source_identity => $LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
  rule_label => $entry_rule,
  handler_family => $entry_family,
  detail => $execution_error,
 ) unless $ok;
 LinkedSpec::RuntimeSemanticObservation::emit_rule_result(
  $descr,
  rule_label => $entry_rule,
  position => pos($$input_ref),
  input_identity => $semantic_input_identity,
 );
 return $result
}

sub ExecuteWithTrace {
 my ($input_ref, $trace_config, $invocation_options) = @_;
 require LinkedSpec::Trace;
 LinkedSpec::Trace::configure_trace(%$trace_config) if ref($trace_config) eq 'HASH';
 return Execute($input_ref, $invocation_options)
}

sub Get { return Execute(@_) }
