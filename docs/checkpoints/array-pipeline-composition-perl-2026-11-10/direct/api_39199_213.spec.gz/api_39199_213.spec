Value:: I {order="";out={order=cat(order,"S");["head:tail"]}.trim_each({order=cat(order,"A");0}).set_key({order=cat(order,"K");"k"},1).with(){order=cat(order,"W");return("ran")};return([out,order])}
