Value:: I {order="";return(split_each({items="bad";items+=1;["head:tail"]},":").set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).coalesce("masked"))}
