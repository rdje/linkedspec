Value:: I {order="";out=filter_nonempty([""]).with(){order=cat(order,"W");return(value.count())};return([out,order])}
