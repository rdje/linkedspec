Value:: I {order="";out=3.split_each(":").with(){order=cat(order,"W");return(value.count())};return([out,order])}
