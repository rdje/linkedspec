Value:: I {return({"k":1}.uppercase_each())}
