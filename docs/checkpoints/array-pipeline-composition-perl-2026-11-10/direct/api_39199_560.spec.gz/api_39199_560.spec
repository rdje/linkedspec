Value:: I {order="";return(filter_match(["head"],/(/).set_key({order=cat(order,"K");"k"},1).coalesce("masked"))}
