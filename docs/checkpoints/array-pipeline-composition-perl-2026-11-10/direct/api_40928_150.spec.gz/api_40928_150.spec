Value:: I {order="";out=take({order=cat(order,"S");["head","tail"]},1).last().uppercase();return([out,order])}
