Value:: I {delimiter=":";return(["head:tail"].split_each(delimiter))}
