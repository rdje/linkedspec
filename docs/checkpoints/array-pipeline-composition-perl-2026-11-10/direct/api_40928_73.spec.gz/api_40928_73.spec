Value:: I {order="";out=slice(["head","tail"],1,1).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
