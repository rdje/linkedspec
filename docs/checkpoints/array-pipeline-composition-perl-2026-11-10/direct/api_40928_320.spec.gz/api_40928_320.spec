Value:: I {source=["head","tail","end"];return(drop_front(source))}
