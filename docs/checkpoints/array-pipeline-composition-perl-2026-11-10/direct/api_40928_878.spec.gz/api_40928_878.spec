Value:: I {return(3.drop_front(1).with(){return(value)})}
