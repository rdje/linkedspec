Value:: I {order="";out=drop_front(["head","tail"],1).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
