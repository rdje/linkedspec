Value:: I {order="";source=["head","tail"];out=source.sorted({order=cat(order,"E");2});return([out,order])}
