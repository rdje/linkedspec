Value:: I {order="";out=undef.trim_each().with(){order=cat(order,"W");return(value.count())};return([out,order])}
