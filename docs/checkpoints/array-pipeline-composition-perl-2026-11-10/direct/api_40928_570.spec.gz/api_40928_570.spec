Value:: I {order="";out=copy(["tail"]).set_key({order=cat(order,"K");"k"},1);return([out,order])}
