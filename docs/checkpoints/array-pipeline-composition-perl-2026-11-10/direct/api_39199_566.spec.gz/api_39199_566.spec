Value:: I {order="";return(["head"].filter_match(/(/).set_key({order=cat(order,"K");"k"},1).coalesce("masked"))}
