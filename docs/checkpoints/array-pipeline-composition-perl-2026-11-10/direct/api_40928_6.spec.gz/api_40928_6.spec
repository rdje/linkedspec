Value:: I {return([take(["head","tail"],1),["head","tail"].take(1)])}
