Value:: I {order="";out=["head","tail"].drop_back(1).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
