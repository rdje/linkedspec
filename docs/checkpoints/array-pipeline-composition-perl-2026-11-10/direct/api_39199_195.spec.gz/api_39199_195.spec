Value:: I {return({"k":1}.trim_each())}
