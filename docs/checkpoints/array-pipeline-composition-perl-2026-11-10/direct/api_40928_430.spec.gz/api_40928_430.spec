Value:: I {source=["head","tail","end"];return(source.slice(1))}
