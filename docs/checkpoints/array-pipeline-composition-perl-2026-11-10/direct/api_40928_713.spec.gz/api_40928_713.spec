Value:: I {source=undef;return(source.slice(1,1).with(){return(value)})}
