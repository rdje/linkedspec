Value:: I {return(drop_back().with(){return(value)})}
