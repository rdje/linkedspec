Value:: I {return(split_each(["head:tail"],{items="bad";items+=1;":"}).set_key({order=cat(order,"K");"k"},1).coalesce("masked"))}
