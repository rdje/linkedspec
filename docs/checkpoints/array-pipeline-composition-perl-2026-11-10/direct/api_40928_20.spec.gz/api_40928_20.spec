Value:: I {return([take_last(["head","tail"],1),["head","tail"].take_last(1)])}
