Value:: I {return(split_each({items="bad";items+=1;["head:tail"]},":").set_key({order=cat(order,"K");"k"},1).coalesce("masked"))}
