Value:: I {order="";out=undef.uniq().with(){order=cat(order,"W");return(value.count())};return([out,order])}
