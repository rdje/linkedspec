Value:: I {source=undef;return(drop_back(source,1))}
