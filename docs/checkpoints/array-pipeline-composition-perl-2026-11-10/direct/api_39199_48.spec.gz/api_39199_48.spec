Value:: I {items=[2,"2","x"];out=uniq(items);indexed=["zero","one","two"];indexed[first(out)]="selected";return([out,items,indexed])}
