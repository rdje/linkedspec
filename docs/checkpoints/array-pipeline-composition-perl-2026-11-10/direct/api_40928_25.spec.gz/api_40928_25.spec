Value:: I {order="";out=take_last(["head","tail"],1).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
