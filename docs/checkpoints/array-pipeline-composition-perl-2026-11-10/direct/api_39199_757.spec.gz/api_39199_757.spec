Value:: I {return(uppercase_each({3}))}
