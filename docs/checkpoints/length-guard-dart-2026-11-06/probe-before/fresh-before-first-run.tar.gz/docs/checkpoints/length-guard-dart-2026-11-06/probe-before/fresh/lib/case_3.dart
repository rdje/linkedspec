// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "length-source/zero_null_with.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJsZW5ndGgtc291cmNlL3plcm9fbnVsbF93aXRoLnNwZWMiLCJmdW5jdGlvbnMiOltdLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge3JldHVybihbbGVuZ3RoKFwiXCIpLmNvYWxlc2NlKDcpLmFkZCgxKSxsZW5ndGgodW5kZWYpLndpdGgoKXtyZXR1cm4oXCJyZWNvdmVyZWRcIil9LGxlbmd0aChcIlwiKS53aXRoKCl7cmV0dXJuKHZhbHVlLmFkZCgxKSl9XSl9IiwibGluZSI6MX0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6InJldHVybihbbGVuZ3RoKFwiXCIpLmNvYWxlc2NlKDcpLmFkZCgxKSxsZW5ndGgodW5kZWYpLndpdGgoKXtyZXR1cm4oXCJyZWNvdmVyZWRcIil9LGxlbmd0aChcIlwiKS53aXRoKCl7cmV0dXJuKHZhbHVlLmFkZCgxKSl9XSkifSwic291cmNlIjoiSSB7cmV0dXJuKFtsZW5ndGgoXCJcIikuY29hbGVzY2UoNykuYWRkKDEpLGxlbmd0aCh1bmRlZikud2l0aCgpe3JldHVybihcInJlY292ZXJlZFwiKX0sbGVuZ3RoKFwiXCIpLndpdGgoKXtyZXR1cm4odmFsdWUuYWRkKDEpKX1dKX0iLCJsaW5lIjoxfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
