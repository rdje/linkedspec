local action_call_names = require("linkedspec.action_call_names")
local ast = require("linkedspec.spec_ast")
local json = require("linkedspec.json")
local trace = require("linkedspec.trace")
local trace_support = require("linkedspec.trace_support")
local unicode_rule_label = require("linkedspec.unicode_rule_label")

local is_rule_label = unicode_rule_label.is_rule_label

local M = {}

local VALIDATION_ERROR_MT = {
  __tostring = function(value)
    return "SpecValidationException: " .. value.message
  end,
}

local RESERVED_RUNTIME_SYMBOLS = {
  STRING = true,
  descr = true,
  minfo = true,
  LSPOS = true,
  LEPOS = true,
  LMATCH = true,
  LSMATCH = true,
  IMATCH = true,
  IMATCH_LIST = true,
  LMATCH_LIST = true,
  IMATCH_HASH = true,
  LMATCH_HASH = true,
  SELF = true,
  this = true,
  ctx = true,
  runtime_ctx = true,
}

local LIFECYCLE_NAMES = {
  I = true,
  LS = true,
  LE = true,
  E = true,
  EX = true,
  IT = true,
  LX = true,
}

local function validation_fail(message, code, stage, fields)
  error(setmetatable({
    message = message,
    code = code,
    stage = stage,
    fields = fields or json.harray(),
  }, VALIDATION_ERROR_MT), 0)
end

function M.is_validation_error(value)
  return getmetatable(value) == VALIDATION_ERROR_MT
end

function M.validation_error_to_json(value)
  if not M.is_validation_error(value) then
    validation_fail("validation_error_to_json expects SpecValidationException")
  end
  local result = json.harray({ message = value.message, fields = value.fields or json.harray() })
  if value.code ~= nil then result.code = value.code end
  if value.stage ~= nil then result.stage = value.stage end
  return result
end

function M.regex_slot_identity_invalid(rule_label, target_rule, regex_index, message)
  local detail = message or
    ("rule '" .. rule_label .. "' references rule '" .. target_rule .. "' regex slot " .. regex_index ..
      ", but that structural slot does not exist")
  validation_fail(
    detail,
    "regex_slot_identity_invalid",
    "validate_compiled_rule",
    json.harray({
      rule_label = rule_label,
      target_rule = target_rule,
      regex_index = regex_index,
    })
  )
end

local function is_identifier(value)
  return type(value) == "string" and value:match("^[A-Za-z_][A-Za-z0-9_]*$") ~= nil
end

local function string_lists_equal(left, right)
  if #left ~= #right then return false end
  for index, value in ipairs(left) do
    if value ~= right[index] then return false end
  end
  return true
end

local function check_at_least_one_rule(spec)
  if #spec.rules == 0 then
    validation_fail("spec does not define any rules", "no_rules_defined", "validate_spec")
  end
end

local function require_rule_label(label, role, line, owner)
  if is_rule_label(label) then return end
  local fields = json.harray({ label = label, line = line, role = role })
  if owner ~= nil then fields.rule_label = owner end
  validation_fail(
    role .. " '" .. label .. "' is not a nonempty Unicode 17.0.0 XID_Continue rule label",
    "invalid_rule_label",
    "validate_rule_labels",
    fields
  )
end

local function check_rule_labels(spec)
  for _, rule in ipairs(spec.rules) do
    require_rule_label(rule.header.label, "declaration", rule.header.line)
    for _, element in ipairs(rule.body) do
      local kind = element.kind
      local node_type = ast.node_type(kind)
      if node_type == "ActionEdgeBodyElementKind" then
        for _, target in ipairs(kind.targets) do
          require_rule_label(target.label, "edge_target", element.line, rule.header.label)
        end
      elseif node_type == "BlindEdgeBodyElementKind" then
        require_rule_label(kind.target, "edge_target", element.line, rule.header.label)
      elseif node_type == "BareEdgeBodyElementKind" then
        for _, target in ipairs(kind.targets) do
          require_rule_label(target.label, "edge_target", element.line, rule.header.label)
        end
      end
    end
  end
end

local function check_duplicate_rule_labels(spec)
  local seen = {}
  for _, rule in ipairs(spec.rules) do
    local label = rule.header.label
    if seen[label] then
      validation_fail("duplicate rule label '" .. label .. "'")
    end
    seen[label] = true
  end
end

local function gap_fields(spec, rule, element, extra)
  local fields = json.harray({
    rule_label = rule.header.label,
    source_id = spec.source_id,
    line = element.line,
  })
  for key, value in pairs(extra or {}) do fields[key] = value end
  return fields
end

local function check_regex_slot_declarations(spec)
  for _, rule in ipairs(spec.rules) do
    local first_lines = {}
    for _, element in ipairs(rule.body) do
      local kind = element.kind
      if ast.node_type(kind) == "RegexBodyElementKind" and kind.slot_id ~= nil then
        local slot_id = kind.slot_id
        if not is_rule_label(slot_id) or slot_id:match("^%d+$") then
          validation_fail(
            "rule '" .. rule.header.label .. "' has invalid regex slot name '" .. slot_id .. "'",
            "regex_slot_name_invalid",
            "parse_declaration",
            gap_fields(spec, rule, element, { slot_name = slot_id })
          )
        elseif first_lines[slot_id] ~= nil then
          validation_fail(
            "rule '" .. rule.header.label .. "' duplicates regex slot name '" .. slot_id .. "'",
            "regex_slot_duplicate_name",
            "resolve_declaration",
            gap_fields(spec, rule, element, {
              slot_name = slot_id,
              first_line = first_lines[slot_id],
            })
          )
        end
        first_lines[slot_id] = first_lines[slot_id] or element.line
      end
    end
  end
end

local function rule_regex_slots(rule)
  local count = 0
  local names = {}
  for _, element in ipairs(rule.body) do
    if ast.node_type(element.kind) == "RegexBodyElementKind" then
      if element.kind.slot_id ~= nil then names[element.kind.slot_id] = count end
      count = count + 1
    end
  end
  return count, names
end

local function check_selector(spec, owner, element, target, rules_by_label)
  if target.selector_kind == "invalid" or
      (target.selector_kind == "named" and not is_rule_label(target.authored_selector)) then
    validation_fail(
      "rule '" .. owner.header.label .. "' has malformed selector for rule '" .. target.label .. "'",
      "regex_slot_selector_invalid",
      "parse_selector",
      gap_fields(spec, owner, element, {
        target_rule = target.label,
        authored_selector = target.authored_selector or "",
      })
    )
  end
  local target_rule = rules_by_label[target.label]
  if target_rule == nil then return end
  local slot_count, names = rule_regex_slots(target_rule)
  if target.selector_kind == "named" then
    local resolved_index = names[target.authored_selector]
    if resolved_index == nil then
      validation_fail(
        "rule '" .. owner.header.label .. "' references unknown regex slot '" ..
          target.authored_selector .. "' in rule '" .. target.label .. "'",
        "regex_slot_unknown_name",
        "resolve_selector",
        gap_fields(spec, owner, element, {
          target_rule = target.label,
          authored_selector = target.authored_selector,
        })
      )
    end
    target.index = resolved_index
  elseif target.selector_kind == "unindexed" then
    target.index = 0
  end
  if target.index < 0 or target.index >= slot_count then
    validation_fail(
      "rule '" .. owner.header.label .. "' references rule '" .. target.label ..
        "' regex slot " .. target.index .. ", but that rule has " .. slot_count .. " regex slot(s)",
      "regex_slot_index_out_of_range",
      "resolve_selector",
      gap_fields(spec, owner, element, {
        target_rule = target.label,
        regex_index = target.index,
        regex_count = slot_count,
      })
    )
  end
end

local function check_and_resolve_selectors(spec)
  local rules_by_label = {}
  for _, rule in ipairs(spec.rules) do rules_by_label[rule.header.label] = rule end
  for _, rule in ipairs(spec.rules) do
    for _, element in ipairs(rule.body) do
      local kind = element.kind
      local node_type = ast.node_type(kind)
      if node_type == "ActionEdgeBodyElementKind" then
        for _, target in ipairs(kind.targets) do
          check_selector(spec, rule, element, target, rules_by_label)
        end
      elseif node_type == "BareEdgeBodyElementKind" and not ast.rule_mode_is_and(rule.header.mode) then
        for _, target in ipairs(kind.targets) do
          check_selector(spec, rule, element, target, rules_by_label)
        end
      end
    end
  end
end

local CAPTURE_GAPS_ELIGIBLE_MODES = {
  Default = true,
  Or = true,
  OrPlus = true,
  OrBounded = true,
  Plus = true,
}

local function capture_execution_shape(mode_name)
  if mode_name == "Default" then return "default_scan_loop" end
  if mode_name == "Or" or mode_name == "OrPlus" or mode_name == "OrBounded" or
      mode_name == "Plus" then
    return "repeat_loop"
  end
  return "single_match"
end

local function capture_edge_ownership(rule)
  local has_action = false
  local has_blind = false
  local has_local_adjacency = false
  local last_regex_line = nil
  for _, element in ipairs(rule.body) do
    local node_type = ast.node_type(element.kind)
    if node_type == "RegexBodyElementKind" then
      last_regex_line = element.line
    elseif node_type == "ActionEdgeBodyElementKind" then
      has_action = true
      if last_regex_line == element.line then has_local_adjacency = true end
      last_regex_line = nil
    elseif node_type == "BlindEdgeBodyElementKind" then
      has_blind = true
      last_regex_line = nil
    elseif node_type == "BareEdgeBodyElementKind" then
      if ast.rule_mode_is_and(rule.header.mode) then
        has_blind = true
      else
        has_action = true
        if last_regex_line == element.line then has_local_adjacency = true end
      end
      last_regex_line = nil
    elseif node_type ~= "CaptureGapsDirectiveBodyElementKind" and
        node_type ~= "SplitMarkerBodyElementKind" then
      last_regex_line = nil
    end
  end
  if has_action and has_blind then return "mixed" end
  if has_local_adjacency then return "local_adjacency" end
  if has_action then return "action" end
  if has_blind then return "blind" end
  return "none"
end

local function check_capture_gaps_directives(spec)
  for _, rule in ipairs(spec.rules) do
    local first_directive = nil
    local legacy_marker = nil
    for _, element in ipairs(rule.body) do
      local node_type = ast.node_type(element.kind)
      if node_type == "CaptureGapsDirectiveBodyElementKind" then
        if first_directive ~= nil then
          validation_fail(
            "rule '" .. rule.header.label .. "' contains duplicate @capture_gaps directives",
            "capture_gaps_duplicate_directive",
            "parse_directive",
            gap_fields(spec, rule, element, { first_line = first_directive.line })
          )
        end
        first_directive = element
      elseif node_type == "SplitMarkerBodyElementKind" and
          element.kind.marker:match("^@[ \t]*mark") == nil then
        legacy_marker = legacy_marker or element
      end
    end
    if first_directive ~= nil then
      if legacy_marker ~= nil then
        validation_fail(
          "rule '" .. rule.header.label .. "' mixes @capture_gaps with legacy marker '" ..
            legacy_marker.kind.marker .. "'",
          "capture_gaps_legacy_marker_conflict",
          "validate_directive",
          gap_fields(spec, rule, first_directive, {
            marker = legacy_marker.kind.marker,
            marker_line = legacy_marker.line,
          })
        )
      end
      local mode_name = rule.header.mode.name
      local family = ast.rule_mode_is_and(rule.header.mode) and "and" or "or_default"
      local cursor_policy = family == "and" and "consume" or "seek"
      local edge_ownership = capture_edge_ownership(rule)
      local execution_shape = capture_execution_shape(mode_name)
      if not CAPTURE_GAPS_ELIGIBLE_MODES[mode_name] or edge_ownership ~= "action" then
        validation_fail(
          "rule '" .. rule.header.label .. "' is not eligible for @capture_gaps",
          "capture_gaps_rule_ineligible",
          "validate_directive",
          gap_fields(spec, rule, first_directive, {
            family = family,
            cursor_policy = cursor_policy,
            edge_ownership = edge_ownership,
            execution_shape = execution_shape,
          })
        )
      end
    end
  end
end

local function check_duplicate_function_names(spec)
  local seen = {}
  for _, definition in ipairs(spec.functions) do
    if seen[definition.name] then
      validation_fail("duplicate user function definition '" .. definition.name .. "'")
    end
    seen[definition.name] = true
  end
end

local function check_function_registry(spec)
  local rule_labels = {}
  for _, rule in ipairs(spec.rules) do
    rule_labels[rule.header.label] = true
  end

  for _, definition in ipairs(spec.functions) do
    local name = definition.name
    if not is_identifier(name) then
      validation_fail("invalid user function name '" .. name .. "'")
    elseif rule_labels[name] then
      validation_fail("user function '" .. name .. "' collides with rule label '" .. name .. "'")
    elseif RESERVED_RUNTIME_SYMBOLS[name] then
      validation_fail("user function '" .. name .. "' uses a reserved runtime symbol")
    elseif LIFECYCLE_NAMES[name] then
      validation_fail("user function '" .. name .. "' collides with lifecycle marker '" .. name .. "'")
    elseif name == "fn" or action_call_names.is_known(name) then
      validation_fail("user function '" .. name .. "' collides with built-in helper/control name '" .. name .. "'")
    end
    if definition.arity ~= #definition.params then
      validation_fail(
        "user function '" .. name .. "' arity " .. definition.arity ..
        " does not match parameter count " .. #definition.params
      )
    end

    local signature = definition.signature
    if signature ~= nil and (
        ast.node_type(signature) ~= "CallableSignature" or
        signature.kind ~= "callable_signature" or
        signature.version ~= 1 or
        not string_lists_equal(signature.positional_params, definition.params) or
        signature.min_arity ~= definition.arity or
        signature.min_arity ~= #signature.positional_params or
        signature.max_arity ~= nil
      ) then
      validation_fail(
        "user function '" .. name .. "' has an invalid variadic callable signature",
        "invalid_callable_signature"
      )
    end

    local parameter_kinds = definition.parameter_kinds
    if parameter_kinds ~= nil then
      local final_param = definition.params[#definition.params]
      if signature ~= nil or json.kind(parameter_kinds) ~= "harray" then
        validation_fail(
          "user function '" .. name .. "' has invalid final codeblock parameter metadata",
          "invalid_parameter_kinds"
        )
      end
      local count = 0
      for param, kind in pairs(parameter_kinds) do
        count = count + 1
        if param ~= final_param or kind ~= "codeblock" then
          validation_fail(
            "user function '" .. name .. "' has invalid final codeblock parameter metadata",
            "invalid_parameter_kinds"
          )
        end
      end
      if count ~= 1 then
        validation_fail(
          "user function '" .. name .. "' has invalid final codeblock parameter metadata",
          "invalid_parameter_kinds"
        )
      end
    end

    local seen_params = {}
    for _, param in ipairs(definition.params) do
      if not is_identifier(param) then
        validation_fail(
          "user function '" .. name .. "' has invalid parameter '" .. param .. "'",
          "invalid_parameter"
        )
      elseif seen_params[param] then
        validation_fail(
          "duplicate parameter '" .. param .. "' in function '" .. name .. "'",
          "duplicate_parameter"
        )
      elseif RESERVED_RUNTIME_SYMBOLS[param] or LIFECYCLE_NAMES[param] or param == "fn" or param == "return" then
        validation_fail(
          "user function '" .. name .. "' parameter '" .. param .. "' is reserved",
          "reserved_parameter"
        )
      end
      seen_params[param] = true
    end
    if signature ~= nil then
      local rest_param = signature.rest_param
      if not is_identifier(rest_param) then
        validation_fail(
          "user function '" .. name .. "' has invalid rest parameter '" .. tostring(rest_param) .. "'",
          "invalid_rest_parameter"
        )
      elseif seen_params[rest_param] then
        validation_fail(
          "duplicate parameter '" .. rest_param .. "' in function '" .. name .. "'",
          "duplicate_parameter"
        )
      elseif RESERVED_RUNTIME_SYMBOLS[rest_param] or LIFECYCLE_NAMES[rest_param] or
          rest_param == "fn" or rest_param == "return" then
        validation_fail(
          "user function '" .. name .. "' parameter '" .. rest_param .. "' is reserved",
          "reserved_parameter"
        )
      end
    end
  end
end

local function check_raw_body_lines(spec)
  for _, rule in ipairs(spec.rules) do
    for _, element in ipairs(rule.body) do
      if ast.node_type(element.kind) == "RawBodyElementKind" then
        validation_fail(
          "rule '" .. rule.header.label .. "': unrecognized body syntax at line " ..
          element.line .. ": " .. element.kind.text
        )
      end
    end
  end
end

local function brace_depth_delta(text)
  local depth = 0
  local quote = nil
  local escaped = false
  for position = 1, #text do
    local byte = text:byte(position)
    if quote then
      if escaped then
        escaped = false
      elseif byte == 0x5C then
        escaped = true
      elseif byte == quote then
        quote = nil
      end
    elseif byte == 0x27 or byte == 0x22 then
      quote = byte
    elseif byte == 0x7B then
      depth = depth + 1
    elseif byte == 0x7D then
      depth = depth - 1
    end
  end
  return depth
end

local function check_balanced_lifecycle_blocks(spec)
  for _, rule in ipairs(spec.rules) do
    local depth = 0
    for _, element in ipairs(rule.body) do
      local kind = element.kind
      if ast.node_type(kind) == "CodeBlockBodyElementKind" then
        local source = element.source:gsub("^%s+", "")
        local marker_remainder = ""
        if source:sub(1, #kind.lifecycle) == kind.lifecycle then
          marker_remainder = source:sub(#kind.lifecycle + 1):gsub("^%s+", "")
        end
        local authored_outer_block = source:sub(1, 1) == "{" or marker_remainder:sub(1, 1) == "{"
        depth = depth + brace_depth_delta(authored_outer_block and source or kind.code)
      end
    end
    if depth ~= 0 then
      validation_fail(
        "rule '" .. rule.header.label .. "' has unbalanced braces: " .. math.abs(depth) ..
          " unmatched " .. (depth > 0 and "open" or "close")
      )
    end
  end
end

local function target_labels(targets)
  local result = json.array()
  for index, target in ipairs(targets) do result[index] = target.label end
  return result
end

local function check_edge_structure(spec)
  local declared_labels = {}
  for _, rule in ipairs(spec.rules) do declared_labels[rule.header.label] = true end

  for _, rule in ipairs(spec.rules) do
    local rule_label = rule.header.label
    for _, element in ipairs(rule.body) do
      local kind = element.kind
      local node_type = ast.node_type(kind)
      if node_type == "BareEdgeBodyElementKind" then
        for _, target in ipairs(kind.targets) do
          if not declared_labels[target.label] then
            validation_fail(
              "bare edge in rule '" .. rule_label .. "' targets undefined rule '" .. target.label .. "'",
              "bare_edge_target_undefined",
              "normalize_edges",
              json.harray({ rule_label = rule_label, target = target.label })
            )
          end
        end
        if ast.rule_mode_is_and(rule.header.mode) then
          for _, target in ipairs(kind.targets) do
            if target.index ~= nil or target.selector_kind ~= "unindexed" then
              validation_fail(
                "indexed bare edge in AND rule '" .. rule_label .. "' requires explicit action ownership",
                "bare_edge_index_requires_action",
                "normalize_edges",
                json.harray({
                  rule_label = rule_label,
                  target = target.label,
                  regex_index = target.index,
                })
              )
            end
          end
          if #kind.targets > 1 then
            validation_fail(
              "grouped bare edge in AND rule '" .. rule_label .. "' requires explicit action ownership",
              "bare_edge_group_requires_action",
              "normalize_edges",
              json.harray({ rule_label = rule_label, targets = target_labels(kind.targets) })
            )
          end
        elseif #kind.targets > 1 and kind.code == nil then
          validation_fail(
            "rule '" .. rule_label .. "': grouped action-edge targets require a shared code block",
            "grouped_action_shared_block_required",
            "validate_rule",
            json.harray({ rule_label = rule_label, targets = target_labels(kind.targets) })
          )
        end
      elseif node_type == "ActionEdgeBodyElementKind" and #kind.targets > 1 and kind.code == nil then
        validation_fail(
          "rule '" .. rule_label .. "': grouped action-edge targets require a shared code block",
          "grouped_action_shared_block_required",
          "validate_rule",
          json.harray({ rule_label = rule_label, targets = target_labels(kind.targets) })
        )
      elseif node_type == "BlindEdgeBodyElementKind" and kind.index ~= nil then
        validation_fail(
          "blind-call target '" .. kind.target .. "' in rule '" .. rule_label ..
            "' cannot select a regex index",
          "blind_call_index_forbidden",
          "validate_rule",
          json.harray({
            rule_label = rule_label,
            target = kind.target,
            regex_index = kind.index,
          })
        )
      end
    end
  end
end

local function check_mixed_edges(spec)
  for _, rule in ipairs(spec.rules) do
    local has_action = false
    local has_blind = false
    for _, element in ipairs(rule.body) do
      local kind = ast.node_type(element.kind)
      if kind == "ActionEdgeBodyElementKind" then
        has_action = true
      elseif kind == "BlindEdgeBodyElementKind" then
        has_blind = true
      elseif kind == "BareEdgeBodyElementKind" then
        if ast.rule_mode_is_and(rule.header.mode) then
          has_blind = true
        else
          has_action = true
        end
      end
    end
    if has_action and has_blind then
      validation_fail(
        "rule '" .. rule.header.label .. "' mixes action and blind edge ownership",
        "mixed_edge_ownership",
        "validate_rule",
        json.harray({
          rule_label = rule.header.label,
          ownerships = json.array({ "action", "blind" }),
        })
      )
    end
  end
end

local function regex_count(rule)
  local count = 0
  for _, element in ipairs(rule.body) do
    if ast.node_type(element.kind) == "RegexBodyElementKind" then
      count = count + 1
    end
  end
  return count
end

local function check_target(owner, rules_by_label, target, index, structural_action)
  local target_rule = rules_by_label[target]
  if not target_rule then
    local message = "rule '" .. owner.header.label .. "' references undefined rule '" .. target .. "'"
    if structural_action then
      M.regex_slot_identity_invalid(
        owner.header.label,
        target,
        index,
        message .. " for regex slot " .. index .. "; that structural slot does not exist"
      )
    end
    validation_fail(message)
  end
  -- Blind edges call declarations; only action edges select regex slots.
  if not structural_action then return end
  local count = regex_count(target_rule)
  if index < 0 or index >= count then
    M.regex_slot_identity_invalid(owner.header.label, target, index)
  end
end

local function check_edge_targets(spec)
  local rules_by_label = {}
  for _, rule in ipairs(spec.rules) do
    rules_by_label[rule.header.label] = rule
  end
  for _, rule in ipairs(spec.rules) do
    for _, element in ipairs(rule.body) do
      local kind = element.kind
      local node_type = ast.node_type(kind)
      if node_type == "ActionEdgeBodyElementKind" then
        for _, target in ipairs(kind.targets) do
          check_target(rule, rules_by_label, target.label, target.index, true)
        end
      elseif node_type == "BlindEdgeBodyElementKind" then
        check_target(rule, rules_by_label, kind.target, 0)
      elseif node_type == "BareEdgeBodyElementKind" then
        for _, target in ipairs(kind.targets) do
          check_target(
            rule,
            rules_by_label,
            target.label,
            target.index or 0,
            not ast.rule_mode_is_and(rule.header.mode)
          )
        end
      end
    end
  end
end

local function regex_structural_problem(pattern)
  local escaped = false
  local in_class = false
  local paren_depth = 0
  for index = 1, #pattern do
    local byte = pattern:byte(index)
    if escaped then
      escaped = false
    elseif byte == 0x5C then
      escaped = true
    elseif in_class then
      if byte == 0x5D then
        in_class = false
      end
    elseif byte == 0x5B then
      in_class = true
    elseif byte == 0x28 then
      paren_depth = paren_depth + 1
    elseif byte == 0x29 then
      paren_depth = paren_depth - 1
      if paren_depth < 0 then
        return "unmatched closing parenthesis"
      end
    end
  end
  if escaped then
    return "dangling escape"
  elseif in_class then
    return "unclosed character class"
  elseif paren_depth ~= 0 then
    return "unbalanced parentheses"
  end
  return nil
end

local function check_regex_syntax(spec)
  for _, rule in ipairs(spec.rules) do
    for _, element in ipairs(rule.body) do
      local kind = element.kind
      if ast.node_type(kind) == "RegexBodyElementKind" then
        local problem = regex_structural_problem(kind.pattern)
        if problem then
          validation_fail(
            "rule '" .. rule.header.label .. "': invalid regex pattern '/" .. kind.pattern .. "/': " .. problem
          )
        end
      end
    end
  end
end

local function check_unused_rules(spec)
  local used = {}
  for _, rule in ipairs(spec.rules) do
    for _, element in ipairs(rule.body) do
      local kind = element.kind
      local node_type = ast.node_type(kind)
      if node_type == "ActionEdgeBodyElementKind" then
        for _, target in ipairs(kind.targets) do
          used[target.label] = true
        end
      elseif node_type == "BlindEdgeBodyElementKind" then
        used[kind.target] = true
      elseif node_type == "BareEdgeBodyElementKind" then
        for _, target in ipairs(kind.targets) do used[target.label] = true end
      end
    end
  end
  local unused = {}
  for _, rule in ipairs(spec.rules) do
    if not used[rule.header.label] then
      unused[#unused + 1] = rule.header.label
    end
  end
  if #unused > 0 then
    validation_fail("unused rule(s) in strict mode: " .. table.concat(unused, ", "))
  end
end

function M.validate_spec(spec, options)
  if ast.node_type(spec) ~= "SpecFile" then
    validation_fail("validate_spec expects a SpecFile node")
  end
  options = options or {}
  if type(options) ~= "table" then
    validation_fail("validation options must be a table")
  end
  if options.strict_syntax ~= nil and type(options.strict_syntax) ~= "boolean" then
    validation_fail("strict_syntax must be a boolean when present")
  end
  if options.trace ~= nil and not trace.is_trace_emitter(options.trace) then
    validation_fail("trace must be a LinkedSpecTraceEmitter")
  end
  return trace_support.run(
    options.trace,
    "lua_frontend:validate_spec",
    "rules=" .. #spec.rules .. " functions=" .. #spec.functions ..
      " strict=" .. (options.strict_syntax and "1" or "0"),
    function()
      check_at_least_one_rule(spec)
      check_rule_labels(spec)
      check_duplicate_rule_labels(spec)
      check_regex_slot_declarations(spec)
      check_duplicate_function_names(spec)
      check_function_registry(spec)
      check_raw_body_lines(spec)
      check_balanced_lifecycle_blocks(spec)
      check_and_resolve_selectors(spec)
      check_capture_gaps_directives(spec)
      check_edge_structure(spec)
      check_mixed_edges(spec)
      check_edge_targets(spec)
      check_regex_syntax(spec)
      if options.strict_syntax then check_unused_rules(spec) end
      trace_support.decision(
        options.trace,
        "lua_frontend:validate_spec:checks",
        true,
        "strict=" .. (options.strict_syntax and "1" or "0")
      )
    end,
    "ok"
  )
end

return M
