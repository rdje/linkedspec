-- TYPE-REFERENCE-BOOK.1.2.23.3.74.5 — installed-host Length guards.
assert(loadfile("lua/src/linkedspec/interpreter.lua"))
assert(loadfile("lua/test/run.lua"))
local l = require("linkedspec")
local json = l.json
local failures, checks = {}, 0
io.stdout:setvbuf("no")
io.stdout:write("HOST ", _VERSION, " ", jit and jit.version or "", "\n")
local function verify(valid, label)
  checks = checks + 1
  if not valid then failures[#failures + 1] = label end
end
local function fixture(name)
  local file = assert(io.open("tests/fixtures/" .. name, "rb"))
  local value = json.decode(file:read("*a")); file:close()
  return value
end
local function observe(identifier, source, input, output)
  local ok, prepared = pcall(function()
    local parsed = l.parse_spec_with_staged_user_function_definitions(source)
    local compiled = l.compile_spec(parsed)
    local restored = l.compile_spec(l.spec_ast.from_json("SpecFile", json.decode(json.encode(l.spec_ast.to_json(parsed)))))
    local emitted = l.emit_lua_source_v2(compiled, "length-source/" .. identifier .. ".spec")
    if output ~= nil and output ~= "" then
      local function persist(directory, extension, body)
        local file = assert(io.open(output .. "/" .. directory .. "/" .. identifier .. extension, "wb"))
        file:write(body); file:close()
      end
      persist("emitted", ".lua", emitted)
      persist("parsed", ".json", json.encode(l.spec_ast.to_json(parsed)))
      io.stdout:write("LENGTH_LUA_INPUT ", identifier, " ", json.encode(l.spec_ast.to_json(parsed)), "\n")
    end
    local parser = assert((loadstring or load)(emitted))()
    return {
      {"native", function() return l.runtime_execute(l.runtime_engine(compiled), input).value end},
      {"restored", function() return l.runtime_execute(l.runtime_engine(restored), input).value end},
      {"plan", function() return l.execute_generated_parser_v2(compiled, l.build_generated_rule_plan(compiled), input, "length-source/" .. identifier .. ".spec") end},
      {"fresh", function() return parser.execute(input) end},
    }
  end)
  if not ok then return json.harray({compile_error=tostring(prepared)}) end
  local result = json.harray({})
  for _, route in ipairs(prepared) do
    local success, value = pcall(route[2])
    result[route[1]] = success and json.harray({value=value}) or json.harray({error=tostring(value),runtime=l.is_runtime_interpreter_error(value),generated=l.is_generated_source_error(value),helper_name=type(value)=="table" and value.helper_name or nil,diagnostic_code=type(value)=="table" and value.diagnostic and value.diagnostic.code or nil,diagnostic_stage=type(value)=="table" and value.diagnostic and value.diagnostic.stage or nil,code=type(value)=="table" and value.code or nil,actual_arity=type(value)=="table" and value.actual_arity or nil,expected_arity=type(value)=="table" and value.expected_arity or nil})
  end
  return result
end
local domain = fixture("length_result_guard_lua_domain.json")
local errors = fixture("length_result_guard_lua_errors.json")
local cases = json.array({})
for _, name in ipairs({"length_result_guard_cases.json", "length_count_source_ownership_cases.json"}) do
  for _, row in ipairs(fixture(name)) do cases[#cases + 1] = row end
end
for _, row in ipairs(cases) do
  local actual = observe(row.id, row.source, row.input, os.getenv("LINKEDSPEC_LENGTH_CAPTURE"))
  io.stdout:write("LENGTH_GUARD_LUA ", row.id, " ", json.encode(actual), "\n")
  verify(actual.compile_error == nil, row.id .. " compiles")
  if row.expected_error then
    verify(json.encode(actual) == json.encode(errors[row.id]), row.id .. " frozen error fields")
    for _, route in ipairs({"native", "restored", "plan", "fresh"}) do
      local value = actual[route]
      verify(value ~= nil and value.error ~= nil and value.error:find(row.expected_error, 1, true) ~= nil,
        row.id .. " " .. route .. " needed source error")
    end
  else
    local expected = row.expected
    if expected == nil then
      assert(row.id == domain.id and row.source == domain.source, "missing authored Length expectation")
      expected = domain.expected
    end
    for _, route in ipairs({"native", "restored", "plan", "fresh"}) do
      local value = actual[route]
      verify(value ~= nil and value.error == nil and json.encode(value.value) == json.encode(expected),
        row.id .. " " .. route)
    end
  end
end
io.stdout:write("LENGTH_GUARD_LUA_SUMMARY ", checks, " checks ", #failures, " failures\n")
if #failures > 0 then error(table.concat(failures, "\n"), 0) end
