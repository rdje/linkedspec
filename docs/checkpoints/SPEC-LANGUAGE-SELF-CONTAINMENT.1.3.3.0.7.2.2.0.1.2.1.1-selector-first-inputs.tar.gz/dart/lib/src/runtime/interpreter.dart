import 'dart:math' as math;

import '../action/action_ast.dart';
import '../action/callable_contract.dart';
import '../action/action_contracts.dart';
import '../action/action_parser.dart';
import '../action/function_registry.dart';
import '../ast/spec_ast.dart';
import '../compiler/compiled_spec.dart';
import '../trace/trace.dart';
import '../validation/spec_validator.dart';
import 'bounded_child_parse_authority.dart';
import 'generated_plan.dart';
import 'matching.dart';
import 'recognition_transaction.dart';
import 'semantic_observation.dart';
import 'source_location.dart';
import 'staged_ast_enrichment.dart';
import 'staged_parse_job.dart';
import 'unicode_case_mapping.dart';

final _leadingBlankLine = RegExp(r'[ \t]*\n');
final _leadingCommentLine = RegExp(r'[ \t]*#[^\n]*(?:\n|$)');

final class RuntimeDiagnostic {
  const RuntimeDiagnostic({
    required this.type,
    required this.stage,
    required this.summary,
    required this.detail,
    this.code,
    this.helperName,
    this.actualArity,
    this.expectedArity,
    this.callableName,
    this.expected,
    this.got,
    this.valueKind,
    this.name,
    this.cycle,
    this.ownerStage,
    this.specName,
    this.specPath,
    this.topRule,
    this.entryRule,
    this.ruleLabel,
    this.handlerSourceLabel,
    this.targetRule,
    this.regexIndex,
    this.expectedRegexIndex,
    this.actualRegexIndex,
    this.operation,
    this.binding,
    this.method,
    this.attempt,
    this.expectedKinds,
    this.segmentIndex,
    this.path,
    this.actualKind,
    this.reason,
    this.expectedKind,
    this.arrayIndex,
    this.length,
    this.sourceSpan,
  });

  final String type;
  final String stage;
  final String? ownerStage;
  final String summary;
  final String detail;
  final String? code;
  final String? helperName;
  final int? actualArity;
  final String? expectedArity;
  final String? callableName;
  final String? expected;
  final int? got;
  final String? valueKind;
  final String? name;
  final List<String>? cycle;
  final String? specName;
  final String? specPath;
  final String? topRule;
  final String? entryRule;
  final String? ruleLabel;
  final String? handlerSourceLabel;
  final String? targetRule;
  final int? regexIndex;
  final int? expectedRegexIndex;
  final int? actualRegexIndex;
  final String? operation;
  final String? binding;
  final String? method;
  final String? attempt;
  final List<String>? expectedKinds;
  final int? segmentIndex;
  final List<Object?>? path;
  final String? actualKind;
  final String? reason;
  final String? expectedKind;
  final int? arrayIndex;
  final int? length;
  final Map<String, Object?>? sourceSpan;

  JsonObject toJson() => {
    'type': type,
    'stage': stage,
    if (ownerStage != null) 'owner_stage': ownerStage,
    'summary': summary,
    'detail': detail,
    if (code != null) 'code': code,
    if (helperName != null) 'helper_name': helperName,
    if (actualArity != null) 'actual_arity': actualArity,
    if (expectedArity != null) 'expected_arity': expectedArity,
    if (callableName != null) 'callable_name': callableName,
    if (expected != null) 'expected': expected,
    if (got != null) 'got': got,
    if (valueKind != null) 'value_kind': valueKind,
    if (name != null) 'name': name,
    if (cycle != null) 'cycle': cycle,
    if (specName != null) 'spec_name': specName,
    if (specPath != null) 'spec_path': specPath,
    if (topRule != null) 'top_rule': topRule,
    if (entryRule != null) 'entry_rule': entryRule,
    if (ruleLabel != null) 'rule_label': ruleLabel,
    if (handlerSourceLabel != null) 'handler_source_label': handlerSourceLabel,
    if (targetRule != null) 'target_rule': targetRule,
    if (regexIndex != null) 'regex_index': regexIndex,
    if (expectedRegexIndex != null) 'expected_regex_index': expectedRegexIndex,
    if (actualRegexIndex != null) 'actual_regex_index': actualRegexIndex,
    if (operation != null) 'operation': operation,
    if (binding != null) 'binding': binding,
    if (method != null) 'method': method,
    if (attempt != null) 'attempt': attempt,
    if (expectedKinds != null) 'expected_kinds': expectedKinds,
    if (segmentIndex != null) 'segment_index': segmentIndex,
    if (path != null) 'path': _copyValue(path),
    if (actualKind != null) 'actual_kind': actualKind,
    if (reason != null) 'reason': reason,
    if (expectedKind != null) 'expected_kind': expectedKind,
    if (arrayIndex != null) 'index': arrayIndex,
    if (length != null) 'length': length,
    if (sourceSpan != null) 'source_span': _copyValue(sourceSpan),
  };
}

final class RuntimeInterpreterException implements Exception {
  const RuntimeInterpreterException(this.message, {this.diagnostic});

  final String message;
  final RuntimeDiagnostic? diagnostic;

  RuntimeInterpreterException withDiagnostic(RuntimeDiagnostic diagnostic) {
    if (this.diagnostic != null) {
      return this;
    }
    return RuntimeInterpreterException(message, diagnostic: diagnostic);
  }

  JsonObject toJson() => {
    'message': message,
    if (diagnostic != null) 'diagnostic': diagnostic!.toJson(),
  };

  @override
  String toString() => 'RuntimeInterpreterException: $message';
}

final class RuntimeDiagnosticOutputEvent {
  const RuntimeDiagnosticOutputEvent({
    required this.helperName,
    required this.ruleLabel,
    required this.message,
  });

  final String helperName;
  final String ruleLabel;
  final String message;

  JsonObject toJson() => {
    'helper_name': helperName,
    'rule_label': ruleLabel,
    'message': message,
  };
}

typedef RuntimeDiagnosticOutputSink =
    void Function(RuntimeDiagnosticOutputEvent event);

final class RuntimeExitNow implements Exception {
  const RuntimeExitNow(this.status);

  final int status;

  @override
  String toString() => 'RuntimeExitNow($status)';
}

final class _RuntimeDiagnosticOutputSinkFailure implements Exception {
  const _RuntimeDiagnosticOutputSinkFailure(this.error, this.stackTrace);

  final Object error;
  final StackTrace stackTrace;
}

final class _RuntimeSemanticObservationSinkFailure implements Exception {
  const _RuntimeSemanticObservationSinkFailure(this.error, this.stackTrace);

  final Object error;
  final StackTrace stackTrace;
}

final class RuntimeLifecycleEvent {
  const RuntimeLifecycleEvent({
    required this.ruleLabel,
    required this.lifecycle,
    required this.line,
  });

  final String ruleLabel;
  final String lifecycle;
  final int line;

  JsonObject toJson() => {
    'rule_label': ruleLabel,
    'lifecycle': lifecycle,
    'line': line,
  };
}

final class RuntimeParseResult {
  const RuntimeParseResult({
    required this.matched,
    required this.value,
    required this.output,
    required this.cursorCodeUnit,
    required this.cursorCharOffset,
    required this.lifecycleEvents,
  });

  final bool matched;
  final Object? value;
  final List<Object?> output;
  final int cursorCodeUnit;
  final int cursorCharOffset;
  final List<RuntimeLifecycleEvent> lifecycleEvents;

  JsonObject toJson() => {
    'matched': matched,
    'value': value,
    'output': output,
    'cursor_code_unit': cursorCodeUnit,
    'cursor_char_offset': cursorCharOffset,
    'lifecycle_events': [for (final event in lifecycleEvents) event.toJson()],
  };
}

final class LinkedSpecRuntimeEngine {
  LinkedSpecRuntimeEngine(
    this.compiledSpec, {
    this.maxIterations = 10000,
    this.specName,
    this.specPath,
    this.boundedChildParseAuthority,
    this.stagedAstEnrichmentSeed,
  });

  final CompiledSpec compiledSpec;
  final int maxIterations;
  final String? specName;
  final String? specPath;
  final ProgressiveExecutionSeed? boundedChildParseAuthority;
  final StagedAstEnrichmentSeed? stagedAstEnrichmentSeed;
  final Map<int, ActionBlock> _userFunctionBodyCache = <int, ActionBlock>{};
  final Map<String, ActionBlock> _codeblockBodyCache = <String, ActionBlock>{};

  /// Returns a fresh detached catalog for all 92 source-boundary projections.
  JsonObject typedSourceProjectionRows() => sourceLocationProjectionRows();

  /// Returns a fresh detached catalog for all seven compatibility aliases.
  List<Object?> typedSourceCompatibilityAliases() =>
      sourceLocationCompatibilityAliases();

  RuntimeParseResult parse(
    String input, {
    String? topRule,
    LinkedSpecTraceEmitter? trace,
    RuntimeDiagnosticOutputSink? diagnosticOutputSink,
    RuntimeSemanticObservationSink? semanticObservationSink,
  }) {
    return _parse(
      input,
      topRule: topRule,
      trace: trace,
      diagnosticOutputSink: diagnosticOutputSink,
      semanticObservationSink: semanticObservationSink,
    );
  }

  /// Execute through a validated generated-family plan.
  ///
  /// Generated source adapters validate ordered labels and families before
  /// calling this method. Each rule entry then selects its structural executor
  /// from [generatedPlan] instead of re-classifying the compiled rule.
  RuntimeParseResult executeGeneratedWithPlan(
    String input,
    Map<String, GeneratedRuleFamily> generatedPlan,
    String sourceIdentity, {
    String? topRule,
    LinkedSpecTraceEmitter? trace,
    RuntimeDiagnosticOutputSink? diagnosticOutputSink,
    RuntimeSemanticObservationSink? semanticObservationSink,
  }) {
    return _parse(
      input,
      topRule: topRule,
      trace: trace,
      diagnosticOutputSink: diagnosticOutputSink,
      semanticObservationSink: semanticObservationSink,
      generatedPlan: Map.unmodifiable(generatedPlan),
      generatedSourceIdentity: sourceIdentity,
    );
  }

  RuntimeParseResult _parse(
    String input, {
    String? topRule,
    LinkedSpecTraceEmitter? trace,
    RuntimeDiagnosticOutputSink? diagnosticOutputSink,
    RuntimeSemanticObservationSink? semanticObservationSink,
    Map<String, GeneratedRuleFamily>? generatedPlan,
    String? generatedSourceIdentity,
  }) {
    try {
      validateCompiledRegexSlotIdentities(compiledSpec);
      validateNestedWriteSerializedState(compiledSpec);
      validateReceiverMutationSerializedState(compiledSpec);
    } on SpecValidationException catch (error) {
      final diagnostic = error.diagnostic;
      throw RuntimeInterpreterException(
        error.message,
        diagnostic: _diagnostic(
          stage: diagnostic?.stage ?? 'validate_compiled_rule',
          code: diagnostic?.code ?? 'regex_slot_identity_invalid',
          summary: 'Dart compiled regex-slot identity validation failed',
          detail: error.message,
          ruleLabel: diagnostic?.field('rule_label') as String?,
          targetRule: diagnostic?.field('target_rule') as String?,
          regexIndex: diagnostic?.field('regex_index') as int?,
        ),
      );
    } on CompiledSpecException catch (error) {
      final code =
          error.message.startsWith('nested_write_serialized_state_invalid:')
          ? 'nested_write_serialized_state_invalid'
          : error.message.startsWith(
              'receiver_mutation_serialized_state_invalid:',
            )
          ? 'receiver_mutation_serialized_state_invalid'
          : 'compiled_state_invalid';
      throw RuntimeInterpreterException(
        error.message,
        diagnostic: _diagnostic(
          stage: 'validate_compiled_rule',
          code: code,
          summary: 'Dart compiled-state validation failed',
          detail: error.message,
        ),
      );
    }
    final ResolvedEntryRule selection;
    try {
      selection = compiledSpec.resolveEntryRule(topRule);
    } on EntryRuleSelectionException catch (error) {
      trace?.traceDecision(
        'dart_runtime:entry_rule_selection',
        false,
        'requested=${error.entryRule ?? '<default>'} effective=<none> '
            'basis=<none> stage=${error.stage} code=${error.code}',
        LinkedSpecTraceLevel.low,
      );
      throw RuntimeInterpreterException(
        error.message,
        diagnostic: _diagnostic(
          stage: error.stage,
          code: error.code,
          summary: 'Dart runtime entry-rule selection failed',
          detail: error.message,
          topRule: error.entryRule,
          entryRule: error.entryRule,
          ruleLabel: error.entryRule,
        ),
      );
    }
    final label = selection.rule.label;
    trace?.traceDecision(
      'dart_runtime:entry_rule_selection',
      true,
      'requested=${topRule ?? '<default>'} effective=$label '
          'basis=${selection.basis.contractName}',
      LinkedSpecTraceLevel.low,
    );
    final context = _RuntimeExecutionContext(
      engine: this,
      input: input,
      maxIterations: maxIterations,
      topRule: label,
      trace: trace,
      diagnosticOutputSink: diagnosticOutputSink,
      semanticObservationSink: semanticObservationSink,
      generatedPlan: generatedPlan,
      generatedSourceIdentity: generatedSourceIdentity,
    );
    // Mirror Perl's public parser wrapper; direct descriptor handlers bypass
    // this leading trivia skip.
    context._setCursorCodeUnit(_publicParserStartCursor(input));
    final traceScope = trace?.enterScope(
      'dart_runtime:parse',
      'top_rule=$label',
      LinkedSpecTraceLevel.high,
    );
    try {
      final result = _executeRule(label, 0, context);
      Object? completedValue = result.value;
      final stagedExecution = context.stagedAstEnrichment;
      if (stagedExecution != null) {
        try {
          completedValue = stagedExecution
              .complete(
                completedValue,
                hasActiveRecognitionTransaction:
                    context.hasActiveRecognitionTransaction,
              )
              .ast;
        } on StagedAstEnrichmentException catch (error) {
          final diagnostic = error.toJson();
          throw RuntimeInterpreterException(
            error.toString(),
            diagnostic: _diagnostic(
              stage: diagnostic['phase']! as String,
              code: diagnostic['code']! as String,
              summary: 'Dart staged-AST enrichment failed',
              detail: error.toString(),
              ruleLabel: context.currentRuleLabel ?? label,
            ),
          );
        }
      }
      final parseResult = RuntimeParseResult(
        matched: result.matched,
        value: completedValue,
        output: List<Object?>.unmodifiable([_copyValue(completedValue)]),
        cursorCodeUnit: context.cursorCodeUnit,
        cursorCharOffset: codeUnitOffsetToCharOffset(
          input,
          context.cursorCodeUnit,
        ),
        lifecycleEvents: List<RuntimeLifecycleEvent>.unmodifiable(
          context.lifecycleEvents,
        ),
      );
      if (context.semanticObservationSink != null) {
        _emitSemanticObservation(
          context,
          RuntimeSemanticObservationEvent.ruleResult(
            ruleLabel: label,
            position: parseResult.cursorCharOffset,
            input: input,
          ),
        );
      }
      if (traceScope != null) {
        trace?.exitScope(
          traceScope,
          'matched=${parseResult.matched} cursor=${parseResult.cursorCodeUnit}',
        );
      }
      return parseResult;
    } on _RuntimeDiagnosticOutputSinkFailure catch (failure) {
      if (traceScope != null) {
        trace?.exitScope(traceScope, 'diagnostic_output_sink_error');
      }
      Error.throwWithStackTrace(failure.error, failure.stackTrace);
    } on _RuntimeSemanticObservationSinkFailure catch (failure) {
      if (traceScope != null) {
        trace?.exitScope(traceScope, 'semantic_observation_sink_error');
      }
      Error.throwWithStackTrace(failure.error, failure.stackTrace);
    } on RuntimeExitNow catch (exit) {
      if (traceScope != null) {
        trace?.exitScope(traceScope, 'exit_status=${exit.status}');
      }
      rethrow;
    } on RuntimeInterpreterException catch (error) {
      final wrapped = error.withDiagnostic(
        context.diagnostic(
          stage: 'runtime_execution',
          summary: 'Dart runtime interpreter failed',
          detail: error.message,
          ruleLabel: context.currentRuleLabel ?? label,
        ),
      );
      if (traceScope != null) {
        trace?.exitScope(traceScope, 'error=${wrapped.message}');
      }
      throw wrapped;
    }
  }

  RuntimeParseResult parseWithTrace(
    String input,
    LinkedSpecTraceConfig traceConfig, {
    String? topRule,
    RuntimeDiagnosticOutputSink? diagnosticOutputSink,
    RuntimeSemanticObservationSink? semanticObservationSink,
  }) {
    final trace = LinkedSpecTraceEmitter(traceConfig);
    return parse(
      input,
      topRule: topRule,
      trace: trace,
      diagnosticOutputSink: diagnosticOutputSink,
      semanticObservationSink: semanticObservationSink,
    );
  }

  RuntimeParseResult execute(
    String input, {
    String? topRule,
    LinkedSpecTraceEmitter? trace,
    RuntimeDiagnosticOutputSink? diagnosticOutputSink,
    RuntimeSemanticObservationSink? semanticObservationSink,
  }) {
    return parse(
      input,
      topRule: topRule,
      trace: trace,
      diagnosticOutputSink: diagnosticOutputSink,
      semanticObservationSink: semanticObservationSink,
    );
  }

  RuntimeParseResult executeWithTrace(
    String input,
    LinkedSpecTraceConfig traceConfig, {
    String? topRule,
    RuntimeDiagnosticOutputSink? diagnosticOutputSink,
    RuntimeSemanticObservationSink? semanticObservationSink,
  }) {
    return parseWithTrace(
      input,
      traceConfig,
      topRule: topRule,
      diagnosticOutputSink: diagnosticOutputSink,
      semanticObservationSink: semanticObservationSink,
    );
  }

  int _publicParserStartCursor(String input) {
    var cursor = 0;
    while (cursor < input.length) {
      final blank = _leadingBlankLine.matchAsPrefix(input, cursor);
      if (blank != null) {
        cursor = blank.end;
        continue;
      }
      final comment = _leadingCommentLine.matchAsPrefix(input, cursor);
      if (comment != null) {
        cursor = comment.end;
        continue;
      }
      break;
    }
    return cursor;
  }

  _RuleResult _executeRule(
    String label,
    int entryRegexIndex,
    _RuntimeExecutionContext context, {
    RecognitionGapEntrySlot? entrySlot,
  }) {
    final rule = compiledSpec.rule(label);
    if (rule == null) {
      throw RuntimeInterpreterException(
        "rule '$label' is not compiled",
        diagnostic: context.diagnostic(
          stage: 'rule_lookup',
          summary: 'Dart runtime rule lookup failed',
          detail: "rule '$label' is not compiled",
          ruleLabel: label,
        ),
      );
    }

    final generatedFamily = context.generatedPlan?[label];
    if (context.generatedPlan != null && generatedFamily == null) {
      throw RuntimeInterpreterException(
        "generated rule plan does not contain '$label'",
        diagnostic: context.diagnostic(
          stage: 'generated_rule_plan',
          summary: 'Dart generated rule plan lookup failed',
          detail: "generated rule plan does not contain '$label'",
          ruleLabel: label,
        ),
      );
    }
    final executionPolicy = _executionPolicyFor(rule, generatedFamily);

    final invocationEntryCodeUnit = context.cursorCodeUnit;
    final recursionKey = '$label:$entryRegexIndex:$invocationEntryCodeUnit';
    if (!context.activeRuleEntries.add(recursionKey)) {
      context.trace?.traceDecision(
        'dart_runtime:recursion_guard',
        true,
        'rule=$label entry_regex=$entryRegexIndex cursor=${context.cursorCodeUnit}',
        LinkedSpecTraceLevel.debug,
      );
      if (context.recursiveObservationExpects(label)) {
        throw context.rejectRecursiveObservation(
          label,
          invocationEntryCodeUnit,
        );
      }
      return _RuleResult(matched: false, value: null);
    }

    final savedRegisters = context.registers;
    context.registers = RuntimeMatchRegisters(
      input: context.input,
      cursorCodeUnit: context.cursorCodeUnit,
      entryMatch: savedRegisters.localMatch,
      captureStartCodeUnit:
          savedRegisters.localMatch?.codeUnitEnd ?? context.cursorCodeUnit,
    );
    context.enterRule(label);
    context.enterRuleLocalBindingScope();
    context.enterRecognitionInvocation(
      label,
      captureGaps: rule.captureGaps != null,
      entrySlot: entrySlot,
    );
    context.noteRecursiveObservationEntry(label, invocationEntryCodeUnit);
    final generatedIdentity = context.generatedSourceIdentity;
    if (generatedFamily != null && generatedIdentity != null) {
      context.trace?.emitEvent(
        LinkedSpecTraceEventKind.mark,
        'generated_rule_enter',
        'source_identity=$generatedIdentity rule=$label '
            'entry_regex_idx=$entryRegexIndex cursor=${context.cursorCodeUnit}',
        LinkedSpecTraceLevel.low,
      );
      context.trace?.emitEvent(
        LinkedSpecTraceEventKind.mark,
        'generated_family_decision',
        'source_identity=$generatedIdentity rule=$label '
            'family=${generatedFamily.wireName}',
        LinkedSpecTraceLevel.low,
      );
    }
    final traceScope = context.trace?.enterScope(
      'dart_runtime:rule',
      'label=$label entry_regex=$entryRegexIndex '
          'mode=${rule.modeMetadata.name} '
          'cursor_policy=${executionPolicy.cursorPolicy.name} '
          'cursor=${context.cursorCodeUnit}',
      LinkedSpecTraceLevel.high,
    );
    var traceExitDetails = 'matched=false cursor=${context.cursorCodeUnit}';
    _RuleResult? terminalResult;
    Object? terminalError;

    try {
      final initReturn = _executeLifecycle(rule, 'I', context);
      if (initReturn != null) {
        final result = _returned(initReturn.value);
        terminalResult = result;
        traceExitDetails =
            'matched=${result.matched} cursor=${context.cursorCodeUnit}';
        return result;
      }

      try {
        final usesBlindDispatch =
            generatedFamily?.usesBlindDispatch ?? rule.blindEdges.isNotEmpty;
        final result = usesBlindDispatch
            ? _executeBlindRule(
                rule,
                context,
                usesAndExecution: executionPolicy.usesAndExecution,
              )
            : _executeRegexRule(
                rule,
                entryRegexIndex,
                context,
                cursorPolicy: executionPolicy.cursorPolicy,
                usesAndExecution: executionPolicy.usesAndExecution,
              );
        terminalResult = result;
        traceExitDetails =
            'matched=${result.matched} cursor=${context.cursorCodeUnit}';
        return result;
      } on _ActionReturn catch (returnSignal) {
        final result = _returned(returnSignal.value);
        terminalResult = result;
        traceExitDetails =
            'matched=${result.matched} cursor=${context.cursorCodeUnit}';
        return result;
      }
    } on RuntimeInterpreterException catch (error) {
      final enriched = error.withDiagnostic(
        context.diagnostic(
          stage: 'runtime_execution',
          summary: 'Dart runtime interpreter failed',
          detail: error.message,
          ruleLabel: label,
        ),
      );
      terminalError = enriched;
      traceExitDetails =
          'error=${enriched.message} cursor=${context.cursorCodeUnit}';
      throw enriched;
    } on Object catch (error) {
      terminalError = error;
      traceExitDetails = 'error=$error cursor=${context.cursorCodeUnit}';
      rethrow;
    } finally {
      if (traceScope != null) {
        context.trace?.exitScope(traceScope, traceExitDetails);
      }
      if (generatedFamily != null && generatedIdentity != null) {
        context.trace?.emitEvent(
          LinkedSpecTraceEventKind.mark,
          'generated_rule_exit',
          'source_identity=$generatedIdentity rule=$label '
              'family=${generatedFamily.wireName} $traceExitDetails',
          LinkedSpecTraceLevel.low,
        );
      }
      try {
        context.leaveRecognitionInvocation(
          label,
          result: terminalResult,
          error: terminalError,
        );
      } finally {
        context.exitRuleLocalBindingScope();
        context.exitRule();
        context.registers = savedRegisters;
        context.activeRuleEntries.remove(recursionKey);
      }
    }
  }

  _RuleExecutionPolicy _executionPolicyFor(
    CompiledRule rule,
    GeneratedRuleFamily? generatedFamily,
  ) {
    if (generatedFamily != null) {
      return _RuleExecutionPolicy(
        cursorPolicy: generatedFamily.cursorPolicy,
        usesAndExecution: generatedFamily.usesAndExecution,
      );
    }
    return _RuleExecutionPolicy(
      cursorPolicy: rule.modeMetadata.isAnd
          ? LinkedSpecParseMode.consume
          : LinkedSpecParseMode.seek,
      usesAndExecution: rule.modeMetadata.isAnd,
    );
  }

  RuntimeDiagnostic _diagnostic({
    required String stage,
    required String summary,
    required String detail,
    String? code,
    String? helperName,
    int? actualArity,
    String? expectedArity,
    String? callableName,
    String? expected,
    int? got,
    String? valueKind,
    String? name,
    List<String>? cycle,
    String? topRule,
    String? entryRule,
    String? ruleLabel,
    String? handlerSourceLabel,
    String? targetRule,
    int? regexIndex,
    int? expectedRegexIndex,
    int? actualRegexIndex,
    String? operation,
    String? binding,
    String? method,
    String? attempt,
    List<String>? expectedKinds,
    int? segmentIndex,
    List<Object?>? path,
    String? actualKind,
    String? reason,
    String? expectedKind,
    int? arrayIndex,
    int? length,
    Map<String, Object?>? sourceSpan,
  }) {
    final effectiveRule = ruleLabel ?? topRule;
    return RuntimeDiagnostic(
      type: 'runtime_parser',
      stage: stage,
      ownerStage: 'dart_runtime',
      summary: summary,
      detail: detail,
      code: code,
      helperName: helperName,
      actualArity: actualArity,
      expectedArity: expectedArity,
      callableName: callableName,
      expected: expected,
      got: got,
      valueKind: valueKind,
      name: name,
      cycle: cycle,
      specName: specName,
      specPath: specPath,
      topRule: topRule,
      entryRule: entryRule,
      ruleLabel: ruleLabel,
      handlerSourceLabel:
          handlerSourceLabel ??
          (effectiveRule == null
              ? 'dart_runtime'
              : 'dart_runtime:rule:$effectiveRule'),
      targetRule: targetRule,
      regexIndex: regexIndex,
      expectedRegexIndex: expectedRegexIndex,
      actualRegexIndex: actualRegexIndex,
      operation: operation,
      binding: binding,
      method: method,
      attempt: attempt,
      expectedKinds: expectedKinds,
      segmentIndex: segmentIndex,
      path: path,
      actualKind: actualKind,
      reason: reason,
      expectedKind: expectedKind,
      arrayIndex: arrayIndex,
      length: length,
      sourceSpan: sourceSpan,
    );
  }

  _RuleResult _executeBlindRule(
    CompiledRule rule,
    _RuntimeExecutionContext context, {
    required bool usesAndExecution,
  }) {
    final min = rule.modeMetadata.repMin;
    if (min == null) {
      final implicitAndResult = <Object?>[];
      var matchedAny = false;
      for (
        var iteration = 0;
        iteration < context.maxIterations;
        iteration += 1
      ) {
        final before = context.cursorCodeUnit;
        final matched = _nextableBool(
          () => _executeBlindOnce(
            rule,
            context,
            usesAndExecution: usesAndExecution,
            implicitAndResult: implicitAndResult,
          ),
        );
        if (matched.nexted) {
          matchedAny = true;
          if (context.cursorCodeUnit == before) {
            break;
          }
          continue;
        }
        if (!matched.value) {
          final loopExit = _executeLifecycle(rule, 'LX', context);
          if (loopExit != null) {
            return _returned(loopExit.value);
          }
        }
        final exitReturn = _executeLifecycle(rule, 'E', context);
        if (exitReturn != null) {
          return _returned(exitReturn.value);
        }
        return _RuleResult(
          matched: matched.value || matchedAny,
          value: usesAndExecution && implicitAndResult.isNotEmpty
              ? List<Object?>.unmodifiable(implicitAndResult)
              : null,
        );
      }
      final loopExit = _executeLifecycle(rule, 'LX', context);
      if (loopExit != null) {
        return _returned(loopExit.value);
      }
      final exitReturn = _executeLifecycle(rule, 'E', context);
      if (exitReturn != null) {
        return _returned(exitReturn.value);
      }
      return _RuleResult(
        matched: matchedAny,
        value: usesAndExecution && implicitAndResult.isNotEmpty
            ? List<Object?>.unmodifiable(implicitAndResult)
            : null,
      );
    }

    var matches = 0;
    var madeFailedAttempt = false;
    for (var iteration = 0; iteration < context.maxIterations; iteration += 1) {
      final max = rule.modeMetadata.repMax;
      if (max != null && matches >= max) {
        break;
      }
      final before = context.cursorCodeUnit;
      final loopStart = _executeLifecycle(rule, 'LS', context);
      if (loopStart != null) {
        return _returned(loopStart.value);
      }

      final matched = _nextableBool(
        () => _executeBlindOnce(
          rule,
          context,
          usesAndExecution: usesAndExecution,
        ),
      );
      if (matched.nexted) {
        matches += 1;
        if (context.cursorCodeUnit == before) {
          break;
        }
        continue;
      }
      if (!matched.value) {
        madeFailedAttempt = true;
        break;
      }

      matches += 1;
      final loopEnd = _executeLifecycle(rule, 'LE', context);
      if (loopEnd != null) {
        return _returned(loopEnd.value);
      }
      final iterationReturn = _executeLifecycle(rule, 'IT', context);
      if (iterationReturn != null) {
        return _returned(iterationReturn.value);
      }
      if (context.cursorCodeUnit == before) {
        break;
      }
    }

    if (matches < min) {
      final loopExit = _executeLifecycle(rule, 'LX', context);
      if (loopExit != null) {
        return _returned(loopExit.value);
      }
      throw RuntimeInterpreterException(
        "rule '${rule.label}' expected at least $min matches, got $matches",
      );
    }

    final extendedExit = _executeLifecycle(rule, 'EX', context);
    if (extendedExit != null) {
      return _returned(extendedExit.value);
    }
    if (madeFailedAttempt || matches > 0) {
      final loopExit = _executeLifecycle(rule, 'LX', context);
      if (loopExit != null) {
        return _returned(loopExit.value);
      }
    }
    final exitReturn = _executeLifecycle(rule, 'E', context);
    if (exitReturn != null) {
      return _returned(exitReturn.value);
    }
    return _RuleResult(matched: matches > 0, value: null);
  }

  bool _executeBlindOnce(
    CompiledRule rule,
    _RuntimeExecutionContext context, {
    required bool usesAndExecution,
    List<Object?>? implicitAndResult,
  }) {
    if (usesAndExecution) {
      var matchedAll = true;
      for (
        var edgeIndex = 0;
        edgeIndex < rule.blindEdges.length;
        edgeIndex += 1
      ) {
        final edge = rule.blindEdges[edgeIndex];
        final before = context.cursorCodeUnit;
        final child = _executeRule(
          edge.target.label,
          edge.target.index,
          context,
        );
        final childMatched = child.matched;
        context.trace?.traceDecision(
          'dart_runtime:child_dispatch',
          childMatched,
          'edge_family=blind mode=AND rule=${rule.label} index=$edgeIndex '
              'target=${edge.target.label}[${edge.target.index}] '
              'cursor_before=$before cursor_after=${context.cursorCodeUnit}',
          LinkedSpecTraceLevel.debug,
        );
        context.retv = child.value;
        if (childMatched) {
          implicitAndResult?.add(_copyValue(child.value));
        }
        final edgeReturn = _executeOptionalPayload(
          edge.actionPayload,
          context,
          rule.label,
          currentEdge: null,
        );
        if (edgeReturn != null) {
          throw _ActionReturn(edgeReturn.value);
        }
        if (!childMatched) {
          matchedAll = false;
          break;
        }
      }
      return matchedAll;
    }

    for (
      var edgeIndex = 0;
      edgeIndex < rule.blindEdges.length;
      edgeIndex += 1
    ) {
      final edge = rule.blindEdges[edgeIndex];
      final before = context.cursorCodeUnit;
      final child = _executeRule(edge.target.label, edge.target.index, context);
      final childMatched = child.matched;
      context.trace?.traceDecision(
        'dart_runtime:child_dispatch',
        childMatched,
        'edge_family=blind mode=OR rule=${rule.label} index=$edgeIndex '
            'target=${edge.target.label}[${edge.target.index}] '
            'cursor_before=$before cursor_after=${context.cursorCodeUnit}',
        LinkedSpecTraceLevel.debug,
      );
      context.retv = child.value;
      final edgeReturn = _executeOptionalPayload(
        edge.actionPayload,
        context,
        rule.label,
        currentEdge: null,
      );
      if (edgeReturn != null) {
        throw _ActionReturn(edgeReturn.value);
      }
      if (childMatched) {
        return true;
      }
    }
    return false;
  }

  _RuleResult _executeRegexRule(
    CompiledRule rule,
    int entryRegexIndex,
    _RuntimeExecutionContext context, {
    required LinkedSpecParseMode cursorPolicy,
    required bool usesAndExecution,
  }) {
    final min = rule.modeMetadata.repMin;
    final captureGaps = rule.captureGaps != null;
    if (min == null) {
      var matchedAny = false;
      for (
        var iteration = 0;
        iteration < context.maxIterations;
        iteration += 1
      ) {
        final before = context.cursorCodeUnit;
        final matched = _nextableBool(
          () => _executeRegexOnce(
            rule,
            context,
            entryRegexIndex: entryRegexIndex,
            cursorPolicy: cursorPolicy,
            andSequence: usesAndExecution && rule.regexPatterns.length > 1,
          ),
        );
        if (matched.nexted) {
          matchedAny = true;
          if (context.cursorCodeUnit == before) {
            break;
          }
          continue;
        }
        if (!matched.value) {
          final loopExit = _executeLifecycle(rule, 'LX', context);
          if (loopExit != null) {
            return _returned(loopExit.value);
          }
        }
        final exitReturn = _executeLifecycle(rule, 'E', context);
        if (exitReturn != null) {
          return _returned(exitReturn.value);
        }
        return _RuleResult(matched: matched.value || matchedAny, value: null);
      }
      final loopExit = _executeLifecycle(rule, 'LX', context);
      if (loopExit != null) {
        return _returned(loopExit.value);
      }
      final exitReturn = _executeLifecycle(rule, 'E', context);
      if (exitReturn != null) {
        return _returned(exitReturn.value);
      }
      return _RuleResult(matched: matchedAny, value: null);
    }

    final actionIterationValues = _collectsExplicitActionIterationValues(rule)
        ? <Object?>[]
        : null;
    var matches = 0;
    var madeFailedAttempt = false;
    for (var iteration = 0; iteration < context.maxIterations; iteration += 1) {
      final max = rule.modeMetadata.repMax;
      if (max != null && matches >= max) {
        break;
      }
      final before = context.cursorCodeUnit;
      RuntimeRegexMatch? selectedMatch;
      if (captureGaps) {
        selectedMatch = _selectRegexMatch(
          rule,
          context,
          entryRegexIndex: 0,
          cursorPolicy: cursorPolicy,
        );
        _traceRegexDecision(
          context,
          rule,
          matched: selectedMatch != null,
          cursorBefore: before,
          cursorPolicy: cursorPolicy,
          match: selectedMatch,
          reason: 'entry_regex=0 capture_gaps=1',
        );
        if (selectedMatch != null) {
          _prepareGapCandidate(rule, selectedMatch, context);
          context.setGapPhase(rule.label, 'LS');
          final loopStart = _executeLifecycle(rule, 'LS', context);
          if (loopStart != null) {
            return _returned(loopStart.value);
          }
        }
      } else {
        final loopStart = _executeLifecycle(rule, 'LS', context);
        if (loopStart != null) {
          return _returned(loopStart.value);
        }
      }

      final matched = _nextableBool(
        () => _executeRegexOnce(
          rule,
          context,
          cursorPolicy: cursorPolicy,
          andSequence: usesAndExecution && rule.regexPatterns.length > 1,
          actionIterationValues: actionIterationValues,
          matchPreselected: captureGaps,
          preselectedMatch: selectedMatch,
        ),
      );
      if (matched.nexted) {
        matches += 1;
        if (context.cursorCodeUnit == before) {
          break;
        }
        continue;
      }
      if (!matched.value) {
        madeFailedAttempt = true;
        break;
      }

      if (captureGaps) {
        _commitGapCandidate(rule, context);
      }
      matches += 1;
      context.setGapPhase(rule.label, 'IT');
      final iterationReturn = _executeLifecycle(rule, 'IT', context);
      if (iterationReturn != null) {
        return _returned(iterationReturn.value);
      }
      if (context.cursorCodeUnit == before) {
        break;
      }
    }

    if (matches < min) {
      context.setGapPhase(rule.label, 'LX');
      final loopExit = _executeLifecycle(rule, 'LX', context);
      if (loopExit != null) {
        return _returned(loopExit.value);
      }
      if (actionIterationValues != null) {
        return const _RuleResult(matched: false, value: null);
      }
      throw RuntimeInterpreterException(
        "rule '${rule.label}' expected at least $min matches, got $matches",
      );
    }

    if (captureGaps) {
      context.installGapTail(rule.label, 'EX');
    }
    context.setGapPhase(rule.label, 'EX');
    final extendedExit = _executeLifecycle(rule, 'EX', context);
    if (extendedExit != null) {
      return _returned(extendedExit.value);
    }
    if (madeFailedAttempt || matches > 0) {
      context.setGapPhase(rule.label, 'LX');
      final loopExit = _executeLifecycle(rule, 'LX', context);
      if (loopExit != null) {
        return _returned(loopExit.value);
      }
    }
    context.setGapPhase(rule.label, 'E');
    final exitReturn = _executeLifecycle(rule, 'E', context);
    if (exitReturn != null) {
      return _returned(exitReturn.value);
    }
    return _RuleResult(
      matched: matches > 0,
      value: actionIterationValues == null
          ? null
          : List<Object?>.unmodifiable(actionIterationValues),
    );
  }

  RuntimeRegexMatch? _selectRegexMatch(
    CompiledRule rule,
    _RuntimeExecutionContext context, {
    required int entryRegexIndex,
    required LinkedSpecParseMode cursorPolicy,
  }) {
    final plan = _regexPlanFor(rule);
    if (plan.patterns.isEmpty) {
      return null;
    }
    return entryRegexIndex > 0 && entryRegexIndex < plan.patterns.length
        ? _matchSpecific(plan, entryRegexIndex, context, cursorPolicy)
        : plan.matcher.match(
            context.input,
            context.cursorCodeUnit,
            parseMode: cursorPolicy,
          );
  }

  void _prepareGapCandidate(
    CompiledRule rule,
    RuntimeRegexMatch match,
    _RuntimeExecutionContext context,
  ) {
    _recordRegexSlotSelected(
      context,
      rule,
      match.alternativeIndex,
      positionCodeUnit: match.codeUnitEnd,
      selectionRole: 'choice',
    );
    context.registers = context.registers.withLocalMatch(match);
    context.noteRecognitionMatch(match);
    context.installGapCandidate(rule.label, match);
  }

  bool _executeRegexOnce(
    CompiledRule rule,
    _RuntimeExecutionContext context, {
    int entryRegexIndex = 0,
    required LinkedSpecParseMode cursorPolicy,
    bool andSequence = false,
    List<Object?>? actionIterationValues,
    bool matchPreselected = false,
    RuntimeRegexMatch? preselectedMatch,
  }) {
    final plan = _regexPlanFor(rule);
    final cursorBefore = context.cursorCodeUnit;
    if (!matchPreselected && plan.patterns.isEmpty) {
      _traceRegexDecision(
        context,
        rule,
        matched: false,
        cursorBefore: cursorBefore,
        cursorPolicy: cursorPolicy,
        reason: 'patterns=0',
      );
      return false;
    }

    if (!matchPreselected && andSequence) {
      for (
        var expectedIndex = 0;
        expectedIndex < plan.patterns.length;
        expectedIndex += 1
      ) {
        final match = _matchSpecific(
          plan,
          expectedIndex,
          context,
          cursorPolicy,
        );
        if (match == null) {
          _traceRegexDecision(
            context,
            rule,
            matched: false,
            cursorBefore: context.cursorCodeUnit,
            cursorPolicy: cursorPolicy,
            reason: 'mode=AND expected_index=$expectedIndex',
          );
          return false;
        }
        _traceRegexDecision(
          context,
          rule,
          matched: true,
          cursorBefore: context.cursorCodeUnit,
          cursorPolicy: cursorPolicy,
          match: match,
          reason: 'mode=AND expected_index=$expectedIndex',
        );
        _assertOrderedRegexMatchIdentity(
          context,
          rule,
          expectedIndex,
          match.alternativeIndex,
        );
        _recordRegexSlotSelected(
          context,
          rule,
          match.alternativeIndex,
          positionCodeUnit: match.codeUnitEnd,
          selectionRole: 'ordered_required',
        );
        context.setGapPhase(rule.label, 'edge');
        _acceptRegexMatch(
          rule,
          match,
          context,
          actionIterationValues: actionIterationValues,
        );
        context.setGapPhase(rule.label, 'LE');
        final loopEnd = _executeLifecycle(rule, 'LE', context);
        if (loopEnd != null) {
          throw _ActionReturn(loopEnd.value);
        }
      }
      return true;
    }

    final match = matchPreselected
        ? preselectedMatch
        : entryRegexIndex > 0 && entryRegexIndex < plan.patterns.length
        ? _matchSpecific(plan, entryRegexIndex, context, cursorPolicy)
        : plan.matcher.match(
            context.input,
            context.cursorCodeUnit,
            parseMode: cursorPolicy,
          );
    if (match == null) {
      if (!matchPreselected) {
        _traceRegexDecision(
          context,
          rule,
          matched: false,
          cursorBefore: cursorBefore,
          cursorPolicy: cursorPolicy,
          reason: 'entry_regex=$entryRegexIndex',
        );
      }
      return false;
    }

    if (!matchPreselected) {
      _traceRegexDecision(
        context,
        rule,
        matched: true,
        cursorBefore: cursorBefore,
        cursorPolicy: cursorPolicy,
        match: match,
        reason: 'entry_regex=$entryRegexIndex',
      );
      final selectionRole = entryRegexIndex > 0 ? 'ordered_required' : 'choice';
      if (selectionRole == 'ordered_required') {
        _assertOrderedRegexMatchIdentity(
          context,
          rule,
          entryRegexIndex,
          match.alternativeIndex,
        );
      }
      _recordRegexSlotSelected(
        context,
        rule,
        match.alternativeIndex,
        positionCodeUnit: match.codeUnitEnd,
        selectionRole: selectionRole,
      );
    }
    context.setGapPhase(rule.label, 'edge');
    _acceptRegexMatch(
      rule,
      match,
      context,
      actionIterationValues: actionIterationValues,
    );
    context.setGapPhase(rule.label, 'LE');
    final loopEnd = _executeLifecycle(rule, 'LE', context);
    if (loopEnd != null) {
      throw _ActionReturn(loopEnd.value);
    }
    return true;
  }

  void _traceRegexDecision(
    _RuntimeExecutionContext context,
    CompiledRule rule, {
    required bool matched,
    required int cursorBefore,
    required LinkedSpecParseMode cursorPolicy,
    required String reason,
    RuntimeRegexMatch? match,
  }) {
    context.trace?.traceDecision(
      'dart_runtime:regex_match',
      matched,
      'rule=${rule.label} $reason parse_mode=${cursorPolicy.name} '
          'alternative=${match?.alternativeIndex ?? -1} '
          'match_start=${match?.codeUnitStart ?? -1} '
          'match_end=${match?.codeUnitEnd ?? -1} '
          'cursor_before=$cursorBefore',
      LinkedSpecTraceLevel.debug,
    );
  }

  RuntimeRegexMatch? _matchSpecific(
    _RegexPlan plan,
    int expectedIndex,
    _RuntimeExecutionContext context,
    LinkedSpecParseMode cursorPolicy,
  ) {
    return plan.matcher.matchAlternative(
      expectedIndex,
      context.input,
      context.cursorCodeUnit,
      parseMode: cursorPolicy,
    );
  }

  void _assertOrderedRegexMatchIdentity(
    _RuntimeExecutionContext context,
    CompiledRule rule,
    int expectedIndex,
    int actualIndex,
  ) {
    final expected = compiledRegexSlotIdentitiesFor(rule, expectedIndex).first;
    final actual = compiledRegexSlotIdentitiesFor(rule, actualIndex).first;
    try {
      assertOrderedRegexSlotIdentity(
        ruleLabel: rule.label,
        expectedTargetRule: expected.targetRule,
        expectedRegexIndex: expected.regexIndex,
        actualTargetRule: actual.targetRule,
        actualRegexIndex: actual.regexIndex,
      );
    } on OrderedRegexSlotIdentityException catch (error) {
      throw RuntimeInterpreterException(
        error.toString(),
        diagnostic: context.diagnostic(
          stage: 'execute_rule',
          code: 'ordered_regex_slot_identity_lost',
          summary: 'Dart ordered regex-slot identity invariant failed',
          detail: error.toString(),
          ruleLabel: error.ruleLabel,
          targetRule: error.targetRule,
          expectedRegexIndex: error.expectedRegexIndex,
          actualRegexIndex: error.actualRegexIndex,
        ),
      );
    }
  }

  void _recordRegexSlotSelected(
    _RuntimeExecutionContext context,
    CompiledRule rule,
    int regexIndex, {
    required int positionCodeUnit,
    required String selectionRole,
  }) {
    for (final identity in compiledRegexSlotIdentitiesFor(rule, regexIndex)) {
      if (context.semanticObservationSink != null) {
        _emitSemanticObservation(
          context,
          RuntimeSemanticObservationEvent.regexSlotSelected(
            ruleLabel: rule.label,
            targetRule: identity.targetRule,
            regexIndex: identity.regexIndex,
            position: codeUnitOffsetToCharOffset(
              context.input,
              positionCodeUnit,
            ),
          ),
        );
      }
      context.trace?.emitEvent(
        LinkedSpecTraceEventKind.mark,
        'dart_runtime:regex_slot_selected',
        'rule_label=${rule.label} selection_role=$selectionRole '
            'target_rule=${identity.targetRule} '
            'regex_index=${identity.regexIndex}',
        LinkedSpecTraceLevel.high,
      );
    }
  }

  void _emitSemanticObservation(
    _RuntimeExecutionContext context,
    RuntimeSemanticObservationEvent event,
  ) {
    final sink = context.semanticObservationSink;
    if (sink == null) {
      return;
    }
    try {
      sink(event);
    } on Object catch (error, stackTrace) {
      throw _RuntimeSemanticObservationSinkFailure(error, stackTrace);
    }
  }

  Object? _readGapContextHelper(
    String helperName,
    _RuntimeExecutionContext context,
    String ruleLabel,
  ) {
    try {
      return switch (helperName) {
        'gap_span' => context.gapSpan(ruleLabel, helperName).toJson(),
        'gap_text' => context.gapText(ruleLabel, helperName),
        'gap_kind' => context.currentGap(ruleLabel, helperName).kind,
        _ => throw StateError('unknown private gap helper $helperName'),
      };
    } on InterMatchGapException catch (error) {
      throw RuntimeInterpreterException(
        error.toString(),
        diagnostic: context.diagnostic(
          stage: 'access_gap_context',
          summary: 'Dart inter-match gap context is unavailable',
          detail: error.toString(),
          code: 'gap_capture_context_unavailable',
          helperName: helperName,
          ruleLabel: ruleLabel,
        ),
      );
    }
  }

  void _commitGapCandidate(
    CompiledRule rule,
    _RuntimeExecutionContext context,
  ) {
    try {
      context.commitGapCandidate(rule.label);
    } on GapCursorRegressionException catch (error) {
      throw RuntimeInterpreterException(
        error.toString(),
        diagnostic: context.diagnostic(
          stage: 'advance_gap_context',
          summary: 'Dart inter-match gap cursor regressed before commit',
          detail: error.toString(),
          code: 'source_location_cursor_regression',
          ruleLabel: rule.label,
        ),
      );
    }
  }

  void _acceptRegexMatch(
    CompiledRule rule,
    RuntimeRegexMatch match,
    _RuntimeExecutionContext context, {
    List<Object?>? actionIterationValues,
  }) {
    context.cursorCodeUnit = match.codeUnitEnd;
    context.registers = context.registers.withLocalMatch(match);
    context.noteRecognitionMatch(match);

    final edgeMatches = _actionEdgesFor(rule, match.alternativeIndex);
    if (edgeMatches.isEmpty) {
      return;
    }

    for (final edgeMatch in edgeMatches) {
      final edgeContext = _CurrentActionEdge(
        ruleLabel: rule.label,
        edge: edgeMatch.edge,
        target: edgeMatch.target,
      );
      if (edgeMatch.edge.actionPayload == null) {
        final child = _executeActionEdgeChild(edgeContext, context);
        context.retv = child.value;
        continue;
      }

      final actionReturn = _executeActionBlock(
        edgeMatch.edge.actionPayload!.actionAst,
        context,
        rule.label,
        currentEdge: edgeContext,
      );
      if (actionReturn != null) {
        if (actionIterationValues == null) {
          throw _ActionReturn(actionReturn.value);
        }
        actionIterationValues.add(_copyValue(actionReturn.value));
      }
      if (!edgeContext.childDispatched &&
          edgeMatch.target.label != rule.label) {
        final child = _executeActionEdgeChild(edgeContext, context);
        context.retv = child.value;
      }
    }
  }

  _RegexPlan _regexPlanFor(CompiledRule rule) {
    return _RegexPlan(patterns: rule.regexPatterns);
  }

  List<_MatchedActionEdge> _actionEdgesFor(
    CompiledRule rule,
    int alternativeIndex,
  ) {
    if (rule.actionEdges.isEmpty) {
      return const [];
    }
    return [
      for (final edge in rule.actionEdges)
        if (edge.regexIndex == alternativeIndex)
          _MatchedActionEdge(edge: edge, target: edge.targets.first),
    ];
  }

  _ActionReturn? _executeLifecycle(
    CompiledRule rule,
    String lifecycle,
    _RuntimeExecutionContext context,
  ) {
    for (final payload in rule.lifecycleActionPayloads) {
      if (payload.lifecycle != lifecycle) {
        continue;
      }
      context.lifecycleEvents.add(
        RuntimeLifecycleEvent(
          ruleLabel: rule.label,
          lifecycle: lifecycle,
          line: payload.line,
        ),
      );
      context.trace?.emitEvent(
        LinkedSpecTraceEventKind.mark,
        'dart_runtime:lifecycle_block',
        'rule=${rule.label} lifecycle=$lifecycle line=${payload.line} '
            'cursor=${context.cursorCodeUnit}',
        LinkedSpecTraceLevel.high,
      );
      if (lifecycle == 'I') {
        for (final statement in payload.actionAst.statements) {
          if (statement.expr case ActionAssignScalarExpr(:final name)) {
            context.recordRuleLocalBinding(name);
          }
          if (statement.expr case ActionProgressiveDispatchSpanExpr(
            :final target,
          )) {
            context.recordRuleLocalBinding(target);
          }
          if (statement.expr case ActionStagedParseJobExpr(:final target)) {
            context.recordRuleLocalBinding(target);
          }
          if (statement.expr case ActionAssignScalarExpr(
            value: ActionObserveRecognitionExpr(:final target),
          )) {
            context.recordRuleLocalBinding(target);
          }
          final expr = statement.expr;
          if (expr is ActionCallExpr &&
              expr.name == 'set' &&
              expr.args.isNotEmpty) {
            final name = _variableName(expr.args.first.value);
            if (name != null) {
              context.recordRuleLocalBinding(name);
            }
          }
        }
      }
      final result = _executeActionBlock(
        payload.actionAst,
        context,
        rule.label,
        currentEdge: null,
      );
      if (result != null) {
        return result;
      }
    }
    return null;
  }

  _ActionReturn? _executeOptionalPayload(
    CompiledActionPayload? payload,
    _RuntimeExecutionContext context,
    String ruleLabel, {
    required _CurrentActionEdge? currentEdge,
  }) {
    if (payload == null) {
      return null;
    }
    return _executeActionBlock(
      payload.actionAst,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
  }

  _ActionReturn? _executeActionBlock(
    ActionBlock block,
    _RuntimeExecutionContext context,
    String ruleLabel, {
    required _CurrentActionEdge? currentEdge,
  }) {
    try {
      for (var index = 0; index < block.statements.length; index += 1) {
        final step = _executeActionStatementAt(
          block.statements,
          index,
          context,
          ruleLabel,
          currentEdge,
        );
        index = step.nextIndex;
      }
      return null;
    } on _ActionReturn catch (returnSignal) {
      return returnSignal;
    } on _ActionNext {
      rethrow;
    } on RuntimeExitNow {
      rethrow;
    } on _RuntimeDiagnosticOutputSinkFailure {
      rethrow;
    } on RuntimeInterpreterException {
      rethrow;
    } catch (error) {
      throw RuntimeInterpreterException(
        'action block failed in rule $ruleLabel: $error',
      );
    }
  }

  _StatementStep _executeActionStatementAt(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final statement = statements[index];
    final expr = statement.expr;
    if (expr is ActionControlIfExpr &&
        expr.branchRole == 'if' &&
        expr.body != null) {
      return _executeAttachedIfChainStatement(
        statements,
        index,
        context,
        ruleLabel,
        currentEdge,
      );
    }
    if (expr is ActionControlIfExpr &&
        expr.branchRole == 'if' &&
        expr.body == null) {
      return _executeMarkerIfChainStatement(
        statements,
        index,
        context,
        ruleLabel,
        currentEdge,
      );
    }
    if (expr is ActionControlWhileExpr && expr.body != null) {
      _executeAttachedWhileStatement(expr, context, ruleLabel, currentEdge);
      return _StatementStep(index);
    }
    if (_isMarkerSwitchStart(expr)) {
      return _executeMarkerSwitchChainStatement(
        statements,
        index,
        context,
        ruleLabel,
        currentEdge,
      );
    }
    if (expr is ActionControlSwitchExpr &&
        (expr.cases.isNotEmpty || expr.defaultCase != null)) {
      _executeAttachedSwitchStatement(expr, context, ruleLabel, currentEdge);
      return _StatementStep(index);
    }
    if ((expr is ActionControlIfExpr && expr.branchRole == 'elseif') ||
        expr is ActionControlElseExpr ||
        expr is ActionControlCaseExpr ||
        expr is ActionControlDefaultExpr ||
        expr is ActionControlMarkerExpr) {
      return _StatementStep(index);
    }
    _evaluateExpression(
      statement.expr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
      statementContext: statement.dropsValue,
    );
    return _StatementStep(index);
  }

  _StatementStep _executeAttachedIfChainStatement(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    var nextIndex = index;
    ActionBlock? selectedBody;
    for (var cursor = index; cursor < statements.length; cursor += 1) {
      final expr = statements[cursor].expr;
      if (cursor == index) {
        final first = expr as ActionControlIfExpr;
        if (runtimeLogicalTruth(
          _evaluateExpression(
            first.condition,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
        )) {
          selectedBody = first.body;
        }
      } else if (expr is ActionControlIfExpr && expr.branchRole == 'elseif') {
        if (selectedBody == null &&
            runtimeLogicalTruth(
              _evaluateExpression(
                expr.condition,
                context,
                ruleLabel,
                currentEdge: currentEdge,
              ),
            )) {
          selectedBody = expr.body;
        }
      } else if (expr is ActionControlElseExpr) {
        selectedBody ??= expr.body;
      } else {
        break;
      }
      nextIndex = cursor;
      if (expr is ActionControlElseExpr) {
        break;
      }
    }

    if (selectedBody != null) {
      final result = _executeActionBlock(
        selectedBody,
        context,
        ruleLabel,
        currentEdge: currentEdge,
      );
      if (result != null) {
        throw _ActionReturn(result.value);
      }
    }
    return _StatementStep(nextIndex);
  }

  _StatementStep _executeMarkerIfChainStatement(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final selection = _selectMarkerIfChain(
      statements,
      index,
      context,
      ruleLabel,
      currentEdge,
    );
    if (selection.start != null && selection.end != null) {
      _executeActionStatementRange(
        statements,
        selection.start!,
        selection.end!,
        context,
        ruleLabel,
        currentEdge,
      );
    }
    return _StatementStep(selection.nextIndex);
  }

  void _executeActionStatementRange(
    List<ActionStatement> statements,
    int start,
    int end,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    for (var cursor = start; cursor < end; cursor += 1) {
      final step = _executeActionStatementAt(
        statements,
        cursor,
        context,
        ruleLabel,
        currentEdge,
      );
      cursor = step.nextIndex;
    }
  }

  _StatementStep _executeMarkerSwitchChainStatement(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final selection = _selectMarkerSwitchChain(
      statements,
      index,
      context,
      ruleLabel,
      currentEdge,
    );
    if (selection.start != null && selection.end != null) {
      _executeActionStatementRange(
        statements,
        selection.start!,
        selection.end!,
        context,
        ruleLabel,
        currentEdge,
      );
    }
    return _StatementStep(selection.nextIndex);
  }

  void _executeAttachedWhileStatement(
    ActionControlWhileExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final body = expr.body;
    if (body == null) {
      return;
    }
    for (var iteration = 0; iteration < context.maxIterations; iteration += 1) {
      if (!runtimeLogicalTruth(
        _evaluateExpression(
          expr.condition,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
      )) {
        return;
      }
      final result = _executeActionBlock(
        body,
        context,
        ruleLabel,
        currentEdge: currentEdge,
      );
      if (result != null) {
        throw _ActionReturn(result.value);
      }
    }
    throw RuntimeInterpreterException(_whileIterationLimitMessage(context));
  }

  void _executeAttachedSwitchStatement(
    ActionControlSwitchExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final body = _selectSwitchBody(expr, context, ruleLabel, currentEdge);
    if (body == null) {
      return;
    }
    final result = _executeActionBlock(
      body,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
    if (result != null) {
      throw _ActionReturn(result.value);
    }
  }

  Object? _evaluateBlockValue(
    ActionBlock block,
    _RuntimeExecutionContext context,
    String ruleLabel, {
    required _CurrentActionEdge? currentEdge,
  }) {
    final flow = _executeValueBlockStatements(
      block,
      context,
      ruleLabel,
      currentEdge,
      finalExpressionYields: true,
    );
    return flow.returned ? flow.value : null;
  }

  _ValueBlockFlow _executeValueBlockStatements(
    ActionBlock block,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge, {
    required bool finalExpressionYields,
  }) {
    final statements = block.statements;
    for (var index = 0; index < statements.length; index += 1) {
      final statement = statements[index];
      final expr = statement.expr;
      final isLast = index == statements.length - 1;

      if (expr is ActionControlIfExpr &&
          expr.branchRole == 'if' &&
          expr.body != null) {
        final step = _executeValueIfChainStatement(
          statements,
          index,
          context,
          ruleLabel,
          currentEdge,
        );
        if (step.flow.returned) {
          return step.flow;
        }
        if (isLast && finalExpressionYields) {
          return const _ValueBlockFlow.returned(null);
        }
        index = step.nextIndex;
        continue;
      }

      if (expr is ActionControlIfExpr &&
          expr.branchRole == 'if' &&
          expr.body == null) {
        final step = _executeValueMarkerIfChainStatement(
          statements,
          index,
          context,
          ruleLabel,
          currentEdge,
        );
        if (step.flow.returned) {
          return step.flow;
        }
        if (isLast && finalExpressionYields) {
          return const _ValueBlockFlow.returned(null);
        }
        index = step.nextIndex;
        continue;
      }

      if (expr is ActionControlWhileExpr && expr.body != null) {
        final flow = _executeValueWhileStatement(
          expr,
          context,
          ruleLabel,
          currentEdge,
        );
        if (flow.returned) {
          return flow;
        }
        if (isLast && finalExpressionYields) {
          return const _ValueBlockFlow.returned(null);
        }
        continue;
      }

      if (_isMarkerSwitchStart(expr)) {
        final step = _executeValueMarkerSwitchChainStatement(
          statements,
          index,
          context,
          ruleLabel,
          currentEdge,
        );
        if (step.flow.returned) {
          return step.flow;
        }
        if (isLast && finalExpressionYields) {
          return const _ValueBlockFlow.returned(null);
        }
        index = step.nextIndex;
        continue;
      }

      if (expr is ActionControlSwitchExpr &&
          (expr.cases.isNotEmpty || expr.defaultCase != null)) {
        final flow = _executeValueSwitchStatement(
          expr,
          context,
          ruleLabel,
          currentEdge,
        );
        if (flow.returned) {
          return flow;
        }
        if (isLast && finalExpressionYields) {
          return const _ValueBlockFlow.returned(null);
        }
        continue;
      }

      if ((expr is ActionControlIfExpr && expr.branchRole == 'elseif') ||
          expr is ActionControlElseExpr ||
          expr is ActionControlCaseExpr ||
          expr is ActionControlDefaultExpr ||
          expr is ActionControlMarkerExpr) {
        if (isLast && finalExpressionYields) {
          return const _ValueBlockFlow.returned(null);
        }
        continue;
      }

      final returnPayload = _localReturnPayload(expr);
      if (returnPayload != null) {
        return _ValueBlockFlow.returned(
          returnPayload.hasValue
              ? _copyValue(
                  _evaluateExpression(
                    returnPayload.value!,
                    context,
                    ruleLabel,
                    currentEdge: currentEdge,
                  ),
                )
              : null,
        );
      }

      if (isLast && finalExpressionYields) {
        return _ValueBlockFlow.returned(
          _evaluateExpression(
            expr,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
        );
      }

      _evaluateExpression(
        expr,
        context,
        ruleLabel,
        currentEdge: currentEdge,
        statementContext: true,
      );
    }
    return const _ValueBlockFlow.continued();
  }

  _ValueStatementStep _executeValueIfChainStatement(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    var nextIndex = index;
    ActionBlock? selectedBody;
    for (var cursor = index; cursor < statements.length; cursor += 1) {
      final expr = statements[cursor].expr;
      if (cursor == index) {
        final first = expr as ActionControlIfExpr;
        if (runtimeLogicalTruth(
          _evaluateExpression(
            first.condition,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
        )) {
          selectedBody = first.body;
        }
      } else if (expr is ActionControlIfExpr && expr.branchRole == 'elseif') {
        if (selectedBody == null &&
            runtimeLogicalTruth(
              _evaluateExpression(
                expr.condition,
                context,
                ruleLabel,
                currentEdge: currentEdge,
              ),
            )) {
          selectedBody = expr.body;
        }
      } else if (expr is ActionControlElseExpr) {
        selectedBody ??= expr.body;
      } else {
        break;
      }
      nextIndex = cursor;
      if (expr is ActionControlElseExpr) {
        break;
      }
    }

    if (selectedBody == null) {
      return _ValueStatementStep(nextIndex, const _ValueBlockFlow.continued());
    }
    return _ValueStatementStep(
      nextIndex,
      _executeValueBlockStatements(
        selectedBody,
        context,
        ruleLabel,
        currentEdge,
        finalExpressionYields: false,
      ),
    );
  }

  _ValueStatementStep _executeValueMarkerIfChainStatement(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final selection = _selectMarkerIfChain(
      statements,
      index,
      context,
      ruleLabel,
      currentEdge,
    );
    if (selection.start == null || selection.end == null) {
      return _ValueStatementStep(
        selection.nextIndex,
        const _ValueBlockFlow.continued(),
      );
    }
    return _ValueStatementStep(
      selection.nextIndex,
      _executeValueStatementRange(
        statements,
        selection.start!,
        selection.end!,
        context,
        ruleLabel,
        currentEdge,
      ),
    );
  }

  _ValueStatementStep _executeValueMarkerSwitchChainStatement(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final selection = _selectMarkerSwitchChain(
      statements,
      index,
      context,
      ruleLabel,
      currentEdge,
    );
    if (selection.start == null || selection.end == null) {
      return _ValueStatementStep(
        selection.nextIndex,
        const _ValueBlockFlow.continued(),
      );
    }
    return _ValueStatementStep(
      selection.nextIndex,
      _executeValueStatementRange(
        statements,
        selection.start!,
        selection.end!,
        context,
        ruleLabel,
        currentEdge,
      ),
    );
  }

  _ValueBlockFlow _executeValueStatementRange(
    List<ActionStatement> statements,
    int start,
    int end,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    for (var cursor = start; cursor < end; cursor += 1) {
      final statement = statements[cursor];
      final expr = statement.expr;

      if (expr is ActionControlIfExpr &&
          expr.branchRole == 'if' &&
          expr.body == null) {
        final step = _executeValueMarkerIfChainStatement(
          statements,
          cursor,
          context,
          ruleLabel,
          currentEdge,
        );
        if (step.flow.returned) {
          return step.flow;
        }
        cursor = step.nextIndex;
        continue;
      }

      if (_isMarkerSwitchStart(expr)) {
        final step = _executeValueMarkerSwitchChainStatement(
          statements,
          cursor,
          context,
          ruleLabel,
          currentEdge,
        );
        if (step.flow.returned) {
          return step.flow;
        }
        cursor = step.nextIndex;
        continue;
      }

      final returnPayload = _localReturnPayload(expr);
      if (returnPayload != null) {
        return _ValueBlockFlow.returned(
          returnPayload.hasValue
              ? _copyValue(
                  _evaluateExpression(
                    returnPayload.value!,
                    context,
                    ruleLabel,
                    currentEdge: currentEdge,
                  ),
                )
              : null,
        );
      }

      _evaluateExpression(
        expr,
        context,
        ruleLabel,
        currentEdge: currentEdge,
        statementContext: true,
      );
    }
    return const _ValueBlockFlow.continued();
  }

  _MarkerIfSelection _selectMarkerIfChain(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final first = statements[index].expr as ActionControlIfExpr;
    int? selectedStart;
    int? selectedEnd;
    var selected = false;
    var depth = 0;
    var nextIndex = statements.length - 1;

    if (runtimeLogicalTruth(
      _evaluateExpression(
        first.condition,
        context,
        ruleLabel,
        currentEdge: currentEdge,
      ),
    )) {
      selectedStart = index + 1;
      selected = true;
    }

    for (var cursor = index + 1; cursor < statements.length; cursor += 1) {
      final expr = statements[cursor].expr;
      if (_isMarkerIfStart(expr)) {
        depth += 1;
        continue;
      }
      if (_isMarkerIfEnd(expr)) {
        if (depth > 0) {
          depth -= 1;
          continue;
        }
        if (selected && selectedEnd == null) {
          selectedEnd = cursor;
        }
        nextIndex = cursor;
        break;
      }
      if (depth != 0) {
        continue;
      }
      if (expr is ActionControlIfExpr &&
          expr.branchRole == 'elseif' &&
          expr.body == null) {
        if (selected && selectedEnd == null) {
          selectedEnd = cursor;
        }
        if (!selected &&
            runtimeLogicalTruth(
              _evaluateExpression(
                expr.condition,
                context,
                ruleLabel,
                currentEdge: currentEdge,
              ),
            )) {
          selectedStart = cursor + 1;
          selected = true;
        }
        continue;
      }
      if (expr is ActionControlElseExpr && expr.body == null) {
        if (selected && selectedEnd == null) {
          selectedEnd = cursor;
        }
        if (!selected) {
          selectedStart = cursor + 1;
          selected = true;
        }
      }
    }

    if (selected && selectedEnd == null) {
      selectedEnd = statements.length;
    }
    return _MarkerIfSelection(
      start: selectedStart,
      end: selectedEnd,
      nextIndex: nextIndex,
    );
  }

  bool _isMarkerIfStart(ActionExpr expr) {
    return expr is ActionControlIfExpr &&
        expr.branchRole == 'if' &&
        expr.body == null;
  }

  bool _isMarkerIfEnd(ActionExpr expr) {
    return expr is ActionControlMarkerExpr && expr.canonicalKeyword == 'endif';
  }

  _MarkerSwitchSelection _selectMarkerSwitchChain(
    List<ActionStatement> statements,
    int index,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final first = statements[index].expr as ActionControlSwitchExpr;
    final selector = _evaluateExpression(
      first.sourceExpr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
    int? selectedStart;
    int? selectedEnd;
    var selected = false;
    var branchMatched = false;
    var depth = 0;
    var nextIndex = statements.length - 1;

    for (var cursor = index + 1; cursor < statements.length; cursor += 1) {
      final expr = statements[cursor].expr;
      if (_isMarkerSwitchStart(expr)) {
        depth += 1;
        continue;
      }
      if (_isMarkerSwitchEnd(expr)) {
        if (depth > 0) {
          depth -= 1;
          continue;
        }
        if (selected && selectedEnd == null) {
          selectedEnd = cursor;
        }
        nextIndex = cursor;
        break;
      }
      if (depth != 0) {
        continue;
      }
      if (expr is ActionControlCaseExpr && expr.body == null) {
        if (selected && selectedEnd == null) {
          selectedEnd = cursor;
        }
        selected = false;
        if (!branchMatched) {
          final candidate = _evaluateSwitchCaseMatch(
            expr.match,
            context,
            ruleLabel,
            currentEdge,
          );
          if (_stringValue(candidate) == _stringValue(selector)) {
            selectedStart = cursor + 1;
            selected = true;
            branchMatched = true;
          }
        }
        continue;
      }
      if (expr is ActionControlDefaultExpr && expr.body == null) {
        if (selected && selectedEnd == null) {
          selectedEnd = cursor;
        }
        selected = false;
        if (!branchMatched) {
          selectedStart = cursor + 1;
          selected = true;
          branchMatched = true;
        }
        continue;
      }
      if (_isMarkerCaseEnd(expr)) {
        if (selected && selectedEnd == null) {
          selectedEnd = cursor;
        }
        selected = false;
      }
    }

    if (selected && selectedEnd == null) {
      selectedEnd = statements.length;
    }
    return _MarkerSwitchSelection(
      start: selectedStart,
      end: selectedEnd,
      nextIndex: nextIndex,
    );
  }

  bool _isMarkerSwitchStart(ActionExpr expr) {
    return expr is ActionControlSwitchExpr &&
        expr.body == null &&
        expr.cases.isEmpty &&
        expr.defaultCase == null;
  }

  bool _isMarkerSwitchEnd(ActionExpr expr) {
    return expr is ActionControlMarkerExpr &&
        expr.canonicalKeyword == 'endswitch';
  }

  bool _isMarkerCaseEnd(ActionExpr expr) {
    return expr is ActionControlMarkerExpr &&
        expr.canonicalKeyword == 'endcase';
  }

  _ValueBlockFlow _executeValueWhileStatement(
    ActionControlWhileExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final body = expr.body;
    if (body == null) {
      return const _ValueBlockFlow.continued();
    }
    for (var iteration = 0; iteration < context.maxIterations; iteration += 1) {
      if (!runtimeLogicalTruth(
        _evaluateExpression(
          expr.condition,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
      )) {
        return const _ValueBlockFlow.continued();
      }
      final flow = _executeValueBlockStatements(
        body,
        context,
        ruleLabel,
        currentEdge,
        finalExpressionYields: false,
      );
      if (flow.returned) {
        return flow;
      }
    }
    throw RuntimeInterpreterException(_whileIterationLimitMessage(context));
  }

  _ValueBlockFlow _executeValueSwitchStatement(
    ActionControlSwitchExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final body = _selectSwitchBody(expr, context, ruleLabel, currentEdge);
    if (body == null) {
      return const _ValueBlockFlow.continued();
    }
    return _executeValueBlockStatements(
      body,
      context,
      ruleLabel,
      currentEdge,
      finalExpressionYields: false,
    );
  }

  ActionBlock? _selectSwitchBody(
    ActionControlSwitchExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final selector = _evaluateExpression(
      expr.sourceExpr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
    for (final item in expr.cases) {
      final candidate = _evaluateSwitchCaseMatch(
        item.match,
        context,
        ruleLabel,
        currentEdge,
      );
      if (_stringValue(candidate) == _stringValue(selector)) {
        return item.body;
      }
    }
    return expr.defaultCase?.body;
  }

  Object? _evaluateSwitchCaseMatch(
    ActionExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (expr is ActionVariableExpr) {
      return expr.name;
    }
    return _evaluateExpression(
      expr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
  }

  _LocalReturnPayload? _localReturnPayload(ActionExpr expr) {
    if (expr is! ActionCallExpr) {
      return null;
    }
    final helperName = canonicalActionHelperName(expr.name);
    if (helperName == 'return_undef' && expr.args.isEmpty) {
      return const _LocalReturnPayload.undef();
    }
    if (helperName != 'return') {
      return null;
    }
    final positionalArgs = expr.args.map((arg) => arg.value).toList();
    return positionalArgs.isEmpty
        ? const _LocalReturnPayload.undef()
        : _LocalReturnPayload.value(positionalArgs.first);
  }

  String _whileIterationLimitMessage(_RuntimeExecutionContext context) {
    return 'LinkedSpec while iteration safety limit exceeded after '
        '${context.maxIterations} iterations';
  }

  Object? _evaluateStructuredControlExpression(
    ActionExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel, {
    required _CurrentActionEdge? currentEdge,
  }) {
    switch (expr) {
      case ActionControlIfExpr(:final body):
        if (body == null) {
          return null;
        }
        final statements = [
          ActionStatement(
            source: expr.source,
            sourceSpan: expr.sourceSpan,
            expr: expr,
          ),
        ];
        _executeAttachedIfChainStatement(
          statements,
          0,
          context,
          ruleLabel,
          currentEdge,
        );
        return null;
      case ActionControlWhileExpr():
        _executeAttachedWhileStatement(expr, context, ruleLabel, currentEdge);
        return null;
      case ActionControlSwitchExpr():
        _executeAttachedSwitchStatement(expr, context, ruleLabel, currentEdge);
        return null;
      default:
        return null;
    }
  }

  Object? _callInlineIf(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (args.isEmpty) {
      return null;
    }
    if (runtimeLogicalTruth(
      _evaluateExpression(
        args[0],
        context,
        ruleLabel,
        currentEdge: currentEdge,
      ),
    )) {
      return args.length >= 2
          ? _evaluateExpression(
              args[1],
              context,
              ruleLabel,
              currentEdge: currentEdge,
            )
          : true;
    }
    for (var index = 2; index < args.length; index += 1) {
      final arg = args[index];
      if (arg is! ActionCallExpr) {
        return _evaluateExpression(
          arg,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        );
      }
      final branchName = canonicalActionHelperName(arg.name);
      final branchArgs = arg.args.map((item) => item.value).toList();
      if (branchName == 'elseif') {
        if (branchArgs.length >= 2 &&
            runtimeLogicalTruth(
              _evaluateExpression(
                branchArgs[0],
                context,
                ruleLabel,
                currentEdge: currentEdge,
              ),
            )) {
          return _evaluateExpression(
            branchArgs[1],
            context,
            ruleLabel,
            currentEdge: currentEdge,
          );
        }
      } else if (branchName == 'else') {
        return branchArgs.isEmpty
            ? null
            : _evaluateExpression(
                branchArgs[0],
                context,
                ruleLabel,
                currentEdge: currentEdge,
              );
      } else {
        return _evaluateExpression(
          arg,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        );
      }
    }
    return null;
  }

  Object? _callInlineSwitch(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (args.isEmpty) {
      return null;
    }
    final selector = _evaluateExpression(
      args.first,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
    ActionExpr? defaultExpr;
    for (final branch in args.skip(1)) {
      if (branch is! ActionCallExpr) {
        continue;
      }
      final branchName = canonicalActionHelperName(branch.name);
      final branchArgs = branch.args.map((arg) => arg.value).toList();
      if (branchName == 'case' && branchArgs.length >= 2) {
        final candidate = _evaluateSwitchCaseMatch(
          branchArgs[0],
          context,
          ruleLabel,
          currentEdge,
        );
        if (_stringValue(candidate) == _stringValue(selector)) {
          return _evaluateExpression(
            branchArgs[1],
            context,
            ruleLabel,
            currentEdge: currentEdge,
          );
        }
      } else if (branchName == 'default' && branchArgs.isNotEmpty) {
        defaultExpr ??= branchArgs.first;
      }
    }
    return defaultExpr == null
        ? null
        : _evaluateExpression(
            defaultExpr,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          );
  }

  Object? _callWithCodeblock(
    ActionCallExpr call,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (call.args.isEmpty || call.args.length > 2) {
      throw RuntimeInterpreterException(
        "LINKEDSPEC_UNSUPPORTED_ACTIONIR_HELPER:with: helper "
        "`with(...) { ... }` expects zero or one value argument plus a "
        "trailing block in rule '$ruleLabel'",
      );
    }
    final callbackExpr = call.args.last.value;
    final scopedValue = call.args.length == 2
        ? _evaluateExpression(
            call.args.first.value,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          )
        : null;
    final callbackValue = _evaluateExpression(
      callbackExpr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
    final callback = _requireFinalCodeblockValue(
      'with',
      callbackValue,
      context,
      ruleLabel,
    );
    final binding = context.enterScopedScalar('value', scopedValue);
    try {
      return _executeCodeblockValue(
        'with',
        callback,
        const [],
        context,
        ruleLabel,
        currentEdge,
        evaluatedValues: callbackExpr is ActionCodeblockArgumentExpr
            ? const []
            : [_copyValue(scopedValue)],
      );
    } finally {
      context.exitScopedVariable(binding);
    }
  }

  Object? _callReceiverWithCodeblock(
    Object? receiver,
    ActionFluentCall call,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (call.args.length != 1) {
      throw RuntimeInterpreterException(
        "LINKEDSPEC_UNSUPPORTED_ACTIONIR_HELPER:with: receiver "
        "`.with() { ... }` expects no parenthesized arguments in rule "
        "'$ruleLabel'",
      );
    }
    final callbackExpr = call.args.single.value;
    final callbackValue = _evaluateExpression(
      callbackExpr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
    final callback = _requireFinalCodeblockValue(
      'with',
      callbackValue,
      context,
      ruleLabel,
    );
    final binding = context.enterScopedScalar('value', _copyValue(receiver));
    try {
      return _executeCodeblockValue(
        'with',
        callback,
        const [],
        context,
        ruleLabel,
        currentEdge,
        evaluatedValues: callbackExpr is ActionCodeblockArgumentExpr
            ? const []
            : [_copyValue(receiver)],
      );
    } finally {
      context.exitScopedVariable(binding);
    }
  }

  Object? _callTreeTraversalTrailingBlock(
    Object? receiver,
    ActionFluentCall call,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final method = canonicalActionHelperName(call.method);
    if (!_treeTraversalHelperNames.contains(method)) {
      return null;
    }
    if (call.args.isEmpty) {
      throw RuntimeInterpreterException(
        _treeTraversalMalformedMessage(method, ruleLabel),
      );
    }
    if ((method == 'walk_leaves' || method == 'map_leaves') &&
        call.args.length != 1) {
      throw RuntimeInterpreterException(
        _treeTraversalMalformedMessage(method, ruleLabel),
      );
    }
    if (method == 'reduce_leaves' && call.args.length != 2) {
      throw RuntimeInterpreterException(
        _treeTraversalMalformedMessage(method, ruleLabel),
      );
    }
    final callbackExpr = call.args.last.value;
    final callbackValue = _evaluateExpression(
      callbackExpr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
    final callback = _TreeCodeblockCallback(
      name: method,
      codeblock: _requireFinalCodeblockValue(
        method,
        callbackValue,
        context,
        ruleLabel,
      ),
      passLeafValue: callbackExpr is! ActionCodeblockArgumentExpr,
    );
    if (receiver is Map) {
      final hash = _asHash(receiver);
      return switch (method) {
        'walk_leaves' => _walkHashTree(
          hash,
          callback,
          context,
          ruleLabel,
          currentEdge,
        ),
        'map_leaves' => _mapHashTree(
          hash,
          callback,
          context,
          ruleLabel,
          currentEdge,
        ),
        'reduce_leaves' => _reduceHashTree(
          hash,
          _evaluateExpression(
            call.args.first.value,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
          callback,
          context,
          ruleLabel,
          currentEdge,
        ),
        _ => null,
      };
    }
    if (receiver is List) {
      final items = _asArray(receiver);
      return switch (method) {
        'walk_leaves' => _walkArrayTree(
          items,
          callback,
          context,
          ruleLabel,
          currentEdge,
        ),
        'map_leaves' => _mapArrayTree(
          items,
          callback,
          context,
          ruleLabel,
          currentEdge,
        ),
        'reduce_leaves' => _reduceArrayTree(
          items,
          _evaluateExpression(
            call.args.first.value,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
          callback,
          context,
          ruleLabel,
          currentEdge,
        ),
        _ => null,
      };
    }
    return null;
  }

  String _treeTraversalMalformedMessage(String method, String ruleLabel) {
    final signature = switch (method) {
      'reduce_leaves' => '.reduce_leaves(initial) { ... }',
      'walk_leaves' => '.walk_leaves() { ... }',
      'map_leaves' => '.map_leaves() { ... }',
      _ => '.<tree-traversal-method>() { ... }',
    };
    return 'LINKEDSPEC_UNSUPPORTED_ACTIONIR_HELPER:$method: receiver '
        '`$signature` requires the accepted tree traversal trailing-block '
        "arity in rule '$ruleLabel'";
  }

  Object? _walkHashTree(
    Map<String, Object?> hash,
    _TreeCodeblockCallback callback,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    void walk(Map<String, Object?> node, List<String> path) {
      final keys = node.keys.toList()..sort();
      for (final key in keys) {
        final value = node[key];
        final nextPath = [...path, key];
        if (value is Map) {
          walk(_asHash(value), nextPath);
        } else {
          _evaluateHashLeafBlock(
            callback,
            value,
            key,
            nextPath,
            null,
            false,
            context,
            ruleLabel,
            currentEdge,
          );
        }
      }
    }

    walk(hash, const []);
    return _copyValue(hash);
  }

  Object? _mapHashTree(
    Map<String, Object?> hash,
    _TreeCodeblockCallback callback,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    Map<String, Object?> mapNode(Map<String, Object?> node, List<String> path) {
      final result = <String, Object?>{};
      final keys = node.keys.toList()..sort();
      for (final key in keys) {
        final value = node[key];
        final nextPath = [...path, key];
        result[key] = value is Map
            ? mapNode(_asHash(value), nextPath)
            : _evaluateHashLeafBlock(
                callback,
                value,
                key,
                nextPath,
                null,
                false,
                context,
                ruleLabel,
                currentEdge,
              );
      }
      return result;
    }

    return mapNode(hash, const []);
  }

  Object? _reduceHashTree(
    Map<String, Object?> hash,
    Object? initial,
    _TreeCodeblockCallback callback,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    var acc = _copyValue(initial);
    void reduceNode(Map<String, Object?> node, List<String> path) {
      final keys = node.keys.toList()..sort();
      for (final key in keys) {
        final value = node[key];
        final nextPath = [...path, key];
        if (value is Map) {
          reduceNode(_asHash(value), nextPath);
        } else {
          acc = _evaluateHashLeafBlock(
            callback,
            value,
            key,
            nextPath,
            acc,
            true,
            context,
            ruleLabel,
            currentEdge,
          );
        }
      }
    }

    reduceNode(hash, const []);
    return acc;
  }

  Object? _evaluateHashLeafBlock(
    _TreeCodeblockCallback callback,
    Object? value,
    String key,
    List<String> path,
    Object? acc,
    bool bindAcc,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final bindings = <_ScopedVariableBinding>[
      if (bindAcc) context.enterScopedScalar('acc', _copyValue(acc)),
      context.enterScopedScalar('value', _copyValue(value)),
      context.enterScopedScalar('key', key),
      context.enterScopedScalar('path', [for (final item in path) item]),
      context.enterScopedScalar('depth', path.length),
    ];
    try {
      return _executeCodeblockValue(
        callback.name,
        callback.codeblock,
        const [],
        context,
        ruleLabel,
        currentEdge,
        evaluatedValues: callback.passLeafValue
            ? [_copyValue(value)]
            : const [],
      );
    } finally {
      for (final binding in bindings.reversed) {
        context.exitScopedVariable(binding);
      }
    }
  }

  Object? _walkArrayTree(
    List<Object?> items,
    _TreeCodeblockCallback callback,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    void walk(List<Object?> node, List<int> path) {
      for (final (index, value) in node.indexed) {
        final nextPath = [...path, index];
        if (value is List) {
          walk(_asArray(value), nextPath);
        } else {
          _evaluateArrayLeafBlock(
            callback,
            value,
            index,
            nextPath,
            null,
            false,
            context,
            ruleLabel,
            currentEdge,
          );
        }
      }
    }

    walk(items, const []);
    return _copyValue(items);
  }

  Object? _mapArrayTree(
    List<Object?> items,
    _TreeCodeblockCallback callback,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    List<Object?> mapNode(List<Object?> node, List<int> path) {
      final result = <Object?>[];
      for (final (index, value) in node.indexed) {
        final nextPath = [...path, index];
        result.add(
          value is List
              ? mapNode(_asArray(value), nextPath)
              : _evaluateArrayLeafBlock(
                  callback,
                  value,
                  index,
                  nextPath,
                  null,
                  false,
                  context,
                  ruleLabel,
                  currentEdge,
                ),
        );
      }
      return result;
    }

    return mapNode(items, const []);
  }

  Object? _reduceArrayTree(
    List<Object?> items,
    Object? initial,
    _TreeCodeblockCallback callback,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    var acc = _copyValue(initial);
    void reduceNode(List<Object?> node, List<int> path) {
      for (final (index, value) in node.indexed) {
        final nextPath = [...path, index];
        if (value is List) {
          reduceNode(_asArray(value), nextPath);
        } else {
          acc = _evaluateArrayLeafBlock(
            callback,
            value,
            index,
            nextPath,
            acc,
            true,
            context,
            ruleLabel,
            currentEdge,
          );
        }
      }
    }

    reduceNode(items, const []);
    return acc;
  }

  Object? _evaluateArrayLeafBlock(
    _TreeCodeblockCallback callback,
    Object? value,
    int index,
    List<int> path,
    Object? acc,
    bool bindAcc,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final bindings = <_ScopedVariableBinding>[
      if (bindAcc) context.enterScopedScalar('acc', _copyValue(acc)),
      context.enterScopedScalar('value', _copyValue(value)),
      context.enterScopedScalar('index', index),
      context.enterScopedScalar('path', [for (final item in path) item]),
      context.enterScopedScalar('depth', path.length),
    ];
    try {
      return _executeCodeblockValue(
        callback.name,
        callback.codeblock,
        const [],
        context,
        ruleLabel,
        currentEdge,
        evaluatedValues: callback.passLeafValue
            ? [_copyValue(value)]
            : const [],
      );
    } finally {
      for (final binding in bindings.reversed) {
        context.exitScopedVariable(binding);
      }
    }
  }

  Object? _evaluateExpression(
    ActionExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel, {
    required _CurrentActionEdge? currentEdge,
    bool statementContext = false,
  }) {
    switch (expr) {
      case ActionStringLiteralExpr(:final value):
        return value;
      case ActionNumberLiteralExpr(:final value):
        return value;
      case ActionBooleanLiteralExpr(:final value):
        return value;
      case ActionRegexLiteralExpr(:final pattern):
        return pattern;
      case ActionUndefExpr():
        return null;
      case ActionVariableExpr(:final name):
        if (name == 'retv') {
          return _readRetv(context, currentEdge);
        }
        return _bindingValueFor(context, name);
      case ActionArrayLiteralExpr(:final items):
        final values = <Object?>[];
        for (final item in items) {
          final value = _evaluateExpression(
            item,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          );
          if (_isArraySpliceArgument(item)) {
            _appendArraySpliceValue(values, value);
          } else {
            values.add(_copyValue(value));
          }
        }
        return values;
      case ActionHashLiteralExpr(:final entries):
        return {
          for (final entry in entries)
            _stringValue(
              _evaluateExpression(
                entry.key,
                context,
                ruleLabel,
                currentEdge: currentEdge,
              ),
            ): _copyValue(
              _evaluateExpression(
                entry.value,
                context,
                ruleLabel,
                currentEdge: currentEdge,
              ),
            ),
        };
      case ActionCodeblockArgumentExpr(:final source, :final bodyAst):
      case ActionCodeblockLiteralExpr(:final source, :final bodyAst):
        _codeblockBodyCache[source] = bodyAst;
        return _copyValue(expr.toJson());
      case ActionCodeblockLiteralErrorExpr(:final code):
        throw RuntimeInterpreterException(
          'invalid callable-codeblock literal in rule $ruleLabel: $code',
        );
      case ActionAssignScalarExpr(:final name, :final value):
        _assertReceiverMutationWritable(
          context,
          name,
          'assign',
          _bindingTargetSpan(expr.sourceSpan, name),
        );
        if (value is ActionRecognitionCheckpointExpr) {
          context.recognitionCheckpoint(ruleLabel, name);
          context.ensureBindingIdentity(name);
          context.variables[name] = null;
          context.arrays.remove(name);
          context.hashes.remove(name);
          return null;
        }
        final stored = _copyValue(
          _evaluateExpression(
            value,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
        );
        context.ensureBindingIdentity(name);
        context.variables[name] = stored;
        context.arrays.remove(name);
        context.hashes.remove(name);
        return _copyValue(stored);
      case ActionAssignArrayAppendExpr(:final name, :final value):
        _assertReceiverMutationWritable(
          context,
          name,
          'append',
          _bindingTargetSpan(expr.sourceSpan, name),
        );
        final stored = _copyValue(
          _evaluateExpression(
            value,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
        );
        return _appendArrayValue(context, name, stored);
      case ActionAssignHashIndexExpr(:final name, :final key, :final value):
        _assertReceiverMutationWritable(
          context,
          name,
          'nested_write',
          _bindingTargetSpan(expr.sourceSpan, name),
        );
        return _assignHashIndex(
          context,
          name,
          key,
          value,
          ruleLabel,
          currentEdge,
        );
      case ActionAssignNestedAccessExpr(
        :final base,
        :final segments,
        :final value,
      ):
        _assertReceiverMutationWritable(
          context,
          base,
          'nested_write',
          _bindingTargetSpan(expr.sourceSpan, base),
        );
        return _writeNested(
          context,
          base,
          segments,
          value,
          ruleLabel,
          currentEdge,
        );
      case ActionReceiverMutationChainExpr():
        return _evaluateReceiverMutationChain(
          expr,
          context,
          ruleLabel,
          currentEdge,
        );
      case ActionIndexedVarExpr(:final name, :final index):
        final collection =
            context.variables[name] ??
            context.arrays[name] ??
            context.hashes[name];
        final indexValue = _evaluateExpression(
          index,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        );
        return _indexValue(collection, indexValue);
      case ActionNestedAccessExpr(:final base, :final segments):
        final root = base == 'retv'
            ? _readRetv(context, currentEdge)
            : (context.variables[base] ??
                  context.arrays[base] ??
                  context.hashes[base]);
        return _readNested(root, segments, context, ruleLabel, currentEdge);
      case ActionValueAccessExpr(:final receiver, :final segments):
        final root = _evaluateExpression(
          receiver,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        );
        return _readNested(root, segments, context, ruleLabel, currentEdge);
      case ActionControlIfExpr():
      case ActionControlWhileExpr():
      case ActionControlSwitchExpr():
        return _evaluateStructuredControlExpression(
          expr,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        );
      case ActionControlElseExpr():
      case ActionControlCaseExpr():
      case ActionControlDefaultExpr():
      case ActionControlMarkerExpr():
        return null;
      case ActionRecognitionCheckpointExpr():
        throw RuntimeInterpreterException(
          'recognition_checkpoint must be assigned to a rule-local token '
          "in rule '$ruleLabel'",
        );
      case ActionStagedParseJobExpr(
        :final target,
        :final textPlan,
        :final options,
      ):
        _assertReceiverMutationWritable(
          context,
          target,
          'assign',
          _bindingTargetSpan(expr.sourceSpan, target),
        );
        final marker = constructStagedParseJobMarker(
          authority: context.sourceAuthority,
          registers: context.registers,
          origin: '$ruleLabel:parse_job',
          textPlan: textPlan,
          options: options,
        );
        final stored = _copyValue(marker);
        context.ensureBindingIdentity(target);
        context.variables[target] = stored;
        context.arrays.remove(target);
        context.hashes.remove(target);
        return _copyValue(stored);
      case ActionProgressiveDispatchSpanExpr(
        :final target,
        :final parserId,
        :final topRule,
        :final span,
      ):
        _assertReceiverMutationWritable(
          context,
          target,
          'assign',
          _bindingTargetSpan(expr.sourceSpan, target),
        );
        final authority = context.progressiveExecution;
        if (authority == null) {
          throw ProgressiveDispatchException.missingRegistry(
            origin: '$ruleLabel:dispatch_span',
            parserId: parserId,
          );
        }
        final value = authority.dispatch(
          origin: '$ruleLabel:dispatch_span',
          parserId: parserId,
          topRule: topRule,
          span: _copyValue(_bindingValueFor(context, span)),
          transactionActive: context.hasActiveRecognitionTransaction,
        );
        final stored = _copyValue(value);
        context.ensureBindingIdentity(target);
        context.variables[target] = stored;
        context.arrays.remove(target);
        context.hashes.remove(target);
        return _copyValue(stored);
      case ActionRecognizeOnceExpr(:final token, :final rule):
        final child = currentEdge != null && currentEdge.target.label == rule
            ? _executeActionEdgeChild(currentEdge, context)
            : _executeRule(rule, 0, context);
        context.retv = child.value;
        return context.recognitionAttempt(
          ruleLabel,
          token,
          matched: child.matched,
          payload: child.value,
        );
      case ActionRecognitionCommitExpr(:final token):
        return context.recognitionCommit(ruleLabel, token);
      case ActionRecognitionRollbackExpr(:final token):
        context.recognitionRollback(ruleLabel, token);
        return null;
      case ActionObserveRecognitionExpr(:final target, :final rule):
        _assertReceiverMutationWritable(
          context,
          target,
          'assign',
          _bindingTargetSpan(expr.sourceSpan, target),
        );
        final observation = context.beginRecursiveObservation(rule);
        try {
          final child = currentEdge != null && currentEdge.target.label == rule
              ? _executeActionEdgeChild(currentEdge, context)
              : _executeRule(rule, 0, context);
          context.retv = child.value;
          context.bindRecursiveObservation(ruleLabel, target, observation);
          return child.value;
        } on Object catch (error, stackTrace) {
          context.bindRecursiveObservation(
            ruleLabel,
            target,
            observation,
            error: error,
          );
          Error.throwWithStackTrace(error, stackTrace);
        }
      case ActionCallExpr(:final name):
        if (name == 'dispatch_span') {
          throw RuntimeInterpreterException(
            'LINKEDSPEC_PROGRESSIVE_SPAN_DISPATCH_ERROR:'
            'progressive_span_binding_required',
          );
        }
        return _evaluateCall(
          expr,
          context,
          ruleLabel,
          currentEdge: currentEdge,
          statementContext: statementContext,
        );
      case ActionFluentChainExpr(:final receiver, :final calls):
        if (statementContext &&
            _executeArrayEndMutationStatement(
              expr,
              context,
              ruleLabel,
              currentEdge,
            )) {
          return null;
        }
        if (calls.isEmpty) {
          return _evaluateExpression(
            receiver,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          );
        }
        if (const {
          'push_back',
          'push_front',
          'pop_back',
          'pop_front',
        }.contains(calls.first.method)) {
          Object? value = _evaluateArrayEndMutationCall(
            receiver,
            calls.first,
            context,
            ruleLabel,
            currentEdge,
          );
          if (value == null) {
            return null;
          }
          for (final call in calls.skip(1)) {
            value = _evaluateFluentCall(
              value,
              call,
              context,
              ruleLabel,
              currentEdge: currentEdge,
            );
          }
          return value;
        }
        var value = _evaluateFluentReceiver(
          receiver,
          canonicalActionHelperName(calls.first.method),
          context,
          ruleLabel,
          currentEdge,
        );
        for (final call in calls) {
          value = _evaluateFluentCall(
            value,
            call,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          );
        }
        return value;
      case ActionBlockValueExpr(:final block):
        return _evaluateBlockValue(
          block,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        );
      case ActionRawExpr(:final source):
        throw RuntimeInterpreterException(
          'unsupported raw action expression in rule $ruleLabel: $source',
        );
      default:
        throw RuntimeInterpreterException(
          'unsupported action expression ${expr.kind} in rule $ruleLabel',
        );
    }
  }

  Object? _evaluateReceiverMutationChain(
    ActionReceiverMutationChainExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final receiver = expr.receiver;
    if (!_hasRuntimeBinding(context, receiver.name)) {
      final message =
          "map_leaves! receiver binding '${receiver.name}' does not exist";
      throw RuntimeInterpreterException(
        message,
        diagnostic: context.diagnostic(
          stage: 'runtime_execution',
          summary: 'Dart map_leaves! receiver mutation failed',
          detail: message,
          code: 'map_leaves_mutation_receiver_missing',
          operation: 'map_leaves_mutation',
          binding: receiver.name,
          method: 'map_leaves',
          sourceSpan: _receiverMutationSourceSpan(receiver.sourceSpan),
        ),
      );
    }
    final rootStorage = _rootStorageForWrite(context, receiver.name);
    final snapshot = _copyValue(rootStorage.value);
    if (snapshot is! Map && snapshot is! List) {
      final actualKind = _nestedWriteValueKind(snapshot);
      final message =
          "map_leaves! receiver '${receiver.name}' must hold an harray or "
          'array, got $actualKind';
      throw RuntimeInterpreterException(
        message,
        diagnostic: context.diagnostic(
          stage: 'runtime_execution',
          summary: 'Dart map_leaves! receiver mutation failed',
          detail: message,
          code: 'map_leaves_mutation_receiver_kind_mismatch',
          operation: 'map_leaves_mutation',
          binding: receiver.name,
          method: 'map_leaves',
          expectedKinds: const ['harray', 'array'],
          actualKind: actualKind,
          sourceSpan: _receiverMutationSourceSpan(receiver.sourceSpan),
        ),
      );
    }
    final identity = context.activateReceiverMutation(receiver.name);
    if (identity == null) {
      _throwReceiverMutationReentrant(
        context,
        receiver.name,
        'map_leaves!',
        receiver.sourceSpan,
      );
    }

    late final Object? rebuilt;
    try {
      rebuilt = snapshot is Map
          ? _mapReceiverMutationHash(
              _asHash(snapshot),
              expr.mutation.callback.body,
              context,
              ruleLabel,
              currentEdge,
            )
          : _mapReceiverMutationArray(
              _asArray(snapshot),
              expr.mutation.callback.body,
              context,
              ruleLabel,
              currentEdge,
            );
      rootStorage.store(context, rebuilt);
    } finally {
      context.deactivateReceiverMutation(identity);
    }

    Object? result = _copyValue(rebuilt);
    for (final call in expr.continuation) {
      final trailingBlock =
          call.args.isNotEmpty &&
          call.args.last.value is ActionCodeblockArgumentExpr;
      result = _evaluateFluentCall(
        result,
        ActionFluentCall(
          method: call.method,
          sourceMethod: call.sourceMethod,
          args: call.args,
          source: call.source,
          sourceSpan: call.sourceSpan,
          trailingBlockArg: trailingBlock,
          receiverTrailingBlockArg: trailingBlock,
        ),
        context,
        ruleLabel,
        currentEdge: currentEdge,
      );
    }
    return _copyValue(result);
  }

  Map<String, Object?> _mapReceiverMutationHash(
    Map<String, Object?> root,
    ActionBlock callback,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    Map<String, Object?> mapNode(Map<String, Object?> node, List<String> path) {
      final result = <String, Object?>{};
      final keys = node.keys.toList()..sort();
      for (final key in keys) {
        final value = node[key];
        final nextPath = [...path, key];
        result[key] = value is Map
            ? mapNode(_asHash(value), nextPath)
            : _evaluateReceiverMutationHashLeaf(
                callback,
                value,
                key,
                nextPath,
                context,
                ruleLabel,
                currentEdge,
              );
      }
      return result;
    }

    return mapNode(root, const []);
  }

  Object? _evaluateReceiverMutationHashLeaf(
    ActionBlock callback,
    Object? value,
    String key,
    List<String> path,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final bindings = <_ScopedVariableBinding>[
      context.enterScopedScalar('value', _copyValue(value)),
      context.enterScopedScalar('key', key),
      context.enterScopedScalar('path', [for (final item in path) item]),
      context.enterScopedScalar('depth', path.length),
    ];
    try {
      return _copyValue(
        _evaluateBlockValue(
          callback,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
      );
    } finally {
      for (final binding in bindings.reversed) {
        context.exitScopedVariable(binding);
      }
    }
  }

  List<Object?> _mapReceiverMutationArray(
    List<Object?> root,
    ActionBlock callback,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    List<Object?> mapNode(List<Object?> node, List<int> path) {
      final result = <Object?>[];
      for (final (index, value) in node.indexed) {
        final nextPath = [...path, index];
        result.add(
          value is List
              ? mapNode(_asArray(value), nextPath)
              : _evaluateReceiverMutationArrayLeaf(
                  callback,
                  value,
                  index,
                  nextPath,
                  context,
                  ruleLabel,
                  currentEdge,
                ),
        );
      }
      return result;
    }

    return mapNode(root, const []);
  }

  Object? _evaluateReceiverMutationArrayLeaf(
    ActionBlock callback,
    Object? value,
    int index,
    List<int> path,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final bindings = <_ScopedVariableBinding>[
      context.enterScopedScalar('value', _copyValue(value)),
      context.enterScopedScalar('index', index),
      context.enterScopedScalar('path', [for (final item in path) item]),
      context.enterScopedScalar('depth', path.length),
    ];
    try {
      return _copyValue(
        _evaluateBlockValue(
          callback,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
      );
    } finally {
      for (final binding in bindings.reversed) {
        context.exitScopedVariable(binding);
      }
    }
  }

  Object? _evaluateCall(
    ActionCallExpr call,
    _RuntimeExecutionContext context,
    String ruleLabel, {
    required _CurrentActionEdge? currentEdge,
    bool statementContext = false,
  }) {
    final positionalArgs = call.args.map((arg) => arg.value).toList();
    final helperName = canonicalActionHelperName(call.name);
    _validateDiagnosticOutputArity(call, helperName, context, ruleLabel);
    if (helperName == 'with') {
      return _callWithCodeblock(call, context, ruleLabel, currentEdge);
    }
    if (statementContext &&
        helperName == 'set_key' &&
        _executeSetKeyStatement(call, context, ruleLabel, currentEdge)) {
      return null;
    }
    if (statementContext &&
        (helperName == 'substr' || helperName == 'regex_subst') &&
        _executeRegexSubstitutionStatement(
          call,
          context,
          ruleLabel,
          currentEdge,
        )) {
      return null;
    }
    if (statementContext &&
        _executeArrayStringTransformStatement(
          call,
          context,
          ruleLabel,
          currentEdge,
        )) {
      return null;
    }
    if (compiledSpec.functionRegistry.hasName(call.name) &&
        call.args.any((arg) => arg is ActionKeywordArgument)) {
      final keywordCount = call.args.whereType<ActionKeywordArgument>().length;
      final detail =
          "user function '${call.name}' accepts positional arguments only in "
          'rule $ruleLabel';
      throw RuntimeInterpreterException(
        detail,
        diagnostic: context.diagnostic(
          stage: 'user_function_call',
          summary: 'Dart user function keyword arguments failed',
          detail: detail,
          code: 'user_function_keyword_arguments_unsupported',
          callableName: call.name,
          expected: 'positional arguments',
          got: keywordCount,
          ruleLabel: ruleLabel,
          handlerSourceLabel: 'dart_runtime:function:${call.name}',
        ),
      );
    }
    final functionResolution = compiledSpec.functionRegistry.resolveCall(
      call.name,
      positionalArgs.length,
    );
    if (functionResolution.matched) {
      return _executeUserFunction(
        functionResolution.entry!,
        positionalArgs,
        context,
        ruleLabel,
        currentEdge,
      );
    }
    if (functionResolution.arityMismatch) {
      throw RuntimeInterpreterException(
        "user function '${call.name}' expects "
        '${functionResolution.expectedArityDescriptions.join(" or ")} '
        'argument(s), '
        'got ${positionalArgs.length} in rule $ruleLabel',
      );
    }
    _validateLogicalHelperArity(call, helperName, context, ruleLabel);
    switch (helperName) {
      case 'return':
        final value = positionalArgs.isEmpty
            ? null
            : _evaluateExpression(
                positionalArgs.first,
                context,
                ruleLabel,
                currentEdge: currentEdge,
              );
        throw _ActionReturn(_copyValue(value));
      case 'return_undef':
        throw const _ActionReturn(null);
      case 'next':
        if (statementContext) {
          throw const _ActionNext();
        }
        return null;
      case 'if':
        return _callInlineIf(positionalArgs, context, ruleLabel, currentEdge);
      case 'switch':
        return _callInlineSwitch(
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'else':
      case 'elseif':
      case 'case':
      case 'default':
        return positionalArgs.isEmpty
            ? null
            : _evaluateExpression(
                positionalArgs.last,
                context,
                ruleLabel,
                currentEdge: currentEdge,
              );
      case 'set':
        return _callSet(
          positionalArgs,
          call.sourceSpan,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'push':
        return _callPush(
          positionalArgs,
          call.sourceSpan,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'array':
        return _callArray(positionalArgs, context, ruleLabel, currentEdge);
      case 'hash':
        return _callHash(positionalArgs, context, ruleLabel, currentEdge);
      case 'copy':
        if (positionalArgs.isEmpty) {
          return null;
        }
        return _copyArgument(
          positionalArgs.first,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'coalesce':
        return _callCoalesce(
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
          requireNonempty: false,
        );
      case 'coalesce_nonempty':
        return _callCoalesce(
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
          requireNonempty: true,
        );
      case 'split':
        return _callSplitFromExpressions(
          positionalArgs,
          call.sourceSpan,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'entry_slot':
        return context.gapEntrySlotValue(ruleLabel);
      case 'gap_span':
      case 'gap_text':
      case 'gap_kind':
        return _readGapContextHelper(helperName, context, ruleLabel);
      case 'entry_text':
        final match = context.registers.entryMatch;
        return match == null
            ? null
            : context.typedSpanTextFromCodeUnits(
                match.codeUnitStart,
                match.codeUnitEnd,
                ruleLabel,
                helperName,
              );
      case 'match_text':
        final match = context.registers.localMatch;
        return match == null
            ? null
            : context.typedSpanTextFromCodeUnits(
                match.codeUnitStart,
                match.codeUnitEnd,
                ruleLabel,
                helperName,
              );
      case 'entry_group':
        return _captureAt(
          context.registers.entryMatch,
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'match_group':
        return _captureAt(
          context.registers.localMatch,
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'entry_groups':
        return List<Object?>.unmodifiable(
          context.registers.entryMatch?.captures ?? const [],
        );
      case 'match_groups':
        return List<Object?>.unmodifiable(
          context.registers.localMatch?.captures ?? const [],
        );
      case 'entry_named':
        return _namedCapture(
          context.registers.entryMatch,
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'match_named':
        return _namedCapture(
          context.registers.localMatch,
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'entry_has':
        return _hasNamedCapture(
          context.registers.entryMatch,
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'match_has':
        return _hasNamedCapture(
          context.registers.localMatch,
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'entry_map':
        return Map<String, Object?>.unmodifiable(
          context.registers.entryMatch?.named ?? const <String, String>{},
        );
      case 'match_map':
        return Map<String, Object?>.unmodifiable(
          context.registers.localMatch?.named ?? const <String, String>{},
        );
      case 'entry_len':
        final match = context.registers.entryMatch;
        return match == null
            ? null
            : context.typedSpanLengthFromCodeUnits(
                match.codeUnitStart,
                match.codeUnitEnd,
                ruleLabel,
                helperName,
              );
      case 'match_len':
        final match = context.registers.localMatch;
        return match == null
            ? null
            : context.typedSpanLengthFromCodeUnits(
                match.codeUnitStart,
                match.codeUnitEnd,
                ruleLabel,
                helperName,
              );
      case 'entry_line':
      case 'entry_start_line':
        final start = context.registers.entryMatch?.codeUnitStart;
        return start == null
            ? 1
            : context.typedPositionLineFromCodeUnit(
                    start,
                    ruleLabel,
                    helperName,
                  ) ??
                  1;
      case 'entry_col':
      case 'entry_start_col':
        final start = context.registers.entryMatch?.codeUnitStart;
        return start == null
            ? 1
            : context.typedPositionColumnFromCodeUnit(
                    start,
                    ruleLabel,
                    helperName,
                  ) ??
                  1;
      case 'entry_end_line':
        final end = context.registers.entryMatch?.codeUnitEnd;
        return end == null
            ? 1
            : context.typedPositionLineFromCodeUnit(
                    end,
                    ruleLabel,
                    helperName,
                  ) ??
                  1;
      case 'entry_end_col':
        final end = context.registers.entryMatch?.codeUnitEnd;
        return end == null
            ? 1
            : context.typedPositionColumnFromCodeUnit(
                    end,
                    ruleLabel,
                    helperName,
                  ) ??
                  1;
      case 'match_line':
      case 'match_start_line':
        final start = context.registers.localMatch?.codeUnitStart;
        return start == null
            ? 1
            : context.typedPositionLineFromCodeUnit(
                    start,
                    ruleLabel,
                    helperName,
                  ) ??
                  1;
      case 'match_col':
      case 'match_start_col':
        final start = context.registers.localMatch?.codeUnitStart;
        return start == null
            ? 1
            : context.typedPositionColumnFromCodeUnit(
                    start,
                    ruleLabel,
                    helperName,
                  ) ??
                  1;
      case 'match_end_line':
        final end = context.registers.localMatch?.codeUnitEnd;
        return end == null
            ? 1
            : context.typedPositionLineFromCodeUnit(
                    end,
                    ruleLabel,
                    helperName,
                  ) ??
                  1;
      case 'match_end_col':
        final end = context.registers.localMatch?.codeUnitEnd;
        return end == null
            ? 1
            : context.typedPositionColumnFromCodeUnit(
                    end,
                    ruleLabel,
                    helperName,
                  ) ??
                  1;
      case 'entry_start_pos':
        final match = context.registers.entryMatch;
        return match == null
            ? null
            : context.typedSpanStartOffsetFromCodeUnits(
                match.codeUnitStart,
                match.codeUnitEnd,
                ruleLabel,
                helperName,
              );
      case 'entry_end_pos':
        final end = context.registers.entryMatch?.codeUnitEnd;
        return end == null
            ? null
            : context.typedPositionOffsetFromCodeUnit(
                end,
                ruleLabel,
                helperName,
              );
      case 'match_start_pos':
        final match = context.registers.localMatch;
        return match == null
            ? null
            : context.typedSpanStartOffsetFromCodeUnits(
                match.codeUnitStart,
                match.codeUnitEnd,
                ruleLabel,
                helperName,
              );
      case 'match_end_pos':
        final end = context.registers.localMatch?.codeUnitEnd;
        return end == null
            ? null
            : context.typedPositionOffsetFromCodeUnit(
                end,
                ruleLabel,
                helperName,
              );
      case 'cursor_pos':
        return context.typedPositionOffsetFromCodeUnit(
          context.cursorCodeUnit,
          ruleLabel,
          helperName,
        );
      case 'cursor_line':
        return context.typedPositionLineFromCodeUnit(
          context.cursorCodeUnit,
          ruleLabel,
          helperName,
        );
      case 'cursor_col':
        return context.typedPositionColumnFromCodeUnit(
          context.cursorCodeUnit,
          ruleLabel,
          helperName,
        );
      case 'cursor_rest':
        return context.typedSpanTextFromCodeUnits(
          context.cursorCodeUnit,
          context.input.length,
          ruleLabel,
          helperName,
        );
      case 'cursor_rest_len':
        return context.typedSpanLengthFromCodeUnits(
          context.cursorCodeUnit,
          context.input.length,
          ruleLabel,
          helperName,
        );
      case 'input_text':
        return context.typedSourceText(ruleLabel, helperName);
      case 'input_len':
        return context.typedSourceLength();
      case 'input_slice':
        return _callInputSlice(positionalArgs, context, ruleLabel, currentEdge);
      case 'input_end_pos':
        return context.typedPositionOffsetFromCodeUnit(
          context.input.length,
          ruleLabel,
          helperName,
        );
      case 'input_end_line':
        return context.typedPositionLineFromCodeUnit(
          context.input.length,
          ruleLabel,
          helperName,
        );
      case 'input_end_col':
        return context.typedPositionColumnFromCodeUnit(
          context.input.length,
          ruleLabel,
          helperName,
        );
      case 'start_capture_slice':
        context.startCaptureSlice(ruleLabel, helperName);
        return null;
      case 'capture_slice':
        return _captureSliceText(
          context,
          untilCursor: false,
          ruleLabel: ruleLabel,
          projection: helperName,
        );
      case 'capture_slice_len':
        return _captureSliceLength(
          context,
          untilCursor: false,
          ruleLabel: ruleLabel,
          projection: helperName,
        );
      case 'capture_slice_until_cursor':
        return _captureSliceText(
          context,
          untilCursor: true,
          ruleLabel: ruleLabel,
          projection: helperName,
        );
      case 'capture_slice_until_cursor_len':
        return _captureSliceLength(
          context,
          untilCursor: true,
          ruleLabel: ruleLabel,
          projection: helperName,
        );
      case 'capture_slice_pos':
        return context.typedPositionOffsetFromCodeUnit(
          _captureStartCodeUnit(context),
          ruleLabel,
          helperName,
        );
      case 'capture_slice_line':
        return context.typedPositionLineFromCodeUnit(
          _captureStartCodeUnit(context),
          ruleLabel,
          helperName,
        );
      case 'capture_slice_col':
        return context.typedPositionColumnFromCodeUnit(
          _captureStartCodeUnit(context),
          ruleLabel,
          helperName,
        );
      case 'start_capture_slice_from':
      case 'capture_rest':
      case 'capture_rest_len':
      case 'capture_take':
      case 'capture_take_len':
      case 'capture_take_until_cursor':
      case 'capture_take_until_cursor_len':
      case 'capture_take_rest':
      case 'capture_take_rest_len':
      case 'mark_here':
      case 'mark_input_start':
      case 'mark_input_end':
      case 'mark_entry_start':
      case 'mark_entry_end':
      case 'mark_match_start':
      case 'mark_match_end':
      case 'mark_copy':
      case 'mark_capture_slice':
      case 'mark_exists':
      case 'mark_pos':
      case 'mark_line':
      case 'mark_col':
      case 'clear_mark':
      case 'capture_from':
      case 'capture_len_from':
      case 'capture_until_cursor_from':
      case 'capture_until_cursor_len_from':
      case 'capture_rest_from':
      case 'capture_rest_len_from':
      case 'capture_take_len_from':
      case 'capture_take_until_cursor_from':
      case 'capture_take_until_cursor_len_from':
      case 'capture_take_rest_from':
      case 'capture_take_rest_len_from':
      case 'capture_between':
      case 'capture_len_between':
      case 'capture_take_between':
      case 'capture_take_between_len':
        return _callCaptureMarkHelper(
          helperName,
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'capture_until_boundary':
        return _callCaptureUntilBoundary(
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'save_cursor':
        final before = context.cursorCodeUnit;
        final stackBefore = context.cursorStack.length;
        context.saveCursor(ruleLabel, helperName);
        _traceCursorControl(
          context,
          ruleLabel,
          'save_cursor',
          before: before,
          stackBefore: stackBefore,
        );
        return null;
      case 'restore_cursor':
        final before = context.cursorCodeUnit;
        final stackBefore = context.cursorStack.length;
        context.restoreCursor(ruleLabel, helperName);
        _traceCursorControl(
          context,
          ruleLabel,
          'restore_cursor',
          before: before,
          stackBefore: stackBefore,
        );
        return null;
      case 'rewind_match_start':
        final before = context.cursorCodeUnit;
        final stackBefore = context.cursorStack.length;
        context.rewindToLocalMatchStart(ruleLabel, helperName);
        _traceCursorControl(
          context,
          ruleLabel,
          'rewind_match_start',
          before: before,
          stackBefore: stackBefore,
        );
        return null;
      case 'rewind_entry_start':
        final before = context.cursorCodeUnit;
        final stackBefore = context.cursorStack.length;
        context.rewindToEntryMatchStart(ruleLabel, helperName);
        _traceCursorControl(
          context,
          ruleLabel,
          'rewind_entry_start',
          before: before,
          stackBefore: stackBefore,
        );
        return null;
      case 'call':
        if (positionalArgs.isEmpty) {
          return null;
        }
        final targetLabel = _ruleNameFromExpr(
          positionalArgs.first,
          context,
          ruleLabel,
          currentEdge,
        );
        final targetIndex =
            currentEdge != null && currentEdge.target.label == targetLabel
            ? currentEdge.target.index
            : 0;
        final child =
            currentEdge != null && currentEdge.target.label == targetLabel
            ? _executeActionEdgeChild(currentEdge, context)
            : _executeRule(targetLabel, targetIndex, context);
        context.retv = child.value;
        return child.value;
      case 'and':
        return _callLogicalAnd(positionalArgs, context, ruleLabel, currentEdge);
      case 'or':
        return _callLogicalOr(positionalArgs, context, ruleLabel, currentEdge);
      case 'not':
        return _callLogicalNot(positionalArgs, context, ruleLabel, currentEdge);
      case 'print':
      case 'say':
        final values = _evaluateValues(
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
        final message = values.map(_diagnosticOutputFragment).join();
        _emitDiagnosticOutput(
          context,
          RuntimeDiagnosticOutputEvent(
            helperName: helperName,
            ruleLabel: ruleLabel,
            message: helperName == 'say' ? '$message\n' : message,
          ),
        );
        return null;
      case 'print_each':
        final values = _evaluateValues(
          positionalArgs,
          context,
          ruleLabel,
          currentEdge,
        );
        final target = values.first;
        if (target is! List) {
          return null;
        }
        final prefix = _diagnosticOutputFragment(values[1]);
        final suffix = values.length == 3
            ? _diagnosticOutputFragment(values[2])
            : '';
        for (final item in target) {
          _emitDiagnosticOutput(
            context,
            RuntimeDiagnosticOutputEvent(
              helperName: helperName,
              ruleLabel: ruleLabel,
              message: '$prefix${_diagnosticOutputFragment(item)}$suffix',
            ),
          );
        }
        return null;
      case 'exit_now':
        final status = positionalArgs.isEmpty
            ? 1
            : _intValue(
                    _evaluateExpression(
                      positionalArgs.first,
                      context,
                      ruleLabel,
                      currentEdge: currentEdge,
                    ),
                  ) ??
                  1;
        throw RuntimeExitNow(status);
      default:
        if (_runtimeArrayHelperNames.contains(helperName)) {
          return _callArrayHelperFromExpressions(
            helperName,
            positionalArgs,
            context,
            ruleLabel,
            currentEdge,
          );
        }
        if (_runtimeHashHelperNames.contains(helperName)) {
          return _callHashHelperFromExpressions(
            helperName,
            positionalArgs,
            context,
            ruleLabel,
            currentEdge,
          );
        }
        if (_runtimePureHelperNames.contains(helperName)) {
          return _callPureHelper(
            helperName,
            _evaluatePureHelperValues(
              helperName,
              positionalArgs,
              context,
              ruleLabel,
              currentEdge,
            ),
          );
        }
        if (_hasRuntimeBinding(context, call.name)) {
          final value = _runtimeBindingValue(context, call.name);
          final codeblock = _decodeRuntimeCodeblock(value);
          if (codeblock == null) {
            final valueKind = _runtimeCallableValueKind(value);
            final detail =
                'value_not_callable callable_name="${call.name}" '
                'value_kind="$valueKind" rule_label="$ruleLabel"';
            throw RuntimeInterpreterException(
              detail,
              diagnostic: context.diagnostic(
                stage: 'callable_codeblock_invocation',
                summary: 'Dart callable codeblock invocation failed',
                detail: detail,
                code: 'value_not_callable',
                callableName: call.name,
                valueKind: valueKind,
                ruleLabel: ruleLabel,
                handlerSourceLabel: 'dart_runtime:codeblock:${call.name}',
              ),
            );
          }
          final keywordCount = call.args
              .whereType<ActionKeywordArgument>()
              .length;
          if (keywordCount > 0) {
            const expected = 'positional arguments';
            final detail =
                'codeblock_keyword_arguments_unsupported '
                'callable_name="${call.name}" expected="$expected" '
                'got=$keywordCount rule_label="$ruleLabel"';
            throw RuntimeInterpreterException(
              detail,
              diagnostic: context.diagnostic(
                stage: 'callable_codeblock_invocation',
                summary: 'Dart callable codeblock invocation failed',
                detail: detail,
                code: 'codeblock_keyword_arguments_unsupported',
                callableName: call.name,
                expected: expected,
                got: keywordCount,
                ruleLabel: ruleLabel,
                handlerSourceLabel: 'dart_runtime:codeblock:${call.name}',
              ),
            );
          }
          return _executeCodeblockValue(
            call.name,
            codeblock,
            positionalArgs,
            context,
            ruleLabel,
            currentEdge,
          );
        }
        final detail =
            'unknown_helper name="${call.name}" rule_label="$ruleLabel"';
        throw RuntimeInterpreterException(
          detail,
          diagnostic: context.diagnostic(
            stage: 'callable_codeblock_invocation',
            summary: 'Dart callable codeblock invocation failed',
            detail: detail,
            code: 'unknown_helper',
            name: call.name,
            ruleLabel: ruleLabel,
          ),
        );
    }
  }

  _RuntimeCodeblockValue _requireFinalCodeblockValue(
    String callableName,
    Object? value,
    _RuntimeExecutionContext context,
    String ruleLabel,
  ) {
    final codeblock = _decodeRuntimeCodeblock(value);
    if (codeblock != null) {
      return codeblock;
    }
    final valueKind = _runtimeCallableValueKind(value);
    final detail =
        'final_argument_not_codeblock callable_name="$callableName" '
        'value_kind="$valueKind" rule_label="$ruleLabel"';
    throw RuntimeInterpreterException(
      detail,
      diagnostic: context.diagnostic(
        stage: 'callable_codeblock_invocation',
        summary: 'Dart final codeblock argument validation failed',
        detail: detail,
        code: 'final_argument_not_codeblock',
        callableName: callableName,
        valueKind: valueKind,
        ruleLabel: ruleLabel,
        handlerSourceLabel: 'dart_runtime:codeblock:$callableName',
      ),
    );
  }

  Object? _executeCodeblockValue(
    String name,
    _RuntimeCodeblockValue codeblock,
    List<ActionExpr> argExprs,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge, {
    List<Object?>? evaluatedValues,
  }) {
    final values =
        evaluatedValues ??
        [
          for (final arg in argExprs)
            _copyValue(
              _evaluateExpression(
                arg,
                context,
                ruleLabel,
                currentEdge: currentEdge,
              ),
            ),
        ];
    final arityMatches =
        values.length >= codeblock.minArity &&
        (codeblock.maxArity == null || values.length <= codeblock.maxArity!);
    if (!arityMatches) {
      final expected = codeblock.maxArity == codeblock.minArity
          ? 'exactly ${codeblock.minArity}'
          : 'at least ${codeblock.minArity}';
      final detail =
          'codeblock_arity_mismatch callable_name="$name" '
          'expected="$expected" got=${values.length} '
          'rule_label="$ruleLabel"';
      throw RuntimeInterpreterException(
        detail,
        diagnostic: context.diagnostic(
          stage: 'callable_codeblock_invocation',
          summary: 'Dart callable codeblock invocation failed',
          detail: detail,
          code: 'codeblock_arity_mismatch',
          callableName: name,
          expected: expected,
          got: values.length,
          ruleLabel: ruleLabel,
          handlerSourceLabel: 'dart_runtime:codeblock:$name',
        ),
      );
    }

    final activeIndex = context.activeCodeblocks.indexOf(name);
    if (activeIndex >= 0) {
      final cycle = [...context.activeCodeblocks.sublist(activeIndex), name];
      final detail =
          'codeblock_recursion_unsupported callable_name="$name" '
          'cycle=$cycle rule_label="$ruleLabel"';
      throw RuntimeInterpreterException(
        detail,
        diagnostic: context.diagnostic(
          stage: 'callable_codeblock_invocation',
          summary: 'Dart callable codeblock invocation failed',
          detail: detail,
          code: 'codeblock_recursion_unsupported',
          callableName: name,
          cycle: cycle,
          ruleLabel: ruleLabel,
          handlerSourceLabel: 'dart_runtime:codeblock:$name',
        ),
      );
    }

    final body = _codeblockBodyCache.putIfAbsent(
      codeblock.sourceText,
      () => parseActionBlock(codeblock.bodySource),
    );
    final bindings = <_ScopedVariableBinding>[];
    context.activeCodeblocks.add(name);
    try {
      for (
        var index = 0;
        index < codeblock.positionalParams.length;
        index += 1
      ) {
        bindings.add(
          context.enterScopedScalar(
            codeblock.positionalParams[index],
            values[index],
          ),
        );
      }
      final restParam = codeblock.restParam;
      if (restParam != null) {
        bindings.add(
          context.enterScopedScalar(
            restParam,
            values.sublist(codeblock.minArity),
          ),
        );
      }
      final flow = _executeValueBlockStatements(
        body,
        context,
        ruleLabel,
        currentEdge,
        finalExpressionYields: true,
      );
      return flow.returned ? _copyValue(flow.value) : null;
    } finally {
      for (final binding in bindings.reversed) {
        context.exitScopedVariable(binding);
      }
      context.activeCodeblocks.removeLast();
    }
  }

  Object? _executeUserFunction(
    UserFunctionEntry entry,
    List<ActionExpr> argExprs,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final values = [
      for (final arg in argExprs)
        _copyValue(
          _evaluateExpression(
            arg,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
        ),
    ];
    if (!entry.acceptsArity(values.length)) {
      throw RuntimeInterpreterException(
        "user function '${entry.name}' expects ${entry.arityExpectation} "
        'argument(s), '
        'got ${values.length} in rule $ruleLabel',
      );
    }
    if (entry.parameterKinds.isNotEmpty) {
      _requireFinalCodeblockValue(entry.name, values.last, context, ruleLabel);
    }

    final activeIndex = context.activeUserFunctions.indexOf(entry.name);
    if (activeIndex >= 0) {
      final cycle = [
        ...context.activeUserFunctions.sublist(activeIndex),
        entry.name,
      ].join(' -> ');
      final detail =
          "user function recursion is not supported: $cycle in rule "
          '$ruleLabel';
      throw RuntimeInterpreterException(
        detail,
        diagnostic: context.diagnostic(
          stage: 'user_function_call',
          summary: 'Dart user function recursion failed',
          detail: detail,
          ruleLabel: ruleLabel,
          handlerSourceLabel: 'dart_runtime:function:${entry.name}',
        ),
      );
    }

    final block = _userFunctionBodyBlock(entry, ruleLabel, context);
    final snapshot = _RuntimeStoreSnapshot.capture(context);
    context.activeUserFunctions.add(entry.name);
    context.suspendRuleLocalBindingTracking();
    context.clearStores();
    for (var index = 0; index < entry.params.length; index += 1) {
      context.bindUserFunctionParam(entry.params[index], values[index]);
    }
    final signature = entry.signature;
    if (signature != null) {
      context.bindUserFunctionParam(
        signature.restParam!,
        values.sublist(signature.minArity),
      );
    }

    try {
      final flow = _executeValueBlockStatements(
        block,
        context,
        ruleLabel,
        currentEdge,
        finalExpressionYields: true,
      );
      return flow.returned ? _copyValue(flow.value) : null;
    } finally {
      context.resumeRuleLocalBindingTracking();
      snapshot.restore(context);
      context.activeUserFunctions.removeLast();
    }
  }

  ActionBlock _userFunctionBodyBlock(
    UserFunctionEntry entry,
    String ruleLabel,
    _RuntimeExecutionContext context,
  ) {
    final cached = _userFunctionBodyCache[entry.index];
    if (cached != null) {
      return cached;
    }
    try {
      final parsed = parseActionBlock(entry.bodySource);
      normalizeActionBlockFinalCodeblocks(
        parsed,
        compiledSpec.functionRegistry,
      );
      _userFunctionBodyCache[entry.index] = parsed;
      return parsed;
    } catch (error) {
      final detail =
          "user function '${entry.name}' body parse failed in rule "
          '$ruleLabel: $error';
      throw RuntimeInterpreterException(
        detail,
        diagnostic: context.diagnostic(
          stage: 'user_function_body_parse',
          summary: 'Dart user function body parse failed',
          detail: detail,
          ruleLabel: ruleLabel,
          handlerSourceLabel: 'dart_runtime:function:${entry.name}',
        ),
      );
    }
  }

  Object? _evaluateFluentCall(
    Object? receiver,
    ActionFluentCall call,
    _RuntimeExecutionContext context,
    String ruleLabel, {
    required _CurrentActionEdge? currentEdge,
  }) {
    final helperName = canonicalActionHelperName(call.method);
    if (helperName == 'with') {
      return _callReceiverWithCodeblock(
        receiver,
        call,
        context,
        ruleLabel,
        currentEdge,
      );
    }
    if (_treeTraversalHelperNames.contains(helperName)) {
      return _callTreeTraversalTrailingBlock(
        receiver,
        call,
        context,
        ruleLabel,
        currentEdge,
      );
    }
    switch (helperName) {
      case 'copy':
        return _copyValue(receiver);
      case 'coalesce':
        return _callCoalesceWithReceiver(
          receiver,
          call.args,
          context,
          ruleLabel,
          currentEdge,
          requireNonempty: false,
        );
      case 'coalesce_nonempty':
        return _callCoalesceWithReceiver(
          receiver,
          call.args,
          context,
          ruleLabel,
          currentEdge,
          requireNonempty: true,
        );
      case 'split':
        return _callSplitWithReceiver(
          receiver,
          call.args,
          context,
          ruleLabel,
          currentEdge,
        );
      case 'push_back':
      case 'push_front':
      case 'pop_back':
      case 'pop_front':
        return null;
      default:
        if (helperName == 'join_values') {
          final values = _evaluateArgumentValues(
            call.args,
            context,
            ruleLabel,
            currentEdge,
          );
          return _callArrayHelper(helperName, [
            values.isEmpty ? '' : values.first,
            receiver,
          ]);
        }
        if (_runtimeArrayHelperNames.contains(helperName)) {
          return _callArrayHelper(helperName, [
            receiver,
            ..._evaluateArgumentValues(
              call.args,
              context,
              ruleLabel,
              currentEdge,
            ),
          ]);
        }
        if (_runtimeHashHelperNames.contains(helperName)) {
          return _callHashHelper(helperName, [
            receiver,
            ..._evaluateArgumentValues(
              call.args,
              context,
              ruleLabel,
              currentEdge,
            ),
          ]);
        }
        if (_runtimeReceiverHelperNames.contains(helperName)) {
          return _callPureHelper(helperName, [
            receiver,
            ..._evaluateArgumentValues(
              call.args,
              context,
              ruleLabel,
              currentEdge,
            ),
          ]);
        }
        throw RuntimeInterpreterException(
          "unsupported runtime fluent method '.${call.method}' in rule $ruleLabel",
        );
    }
  }

  Object? _callSet(
    List<ActionExpr> args,
    ActionSourceSpan callSpan,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (args.length < 2) {
      return null;
    }
    final variableTarget = _variableName(args[0]);
    if (variableTarget == null) {
      throw RuntimeInterpreterException(
        'set target in rule $ruleLabel must be a variable',
      );
    }
    _assertReceiverMutationWritable(
      context,
      variableTarget,
      'helper:set',
      callSpan,
    );
    final value = _copyValue(
      _evaluateExpression(
        args[1],
        context,
        ruleLabel,
        currentEdge: currentEdge,
      ),
    );
    context.ensureBindingIdentity(variableTarget);
    context.variables[variableTarget] = value;
    context.arrays.remove(variableTarget);
    context.hashes.remove(variableTarget);
    return _copyValue(value);
  }

  bool _executeArrayStringTransformStatement(
    ActionCallExpr call,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final helperName = canonicalActionHelperName(call.name);
    final args = call.args.map((arg) => arg.value).toList();
    final expectedArity = switch (helperName) {
      'trim_each' ||
      'filter_nonempty' ||
      'lowercase_each' ||
      'uppercase_each' ||
      'uniq' => 1,
      'split_each' || 'filter_match' => 2,
      _ => null,
    };
    if (expectedArity == null || args.length != expectedArity) {
      return false;
    }
    final bareTarget = _variableName(args.first);
    if (bareTarget == null) {
      return false;
    }
    _assertReceiverMutationWritable(
      context,
      bareTarget,
      'helper:$helperName',
      call.sourceSpan,
    );
    if (!const {
      'trim_each',
      'filter_nonempty',
      'lowercase_each',
      'uppercase_each',
    }.contains(helperName)) {
      // FUTURE-PARITY-BACKLOG.5 owns Dart write-back for split_each,
      // filter_match, and uniq. They are still binding-target mutation
      // attempts for active-receiver guard precedence, but their ordinary
      // behavior remains unchanged until that separately owned repair.
      return false;
    }
    final transformed = _callArrayHelperFromExpressions(
      helperName,
      args,
      context,
      ruleLabel,
      currentEdge,
    );
    _replaceBareArrayValue(context, bareTarget, _asArray(transformed));
    return true;
  }

  Object? _callPush(
    List<ActionExpr> args,
    ActionSourceSpan callSpan,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (args.isEmpty) {
      _assertReceiverMutationWritable(
        context,
        ruleLabel,
        'helper:push',
        callSpan,
      );
      final child = _requireCurrentEdgeChild(currentEdge, context, ruleLabel);
      return _appendArrayValue(context, ruleLabel, child.value);
    }

    if (args.length == 1 && currentEdge != null) {
      final childRule = _variableName(args[0]);
      if (childRule != null && compiledSpec.rule(childRule) != null) {
        _assertReceiverMutationWritable(
          context,
          ruleLabel,
          'helper:push',
          callSpan,
        );
        final child = childRule == currentEdge.target.label
            ? _executeActionEdgeChild(currentEdge, context)
            : _executeRule(childRule, 0, context);
        context.retv = child.value;
        return _appendArrayValue(context, ruleLabel, child.value);
      }
      final target = _variableName(args[0]);
      if (target == null) {
        throw RuntimeInterpreterException(
          'push target in rule $ruleLabel must be a variable',
        );
      }
      _assertReceiverMutationWritable(context, target, 'helper:push', callSpan);
      final child = _executeActionEdgeChild(currentEdge, context);
      context.retv = child.value;
      return _appendArrayValue(context, target, child.value);
    }

    if (args.length >= 2) {
      final firstName = _variableName(args[0]);
      final secondTarget = _variableName(args[1]);
      if (currentEdge != null &&
          firstName != null &&
          compiledSpec.rule(firstName) != null) {
        final childIndex = _literalNonNegativeInteger(args[1]);
        if (secondTarget != null || childIndex != null) {
          final target = secondTarget ?? ruleLabel;
          _assertReceiverMutationWritable(
            context,
            target,
            'helper:push',
            callSpan,
          );
          final child = firstName == currentEdge.target.label
              ? _executeActionEdgeChild(currentEdge, context)
              : _executeRule(firstName, 0, context);
          context.retv = child.value;
          if (secondTarget != null) {
            return _appendArrayValue(context, secondTarget, child.value);
          }
          return _appendArrayValue(
            context,
            ruleLabel,
            _indexValue(child.value, childIndex),
          );
        }
      }

      final target = _variableName(args[0]);
      if (target == null) {
        throw RuntimeInterpreterException(
          'push target in rule $ruleLabel must be a variable',
        );
      }
      _assertReceiverMutationWritable(context, target, 'helper:push', callSpan);
      final value = _copyValue(
        _evaluateExpression(
          args[1],
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
      );
      return _appendArrayValue(context, target, value);
    }

    return null;
  }

  Object? _callArray(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final values = <Object?>[];
    for (final arg in args) {
      final value = _evaluateExpression(
        arg,
        context,
        ruleLabel,
        currentEdge: currentEdge,
      );
      if (_isArraySpliceArgument(arg)) {
        _appendArraySpliceValue(values, value);
      } else {
        values.add(_copyValue(value));
      }
    }
    return values;
  }

  Object? _callHash(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final entries = <String, Object?>{};
    final values = [
      for (final arg in args)
        _evaluateExpression(arg, context, ruleLabel, currentEdge: currentEdge),
    ];
    for (var index = 0; index + 1 < values.length; index += 2) {
      final key = _stringValue(values[index]);
      final value = _copyValue(values[index + 1]);
      entries[key] = value;
    }
    for (final (index, value) in values.indexed) {
      if (_isHashSpliceArgument(args[index]) && value is Map) {
        for (final entry in _asHash(value).entries) {
          entries[entry.key] = _copyValue(entry.value);
        }
      }
    }
    return entries;
  }

  Object? _callInputSlice(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (args.isEmpty) {
      return context.typedSourceText(ruleLabel, 'input_slice');
    }
    final start = _nonNegativeInt(
      _evaluateExpression(
        args[0],
        context,
        ruleLabel,
        currentEdge: currentEdge,
      ),
      0,
    );
    final width = args.length >= 2
        ? _nonNegativeInt(
            _evaluateExpression(
              args[1],
              context,
              ruleLabel,
              currentEdge: currentEdge,
            ),
            context.input.runes.length,
          )
        : context.input.runes.length - start;
    return context.typedSourceSlice(start, width, ruleLabel, 'input_slice');
  }

  List<Object?> _evaluateValues(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    return [
      for (final arg in args)
        _evaluateExpression(arg, context, ruleLabel, currentEdge: currentEdge),
    ];
  }

  void _validateDiagnosticOutputArity(
    ActionCallExpr call,
    String helperName,
    _RuntimeExecutionContext context,
    String ruleLabel,
  ) {
    final expected = switch (helperName) {
      'print' || 'say' => 'at least 1 positional argument',
      'print_each' => '2 or 3 positional arguments',
      _ => null,
    };
    if (expected == null) {
      return;
    }

    final positionalCount = call.args
        .whereType<ActionPositionalArgument>()
        .length;
    final allPositional = positionalCount == call.args.length;
    final validCount = switch (helperName) {
      'print' || 'say' => positionalCount >= 1,
      'print_each' => positionalCount == 2 || positionalCount == 3,
      _ => true,
    };
    if (allPositional && validCount) {
      return;
    }

    final message =
        "helper '$helperName' expects $expected, got $positionalCount "
        'in rule $ruleLabel';
    throw RuntimeInterpreterException(
      message,
      diagnostic: context.diagnostic(
        stage: 'helper_arity_mismatch',
        summary: 'Dart runtime helper arity mismatch',
        detail: message,
        ruleLabel: ruleLabel,
      ),
    );
  }

  void _validateLogicalHelperArity(
    ActionCallExpr call,
    String helperName,
    _RuntimeExecutionContext context,
    String ruleLabel,
  ) {
    final expected = switch (helperName) {
      'and' || 'or' => 'at least 1 positional argument',
      'not' => 'exactly 1 positional argument',
      _ => null,
    };
    if (expected == null) {
      return;
    }

    final positionalCount = call.args
        .whereType<ActionPositionalArgument>()
        .length;
    final allPositional = positionalCount == call.args.length;
    final validCount = switch (helperName) {
      'and' || 'or' => positionalCount >= 1,
      'not' => positionalCount == 1,
      _ => true,
    };
    if (allPositional && validCount) {
      return;
    }

    final message =
        'helper_arity_mismatch helper_name=$helperName '
        'actual_arity=$positionalCount expected_arity="$expected" '
        'rule_label=$ruleLabel';
    throw RuntimeInterpreterException(
      message,
      diagnostic: context.diagnostic(
        stage: 'helper_arity_mismatch',
        summary: 'Dart runtime logical-helper arity mismatch',
        detail: message,
        code: 'helper_arity_mismatch',
        helperName: helperName,
        actualArity: positionalCount,
        expectedArity: expected,
        ruleLabel: ruleLabel,
        handlerSourceLabel: 'dart_runtime:helper:$helperName',
      ),
    );
  }

  void _emitDiagnosticOutput(
    _RuntimeExecutionContext context,
    RuntimeDiagnosticOutputEvent event,
  ) {
    final sink = context.diagnosticOutputSink;
    if (sink == null) {
      return;
    }
    try {
      sink(event);
    } on Object catch (error, stackTrace) {
      throw _RuntimeDiagnosticOutputSinkFailure(error, stackTrace);
    }
  }

  List<Object?> _evaluateArgumentValues(
    List<ActionArgument> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    return [
      for (final arg in args)
        _evaluateExpression(
          arg.value,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
    ];
  }

  Object? _evaluateFluentReceiver(
    ActionExpr receiver,
    String helperName,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final receiverName = _variableName(receiver);
    if (receiverName != null) {
      if (_treeTraversalHelperNames.contains(helperName)) {
        if (_hasHashValue(context, receiverName)) {
          return Map<String, Object?>.unmodifiable(
            _hashValueFor(context, receiverName),
          );
        }
        if (_hasArrayValue(context, receiverName)) {
          return List<Object?>.unmodifiable(
            _arrayValueFor(context, receiverName),
          );
        }
      }
      if ((helperName == 'copy' || helperName == 'flat') &&
          _hasArrayValue(context, receiverName)) {
        return List<Object?>.unmodifiable(
          _arrayValueFor(context, receiverName),
        );
      }
      if ((helperName == 'copy' || helperName == 'flat') &&
          _hasHashValue(context, receiverName)) {
        return Map<String, Object?>.unmodifiable(
          _hashValueFor(context, receiverName),
        );
      }
      if (_arrayOnlyReceiverHelpers.contains(helperName)) {
        return List<Object?>.unmodifiable(
          _arrayValueFor(context, receiverName),
        );
      }
      if (_arrayPreferredReceiverHelpers.contains(helperName) &&
          _hasArrayValue(context, receiverName)) {
        return List<Object?>.unmodifiable(
          _arrayValueFor(context, receiverName),
        );
      }
      if (_hashOnlyReceiverHelpers.contains(helperName)) {
        return Map<String, Object?>.unmodifiable(
          _hashValueFor(context, receiverName),
        );
      }
      if (_hashPreferredReceiverHelpers.contains(helperName) &&
          _hasHashValue(context, receiverName)) {
        return Map<String, Object?>.unmodifiable(
          _hashValueFor(context, receiverName),
        );
      }
    }
    return _evaluateExpression(
      receiver,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
  }

  bool _executeArrayEndMutationStatement(
    ActionFluentChainExpr expr,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (expr.calls.length != 1) {
      return false;
    }
    final call = expr.calls.single;
    return _evaluateArrayEndMutationCall(
          expr.receiver,
          call,
          context,
          ruleLabel,
          currentEdge,
        ) !=
        null;
  }

  List<Object?>? _evaluateArrayEndMutationCall(
    ActionExpr receiver,
    ActionFluentCall call,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final bareTarget = _variableName(receiver);
    if (bareTarget == null) {
      return null;
    }
    final target = bareTarget;
    final mutationSpan = ActionSourceSpan(
      start: receiver.sourceSpan.start,
      end: call.sourceSpan.end,
    );
    switch (call.method) {
      case 'push_back':
      case 'push_front':
        if (call.args.length != 1) {
          return null;
        }
        _assertReceiverMutationWritable(
          context,
          target,
          call.method,
          mutationSpan,
        );
        final value = _copyValue(
          _evaluateExpression(
            call.args.single.value,
            context,
            ruleLabel,
            currentEdge: currentEdge,
          ),
        );
        final array = _bareArrayForMutation(context, target);
        if (call.method == 'push_back') {
          array.add(value);
        } else {
          array.insert(0, value);
        }
        return _storeBareArray(context, target, array);
      case 'pop_back':
      case 'pop_front':
        if (call.args.isNotEmpty) {
          return null;
        }
        _assertReceiverMutationWritable(
          context,
          target,
          call.method,
          mutationSpan,
        );
        final array = _bareArrayForMutation(context, target);
        if (array.isNotEmpty) {
          if (call.method == 'pop_back') {
            array.removeLast();
          } else {
            array.removeAt(0);
          }
        }
        return _storeBareArray(context, target, array);
      default:
        return null;
    }
  }

  bool _executeSetKeyStatement(
    ActionCallExpr call,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (canonicalActionHelperName(call.name) != 'set_key') {
      return false;
    }
    var args = call.args.map((arg) => arg.value).toList();
    if (args.length == 4 && _variableName(args.first) != null) {
      args = args.sublist(1);
    }
    if (args.length != 3) {
      return false;
    }
    final bareTarget = _variableName(args[0]);
    if (bareTarget == null || bareTarget.isEmpty) {
      return false;
    }
    final target = bareTarget;
    _assertReceiverMutationWritable(
      context,
      target,
      'helper:set_key',
      call.sourceSpan,
    );
    final key = _stringValue(
      _evaluateExpression(
        args[1],
        context,
        ruleLabel,
        currentEdge: currentEdge,
      ),
    );
    final value = _copyValue(
      _evaluateExpression(
        args[2],
        context,
        ruleLabel,
        currentEdge: currentEdge,
      ),
    );
    _setBareHashEntry(context, target, key, value);
    return true;
  }

  bool _executeRegexSubstitutionStatement(
    ActionCallExpr call,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final helperName = canonicalActionHelperName(call.name);
    if (helperName != 'substr' && helperName != 'regex_subst') {
      return false;
    }
    final args = call.args.map((arg) => arg.value).toList();
    if (args.length < 3) {
      return false;
    }
    final target = _scalarTargetName(args[0]);
    if (target == null || target.isEmpty) {
      return false;
    }
    _assertReceiverMutationWritable(
      context,
      target,
      'helper:$helperName',
      call.sourceSpan,
    );
    final source = _scalarString(context.variables[target], nullAsEmpty: true);
    if (source == null) {
      return false;
    }
    final patternValue = _evaluatePatternArgument(
      args[1],
      context,
      ruleLabel,
      currentEdge,
    );
    final pattern = patternValue is _RuntimeRegexPattern
        ? patternValue.pattern
        : _scalarString(patternValue);
    if (pattern == null) {
      return false;
    }
    final replacement = args[2] is ActionRegexLiteralExpr
        ? (args[2] as ActionRegexLiteralExpr).pattern
        : (_scalarString(
                _evaluateExpression(
                  args[2],
                  context,
                  ruleLabel,
                  currentEdge: currentEdge,
                ),
                nullAsEmpty: true,
              ) ??
              '');
    final flags = args.length >= 4
        ? _regexFlagString(args[3], context, ruleLabel, currentEdge)
        : '';
    final regex = _compileRegex(pattern, flags: flags);
    if (regex == null) {
      return false;
    }
    final updated = _replaceRegex(
      source,
      regex,
      replacement,
      global: flags.contains('g'),
    );
    context.ensureBindingIdentity(target);
    context.variables[target] = updated;
    context.arrays.remove(target);
    context.hashes.remove(target);
    return true;
  }

  Object? _callSplitFromExpressions(
    List<ActionExpr> args,
    ActionSourceSpan callSpan,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final bareTarget = args.length >= 3 ? _variableName(args.first) : null;
    if (bareTarget != null) {
      _assertReceiverMutationWritable(
        context,
        bareTarget,
        'helper:split',
        callSpan,
      );
      final source = _evaluateExpression(
        args[1],
        context,
        ruleLabel,
        currentEdge: currentEdge,
      );
      final delimiterExpr = args.length >= 3 ? args[2] : null;
      final delimiter = delimiterExpr == null
          ? ''
          : _evaluateExpression(
              delimiterExpr,
              context,
              ruleLabel,
              currentEdge: currentEdge,
            );
      final parts = _splitStringValue(
        source,
        delimiter,
        regexDelimiter: delimiterExpr is ActionRegexLiteralExpr,
      );
      return _replaceBareArrayValue(context, bareTarget, parts);
    }

    final values = _evaluateValues(args, context, ruleLabel, currentEdge);
    return _callSplit(
      values,
      regexDelimiter: args.length >= 2 && args[1] is ActionRegexLiteralExpr,
    );
  }

  Object? _callSplitWithReceiver(
    Object? receiver,
    List<ActionArgument> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (args.isEmpty) {
      return null;
    }
    final delimiterExpr = args.first.value;
    final delimiter = _evaluateExpression(
      delimiterExpr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
    return _splitStringValue(
      receiver,
      delimiter,
      regexDelimiter: delimiterExpr is ActionRegexLiteralExpr,
    );
  }

  Object? _callArrayHelperFromExpressions(
    String helperName,
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    return _callArrayHelper(
      helperName,
      _evaluateArrayHelperValues(
        helperName,
        args,
        context,
        ruleLabel,
        currentEdge,
      ),
    );
  }

  List<Object?> _evaluateArrayHelperValues(
    String helperName,
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    Object? evaluate(ActionExpr arg) =>
        _evaluateExpression(arg, context, ruleLabel, currentEdge: currentEdge);
    Object? arrayArg(int index) => index < args.length
        ? _evaluateArrayArgument(args[index], context, ruleLabel, currentEdge)
        : null;
    Object? maybeArrayArg(int index) => index < args.length
        ? _evaluateMaybeArrayArgument(
            args[index],
            context,
            ruleLabel,
            currentEdge,
          )
        : null;

    return switch (helperName) {
      'count' || 'is_empty' || 'is_nonempty' => [maybeArrayArg(0)],
      'first' ||
      'last' ||
      'sorted' ||
      'reversed' ||
      'trim_each' ||
      'filter_nonempty' ||
      'lowercase_each' ||
      'uppercase_each' ||
      'uniq' => [arrayArg(0)],
      'take' ||
      'take_last' ||
      'drop_front' ||
      'drop_back' ||
      'contains' ||
      'index_of' => [
        arrayArg(0),
        for (final arg in args.skip(1)) evaluate(arg),
      ],
      'filter_match' || 'split_each' => [
        arrayArg(0),
        if (args.length >= 2)
          _evaluatePatternArgument(args[1], context, ruleLabel, currentEdge),
      ],
      'slice' => [arrayArg(0), for (final arg in args.skip(1)) evaluate(arg)],
      'join_values' => [
        args.isEmpty ? '' : evaluate(args[0]),
        args.length >= 2 ? arrayArg(1) : <Object?>[],
      ],
      'flat' => [if (args.isNotEmpty) maybeArrayArg(0)],
      'flat_array' || 'concat_arrays' => [
        for (final arg in args)
          _evaluateMaybeArrayArgument(arg, context, ruleLabel, currentEdge),
      ],
      'split_tagged_records' => [
        if (args.isNotEmpty) evaluate(args[0]),
        if (args.length >= 2)
          _evaluatePatternArgument(args[1], context, ruleLabel, currentEdge),
        for (final arg in args.skip(2)) evaluate(arg),
      ],
      _ => [for (final arg in args) evaluate(arg)],
    };
  }

  Object? _callHashHelperFromExpressions(
    String helperName,
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    return _callHashHelper(
      helperName,
      _evaluateHashHelperValues(
        helperName,
        args,
        context,
        ruleLabel,
        currentEdge,
      ),
    );
  }

  List<Object?> _evaluateHashHelperValues(
    String helperName,
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    Object? evaluate(ActionExpr arg) =>
        _evaluateExpression(arg, context, ruleLabel, currentEdge: currentEdge);
    Object? hashArg(int index) => index < args.length
        ? _evaluateHashArgument(args[index], context, ruleLabel, currentEdge)
        : null;
    Object? maybeHashArg(int index) => index < args.length
        ? _evaluateMaybeHashArgument(
            args[index],
            context,
            ruleLabel,
            currentEdge,
          )
        : null;

    return switch (helperName) {
      'merge_hash' => [
        if (args.isNotEmpty) evaluate(args[0]),
        for (var index = 1; index < args.length; index += 1)
          maybeHashArg(index),
      ],
      'flat_hash' => [
        for (var index = 0; index < args.length; index += 1)
          maybeHashArg(index),
      ],
      'count_keys' || 'sorted_keys' || 'sorted_values' => [hashArg(0)],
      'has_key' || 'set_key' || 'rename_key' || 'drop_keys' || 'pick_keys' => [
        hashArg(0),
        for (final arg in args.skip(1)) evaluate(arg),
      ],
      _ => [for (final arg in args) evaluate(arg)],
    };
  }

  Object? _evaluateArrayArgument(
    ActionExpr arg,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final name = _variableName(arg);
    if (name != null) {
      return List<Object?>.unmodifiable(_arrayValueFor(context, name));
    }
    return _evaluateExpression(
      arg,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
  }

  Object? _evaluateMaybeArrayArgument(
    ActionExpr arg,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final name = _variableName(arg);
    if (name != null && _hasArrayValue(context, name)) {
      return List<Object?>.unmodifiable(_arrayValueFor(context, name));
    }
    return _evaluateExpression(
      arg,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
  }

  Object? _evaluateHashArgument(
    ActionExpr arg,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final name = _variableName(arg);
    if (name != null) {
      return Map<String, Object?>.unmodifiable(_hashValueFor(context, name));
    }
    return _evaluateExpression(
      arg,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
  }

  Object? _evaluateMaybeHashArgument(
    ActionExpr arg,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final name = _variableName(arg);
    if (name != null && _hasHashValue(context, name)) {
      return Map<String, Object?>.unmodifiable(_hashValueFor(context, name));
    }
    return _evaluateExpression(
      arg,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
  }

  Object? _evaluatePatternArgument(
    ActionExpr arg,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (arg is ActionRegexLiteralExpr) {
      return _RuntimeRegexPattern(arg.pattern);
    }
    return _evaluateExpression(
      arg,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    );
  }

  List<Object?> _evaluatePureHelperValues(
    String helperName,
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (_numericAggregateHelperNames.contains(helperName) && args.length == 1) {
      return [_copyArgument(args.first, context, ruleLabel, currentEdge)];
    }
    return _evaluateValues(args, context, ruleLabel, currentEdge);
  }

  Object? _callCoalesce(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge, {
    required bool requireNonempty,
  }) {
    for (final arg in args) {
      final value = _evaluateExpression(
        arg,
        context,
        ruleLabel,
        currentEdge: currentEdge,
      );
      if (_coalesceAccepts(value, requireNonempty: requireNonempty)) {
        return _copyValue(value);
      }
    }
    return null;
  }

  Object? _callCoalesceWithReceiver(
    Object? receiver,
    List<ActionArgument> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge, {
    required bool requireNonempty,
  }) {
    if (_coalesceAccepts(receiver, requireNonempty: requireNonempty)) {
      return _copyValue(receiver);
    }
    for (final arg in args) {
      final value = _evaluateExpression(
        arg.value,
        context,
        ruleLabel,
        currentEdge: currentEdge,
      );
      if (_coalesceAccepts(value, requireNonempty: requireNonempty)) {
        return _copyValue(value);
      }
    }
    return null;
  }

  String? _captureSliceText(
    _RuntimeExecutionContext context, {
    required bool untilCursor,
    required String ruleLabel,
    required String projection,
  }) {
    final start = _captureStartCodeUnit(context);
    final end = _captureEndCodeUnit(context, untilCursor: untilCursor);
    return context.typedSpanTextFromCodeUnits(
      start,
      end,
      ruleLabel,
      projection,
    );
  }

  int? _captureSliceLength(
    _RuntimeExecutionContext context, {
    required bool untilCursor,
    required String ruleLabel,
    required String projection,
  }) {
    final start = _captureStartCodeUnit(context);
    final end = _captureEndCodeUnit(context, untilCursor: untilCursor);
    return context.typedSpanLengthFromCodeUnits(
      start,
      end,
      ruleLabel,
      projection,
    );
  }

  int _captureStartCodeUnit(_RuntimeExecutionContext context) {
    return (context.registers.captureStartCodeUnit ?? 0).clamp(
      0,
      context.input.length,
    );
  }

  int _captureEndCodeUnit(
    _RuntimeExecutionContext context, {
    required bool untilCursor,
  }) {
    final end = untilCursor
        ? context.cursorCodeUnit
        : context.registers.localMatch?.codeUnitStart ?? context.cursorCodeUnit;
    return end.clamp(0, context.input.length);
  }

  Object? _callCaptureMarkHelper(
    String helperName,
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    String? markName(int index) {
      if (index >= args.length) {
        return null;
      }
      return _captureName(args[index], context, ruleLabel, currentEdge);
    }

    String? spanText(int start, int end) {
      return context.typedSpanTextFromCodeUnits(
        start,
        end,
        ruleLabel,
        helperName,
      );
    }

    int? spanLength(int start, int end) =>
        context.typedSpanLengthFromCodeUnits(start, end, ruleLabel, helperName);

    final captureStart = _captureStartCodeUnit(context);
    final matchStart = _captureEndCodeUnit(context, untilCursor: false);
    final cursor = context.cursorCodeUnit;
    final inputEnd = context.input.length;
    final marks = context.marksFor(ruleLabel);

    switch (helperName) {
      case 'start_capture_slice_from':
        final name = markName(0);
        final offset = name == null
            ? null
            : context.typedMarkCodeUnit(ruleLabel, name, helperName);
        if (offset != null) {
          context.startCaptureSliceAt(offset, ruleLabel, helperName);
        }
        return null;
      case 'capture_rest':
        return spanText(captureStart, inputEnd);
      case 'capture_rest_len':
        return spanLength(captureStart, inputEnd);
      case 'capture_take':
        final value = spanText(captureStart, matchStart);
        if (value != null) {
          context.startCaptureSliceAt(cursor, ruleLabel, helperName);
        }
        return value;
      case 'capture_take_len':
        final value = spanLength(captureStart, matchStart);
        if (value != null) {
          context.startCaptureSliceAt(cursor, ruleLabel, helperName);
        }
        return value;
      case 'capture_take_until_cursor':
        final value = spanText(captureStart, cursor);
        if (value != null) {
          context.startCaptureSliceAt(cursor, ruleLabel, helperName);
        }
        return value;
      case 'capture_take_until_cursor_len':
        final value = spanLength(captureStart, cursor);
        if (value != null) {
          context.startCaptureSliceAt(cursor, ruleLabel, helperName);
        }
        return value;
      case 'capture_take_rest':
        final value = spanText(captureStart, inputEnd);
        if (value != null) {
          context.startCaptureSliceAt(inputEnd, ruleLabel, helperName);
        }
        return value;
      case 'capture_take_rest_len':
        final value = spanLength(captureStart, inputEnd);
        if (value != null) {
          context.startCaptureSliceAt(inputEnd, ruleLabel, helperName);
        }
        return value;
      case 'mark_here':
        final name = markName(0);
        if (name != null) {
          context.typedMarkSet(ruleLabel, name, cursor, helperName);
        }
        return null;
      case 'mark_input_start':
        final name = markName(0);
        if (name != null) {
          context.typedMarkSet(ruleLabel, name, 0, helperName);
        }
        return null;
      case 'mark_input_end':
        final name = markName(0);
        if (name != null) {
          context.typedMarkSet(ruleLabel, name, inputEnd, helperName);
        }
        return null;
      case 'mark_entry_start':
        final name = markName(0);
        final offset = context.registers.entryMatch?.codeUnitStart;
        if (name != null && offset != null) {
          context.typedMarkSet(ruleLabel, name, offset, helperName);
        }
        return null;
      case 'mark_entry_end':
        final name = markName(0);
        final offset = context.registers.entryMatch?.codeUnitEnd;
        if (name != null && offset != null) {
          context.typedMarkSet(ruleLabel, name, offset, helperName);
        }
        return null;
      case 'mark_match_start':
        final name = markName(0);
        final offset = context.registers.localMatch?.codeUnitStart;
        if (name != null && offset != null) {
          context.typedMarkSet(ruleLabel, name, offset, helperName);
        }
        return null;
      case 'mark_match_end':
        final name = markName(0);
        final offset = context.registers.localMatch?.codeUnitEnd;
        if (name != null && offset != null) {
          context.typedMarkSet(ruleLabel, name, offset, helperName);
        }
        return null;
      case 'mark_copy':
        final target = markName(0);
        final source = markName(1);
        if (target != null) {
          final offset = source == null
              ? null
              : context.typedMarkCodeUnit(ruleLabel, source, helperName);
          if (offset == null) {
            marks.remove(target);
          } else {
            context.typedMarkSet(ruleLabel, target, offset, helperName);
          }
        }
        return null;
      case 'mark_capture_slice':
        final name = markName(0);
        if (name != null) {
          context.typedMarkSet(ruleLabel, name, captureStart, helperName);
        }
        return null;
      case 'mark_exists':
        final name = markName(0);
        return name != null && marks.containsKey(name) ? 1 : 0;
      case 'mark_pos':
        final name = markName(0);
        final offset = name == null
            ? null
            : context.typedMarkCodeUnit(ruleLabel, name, helperName);
        return offset == null
            ? null
            : context.typedPositionOffsetFromCodeUnit(
                offset,
                ruleLabel,
                helperName,
              );
      case 'mark_line':
        final name = markName(0);
        final offset = name == null
            ? null
            : context.typedMarkCodeUnit(ruleLabel, name, helperName);
        return offset == null
            ? null
            : context.typedPositionLineFromCodeUnit(
                offset,
                ruleLabel,
                helperName,
              );
      case 'mark_col':
        final name = markName(0);
        final offset = name == null
            ? null
            : context.typedMarkCodeUnit(ruleLabel, name, helperName);
        return offset == null
            ? null
            : context.typedPositionColumnFromCodeUnit(
                offset,
                ruleLabel,
                helperName,
              );
      case 'clear_mark':
        final name = markName(0);
        if (name != null) {
          marks.remove(name);
        }
        return null;
      case 'capture_from':
      case 'capture_len_from':
      case 'capture_until_cursor_from':
      case 'capture_until_cursor_len_from':
      case 'capture_rest_from':
      case 'capture_rest_len_from':
      case 'capture_take_len_from':
      case 'capture_take_until_cursor_from':
      case 'capture_take_until_cursor_len_from':
      case 'capture_take_rest_from':
      case 'capture_take_rest_len_from':
        final name = markName(0);
        final start = name == null
            ? null
            : context.typedMarkCodeUnit(ruleLabel, name, helperName);
        if (name == null || start == null) {
          return null;
        }
        final end = switch (helperName) {
          'capture_from' ||
          'capture_len_from' ||
          'capture_take_len_from' => matchStart,
          'capture_until_cursor_from' ||
          'capture_until_cursor_len_from' ||
          'capture_take_until_cursor_from' ||
          'capture_take_until_cursor_len_from' => cursor,
          _ => inputEnd,
        };
        final lengthResult =
            helperName.contains('_len_') || helperName == 'capture_len_from';
        final value = lengthResult
            ? spanLength(start, end)
            : spanText(start, end);
        if (value != null && helperName.startsWith('capture_take_')) {
          context.typedMarkSet(
            ruleLabel,
            name,
            helperName.contains('_rest_') ? inputEnd : cursor,
            helperName,
          );
        }
        return value;
      case 'capture_between':
      case 'capture_len_between':
      case 'capture_take_between':
      case 'capture_take_between_len':
        final startName = markName(0);
        final endName = markName(1);
        final start = startName == null
            ? null
            : context.typedMarkCodeUnit(ruleLabel, startName, helperName);
        final end = endName == null
            ? null
            : context.typedMarkCodeUnit(ruleLabel, endName, helperName);
        if (startName == null || start == null || end == null) {
          return null;
        }
        final value = helperName.contains('len')
            ? spanLength(start, end)
            : spanText(start, end);
        if (value != null && helperName.startsWith('capture_take_')) {
          context.typedMarkSet(ruleLabel, startName, end, helperName);
        }
        return value;
      default:
        return null;
    }
  }

  Object? _callCaptureUntilBoundary(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    if (args.isEmpty) {
      return null;
    }
    var sawValidBoundary = false;
    int? boundaryStart;
    for (final arg in args) {
      final targetLabel = _ruleNameFromExpr(
        arg,
        context,
        ruleLabel,
        currentEdge,
      );
      final targetRule = compiledSpec.rule(targetLabel);
      if (targetRule == null) {
        continue;
      }
      final plan = _regexPlanFor(targetRule);
      if (plan.patterns.isEmpty) {
        continue;
      }
      sawValidBoundary = true;
      final boundaryMatch = RuntimeRegexAlternation.compile(
        plan.patterns,
      ).seekMatch(context.input, context.cursorCodeUnit);
      if (boundaryMatch != null &&
          (boundaryStart == null ||
              boundaryMatch.codeUnitStart < boundaryStart)) {
        boundaryStart = boundaryMatch.codeUnitStart;
      }
    }
    if (!sawValidBoundary) {
      return null;
    }
    boundaryStart ??= context.input.length;
    final captureStart = context.cursorCodeUnit;
    final captured = context.typedSpanTextFromCodeUnits(
      captureStart,
      boundaryStart,
      ruleLabel,
      'capture_until_boundary',
    );
    if (captured == null) {
      context.trace?.traceDecision(
        'dart_runtime:source_boundary',
        false,
        'helper=capture_until_boundary rule=$ruleLabel '
            'capture_start=$captureStart boundary=$boundaryStart',
        LinkedSpecTraceLevel.debug,
      );
      return null;
    }
    context._setCursorCodeUnit(boundaryStart);
    context.trace?.emitEvent(
      LinkedSpecTraceEventKind.mark,
      'dart_runtime:source_boundary',
      'helper=capture_until_boundary rule=$ruleLabel '
          'capture_start=$captureStart boundary=$boundaryStart '
          'length=${boundaryStart - captureStart}',
      LinkedSpecTraceLevel.debug,
    );
    return captured;
  }

  bool _callLogicalAnd(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final values = _evaluateValues(args, context, ruleLabel, currentEdge);
    var result = true;
    for (final value in values) {
      if (!runtimeLogicalTruth(value)) {
        result = false;
      }
    }
    return result;
  }

  bool _callLogicalOr(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final values = _evaluateValues(args, context, ruleLabel, currentEdge);
    var result = false;
    for (final value in values) {
      if (runtimeLogicalTruth(value)) {
        result = true;
      }
    }
    return result;
  }

  bool _callLogicalNot(
    List<ActionExpr> args,
    _RuntimeExecutionContext context,
    String ruleLabel,
    _CurrentActionEdge? currentEdge,
  ) {
    final values = _evaluateValues(args, context, ruleLabel, currentEdge);
    return !runtimeLogicalTruth(values.single);
  }

  Object? _readRetv(
    _RuntimeExecutionContext context,
    _CurrentActionEdge? currentEdge,
  ) {
    if (context.retv != null || currentEdge == null) {
      return context.retv;
    }
    final child = _executeActionEdgeChild(currentEdge, context);
    context.retv = child.value;
    return child.value;
  }

  _RuleResult _requireCurrentEdgeChild(
    _CurrentActionEdge? currentEdge,
    _RuntimeExecutionContext context,
    String ruleLabel,
  ) {
    if (currentEdge == null) {
      throw RuntimeInterpreterException(
        'push() in rule $ruleLabel requires an action-edge child context',
      );
    }
    final child = _executeActionEdgeChild(currentEdge, context);
    context.retv = child.value;
    return child;
  }

  _RuleResult _executeActionEdgeChild(
    _CurrentActionEdge currentEdge,
    _RuntimeExecutionContext context,
  ) {
    currentEdge.childDispatched = true;
    final before = context.cursorCodeUnit;
    final childRule = compiledSpec.rule(currentEdge.target.label);
    if (childRule == null) {
      throw RuntimeInterpreterException(
        "action edge references undefined child '${currentEdge.target.label}'",
      );
    }
    if (_isPassiveTerminalRule(childRule) &&
        !context.recursiveObservationExpects(currentEdge.target.label)) {
      context.trace?.traceDecision(
        'dart_runtime:child_dispatch',
        false,
        'edge_family=action rule=${currentEdge.ruleLabel} '
            'target=${currentEdge.target.label}[${currentEdge.target.index}] '
            'passive=1 cursor_before=$before cursor_after=${context.cursorCodeUnit}',
        LinkedSpecTraceLevel.debug,
      );
      return _RuleResult(matched: false, value: null);
    }
    final entrySlot = context.gapEntrySlotForEdge(currentEdge);
    final child = _executeRule(
      currentEdge.target.label,
      currentEdge.target.index,
      context,
      entrySlot: entrySlot,
    );
    context.trace?.traceDecision(
      'dart_runtime:child_dispatch',
      child.matched,
      'edge_family=action rule=${currentEdge.ruleLabel} '
          'target=${currentEdge.target.label}[${currentEdge.target.index}] '
          'cursor_before=$before cursor_after=${context.cursorCodeUnit}',
      LinkedSpecTraceLevel.debug,
    );
    return child;
  }

  void _traceCursorControl(
    _RuntimeExecutionContext context,
    String ruleLabel,
    String helperName, {
    required int before,
    required int stackBefore,
  }) {
    context.trace?.emitEvent(
      LinkedSpecTraceEventKind.mark,
      'dart_runtime:cursor_control',
      'helper=$helperName rule=$ruleLabel before=$before '
          'after=${context.cursorCodeUnit} stack_before=$stackBefore '
          'stack_after=${context.cursorStack.length}',
      LinkedSpecTraceLevel.debug,
    );
  }

  bool _isPassiveTerminalRule(CompiledRule rule) {
    return rule.lifecycleActionPayloads.isEmpty &&
        rule.actionEdges.isEmpty &&
        rule.blindEdges.isEmpty &&
        rule.plainActionPayloads.isEmpty;
  }
}

bool _isHashSpliceArgument(ActionExpr expr) {
  return switch (expr) {
    ActionCallExpr(:final name) => {
      'flat',
      'flat_hash',
    }.contains(canonicalActionHelperName(name)),
    ActionFluentChainExpr(:final calls) when calls.isNotEmpty => {
      'flat',
      'flat_hash',
    }.contains(canonicalActionHelperName(calls.last.method)),
    _ => false,
  };
}

bool _isArraySpliceArgument(ActionExpr expr) {
  return switch (expr) {
    ActionCallExpr(:final name) => {
      'flat',
      'flat_array',
      'flat_hash',
    }.contains(canonicalActionHelperName(name)),
    ActionFluentChainExpr(:final calls) when calls.isNotEmpty => {
      'flat',
      'flat_array',
      'flat_hash',
    }.contains(canonicalActionHelperName(calls.last.method)),
    _ => false,
  };
}

void _appendArraySpliceValue(List<Object?> values, Object? value) {
  if (value is Map) {
    for (final entry in _asHash(value).entries) {
      values.add(entry.key);
      values.add(_copyValue(entry.value));
    }
    return;
  }
  if (value is List) {
    for (final item in value) {
      values.add(_copyValue(item));
    }
    return;
  }
  values.add(_copyValue(value));
}

const _runtimePureHelperNames = <String>{
  'cat',
  'contains_substr',
  'ends_with',
  'is_defined',
  'is_empty',
  'is_nonempty',
  'is_undefined',
  'length',
  'lowercase',
  'matches',
  'num_abs',
  'num_add',
  'num_avg',
  'num_ceil',
  'num_clamp',
  'num_div',
  'num_eq',
  'num_floor',
  'num_ge',
  'num_gt',
  'num_le',
  'num_lt',
  'num_max',
  'num_median',
  'num_min',
  'num_mod',
  'num_mul',
  'num_ne',
  'num_range',
  'num_round',
  'num_sub',
  'num_sum',
  'replace_substr',
  'rm_prefix',
  'rm_suffix',
  'split',
  'starts_with',
  'str_eq',
  'str_ge',
  'str_gt',
  'str_le',
  'str_lt',
  'str_ne',
  'substr',
  'trim',
  'uppercase',
};

const _numericAggregateHelperNames = <String>{
  'num_avg',
  'num_max',
  'num_median',
  'num_min',
  'num_range',
  'num_sum',
};

const _runtimeArrayHelperNames = <String>{
  'concat_arrays',
  'contains',
  'count',
  'drop_back',
  'drop_front',
  'filter_match',
  'filter_nonempty',
  'first',
  'flat',
  'flat_array',
  'index_of',
  'join_values',
  'last',
  'lowercase_each',
  'reversed',
  'slice',
  'sorted',
  'split_each',
  'split_tagged_records',
  'take',
  'take_last',
  'trim_each',
  'uniq',
  'uppercase_each',
};

const _runtimeHashHelperNames = <String>{
  'count_keys',
  'drop_keys',
  'flat_hash',
  'has_key',
  'merge_hash',
  'pick_keys',
  'rename_key',
  'set_key',
  'sorted_keys',
  'sorted_values',
};

const _treeTraversalHelperNames = <String>{
  'walk_leaves',
  'map_leaves',
  'reduce_leaves',
};

const _arrayOnlyReceiverHelpers = <String>{
  ..._runtimeArrayHelperNames,
  'num_avg',
  'num_median',
  'num_range',
  'num_sum',
};

const _arrayPreferredReceiverHelpers = <String>{
  'is_empty',
  'is_nonempty',
  'num_max',
  'num_min',
};

const _hashOnlyReceiverHelpers = <String>{..._runtimeHashHelperNames};

const _hashPreferredReceiverHelpers = <String>{'is_empty', 'is_nonempty'};

const _runtimeReceiverHelperNames = <String>{
  ..._runtimePureHelperNames,
  ..._runtimeArrayHelperNames,
  ..._runtimeHashHelperNames,
  'coalesce',
  'coalesce_nonempty',
};

Object? _callPureHelper(String helperName, List<Object?> values) {
  if (helperName.startsWith('num_')) {
    return _callNumericHelper(helperName, values);
  }
  if (helperName.startsWith('str_')) {
    return _callStringCompareHelper(helperName, values);
  }
  return switch (helperName) {
    'cat' => _callCat(values),
    'contains_substr' => _callStringPredicate(
      values,
      (value, needle) => value.contains(needle),
    ),
    'ends_with' => _callStringPredicate(
      values,
      (value, suffix) => value.endsWith(suffix),
    ),
    'is_defined' => values.isNotEmpty && values.first != null,
    'is_empty' => _isEmptyValue(values.isEmpty ? null : values.first),
    'is_nonempty' => !_isEmptyValue(values.isEmpty ? null : values.first),
    'is_undefined' => values.isEmpty || values.first == null,
    'length' => _lengthValue(values.isEmpty ? null : values.first),
    'lowercase' => _stringTransform(values, unicodeLowercase),
    'matches' => _callMatches(values),
    'replace_substr' => _callReplaceSubstr(values),
    'rm_prefix' => _callRemoveEdge(values, prefix: true),
    'rm_suffix' => _callRemoveEdge(values, prefix: false),
    'split' => _callSplit(values),
    'starts_with' => _callStringPredicate(
      values,
      (value, prefix) => value.startsWith(prefix),
    ),
    'substr' => _callSubstr(values),
    'trim' => _stringTransform(values, (value) => value.trim()),
    'uppercase' => _stringTransform(values, unicodeUppercase),
    _ => throw RuntimeInterpreterException(
      "unsupported pure runtime helper '$helperName'",
    ),
  };
}

Object? _callArrayHelper(String helperName, List<Object?> values) {
  return switch (helperName) {
    'concat_arrays' => _callConcatArrays(values),
    'contains' => _callArrayContains(values),
    'count' => _lengthValue(values.isEmpty ? null : values.first) ?? 0,
    'drop_back' => _callDrop(values, front: false),
    'drop_front' => _callDrop(values, front: true),
    'filter_match' => _callFilterMatch(values),
    'filter_nonempty' => _arrayTransform(values, (items) {
      return [
        for (final item in items)
          if (!_isEmptyValue(item)) _copyValue(item),
      ];
    }),
    'first' => _arrayItem(values, first: true),
    'flat' => _callFlat(values),
    'flat_array' => _callFlatArray(values),
    'index_of' => _callIndexOf(values),
    'join_values' => _callJoinValues(values),
    'last' => _arrayItem(values, first: false),
    'lowercase_each' => _mapStringItems(values, unicodeLowercase),
    'reversed' => _arrayTransform(values, (items) {
      return [for (final item in items.reversed) _copyValue(item)];
    }),
    'slice' => _callSlice(values),
    'sorted' => _arrayTransform(values, (items) {
      final sorted = [for (final item in items) _copyValue(item)]
        ..sort(
          (left, right) => _scalarString(
            left,
            nullAsEmpty: true,
          )!.compareTo(_scalarString(right, nullAsEmpty: true)!),
        );
      return sorted;
    }),
    'split_each' => _callSplitEach(values),
    'split_tagged_records' => _callSplitTaggedRecords(values),
    'take' => _callTake(values, front: true),
    'take_last' => _callTake(values, front: false),
    'trim_each' => _mapStringItems(values, (value) => value.trim()),
    'uniq' => _callUniq(values),
    'uppercase_each' => _mapStringItems(values, unicodeUppercase),
    _ => throw RuntimeInterpreterException(
      "unsupported array runtime helper '$helperName'",
    ),
  };
}

Object? _callHashHelper(String helperName, List<Object?> values) {
  return switch (helperName) {
    'count_keys' =>
      _hashItems(values.isEmpty ? null : values.first)?.length ?? 0,
    'drop_keys' => _callDropKeys(values),
    'flat_hash' => _callFlatHash(values),
    'has_key' => _callHasKey(values),
    'merge_hash' => _callMergeHash(values),
    'pick_keys' => _callPickKeys(values),
    'rename_key' => _callRenameKey(values),
    'set_key' => _callSetKey(values),
    'sorted_keys' => _callSortedKeys(values),
    'sorted_values' => _callSortedValues(values),
    _ => throw RuntimeInterpreterException(
      "unsupported hash runtime helper '$helperName'",
    ),
  };
}

Object? _arrayItem(List<Object?> values, {required bool first}) {
  final items = _arrayItems(values.isEmpty ? null : values.first);
  if (items == null || items.isEmpty) {
    return null;
  }
  return _copyValue(first ? items.first : items.last);
}

Object? _arrayTransform(
  List<Object?> values,
  List<Object?> Function(List<Object?> items) transform,
) {
  final items = _arrayItems(values.isEmpty ? null : values.first);
  if (items == null) {
    return <Object?>[];
  }
  return transform(items);
}

Object? _callTake(List<Object?> values, {required bool front}) {
  final items = _arrayItems(values.isEmpty ? null : values.first);
  if (items == null) {
    return <Object?>[];
  }
  final count = _nonNegativeInt(values.length >= 2 ? values[1] : null, 1);
  if (front) {
    return [for (final item in items.take(count)) _copyValue(item)];
  }
  final start = math.max(0, items.length - count);
  return [for (final item in items.skip(start)) _copyValue(item)];
}

Object? _callDrop(List<Object?> values, {required bool front}) {
  final items = _arrayItems(values.isEmpty ? null : values.first);
  if (items == null) {
    return <Object?>[];
  }
  final count = _nonNegativeInt(values.length >= 2 ? values[1] : null, 1);
  if (front) {
    return [for (final item in items.skip(count)) _copyValue(item)];
  }
  final end = math.max(0, items.length - count);
  return [for (final item in items.take(end)) _copyValue(item)];
}

Object? _callSlice(List<Object?> values) {
  final items = _arrayItems(values.isEmpty ? null : values.first);
  if (items == null) {
    return <Object?>[];
  }
  final start = _nonNegativeInt(values.length >= 2 ? values[1] : null, 0);
  final length = _nonNegativeInt(
    values.length >= 3 ? values[2] : null,
    items.length,
  );
  if (start >= items.length) {
    return <Object?>[];
  }
  final end = math.min(items.length, start + length);
  return [for (final item in items.sublist(start, end)) _copyValue(item)];
}

Object? _callArrayContains(List<Object?> values) {
  final items = _arrayItems(values.isEmpty ? null : values.first);
  if (items == null || values.length < 2) {
    return 0;
  }
  final needle = _scalarString(values[1], nullAsEmpty: true);
  return items.any((item) => _scalarString(item, nullAsEmpty: true) == needle)
      ? 1
      : 0;
}

Object? _callIndexOf(List<Object?> values) {
  final items = _arrayItems(values.isEmpty ? null : values.first);
  if (items == null || values.length < 2) {
    return null;
  }
  final needle = _scalarString(values[1], nullAsEmpty: true);
  for (final (index, item) in items.indexed) {
    if (_scalarString(item, nullAsEmpty: true) == needle) {
      return index;
    }
  }
  return null;
}

Object? _callJoinValues(List<Object?> values) {
  final delimiter = _scalarString(
    values.isEmpty ? '' : values.first,
    nullAsEmpty: true,
  );
  if (delimiter == null) {
    return '';
  }
  final items = values.length >= 2 ? _arrayItems(values[1]) : const <Object?>[];
  final parts = items ?? (values.length >= 2 ? <Object?>[values[1]] : const []);
  return parts
      .map((value) => _scalarString(value, nullAsEmpty: true) ?? '')
      .join(delimiter);
}

Object? _mapStringItems(
  List<Object?> values,
  String Function(String value) transform,
) {
  return _arrayTransform(values, (items) {
    return [
      for (final item in items)
        transform(_scalarString(item, nullAsEmpty: true) ?? ''),
    ];
  });
}

Object? _callSplitEach(List<Object?> values) {
  return _arrayTransform(values, (items) {
    final delimiter = values.length >= 2 ? values[1] : '';
    return [
      for (final item in items)
        ..._splitStringValue(item, delimiter, regexDelimiter: false),
    ];
  });
}

Object? _callFilterMatch(List<Object?> values) {
  final items = _arrayItems(values.isEmpty ? null : values.first);
  if (items == null || values.length < 2) {
    return <Object?>[];
  }
  final regex = _regexFromValue(values[1]);
  if (regex == null) {
    return <Object?>[];
  }
  return [
    for (final item in items)
      if (regex.hasMatch(_scalarString(item, nullAsEmpty: true) ?? ''))
        _copyValue(item),
  ];
}

Object? _callUniq(List<Object?> values) {
  return _arrayTransform(values, (items) {
    final seen = <String>{};
    final result = <Object?>[];
    for (final item in items) {
      final key = _scalarString(item, nullAsEmpty: true) ?? '';
      if (seen.add(key)) {
        result.add(_copyValue(item));
      }
    }
    return result;
  });
}

Object? _callFlat(List<Object?> values) {
  if (values.isEmpty) {
    return [null];
  }
  final value = values.first;
  if (value is Map) {
    return _asHash(value);
  }
  if (value is List) {
    return [for (final item in value) _copyValue(item)];
  }
  return [_copyValue(value)];
}

Object? _callFlatArray(List<Object?> values) {
  return [
    for (final value in values)
      if (value is List)
        for (final item in value) _copyValue(item)
      else
        _copyValue(value),
  ];
}

Object? _callConcatArrays(List<Object?> values) => _callFlatArray(values);

Object? _callSplitTaggedRecords(List<Object?> values) {
  if (values.length < 3) {
    return <Object?>[];
  }
  final tag = _scalarString(values[2], nullAsEmpty: true) ?? '';
  final fields = [for (final field in values.skip(3)) _copyValue(field)];
  return [
    for (final item in _splitStringValue(
      values[0],
      values[1],
      regexDelimiter: false,
    ))
      [tag, item, ...fields.map(_copyValue)],
  ];
}

Map<String, Object?>? _hashItems(Object? value) {
  if (value is! Map) {
    return null;
  }
  return _asHash(value);
}

Object? _callMergeHash(List<Object?> values) {
  final merged = <String, Object?>{};
  for (final value in values) {
    final hash = _hashItems(value);
    if (hash == null) {
      continue;
    }
    for (final entry in hash.entries) {
      merged[entry.key] = _copyValue(entry.value);
    }
  }
  return merged;
}

Object? _callSetKey(List<Object?> values) {
  if (values.length < 3) {
    return null;
  }
  final hash = _hashItems(values.first);
  if (hash == null) {
    return _copyValue(values.first);
  }
  hash[_stringValue(values[1])] = _copyValue(values[2]);
  return hash;
}

Object? _callRenameKey(List<Object?> values) {
  if (values.length < 3) {
    return null;
  }
  final hash = _hashItems(values.first);
  if (hash == null) {
    return _copyValue(values.first);
  }
  final oldKey = _stringValue(values[1]);
  final newKey = _stringValue(values[2]);
  return {
    for (final entry in hash.entries)
      if (entry.key == oldKey)
        newKey: _copyValue(entry.value)
      else
        entry.key: _copyValue(entry.value),
  };
}

Object? _callDropKeys(List<Object?> values) {
  final hash = _hashItems(values.isEmpty ? null : values.first);
  if (hash == null) {
    return values.isEmpty ? null : _copyValue(values.first);
  }
  final keys = {for (final value in values.skip(1)) _stringValue(value)};
  return {
    for (final entry in hash.entries)
      if (!keys.contains(entry.key)) entry.key: _copyValue(entry.value),
  };
}

Object? _callPickKeys(List<Object?> values) {
  final hash = _hashItems(values.isEmpty ? null : values.first);
  if (hash == null) {
    return null;
  }
  final keys = {for (final value in values.skip(1)) _stringValue(value)};
  return {
    for (final entry in hash.entries)
      if (keys.contains(entry.key)) entry.key: _copyValue(entry.value),
  };
}

Object? _callSortedKeys(List<Object?> values) {
  final hash = _hashItems(values.isEmpty ? null : values.first);
  if (hash == null) {
    return <Object?>[];
  }
  final keys = hash.keys.toList()..sort();
  return keys;
}

Object? _callSortedValues(List<Object?> values) {
  final hash = _hashItems(values.isEmpty ? null : values.first);
  if (hash == null) {
    return <Object?>[];
  }
  final entries = hash.entries.toList()
    ..sort((left, right) => left.key.compareTo(right.key));
  return [for (final entry in entries) _copyValue(entry.value)];
}

Object? _callHasKey(List<Object?> values) {
  final hash = _hashItems(values.isEmpty ? null : values.first);
  if (hash == null || values.length < 2) {
    return 0;
  }
  return hash.containsKey(_stringValue(values[1])) ? 1 : 0;
}

Object? _callFlatHash(List<Object?> values) {
  final flattened = <String, Object?>{};
  for (final value in values) {
    final hash = _hashItems(value);
    if (hash == null) {
      continue;
    }
    for (final entry in hash.entries) {
      flattened[entry.key] = _copyValue(entry.value);
    }
  }
  return flattened;
}

bool _coalesceAccepts(Object? value, {required bool requireNonempty}) {
  if (value == null) {
    return false;
  }
  if (!requireNonempty) {
    return true;
  }
  return value is! String || value.isNotEmpty;
}

Object? _callCat(List<Object?> values) {
  final buffer = StringBuffer();
  for (final value in values) {
    final string = _scalarString(value);
    if (string == null) {
      return null;
    }
    buffer.write(string);
  }
  return buffer.toString();
}

Object? _stringTransform(
  List<Object?> values,
  String Function(String value) transform,
) {
  final value = values.isEmpty ? null : _scalarString(values.first);
  return value == null ? null : transform(value);
}

Object? _callStringPredicate(
  List<Object?> values,
  bool Function(String value, String needle) test,
) {
  if (values.length < 2) {
    return 0;
  }
  final value = _scalarString(values[0]);
  final needle = _scalarString(values[1], nullAsEmpty: true);
  if (value == null || needle == null) {
    return 0;
  }
  return test(value, needle) ? 1 : 0;
}

Object? _callMatches(List<Object?> values) {
  if (values.length < 2) {
    return false;
  }
  final value = _scalarString(values[0]);
  final pattern = _scalarString(values[1]);
  if (value == null || pattern == null) {
    return false;
  }
  return RuntimeRegexAlternation.compile([pattern]).seekMatch(value, 0) != null;
}

Object? _callReplaceSubstr(List<Object?> values) {
  if (values.length < 3) {
    return null;
  }
  final value = _scalarString(values[0]);
  final oldValue = _scalarString(values[1], nullAsEmpty: true);
  final newValue = _scalarString(values[2], nullAsEmpty: true);
  if (value == null || oldValue == null || newValue == null) {
    return null;
  }
  if (oldValue.isEmpty) {
    return value;
  }
  return value.replaceAll(oldValue, newValue);
}

Object? _callRemoveEdge(List<Object?> values, {required bool prefix}) {
  if (values.length < 2) {
    return null;
  }
  final value = _scalarString(values[0]);
  final edge = _scalarString(values[1], nullAsEmpty: true);
  if (value == null || edge == null) {
    return null;
  }
  if (prefix) {
    return value.startsWith(edge) ? value.substring(edge.length) : value;
  }
  return value.endsWith(edge)
      ? value.substring(0, value.length - edge.length)
      : value;
}

Object? _callSubstr(List<Object?> values) {
  if (values.length < 2 || values.first == null || values[1] == null) {
    return null;
  }
  final value = _scalarString(values[0]);
  if (value == null) {
    return null;
  }
  final start = math.max(0, _intValue(values[1]) ?? 0);
  final length = values.length >= 3 && values[2] != null
      ? math.max(0, _intValue(values[2]) ?? 0)
      : null;
  return _charSubstring(value, start, length);
}

Object? _callSplit(List<Object?> values, {bool regexDelimiter = false}) {
  if (values.length < 2) {
    return null;
  }
  return _splitStringValue(
    values[0],
    values[1],
    regexDelimiter: regexDelimiter,
  );
}

Object? _lengthValue(Object? value) {
  if (value == null) {
    return null;
  }
  if (value is String) {
    return value.runes.length;
  }
  if (value is List) {
    return value.length;
  }
  if (value is Map) {
    return value.length;
  }
  return _scalarString(value)?.runes.length;
}

bool _isEmptyValue(Object? value) {
  return switch (value) {
    null => true,
    String value => value.isEmpty,
    List<dynamic> value => value.isEmpty,
    Map<dynamic, dynamic> value => value.isEmpty,
    _ => false,
  };
}

Object? _callStringCompareHelper(String helperName, List<Object?> values) {
  if (values.length < 2) {
    return null;
  }
  final left = _scalarString(values[0]);
  final right = _scalarString(values[1]);
  if (left == null || right == null) {
    return null;
  }
  final comparison = left.compareTo(right);
  return switch (helperName) {
    'str_eq' => comparison == 0,
    'str_ne' => comparison != 0,
    'str_gt' => comparison > 0,
    'str_ge' => comparison >= 0,
    'str_lt' => comparison < 0,
    'str_le' => comparison <= 0,
    _ => throw RuntimeInterpreterException(
      "unsupported string comparison helper '$helperName'",
    ),
  };
}

Object? _callNumericHelper(String helperName, List<Object?> values) {
  switch (helperName) {
    case 'num_add':
      if (values.length < 2) {
        return null;
      }
      return _numericFold(values, (left, right) => left + right);
    case 'num_sub':
      if (values.length != 2) {
        return null;
      }
      return _numericFold(values, (left, right) => left - right);
    case 'num_mul':
      if (values.length < 2) {
        return null;
      }
      return _numericFold(values, (left, right) => left * right);
    case 'num_div':
      if (values.length != 2) {
        return null;
      }
      return _numericFold(values, (left, right) {
        if (right == 0) {
          throw const _InvalidNumericResult();
        }
        return left / right;
      });
    case 'num_mod':
      if (values.length != 2) {
        return null;
      }
      final left = _numValue(values[0]);
      final right = _numValue(values[1]);
      if (left == null ||
          right == null ||
          right == 0 ||
          !_isInteger(left) ||
          !_isInteger(right)) {
        return null;
      }
      return _jsonNumber(left - (left / right).floor() * right);
    case 'num_abs':
      if (values.length != 1) {
        return null;
      }
      return _unaryNumber(values, (value) => value.abs());
    case 'num_floor':
      if (values.length != 1) {
        return null;
      }
      return _unaryNumber(values, (value) => value.floor());
    case 'num_ceil':
      if (values.length != 1) {
        return null;
      }
      return _unaryNumber(values, (value) => value.ceil());
    case 'num_round':
      if (values.length != 1) {
        return null;
      }
      return _unaryNumber(values, (value) => value.round());
    case 'num_min':
      return _minMax(values, math.min);
    case 'num_max':
      return _minMax(values, math.max);
    case 'num_clamp':
      if (values.length != 3) {
        return null;
      }
      final value = _numValue(values[0]);
      final lower = _numValue(values[1]);
      final upper = _numValue(values[2]);
      if (value == null || lower == null || upper == null || lower > upper) {
        return null;
      }
      return _jsonNumber(value.clamp(lower, upper));
    case 'num_sum':
      final numbers = _numericList(values.isEmpty ? null : values.first);
      if (numbers == null) {
        return null;
      }
      return _jsonNumber(numbers.fold<num>(0, (sum, value) => sum + value));
    case 'num_avg':
      final numbers = _numericList(values.isEmpty ? null : values.first);
      if (numbers == null || numbers.isEmpty) {
        return null;
      }
      return _jsonNumber(
        numbers.fold<num>(0, (sum, value) => sum + value) / numbers.length,
      );
    case 'num_median':
      final numbers = _numericList(values.isEmpty ? null : values.first);
      if (numbers == null || numbers.isEmpty) {
        return null;
      }
      final sorted = [...numbers]..sort();
      final middle = sorted.length ~/ 2;
      if (sorted.length.isOdd) {
        return _jsonNumber(sorted[middle]);
      }
      return _jsonNumber((sorted[middle - 1] + sorted[middle]) / 2);
    case 'num_range':
      final numbers = _numericList(values.isEmpty ? null : values.first);
      if (numbers == null || numbers.isEmpty) {
        return null;
      }
      var minimum = numbers.first;
      var maximum = numbers.first;
      for (final value in numbers.skip(1)) {
        minimum = math.min(minimum, value);
        maximum = math.max(maximum, value);
      }
      return _jsonNumber(maximum - minimum);
    case 'num_eq':
    case 'num_ne':
    case 'num_gt':
    case 'num_ge':
    case 'num_lt':
    case 'num_le':
      return _numericCompare(helperName, values);
    default:
      throw RuntimeInterpreterException(
        "unsupported numeric helper '$helperName'",
      );
  }
}

Object? _numericFold(
  List<Object?> values,
  num Function(num left, num right) combine,
) {
  if (values.isEmpty) {
    return null;
  }
  final first = _numValue(values.first);
  if (first == null) {
    return null;
  }
  var current = first;
  try {
    for (final value in values.skip(1)) {
      final next = _numValue(value);
      if (next == null) {
        return null;
      }
      current = combine(current, next);
    }
  } on _InvalidNumericResult {
    return null;
  }
  return _jsonNumber(current);
}

Object? _unaryNumber(List<Object?> values, num Function(num value) transform) {
  if (values.isEmpty) {
    return null;
  }
  final value = _numValue(values.first);
  return value == null ? null : _jsonNumber(transform(value));
}

Object? _minMax(
  List<Object?> values,
  num Function(num left, num right) select,
) {
  if (values.length == 1 && values.first is List) {
    final numbers = _numericList(values.first);
    if (numbers == null || numbers.isEmpty) {
      return null;
    }
    return _jsonNumber(numbers.skip(1).fold<num>(numbers.first, select));
  }
  if (values.length < 2) {
    return null;
  }
  return _numericFold(values, select);
}

Object? _numericCompare(String helperName, List<Object?> values) {
  if (values.length != 2) {
    return null;
  }
  final left = _numValue(values[0]);
  final right = _numValue(values[1]);
  if (left == null || right == null) {
    return null;
  }
  final result = switch (helperName) {
    'num_eq' => left == right,
    'num_ne' => left != right,
    'num_gt' => left > right,
    'num_ge' => left >= right,
    'num_lt' => left < right,
    'num_le' => left <= right,
    _ => throw RuntimeInterpreterException(
      "unsupported numeric comparison helper '$helperName'",
    ),
  };
  return result ? 1 : 0;
}

List<num>? _numericList(Object? value) {
  if (value is! List) {
    return null;
  }
  final numbers = <num>[];
  for (final item in value) {
    final number = _numValue(item);
    if (number == null) {
      return null;
    }
    numbers.add(number);
  }
  return numbers;
}

num? _numValue(Object? value) {
  if (value == null || value is List || value is Map || value is bool) {
    return null;
  }
  if (value is num) {
    return value.isFinite ? value : null;
  }
  final text = '$value';
  final match = _strictDecimalText.matchAsPrefix(text);
  if (match == null || match.end != text.length) {
    return null;
  }
  final parsed = num.tryParse(text);
  return parsed != null && parsed.isFinite ? parsed : null;
}

int? _intValue(Object? value) {
  if (value == null || value is List || value is Map || value is bool) {
    return null;
  }
  if (value is num) {
    return value.toInt();
  }
  return int.tryParse('$value'.trim());
}

bool _isInteger(num value) {
  return value.isFinite && value == value.truncateToDouble();
}

final _strictDecimalText = RegExp(r'-?(?:\d+(?:\.\d+)?|\.\d+)');

Object? _jsonNumber(num value) {
  if (!value.isFinite) {
    return null;
  }
  if (_isInteger(value)) {
    return value.toInt();
  }
  return value;
}

List<Object?>? _arrayItems(Object? value) {
  if (value is! List) {
    return null;
  }
  return [for (final item in value) _copyValue(item)];
}

int _nonNegativeInt(Object? value, int defaultValue) {
  return math.max(0, _intValue(value) ?? defaultValue);
}

List<Object?> _splitStringValue(
  Object? value,
  Object? delimiter, {
  required bool regexDelimiter,
}) {
  final source = _scalarString(value);
  if (source == null) {
    return <Object?>[];
  }
  if (delimiter is _RuntimeRegexPattern || regexDelimiter) {
    final pattern = delimiter is _RuntimeRegexPattern
        ? delimiter.pattern
        : (_scalarString(delimiter) ?? '');
    final regex = _compileRegex(pattern);
    if (regex == null) {
      return <Object?>[];
    }
    return source.split(regex);
  }
  final literal = _scalarString(delimiter, nullAsEmpty: true);
  if (literal == null) {
    return <Object?>[];
  }
  if (literal.isEmpty) {
    return [for (final rune in source.runes) String.fromCharCode(rune)];
  }
  return source.split(literal);
}

RegExp? _regexFromValue(Object? value) {
  final pattern = value is _RuntimeRegexPattern
      ? value.pattern
      : _scalarString(value);
  if (pattern == null) {
    return null;
  }
  return _compileRegex(pattern);
}

RegExp? _compileRegex(String pattern, {String flags = ''}) {
  try {
    return compileRuntimeRegex(
      pattern,
      caseSensitive: !flags.contains('i'),
      multiLine: flags.contains('m'),
      dotAll: flags.contains('s'),
    );
  } on FormatException {
    return null;
  }
}

String _regexFlagString(
  ActionExpr expr,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  final name = _variableName(expr);
  if (name != null) {
    return name;
  }
  return _scalarString(
        context.engine._evaluateExpression(
          expr,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
        nullAsEmpty: true,
      ) ??
      '';
}

String _replaceRegex(
  String source,
  RegExp regex,
  String replacement, {
  required bool global,
}) {
  if (global) {
    return source.replaceAllMapped(
      regex,
      (match) => _expandRegexReplacement(replacement, match),
    );
  }
  return source.replaceFirstMapped(
    regex,
    (match) => _expandRegexReplacement(replacement, match),
  );
}

String _expandRegexReplacement(String replacement, Match match) {
  return replacement.replaceAllMapped(RegExp(r'\$(\d+)'), (placeholder) {
    final index = int.tryParse(placeholder[1] ?? '');
    if (index == null || index < 0 || index > match.groupCount) {
      return '';
    }
    return match.group(index) ?? '';
  });
}

String? _scalarString(Object? value, {bool nullAsEmpty = false}) {
  if (value == null) {
    return nullAsEmpty ? '' : null;
  }
  if (value is _RuntimeRegexPattern) {
    return value.pattern;
  }
  if (value is List || value is Map) {
    return nullAsEmpty ? '' : null;
  }
  if (value is bool) {
    return value ? '1' : '0';
  }
  if (value is num) {
    if (!value.isFinite) {
      return null;
    }
    if (value == 0) {
      return '0';
    }
    if (value == value.truncateToDouble()) {
      return value.toInt().toString();
    }
    return value.toString();
  }
  return '$value';
}

String _diagnosticOutputFragment(Object? value) {
  return _scalarString(value, nullAsEmpty: true) ?? '';
}

String _charSubstring(String value, int start, int? length) {
  final chars = value.runes.toList();
  if (start >= chars.length) {
    return '';
  }
  final end = length == null
      ? chars.length
      : math.min(chars.length, start + length);
  return String.fromCharCodes(chars.sublist(start, end));
}

final class _InvalidNumericResult implements Exception {
  const _InvalidNumericResult();
}

final class _RuntimeRegexPattern {
  const _RuntimeRegexPattern(this.pattern);

  final String pattern;
}

final class _RuleExecutionPolicy {
  const _RuleExecutionPolicy({
    required this.cursorPolicy,
    required this.usesAndExecution,
  });

  final LinkedSpecParseMode cursorPolicy;
  final bool usesAndExecution;
}

final class _RuntimeExecutionContext {
  _RuntimeExecutionContext({
    required this.engine,
    required this.input,
    required this.maxIterations,
    required this.topRule,
    required this.trace,
    required this.diagnosticOutputSink,
    required this.semanticObservationSink,
    this.generatedPlan,
    this.generatedSourceIdentity,
  }) : registers = RuntimeMatchRegisters.empty(input),
       sourceAuthority = SourceAuthority(sources: {'input': input}),
       progressiveExecution = engine.boundedChildParseAuthority?.start(),
       stagedAstEnrichment = engine.stagedAstEnrichmentSeed?.start() {
    recognitionAuthority = RecognitionTransactionAuthority(
      sourceAuthority: sourceAuthority,
      sourceIdentity: 'input',
    );
  }

  final LinkedSpecRuntimeEngine engine;
  final String input;
  final int maxIterations;
  final String topRule;
  final LinkedSpecTraceEmitter? trace;
  final RuntimeDiagnosticOutputSink? diagnosticOutputSink;
  final RuntimeSemanticObservationSink? semanticObservationSink;
  final Map<String, GeneratedRuleFamily>? generatedPlan;
  final String? generatedSourceIdentity;
  final SourceAuthority sourceAuthority;
  final ProgressiveExecutionState? progressiveExecution;
  final StagedAstEnrichmentState? stagedAstEnrichment;
  late final RecognitionTransactionAuthority recognitionAuthority;
  final Map<String, Object?> variables = <String, Object?>{};
  final Map<String, List<Object?>> arrays = <String, List<Object?>>{};
  final Map<String, Map<String, Object?>> hashes =
      <String, Map<String, Object?>>{};
  final Map<String, int> _bindingIdentities = <String, int>{};
  final Map<int, String> _activeReceiverMutations = <int, String>{};
  final Map<String, Map<String, int>> markBuckets =
      <String, Map<String, int>>{};
  final Set<String> activeRuleEntries = <String>{};
  final List<String> activeUserFunctions = <String>[];
  final List<String> activeCodeblocks = <String>[];
  final List<RuntimeLifecycleEvent> lifecycleEvents = <RuntimeLifecycleEvent>[];
  final List<int> cursorStack = <int>[];
  final List<String> _ruleStack = <String>[];
  final List<Map<String, _VariableSnapshot>> _ruleLocalBindingScopes =
      <Map<String, _VariableSnapshot>>[];
  final List<_RecognitionRuntimeFrame> _recognitionFrames =
      <_RecognitionRuntimeFrame>[];
  final List<_RecursiveObservationScope> _recursiveObservationScopes =
      <_RecursiveObservationScope>[];
  int _ruleLocalBindingSuppressionDepth = 0;
  int _nextBindingIdentity = 1;

  RuntimeMatchRegisters registers;
  Object? retv;
  int cursorCodeUnit = 0;

  String? get currentRuleLabel {
    return _ruleStack.isEmpty ? null : _ruleStack.last;
  }

  bool get hasActiveRecognitionTransaction =>
      _recognitionFrames.any((frame) => frame.tokens.isNotEmpty);

  int get cursorCharOffset {
    return codeUnitOffsetToCharOffset(input, cursorCodeUnit);
  }

  LineColumn get cursorLineColumn {
    return lineColumnAtCodeUnitOffset(input, cursorCodeUnit);
  }

  List<Object?> arrayFor(String name) {
    return arrays.putIfAbsent(name, () => <Object?>[]);
  }

  Map<String, Object?> hashFor(String name) {
    return hashes.putIfAbsent(name, () => <String, Object?>{});
  }

  Map<String, int> marksFor(String ruleLabel) {
    return markBuckets.putIfAbsent(ruleLabel, () => <String, int>{});
  }

  RecognitionFrameState _recognitionFrameState(String ruleLabel) {
    return RecognitionFrameState(
      cursor: cursorCodeUnit,
      boundary: registers.captureStartCodeUnit,
      marks: marksFor(ruleLabel),
    );
  }

  void _applyRecognitionFrameState(
    String ruleLabel,
    RecognitionFrameState state,
  ) {
    cursorCodeUnit = state.cursor.clamp(0, input.length);
    registers = RuntimeMatchRegisters(
      input: input,
      cursorCodeUnit: cursorCodeUnit,
      entryMatch: registers.entryMatch,
      localMatch: registers.localMatch,
      captureStartCodeUnit: state.boundary,
    );
    markBuckets[ruleLabel] = Map<String, int>.from(state.marks);
  }

  void enterRecognitionInvocation(
    String ruleLabel, {
    required bool captureGaps,
    required RecognitionGapEntrySlot? entrySlot,
  }) {
    final priorMarks = markBuckets.remove(ruleLabel);
    markBuckets[ruleLabel] = <String, int>{};
    try {
      final frame = recognitionAuthority.enterInvocation(
        rule: ruleLabel,
        origin: '$ruleLabel:handler_entry',
        state: _recognitionFrameState(ruleLabel),
        captureGaps: captureGaps,
        entrySlot: entrySlot,
      );
      final identity = recognitionAuthority.invocationIdentity(frame);
      _recognitionFrames.add(
        _RecognitionRuntimeFrame(
          rule: ruleLabel,
          authorityFrame: frame,
          identity: identity,
          priorMarks: priorMarks,
        ),
      );
    } on Object {
      if (priorMarks == null) {
        markBuckets.remove(ruleLabel);
      } else {
        markBuckets[ruleLabel] = priorMarks;
      }
      rethrow;
    }
  }

  void leaveRecognitionInvocation(
    String ruleLabel, {
    required _RuleResult? result,
    required Object? error,
  }) {
    final frame = _recognitionFrame(ruleLabel);
    final actual = _recognitionFrameState(ruleLabel);
    final restored = frame.tokens.isEmpty
        ? actual
        : frame.tokens.values.first.snapshot;
    Object? leaveError;
    try {
      recognitionAuthority.setFrameState(frame.authorityFrame, actual);
      recognitionAuthority.leaveInvocation(frame.authorityFrame);
    } on Object catch (caught) {
      leaveError = caught;
      if (error == null) {
        rethrow;
      }
    } finally {
      final observation = frame.observationScope;
      if (observation != null) {
        final terminalError = error ?? leaveError;
        final accepted = terminalError == null && (result?.matched ?? false);
        observation.completion = _RecursiveObservationCompletion(
          identity: frame.identity,
          entryCodeUnit: frame.entryCodeUnit,
          selectedMatch: frame.selectedMatch,
          acceptedExitCodeUnit: accepted ? actual.cursor : null,
          outcome: terminalError != null
              ? 'aborted'
              : accepted
              ? 'accepted'
              : 'failed',
          diagnostic: _recursiveObservationDiagnostic(terminalError),
        );
      }
      _applyRecognitionFrameState(ruleLabel, restored);
      _recognitionFrames.removeLast();
      if (frame.priorMarks == null) {
        markBuckets.remove(ruleLabel);
      } else {
        markBuckets[ruleLabel] = frame.priorMarks!;
      }
    }
  }

  _RecursiveObservationScope beginRecursiveObservation(String rule) {
    final scope = _RecursiveObservationScope(rule);
    _recursiveObservationScopes.add(scope);
    return scope;
  }

  bool recursiveObservationExpects(String rule) {
    if (_recursiveObservationScopes.isEmpty) {
      return false;
    }
    final scope = _recursiveObservationScopes.last;
    return !scope.entered && scope.rule == rule;
  }

  RuntimeInterpreterException rejectRecursiveObservation(
    String rule,
    int entryCodeUnit,
  ) {
    final scope = _recursiveObservationScopes.last;
    final identity = recognitionAuthority.reserveRejectedInvocation(rule: rule);
    final direct =
        _recognitionFrames.isNotEmpty && _recognitionFrames.last.rule == rule;
    final code = direct
        ? 'source_location_nonprogress_direct_recursion'
        : 'source_location_nonprogress_mutual_recursion';
    scope
      ..entered = true
      ..completion = _RecursiveObservationCompletion(
        identity: identity,
        entryCodeUnit: entryCodeUnit,
        selectedMatch: null,
        acceptedExitCodeUnit: null,
        outcome: 'rejected',
        diagnostic: code,
      );
    return RuntimeInterpreterException(
      code,
      diagnostic: diagnostic(
        stage: 'runtime_execution',
        summary: 'Dart recursive recognition made no progress',
        detail: code,
        code: code,
        ruleLabel: rule,
      ),
    );
  }

  void noteRecursiveObservationEntry(String rule, int entryCodeUnit) {
    if (!recursiveObservationExpects(rule)) {
      return;
    }
    final scope = _recursiveObservationScopes.last..entered = true;
    final frame = _recognitionFrames.last;
    frame
      ..entryCodeUnit = entryCodeUnit
      ..observationScope = scope;
  }

  void noteRecognitionMatch(RuntimeRegexMatch match) {
    if (_recognitionFrames.isNotEmpty) {
      _recognitionFrames.last.selectedMatch = match;
    }
  }

  void setGapPhase(String ruleLabel, String phase) {
    final frame = _recognitionFrame(ruleLabel);
    recognitionAuthority.setGapPhase(frame.authorityFrame, phase);
  }

  void installGapCandidate(String ruleLabel, RuntimeRegexMatch match) {
    final frame = _recognitionFrame(ruleLabel);
    recognitionAuthority.installGapCandidate(
      frame.authorityFrame,
      match.codeUnitStart,
    );
  }

  void commitGapCandidate(String ruleLabel) {
    final frame = _recognitionFrame(ruleLabel);
    final selected = frame.selectedMatch;
    if (selected == null) {
      return;
    }
    recognitionAuthority.commitGapCandidate(
      frame.authorityFrame,
      cursorCodeUnit: cursorCodeUnit,
      selectedEndCodeUnit: selected.codeUnitEnd,
    );
  }

  void installGapTail(String ruleLabel, String phase) {
    final frame = _recognitionFrame(ruleLabel);
    recognitionAuthority.installGapTail(
      frame.authorityFrame,
      input.length,
      phase,
    );
  }

  RecognitionGapEntrySlot? gapEntrySlotForEdge(_CurrentActionEdge currentEdge) {
    final frame = _recognitionFrame(currentEdge.ruleLabel);
    return recognitionAuthority.gapEntrySlot(
      frame.authorityFrame,
      targetRule: currentEdge.target.label,
      regexIndex: currentEdge.edge.childRegexIndex,
      slotId: currentEdge.edge.targetSlotId,
      selectorKind: currentEdge.edge.selectorKind,
      authoredSelector: currentEdge.edge.authoredSelector,
    );
  }

  Map<String, Object?>? gapEntrySlotValue(String ruleLabel) {
    final frame = _recognitionFrame(ruleLabel);
    final value = recognitionAuthority.entrySlot(frame.authorityFrame);
    return value == null ? null : Map<String, Object?>.from(value);
  }

  RecognitionGapContext currentGap(String ruleLabel, String accessor) {
    final frame = _recognitionFrame(ruleLabel);
    return recognitionAuthority.currentGap(frame.authorityFrame, accessor);
  }

  Span gapSpan(String ruleLabel, String accessor) {
    final gap = currentGap(ruleLabel, accessor);
    final sourceContext = SourceLocationContext(
      ruleRole: '$ruleLabel:gap_context',
      invocationRole: 'gap_owner',
    );
    final start = sourceAuthority.positionFromCodeUnit(
      sourceId: gap.sourceId,
      codeUnitOffset: gap.startCodeUnit,
      context: sourceContext,
    );
    final end = sourceAuthority.positionFromCodeUnit(
      sourceId: gap.sourceId,
      codeUnitOffset: gap.endCodeUnit,
      context: sourceContext,
    );
    return sourceAuthority.directSpan(
      start: start,
      end: end,
      provenance: 'gap',
      context: sourceContext,
    );
  }

  String gapText(String ruleLabel, String accessor) {
    final sourceContext = SourceLocationContext(
      ruleRole: '$ruleLabel:gap_context',
      invocationRole: 'gap_owner',
    );
    return sourceAuthority.materialize(
      gapSpan(ruleLabel, accessor),
      context: sourceContext,
    );
  }

  void bindRecursiveObservation(
    String ruleLabel,
    String target,
    _RecursiveObservationScope scope, {
    Object? error,
  }) {
    if (_recursiveObservationScopes.isEmpty ||
        !identical(_recursiveObservationScopes.last, scope)) {
      throw StateError('recursive observation scope order is invalid');
    }
    final completion = scope.completion;
    if (completion == null) {
      throw StateError(
        'recursive observation for ${scope.rule} completed without a record: '
        '$error',
      );
    }
    final sourceContext = SourceLocationContext(
      ruleRole: '$ruleLabel:recursive_observation',
      invocationRole: 'recursive_observation',
    );
    Map<String, Object?> position(int codeUnitOffset) => sourceAuthority
        .positionFromCodeUnit(
          sourceId: 'input',
          codeUnitOffset: codeUnitOffset,
          context: sourceContext,
        )
        .toJson();
    Map<String, Object?> span(RuntimeRegexMatch match) {
      final start = sourceAuthority.positionFromCodeUnit(
        sourceId: 'input',
        codeUnitOffset: match.codeUnitStart,
        context: sourceContext,
      );
      final end = sourceAuthority.positionFromCodeUnit(
        sourceId: 'input',
        codeUnitOffset: match.codeUnitEnd,
        context: sourceContext,
      );
      return sourceAuthority
          .directSpan(
            start: start,
            end: end,
            provenance: 'match',
            context: sourceContext,
          )
          .toJson();
    }

    final record = <String, Object?>{
      'source_id': 'input',
      'rule_label': completion.identity.rule,
      'invocation_id': completion.identity.invocationId,
      'parent_invocation_id': completion.identity.parentInvocationId,
      'entry_position': position(completion.entryCodeUnit),
      'selected_match': completion.selectedMatch == null
          ? null
          : span(completion.selectedMatch!),
      'accepted_exit': completion.acceptedExitCodeUnit == null
          ? null
          : position(completion.acceptedExitCodeUnit!),
      'outcome': completion.outcome,
      'diagnostic': completion.diagnostic,
    };
    recordRuleLocalBinding(target);
    hashes[target] = _asHash(record);
    variables.remove(target);
    arrays.remove(target);
    _recursiveObservationScopes.removeLast();
  }

  void recognitionCheckpoint(String ruleLabel, String slot) {
    final frame = _recognitionFrame(ruleLabel);
    final actual = _recognitionFrameState(ruleLabel);
    recognitionAuthority.setFrameState(frame.authorityFrame, actual);
    final token = recognitionAuthority.checkpoint(
      frame.authorityFrame,
      '$ruleLabel:$slot',
    );
    frame.tokens[slot] = _RecognitionRuntimeToken(
      authorityToken: token,
      snapshot: actual,
    );
  }

  bool recognitionAttempt(
    String ruleLabel,
    String slot, {
    required bool matched,
    required Object? payload,
  }) {
    final frame = _recognitionFrame(ruleLabel);
    final token = _recognitionToken(frame, slot, '$ruleLabel:recognize_once');
    return recognitionAuthority.attempt(
      frame.authorityFrame,
      token.authorityToken,
      matched: matched,
      payload: payload,
      state: _recognitionFrameState(ruleLabel),
    );
  }

  Object? recognitionCommit(String ruleLabel, String slot) {
    final frame = _recognitionFrame(ruleLabel);
    final token = _recognitionToken(
      frame,
      slot,
      '$ruleLabel:recognition_commit',
    );
    recognitionAuthority.setFrameState(
      frame.authorityFrame,
      _recognitionFrameState(ruleLabel),
    );
    final payload = recognitionAuthority.commit(
      frame.authorityFrame,
      token.authorityToken,
    );
    frame.tokens.remove(slot);
    return payload;
  }

  void recognitionRollback(String ruleLabel, String slot) {
    final frame = _recognitionFrame(ruleLabel);
    final token = _recognitionToken(
      frame,
      slot,
      '$ruleLabel:recognition_rollback',
    );
    recognitionAuthority.setFrameState(
      frame.authorityFrame,
      _recognitionFrameState(ruleLabel),
    );
    recognitionAuthority.rollback(frame.authorityFrame, token.authorityToken);
    _applyRecognitionFrameState(
      ruleLabel,
      recognitionAuthority.frameState(frame.authorityFrame),
    );
    frame.tokens.remove(slot);
  }

  _RecognitionRuntimeFrame _recognitionFrame(String ruleLabel) {
    if (_recognitionFrames.isEmpty ||
        _recognitionFrames.last.rule != ruleLabel) {
      throw StateError('recognition invocation is not active for $ruleLabel');
    }
    return _recognitionFrames.last;
  }

  _RecognitionRuntimeToken _recognitionToken(
    _RecognitionRuntimeFrame frame,
    String slot,
    String origin,
  ) {
    return frame.tokens[slot] ??
        recognitionAuthority.rejectMissingToken(frame.authorityFrame, origin);
  }

  SourceLocationContext _typedSourceContext(
    String ruleLabel,
    String projection,
  ) => SourceLocationContext(
    ruleRole: '$ruleLabel:$projection',
    invocationRole: 'compatibility_projection',
  );

  Position? typedPositionFromCodeUnit(
    int codeUnitOffset,
    String ruleLabel,
    String projection,
  ) {
    try {
      return sourceAuthority.positionFromCodeUnit(
        sourceId: 'input',
        codeUnitOffset: codeUnitOffset,
        context: _typedSourceContext(ruleLabel, projection),
      );
    } on SourceLocationException {
      return null;
    }
  }

  Position? typedPositionFromScalar(
    int scalarOffset,
    String ruleLabel,
    String projection,
  ) {
    try {
      return sourceAuthority.position(
        sourceId: 'input',
        offset: scalarOffset,
        context: _typedSourceContext(ruleLabel, projection),
      );
    } on SourceLocationException {
      return null;
    }
  }

  Span? typedSpanFromCodeUnits(
    int startCodeUnit,
    int endCodeUnit,
    String ruleLabel,
    String projection,
  ) {
    final start = typedPositionFromCodeUnit(
      startCodeUnit,
      ruleLabel,
      projection,
    );
    final end = typedPositionFromCodeUnit(endCodeUnit, ruleLabel, projection);
    if (start == null || end == null) {
      return null;
    }
    try {
      return sourceAuthority.directSpan(
        start: start,
        end: end,
        provenance: projection,
        context: _typedSourceContext(ruleLabel, projection),
      );
    } on SourceLocationException {
      return null;
    }
  }

  Span? typedSpanFromScalars(
    int start,
    int end,
    String ruleLabel,
    String projection,
  ) {
    final startPosition = typedPositionFromScalar(start, ruleLabel, projection);
    final endPosition = typedPositionFromScalar(end, ruleLabel, projection);
    if (startPosition == null || endPosition == null) {
      return null;
    }
    try {
      return sourceAuthority.directSpan(
        start: startPosition,
        end: endPosition,
        provenance: projection,
        context: _typedSourceContext(ruleLabel, projection),
      );
    } on SourceLocationException {
      return null;
    }
  }

  String? typedSpanTextFromCodeUnits(
    int start,
    int end,
    String ruleLabel,
    String projection,
  ) {
    final span = typedSpanFromCodeUnits(start, end, ruleLabel, projection);
    if (span == null) {
      return null;
    }
    try {
      return sourceAuthority.materialize(
        span,
        context: _typedSourceContext(ruleLabel, projection),
      );
    } on SourceLocationException {
      return null;
    }
  }

  int? typedSpanLengthFromCodeUnits(
    int start,
    int end,
    String ruleLabel,
    String projection,
  ) => typedSpanFromCodeUnits(start, end, ruleLabel, projection)?.scalarLength;

  int? typedSpanStartOffsetFromCodeUnits(
    int start,
    int end,
    String ruleLabel,
    String projection,
  ) => typedSpanFromCodeUnits(start, end, ruleLabel, projection)?.start;

  int? typedPositionOffsetFromCodeUnit(
    int codeUnitOffset,
    String ruleLabel,
    String projection,
  ) => typedPositionFromCodeUnit(codeUnitOffset, ruleLabel, projection)?.offset;

  SourceCoordinates? typedCoordinatesFromCodeUnit(
    int codeUnitOffset,
    String ruleLabel,
    String projection,
  ) {
    final position = typedPositionFromCodeUnit(
      codeUnitOffset,
      ruleLabel,
      projection,
    );
    if (position == null) {
      return null;
    }
    try {
      return sourceAuthority.coordinates(
        position,
        context: _typedSourceContext(ruleLabel, projection),
      );
    } on SourceLocationException {
      return null;
    }
  }

  int? typedPositionLineFromCodeUnit(
    int codeUnitOffset,
    String ruleLabel,
    String projection,
  ) =>
      typedCoordinatesFromCodeUnit(codeUnitOffset, ruleLabel, projection)?.line;

  int? typedPositionColumnFromCodeUnit(
    int codeUnitOffset,
    String ruleLabel,
    String projection,
  ) => typedCoordinatesFromCodeUnit(
    codeUnitOffset,
    ruleLabel,
    projection,
  )?.column;

  int? typedSourceLength() => sourceAuthority.sourceScalarLength('input');

  String? typedSourceText(String ruleLabel, String projection) {
    final length = typedSourceLength();
    if (length == null) {
      return null;
    }
    final span = typedSpanFromScalars(0, length, ruleLabel, projection);
    if (span == null) {
      return null;
    }
    try {
      return sourceAuthority.materialize(
        span,
        context: _typedSourceContext(ruleLabel, projection),
      );
    } on SourceLocationException {
      return null;
    }
  }

  String? typedSourceSlice(
    int start,
    int width,
    String ruleLabel,
    String projection,
  ) {
    final length = typedSourceLength();
    if (length == null) {
      return null;
    }
    final clampedStart = start.clamp(0, length);
    final end = math.min(length, clampedStart + width);
    final span = typedSpanFromScalars(clampedStart, end, ruleLabel, projection);
    if (span == null) {
      return null;
    }
    try {
      return sourceAuthority.materialize(
        span,
        context: _typedSourceContext(ruleLabel, projection),
      );
    } on SourceLocationException {
      return null;
    }
  }

  bool typedMarkSet(
    String ruleLabel,
    String name,
    int codeUnitOffset,
    String projection,
  ) {
    if (typedPositionFromCodeUnit(codeUnitOffset, ruleLabel, projection) ==
        null) {
      return false;
    }
    marksFor(ruleLabel)[name] = codeUnitOffset;
    return true;
  }

  int? typedMarkCodeUnit(String ruleLabel, String name, String projection) {
    final offset = marksFor(ruleLabel)[name];
    if (offset == null ||
        typedPositionFromCodeUnit(offset, ruleLabel, projection) == null) {
      return null;
    }
    return offset;
  }

  void clearStores() {
    variables.clear();
    arrays.clear();
    hashes.clear();
    _bindingIdentities.clear();
  }

  int ensureBindingIdentity(String name) {
    return _bindingIdentities.putIfAbsent(name, () => _nextBindingIdentity++);
  }

  int bindFreshIdentity(String name) {
    final identity = _nextBindingIdentity++;
    _bindingIdentities[name] = identity;
    return identity;
  }

  int? visibleBindingIdentity(String name) {
    if (!variables.containsKey(name) &&
        !arrays.containsKey(name) &&
        !hashes.containsKey(name)) {
      return null;
    }
    return ensureBindingIdentity(name);
  }

  int? activateReceiverMutation(String name) {
    final identity = visibleBindingIdentity(name);
    if (identity == null || _activeReceiverMutations.containsKey(identity)) {
      return null;
    }
    _activeReceiverMutations[identity] = name;
    return identity;
  }

  void deactivateReceiverMutation(int identity) {
    _activeReceiverMutations.remove(identity);
  }

  String? activeReceiverMutationFor(String name) {
    final identity = visibleBindingIdentity(name);
    return identity == null ? null : _activeReceiverMutations[identity];
  }

  void bindUserFunctionParam(String name, Object? value) {
    final copied = _copyValue(value);
    bindFreshIdentity(name);
    variables[name] = copied;
    if (copied is List) {
      arrays[name] = _asArray(copied);
      hashes.remove(name);
    } else if (copied is Map) {
      hashes[name] = _asHash(copied);
      arrays.remove(name);
    } else {
      arrays.remove(name);
      hashes.remove(name);
    }
  }

  void enterRule(String label) {
    _ruleStack.add(label);
  }

  void exitRule() {
    if (_ruleStack.isNotEmpty) {
      _ruleStack.removeLast();
    }
  }

  void enterRuleLocalBindingScope() {
    _ruleLocalBindingScopes.add(<String, _VariableSnapshot>{});
  }

  void exitRuleLocalBindingScope() {
    if (_ruleLocalBindingScopes.isEmpty) {
      return;
    }
    final scope = _ruleLocalBindingScopes.removeLast();
    for (final entry in scope.entries) {
      entry.value.restore(this, entry.key);
    }
  }

  void recordRuleLocalBinding(String name) {
    if (_ruleLocalBindingSuppressionDepth > 0 ||
        _ruleLocalBindingScopes.isEmpty) {
      return;
    }
    final scope = _ruleLocalBindingScopes.last;
    scope.putIfAbsent(name, () => _VariableSnapshot.capture(this, name));
  }

  void suspendRuleLocalBindingTracking() {
    _ruleLocalBindingSuppressionDepth += 1;
  }

  void resumeRuleLocalBindingTracking() {
    if (_ruleLocalBindingSuppressionDepth > 0) {
      _ruleLocalBindingSuppressionDepth -= 1;
    }
  }

  RuntimeDiagnostic diagnostic({
    required String stage,
    required String summary,
    required String detail,
    String? code,
    String? helperName,
    int? actualArity,
    String? expectedArity,
    String? callableName,
    String? expected,
    int? got,
    String? valueKind,
    String? name,
    List<String>? cycle,
    String? ruleLabel,
    String? handlerSourceLabel,
    String? targetRule,
    int? regexIndex,
    int? expectedRegexIndex,
    int? actualRegexIndex,
    String? operation,
    String? binding,
    String? method,
    String? attempt,
    List<String>? expectedKinds,
    int? segmentIndex,
    List<Object?>? path,
    String? actualKind,
    String? reason,
    String? expectedKind,
    int? arrayIndex,
    int? length,
    Map<String, Object?>? sourceSpan,
  }) {
    final effectiveRule = ruleLabel ?? currentRuleLabel ?? topRule;
    return engine._diagnostic(
      stage: stage,
      summary: summary,
      detail: detail,
      code: code,
      helperName: helperName,
      actualArity: actualArity,
      expectedArity: expectedArity,
      callableName: callableName,
      expected: expected,
      got: got,
      valueKind: valueKind,
      name: name,
      cycle: cycle,
      topRule: topRule,
      ruleLabel: effectiveRule,
      handlerSourceLabel: handlerSourceLabel,
      targetRule: targetRule,
      regexIndex: regexIndex,
      expectedRegexIndex: expectedRegexIndex,
      actualRegexIndex: actualRegexIndex,
      operation: operation,
      binding: binding,
      method: method,
      attempt: attempt,
      expectedKinds: expectedKinds,
      segmentIndex: segmentIndex,
      path: path,
      actualKind: actualKind,
      reason: reason,
      expectedKind: expectedKind,
      arrayIndex: arrayIndex,
      length: length,
      sourceSpan: sourceSpan,
    );
  }

  _ScopedVariableBinding enterScopedScalar(String name, Object? value) {
    final binding = _ScopedVariableBinding(
      name: name,
      snapshot: _VariableSnapshot.capture(this, name),
    );
    bindFreshIdentity(name);
    variables[name] = _copyValue(value);
    arrays.remove(name);
    hashes.remove(name);
    return binding;
  }

  void exitScopedVariable(_ScopedVariableBinding binding) {
    binding.snapshot.restore(this, binding.name);
  }

  void saveCursor(String ruleLabel, String projection) {
    if (typedPositionFromCodeUnit(cursorCodeUnit, ruleLabel, projection) !=
        null) {
      cursorStack.add(cursorCodeUnit);
    }
  }

  void restoreCursor(String ruleLabel, String projection) {
    if (cursorStack.isEmpty) {
      return;
    }
    final target = cursorStack.removeLast();
    if (typedPositionFromCodeUnit(target, ruleLabel, projection) != null) {
      _setCursorCodeUnit(target);
    }
  }

  void rewindToLocalMatchStart(String ruleLabel, String projection) {
    final target = registers.localMatch?.codeUnitStart;
    if (target == null ||
        typedPositionFromCodeUnit(target, ruleLabel, projection) == null) {
      return;
    }
    _setCursorCodeUnit(target);
  }

  void rewindToEntryMatchStart(String ruleLabel, String projection) {
    final target = registers.entryMatch?.codeUnitStart;
    if (target == null ||
        typedPositionFromCodeUnit(target, ruleLabel, projection) == null) {
      return;
    }
    _setCursorCodeUnit(target);
  }

  void _setCursorCodeUnit(int codeUnitCursor) {
    cursorCodeUnit = codeUnitCursor.clamp(0, input.length);
    registers = registers.withCursorCodeUnit(cursorCodeUnit);
  }

  void startCaptureSlice(String ruleLabel, String projection) {
    startCaptureSliceAt(cursorCodeUnit, ruleLabel, projection);
  }

  void startCaptureSliceAt(
    int codeUnitOffset,
    String ruleLabel,
    String projection,
  ) {
    if (typedPositionFromCodeUnit(codeUnitOffset, ruleLabel, projection) !=
        null) {
      registers = registers.withCaptureStartCodeUnit(codeUnitOffset);
    }
  }
}

final class _RecognitionRuntimeFrame {
  _RecognitionRuntimeFrame({
    required this.rule,
    required this.authorityFrame,
    required this.identity,
    required this.priorMarks,
  });

  final String rule;
  final Object authorityFrame;
  final RecognitionInvocationIdentity identity;
  final Map<String, int>? priorMarks;
  int entryCodeUnit = 0;
  RuntimeRegexMatch? selectedMatch;
  _RecursiveObservationScope? observationScope;
  final Map<String, _RecognitionRuntimeToken> tokens =
      <String, _RecognitionRuntimeToken>{};
}

final class _RecursiveObservationScope {
  _RecursiveObservationScope(this.rule);

  final String rule;
  bool entered = false;
  _RecursiveObservationCompletion? completion;
}

final class _RecursiveObservationCompletion {
  const _RecursiveObservationCompletion({
    required this.identity,
    required this.entryCodeUnit,
    required this.selectedMatch,
    required this.acceptedExitCodeUnit,
    required this.outcome,
    required this.diagnostic,
  });

  final RecognitionInvocationIdentity identity;
  final int entryCodeUnit;
  final RuntimeRegexMatch? selectedMatch;
  final int? acceptedExitCodeUnit;
  final String outcome;
  final String? diagnostic;
}

final class _RecognitionRuntimeToken {
  const _RecognitionRuntimeToken({
    required this.authorityToken,
    required this.snapshot,
  });

  final Object authorityToken;
  final RecognitionFrameState snapshot;
}

final class _StatementStep {
  const _StatementStep(this.nextIndex);

  final int nextIndex;
}

final class _ValueStatementStep {
  const _ValueStatementStep(this.nextIndex, this.flow);

  final int nextIndex;
  final _ValueBlockFlow flow;
}

final class _MarkerIfSelection {
  const _MarkerIfSelection({
    required this.start,
    required this.end,
    required this.nextIndex,
  });

  final int? start;
  final int? end;
  final int nextIndex;
}

final class _MarkerSwitchSelection {
  const _MarkerSwitchSelection({
    required this.start,
    required this.end,
    required this.nextIndex,
  });

  final int? start;
  final int? end;
  final int nextIndex;
}

final class _ValueBlockFlow {
  const _ValueBlockFlow.continued() : returned = false, value = null;

  const _ValueBlockFlow.returned(this.value) : returned = true;

  final bool returned;
  final Object? value;
}

final class _LocalReturnPayload {
  const _LocalReturnPayload.undef() : hasValue = false, value = null;

  const _LocalReturnPayload.value(this.value) : hasValue = true;

  final bool hasValue;
  final ActionExpr? value;
}

final class _ScopedVariableBinding {
  const _ScopedVariableBinding({required this.name, required this.snapshot});

  final String name;
  final _VariableSnapshot snapshot;
}

final class _VariableSnapshot {
  const _VariableSnapshot({
    required this.hadVariable,
    required this.variable,
    required this.hadArray,
    required this.array,
    required this.hadHash,
    required this.hash,
    required this.hadIdentity,
    required this.identity,
  });

  factory _VariableSnapshot.capture(
    _RuntimeExecutionContext context,
    String name,
  ) {
    return _VariableSnapshot(
      hadVariable: context.variables.containsKey(name),
      variable: _copyValue(context.variables[name]),
      hadArray: context.arrays.containsKey(name),
      array: [
        for (final item in context.arrays[name] ?? const []) _copyValue(item),
      ],
      hadHash: context.hashes.containsKey(name),
      hash: {
        for (final entry
            in (context.hashes[name] ?? const <String, Object?>{}).entries)
          entry.key: _copyValue(entry.value),
      },
      hadIdentity: context._bindingIdentities.containsKey(name),
      identity: context._bindingIdentities[name],
    );
  }

  final bool hadVariable;
  final Object? variable;
  final bool hadArray;
  final List<Object?> array;
  final bool hadHash;
  final Map<String, Object?> hash;
  final bool hadIdentity;
  final int? identity;

  void restore(_RuntimeExecutionContext context, String name) {
    if (hadVariable) {
      context.variables[name] = _copyValue(variable);
    } else {
      context.variables.remove(name);
    }
    if (hadArray) {
      context.arrays[name] = [for (final item in array) _copyValue(item)];
    } else {
      context.arrays.remove(name);
    }
    if (hadHash) {
      context.hashes[name] = {
        for (final entry in hash.entries) entry.key: _copyValue(entry.value),
      };
    } else {
      context.hashes.remove(name);
    }
    if (hadIdentity) {
      context._bindingIdentities[name] = identity!;
    } else {
      context._bindingIdentities.remove(name);
    }
  }
}

final class _RuntimeStoreSnapshot {
  const _RuntimeStoreSnapshot({
    required this.variables,
    required this.arrays,
    required this.hashes,
    required this.bindingIdentities,
  });

  factory _RuntimeStoreSnapshot.capture(_RuntimeExecutionContext context) {
    return _RuntimeStoreSnapshot(
      variables: {
        for (final entry in context.variables.entries)
          entry.key: _copyValue(entry.value),
      },
      arrays: {
        for (final entry in context.arrays.entries)
          entry.key: [for (final item in entry.value) _copyValue(item)],
      },
      hashes: {
        for (final entry in context.hashes.entries)
          entry.key: {
            for (final hashEntry in entry.value.entries)
              hashEntry.key: _copyValue(hashEntry.value),
          },
      },
      bindingIdentities: Map<String, int>.from(context._bindingIdentities),
    );
  }

  final Map<String, Object?> variables;
  final Map<String, List<Object?>> arrays;
  final Map<String, Map<String, Object?>> hashes;
  final Map<String, int> bindingIdentities;

  void restore(_RuntimeExecutionContext context) {
    context.clearStores();
    context.variables.addAll({
      for (final entry in variables.entries) entry.key: _copyValue(entry.value),
    });
    context.arrays.addAll({
      for (final entry in arrays.entries)
        entry.key: [for (final item in entry.value) _copyValue(item)],
    });
    context.hashes.addAll({
      for (final entry in hashes.entries)
        entry.key: {
          for (final hashEntry in entry.value.entries)
            hashEntry.key: _copyValue(hashEntry.value),
        },
    });
    context._bindingIdentities.addAll(bindingIdentities);
  }
}

final class _NestedWriteRoot {
  const _NestedWriteRoot._(this.name, this.value, this.kind, this.present);

  const _NestedWriteRoot.absent(String name)
    : this._(name, null, _NestedWriteRootKind.scalar, false);

  const _NestedWriteRoot.scalar(String name, Object? value)
    : this._(name, value, _NestedWriteRootKind.scalar, true);

  const _NestedWriteRoot.array(String name, Object? value)
    : this._(name, value, _NestedWriteRootKind.array, true);

  const _NestedWriteRoot.hash(String name, Object? value)
    : this._(name, value, _NestedWriteRootKind.hash, true);

  final String name;
  final Object? value;
  final _NestedWriteRootKind kind;
  final bool present;

  void store(_RuntimeExecutionContext context, Object? value) {
    context.ensureBindingIdentity(name);
    switch (kind) {
      case _NestedWriteRootKind.scalar:
        context.variables[name] = _copyValue(value);
      case _NestedWriteRootKind.array:
        context.arrays[name] = _asArray(value);
      case _NestedWriteRootKind.hash:
        context.hashes[name] = _asHash(value);
    }
  }
}

enum _NestedWriteRootKind { scalar, array, hash }

final class _EvaluatedWriteSegment {
  const _EvaluatedWriteSegment({required this.value, required this.sourceSpan});

  final Object? value;
  final ActionSourceSpan sourceSpan;
}

final class _WriteSelector {
  const _WriteSelector.key(this.key, this.sourceSpan)
    : index = null,
      expectedKind = 'harray';

  const _WriteSelector.index(this.index, this.sourceSpan)
    : key = null,
      expectedKind = 'array';

  final String? key;
  final int? index;
  final String expectedKind;
  final ActionSourceSpan sourceSpan;

  Object get pathValue => key ?? index!;
}

final class _RegexPlan {
  _RegexPlan({required this.patterns})
    : matcher = RuntimeRegexAlternation.compile(patterns);

  final List<String> patterns;
  final RuntimeRegexAlternation matcher;
}

final class _MatchedActionEdge {
  const _MatchedActionEdge({required this.edge, required this.target});

  final CompiledActionEdge edge;
  final DependencyRef target;
}

final class _CurrentActionEdge {
  _CurrentActionEdge({
    required this.ruleLabel,
    required this.edge,
    required this.target,
  });

  final String ruleLabel;
  final CompiledActionEdge edge;
  final DependencyRef target;
  bool childDispatched = false;
}

final class _RuleResult {
  const _RuleResult({required this.matched, required this.value});

  final bool matched;
  final Object? value;
}

final class _ActionReturn implements Exception {
  const _ActionReturn(this.value);

  final Object? value;
}

final class _ActionNext implements Exception {
  const _ActionNext();
}

final class _NextableBool {
  const _NextableBool.value(this.value) : nexted = false;

  const _NextableBool.nexted() : value = false, nexted = true;

  final bool value;
  final bool nexted;
}

const _explicitActionResultRepetitionModes = <String>{
  'Star',
  'Plus',
  'Optional',
  'Or',
  'OrPlus',
  'OrBounded',
};

bool _collectsExplicitActionIterationValues(CompiledRule rule) {
  return rule.actionEdges.isNotEmpty &&
      _explicitActionResultRepetitionModes.contains(rule.modeMetadata.name);
}

String? _recursiveObservationDiagnostic(Object? error) {
  if (error == null) {
    return null;
  }
  if (error is RecognitionTransactionException) {
    return error.toJson()['code'] as String?;
  }
  if (error is RuntimeInterpreterException) {
    final code = error.diagnostic?.code;
    if (code != null) {
      return code;
    }
    final transaction = RegExp(
      r'LINKEDSPEC_RECOGNITION_TRANSACTION_ERROR:([a-z0-9_]+)',
    ).firstMatch(error.message);
    if (transaction != null) {
      return transaction.group(1);
    }
    final sourceLocation = RegExp(
      r'(source_location_[a-z0-9_]+)',
    ).firstMatch(error.message);
    return sourceLocation?.group(1);
  }
  if (error is RuntimeExitNow) {
    return 'runtime_exit';
  }
  return null;
}

_NextableBool _nextableBool(bool Function() callback) {
  try {
    return _NextableBool.value(callback());
  } on _ActionNext {
    return const _NextableBool.nexted();
  }
}

_RuleResult _returned(Object? value) {
  return _RuleResult(matched: value != null, value: _copyValue(value));
}

Object? _captureAt(
  RuntimeRegexMatch? match,
  List<ActionExpr> args,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  if (match == null || args.isEmpty) {
    return null;
  }
  final indexValue = context.engine._evaluateExpression(
    args.first,
    context,
    ruleLabel,
    currentEdge: currentEdge,
  );
  final index = indexValue is num
      ? indexValue.toInt()
      : int.tryParse('$indexValue');
  if (index == null || index < 0 || index >= match.captures.length) {
    return null;
  }
  return match.captures[index];
}

String _ruleNameFromExpr(
  ActionExpr expr,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  final name = _variableName(expr);
  if (name != null) {
    return name;
  }
  final evaluated = context.engine._evaluateExpression(
    expr,
    context,
    ruleLabel,
    currentEdge: currentEdge,
  );
  return _stringValue(evaluated);
}

String? _scalarTargetName(ActionExpr expr) {
  final variable = _variableName(expr);
  if (variable != null) {
    return variable;
  }
  if (expr is! ActionCallExpr ||
      expr.name != 'scalar' ||
      expr.args.length != 1) {
    return null;
  }
  return _variableName(expr.args.single.value);
}

bool _hasArrayValue(_RuntimeExecutionContext context, String name) {
  return context.arrays.containsKey(name) || context.variables[name] is List;
}

bool _hasHashValue(_RuntimeExecutionContext context, String name) {
  return context.hashes.containsKey(name) || context.variables[name] is Map;
}

String? _variableName(ActionExpr expr) {
  return switch (expr) {
    ActionVariableExpr(:final name) => name,
    _ => null,
  };
}

int? _literalNonNegativeInteger(ActionExpr expr) {
  if (expr is! ActionNumberLiteralExpr) {
    return null;
  }
  final value = expr.value;
  if (value < 0 || value != value.truncateToDouble()) {
    return null;
  }
  return value.toInt();
}

List<Object?> _asArray(Object? value) {
  if (value is List<Object?>) {
    return [for (final item in value) _copyValue(item)];
  }
  if (value is List) {
    return [for (final item in value) _copyValue(item)];
  }
  return <Object?>[];
}

Map<String, Object?> _asHash(Object? value) {
  if (value is Map<String, Object?>) {
    return {
      for (final entry in value.entries) entry.key: _copyValue(entry.value),
    };
  }
  if (value is Map) {
    return {
      for (final entry in value.entries)
        '${entry.key}': _copyValue(entry.value),
    };
  }
  return <String, Object?>{};
}

List<Object?> _arrayValueFor(_RuntimeExecutionContext context, String name) {
  final variable = context.variables[name];
  if (variable is List) {
    return [for (final item in variable) _copyValue(item)];
  }
  final stored = context.arrays[name];
  if (stored != null) {
    return [for (final item in stored) _copyValue(item)];
  }
  return <Object?>[];
}

Object? _bindingValueFor(_RuntimeExecutionContext context, String name) {
  if (context.variables.containsKey(name)) {
    return _copyValue(context.variables[name]);
  }
  if (context.arrays.containsKey(name)) {
    return List<Object?>.unmodifiable(_arrayValueFor(context, name));
  }
  if (context.hashes.containsKey(name)) {
    return Map<String, Object?>.unmodifiable(_hashValueFor(context, name));
  }
  if (context.engine.compiledSpec.rule(name) != null) {
    return const <Object?>[];
  }
  return null;
}

Never _bindingKindMismatch(String name, String expectedKind, Object? actual) {
  final actualKind = switch (actual) {
    List() => 'array',
    Map() => 'harray',
    _ => 'scalar',
  };
  throw RuntimeInterpreterException(
    'binding_kind_mismatch identifier=$name '
    'expected_kind=$expectedKind actual_kind=$actualKind',
  );
}

List<Object?> _bareArrayForMutation(
  _RuntimeExecutionContext context,
  String name,
) {
  if (context.variables.containsKey(name)) {
    final value = context.variables[name];
    if (value is List) {
      return _asArray(value);
    }
    _bindingKindMismatch(name, 'array', value);
  }
  if (context.arrays.containsKey(name)) {
    return _arrayValueFor(context, name);
  }
  if (context.hashes.containsKey(name)) {
    _bindingKindMismatch(name, 'array', context.hashes[name]);
  }
  return <Object?>[];
}

List<Object?> _storeBareArray(
  _RuntimeExecutionContext context,
  String name,
  List<Object?> values,
) {
  final updated = [for (final item in values) _copyValue(item)];
  context.ensureBindingIdentity(name);
  if (context.arrays.containsKey(name) &&
      !context.variables.containsKey(name)) {
    context.arrays[name] = updated;
    context.hashes.remove(name);
  } else {
    context.variables[name] = updated;
    context.arrays.remove(name);
    context.hashes.remove(name);
  }
  return List<Object?>.unmodifiable([
    for (final item in updated) _copyValue(item),
  ]);
}

List<Object?> _appendArrayValue(
  _RuntimeExecutionContext context,
  String name,
  Object? value,
) {
  final stored = _copyValue(value);
  final updated = _bareArrayForMutation(context, name)..add(stored);
  return _storeBareArray(context, name, updated);
}

List<Object?> _replaceBareArrayValue(
  _RuntimeExecutionContext context,
  String name,
  List<Object?> values,
) {
  _bareArrayForMutation(context, name);
  return _storeBareArray(context, name, values);
}

Map<String, Object?> _hashValueFor(
  _RuntimeExecutionContext context,
  String name,
) {
  final variable = context.variables[name];
  if (variable is Map) {
    return _asHash(variable);
  }
  final stored = context.hashes[name];
  if (stored != null) {
    return {
      for (final entry in stored.entries) entry.key: _copyValue(entry.value),
    };
  }
  return <String, Object?>{};
}

Map<String, Object?> _bareHashForMutation(
  _RuntimeExecutionContext context,
  String name,
) {
  if (context.variables.containsKey(name)) {
    final value = context.variables[name];
    if (value is Map) {
      return _asHash(value);
    }
    _bindingKindMismatch(name, 'harray', value);
  }
  if (context.hashes.containsKey(name)) {
    return _hashValueFor(context, name);
  }
  if (context.arrays.containsKey(name)) {
    _bindingKindMismatch(name, 'harray', context.arrays[name]);
  }
  return <String, Object?>{};
}

Map<String, Object?> _storeBareHash(
  _RuntimeExecutionContext context,
  String name,
  Map<String, Object?> values,
) {
  final updated = _asHash(values);
  context.ensureBindingIdentity(name);
  if (context.hashes.containsKey(name) &&
      !context.variables.containsKey(name)) {
    context.hashes[name] = updated;
    context.arrays.remove(name);
  } else {
    context.variables[name] = updated;
    context.arrays.remove(name);
    context.hashes.remove(name);
  }
  return Map<String, Object?>.unmodifiable(_asHash(updated));
}

Map<String, Object?> _setBareHashEntry(
  _RuntimeExecutionContext context,
  String name,
  String key,
  Object? value,
) {
  final updated = _bareHashForMutation(context, name);
  updated[key] = _copyValue(value);
  return _storeBareHash(context, name, updated);
}

Object? _readNested(
  Object? root,
  List<ActionAccessSegment> segments,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  var value = root;
  for (final segment in segments) {
    switch (segment) {
      case ActionKeyAccessSegment(value: final key):
        value = value is Map ? value[key] : null;
      case ActionIndexAccessSegment(:final expr):
        final index = context.engine._evaluateExpression(
          expr,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        );
        value = _indexValue(value, index);
    }
  }
  return value;
}

Object? _indexValue(Object? collection, Object? indexValue) {
  if (collection is Map) {
    return collection[_stringValue(indexValue)];
  }
  final index = indexValue is num
      ? indexValue.toInt()
      : int.tryParse('$indexValue');
  if (collection is List &&
      index != null &&
      index >= 0 &&
      index < collection.length) {
    return collection[index];
  }
  return null;
}

Object? _assignHashIndex(
  _RuntimeExecutionContext context,
  String name,
  ActionExpr key,
  ActionExpr value,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  if (context.variables.containsKey(name)) {
    final root = context.variables[name];
    if (root is Map) {
      final storedKey = _stringValue(
        context.engine._evaluateExpression(
          key,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
      );
      final storedValue = _copyValue(
        context.engine._evaluateExpression(
          value,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
      );
      return _setBareHashEntry(context, name, storedKey, storedValue);
    }
    if (root is List) {
      if (key is ActionStringLiteralExpr) {
        return null;
      }
      final list = _asArray(root);
      final indexValue = context.engine._evaluateExpression(
        key,
        context,
        ruleLabel,
        currentEdge: currentEdge,
      );
      final index = _arrayIndex(indexValue);
      if (index == null || index > list.length) {
        return null;
      }
      final storedValue = _copyValue(
        context.engine._evaluateExpression(
          value,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
      );
      if (index == list.length) {
        list.add(storedValue);
      } else {
        list[index] = storedValue;
      }
      context.ensureBindingIdentity(name);
      context.variables[name] = list;
      return _copyValue(list);
    }
    _bindingKindMismatch(name, 'harray', root);
  }

  final storedKey = _stringValue(
    context.engine._evaluateExpression(
      key,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    ),
  );
  final storedValue = _copyValue(
    context.engine._evaluateExpression(
      value,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    ),
  );
  return _setBareHashEntry(context, name, storedKey, storedValue);
}

ActionSourceSpan _bindingTargetSpan(ActionSourceSpan sourceSpan, String name) {
  return ActionSourceSpan(
    start: sourceSpan.start,
    end: sourceSpan.start + name.runes.length,
  );
}

Map<String, Object?> _receiverMutationSourceSpan(ActionSourceSpan span) {
  return {...span.toJson(), 'unit': 'unicode_scalar', 'provenance': 'authored'};
}

void _assertReceiverMutationWritable(
  _RuntimeExecutionContext context,
  String target,
  String attempt,
  ActionSourceSpan sourceSpan,
) {
  final activeBinding = context.activeReceiverMutationFor(target);
  if (activeBinding == null) {
    return;
  }
  _throwReceiverMutationReentrant(context, activeBinding, attempt, sourceSpan);
}

Never _throwReceiverMutationReentrant(
  _RuntimeExecutionContext context,
  String binding,
  String attempt,
  ActionSourceSpan sourceSpan,
) {
  final message =
      "cannot write active map_leaves! receiver binding '$binding' from "
      'its callback';
  throw RuntimeInterpreterException(
    message,
    diagnostic: context.diagnostic(
      stage: 'runtime_execution',
      summary: 'Dart map_leaves! receiver mutation failed',
      detail: message,
      code: 'receiver_mutation_reentrant',
      operation: 'map_leaves_mutation',
      binding: binding,
      method: 'map_leaves',
      attempt: attempt,
      sourceSpan: _receiverMutationSourceSpan(sourceSpan),
    ),
  );
}

_NestedWriteRoot _rootStorageForWrite(
  _RuntimeExecutionContext context,
  String base,
) {
  if (context.variables.containsKey(base)) {
    return _NestedWriteRoot.scalar(base, context.variables[base]);
  }
  if (context.arrays.containsKey(base)) {
    return _NestedWriteRoot.array(base, context.arrays[base]);
  }
  if (context.hashes.containsKey(base)) {
    return _NestedWriteRoot.hash(base, context.hashes[base]);
  }
  return _NestedWriteRoot.absent(base);
}

Object? _writeNested(
  _RuntimeExecutionContext context,
  String base,
  List<ActionWritePathSegment> segments,
  ActionExpr value,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  if (segments.isEmpty) {
    final message =
        "nested write carrier for binding '$base' must contain at least one "
        'typed path segment';
    throw RuntimeInterpreterException(
      message,
      diagnostic: context.diagnostic(
        stage: 'runtime_execution',
        summary: 'Dart nested write carrier validation failed',
        detail: message,
        code: 'nested_write_serialized_state_invalid',
        operation: 'nested_write_vivification',
        binding: base,
      ),
    );
  }
  final evaluatedSegments = _evaluateWriteSegments(
    segments,
    context,
    ruleLabel,
    currentEdge,
  );
  final storedValue = _copyValue(
    context.engine._evaluateExpression(
      value,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    ),
  );
  final rootStorage = _rootStorageForWrite(context, base);
  final selectors = _classifyWriteSelectors(context, base, evaluatedSegments);
  final root = rootStorage.present
      ? _copyValue(rootStorage.value)
      : _emptyContainer(selectors.first);
  _assignVivifiedNestedValue(context, base, root, selectors, storedValue);
  rootStorage.store(context, root);
  return _copyValue(root);
}

void _assignVivifiedNestedValue(
  _RuntimeExecutionContext context,
  String base,
  Object? root,
  List<_WriteSelector> segments,
  Object? value,
) {
  var node = root;
  for (var index = 0; index < segments.length; index += 1) {
    final isLast = index == segments.length - 1;
    final segment = segments[index];
    final path = [
      for (var pathIndex = 0; pathIndex < index; pathIndex += 1)
        segments[pathIndex].pathValue,
    ];
    if (segment.key case final key?) {
      if (node is! Map<String, Object?>) {
        _throwNestedWriteKindConflict(
          context,
          base,
          index,
          path,
          segment,
          node,
        );
      }
      if (isLast) {
        node[key] = _copyValue(value);
        continue;
      }
      if (!node.containsKey(key)) {
        final child = _emptyContainer(segments[index + 1]);
        node[key] = child;
        node = child;
      } else {
        node = node[key];
      }
      continue;
    }

    final listIndex = segment.index!;
    if (node is! List<Object?>) {
      _throwNestedWriteKindConflict(context, base, index, path, segment, node);
    }
    if (listIndex > node.length) {
      _throwNestedWriteArrayGap(
        context,
        base,
        index,
        path,
        segment,
        node.length,
      );
    }
    if (isLast) {
      if (listIndex == node.length) {
        node.add(_copyValue(value));
      } else {
        node[listIndex] = _copyValue(value);
      }
      continue;
    }
    if (listIndex == node.length) {
      final child = _emptyContainer(segments[index + 1]);
      node.add(child);
      node = child;
    } else {
      node = node[listIndex];
    }
  }
}

List<_EvaluatedWriteSegment> _evaluateWriteSegments(
  List<ActionWritePathSegment> segments,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  return [
    for (final segment in segments)
      _EvaluatedWriteSegment(
        value: context.engine._evaluateExpression(
          segment.expression,
          context,
          ruleLabel,
          currentEdge: currentEdge,
        ),
        sourceSpan: segment.sourceSpan,
      ),
  ];
}

List<_WriteSelector> _classifyWriteSelectors(
  _RuntimeExecutionContext context,
  String base,
  List<_EvaluatedWriteSegment> segments,
) {
  final selectors = <_WriteSelector>[];
  for (final (index, segment) in segments.indexed) {
    final value = segment.value;
    if (value is String) {
      selectors.add(_WriteSelector.key(value, segment.sourceSpan));
      continue;
    }
    if (value is int && value >= 0) {
      selectors.add(_WriteSelector.index(value, segment.sourceSpan));
      continue;
    }
    final actualKind = _nestedWriteValueKind(value);
    final reason = value is int && value < 0
        ? 'negative_integer'
        : value is num
        ? 'fractional_number'
        : 'kind_not_path_selector';
    final message =
        "nested write segment $index for binding '$base' must evaluate "
        'to a string or nonnegative integer; got $actualKind ($reason)';
    throw RuntimeInterpreterException(
      message,
      diagnostic: context.diagnostic(
        stage: 'runtime_execution',
        summary: 'Dart nested write failed',
        detail: message,
        code: 'nested_write_segment_invalid',
        operation: 'nested_write_vivification',
        binding: base,
        segmentIndex: index,
        path: [for (final selector in selectors) selector.pathValue],
        actualKind: actualKind,
        reason: reason,
        sourceSpan: _nestedWriteSourceSpan(segment.sourceSpan),
      ),
    );
  }
  return selectors;
}

Object _emptyContainer(_WriteSelector selector) {
  return selector.key != null ? <String, Object?>{} : <Object?>[];
}

Never _throwNestedWriteKindConflict(
  _RuntimeExecutionContext context,
  String base,
  int segmentIndex,
  List<Object?> path,
  _WriteSelector selector,
  Object? actual,
) {
  final actualKind = _nestedWriteValueKind(actual);
  final message =
      "nested write segment $segmentIndex for binding '$base' requires "
      '${selector.expectedKind}; found $actualKind';
  throw RuntimeInterpreterException(
    message,
    diagnostic: context.diagnostic(
      stage: 'runtime_execution',
      summary: 'Dart nested write failed',
      detail: message,
      code: 'nested_write_kind_conflict',
      operation: 'nested_write_vivification',
      binding: base,
      segmentIndex: segmentIndex,
      path: path,
      expectedKind: selector.expectedKind,
      actualKind: actualKind,
      sourceSpan: _nestedWriteSourceSpan(selector.sourceSpan),
    ),
  );
}

Never _throwNestedWriteArrayGap(
  _RuntimeExecutionContext context,
  String base,
  int segmentIndex,
  List<Object?> path,
  _WriteSelector selector,
  int length,
) {
  final index = selector.index!;
  final message =
      "nested write segment $segmentIndex for binding '$base' cannot "
      'create array index $index at length $length';
  throw RuntimeInterpreterException(
    message,
    diagnostic: context.diagnostic(
      stage: 'runtime_execution',
      summary: 'Dart nested write failed',
      detail: message,
      code: 'nested_write_array_gap',
      operation: 'nested_write_vivification',
      binding: base,
      segmentIndex: segmentIndex,
      path: path,
      arrayIndex: index,
      length: length,
      sourceSpan: _nestedWriteSourceSpan(selector.sourceSpan),
    ),
  );
}

String _nestedWriteValueKind(Object? value) {
  return switch (value) {
    null => 'null',
    bool() => 'boolean',
    int() => 'integer',
    num() => 'number',
    String() => 'string',
    List() => 'array',
    Map() when _decodeRuntimeCodeblock(value) != null => 'codeblock',
    Map() => 'harray',
    _ => 'scalar',
  };
}

Map<String, Object?> _nestedWriteSourceSpan(ActionSourceSpan span) {
  return {...span.toJson(), 'unit': 'unicode_scalar', 'provenance': 'authored'};
}

int? _arrayIndex(Object? value) {
  final index = value is num ? value.toInt() : int.tryParse('$value');
  return index != null && index >= 0 ? index : null;
}

Object? _copyArgument(
  ActionExpr expr,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  final name = _variableName(expr);
  if (name != null) {
    if (context.variables[name] is List) {
      return _arrayValueFor(context, name);
    }
    if (context.variables[name] is Map) {
      return _hashValueFor(context, name);
    }
    if (context.arrays.containsKey(name)) {
      return _arrayValueFor(context, name);
    }
    if (context.hashes.containsKey(name)) {
      return _hashValueFor(context, name);
    }
  }
  return _copyValue(
    context.engine._evaluateExpression(
      expr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    ),
  );
}

Object? _namedCapture(
  RuntimeRegexMatch? match,
  List<ActionExpr> args,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  if (match == null || args.isEmpty) {
    return null;
  }
  final name = _captureName(args.first, context, ruleLabel, currentEdge);
  return match.namedCapture(name);
}

int _hasNamedCapture(
  RuntimeRegexMatch? match,
  List<ActionExpr> args,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  if (match == null || args.isEmpty) {
    return 0;
  }
  final name = _captureName(args.first, context, ruleLabel, currentEdge);
  return match.named.containsKey(name) ? 1 : 0;
}

String _captureName(
  ActionExpr expr,
  _RuntimeExecutionContext context,
  String ruleLabel,
  _CurrentActionEdge? currentEdge,
) {
  final literalName = _variableName(expr);
  if (literalName != null) {
    return literalName;
  }
  return _stringValue(
    context.engine._evaluateExpression(
      expr,
      context,
      ruleLabel,
      currentEdge: currentEdge,
    ),
  );
}

bool _hasRuntimeBinding(_RuntimeExecutionContext context, String name) {
  return context.variables.containsKey(name) ||
      context.arrays.containsKey(name) ||
      context.hashes.containsKey(name);
}

Object? _runtimeBindingValue(_RuntimeExecutionContext context, String name) {
  if (context.variables.containsKey(name)) {
    return _copyValue(context.variables[name]);
  }
  if (context.arrays.containsKey(name)) {
    return _copyValue(context.arrays[name]);
  }
  return _copyValue(context.hashes[name]);
}

String _runtimeCallableValueKind(Object? value) {
  return switch (value) {
    List() => 'array',
    Map() => 'harray',
    _ => 'scalar',
  };
}

_RuntimeCodeblockValue? _decodeRuntimeCodeblock(Object? value) {
  if (value is! Map ||
      (value['kind'] != 'codeblock_literal' &&
          value['kind'] != 'codeblock_argument') ||
      value['version'] != 1 ||
      value['source_text'] is! String ||
      value['body_source'] is! String ||
      value['body_ast'] is! Map ||
      (value['body_ast'] as Map)['kind'] != 'action_block') {
    return null;
  }
  final signature = value['signature'];
  if (signature is! Map ||
      signature['kind'] != 'callable_signature' ||
      signature['version'] != 1 ||
      signature['positional_params'] is! List ||
      signature['min_arity'] is! int) {
    return null;
  }
  final rawParams = signature['positional_params'] as List;
  if (rawParams.any((param) => param is! String)) {
    return null;
  }
  final positionalParams = rawParams.cast<String>();
  final restParam = signature['rest_param'];
  final maxArity = signature['max_arity'];
  final minArity = signature['min_arity'] as int;
  if ((restParam != null && restParam is! String) ||
      (maxArity != null && maxArity is! int) ||
      minArity != positionalParams.length ||
      (restParam == null && maxArity != minArity) ||
      (restParam != null && maxArity != null)) {
    return null;
  }
  return _RuntimeCodeblockValue(
    positionalParams: List.unmodifiable(positionalParams),
    restParam: restParam as String?,
    minArity: minArity,
    maxArity: maxArity as int?,
    sourceText: value['source_text'] as String,
    bodySource: value['body_source'] as String,
  );
}

final class _RuntimeCodeblockValue {
  const _RuntimeCodeblockValue({
    required this.positionalParams,
    required this.restParam,
    required this.minArity,
    required this.maxArity,
    required this.sourceText,
    required this.bodySource,
  });

  final List<String> positionalParams;
  final String? restParam;
  final int minArity;
  final int? maxArity;
  final String sourceText;
  final String bodySource;
}

final class _TreeCodeblockCallback {
  const _TreeCodeblockCallback({
    required this.name,
    required this.codeblock,
    required this.passLeafValue,
  });

  final String name;
  final _RuntimeCodeblockValue codeblock;
  final bool passLeafValue;
}

Object? _copyValue(Object? value) {
  if (value is List<Object?>) {
    return [for (final item in value) _copyValue(item)];
  }
  if (value is List) {
    return [for (final item in value) _copyValue(item)];
  }
  if (value is Map<String, Object?>) {
    return {
      for (final entry in value.entries) entry.key: _copyValue(entry.value),
    };
  }
  if (value is Map) {
    return {
      for (final entry in value.entries)
        '${entry.key}': _copyValue(entry.value),
    };
  }
  return value;
}

String _stringValue(Object? value) {
  if (value == null) {
    return '';
  }
  return '$value';
}

/// Apply LinkedSpec's typed logical truth policy without invoking [value].
bool runtimeLogicalTruth(Object? value) {
  return switch (value) {
    null => false,
    bool value => value,
    num value => value != 0,
    String value => value.isNotEmpty,
    List<dynamic> value => value.isNotEmpty,
    Map<dynamic, dynamic> value => value.isNotEmpty,
    _ => true,
  };
}
