part of 'semantic_index.dart';

// FUTURE-PARITY-BACKLOG.10.5.4.1-.3 — immutable typed query values, exact
// projection-only evaluator, raw-neutral validation, and public API.

const _semanticModelId = 'linkedspec-semantic-model-v1';
const _semanticQueryId = 'linkedspec-semantic-query-v1';
const _semanticPageDefault = 100;
const _semanticPageMax = 1000;
const _semanticRecordBudgetDefault = 1000;
const _semanticRelationBudgetDefault = 2000;
const _semanticDepthBudgetDefault = 4;
const _semanticRecordBudgetMax = 10000;
const _semanticRelationBudgetMax = 20000;
const _semanticDepthBudgetMax = 8;
const _semanticRequestFields = <String>{
  'contract',
  'operation',
  'subjects',
  'record_kinds',
  'relation_kinds',
  'direction',
  'page',
  'budget',
  'source',
};

/// One native semantic-query-v1 operation.
enum SemanticQueryOperation {
  capabilities('capabilities'),
  list('list'),
  get('get'),
  relations('relations'),
  explain('explain');

  const SemanticQueryOperation(this.wireName);

  final String wireName;
}

/// Traversal direction for a semantic relation query.
enum SemanticQueryDirection {
  outgoing('outgoing'),
  incoming('incoming'),
  both('both');

  const SemanticQueryDirection(this.wireName);

  final String wireName;
}

/// Canonical after-id page request.
final class SemanticQueryPage {
  const SemanticQueryPage({this.afterId, this.limit = _semanticPageDefault});

  final String? afterId;
  final int limit;

  Map<String, Object?> toJson() => {'after_id': afterId, 'limit': limit};

  @override
  bool operator ==(Object other) =>
      other is SemanticQueryPage &&
      other.afterId == afterId &&
      other.limit == limit;

  @override
  int get hashCode => Object.hash(afterId, limit);
}

/// Logical query budgets, independent of host resource accounting.
final class SemanticQueryBudget {
  const SemanticQueryBudget({
    this.maxRecords = _semanticRecordBudgetDefault,
    this.maxRelations = _semanticRelationBudgetDefault,
    this.maxDepth = _semanticDepthBudgetDefault,
  });

  final int maxRecords;
  final int maxRelations;
  final int maxDepth;

  Map<String, Object?> toJson() => {
    'max_records': maxRecords,
    'max_relations': maxRelations,
    'max_depth': maxDepth,
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQueryBudget &&
      other.maxRecords == maxRecords &&
      other.maxRelations == maxRelations &&
      other.maxDepth == maxDepth;

  @override
  int get hashCode => Object.hash(maxRecords, maxRelations, maxDepth);
}

/// Query-selected source projection beneath the construction ceiling.
final class SemanticQuerySource {
  const SemanticQuerySource({
    this.detail = SemanticSourceDetail.none,
    this.includeContentDigest = false,
  });

  final SemanticSourceDetail detail;
  final bool includeContentDigest;

  Map<String, Object?> toJson() => {
    'detail': detail.wireName,
    'include_content_digest': includeContentDigest,
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQuerySource &&
      other.detail == detail &&
      other.includeContentDigest == includeContentDigest;

  @override
  int get hashCode => Object.hash(detail, includeContentDigest);
}

/// Strongly typed native projection of one semantic-query-v1 request.
final class SemanticQuery {
  SemanticQuery({
    this.contract = _semanticQueryId,
    required this.operation,
    List<String> subjects = const [],
    List<String> recordKinds = const [],
    List<String> relationKinds = const [],
    this.direction = SemanticQueryDirection.outgoing,
    this.page = const SemanticQueryPage(),
    this.budget = const SemanticQueryBudget(),
    this.source = const SemanticQuerySource(),
  }) : subjects = List.unmodifiable(subjects),
       recordKinds = List.unmodifiable(recordKinds),
       relationKinds = List.unmodifiable(relationKinds);

  final String contract;
  final SemanticQueryOperation operation;
  final List<String> subjects;
  final List<String> recordKinds;
  final List<String> relationKinds;
  final SemanticQueryDirection direction;
  final SemanticQueryPage page;
  final SemanticQueryBudget budget;
  final SemanticQuerySource source;

  Map<String, Object?> toJson() => {
    'contract': contract,
    'operation': operation.wireName,
    'subjects': [...subjects],
    'record_kinds': [...recordKinds],
    'relation_kinds': [...relationKinds],
    'direction': direction.wireName,
    'page': page.toJson(),
    'budget': budget.toJson(),
    'source': source.toJson(),
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQuery &&
      other.contract == contract &&
      other.operation == operation &&
      _listsEqual(other.subjects, subjects) &&
      _listsEqual(other.recordKinds, recordKinds) &&
      _listsEqual(other.relationKinds, relationKinds) &&
      other.direction == direction &&
      other.page == page &&
      other.budget == budget &&
      other.source == source;

  @override
  int get hashCode => Object.hash(
    contract,
    operation,
    Object.hashAll(subjects),
    Object.hashAll(recordKinds),
    Object.hashAll(relationKinds),
    direction,
    page,
    budget,
    source,
  );
}

/// Source reference after query-time privacy projection.
final class SemanticQuerySourceReference {
  SemanticQuerySourceReference({
    required this.sourceId,
    required this.logicalName,
    required this.span,
    required this.excerpt,
    required this.contentDigest,
    List<String> provenanceIds = const [],
  }) : provenanceIds = List.unmodifiable(provenanceIds);

  final String sourceId;
  final String logicalName;
  final SemanticSourceSpan? span;
  final String? excerpt;
  final String? contentDigest;
  final List<String> provenanceIds;

  Map<String, Object?> toJson() => {
    'source_id': sourceId,
    'logical_name': logicalName,
    'span': span?.toJson(),
    'excerpt': excerpt,
    'content_digest': contentDigest,
    'provenance_ids': [...provenanceIds],
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQuerySourceReference &&
      other.sourceId == sourceId &&
      other.logicalName == logicalName &&
      other.span == span &&
      other.excerpt == excerpt &&
      other.contentDigest == contentDigest &&
      _listsEqual(other.provenanceIds, provenanceIds);

  @override
  int get hashCode => Object.hash(
    sourceId,
    logicalName,
    span,
    excerpt,
    contentDigest,
    Object.hashAll(provenanceIds),
  );
}

/// One public clone-safe semantic model record.
final class SemanticQueryRecord {
  SemanticQueryRecord({
    required this.id,
    required this.kind,
    required this.name,
    required this.ownerId,
    required this.order,
    required this.source,
    required Map<String, Object?> facts,
    List<String> redactions = const [],
  }) : facts = _immutableFields(facts),
       redactions = List.unmodifiable(redactions);

  final String id;
  final String kind;
  final String? name;
  final String? ownerId;
  final int order;
  final SemanticQuerySourceReference? source;
  final Map<String, Object?> facts;
  final List<String> redactions;

  Map<String, Object?> toJson() => {
    'id': id,
    'kind': kind,
    'name': name,
    'owner_id': ownerId,
    'order': order,
    'source': source?.toJson(),
    'facts': _detachedFields(facts),
    'redactions': [...redactions],
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQueryRecord &&
      _plainValuesEqual(other.toJson(), toJson());

  @override
  int get hashCode => _plainValueHash(toJson());
}

/// One public clone-safe semantic model relation.
final class SemanticQueryRelation {
  SemanticQueryRelation({
    required this.id,
    required this.kind,
    required this.fromId,
    required this.toId,
    required this.order,
    required this.source,
    required Map<String, Object?> facts,
    List<String> evidenceIds = const [],
  }) : facts = _immutableFields(facts),
       evidenceIds = List.unmodifiable(evidenceIds);

  final String id;
  final String kind;
  final String fromId;
  final String toId;
  final int order;
  final SemanticQuerySourceReference? source;
  final Map<String, Object?> facts;
  final List<String> evidenceIds;

  Map<String, Object?> toJson() => {
    'id': id,
    'kind': kind,
    'from_id': fromId,
    'to_id': toId,
    'order': order,
    'source': source?.toJson(),
    'facts': _detachedFields(facts),
    'evidence_ids': [...evidenceIds],
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQueryRelation &&
      _plainValuesEqual(other.toJson(), toJson());

  @override
  int get hashCode => _plainValueHash(toJson());
}

/// Portable query diagnostic, distinct from compilation/runtime records.
final class SemanticQueryDiagnostic {
  SemanticQueryDiagnostic({
    required this.code,
    required this.severity,
    required this.message,
    required Map<String, Object?> fields,
  }) : fields = _immutableFields(fields);

  final String code;
  final String severity;
  final String message;
  final Map<String, Object?> fields;

  Map<String, Object?> toJson() => {
    'code': code,
    'severity': severity,
    'message': message,
    'fields': _detachedFields(fields),
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQueryDiagnostic &&
      _plainValuesEqual(other.toJson(), toJson());

  @override
  int get hashCode => _plainValueHash(toJson());
}

/// Canonical response paging state.
final class SemanticQueryPageState {
  SemanticQueryPageState({
    required Object? afterId,
    required this.nextAfterId,
    required this.complete,
  }) : afterId = _immutablePlainValue(afterId);

  final Object? afterId;
  final String? nextAfterId;
  final bool complete;

  Map<String, Object?> toJson() => {
    'after_id': _detachedPlainValue(afterId),
    'next_after_id': nextAfterId,
    'complete': complete,
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQueryPageState &&
      _plainValuesEqual(other.afterId, afterId) &&
      other.nextAfterId == nextAfterId &&
      other.complete == complete;

  @override
  int get hashCode =>
      Object.hash(_plainValueHash(afterId), nextAfterId, complete);
}

/// Logical traversal cost reported by one query.
final class SemanticQueryCost {
  const SemanticQueryCost({
    required this.recordsExamined,
    required this.relationsExamined,
    required this.depthReached,
  });

  final int recordsExamined;
  final int relationsExamined;
  final int depthReached;

  Map<String, Object?> toJson() => {
    'records_examined': recordsExamined,
    'relations_examined': relationsExamined,
    'depth_reached': depthReached,
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQueryCost &&
      other.recordsExamined == recordsExamined &&
      other.relationsExamined == relationsExamined &&
      other.depthReached == depthReached;

  @override
  int get hashCode =>
      Object.hash(recordsExamined, relationsExamined, depthReached);
}

/// Exact native and neutral semantic-query-v1 response envelope.
final class SemanticQueryResponse {
  SemanticQueryResponse({
    required this.contract,
    required this.model,
    required this.ok,
    required this.snapshot,
    List<SemanticQueryRecord> records = const [],
    List<SemanticQueryRelation> relations = const [],
    required this.page,
    required this.cost,
    List<SemanticQueryDiagnostic> diagnostics = const [],
  }) : records = List.unmodifiable(records),
       relations = List.unmodifiable(relations),
       diagnostics = List.unmodifiable(diagnostics);

  final String contract;
  final String model;
  final bool ok;
  final SemanticSnapshot snapshot;
  final List<SemanticQueryRecord> records;
  final List<SemanticQueryRelation> relations;
  final SemanticQueryPageState page;
  final SemanticQueryCost cost;
  final List<SemanticQueryDiagnostic> diagnostics;

  Map<String, Object?> toJson() => {
    'contract': contract,
    'model': model,
    'ok': ok,
    'snapshot': snapshot.toJson(),
    'records': [for (final record in records) record.toJson()],
    'relations': [for (final relation in relations) relation.toJson()],
    'page': page.toJson(),
    'cost': cost.toJson(),
    'diagnostics': [for (final diagnostic in diagnostics) diagnostic.toJson()],
  };

  @override
  bool operator ==(Object other) =>
      other is SemanticQueryResponse &&
      _plainValuesEqual(other.toJson(), toJson());

  @override
  int get hashCode => _plainValueHash(toJson());
}

final class _SemanticQueryPageResult<T> {
  const _SemanticQueryPageResult({
    required this.selected,
    required this.page,
    required this.limitedByBudget,
  });

  final List<T> selected;
  final SemanticQueryPageState page;
  final bool limitedByBudget;
}

final class _SemanticQueryTraversal {
  const _SemanticQueryTraversal({
    required this.relations,
    required this.depthById,
    required this.depthLimited,
  });

  final List<Map<String, Object?>> relations;
  final Map<String, int> depthById;
  final bool depthLimited;
}

SemanticQueryResponse _evaluateSemanticQueryNeutral(
  Map<String, Object?> projection,
  Object? requestValue,
) {
  final snapshot = _semanticQuerySnapshot(projection);
  final validation = _validateSemanticQueryRequest(snapshot, requestValue);
  final error = validation.error;
  if (error != null) {
    return error;
  }
  return _evaluateSemanticQuery(projection, validation.request!);
}

({SemanticQuery? request, SemanticQueryResponse? error})
_validateSemanticQueryRequest(SemanticSnapshot snapshot, Object? requestValue) {
  if (requestValue is! Map) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'request_not_object',
    );
  }
  final contract = requestValue['contract'];
  if (contract != _semanticQueryId) {
    return _semanticQueryValidationError(
      _semanticNeutralEmptyQueryResponse(
        snapshot,
        requestValue,
        _semanticQueryDiagnostic(
          'semantic_query_contract_unsupported',
          requested: contract,
        ),
      ),
    );
  }
  if (!_semanticHasExactKeys(requestValue, _semanticRequestFields)) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'request_fields',
    );
  }
  final page = _semanticExactObject(requestValue['page'], const {
    'after_id',
    'limit',
  });
  if (page == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'page_fields',
    );
  }
  final budget = _semanticExactObject(requestValue['budget'], const {
    'max_records',
    'max_relations',
    'max_depth',
  });
  if (budget == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'budget_fields',
    );
  }
  final source = _semanticExactObject(requestValue['source'], const {
    'detail',
    'include_content_digest',
  });
  if (source == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'source_fields',
    );
  }

  final operation = switch (requestValue['operation']) {
    'capabilities' => SemanticQueryOperation.capabilities,
    'list' => SemanticQueryOperation.list,
    'get' => SemanticQueryOperation.get,
    'relations' => SemanticQueryOperation.relations,
    'explain' => SemanticQueryOperation.explain,
    _ => null,
  };
  if (operation == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'operation',
    );
  }
  final subjects = _semanticStringArray(requestValue['subjects']);
  if (subjects == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'subjects_type',
    );
  }
  final recordKinds = _semanticStringArray(requestValue['record_kinds']);
  if (recordKinds == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'record_kinds_type',
    );
  }
  final relationKinds = _semanticStringArray(requestValue['relation_kinds']);
  if (relationKinds == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'relation_kinds_type',
    );
  }
  for (final (name, values) in [
    ('subjects', subjects),
    ('record_kinds', recordKinds),
    ('relation_kinds', relationKinds),
  ]) {
    if (values.toSet().length != values.length) {
      return _semanticInvalidQueryValidation(
        snapshot,
        requestValue,
        reason: '${name}_duplicate',
      );
    }
  }
  if (recordKinds.any((kind) => !_semanticRecordKinds.contains(kind))) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'record_kind',
    );
  }
  if (relationKinds.any((kind) => !_semanticRelationKinds.contains(kind))) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'relation_kind',
    );
  }
  if (!_semanticRankOrdered(recordKinds, _semanticRecordKinds)) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'record_kind_order',
    );
  }
  if (!_semanticRankOrdered(relationKinds, _semanticRelationKinds)) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'relation_kind_order',
    );
  }

  final direction = switch (requestValue['direction']) {
    'outgoing' => SemanticQueryDirection.outgoing,
    'incoming' => SemanticQueryDirection.incoming,
    'both' => SemanticQueryDirection.both,
    _ => null,
  };
  if (direction == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'direction',
    );
  }
  final rawAfterId = page['after_id'];
  final String? afterId;
  if (rawAfterId == null) {
    afterId = null;
  } else if (rawAfterId is String && !_semanticLooksNumeric(rawAfterId)) {
    afterId = rawAfterId;
  } else {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'after_id',
    );
  }
  final pageLimit = _semanticIntegerInRange(
    page['limit'],
    minimum: 1,
    maximum: _semanticPageMax,
  );
  if (pageLimit == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'page_limit',
    );
  }
  final maxRecords = _semanticIntegerInRange(
    budget['max_records'],
    minimum: 1,
    maximum: _semanticRecordBudgetMax,
  );
  if (maxRecords == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'max_records',
    );
  }
  final maxRelations = _semanticIntegerInRange(
    budget['max_relations'],
    minimum: 1,
    maximum: _semanticRelationBudgetMax,
  );
  if (maxRelations == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'max_relations',
    );
  }
  final maxDepth = _semanticIntegerInRange(
    budget['max_depth'],
    minimum: 0,
    maximum: _semanticDepthBudgetMax,
  );
  if (maxDepth == null) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'max_depth',
    );
  }
  final sourceDetail = switch (source['detail']) {
    'none' => SemanticSourceDetail.none,
    'identity' => SemanticSourceDetail.identity,
    'span' => SemanticSourceDetail.span,
    'text' => SemanticSourceDetail.text,
    _ => null,
  };
  final includeContentDigest = source['include_content_digest'];
  if (sourceDetail == null || includeContentDigest is! bool) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'source_policy',
    );
  }
  if (includeContentDigest && sourceDetail != SemanticSourceDetail.text) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'digest_requires_text',
    );
  }
  if (sourceDetail.index > snapshot.sourceDetailCeiling.index ||
      (includeContentDigest && !snapshot.contentDigestAvailable)) {
    return _semanticQueryValidationError(
      _semanticNeutralEmptyQueryResponse(
        snapshot,
        requestValue,
        _semanticQueryDiagnostic(
          'semantic_query_source_detail_forbidden',
          reason: snapshot.sourceDetailCeiling.wireName,
          requested: sourceDetail.wireName,
        ),
      ),
    );
  }

  final validCombination = switch (operation) {
    SemanticQueryOperation.capabilities ||
    SemanticQueryOperation.list => subjects.isEmpty && relationKinds.isEmpty,
    SemanticQueryOperation.get =>
      subjects.isNotEmpty && recordKinds.isEmpty && relationKinds.isEmpty,
    SemanticQueryOperation.relations =>
      subjects.isNotEmpty && recordKinds.isEmpty,
    SemanticQueryOperation.explain =>
      subjects.length == 1 && recordKinds.isEmpty && relationKinds.isEmpty,
  };
  if (!validCombination) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'operation_combination',
    );
  }
  if (operation == SemanticQueryOperation.capabilities &&
      recordKinds.isNotEmpty) {
    return _semanticInvalidQueryValidation(
      snapshot,
      requestValue,
      reason: 'capability_filter',
    );
  }

  return (
    request: SemanticQuery(
      contract: contract as String,
      operation: operation,
      subjects: subjects,
      recordKinds: recordKinds,
      relationKinds: relationKinds,
      direction: direction,
      page: SemanticQueryPage(afterId: afterId, limit: pageLimit),
      budget: SemanticQueryBudget(
        maxRecords: maxRecords,
        maxRelations: maxRelations,
        maxDepth: maxDepth,
      ),
      source: SemanticQuerySource(
        detail: sourceDetail,
        includeContentDigest: includeContentDigest,
      ),
    ),
    error: null,
  );
}

({SemanticQuery? request, SemanticQueryResponse? error})
_semanticInvalidQueryValidation(
  SemanticSnapshot snapshot,
  Object? requestValue, {
  required String reason,
}) => _semanticQueryValidationError(
  _semanticNeutralEmptyQueryResponse(
    snapshot,
    requestValue,
    _semanticQueryDiagnostic('semantic_query_invalid', reason: reason),
  ),
);

({SemanticQuery? request, SemanticQueryResponse? error})
_semanticQueryValidationError(SemanticQueryResponse error) =>
    (request: null, error: error);

bool _semanticHasExactKeys(Map<Object?, Object?> value, Set<String> fields) =>
    value.length == fields.length &&
    value.keys.every((key) => key is String && fields.contains(key));

Map<Object?, Object?>? _semanticExactObject(
  Object? value,
  Set<String> fields,
) => value is Map && _semanticHasExactKeys(value, fields) ? value : null;

List<String>? _semanticStringArray(Object? value) {
  if (value is! List || value.any((item) => item is! String)) {
    return null;
  }
  return value.cast<String>().toList();
}

bool _semanticRankOrdered(List<String> values, List<String> ranks) {
  for (var index = 1; index < values.length; index += 1) {
    if (ranks.indexOf(values[index - 1]) > ranks.indexOf(values[index])) {
      return false;
    }
  }
  return true;
}

bool _semanticLooksNumeric(String value) {
  final trimmed = value.trim();
  return trimmed.isNotEmpty && double.tryParse(trimmed) != null;
}

int? _semanticIntegerInRange(
  Object? value, {
  required int minimum,
  required int maximum,
}) => value is int && value >= minimum && value <= maximum ? value : null;

SemanticQueryResponse _evaluateSemanticQuery(
  Map<String, Object?> projection,
  SemanticQuery request,
) {
  final snapshot = _semanticQuerySnapshot(projection);
  final ceilingError = _semanticSourceCeilingError(snapshot, request);
  if (ceilingError != null) {
    return ceilingError;
  }

  final records = (projection['records']! as List<Object?>)
      .cast<Map<String, Object?>>();
  final relations = (projection['relations']! as List<Object?>)
      .cast<Map<String, Object?>>();
  final recordById = <String, Map<String, Object?>>{
    for (final record in records) record['id']! as String: record,
  };
  if ((request.operation == SemanticQueryOperation.get ||
          request.operation == SemanticQueryOperation.relations) &&
      request.subjects.any((subject) => !recordById.containsKey(subject))) {
    return _semanticEmptyQueryResponse(
      snapshot,
      request,
      _semanticQueryDiagnostic(
        'semantic_query_invalid',
        reason: 'unknown_subject',
      ),
    );
  }

  final selectedRecords = <SemanticQueryRecord>[];
  final selectedRelations = <SemanticQueryRelation>[];
  final diagnostics = <SemanticQueryDiagnostic>[];
  late SemanticQueryPageState page;
  var recordCost = 0;
  var relationCost = 0;
  var depthReached = 0;
  String? budgetReason;
  switch (request.operation) {
    case SemanticQueryOperation.capabilities:
      final paged = _semanticPageStream(
        [_semanticCapabilitiesRecord(snapshot)],
        request,
        request.budget.maxRecords,
        (record) => record.id,
      );
      if (paged == null) {
        return _semanticInvalidAfterId(snapshot, request);
      }
      selectedRecords.addAll(paged.selected);
      page = paged.page;
      recordCost = selectedRecords.length;
      if (paged.limitedByBudget) {
        budgetReason = 'max_records';
      }
    case SemanticQueryOperation.list:
      final wanted = request.recordKinds.toSet();
      final candidates = records
          .where(
            (record) =>
                wanted.isEmpty || wanted.contains(record['kind']! as String),
          )
          .toList();
      final paged = _semanticPageStream(
        candidates,
        request,
        request.budget.maxRecords,
        (record) => record['id']! as String,
      );
      if (paged == null) {
        return _semanticInvalidAfterId(snapshot, request);
      }
      selectedRecords.addAll(
        paged.selected.map(
          (record) =>
              _projectSemanticQueryRecord(record, projection, request.source),
        ),
      );
      page = paged.page;
      recordCost = selectedRecords.length;
      if (paged.limitedByBudget) {
        budgetReason = 'max_records';
      }
    case SemanticQueryOperation.get:
      final wanted = request.subjects.toSet();
      final candidates = records
          .where((record) => wanted.contains(record['id']! as String))
          .toList();
      final paged = _semanticPageStream(
        candidates,
        request,
        request.budget.maxRecords,
        (record) => record['id']! as String,
      );
      if (paged == null) {
        return _semanticInvalidAfterId(snapshot, request);
      }
      selectedRecords.addAll(
        paged.selected.map(
          (record) =>
              _projectSemanticQueryRecord(record, projection, request.source),
        ),
      );
      page = paged.page;
      recordCost = selectedRecords.length;
      if (paged.limitedByBudget) {
        budgetReason = 'max_records';
      }
    case SemanticQueryOperation.relations:
      final traversal = _traverseSemanticQueryRelations(relations, request);
      final paged = _semanticPageStream(
        traversal.relations,
        request,
        request.budget.maxRelations,
        (relation) => relation['id']! as String,
      );
      if (paged == null) {
        return _semanticInvalidAfterId(snapshot, request);
      }
      selectedRelations.addAll(
        paged.selected.map(
          (relation) => _projectSemanticQueryRelation(
            relation,
            projection,
            request.source,
          ),
        ),
      );
      page = paged.page;
      relationCost = selectedRelations.length;
      for (final relation in paged.selected) {
        final relationDepth = traversal.depthById[relation['id']]!;
        if (relationDepth > depthReached) {
          depthReached = relationDepth;
        }
      }
      if (paged.limitedByBudget) {
        budgetReason = 'max_relations';
      } else if (traversal.depthLimited) {
        budgetReason = 'max_depth';
      }
    case SemanticQueryOperation.explain:
      final subject = request.subjects.single;
      Map<String, Object?>? decision;
      final direct = recordById[subject];
      if (direct != null && direct['kind'] == 'decision') {
        decision = direct;
      } else {
        final owned = records
            .where(
              (record) =>
                  record['kind'] == 'decision' && record['owner_id'] == subject,
            )
            .toList();
        if (owned.length == 1) {
          decision = owned.single;
        }
      }
      if (decision == null) {
        return _semanticEmptyQueryResponse(
          snapshot,
          request,
          _semanticQueryDiagnostic(
            'semantic_query_invalid',
            reason: 'not_explainable',
          ),
        );
      }
      final stepCandidates = records
          .where(
            (record) =>
                record['kind'] == 'explanation_step' &&
                record['owner_id'] == decision!['id'],
          )
          .toList();
      final paged = _semanticPageStream(
        stepCandidates,
        request,
        request.budget.maxRecords - 1,
        (record) => record['id']! as String,
      );
      if (paged == null) {
        return _semanticInvalidAfterId(snapshot, request);
      }
      selectedRecords.add(
        _projectSemanticQueryRecord(decision, projection, request.source),
      );
      selectedRecords.addAll(
        paged.selected.map(
          (record) =>
              _projectSemanticQueryRecord(record, projection, request.source),
        ),
      );
      final stepIds = paged.selected.map((record) => record['id']).toSet();
      selectedRelations.addAll(
        relations
            .where(
              (relation) =>
                  relation['kind'] == 'explained_by' &&
                  relation['from_id'] == decision!['id'] &&
                  stepIds.contains(relation['to_id']),
            )
            .map(
              (relation) => _projectSemanticQueryRelation(
                relation,
                projection,
                request.source,
              ),
            ),
      );
      page = paged.page;
      recordCost = selectedRecords.length;
      relationCost = selectedRelations.length;
      depthReached = paged.selected.isEmpty ? 0 : 1;
      if (paged.limitedByBudget) {
        budgetReason = 'max_records';
      }
  }

  if (budgetReason != null) {
    page = SemanticQueryPageState(
      afterId: page.afterId,
      nextAfterId: page.nextAfterId,
      complete: false,
    );
    diagnostics.add(
      _semanticQueryDiagnostic(
        'semantic_query_budget_exceeded',
        reason: budgetReason,
      ),
    );
  }

  return SemanticQueryResponse(
    contract: _semanticQueryId,
    model: _semanticModelId,
    ok: true,
    snapshot: snapshot,
    records: selectedRecords,
    relations: selectedRelations,
    page: page,
    cost: SemanticQueryCost(
      recordsExamined: recordCost,
      relationsExamined: relationCost,
      depthReached: depthReached,
    ),
    diagnostics: diagnostics,
  );
}

_SemanticQueryPageResult<T>? _semanticPageStream<T>(
  List<T> items,
  SemanticQuery request,
  int budgetLimit,
  String Function(T item) id,
) {
  var start = 0;
  final afterId = request.page.afterId;
  if (afterId != null) {
    final cursor = items.indexWhere((item) => id(item) == afterId);
    if (cursor < 0) {
      return null;
    }
    start = cursor + 1;
  }

  final remaining = items.sublist(start);
  final limitedByBudget = remaining.length > budgetLimit;
  final selectedCount = _semanticMinimum(
    remaining.length,
    _semanticMinimum(request.page.limit, budgetLimit),
  );
  final selected = remaining.sublist(0, selectedCount);
  final complete = selectedCount == remaining.length && !limitedByBudget;
  final nextAfterId = selected.isNotEmpty && !complete
      ? id(selected.last)
      : null;
  return _SemanticQueryPageResult(
    selected: selected,
    page: SemanticQueryPageState(
      afterId: afterId,
      nextAfterId: nextAfterId,
      complete: complete,
    ),
    limitedByBudget: limitedByBudget,
  );
}

int _semanticMinimum(int left, int right) => left < right ? left : right;

_SemanticQueryTraversal _traverseSemanticQueryRelations(
  List<Map<String, Object?>> relations,
  SemanticQuery request,
) {
  final wantedKinds = request.relationKinds.toSet();
  var frontier = request.subjects.toSet();
  final visited = {...frontier};
  final depthById = <String, int>{};

  for (var depth = 1; depth <= request.budget.maxDepth; depth += 1) {
    final layer = _semanticRelationLayer(
      relations,
      frontier,
      wantedKinds,
      request.direction,
      depthById.keys.toSet(),
    );
    if (layer.isEmpty) {
      break;
    }
    final nextFrontier = <String>{};
    for (final relation in layer) {
      final relationId = relation['id']! as String;
      final fromId = relation['from_id']! as String;
      final toId = relation['to_id']! as String;
      depthById[relationId] = depth;
      if ((request.direction == SemanticQueryDirection.outgoing ||
              request.direction == SemanticQueryDirection.both) &&
          frontier.contains(fromId)) {
        nextFrontier.add(toId);
      }
      if ((request.direction == SemanticQueryDirection.incoming ||
              request.direction == SemanticQueryDirection.both) &&
          frontier.contains(toId)) {
        nextFrontier.add(fromId);
      }
    }
    nextFrontier.removeWhere(visited.contains);
    visited.addAll(nextFrontier);
    frontier = nextFrontier;
    if (frontier.isEmpty) {
      break;
    }
  }

  final depthLimited =
      frontier.isNotEmpty &&
      _semanticRelationLayer(
        relations,
        frontier,
        wantedKinds,
        request.direction,
        depthById.keys.toSet(),
      ).isNotEmpty;
  return _SemanticQueryTraversal(
    relations: relations
        .where((relation) => depthById.containsKey(relation['id']))
        .toList(),
    depthById: depthById,
    depthLimited: depthLimited,
  );
}

List<Map<String, Object?>> _semanticRelationLayer(
  List<Map<String, Object?>> relations,
  Set<String> frontier,
  Set<String> wantedKinds,
  SemanticQueryDirection direction,
  Set<String> selectedIds,
) => relations.where((relation) {
  final id = relation['id']! as String;
  final kind = relation['kind']! as String;
  final fromId = relation['from_id']! as String;
  final toId = relation['to_id']! as String;
  final kindMatches = wantedKinds.isEmpty || wantedKinds.contains(kind);
  final outgoing =
      (direction == SemanticQueryDirection.outgoing ||
          direction == SemanticQueryDirection.both) &&
      frontier.contains(fromId);
  final incoming =
      (direction == SemanticQueryDirection.incoming ||
          direction == SemanticQueryDirection.both) &&
      frontier.contains(toId);
  return kindMatches && (outgoing || incoming) && !selectedIds.contains(id);
}).toList();

SemanticSnapshot _semanticQuerySnapshot(Map<String, Object?> projection) {
  final value = projection['snapshot']! as Map<String, Object?>;
  return SemanticSnapshot(
    id: value['id']! as String,
    state: switch (value['state']) {
      'compiled' => SemanticSnapshotState.compiled,
      'failed_compilation' => SemanticSnapshotState.failedCompilation,
      final state => throw StateError(
        'Unknown semantic snapshot state: $state',
      ),
    },
    hasExecution: value['has_execution']! as bool,
    sourceDetailCeiling: _semanticSourceDetail(value['source_detail_ceiling']),
    contentDigestAvailable: value['content_digest_available']! as bool,
  );
}

SemanticQueryResponse? _semanticSourceCeilingError(
  SemanticSnapshot snapshot,
  SemanticQuery request,
) {
  final source = request.source;
  if (source.detail.index <= snapshot.sourceDetailCeiling.index &&
      (!source.includeContentDigest || snapshot.contentDigestAvailable)) {
    return null;
  }
  return _semanticEmptyQueryResponse(
    snapshot,
    request,
    _semanticQueryDiagnostic(
      'semantic_query_source_detail_forbidden',
      reason: snapshot.sourceDetailCeiling.wireName,
      requested: source.detail.wireName,
    ),
  );
}

SemanticQueryRecord _semanticCapabilitiesRecord(SemanticSnapshot snapshot) =>
    SemanticQueryRecord(
      id: 'capabilities:0',
      kind: 'capabilities',
      name: 'semantic introspection v1',
      ownerId: null,
      order: 0,
      source: null,
      facts: {
        'model_ids': [_semanticModelId],
        'query_ids': [_semanticQueryId],
        'record_kinds': [..._semanticRecordKinds],
        'relation_kinds': [..._semanticRelationKinds],
        'source_detail_ceiling': snapshot.sourceDetailCeiling.wireName,
        'page_default': _semanticPageDefault,
        'page_max': _semanticPageMax,
        'budget_defaults': {
          'max_records': _semanticRecordBudgetDefault,
          'max_relations': _semanticRelationBudgetDefault,
          'max_depth': _semanticDepthBudgetDefault,
        },
        'budget_maxima': {
          'max_records': _semanticRecordBudgetMax,
          'max_relations': _semanticRelationBudgetMax,
          'max_depth': _semanticDepthBudgetMax,
        },
        'execution_observation': snapshot.hasExecution,
        'features': <Object?>[],
      },
    );

SemanticQueryRecord _projectSemanticQueryRecord(
  Map<String, Object?> record,
  Map<String, Object?> projection,
  SemanticQuerySource policy,
) {
  final facts = _detachedFields(record['facts']! as Map<String, Object?>);
  final sensitive = switch (record['kind']) {
    'regex_slot' => ('pattern', '/facts/pattern'),
    'diagnostic' => ('message', '/facts/message'),
    'explanation_step' => ('summary', '/facts/summary'),
    _ => null,
  };
  var redactions = (record['redactions']! as List<Object?>).cast<String>();
  if (policy.detail != SemanticSourceDetail.text && sensitive != null) {
    facts[sensitive.$1] = null;
    redactions = [sensitive.$2];
  }
  return SemanticQueryRecord(
    id: record['id']! as String,
    kind: record['kind']! as String,
    name: record['name'] as String?,
    ownerId: record['owner_id'] as String?,
    order: record['order']! as int,
    source: _projectSemanticQuerySource(
      record['source'] as String?,
      projection,
      policy,
    ),
    facts: facts,
    redactions: redactions,
  );
}

SemanticQueryRelation _projectSemanticQueryRelation(
  Map<String, Object?> relation,
  Map<String, Object?> projection,
  SemanticQuerySource policy,
) => SemanticQueryRelation(
  id: relation['id']! as String,
  kind: relation['kind']! as String,
  fromId: relation['from_id']! as String,
  toId: relation['to_id']! as String,
  order: relation['order']! as int,
  source: _projectSemanticQuerySource(
    relation['source'] as String?,
    projection,
    policy,
  ),
  facts: relation['facts']! as Map<String, Object?>,
  evidenceIds: (relation['evidence_ids']! as List<Object?>).cast<String>(),
);

SemanticQuerySourceReference? _projectSemanticQuerySource(
  String? sourceKey,
  Map<String, Object?> projection,
  SemanticQuerySource policy,
) {
  if (sourceKey == null || policy.detail == SemanticSourceDetail.none) {
    return null;
  }
  final sourceRefs = projection['source_refs']! as Map<String, Object?>;
  final source = sourceRefs[sourceKey]! as Map<String, Object?>;
  return SemanticQuerySourceReference(
    sourceId: source['source_id']! as String,
    logicalName: source['logical_name']! as String,
    span: policy.detail.index >= SemanticSourceDetail.span.index
        ? _semanticQuerySpan(source['span']! as Map<String, Object?>)
        : null,
    excerpt: policy.detail == SemanticSourceDetail.text
        ? source['excerpt']! as String
        : null,
    contentDigest:
        policy.detail == SemanticSourceDetail.text &&
            policy.includeContentDigest
        ? source['content_digest']! as String
        : null,
    provenanceIds: (source['provenance_ids']! as List<Object?>).cast<String>(),
  );
}

SemanticSourceSpan _semanticQuerySpan(Map<String, Object?> value) =>
    SemanticSourceSpan(
      startByte: value['start_byte']! as int,
      endByte: value['end_byte']! as int,
      startLine: value['start_line']! as int,
      startColumn: value['start_column']! as int,
      endLine: value['end_line']! as int,
      endColumn: value['end_column']! as int,
    );

SemanticQueryDiagnostic _semanticQueryDiagnostic(
  String code, {
  String? reason,
  Object? requested,
}) => switch (code) {
  'semantic_query_budget_exceeded' => SemanticQueryDiagnostic(
    code: code,
    severity: 'warning',
    message:
        'Semantic query budget was reached; returning the deterministic prefix.',
    fields: {'limit': reason},
  ),
  'semantic_query_contract_unsupported' => SemanticQueryDiagnostic(
    code: code,
    severity: 'error',
    message: 'Unsupported semantic query contract.',
    fields: {
      'requested': requested,
      'supported': [_semanticQueryId],
    },
  ),
  'semantic_query_source_detail_forbidden' => SemanticQueryDiagnostic(
    code: code,
    severity: 'error',
    message: 'Requested source detail exceeds the index ceiling.',
    fields: {'requested': requested, 'ceiling': reason},
  ),
  _ => SemanticQueryDiagnostic(
    code: 'semantic_query_invalid',
    severity: 'error',
    message: 'Invalid semantic query request.',
    fields: {'reason': reason},
  ),
};

SemanticQueryResponse _semanticEmptyQueryResponse(
  SemanticSnapshot snapshot,
  SemanticQuery request,
  SemanticQueryDiagnostic diagnostic,
) => _semanticRejectedQueryResponse(
  snapshot,
  afterId: request.page.afterId,
  diagnostic: diagnostic,
);

SemanticQueryResponse _semanticNeutralEmptyQueryResponse(
  SemanticSnapshot snapshot,
  Object? request,
  SemanticQueryDiagnostic diagnostic,
) {
  Object? afterId;
  if (request is Map && request['page'] is Map) {
    final page = request['page']! as Map;
    if (page.containsKey('after_id')) {
      afterId = _detachedPlainValue(page['after_id']);
    }
  }
  return _semanticRejectedQueryResponse(
    snapshot,
    afterId: afterId,
    diagnostic: diagnostic,
  );
}

SemanticQueryResponse _semanticRejectedQueryResponse(
  SemanticSnapshot snapshot, {
  required Object? afterId,
  required SemanticQueryDiagnostic diagnostic,
}) => SemanticQueryResponse(
  contract: _semanticQueryId,
  model: _semanticModelId,
  ok: false,
  snapshot: snapshot,
  page: SemanticQueryPageState(
    afterId: afterId,
    nextAfterId: null,
    complete: true,
  ),
  cost: const SemanticQueryCost(
    recordsExamined: 0,
    relationsExamined: 0,
    depthReached: 0,
  ),
  diagnostics: [diagnostic],
);

SemanticQueryResponse _semanticInvalidAfterId(
  SemanticSnapshot snapshot,
  SemanticQuery request,
) => _semanticEmptyQueryResponse(
  snapshot,
  request,
  _semanticQueryDiagnostic(
    'semantic_query_invalid',
    reason: 'after_id_not_in_primary_stream',
  ),
);

SemanticSourceDetail _semanticSourceDetail(Object? value) => switch (value) {
  'none' => SemanticSourceDetail.none,
  'identity' => SemanticSourceDetail.identity,
  'span' => SemanticSourceDetail.span,
  'text' => SemanticSourceDetail.text,
  _ => throw StateError('Unknown semantic source detail: $value'),
};
