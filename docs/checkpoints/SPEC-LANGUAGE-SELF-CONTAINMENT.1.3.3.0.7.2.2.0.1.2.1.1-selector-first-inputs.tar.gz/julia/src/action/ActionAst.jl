struct ActionSourceSpan
    start::Int
    stop::Int
end

abstract type ActionNode end
abstract type ActionExpr <: ActionNode end
abstract type ActionArgument end
abstract type ActionAccessSegment end

struct ActionStatement <: ActionNode
    kind::String
    source::String
    source_span::ActionSourceSpan
    expr::ActionExpr
    drops_value::Bool
end

function ActionStatement(; source, source_span, expr, drops_value = true)
    return ActionStatement("action_stmt", String(source), source_span, expr, drops_value)
end

struct ActionBlock <: ActionNode
    kind::String
    source::String
    source_span::ActionSourceSpan
    statements::Vector{ActionStatement}
end

function ActionBlock(; source, source_span, statements)
    return ActionBlock("action_block", String(source), source_span, ActionStatement[statements...])
end

struct ActionPositionalArgument <: ActionArgument
    value::ActionExpr
end

struct ActionKeywordArgument <: ActionArgument
    name::String
    value::ActionExpr
end

function ActionKeywordArgument(; name, value)
    return ActionKeywordArgument(String(name), value)
end

struct ActionCallExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    name::String
    args::Vector{ActionArgument}
    source_method::Union{Nothing,String}
    trailing_block_arg::Bool
    trailing_block_source_span::Union{Nothing,ActionSourceSpan}
end

function ActionCallExpr(;
    source,
    source_span,
    name,
    args,
    source_method = nothing,
    trailing_block_arg = false,
    trailing_block_source_span = nothing,
)
    return ActionCallExpr(
        "call",
        String(source),
        source_span,
        String(name),
        ActionArgument[args...],
        source_method === nothing ? nothing : String(source_method),
        trailing_block_arg,
        trailing_block_source_span,
    )
end

"""Create one rule-local opaque recognition-transaction token."""
struct ActionRecognitionCheckpointExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
end

function ActionRecognitionCheckpointExpr(; source, source_span)
    return ActionRecognitionCheckpointExpr(
        "recognition_checkpoint",
        String(source),
        source_span,
    )
end

"""Perform one non-eager recognition attempt against a static child rule."""
struct ActionRecognizeOnceExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    token::String
    rule::String
end

function ActionRecognizeOnceExpr(; source, source_span, token, rule)
    return ActionRecognizeOnceExpr(
        "recognize_once",
        String(source),
        source_span,
        String(token),
        String(rule),
    )
end

"""Observe one statically named child invocation and bind its detached record."""
struct ActionObserveRecognitionExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    target::String
    rule::String
end

function ActionObserveRecognitionExpr(; source, source_span, target, rule)
    return ActionObserveRecognitionExpr(
        "observe_recognition",
        String(source),
        source_span,
        String(target),
        String(rule),
    )
end

"""Commit one attempted token and return its staged payload."""
struct ActionRecognitionCommitExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    token::String
end

function ActionRecognitionCommitExpr(; source, source_span, token)
    return ActionRecognitionCommitExpr(
        "recognition_commit",
        String(source),
        source_span,
        String(token),
    )
end

"""Restore one attempted token's checkpoint and invalidate the token."""
struct ActionRecognitionRollbackExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    token::String
end

function ActionRecognitionRollbackExpr(; source, source_span, token)
    return ActionRecognitionRollbackExpr(
        "recognition_rollback",
        String(source),
        source_span,
        String(token),
    )
end

"""Assign one bounded child parse selected by logical identity and direct span."""
struct ActionProgressiveDispatchSpanExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    target::String
    parser_id::String
    top_rule::String
    span::String
end

function ActionProgressiveDispatchSpanExpr(;
    source,
    source_span,
    target,
    parser_id,
    top_rule,
    span,
)
    return ActionProgressiveDispatchSpanExpr(
        "progressive_dispatch_span",
        String(source),
        source_span,
        String(target),
        String(parser_id),
        String(top_rule),
        String(span),
    )
end

"""One direct live-match projection in a staged parse-job text plan."""
struct ActionStagedParseJobDirectTextPlan
    source::String
    index::Union{Nothing,Int}
end

function ActionStagedParseJobDirectTextPlan(; source, index = nothing)
    return ActionStagedParseJobDirectTextPlan(
        String(source),
        index === nothing ? nothing : Int(index),
    )
end

"""Closed source-provenance plan for one inert staged parse-job declaration."""
abstract type ActionStagedParseJobTextPlan end

struct ActionStagedParseJobDirectSpanPlan <: ActionStagedParseJobTextPlan
    kind::String
    source::String
    index::Union{Nothing,Int}
end

function ActionStagedParseJobDirectSpanPlan(; source, index = nothing)
    return ActionStagedParseJobDirectSpanPlan(
        "direct_span",
        String(source),
        index === nothing ? nothing : Int(index),
    )
end

struct ActionStagedParseJobDerivedTextPlan <: ActionStagedParseJobTextPlan
    kind::String
    policy::String
    segments::Tuple{Vararg{ActionStagedParseJobDirectTextPlan}}
end

function ActionStagedParseJobDerivedTextPlan(; segments)
    return ActionStagedParseJobDerivedTextPlan(
        "derived_text",
        "concatenate_in_order",
        Tuple(ActionStagedParseJobDirectTextPlan[segments...]),
    )
end

"""Normalized literal-only options retained by a staged declaration."""
struct ActionStagedParseJobOptions
    node_kind::String
    payload_kind::String
    spec::String
    top::Union{Nothing,String}
    result_policy::String
    into::Union{Nothing,String}
    on_error::String
    required_capabilities::Tuple{Vararg{String}}
end

function ActionStagedParseJobOptions(;
    node_kind,
    payload_kind,
    spec,
    top = nothing,
    result_policy,
    into = nothing,
    on_error,
    required_capabilities,
)
    return ActionStagedParseJobOptions(
        String(node_kind),
        String(payload_kind),
        String(spec),
        top === nothing ? nothing : String(top),
        String(result_policy),
        into === nothing ? nothing : String(into),
        String(on_error),
        Tuple(String[String(capability) for capability in required_capabilities]),
    )
end

"""
Declare one inert general staged parse job with typed source provenance.

This node owns the complete scalar assignment. It retains logical data only:
no parser, registry, callback, path, scheduler, or host authority.
"""
struct ActionStagedParseJobExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    target::String
    version::Int
    sidecar_kind::String
    effect::String
    text_plan::ActionStagedParseJobTextPlan
    options::ActionStagedParseJobOptions
end

function ActionStagedParseJobExpr(;
    source,
    source_span,
    target,
    text_plan,
    options,
)
    return ActionStagedParseJobExpr(
        "staged_parse_job_marker",
        String(source),
        source_span,
        String(target),
        2,
        "staged_parse_job_v2",
        "staged_parse_job_declaration",
        text_plan,
        options,
    )
end

struct ActionVariableExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    name::String
end

function ActionVariableExpr(; source, source_span, name)
    return ActionVariableExpr("variable", String(source), source_span, String(name))
end

struct ActionIndexedVarExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    name::String
    index::ActionExpr
end

function ActionIndexedVarExpr(; source, source_span, name, index)
    return ActionIndexedVarExpr("indexed_var", String(source), source_span, String(name), index)
end

struct ActionKeyAccessSegment <: ActionAccessSegment
    kind::String
    value::String
    source::String
    source_span::ActionSourceSpan
end

function ActionKeyAccessSegment(; value, source, source_span)
    return ActionKeyAccessSegment("key", String(value), String(source), source_span)
end

struct ActionIndexAccessSegment <: ActionAccessSegment
    kind::String
    expr::ActionExpr
    source::String
    source_span::ActionSourceSpan
end

function ActionIndexAccessSegment(; expr, source, source_span)
    return ActionIndexAccessSegment("index", expr, String(source), source_span)
end

"""One expression-bearing segment in an authored nested-write path."""
struct ActionWritePathSegment
    kind::String
    source::String
    source_span::ActionSourceSpan
    expression::ActionExpr
end

function ActionWritePathSegment(; source, source_span, expression)
    return ActionWritePathSegment(
        "path_segment",
        String(source),
        source_span,
        expression,
    )
end

struct ActionNestedAccessExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    base::String
    segments::Vector{ActionAccessSegment}
end

function ActionNestedAccessExpr(; source, source_span, base, segments)
    return ActionNestedAccessExpr(
        "nested_access",
        String(source),
        source_span,
        String(base),
        ActionAccessSegment[segments...],
    )
end

"""A mixed access path whose receiver is an evaluated expression result."""
struct ActionValueAccessExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    receiver::ActionExpr
    segments::Vector{ActionAccessSegment}
end

function ActionValueAccessExpr(; source, source_span, receiver, segments)
    return ActionValueAccessExpr(
        "value_access",
        String(source),
        source_span,
        receiver,
        ActionAccessSegment[segments...],
    )
end

struct ActionArrayLiteralExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    items::Vector{ActionExpr}
end

function ActionArrayLiteralExpr(; source, source_span, items)
    return ActionArrayLiteralExpr("array_literal", String(source), source_span, ActionExpr[items...])
end

struct ActionHashLiteralEntry
    key::ActionExpr
    value::ActionExpr
end

function ActionHashLiteralEntry(; key, value)
    return ActionHashLiteralEntry(key, value)
end

struct ActionHashLiteralExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    entries::Vector{ActionHashLiteralEntry}
end

function ActionHashLiteralExpr(; source, source_span, entries)
    return ActionHashLiteralExpr(
        "hash_literal",
        String(source),
        source_span,
        ActionHashLiteralEntry[entries...],
    )
end

struct ActionBlockValueExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    block::ActionBlock
end

function ActionBlockValueExpr(; source, source_span, block)
    return ActionBlockValueExpr("block_value", String(source), source_span, block)
end

"""An inert, serializable callable-codeblock value with a deferred typed body."""
struct ActionCodeblockLiteralExpr <: ActionExpr
    kind::String
    version::Int
    signature::CallableSignature
    body_source::String
    body_ast::ActionBlock
    source::String
    source_span::ActionSourceSpan
    body_span::ActionSourceSpan
end

function ActionCodeblockLiteralExpr(;
    version = 1,
    signature,
    body_source,
    body_ast,
    source,
    source_span,
    body_span,
)
    return ActionCodeblockLiteralExpr(
        "codeblock_literal",
        version,
        signature,
        String(body_source),
        body_ast,
        String(source),
        source_span,
        body_span,
    )
end

"""A zero-positional contextual block admitted by a callable's final-parameter contract."""
struct ActionCodeblockArgumentExpr <: ActionExpr
    kind::String
    version::Int
    signature::CallableSignature
    body_source::String
    body_ast::ActionBlock
    source::String
    source_span::ActionSourceSpan
    body_span::ActionSourceSpan
end

function ActionCodeblockArgumentExpr(;
    version = 1,
    signature,
    body_source,
    body_ast,
    source,
    source_span,
    body_span,
)
    return ActionCodeblockArgumentExpr(
        "codeblock_argument",
        version,
        signature,
        String(body_source),
        body_ast,
        String(source),
        source_span,
        body_span,
    )
end

"""Stable parser result for a malformed callable-codeblock literal."""
struct ActionCodeblockLiteralErrorExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    code::String
end

function ActionCodeblockLiteralErrorExpr(; source, source_span, code)
    return ActionCodeblockLiteralErrorExpr(
        "codeblock_literal_error",
        String(source),
        source_span,
        String(code),
    )
end

struct ActionStringLiteralExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    value::String
    quote_char::String
end

function ActionStringLiteralExpr(; source, source_span, value, quote_char)
    return ActionStringLiteralExpr("string", String(source), source_span, String(value), String(quote_char))
end

struct ActionNumberLiteralExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    value::Union{Int,Float64}
end

function ActionNumberLiteralExpr(; source, source_span, value)
    return ActionNumberLiteralExpr("number", String(source), source_span, value)
end

struct ActionBooleanLiteralExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    value::Bool
end

function ActionBooleanLiteralExpr(; source, source_span, value)
    return ActionBooleanLiteralExpr("boolean", String(source), source_span, value)
end

struct ActionRegexLiteralExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    pattern::String
    flags::String
end

function ActionRegexLiteralExpr(; source, source_span, pattern, flags = "")
    return ActionRegexLiteralExpr("regex", String(source), source_span, String(pattern), String(flags))
end

struct ActionUndefExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
end

function ActionUndefExpr(; source, source_span)
    return ActionUndefExpr("undef", String(source), source_span)
end

struct ActionAssignScalarExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    name::String
    value::ActionExpr
end

function ActionAssignScalarExpr(; source, source_span, name, value)
    return ActionAssignScalarExpr("assign_scalar", String(source), source_span, String(name), value)
end

struct ActionAssignArrayAppendExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    name::String
    value::ActionExpr
end

function ActionAssignArrayAppendExpr(; source, source_span, name, value)
    return ActionAssignArrayAppendExpr("assign_array_append", String(source), source_span, String(name), value)
end

struct ActionAssignHashIndexExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    name::String
    key::ActionExpr
    value::ActionExpr
end

function ActionAssignHashIndexExpr(; source, source_span, name, key, value)
    return ActionAssignHashIndexExpr("assign_hash_index", String(source), source_span, String(name), key, value)
end

struct ActionAssignNestedAccessExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    base::String
    segments::Vector{ActionWritePathSegment}
    value::ActionExpr
end

function ActionAssignNestedAccessExpr(; source, source_span, base, segments, value)
    return ActionAssignNestedAccessExpr(
        "assign_nested_access",
        String(source),
        source_span,
        String(base),
        ActionWritePathSegment[segments...],
        value,
    )
end

"""One bare, addressable uniform binding targeted by a receiver mutation."""
struct ActionReceiverMutationBindingReference <: ActionNode
    kind::String
    source::String
    source_span::ActionSourceSpan
    name::String
end

function ActionReceiverMutationBindingReference(; source, source_span, name)
    return ActionReceiverMutationBindingReference(
        "binding_reference",
        String(source),
        source_span,
        String(name),
    )
end

"""The immediate typed callback owned by `map_leaves!`."""
struct ActionReceiverMutationCallback <: ActionNode
    kind::String
    source::String
    source_span::ActionSourceSpan
    body::ActionBlock
end

function ActionReceiverMutationCallback(; source, source_span, body)
    return ActionReceiverMutationCallback(
        "block_value",
        String(source),
        source_span,
        body,
    )
end

"""The sole v1 receiver-mutating call."""
struct ActionReceiverMutationCall <: ActionNode
    kind::String
    source::String
    source_span::ActionSourceSpan
    method::String
    source_method::String
    method_span::ActionSourceSpan
    args_span::ActionSourceSpan
    callback::ActionReceiverMutationCallback
end

function ActionReceiverMutationCall(;
    source,
    source_span,
    method,
    source_method,
    method_span,
    args_span,
    callback,
)
    return ActionReceiverMutationCall(
        "receiver_mutation_call",
        String(source),
        source_span,
        String(method),
        String(source_method),
        method_span,
        args_span,
        callback,
    )
end

"""One ordinary non-bang fluent call after receiver publication."""
struct ActionReceiverMutationContinuationCall <: ActionNode
    kind::String
    source::String
    source_span::ActionSourceSpan
    method::String
    source_method::String
    args_source::String
    args_span::ActionSourceSpan
    args::Vector{ActionArgument}
end

function ActionReceiverMutationContinuationCall(;
    source,
    source_span,
    method,
    source_method,
    args_source,
    args_span,
    args,
)
    return ActionReceiverMutationContinuationCall(
        "fluent_call",
        String(source),
        source_span,
        String(method),
        String(source_method),
        String(args_source),
        args_span,
        ActionArgument[args...],
    )
end

"""One guarded receiver mutation followed by ordinary fluent continuation."""
struct ActionReceiverMutationChainExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    receiver::ActionReceiverMutationBindingReference
    mutation::ActionReceiverMutationCall
    continuation::Vector{ActionReceiverMutationContinuationCall}
end

function ActionReceiverMutationChainExpr(;
    source,
    source_span,
    receiver,
    mutation,
    continuation,
)
    return ActionReceiverMutationChainExpr(
        "receiver_mutation_chain",
        String(source),
        source_span,
        receiver,
        mutation,
        ActionReceiverMutationContinuationCall[continuation...],
    )
end

struct ActionFluentCall
    method::String
    args::Vector{ActionArgument}
    source::String
    source_span::ActionSourceSpan
    source_method::Union{Nothing,String}
    trailing_block_arg::Bool
    receiver_trailing_block_arg::Bool
    trailing_block_source_span::Union{Nothing,ActionSourceSpan}
end

function ActionFluentCall(;
    method,
    args,
    source,
    source_span,
    source_method = nothing,
    trailing_block_arg = false,
    receiver_trailing_block_arg = false,
    trailing_block_source_span = nothing,
)
    return ActionFluentCall(
        String(method),
        ActionArgument[args...],
        String(source),
        source_span,
        source_method === nothing ? nothing : String(source_method),
        trailing_block_arg,
        receiver_trailing_block_arg,
        trailing_block_source_span,
    )
end

struct ActionFluentChainExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    receiver::ActionExpr
    calls::Vector{ActionFluentCall}
end

function ActionFluentChainExpr(; source, source_span, receiver, calls)
    return ActionFluentChainExpr(
        "fluent_chain",
        String(source),
        source_span,
        receiver,
        ActionFluentCall[calls...],
    )
end

struct ActionControlIfExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    keyword::String
    canonical_keyword::String
    branch_role::String
    condition::ActionExpr
    args::Vector{ActionArgument}
    body::Union{Nothing,ActionBlock}
    body_source_span::Union{Nothing,ActionSourceSpan}
end

function ActionControlIfExpr(;
    source,
    source_span,
    keyword,
    canonical_keyword,
    branch_role,
    condition,
    args,
    body = nothing,
    body_source_span = nothing,
)
    return ActionControlIfExpr(
        "control_if",
        String(source),
        source_span,
        String(keyword),
        String(canonical_keyword),
        String(branch_role),
        condition,
        ActionArgument[args...],
        body,
        body_source_span,
    )
end

struct ActionControlElseExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    keyword::String
    canonical_keyword::String
    args::Vector{ActionArgument}
    body::Union{Nothing,ActionBlock}
    body_source_span::Union{Nothing,ActionSourceSpan}
end

function ActionControlElseExpr(;
    source,
    source_span,
    keyword,
    canonical_keyword,
    args,
    body = nothing,
    body_source_span = nothing,
)
    return ActionControlElseExpr(
        "control_else",
        String(source),
        source_span,
        String(keyword),
        String(canonical_keyword),
        ActionArgument[args...],
        body,
        body_source_span,
    )
end

struct ActionControlMarkerExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    keyword::String
    canonical_keyword::String
    args::Vector{ActionArgument}
end

function ActionControlMarkerExpr(; kind, source, source_span, keyword, canonical_keyword, args)
    return ActionControlMarkerExpr(
        String(kind),
        String(source),
        source_span,
        String(keyword),
        String(canonical_keyword),
        ActionArgument[args...],
    )
end

struct ActionControlWhileExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    keyword::String
    canonical_keyword::String
    condition::ActionExpr
    args::Vector{ActionArgument}
    body::Union{Nothing,ActionBlock}
    body_source_span::Union{Nothing,ActionSourceSpan}
end

function ActionControlWhileExpr(;
    source,
    source_span,
    keyword,
    canonical_keyword,
    condition,
    args,
    body = nothing,
    body_source_span = nothing,
)
    return ActionControlWhileExpr(
        "control_while",
        String(source),
        source_span,
        String(keyword),
        String(canonical_keyword),
        condition,
        ActionArgument[args...],
        body,
        body_source_span,
    )
end

struct ActionControlSwitchExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    keyword::String
    canonical_keyword::String
    source_expr::ActionExpr
    args::Vector{ActionArgument}
    body::Union{Nothing,ActionBlock}
    body_source_span::Union{Nothing,ActionSourceSpan}
    cases::Vector{ActionExpr}
    default_case::Union{Nothing,ActionExpr}
end

function ActionControlSwitchExpr(;
    source,
    source_span,
    keyword,
    canonical_keyword,
    source_expr,
    args,
    body = nothing,
    body_source_span = nothing,
    cases = Any[],
    default_case = nothing,
)
    return ActionControlSwitchExpr(
        "control_switch",
        String(source),
        source_span,
        String(keyword),
        String(canonical_keyword),
        source_expr,
        ActionArgument[args...],
        body,
        body_source_span,
        ActionExpr[cases...],
        default_case,
    )
end

struct ActionControlCaseExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    keyword::String
    canonical_keyword::String
    match::ActionExpr
    args::Vector{ActionArgument}
    body::Union{Nothing,ActionBlock}
    body_source_span::Union{Nothing,ActionSourceSpan}
end

function ActionControlCaseExpr(;
    source,
    source_span,
    keyword,
    canonical_keyword,
    match,
    args,
    body = nothing,
    body_source_span = nothing,
)
    return ActionControlCaseExpr(
        "control_case",
        String(source),
        source_span,
        String(keyword),
        String(canonical_keyword),
        match,
        ActionArgument[args...],
        body,
        body_source_span,
    )
end

struct ActionControlDefaultExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    keyword::String
    canonical_keyword::String
    args::Vector{ActionArgument}
    body::Union{Nothing,ActionBlock}
    body_source_span::Union{Nothing,ActionSourceSpan}
end

function ActionControlDefaultExpr(;
    source,
    source_span,
    keyword,
    canonical_keyword,
    args,
    body = nothing,
    body_source_span = nothing,
)
    return ActionControlDefaultExpr(
        "control_default",
        String(source),
        source_span,
        String(keyword),
        String(canonical_keyword),
        ActionArgument[args...],
        body,
        body_source_span,
    )
end

struct ActionRawExpr <: ActionExpr
    kind::String
    source::String
    source_span::ActionSourceSpan
    reason::String
end

function ActionRawExpr(; source, source_span, reason)
    return ActionRawExpr("raw_perl", String(source), source_span, String(reason))
end

struct RemovedAggregateSelector
    surface::String
    identifier::String
end

function removed_aggregate_selector_diagnostic(selector::RemovedAggregateSelector)
    return "aggregate_selector_removed surface=$(selector.surface) " *
           "identifier=$(selector.identifier) replacement=$(selector.identifier)"
end

"""Return the first removed aggregate selector in `block`, if any."""
function find_removed_aggregate_selector(block::ActionBlock)
    for statement in block.statements
        selector = find_removed_aggregate_selector(statement.expr)
        if selector !== nothing
            return selector
        end
    end
    return nothing
end

function _find_removed_aggregate_selector_in_args(args)
    for arg in args
        selector = find_removed_aggregate_selector(arg.value)
        if selector !== nothing
            return selector
        end
    end
    return nothing
end

function _find_removed_aggregate_selector_in_block(block)
    return block === nothing ? nothing : find_removed_aggregate_selector(block)
end

function _find_removed_aggregate_selector_in_segments(segments)
    for segment in segments
        if segment isa ActionIndexAccessSegment
            selector = find_removed_aggregate_selector(segment.expr)
            if selector !== nothing
                return selector
            end
        end
    end
    return nothing
end

function _find_removed_aggregate_selector_in_write_segments(segments)
    for segment in segments
        selector = find_removed_aggregate_selector(segment.expression)
        if selector !== nothing
            return selector
        end
    end
    return nothing
end

"""Return the first removed one-bare-identifier aggregate selector below `expr`."""
function find_removed_aggregate_selector(expr::ActionExpr)
    if expr isa ActionCallExpr
        if expr.name in ("array", "hash") && length(expr.args) == 1
            arg = only(expr.args)
            if arg isa ActionPositionalArgument && arg.value isa ActionVariableExpr
                return RemovedAggregateSelector(expr.name, arg.value.name)
            end
        end
        return _find_removed_aggregate_selector_in_args(expr.args)
    elseif expr isa ActionRecognitionCheckpointExpr ||
           expr isa ActionRecognizeOnceExpr ||
           expr isa ActionObserveRecognitionExpr ||
           expr isa ActionRecognitionCommitExpr ||
           expr isa ActionRecognitionRollbackExpr ||
           expr isa ActionProgressiveDispatchSpanExpr ||
           expr isa ActionStagedParseJobExpr
        return nothing
    elseif expr isa ActionReceiverMutationChainExpr
        selector = find_removed_aggregate_selector(expr.mutation.callback.body)
        if selector !== nothing
            return selector
        end
        for call in expr.continuation
            selector = _find_removed_aggregate_selector_in_args(call.args)
            if selector !== nothing
                return selector
            end
        end
        return nothing
    elseif expr isa ActionFluentChainExpr
        selector = find_removed_aggregate_selector(expr.receiver)
        if selector !== nothing
            return selector
        end
        for call in expr.calls
            selector = _find_removed_aggregate_selector_in_args(call.args)
            if selector !== nothing
                return selector
            end
        end
        return nothing
    elseif expr isa ActionAssignScalarExpr || expr isa ActionAssignArrayAppendExpr
        return find_removed_aggregate_selector(expr.value)
    elseif expr isa ActionAssignHashIndexExpr
        selector = find_removed_aggregate_selector(expr.key)
        return selector === nothing ? find_removed_aggregate_selector(expr.value) : selector
    elseif expr isa ActionAssignNestedAccessExpr
        selector = _find_removed_aggregate_selector_in_write_segments(expr.segments)
        return selector === nothing ? find_removed_aggregate_selector(expr.value) : selector
    elseif expr isa ActionIndexedVarExpr
        return find_removed_aggregate_selector(expr.index)
    elseif expr isa ActionNestedAccessExpr
        return _find_removed_aggregate_selector_in_segments(expr.segments)
    elseif expr isa ActionValueAccessExpr
        selector = find_removed_aggregate_selector(expr.receiver)
        return selector === nothing ?
               _find_removed_aggregate_selector_in_segments(expr.segments) : selector
    elseif expr isa ActionArrayLiteralExpr
        for item in expr.items
            selector = find_removed_aggregate_selector(item)
            if selector !== nothing
                return selector
            end
        end
        return nothing
    elseif expr isa ActionHashLiteralExpr
        for entry in expr.entries
            selector = find_removed_aggregate_selector(entry.key)
            if selector === nothing
                selector = find_removed_aggregate_selector(entry.value)
            end
            if selector !== nothing
                return selector
            end
        end
        return nothing
    elseif expr isa ActionBlockValueExpr
        return find_removed_aggregate_selector(expr.block)
    elseif expr isa ActionCodeblockLiteralExpr || expr isa ActionCodeblockArgumentExpr ||
           expr isa ActionCodeblockLiteralErrorExpr
        return nothing
    elseif expr isa ActionControlIfExpr
        selector = find_removed_aggregate_selector(expr.condition)
        selector === nothing && (selector = _find_removed_aggregate_selector_in_args(expr.args))
        selector === nothing && (selector = _find_removed_aggregate_selector_in_block(expr.body))
        return selector
    elseif expr isa ActionControlElseExpr || expr isa ActionControlDefaultExpr
        selector = _find_removed_aggregate_selector_in_args(expr.args)
        return selector === nothing ? _find_removed_aggregate_selector_in_block(expr.body) : selector
    elseif expr isa ActionControlMarkerExpr
        return _find_removed_aggregate_selector_in_args(expr.args)
    elseif expr isa ActionControlWhileExpr
        selector = find_removed_aggregate_selector(expr.condition)
        selector === nothing && (selector = _find_removed_aggregate_selector_in_args(expr.args))
        selector === nothing && (selector = _find_removed_aggregate_selector_in_block(expr.body))
        return selector
    elseif expr isa ActionControlSwitchExpr
        selector = find_removed_aggregate_selector(expr.source_expr)
        selector === nothing && (selector = _find_removed_aggregate_selector_in_args(expr.args))
        selector === nothing && (selector = _find_removed_aggregate_selector_in_block(expr.body))
        if selector !== nothing
            return selector
        end
        for case_expr in expr.cases
            selector = find_removed_aggregate_selector(case_expr)
            if selector !== nothing
                return selector
            end
        end
        return expr.default_case === nothing ?
               nothing : find_removed_aggregate_selector(expr.default_case)
    elseif expr isa ActionControlCaseExpr
        selector = find_removed_aggregate_selector(expr.match)
        selector === nothing && (selector = _find_removed_aggregate_selector_in_args(expr.args))
        selector === nothing && (selector = _find_removed_aggregate_selector_in_block(expr.body))
        return selector
    end
    return nothing
end

to_json(span::ActionSourceSpan) = Dict("start" => span.start, "end" => span.stop)

function _action_base_json(node)
    return Dict{String,Any}(
        "kind" => node.kind,
        "source" => node.source,
        "source_span" => to_json(node.source_span),
    )
end

function to_json(block::ActionBlock)
    result = _action_base_json(block)
    result["statements"] = [to_json(statement) for statement in block.statements]
    return result
end

function to_json(statement::ActionStatement)
    result = _action_base_json(statement)
    result["expr"] = to_json(statement.expr)
    result["drops_value"] = statement.drops_value
    return result
end

to_json(argument::ActionPositionalArgument) = to_json(argument.value)
to_json(argument::ActionKeywordArgument) = Dict("name" => argument.name, "value" => to_json(argument.value))

function to_json(expr::ActionCallExpr)
    result = _action_base_json(expr)
    result["name"] = expr.name
    _put_if_present!(result, "source_method", expr.source_method)
    result["args"] = [to_json(argument) for argument in expr.args]
    if expr.trailing_block_arg
        result["trailing_block_arg"] = true
    end
    if expr.trailing_block_source_span !== nothing
        result["trailing_block_source_span"] = to_json(expr.trailing_block_source_span)
    end
    return result
end

to_json(expr::ActionRecognitionCheckpointExpr) = _action_base_json(expr)

function to_json(expr::ActionRecognizeOnceExpr)
    result = _action_base_json(expr)
    result["token"] = expr.token
    result["rule"] = expr.rule
    return result
end

function to_json(expr::ActionObserveRecognitionExpr)
    result = _action_base_json(expr)
    result["target"] = expr.target
    result["rule"] = expr.rule
    return result
end

function to_json(expr::ActionRecognitionCommitExpr)
    result = _action_base_json(expr)
    result["token"] = expr.token
    return result
end

function to_json(expr::ActionRecognitionRollbackExpr)
    result = _action_base_json(expr)
    result["token"] = expr.token
    return result
end

function to_json(expr::ActionProgressiveDispatchSpanExpr)
    result = _action_base_json(expr)
    result["target"] = expr.target
    result["parser_id"] = expr.parser_id
    result["top_rule"] = expr.top_rule
    result["span"] = expr.span
    return result
end

function to_json(plan::ActionStagedParseJobDirectTextPlan)
    result = Dict{String,Any}("source" => plan.source)
    _put_if_present!(result, "index", plan.index)
    return result
end

function to_json(plan::ActionStagedParseJobDirectSpanPlan)
    result = Dict{String,Any}(
        "kind" => plan.kind,
        "source" => plan.source,
    )
    _put_if_present!(result, "index", plan.index)
    return result
end

function to_json(plan::ActionStagedParseJobDerivedTextPlan)
    return Dict{String,Any}(
        "kind" => plan.kind,
        "policy" => plan.policy,
        "segments" => Any[to_json(segment) for segment in plan.segments],
    )
end

function to_json(options::ActionStagedParseJobOptions)
    result = Dict{String,Any}(
        "node_kind" => options.node_kind,
        "payload_kind" => options.payload_kind,
        "spec" => options.spec,
        "result_policy" => options.result_policy,
        "on_error" => options.on_error,
        "required_capabilities" => Any[options.required_capabilities...],
    )
    _put_if_present!(result, "top", options.top)
    _put_if_present!(result, "into", options.into)
    return result
end

function to_json(expr::ActionStagedParseJobExpr)
    result = _action_base_json(expr)
    result["target"] = expr.target
    result["version"] = expr.version
    result["sidecar_kind"] = expr.sidecar_kind
    result["effect"] = expr.effect
    result["text_plan"] = to_json(expr.text_plan)
    result["options"] = to_json(expr.options)
    return result
end

function to_json(expr::ActionVariableExpr)
    result = _action_base_json(expr)
    result["name"] = expr.name
    return result
end

function to_json(expr::ActionIndexedVarExpr)
    result = _action_base_json(expr)
    result["name"] = expr.name
    result["index"] = to_json(expr.index)
    return result
end

function to_json(segment::ActionKeyAccessSegment)
    return Dict(
        "kind" => segment.kind,
        "value" => segment.value,
        "source" => segment.source,
        "source_span" => to_json(segment.source_span),
    )
end

function to_json(segment::ActionIndexAccessSegment)
    return Dict(
        "kind" => segment.kind,
        "expr" => to_json(segment.expr),
        "source" => segment.source,
        "source_span" => to_json(segment.source_span),
    )
end

function to_json(segment::ActionWritePathSegment)
    return Dict(
        "kind" => segment.kind,
        "source" => segment.source,
        "source_span" => to_json(segment.source_span),
        "expression" => to_json(segment.expression),
    )
end

function to_json(expr::ActionNestedAccessExpr)
    result = _action_base_json(expr)
    result["base"] = expr.base
    result["segments"] = [to_json(segment) for segment in expr.segments]
    return result
end

function to_json(expr::ActionValueAccessExpr)
    result = _action_base_json(expr)
    result["receiver"] = to_json(expr.receiver)
    result["segments"] = [to_json(segment) for segment in expr.segments]
    return result
end

function to_json(expr::ActionArrayLiteralExpr)
    result = _action_base_json(expr)
    result["items"] = [to_json(item) for item in expr.items]
    return result
end

to_json(entry::ActionHashLiteralEntry) = Dict("key" => to_json(entry.key), "value" => to_json(entry.value))

function to_json(expr::ActionHashLiteralExpr)
    result = _action_base_json(expr)
    result["entries"] = [to_json(entry) for entry in expr.entries]
    return result
end

function to_json(expr::ActionBlockValueExpr)
    result = _action_base_json(expr)
    result["block"] = to_json(expr.block)
    return result
end

function to_json(expr::ActionCodeblockLiteralExpr)
    return Dict{String,Any}(
        "kind" => expr.kind,
        "version" => expr.version,
        "signature" => to_json(expr.signature),
        "body_source" => expr.body_source,
        "body_ast" => to_json(expr.body_ast),
        "source_text" => expr.source,
        "source_span" => to_json(expr.source_span),
        "body_span" => to_json(expr.body_span),
    )
end

function to_json(expr::ActionCodeblockArgumentExpr)
    return Dict{String,Any}(
        "kind" => expr.kind,
        "version" => expr.version,
        "signature" => to_json(expr.signature),
        "body_source" => expr.body_source,
        "body_ast" => to_json(expr.body_ast),
        "source_text" => expr.source,
        "source_span" => to_json(expr.source_span),
        "body_span" => to_json(expr.body_span),
    )
end

function to_json(expr::ActionCodeblockLiteralErrorExpr)
    result = _action_base_json(expr)
    result["code"] = expr.code
    return result
end

function to_json(expr::ActionStringLiteralExpr)
    result = _action_base_json(expr)
    result["value"] = expr.value
    result["quote"] = expr.quote_char
    return result
end

function to_json(expr::ActionNumberLiteralExpr)
    result = _action_base_json(expr)
    result["value"] = expr.value
    return result
end

function to_json(expr::ActionBooleanLiteralExpr)
    result = _action_base_json(expr)
    result["value"] = expr.value
    return result
end

function to_json(expr::ActionRegexLiteralExpr)
    result = _action_base_json(expr)
    result["pattern"] = expr.pattern
    result["flags"] = expr.flags
    return result
end

to_json(expr::ActionUndefExpr) = _action_base_json(expr)

function to_json(expr::ActionAssignScalarExpr)
    result = _action_base_json(expr)
    result["name"] = expr.name
    result["value"] = to_json(expr.value)
    return result
end

function to_json(expr::ActionAssignArrayAppendExpr)
    result = _action_base_json(expr)
    result["name"] = expr.name
    result["value"] = to_json(expr.value)
    return result
end

function to_json(expr::ActionAssignHashIndexExpr)
    result = _action_base_json(expr)
    result["name"] = expr.name
    result["key"] = to_json(expr.key)
    result["value"] = to_json(expr.value)
    return result
end

function to_json(expr::ActionAssignNestedAccessExpr)
    result = _action_base_json(expr)
    result["base"] = expr.base
    result["segments"] = [to_json(segment) for segment in expr.segments]
    result["value"] = to_json(expr.value)
    return result
end

function to_json(reference::ActionReceiverMutationBindingReference)
    result = _action_base_json(reference)
    result["name"] = reference.name
    return result
end

function to_json(callback::ActionReceiverMutationCallback)
    result = _action_base_json(callback)
    result["body"] = to_json(callback.body)
    return result
end

function to_json(call::ActionReceiverMutationCall)
    result = _action_base_json(call)
    result["method"] = call.method
    result["source_method"] = call.source_method
    result["method_span"] = to_json(call.method_span)
    result["args_span"] = to_json(call.args_span)
    result["callback"] = to_json(call.callback)
    return result
end

function to_json(call::ActionReceiverMutationContinuationCall)
    result = _action_base_json(call)
    result["method"] = call.method
    result["source_method"] = call.source_method
    result["args_source"] = call.args_source
    result["args_span"] = to_json(call.args_span)
    result["args"] = [to_json(argument) for argument in call.args]
    return result
end

function to_json(expr::ActionReceiverMutationChainExpr)
    result = _action_base_json(expr)
    result["receiver"] = to_json(expr.receiver)
    result["mutation"] = to_json(expr.mutation)
    result["continuation"] = [to_json(call) for call in expr.continuation]
    return result
end

function to_json(call::ActionFluentCall)
    result = Dict{String,Any}(
        "method" => call.method,
        "args" => [to_json(argument) for argument in call.args],
        "source" => call.source,
        "source_span" => to_json(call.source_span),
    )
    _put_if_present!(result, "source_method", call.source_method)
    if call.trailing_block_arg
        result["trailing_block_arg"] = true
    end
    if call.receiver_trailing_block_arg
        result["receiver_trailing_block_arg"] = true
    end
    if call.trailing_block_source_span !== nothing
        result["trailing_block_source_span"] = to_json(call.trailing_block_source_span)
    end
    return result
end

function to_json(expr::ActionFluentChainExpr)
    result = _action_base_json(expr)
    result["receiver"] = to_json(expr.receiver)
    result["calls"] = [to_json(call) for call in expr.calls]
    return result
end

function to_json(expr::ActionControlIfExpr)
    result = _action_base_json(expr)
    result["keyword"] = expr.keyword
    result["canonical_keyword"] = expr.canonical_keyword
    result["branch_role"] = expr.branch_role
    result["condition"] = to_json(expr.condition)
    result["args"] = [to_json(argument) for argument in expr.args]
    _put_action_block_fields!(result, expr.body, expr.body_source_span)
    return result
end

function to_json(expr::ActionControlElseExpr)
    result = _action_base_json(expr)
    result["keyword"] = expr.keyword
    result["canonical_keyword"] = expr.canonical_keyword
    result["branch_role"] = "else"
    result["args"] = [to_json(argument) for argument in expr.args]
    _put_action_block_fields!(result, expr.body, expr.body_source_span)
    return result
end

function to_json(expr::ActionControlMarkerExpr)
    result = _action_base_json(expr)
    result["keyword"] = expr.keyword
    result["canonical_keyword"] = expr.canonical_keyword
    result["args"] = [to_json(argument) for argument in expr.args]
    return result
end

function to_json(expr::ActionControlWhileExpr)
    result = _action_base_json(expr)
    result["keyword"] = expr.keyword
    result["canonical_keyword"] = expr.canonical_keyword
    result["condition"] = to_json(expr.condition)
    result["args"] = [to_json(argument) for argument in expr.args]
    _put_action_block_fields!(result, expr.body, expr.body_source_span)
    return result
end

function to_json(expr::ActionControlSwitchExpr)
    result = _action_base_json(expr)
    result["keyword"] = expr.keyword
    result["canonical_keyword"] = expr.canonical_keyword
    result["source_expr"] = to_json(expr.source_expr)
    result["args"] = [to_json(argument) for argument in expr.args]
    _put_action_block_fields!(result, expr.body, expr.body_source_span)
    if !isempty(expr.cases)
        result["cases"] = [to_json(item) for item in expr.cases]
    end
    if expr.default_case !== nothing
        result["default"] = to_json(expr.default_case)
    end
    return result
end

function to_json(expr::ActionControlCaseExpr)
    result = _action_base_json(expr)
    result["keyword"] = expr.keyword
    result["canonical_keyword"] = expr.canonical_keyword
    result["match"] = to_json(expr.match)
    result["args"] = [to_json(argument) for argument in expr.args]
    _put_action_block_fields!(result, expr.body, expr.body_source_span)
    return result
end

function to_json(expr::ActionControlDefaultExpr)
    result = _action_base_json(expr)
    result["keyword"] = expr.keyword
    result["canonical_keyword"] = expr.canonical_keyword
    result["args"] = [to_json(argument) for argument in expr.args]
    _put_action_block_fields!(result, expr.body, expr.body_source_span)
    return result
end

function to_json(expr::ActionRawExpr)
    result = _action_base_json(expr)
    result["reason"] = expr.reason
    return result
end

function _put_action_block_fields!(result, body, body_source_span)
    if body !== nothing
        result["body"] = to_json(body)
    end
    if body_source_span !== nothing
        result["body_source_span"] = to_json(body_source_span)
    end
    return result
end
