# Backend Handoff

Dart blind-target validation now accepts declared rules without regex slots while action targets retain strict slot checks. The qualified target has four passing runtime controls; blind `.push` parent calls now pass the13 single-pass/repeated controls. Conventional rule arrays are fresh per invocation. Three coordinator controls still collect an extra empty nonconsuming iteration; ordinary progress/lifecycle authority remains separately owned. Pure-code blind children now compile and execute without manufactured regex slots on the recorded Dart routes. Call references remain complete while the regex dependency map contains actual regexes only; strict action and validation-bypass checks remain. This compiler repair does not establish complete coordinator runtime parity.

Julia now accepts referenced and pure-code blind targets without fabricated regex slots. Recorded direct-call, AND literal-return and pure-code native/restored/plan/fresh controls pass. Blind `.push` now calls the enclosing parent on13 recorded single-pass/repeated controls, preserving typed falsey/null/container values and explicit targets with existing emitted modules. Conventional arrays are now fresh per invocation; direct twice and caller scalar/Array/Hash restoration controls pass. Three referenced coordinators still collect a final empty ordinary iteration under canonical progress review. A separate control shows Julia shares an undeclared child working variable where current Perl keeps it local; that scope-authority repair remains required before admission.

Installed safe PUC Lua5.5/LuaJIT now compile referenced and pure-code blind targets without fabricated regex slots. Ten recorded native/restored/plan/fresh runtime controls pass per host; three coordinator empty-tail cases remain under canonical ordinary-progress review. Action slots and strict errors remain unchanged. No Lua5.4, unsafe-pattern or full admission claim follows.

Current focused Rust work preserves typed blind returns, invocation-local accumulators and parent-calling blind `.push` on the recorded routes. Repeated blind post-call returns now complete the current iteration or AND group with minimum/progress checks on the recorded routes. Portable blind-parent `LX` authority remains open. Perl single-action AND source now reuses its invocation-local match declarations. Regenerate older emitted modules to remove their duplicate-declaration warnings; recorded values, metadata and format remain unchanged. OR action source now reuses the same declarations too; regenerate older OR modules to remove their loading warnings. Blind scalar declarations now reuse existing preamble declarations too, including empty .return() and explicit-target push. Nested repetition locals stay independent; regenerate older modules to remove scalar loading warnings. Recorded values, metadata and diagnostic JSON are unchanged. Perl runtime rule guards now use pinned Unicode labels; the recorded native/emitted and retained-module routes execute `Ω` roots and Unicode blind/direct callees. Static Unicode `recognize_once` and `observe_recognition` callees now pass their scanner, lowering and runtime checks on the recorded routes. Existing valid modules remain reusable; observation modules emitted by the incomplete intermediate compiler require regeneration. Remaining ordinary-progress, lifecycle and cross-rule scope prerequisites stay open before admission; earlier bounded admissions below retain their stated scope.

Perl readonly anonymous capture String results now compose through direct defaults, String/Array selection and Number continuations. Native getter behavior remains the same; regenerate modules affected by the earlier direct-chain compiler gap. Rust already supports the same bounded target across native, restored and generated-plan execution without a runtime change. Dart also already supports the target across its native, restored and generated-plan routes without a runtime change. Julia also already supports the target across native, reconstructed, generated-plan and freshly loaded emitted Module routes without a runtime change. Installed PUC Lua 5.5.1/LuaJIT also already support the bounded target across native, restored, generated-plan and freshly loaded module routes without a runtime change. Existing direct-consumer and callback policies remain qualified; declared Lua 5.4 and broader source/context/portable admission stay separate.

Perl anonymous advancing capture String results now support direct default, String/Array-selection and Number continuations. Native endpoint and origin updates remain unchanged; the live cursor does not move. Regenerate older modules affected by this direct-chain compiler gap. Rust already supports the advancing target across native, restored and generated-plan routes without a runtime change, including its existing caller-context callback effects. Dart also already supports the advancing target across native, restored and generated-plan execution without a runtime change. Julia also preserves the target across native, reconstructed, generated-plan and same-process freshly loaded emitted Module routes without a runtime change. Installed PUC Lua 5.5.1/LuaJIT also preserve the advancing target across native, restored, generated-plan and freshly loaded modules without a runtime change. Declared Lua 5.4 and full-context checks stay separate.

Perl anonymous advancing capture Number results now support direct default/arithmetic and Number-to-String/Array-selection continuations. Native widths, guarded origin updates and live-cursor behavior remain unchanged; regenerate older modules affected by the compiler gap. Rust also already supports the Number target across native, restored and generated-plan routes without a runtime change. Dart also already supports the Number target across native, restored and generated-plan routes without a runtime change. Julia also already supports the Number target across native, reconstructed, generated-plan and same-process freshly loaded emitted Module routes without a runtime change. Installed PUC Lua 5.5.1/LuaJIT also preserve the Number target across native, restored, generated-plan and freshly loaded modules without a runtime change. Declared Lua 5.4 and broader context checks stay separate.

Perl structural-boundary capture results now support direct default/String and Number continuations. Existing boundary selection, non-consumption, EOF/unresolved behavior and cursor effects remain; malformed argument slots keep their prior rejection phase. Regenerate affected older modules. Rust already supports the boundary-result target across native, restored and generated-plan execution without a runtime change. Dart also already supports the boundary-result target across native, restored and generated-plan execution without a runtime change. Julia also already supports the boundary-result target across native, reconstructed, generated-plan and same-process freshly loaded emitted Module routes without a runtime change. PUC Lua 5.5.1 and LuaJIT also preserve the boundary-result target across native, restored, generated-plan and freshly loaded modules without a runtime change. Declared Lua 5.4 and broader context checks stay separate.

The retained Perl regression subset has focused passing evidence. `pick_keys` keeps distinct operand keys and `sorted_values` scalar inputs no longer consult symbolic host hashes; regenerate affected older Perl modules. Copy checks follow approved scalar/null preservation and actual-kind continuations, while typed mutation checks preserve key-before-value snapshots. The original twenty-eight failure groups now pass together in a current-source replay. The dependent projected-value assertion follows the repaired scalar-isolation guard; its public value controls and seeded isolation regression also pass. These results establish no full-suite or portable admission; broader absent/legacy collection isolation stays open.

> **Nested-write and `map_leaves!` parity is publicly closed:** ordinary bare-binding nested assignment performs
> evaluated string/integer path selection, dense unambiguous creation, isolated publication, and detached result
> delivery on Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT. The sole v1 bang method maps only an existing bare
> harray/array receiver's leaves over its original shape, guards that receiver identity during callbacks, commits
> once, and starts continuation afterward. Run `bash tools/check_mutation_six_runtime.sh` for the six-runtime proof
> and `bash tools/run_python_project_data.sh tools/check_mutation_public_surface.py` for current public no-drift.
>
> **Standalone lifecycle-block parity is complete:** ADR `0094` requires a rule-item-leading `{ ... }` to
> normalize directly to lifecycle `I`, preserve authored source/line and explicit-twin ActionIR semantics, append
> duplicates in order, retain every earlier brace owner, and leave legacy plain carriers inert. Perl, Rust, Dart,
> Julia, PUC Lua, and LuaJIT are admitted, and `specs/spec.spec` preserves reserved lifecycle precedence. Run
> `bash tools/check_standalone_lifecycle_block_five_backend.sh` for the closed recurring proof.
>

> **Accepted cursor/generated migration:** ADR `0044` requires every backend to
> derive cursor policy from authored family, preserve child ownership, remove
> public/global overrides with portable diagnostics, project per-rule
> `cursor_policy`, and emit/consume `linkedspec-generated-source-v2`. Version-2
> plan rows retain `{label, family}` and derive policy from family. Perl is
> admitted across the composed contract, as are Rust and Dart through their own
> topology-checked consumers. Julia is fully admitted with typed normalization,
> intrinsic execution, cursor descriptor v1, generated-source v2, and no public
> override. Lua now has typed normalization, intrinsic normal live/loaded/
> normalized/recursive/traced execution, cursor descriptor v1 with exact
> direct/normalized/loaded byte identity, and generated-source v2 with exact
> five-seek/five-consume derivation on both ABIs. Global-option removal is now
> complete too: high-level legacy keys fail with the portable removal diagnostic,
> and primary help/request trace no longer expose the retired flag. One exact
> 15-role consumer now admits the complete projection on both Lua ABIs;
> v1 generated artifacts must be regenerated. The recurring six-runtime plus
> selected 5x2x5 gate and current public surfaces are admitted at 79 migration
> files, 8 complete / 0 pending, and 60 rejected mutations.
>
> **Accepted source-location/cursor architecture:** ADR `0056` requires one backend-neutral immutable model
> for caller-authorized source identity, Unicode-scalar positions, same-source half-open spans, and ordered derived
> provenance. Perl's existing source-boundary helpers project that model and are admitted. Rust now admits the
> same internal projections across native, reconstructed, and generated-plan execution while retaining byte
> registers; its ordinary four-test consumer is required by canonical CI. Dart now implements the same internal
> values and all 92+7 projections while retaining UTF-16 code-unit registers. Its explicit four-test consumer
> passes native, reconstructed, generated-plan, and freshly emitted execution under ordinary discovery and
> canonical CI.
>
> Julia now admits the same internal values and 92+7 projections while retaining zero-based UTF-8 code-unit
> registers. Its explicit consumer passes native, reconstructed, and generated-plan execution under ordinary
> discovery and canonical CI. Both Lua ABIs share a private immutable value core and exact 92+7 helper projections
> across native, reconstructed, and generated-plan execution. Their one shared consumer now runs once per ABI in
> ordinary and canonical discovery and passes 240/240 each while preserving existing UTF-8-byte registers, values,
> and mutation timing. One repository-routed recurring driver composes neutral, Perl, Rust, Dart, Julia, PUC Lua,
> and LuaJIT in exact order, then generated-source, capability, and language-coverage ledgers. Run
> `bash tools/check_typed_source_location_six_runtime.sh`; canonical CI exposes the same all-toolchain proof behind
> `LINKEDSPEC_RUN_TYPED_SOURCE_MATRIX=1`. Five backend source groups map to six runtime routes because the shared
> Lua source executes on both ABIs. At the staged-recurrence boundary, governance was 13 complete / 1 pending with 187 drift mutations after the
> independently governed transaction-safety projection, recursive-observation public projection/no-drift, and
> lossless-gap, progressive-recurrence, and staged-AST-recurrence closeouts.
>
> Combined typed authoring-model public no-drift is current with 14/14 rollout legs complete and no new runtime or public API.
> `bash tools/check_typed_authoring_model_six_runtime.sh` composes the six existing recurring drivers in order;
> each constituent driver remains the sole behavior/runtime authority for its lane.
>
> No-change recomposition `.14.2.7` reruns that exact authority and closes the internal value/helper implementation
> parent `.14.2`. It adds no replacement backend surface and does not promote the combined final `.14.8` row.
>
> Behavior-free transaction audit `.14.3.0` proves every backend still has rule-label mark buckets and an
> execution-context cursor-only compatibility stack. Child match and anonymous-boundary registers are already
> framed, but recursive same-label marks, opaque token ownership/generation, a closed ActionIR effect classifier,
> and structured repetition/recursion progress failures are not. Do not rename `save_cursor`/`restore_cursor` or
> treat those compatibility controls as transaction support. The accepted transaction forms are `recognition_checkpoint()`,
> `recognize_once(token, call(Rule))`, `recognition_commit(token)`, and `recognition_rollback(token)`. The attempt
> returns a match boolean; commit separately exposes the staged payload. The neutral authority is now executable
> and fail-closed over 134 current + four dedicated node rows, 250 call rows, and 58 mutations.
> Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT transaction support is current and canonically admitted.
> Public no-drift is current and recognition rollout is 9/9 complete. Neutral proof alone is not backend support.
>
> Perl now has an admitted end-to-end implementation behind that boundary: dedicated ActionIR, recursive static
> effect validation, invocation-local cursor/boundary/marks, falsey-safe staging, typed cursor-progress failures,
> and independently loaded generated-source execution are GREEN in the exact 51-test final-path consumer. Canonical
> CI requires, syntax-checks, and executes that consumer exactly once.
>
> Rust now has an admitted documentation-hidden end-to-end integration.
> Four dedicated non-eager expression nodes survive serialized reconstruction; the recursive effect and cursor-
> progress classifiers enforce the neutral fixtures; and native, reconstructed, generated-plan, and independently
> compiled emitted-source carriers share the private invocation/cursor/boundary/mark/token authority. The ordinary
> contract passes 12 tests, including a false recognized payload, and canonical CI executes that exact target once.
> Rust's admission advanced only its own row; no later leg was promoted early.
>
> Dart now has an admitted package-private end-to-end integration. Four dedicated non-eager nodes, recursive effect
> closure, cursor-only progress, and live UTF-16 cursor/boundary/invocation-mark synchronization converge across
> native, reconstructed, generated-plan, and freshly analyzed emitted-source execution. The ordinary 10-test
> consumer preserves false payloads and compatibility cursor behavior; canonical CI executes that exact project-
> data-routed target once. Only Dart advanced in that admission; its private authority is not exported.
>
> Julia now has an admitted private end-to-end integration behind the same non-exported authority. Four dedicated non-eager
> nodes, recursive effect closure, cursor-only progress, and live UTF-8 code-unit cursor/boundary/invocation-mark
> synchronization converge across native, reconstructed, generated-plan, and independently loaded emitted-module
> execution. The Julia consumer now passes 207 assertions after freezing the promoted Lua, recurring, and public-
> no-drift rows; it is included in ordinary Julia discovery and executed once directly by
> canonical CI. That admission advanced only Julia; the private authority stays unexported.
>
> Shared Lua transaction work uses one private Lua-5.1-compatible authority and one private runtime adapter rather
> than an ABI-specific fork. Explicit authority runs pass 187 assertions per ABI. Explicit integration runs pass
> 246 per ABI across four non-eager nodes, recursive effect closure, cursor-only progress, native/reconstructed/
> generated-plan execution, and an independently loaded emitted module. The adapter synchronizes the live UTF-8-byte
> cursor, nullable anonymous boundary, and isolated same-label marks, and successful `false` survives commit.
> Both modules remain unexported. Admission `.14.3.6.3` removes the RED selector and executes the unchanged
> 246-assertion source once per ABI in ordinary discovery and once per ABI in canonical CI. Only PUC Lua and LuaJIT
> advanced in that admission.
>
> The exact six-runtime recurring proof is current. `tools/check_recognition_transaction_six_runtime.sh` runs the
> neutral checker, then Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT in that order, followed by the generated-source,
> capability, and language-coverage ledgers. Five source groups map to six runtime routes because one unchanged Lua
> source runs on both ABIs. It uses the project-data initializer and is optionally composed by canonical CI through
> `LINKEDSPEC_RUN_RECOGNITION_TRANSACTION_MATRIX=1`. Public no-drift now locks that unchanged composition:
> recognition rollout is 9/9 complete and transaction activity `.14.3` is closed.
>
> Any cursor transaction is one explicit
> recognition attempt over invocation-local cursor/boundary/marks only; it adds no search tree and cannot undo
> actions, AST/user state, output/diagnostics, registry work, or host effects. Recursive boundaries remain read-only,
> progress is portable, span-native parser dispatch grants no implicit authority, and ADR `0045` retains gap syntax/
> lifecycle ownership. The neutral contract and all six internal value/projection runtime targets are admitted.
> Existing helpers retain their public results and established scalar, byte, or code-unit mark/cursor behavior.
>
> Public authored typed values remain intentionally absent. Recursive-observation and span-native dispatch retain
> their already-complete owners, while final program-wide owner `FUTURE-PARITY-BACKLOG.14.8` now closes the combined
> recurring/public no-drift row without changing transaction behavior.
>
> Recursive-observation audit `.14.4.0` is behavior-free and now fixes the handoff boundary. Extend each backend's
> existing private monotonic recognition-invocation authority; do not add another stack or completed-history log.
> Capture entry before child `I` lifecycle/family matching, preserve the terminal child-local regex match when one
> exists, publish accepted exit only after normal accepted return, and keep `accepted` / `failed` / `aborted` /
> `rejected` distinct. Action edges carry the parent-selected match into child entry state; direct calls do not
> invent one. The child always derives seek/consume from its own family.
>
> Every non-root parent id must name a distinct earlier invocation in the same source authority. A non-progress
> guard that fires before child frame entry reserves a fresh attempted-child identity, points it at the active
> parent, records rejection, and pushes no live frame. Corrective `.14.4.0.1` has replaced the original
> `direct_nonprogress` self-parent with numeric attempted-child lineage and now rejects self-parenting, identity
> reuse, non-earlier parents, and cycles.
>
> Executable neutral `.14.4.1` selected
> `value = observe_recognition(observation, call(Child))` syntax. The target is one bare rule-local harray and the
> operand is exactly one unevaluated static call. Preserve the ordinary child payload as the expression result and
> bind a separate recursively detached nine-field observation. Use existing harray field access; do not add a
> custom public value kind or accessor family. The 33-transition neutral machine is authoritative for action-edge
> versus direct entry, terminal selected-match replacement, accepted-only exit, all four outcomes, child-owned
> seek/consume, fresh rejected-child ids, and no parse-wide history.
> Perl `.2` admits that exact private surface across live and independently loaded generated-source execution.
> It uses one dedicated `OBSERVE_RECOGNITION` node, fail-closed static target/operand policy, the existing monotonic
> invocation authority, and no history ledger. The node is a forbidden binding-write inside recognition
> transactions. Rust `.3` now admits one dedicated `ObserveRecognition` expression across native, serialized
> reconstruction, generated-plan, and independently compiled emitted source. It reuses the same invocation
> authority, converts UTF-8-byte registers only at the typed carrier boundary, preserves falsey payloads and
> child-owned cursor policy, retains no history, and is likewise a forbidden transaction binding-write. Dart `.4`
> now admits one private `ActionObserveRecognitionExpr` across native, reconstructed, generated-plan, and freshly
> analyzed emitted source. It uses the existing invocation authority, converts UTF-16 code-unit registers only at
> the typed scalar boundary, preserves falsey payloads and child-owned cursor policy, binds before propagating typed
> failure, retains no history, and is a forbidden transaction binding-write. Julia `.5` now admits one private
> `ActionObserveRecognitionExpr` across native, reconstructed, generated-plan, and independently loaded emitted-
> module execution. It reuses the same authority, projects zero-based UTF-8 code-unit registers to Unicode-scalar
> records only at the typed boundary, preserves falsey payloads and child-owned cursor policy, binds before typed
> failure propagation, retains no history, and is a forbidden transaction binding-write. Shared Lua `.6` now
> admits one Lua-5.1-compatible dedicated `observe_recognition` node across native, reconstructed, generated-plan,
> and independently loaded emitted-source execution. The same 43 assertions pass independently on PUC Lua and
> LuaJIT; zero-based UTF-8-byte registers cross the private typed source authority only at projection. Recurring
> `.7` composes the exact unchanged consumers and public closeout `.8` governs documentation plus absence. Recursive-observation public projection is current without a public facade, value, schema, semantic/MCP, CLI, or README admission.
>
> Recursive-observation recurrence is one repository-routed five-source/six-runtime proof:
> `bash tools/check_recursive_observation_six_runtime.sh`. It runs neutral; Perl, Rust, Dart, Julia, PUC Lua, and
> LuaJIT; then generated-source, capability, and language-coverage ledgers. Canonical CI exposes it behind
> `LINKEDSPEC_RUN_RECURSIVE_OBSERVATION_MATRIX=1`. Twelve topology/storage/rollout regressions promote only the
> observation row. Twenty-seven further public-projection mutations reject stale prose and premature surface
> widening without adding a rollout row, producing 9/5/114. At that boundary the combined `.14.8` row was pending;
> it is now complete at aggregate 14/0/231. Lossless-gap composition subsequently binds the unchanged 9/0/63 plus public 8/15/10/34 gap authority through
> existing `gap_span`, adds twelve drift mutations, and promotes only its row. Corrective transaction composition
> then binds the independently complete 9/9 recognition authority into `transaction_safety`, producing 11/3/152
> at that boundary without behavior or outward-surface movement. Progressive recurrence now runs
> `bash tools/check_progressive_span_dispatch_six_runtime.sh`, binds five sources to six runtime routes, and
> promoted only its typed row for 12/2/170 truth at that boundary; current aggregate truth is 14/0/231. Run
> `bash tools/check_typed_gap_composition_six_runtime.sh`; no second gap behavior owner or outward surface exists.
>
> Progressive span dispatch is private and current on Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT; recurring proof and public no-drift are complete at 9/9, while every guarded outward surface remains absent.
>
> Progressive neutral `.14.6.1` reserves
> `value = dispatch_span("expr-v1", "Expr", span)` as a dedicated fail-only private expression. Its checker passes
> 2 immutable registry entries, 2 sources/8 rebased views, 6 authority, 6 cancellation, 8 chain, 4 execution
> cases, 9 Rust + 8 Dart + 9 Julia + 9 Lua carrier paths and 10 outward guards with zero backend guards, 26
> diagnostics, 9/9 rollout, 116 contract mutations, and public governance over six documents / twelve stale
> denials / ten outward guards / sixty mutations. Perl, exact cfg-enabled Rust, Dart, Julia, PUC Lua, and LuaJIT
> are privately admitted. The exact five-source/six-route recurrence driver plus four support ledgers owns the
> corrected behavioral recurring row and retains typed `progressive_span_dispatch` at 12/2/170. The rejected
> effect owns exactly current node `PROGRESSIVE_DISPATCH_SPAN` and no call row;
> outward guards deny exposure. No path loader, public facade/schema/semantic/MCP/CLI/README surface, shared helper
> inventory, generated format, or typed rollout row moves. Lua `.14.6.6.0` runs one shared dormant Lua-5.1-
> compatible consumer on PUC Lua and LuaJIT: each passes 85 of 86 assertions and fails only because the generic
> call is not yet one exclusive `progressive_dispatch_span` node. Private authority `.14.6.6.1` now passes
> 273/273 on both hosts while remaining unexported and carrier-free. Ordinary and canonical discovery remain inert.
>
> Definitive neutral signoff passes the exact six-runtime composition and support ledgers, all eight doctrines,
> six-family containment, repository relocation, CLI 66x2, RAM 35%, and canonical Phase 0 1,031/1,031 in 714
> seconds through the exact local-CI success marker. No runtime or public admission moved.
>
> Definitive Perl-admission signoff passes the 17-test Perl route, the unchanged Rust/Dart/Julia/Lua consumers,
> generated-source/capability/language ledgers, all eight doctrines, containment/relocation, CLI 66x2, RAM 50%,
> and Phase 0 1,031/1,031 in 723 seconds. Rust `.14.4.3` signoff passes the exact six-runtime and repeated-action
> compositions, containment/relocation, CLI 66x2, RAM 46%, and Phase 0 1,031/1,031 in 744 seconds. Dart `.14.4.4`
> signoff passes the corresponding Dart 7+4 route, all eight doctrines, containment/relocation, CLI 66x2, RAM 57%,
> and Phase 0 1,031/1,031 in 752 seconds through the complete typed-source opt-in and exact local-CI marker. Julia
> `.14.4.5` then passes 30 observation assertions and the corresponding composed authorities. Shared Lua `.14.4.6`
> passes 43 observation assertions per ABI, complete ordinary/storage proof, both composed matrices,
> containment/relocation, CLI 66x2, RAM 61%, and Phase 0 1,031/1,031 in 734 seconds through exact canonical success.
> Recurrence `.14.4.7` then passes all six exact observation routes and support ledgers, all eight doctrines,
> containment/relocation, CLI 66x2, RAM 62%, and Phase 0 1,031/1,031 in 723 seconds through exact canonical success;
> no public recursive-observation surface is implied.
>
> **Repeated-action handoff:** Every backend must consume
> `linkedspec-explicit-repetition-action-result-v1`: bare `OR` is minimum-one repetition, explicit action returns
> collect per hit, lifecycle returns remain whole-rule authority, pipe remains scalar, and generated source remains
> v2. The repeated-action recurring gate is `tools/check_repeated_action_result_five_backend.sh`; its public
> rollout is closed at 8 complete / 0 pending.

> **Active Lua callable-codeblock handoff:** `FUTURE-PARITY-BACKLOG.11.8.1-.3` now preserve and invoke exact
> `{|params| body }` / `{|| body }` as the neutral inert eight-field value on PUC Lua and LuaJIT. Exact signature,
> typed deferred body, source/body text and containing Unicode-character spans survive copies, ordinary user
> functions, compiled/generated/emitted effective state, and semantic projection without execution or capture.
> Post-static bound invocation now reuses the existing scoped binder/interpreter for ordered copied arguments,
> live caller nonparameters, local results/access/chaining, exact failures, and ordered recursion. Canonical
> effective-`SpecFile` reconstruction, generated-plan execution, and byte-fresh emitted modules now reuse that
> exact state and executor on both ABIs. Only the final recurring/public leaf may admit Lua. Colon keywords are typed only for governed
> rejection; `name = value` remains positional. No closure, captured environment, second codec, or second executor
> is part of the handoff.

This chapter is the **single entry point** for anyone building a LinkedSpec backend
in a new language (Rust, Dart, Julia, Lua, etc.). It links every specification, contract,
and test artifact you need — in reading order.

## What You're Building

A LinkedSpec backend compiles `.spec` grammar files into runnable parsers. It must:

1. Expose an idiomatic native library, module, package, or crate that applications can
   call in the host process.
2. Accept `.spec` source and parser input as in-memory host-language values, then return
   structured host-language results without requiring a CLI, subprocess, temporary file,
   or serialized inter-process handoff.
3. Parse `.spec` files according to the formal grammar.
4. Parse helper/action language text into typed AST/IR nodes before lowering,
   interpretation, or code emission.
5. Preserve staged linked parsing semantics: extracted text payloads can become
   source-provenance parse jobs routed to later `.spec` parsers.
6. Compile the parsed model into runtime handlers or an equivalent executable compiled
   model through the accepted backend-neutral seams.
7. Execute with identical semantics to the Perl reference.
8. Pass direct library-level tests plus the language-neutral test corpus.

Native in-memory embedding is the primary completion gate (ADR 0022). A backend CLI is a
secondary thin adapter over the same parser/compiler/runtime library and may not own
exclusive `.spec` or runtime semantics. Named/file-oriented convenience APIs are welcome,
but they cannot be the only complete data path. Interpreter versus generated-source
execution remains a backend choice and does not change this embedding requirement.
Distinct backend executable names must nevertheless expose one identical user-facing CLI
contract under ADR 0023: the same command structure, option names and meanings, positional
arguments, outputs/errors, and exit semantics.

### Exact Cross-Backend CLI Contract

The executable token identifies the backend. It is the only intended user-interface difference.
Host-language launch syntax may also differ in a source checkout, but the argument vector after
the executable is identical:

```text
<variant-command> --spec NAME --input TEXT [options]
<variant-command> --spec-file PATH --input-file PATH [options]
<variant-command> --inline-spec TEXT --input TEXT [options]
```

Source selection requires exactly one of `--spec`, `--spec-file`, or `--inline-spec`. Input
selection requires exactly one of `--input` or `--input-file`. Every primary command exposes
the same optional controls:

- `--top-rule NAME`
- `--trace LEVEL`
- `--trace-file PATH`
- `--trace-mode stdout|route|mirror`
- `--trace-reset`
- `--trace-emoji`
- `--help` / `-h`

The retired `--parse-mode` flag is recognized only as a usage error: exit `2`
with `--parse-mode has been removed; cursor policy is derived from each rule
(OR/default=seek, AND=consume)`. Perl, Rust, Dart, and Julia project those
shared fixture bytes. Lua ordinary runtime execution is already intrinsic, but
its CLI/help/request-trace removal remains `.9.1.7.5`.

There are no primary-CLI subcommands and no positional arguments. Corpus runners and backend
status probes are separate developer commands. Trace levels accept numeric values plus the
shared names/aliases `none`/`quiet`, `low`, `medium`/`med`, `high`, `full`, and
`debug`/`verbose`.

Help and successful parsing exit `0`; normalized spec/input/runtime failure exits `1`; usage
failure exits `2`. Successful parsing writes one canonical JSON value plus one newline to
stdout. CLI-controlled stdout, stderr, diagnostic structure, and trace routing are locked by
the same language-neutral fixtures for every backend.

Without an explicit CLI trace option, operational failures have empty stdout and exactly one
of these stderr records, each ending in one newline:

```text
linkedspec: parser compilation failed
linkedspec: input load failed
linkedspec: parser invocation failed
```

Each exits `1`. Compilation and source loading happen before deferred input-file loading, so
an invalid spec wins over a simultaneously missing input. Backend owner names, host paths,
OS error wording, exception source locations, and ambient backend-specific trace environment
variables are not part of the shared primary-command output.

ADR `0024` separates portable primary trace from rich native trace. Primary records
are deterministic UTF-8 lines shaped as `[linkedspec][LEVEL] EVENT`: low records
compile/input/invoke start and outcome, medium adds request controls, high adds byte
counts, full adds JSON byte length, and debug adds protocol version. `none`/`quiet`
are silent. Stdout/route/mirror, selected-file defaults, reset/persistence, emoji,
UTF-8 byte counts, percent-escaped user fields, and traced failures are exact shared
behavior. Native in-memory APIs retain their
backend-internal scope/decision/mark/dump streams.

The Rust rollout audit found that its libraries already owned full-source parsing, validation, compilation,
structured execution, and rich native tracing. `linkedspec-rust` now exists. Direct-result execution and optional
entry selection are library capabilities—not CLI-only mutations—so native callers retain the same observable
operation while cursor policy stays intrinsic to each entered rule:

```rust
use linkedspec_runtime::engine::{Engine, ExecutionOptions};

let options = ExecutionOptions::new().with_entry_rule("Alternate");
let value = engine.execute_value(input, &options)?;
```

`execute_value` returns the selected rule value directly and does not mutate the compiled spec. Its traced variants
accept the same options. The older `Engine::execute` remains compatible with existing Rust callers and returns the
engine accumulator wrapper; primary commands use `execute_value` and never guess by unwrapping arbitrary arrays.

ADR `0025` makes this a strict UTF-8 text command. Argument values, source, input,
canonical JSON, help/errors, and trace are Unicode scalar text encoded once as UTF-8.
Valid text is preserved without normalization, BOM removal, newline conversion, or
trimming. Invalid spec-file bytes produce the stable compilation failure; invalid
input-file bytes produce the stable input-load failure. Invalid-byte OS argv is
outside the portable text interface, and arbitrary binary parsing would require a
future explicit byte-stream contract. Perl implementation is exact through `.1.5.1.6.2`: strict argv/file
decoding, preserved BOM/code points/newlines, recursive canonical JSON, stable invalid-file phases, and exact
trace byte counts pass 61 shared cases. `.6.3` closes final reference no-drift; Rust `.1.5.2.4` combines its
exact boundary, historically reusable entry/mode/direct-result execution, and canonical trace projection to pass all 61
unchanged cases in default/POSIX environments and adds recurring local verification. The Rust primary-command
milestone is closed; Dart and Julia now also pass all 61 default/POSIX cases. `.1.5.4.3` owns recurring warmed
four-command integration and closed the original exact CLI lane; `LUA-BACKEND-PARITY.7.2` has since extended the
same driver to Lua and 5x2x61.

### Call-name coverage versus executable parity

The capability audit now derives the same 250 current ActionIR call names from Dart, Julia, and Lua. Every name
appears in this book and in the governed occurrence sources: the 105-fixture neutral corpus, the exact
complete-named-mark fixture, and the public gap-contract example. The strict checker independently derives 126
public identifier-shaped calls from the Perl ActionIR contract registry, requires every one in each backend
inventory, and currently rejects fifteen classified names: nine compatibility/legacy/internal contracts, five
grammar-owned recognition intrinsics, and private cross-backend progressive `dispatch_span`; all lower to
dedicated nodes rather than shared helper calls. The progressive exclusion remains because the intrinsic is
private even though exact shared-backend recurrence is current. Dart's,
Julia's, and Lua's separately rolled-out seven
source-boundary compatibility aliases are checked with their canonical targets against the neutral typed-source contract; they do
not silently widen the shared 250-name inventory. Lua executes the mappings through one shared runtime on PUC Lua
and LuaJIT across native, loaded, reconstructed, generated-plan, and emitted carriers. This supersedes two
historical blind spots: aligned lists first omitted
`mark_capture_slice(...)` and `start_capture_slice_from(...)` at 237 names, then all inventories omitted seven
documented complete-mark helpers at 239 names because the old reverse check began with corpus occurrences.

Vocabulary identity remains necessary but insufficient. A diagnostic 105-case run originally found Rust, Dart,
and Julia at 100/105 despite recognizing the provisional vocabulary. The backend repair leaves aligned exhaustive
pure values, empty-local-match positions, marker control, and anonymous/named capture marks. Final admission now
checks in all six governed sources from `capability_conformance/fixtures/`; Perl regenerates their exact values,
and Perl, Rust, Dart, and Julia all pass the complete 105/105 manifest unchanged. The named marks are rule-local,
host-safe internal offsets project public Unicode-character positions/lengths, and non-repeated `AND` blind-call
wrappers preserve ordered child-return values unless an explicit parent return overrides them.
All three runtimes preserve the crucial distinction between no local match and a present zero-width match at
offset zero.

For example, this portable action-edge grammar deliberately constructs object keys out of
order:

```text
Top::
 /x/ -> Done { return(hash("z", 0, "a", hash("d", 4, "b", 2))) }

Done::
 /x/
```

Given input `x`, every conforming primary command must write these exact bytes, including the
single line ending:

```text
{"a":{"b":2,"d":4},"z":0}
```

The neutral suite also returns an input file ending in `x` plus a newline through
`input_text()`. Its JSON bytes are `"x\n"` followed by the one record newline, which proves
file loading does not trim content and output framing does not add a second newline.

This contract now passes on every implemented executable through the recurring 5x2x61 matrix. The historical
gap census found implicit Perl option aliases and trace leakage, no Rust primary binary, a corpus-oriented Dart
primary, and Julia-local help/error/trace differences; the `.1.5.1` through `.1.5.4` repair lanes closed those
gaps without backend-specific fixture expectations. Julia's repair was split under
`JULIA-BACKEND-PARITY.7.3.2`; `.7.3.2.1` closes compile/parser/
    function-shell/staged trace coverage, `.7.3.2.2` closes exact argument/source/input handling, `.7.3.2.3`
    closes execution/direct canonical JSON, `.7.3.2.4` closes errors/exits/trace routing, and `.7.3.2.5` closes
    nine-family direct-command conformance. `.7.3.3` closes the local audit without claiming global identity.
    Global `.1.5.1.5` closed 53 exact Perl cases: two help, 20 usage, seven success, four operational failure, and
    20 trace families in default/POSIX environments. A signoff probe then exposed UTF-8 argv/JSON mojibake;
    `.1.5.1.6.2` fixes the adapter and adds eight exact Unicode/invalid families, bringing Perl to 61/61. `.6.3`
    closes final reference no-drift; Rust `.1.5.2.4` combines reusable direct-result/entry/mode execution with
canonical trace, passes 61/61 in both environments, and adds `tools/run_rust_local.sh`.
    Dart and Julia close their corresponding focused legs, and `tools/run_primary_cli_matrix.sh` is the global
    recurring identity owner. Complete capability census `.1.6` and generated-source `.3` remain separate.

ADRs `0049`/`0050` and `FUTURE-PARITY-BACKLOG.10.2` make deep semantic introspection executable before backend
admission. `linkedspec-semantic-model-v1` / `linkedspec-semantic-query-v1` define an immutable normalized native
index for rules, regex slots, edges, lifecycle, calls, shapes, staged/generated provenance, portable diagnostics,
runtime observations, and explanations. Snapshot-local ids/order, bounded pages/cost, structural source privacy,
and exact fixtures are mandatory. Descriptors remain a separate compatibility projection; AST/IR, callables,
compiled regexes, object identities, implicit paths, and generated implementation source cannot enter responses.
MCP is handle-only transport and cannot compile, read paths, derive facts, or own explanations. ADR `0054`
requires one exact contract implemented natively in Perl, Rust, Dart, Julia, and Lua, with the same Lua source
admitted on both PUC Lua and LuaJIT. ADR `0055` pins modern MCP `2026-07-28` over stdio: per-request metadata,
mandatory `server/discover`, explicit opaque handles, no legacy initialization/session/ping, and exact
cancellation/error/policy/canonical/shutdown rules. Any later one-endpoint aggregator or legacy adapter is outside
`.10.9`, separately task-tree-owned, and routing/compatibility-only.

Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT now provide the complete native semantic stack and exact twelve-role
admission. Current governance is exact at six fixture groups, 20 query digests, and 128 rejected mutations;
semantic public rollout 9/9 and native admission 6/6 are complete. The five native MCP implementations serve Perl,
Rust, Dart, Julia, and shared Lua, with six runtime admissions. MCP protocol policy `.10.9.1.0`, shared machine artifacts
`.10.9.1.1`, independent 68-mutation validation `.10.9.1.2`, and ordered canonical composition `.10.9.1.3` are
complete. ADR `0057` and behavior-free Perl `.10.9.2.0` freeze a direct `LinkedSpec::MCPServer`, generated
filesystem-free contract binding, strict duplicate-safe JSON wire, OS CSPRNG/monotonic expiry, opaque host
authorization, lowering-only policy, and `.1-.4` implementation/admission split. Perl `.10.9.2.1` implements the
generated binding, private schema runtime, secure registry, and exact decoded dispatch with canonical signoff.
Strict stdio/lifecycle `.10.9.2.2` now implements bounded duplicate-safe input, canonical LF output, cancellation
through flush, sanitized logging, and EOF/I/O cleanup. Exact Perl admission `.10.9.2.3` now adds one twelve-role
consumer and a separate status/proof ledger at 1/5 implementations + 1/6 runtimes, shared rollout pending, and 28
rejected mutations; focused and canonical proof are green. No-change Perl closeout `.10.9.2.4` is complete from
clean `28f84826`; focused and canonical committed-owner recomposition close parent `.10.9.2`, and remaining
native/runtime admission `.10.9.5-.7` follows after the clean Dart boundary. Dart behavior-free audit
`.10.9.4.0` and ADR `0059` now freeze its exact generated/server/wire/security/admission seams without changing
the 2/5 + 2/6 ledger. Dart `.10.9.4.1` implements its generated binding/runtime and secure decoded server;
`.10.9.4.2` implements bounded duplicate-safe canonical stdio, cancellation through flush, fixed optional
diagnostics, and EOF/I/O release over caller-owned streams. Exact admission `.10.9.4.3` now composes one ordered
twelve-role public consumer, advances only Dart to 3/5 implementations + 3/6 runtimes, keeps rollout pending,
and rejects 58 mutations. No-change closeout `.4` recomposes every committed neutral, Perl, Rust, and Dart owner
unchanged, closes the Dart parent without status movement, and makes Julia `.10.9.5` next.

Rust preflight `.10.9.3.0` and ADR `0058` made the handoff exact. Public in-process
`linkedspec-runtime::McpServer` retains caller-created `Arc<SemanticIndex>` values and
calls only `capabilities()` and `query_neutral()`. Shared verified-bundle construction feeds the byte-identical
Perl generator and formatter-stable filesystem-free Rust binding. Direct locked OS entropy, server-local monotonic
time, SHA-256 authorization digests, lowering-only policy, canonical `Value` payloads, and unwind sanitation are
implemented and publicly corpus-tested. Strict borrowed-stream stdio `.10.9.3.2` supplies bounded duplicate-safe
framing, canonical output, cancellation through flush, and EOF/I/O release. Exact admission `.10.9.3.3` composes
one twelve-role external consumer and advances only Rust to 2/5 implementations + 2/6 runtimes, with rollout
pending and 39 rejected mutations. No MCP mode was added to `linkedspec-rust`; there is no new executable, source
bootstrap, SDK/async/network stack, semantic cache, aggregator, or legacy adapter. No-change closeout `.10.9.3.4`
recomposes the committed owners under focused and canonical proof and closes parent `.10.9.3`. Dart planning
`.10.9.4.0` consumes that clean handoff, and `.10.9.4.1` now implements the generated 82,875-byte private part,
frozen runtime, same-process server around caller-owned `SemanticIndex`, core secure entropy/monotonic expiry,
digest authorization, lowering-only policy, decoded dispatch, and authority fences. `.10.9.4.2` now implements
strict duplicate-safe/canonical stdio, cancellation through flush, fixed optional diagnostics, and EOF/I/O release
over caller-owned streams. Exact admission `.10.9.4.3` composes one ordered twelve-role public consumer and moves
the formal ledger to 3/5 implementations + 3/6 runtimes with rollout pending and 58 rejected mutations.
No-change closeout `.10.9.4.4` recomposes every committed neutral, Perl, Rust, and Dart owner unchanged, preserves
the same ledger and all 58 mutations, closes parent `.10.9.4`, and hands the exact contract to Julia `.10.9.5`.
Behavior-free Julia `.10.9.5.0` and ADR `0060` now freeze a generated Base64 contract module, private frozen
runtime, synchronous native `McpServer`, strict UTF-8/duplicate/number-kind-preserving wire, exact Julia
admission, and no-change closeout under `.1-.4`. Julia's existing `semantic_capabilities`,
`semantic_query_neutral`, and `to_json` remain the sole semantic authority. OS-backed `RandomDevice`, monotonic
`time_ns`, Base64, SHA-256, and borrowed `IO` satisfy the server without a third-party package, SDK, executable,
or primary-CLI mode. Decoded implementation `.10.9.5.1` now ships the 119,538-byte generated binding, frozen
runtime, secure opaque registry, lower-only policy, public decoded dispatch, and 48 + 139 focused assertions.
Strict byte/framing/lifecycle implementation `.10.9.5.2` now ships bounded duplicate-safe number-kind-preserving
stdio, canonical LF, cancellation through flush, fixed optional diagnostics, and EOF/I/O release over caller-owned
streams at 170 further assertions. Exact admission `.10.9.5.3` composes one ordered twelve-role external consumer
at 178 assertions, advances only Julia to 4/5 implementations + 4/6 runtimes, leaves shared rollout pending, and
raises omission-sensitive governance to 79 rejected mutations. No-change `.10.9.5.4` recomposes every committed
owner unchanged, closes parent `.10.9.5`, and hands the exact contract to shared Lua planning `.10.9.6.0`.

The Lua handoff is complete through `.10.9.6.1-.4` under ADR `0061`. It reuses only protected Lua
`SemanticIndex` values, `capabilities()`, `query_neutral()`, strict `linkedspec.json`, pure-Lua SHA-256, and the
existing managed dual-ABI builder. The implemented generator embeds the 82,543-byte canonical bundle as a
delimiter-safe long-bracket literal; the protected server owns secure handles and lower-only decoded dispatch;
and one two-function C99 entropy/monotonic-time module is compiled for each ABI. Strict `.2` scans number tokens
before decoding and reads borrowed interactive streams one byte at a time under the 1 MiB bound. One exact source
and consumer serve PUC Lua and LuaJIT. Do not add `/dev/urandom`, `math.random`, wall-clock, LuaRocks,
MCP SDK, network/
async transport, executable, source bootstrap, semantic cache, ABI-specific source, or a second server. Formal
status is 5/5 implementations + 6/6 runtimes with 114 rejected mutations; no-change `.4` closes parent
`.10.9.6`, and recurring rollout remains `.10.9.7`.

For a Dart implementation, reuse staged `SpecFile`/function sidecars, `CompiledSpec`, `UserFunctionRegistry`,
typed ActionIR resolution, `SpecPortableDiagnostic`, strict loaded source text, `buildGeneratedRulePlan`, and the
runtime's post-match slot/final-result seams. Do not serialize AST JSON or derive semantics from descriptor layout.
Ordinary Dart rule/body nodes are line-oriented and loaded state includes a host path, so a new opaque constructor
must copy caller source and logical identity and own exact byte/scalar correlation. Runtime observation must be a
typed invocation-local channel distinct from trace and diagnostic output.

Dart now implements that private construction through exact static and call/staged/generated projection. Calls
deep-equal the complete 22-record / 25-relation target: native function sidecars remain distinct payload, parse-job,
and result records with causal directions, while the validated selected generated-v2 row remains a separate
generated handler-plan record. The adapter emits no implementation source and executes no target. Immutable query,
typed runtime observation, and one composed admission consumer remain independent layers. Documentation-
only `.10.5.3.3` has recomposed 22 exact calls/static/foundation tests and closed this projection boundary;
query audit `.10.5.4.0` now makes that boundary executable as a plan. The evaluator must receive a fresh detached
clone containing only snapshot, source references, canonical records, and canonical relations. Typed record/source
kernel `.1` now implements immutable package-private capabilities/list/get/explain/source privacy at nine exact
static response digests. Traversal/limits `.2` completes canonical directional breadth-first relations, pages,
logical budgets/costs, deterministic prefixes, and all 16 successful static digests. Public `.3` now exports
`capabilities`, typed `query`, raw-neutral `queryNeutral`, and the immutable protocol types through that same
projection-only evaluator. All 19 static digests and 26 neutral validation boundaries are exact; closeout `.4`
now composition-closes the query parent on committed code. Runtime audit `.10.5.5.0` fixes existing post-match
slot selection and successful final-result construction as the only observation authorities. It also freezes zero
absent-sink work, exact observer exception passthrough through generated wrappers, immutable derivation only from
static graph evidence, and the `.1-.4` order. Typed direct-engine capture `.1`, immutable topology-validated
runtime projection `.2`, and generated/emitted direct/traced propagation `.3` are complete; composition closeout
`.4` closes the parent on committed code without promotion, and exact admission `.10.5.6` is complete.

Capture `.10.5.5.1` now exports the v1 contract, immutable slot/result event values, and optional synchronous sink.
Direct, loaded, reconstructed, traced convenience, and validated generated-plan engine routes emit exact Unicode-
scalar positions and final UTF-8 input identity while preserving result/cursor/trace/diagnostic values and caller
failure identity. Null guards precede event allocation and input hashing. Public generated/emitted direct and
traced wrappers now accept the optional sink and restore exact caller callback identity before generic generated
error translation. Observed/unobserved results and diagnostics agree, routed trace bytes agree, immediate exit
omits the final result, and generated-source v2/format 2 is unchanged. Derivation `.10.5.5.2` validates retained
events against detached static rule/slot/selection
topology, creates a separate immutable canonical execution/event/`observed_as` snapshot, preserves the base, and
matches the twentieth digest through typed and raw-neutral query. Generated/emitted propagation `.3`, composition
closeout `.4`, and exact 12-role admission `.10.5.6` are complete.

Julia now has its pinned Unicode-17 prerequisite, composition-closed opaque source/compiled-or-failed foundation,
all five private static targets, calls/staging/generated provenance, and complete immutable typed/raw-neutral
query. `semantic_index` copies valid text or strict UTF-8 bytes, owns exact byte/scalar coordinates and four source
ceilings, retains compiler authority privately, and queries exactly one fresh detached projection. All 19 static
response hashes and 26 malformed-request boundaries are exact at focused 1,063 and complete Julia
8,605/primary/105.

Behavior-free `.10.6.6.0` freezes the remaining runtime-observation topology. Slot capture belongs after accepted
match/ordered identity and before effects, using the match end rather than the still-old context cursor; final
capture belongs after `RuntimeParseResult` construction. Direct, loaded, reconstructed, generated-plan, emitted,
and traced routes converge there. Trace/diagnostics remain separate; absent sink means no event allocation or input
hash; generated broad catches need exact callback-identity passthrough; immutable derivation uses only detached
static topology and shapes. Typed capture `.1`, derivation `.2`, generated/emitted propagation `.3`, and closeout
`.4` precede admission `.7`, so Julia still does not advance the 4/9 rollout or 3/6 native-admission ledger.

Typed engine capture `.10.6.6.1` is now complete. Julia exports the immutable v1 slot/result event vocabulary and
supports `semantic_observation_sink` on native parse/execute, traced convenience, loaded/reconstructed engines,
and validated generated-plan direct/traced helpers. Exact Unicode-scalar positions, final UTF-8 input identity,
zero absent-sink allocation/hash work, synchronous exact callback failure identity, failure omission, and result/
trace/diagnostic non-interference pass at new 66/focused 1,129 and complete Julia 8,671/primary/105. Backend work
must keep fresh emitted public wrapper propagation in `.3`; generated-source v2/format 2 and the 4/9 rollout / 3/6
admission ledgers do not move in `.1`.

Immutable observed-index derivation `.10.6.6.2` is now complete. Public `with_execution_observation` validates only
exact typed events and the base index's detached static rule/edge/slot/`selects_regex` evidence, derives all source
and shape facts from that projection, and returns a fresh `has_execution=true` index while leaving the base static.
It matches the twentieth typed/raw-neutral digest at new 157/focused 1,286 and complete Julia 8,828/primary/105.
Malformed, foreign, reordered, duplicate-final, wrong-entry, and unsupported-slot observations reject through the
portable invalid-observation boundary. No ledger or generated-format state moves in `.2`.

Generated/emitted propagation `.10.6.6.3` is now complete. Fresh Julia module `execute` and `execute_with_trace`
wrappers accept the same optional `semantic_observation_sink` and forward it to the validated generated-plan
helpers. Public-helper, freshly included, and isolated-host proof locks canonical events/twentieth digest, exact
callback object identity, exit final-result omission, and result/diagnostic/trace non-interference. The route suite
adds 51 assertions; all twelve semantic suites compose at 1,337 and complete Julia reaches 8,879/primary/105.
Generated-source identity remains v2/format 2 with the unchanged `{label, family}` plan. Backend implementations
must treat observer propagation as a runtime adapter, not a serialized plan field or a second event owner. Full
primary 5x2x66, ten Unicode legs, unchanged ledgers, canonical Rust 79.78s + Dart 1/1 + primary 66x2 + Phase 0
1,031/637s, book/KM 694/5,348, doctrines, and exact 1,749,080-KiB cleanup preserving 517 Pgen artifacts pass.

No-change closeout `.10.6.6.4` is now complete. It retrieves the four committed runtime-observation authorities
and recomposes all twelve Julia semantic suites at focused 1,337, then repeats complete Julia 8,879/primary/105,
primary 5x2x66, ten Unicode legs, unchanged ledgers, and canonical proof. Parent `.10.6.6` closes without a new
implementation owner, generated-format/runtime change, or promotion. Keep `.10.6.7` pending until one exact
12-role Julia admission consumer owns the 4/9 and 3/6 ledger movement.

Two language prerequisites precede that adapter. ADR `0051` pins labels to Unicode 17.0.0 `XID_Continue` with
exact case- and normalization-sensitive identity. Shared `.10.5.0.1` generates and guards one portable 806-range
class, consumes it at all 12 label sites in first-authoritative `specs/spec.spec`, freshness-locks all four corpus
copies, and proves current grammar on five backends. Dart `.10.5.0.2.0-.1` generates the matching native scalar
classifier/prefix scanner, routes headers plus action/blind/bare targets through it, and validates declarations and
targets from parsed, reconstructed, and programmatic ASTs. `.10.5.0.2.2` proves every positive/distinct neutral
identity through compiled maps/order, descriptors, generated plans, reconstruction, isolated emitted execution,
selectors, diagnostics, traces, strict loaders, and primary commands. Negative/identifier isolation and composed
signoff split into `.10.5.0.2.3-.4`: `.3` now exhausts all eight invalid labels across external AST, source,
no-prefix, and primary routes and locks the narrower function/helper/lifecycle/fluent/mark grammars. Composed `.4`
passes complete Dart and canonical signoff and closes the prerequisite without advancing the then-current semantic
ledger. Source/static/calls/query/runtime/admission subsequently complete through `.10.5.6`; Julia has since
inherited and closed the same pinned-label prerequisite plus its source/outcome foundation, while Lua remains later.

Dart's current 105/105 corpus result includes four byte-identical current `specs/spec.spec` inputs. Shared
`.10.5.0.1.2` regenerated them verbatim, enforces byte/hash freshness, and composes current-grammar execution across
all five backends under both command environments.

The backend contract is implementation-language neutral. The same `.spec` source,
AST payloads, parse-job metadata, descriptors, diagnostics, and parser entry semantics
apply whether the implementation is Perl5, Raku, Rust, Julia, Lua, Dart, Zig, Go, or a
future language.

The scheduled future full-parity rollout is Dart first, Julia second, and Lua third
(ADR 0021). That order affects task-tree sequencing only; the conformance contract is
the same for every backend. Lua and any later backend must define its native module API
before CLI productization can satisfy its backend plan.

Text-to-AST is a backend conformance rule, not an optional implementation style.
Do not build a backend by applying textual helper rewrites directly into host-language
source. The Perl reference now has an additive `LinkedSpec::ActionIR::AST` parser seam
for calls, literals, variables, direct access, shape literals, block values,
assignments, expression statements, and receiver-dot chains. Its `MethodLowering`
consumer has started using that AST for non-call value expressions: primitive literals,
scoped bare scalar reads, direct indexed/nested access, shape literals, and block
values. It also lowers value-only helper-call composition from AST `call` nodes for
scalar normalization, string predicate/composition, coalesce/concat, and scalar-argument
numeric helpers. It also lowers retained aggregate-constructor, collection/reducer, and hash helper
calls from AST `call` nodes while preserving their existing symbol/value slot policy.
Bare typed reads are the destination surface. Exact one-identifier aggregate selectors are retired and report
`aggregate_selector_removed` on Perl, Rust, Dart, Julia, and Lua before execution.
`tools/check_aggregate_selector_retirement.py` is the canonical cross-variant guard: it requires the shared six
invalid cases, portable fields, all five compiled-state admission boundaries, eight retained constructor/literal
classes, and zero known selector-only runtime dispatch.
Julia's boundary recursively inspects typed rule ActionIR, parses valid deferred function bodies and fluent calls,
and repeats validation for generated emission and plan execution, so unused or caller-constructed state cannot
bypass rejection. Selector-specific Julia runtime dispatch is gone.
Lua likewise inspects typed and valid deferred compiled state, repeats validation when a runtime engine accepts its
mutable compiled table, and has no selector-specific read, target, receiver, split, or transform dispatch.
Retired short aliases `s(...)`/`a(...)`/`h(...)` remain ordinary unresolved helpers rather than normalized.
Unsupported covered helper
forms now report unresolved-helper metadata instead of leaking as generated host-language
calls. Receiver-dot value chains now lower from AST `fluent_chain` nodes for the array,
hash, string, and number receiver families before the legacy receiver-dot text normalizers
run. Generalized return payloads now lower typed value/call/chain nodes through the same
AST traversal before raw fallback, while narrow untyped compatibility payloads still
remain migration debt. Assignment and mutation operator statements now consume typed AST
target/key/value fields before legacy fallback. Helper-call statements and returns now
consume typed AST `call` fields for `set`, `set_key`, `push`, `return`, and
`return_undef`, and array end-mutation receiver statements
consume typed AST `fluent_chain` fields. Expression-valued block side effects,
block-local returns, and final block expressions now consume typed block/statement AST
fields. Structured control-flow lowering now consumes typed AST fields for the if/when,
switch/case/default, and attached-while statement families. Standalone supported value
statements now produce canonical `VALUE_DROP` events: the backend computes the typed
value expression and intentionally discards the result. Unknown typed calls and
function-call receiver chains in return/value positions now use the unresolved-helper
diagnostic path instead of becoming generated host-language calls.
Top-level `fn name(args) { body }` definitions are now accepted and recorded in the Perl
reference descriptor registry. Each definition carries params, arity, source/body spans,
body source, and an ActionIR body AST. The registry rejects duplicate functions,
reserved names, built-in helper/control collisions, rule-label collisions, and invalid
or duplicate parameters before runtime. The Perl reference now resolves registered
exact-arity calls during value-expression lowering; wrong-arity registered calls remain
unresolved-helper diagnostics with zero raw fallback. Registered standalone calls and
receiver chains now lower as canonical `VALUE_DROP` statements on the Perl reference.
The Rust backend carries the same definitions through parsed and compiled registry
records and executes the MVP runtime surface: registered calls resolve before helper
fallback, run in fresh function-local stores, feed compatible receiver chains, and
discard standalone results.
The function surface is closed at that MVP boundary. New backends should implement
top-level `fn name(args) { ... }` with explicit parentheses and braced, value-oriented
bodies. Do not add alternate spellings (`function ... endfunction`, `fn ... endfn`),
optional zero-argument parentheses, brace-less bodies, caller-state-mutating functions,
recursive user functions, closures/lambdas/currying, or function namespaces unless a
future task-tree leaf and contract explicitly adopt them.

Staged linked parsing is also a backend conformance rule. A backend must be able to
represent an AST node that contains extracted text and a parse intent, then dispatch that
payload to a deterministic next parser while preserving source spans and parent-node
context. One stage can emit several different parse-job kinds; each kind may route to a
different next-stage `.spec`. This is different from spec imports: imports compose grammar
files, while staged dispatch parses runtime payload text already extracted by a parser.
For `.spec` language evolution, `specs/spec.spec` is the first authoritative grammar and
later `.spec` stages derive from its parsed payloads rather than a competing permanent
bootstrap grammar.

The accepted parse-job annotation design is `parse_job(text_expr, options)` once
implemented. It yields a marker value plus sidecar metadata: deterministic job id, parent
AST path, node kind, payload kind, exact text, source span, parser spec id, optional top
rule, result policy, and failure policy. Result policies are `replace_marker`,
`replace_field`, `sibling_field`, and `append_child`; failure policies are `fail`,
`keep_text`, and `diagnostic_node`. Backends must treat this as a neutral metadata
contract, not a host-language callback surface. Current shipped parsers do not yet accept
or execute `parse_job(...)`.

The accepted staged dispatch design is also neutral. Implement a registry with
`resolve`, `load`, `compile`, and `execute` operations. Resolution order is parent
import aliases/composed identities, declaring-spec-relative paths, configured search
roots, then explicit registry providers. Cache compiled parsers by normalized spec
identity, content digest, import/include graph fingerprint, selected top rule, `.spec`
language version, helper/action contract version, staged parsing contract version, and
backend capability set. Dispatch jobs in stable parent-AST-path/source-span/job-id order,
and diagnose active-chain cycles that repeat spec identity, top rule, payload digest, and
source span. Current shipped parsers implement only the first narrow function-body
provider; general staged registry/provider search and recursive dispatch queues remain
future work.

The first prototype target is user-function body payloads. A backend should treat that
as a narrow proof of the neutral staged contract: `specs/spec.spec` extracts a bounded
body payload, a parse job names the next parser/top rule, source provenance is preserved,
and the refined body AST is stitched back deterministically. Do not copy a Perl or Rust
bridge as the semantic model; host implementation details are adapters around the
`.spec`/AST contract.

The proof must include an AST-shape oracle for the returned function-definition node.
Runtime equality alone is not enough: a backend must be able to predict and then assert
the `function_definition` AST shape, including the refined body payload and provenance
fields that staged dispatch is responsible for. That oracle should be fed by a large
variation suite for the spec rule returning the AST: whitespace forms, arity forms,
nested blocks, quoted strings, regex-looking payloads, adjacency to rules or other
definitions, and invalid definitions with expected diagnostics. Use a dedicated small
spec file/top rule for those focused AST-shape tests when that gives a tighter harness.

For backend implementers, the expected harness is a wrapper top rule that dispatches to
a normal `function_definition` rule and returns collected nodes. The function rule must
not rely on compacted numbered captures for optional fields. The neutral returned node
uses parsed parameter arrays, exact inner body text, neutral source/body spans, a
function-body parse-job field, and a stitched body AST after dispatch.

The current provenance seam is the neutral `body_payload` plus `body_parse_job` returned
by `specs/user_function_definition.spec`. Neither field is a backend callback.
`body_payload` contains exact function-body text,
half-open source span, source-slice provenance, source-order parent path, function name,
params, arity, `node_kind = function_definition`, and `payload_kind = function_body`.
`body_parse_job` is the parse-intent sidecar for that payload: deterministic job id,
parent AST path, parser spec identity, top rule, result/failure policies, exact text,
source span, and diagnostic ownership. The Perl reference plus Rust, Dart, Julia, and Lua runtimes consume
that spec-returned AST today and normalize the source-order path/job id once the function
ordinal is known. They dispatch that job through the minimal staged parser registry:
`resolve` maps `actionir-body.spec` to a built-in provider identity, `load` records the
adapter contract digest, `compile` selects top rule `action_block`, and `execute` returns
the body `action_block` AST stitched into `body_ast`. General provider search roots,
imports, and recursive staged queues remain future work.

Audit `.14.7.0` sharpens this boundary. Calling the raw registry with another
`result_policy` or `failure_policy` proves only that the record transports that string;
the current function-specific validator/stitch path is the owner that implements and
enforces `replace_field` / `body_ast` / `fail`. The current queue executes one depth and
does not rescan stitched results. Corrective `.14.7.1` makes every wrong-top compile
diagnostic retain the original job id/path/parser/top/payload/span/failure context plus
the resolved built-in identity across Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT.
Backend implementation must consume the neutral `.14.7.2` oracle, not extend these
narrow adapters independently.

That oracle is now executable. ADR `0088`, `capability_conformance/staged_ast_enrichment_contract.json`, and the
[Staged AST Enrichment Contract](../compiler/staged-ast-enrichment.md) require pre-resolved/precompiled immutable
authority, typed direct/ordered-derived provenance, deterministic v2 ids, breadth-first depth/path/provenance/id
ordering, fresh sibling contexts, all four result and three failure policies, decreasing provenance chains,
shared cancellation/resources, detached results, 37 portable diagnostics, explicit v1 compatibility, and four
fresh-authority carrier routes. Perl `.14.7.3.1-.4` now provide and privately admit the complete backend boundary:
exact literal-option assignment annotations become one exclusive opaque marker with detached direct/ordered-
derived typed provenance; one unexported authority accepts caller-frozen candidate outcomes and already-compiled
callbacks, then performs pure resolution/cache, deterministic identity, isolated one-depth execution, every
result/failure policy, detached stitching, breadth-first recurrence, exact-text/full-provenance chains, shared
limits, callback safe points, and direct/ordered-derived source rebasing. Malformed, smuggled, residual,
recognition-reachable, ambiguous, authority-elevating, stale-target, live-result, and over-limit forms fail closed.
`LinkedSpec::StagedASTEnrichmentRuntime` constructs a fresh scheduler/cache from host-only options for each
top-level invocation and runs it only after the complete parent parse. Native, normalized-descriptor, validated generated-plan, and independently loaded
emitted routes return equal detached output while serialized carrier data contains no live authority. The
final-path oracle is 143/143 and appears once in phase-0 and once in canonical CI; only Perl rollout is promoted.
Generated-source v2, function-body v1, public inventory, and outward surfaces remain unchanged. Rust
`.14.7.4.0-.4` now supply and privately admit the corresponding complete path. The ordinary and canonical
consumer preserves current v1 and proves an exclusive
inert marker, strict literal options, exact text, typed direct/ordered-derived provenance, caller-frozen pure
resolution/cache, deterministic sibling-isolated execution, detached atomic stitching, every result/failure
policy, breadth-first next-depth scheduling, exact cycle/decrease guards, shared cancellation/resources, callback
safe points/expiry, direct/ordered-derived source rebasing, and adversarial denials. Native, reconstructed,
validated generated-plan, and independently compiled emitted execution each start from the same host-only seed but
build a fresh registry/cache and recursive authority after the complete parent result. The four results are equal
and detached; emitted logical source serializes none of the live authority. The temporary outer cfg, cfg-only
exports, check-cfg registration, and conditional dead-code allowance are gone. `TRACE-OBSERVABILITY.5.1-.4` are complete: traced progressive
validation and gap-aware child-dispatch parity are restored, while the private authority stays dormant beside the
one admitted contract route. `.5.4` historically aligned the Perl snapshot to 79 mutations plus Rust
`dormant_red`; Rust admission now advances the neutral oracle to 84 mutations and promotes only Rust. Dart and
Julia have since reached the same private admission boundary. Lua `.14.7.7.0-.4` now own one shared stable admitted
consumer, its marker/provenance carrier, caller-frozen current-depth resolver/cache/policy engine, bounded
breadth-first recurrence, source rebasing, and a fresh host-only seed across four production routes. PUC Lua and
LuaJIT each pass 888 assertions; ordinary/canonical discovery executes that source exactly once per ABI and both
rollout legs are complete. Independent `.5` recomposes every committed route unchanged and closes shared Lua;
recurring five-source/six-route proof `.14.7.8` and public authoring/no-drift `.14.7.9` are now complete.
Dart
`.14.7.5.0-.4` freeze one exact historical `test_dormant/` boundary, lower exact
assignment-form `parse_job` to a live-proven private marker, and add a separate caller-frozen pure resolver/cache/
recursive policy engine. It selects default top before identity, caches plans only, prepares complete depths,
reserves cross-plan targets, isolates sibling state, detaches results, implements all policies, queues returned
markers breadth-first, enforces strict lineage/shared resources, expires safe points, and rebases direct/derived
source locations. A host-only seed starts fresh registry/cache/recursive authority after the parent AST through
native, reconstructed, generated-plan, and independently executed emitted routes. The final-path consumer passes
19/19 in ordinary/canonical admission. Julia `.14.7.6.0-.4` preserves the unchanged function-body-v1 path while
lowering only exact scalar assignment-form `parse_job` to an inert dedicated node. Native Julia capture offsets
feed the typed source authority directly, so Unicode-scalar direct/ordered-derived provenance requires no copied-
text search; four logical routes return the same detached marker. A separate tuple-frozen caller-prepared registry
then performs pure selected-top-before-id resolution, plan-only caching, complete-depth target reservation and
typed order, sibling isolation, detachment, and every result/failure policy. A separate recursive path now performs
complete breadth-first depths with exact lineage, non-resetting bounds, expiring safe points, and source projection.
An opaque host-only seed starts a fresh registry/cache/recursive authority for every native, reconstructed,
generated-plan, and independently included emitted execution, then enriches only after the complete parent value.
The explicit consumer is 491/491 and admitted once in ordinary/canonical topology. Governance is 106 mutations
after shared Lua admission. Lua `.14.7.7.1` lowers only exact scalar assignment-form `parse_job` to an
inert detached marker and converts private native capture ranges through typed source authority without copied-
text search. `.14.7.7.2` adds pure pre-registered resolution, selected-top-before-id identity, plan-only caching,
complete-depth target reservation and typed order, fresh sibling contexts, detached unpublished-copy stitching,
all four result plus three failure policies, and live/target/conflict denials without widening function-body v1.
`.14.7.7.3` adds complete breadth-first depths, exact cycle/decrease lineage, non-resetting cancellation/deadline/
steps/calls/depth/result/diagnostic bounds, expiring callback safe points, and direct/ordered-derived source
projection. `StagedAstEnrichmentSeed` starts fresh callback/registry/cache/recursive authority only after the
parent AST completes through native, reconstructed, generated-plan, and independently loaded emitted routes.
Generated format and public behavior remain unchanged; `.14.7.7.4` admits the unchanged 888/888 source once per
ABI and completes both rollout rows. Independent `.5` reruns both ABIs, all admitted peers, exact topology, and
106-mutation governance without executable movement before parent closure.
Mandatory engineering-notes segment `4989` is finitely authorized at 19 files / 18
manifest lines by ADR `0092`. Lua current-depth closeout's mandatory change-history segment `4989` is finitely
authorized at 24 files / 23 manifest lines by ADR `0093`; no other pressure ceiling changes.

Progressive dispatch is a separate synchronous path under `FUTURE-PARITY-BACKLOG.14.6`. Audit `.14.6.0` proves
that none of these registries can invoke a normal loaded spec while a parser is active. The portable design uses
an immutable host-seeded entry for an already compiled logical parser identity and one contiguous typed source
span. Child registers are bounded-view-local while typed coordinates rebase to the original source; parent state
is isolated; capabilities intersect; policy/resource/source-detail ceilings only narrow; cancellation propagates;
and repeated parser/top/source dispatch must strictly shrink the span. Never route an authored parser id to the
filesystem. Derived text, deterministic parse-job queues, and AST stitching remain staged `.14.7` work.

Perl `.14.6.2.1-.3` provide the current admitted private reference seam. One exclusive ActionIR contract claims the whole
reserved assignment, static policy validates its two literals and bare span, and each wrapper constructs a fresh
invocation from a host-only option. Live, reconstructed descriptor, validated generated-plan, and independently
loaded generated-v2 packages agree; emitted source preserves logical operands only. Recognition transactions
reject the effect. Canonical CI runs the exact green consumer once, but no public surface is admitted.

Rust `.14.6.3.0` historically froze the corresponding final-path boundary at one missing dedicated node. Its exact
outer-cfg consumer and four-route identity remain the continuity proof.

Rust `.14.6.3.1` now supplies only the underlying private authority. A doc-hidden module owns immutable logical
entries with already compiled callbacks, fresh invocation state, typed same-source bounded views, global scalar/
line/column/UTF-8 rebasing, intersected grants and ceiling minima, shared cancellation/deadline/steps, decreasing
span/depth/call guards, callback containment, expiring views, and detached node-bounded JSON results. Its separate
outer-cfg consumer proves the neutral matrix and all diagnostics but runs zero tests ordinarily and has no
canonical route. Rust `.14.6.3.2` now adds one exclusive logical-only node and delegates native, reconstructed,
generated-plan, and independently compiled emitted-source execution to a fresh host seed. Static recognition
effect closure plus a live-token runtime check forbid dispatch in uncommitted attempts; generated data contains no
callback or authority. Rust `.14.6.3.3` canonically routes that same cfg-enabled consumer once and promotes only
Rust, while ordinary discovery remains zero tests.

Dart `.14.6.4.0` froze the corresponding final-path boundary under the historical dormant path;
`.14.6.4.2` preserves that identity and fixture
while turning it GREEN through one exclusive `ActionProgressiveDispatchSpanExpr`. Exact malformed operands,
residual generic calls, recognition-effect composition, and live transactions fail closed.

Dart `.14.6.4.1` now provides `lib/src/runtime/bounded_child_parse_authority.dart` without exporting or carrying
it. The module owns immutable logical entries with already-compiled callbacks; fresh invocation-local source,
cancellation, deadline, budget, chain, depth, and call authority; typed bounded views over the existing
`SourceAuthority`; narrowing grants/ceilings; and deeply detached node-bounded results. Callbacks receive no live
invocation object. Legitimate nesting uses `request.dispatchNested(...)`, which shares invocation state only while
the source view is active; a retained request fails after callback return. The separate dormant authority consumer
passes every neutral case and all 26 diagnostics while ordinary/canonical discovery remains inert. An opaque seed
now starts fresh authority for native, reconstructed, generated-plan, and independently analyzed emitted-source
execution; generated data carries only target/parser/top/span and no callback, registry, source snapshot,
cancellation, fingerprint, or mutable state. `.14.6.4.3` moves the unchanged seven-group consumer to
`dart/test/progressive_span_dispatch_contract_test.dart`; ordinary discovery and one exact canonical route admit
it and promote only Dart to rollout 4/9/103.

Julia `.14.6.5.1` owns the corresponding unexported `BoundedChildParseAuthority`: immutable logical entries with
already-compiled callbacks, fresh invocation-local source and limits, typed globally rebased bounded views,
narrowing grants/ceilings, shared cancellation/deadline/steps, decreasing spans, callback/request expiry, and
detached node-bounded results. `.14.6.5.2` adds one exclusive `ActionProgressiveDispatchSpanExpr` plus native,
`SpecFile`-JSON reconstructed, generated-plan, and independently included emitted-module carriers through a fresh
opaque seed. Generated data carries no callback or authority. `.14.6.5.3` moves the same 62-assertion carrier to
`julia/test/progressive_span_dispatch_contract_test.jl`, includes it once in ordinary discovery, and registers one
exact canonical route. It promotes only Julia to rollout 5/9/106; the separate 210-assertion authority consumer
remains dormant and directly runnable. `.14.6.5.4` independently recomposes those owners and closes Julia.

Lua `.14.6.6.0` then freezes one dual-ABI dormant RED before any production implementation. Both Lua hosts prove
the reserved form is still a generic call and that all four carrier shapes preserve the typed unsupported-helper
failure; 85 assertions pass and the sole deliberate failure requires the missing dedicated node. Private shared
authority `.14.6.6.1` is now current as one Lua-5.1-compatible direct module. Its opaque immutable entries,
copied-source invocations, typed rebased callback views, narrowing grants/ceilings, shared cancellation and limits,
expiring requests, and detached bounded results pass 273 assertions per ABI. Carrier `.2` adds one exclusive node
and four fresh-authority routes, making the shared consumer GREEN at 178/178 per ABI while dormant. Admission `.3`
moves that same source into ordinary discovery once per ABI and one exact canonical route per ABI, promoting only
PUC Lua and LuaJIT to rollout 7/9/112. The authority proof remains dormant; recomposition `.4` follows.

The spec's body shell is a
linked opener/closer parse: `body_brace`
handles nested brace islands, quoted strings, comments, and regex literals are protected
before brace dispatch, and the outer close is matched by `function_definition[1]`.
Backends must converge on this same spec-defined AST contract instead of maintaining
host-language definition grammars as the staged dispatch queue becomes portable.

Lua's `.5.1.1` implementation lives in `lua/src/linkedspec/staged_parser_registry.lua`.
It defensively copies exact typed jobs, decorates equal sort keys with input order to make
Lua sorting stable, exposes the governed digest/cache/compiled/result records, rejects
unsupported providers and sidecar/duplicate-job drift, and rebuilds immutable function/spec
records during stitching. `parse_spec_with_staged_user_function_definition_asts(...)`
composes an explicit node batch and dispatch directly. `.5.2.2` adds
`parse_spec_with_staged_user_function_definitions(source)`, which resolves and compiles the bundled owning grammar
once and supplies that node batch automatically without a raw scanner. `.5.1.2` adds registry-first fixed-v1
execution: eager ordered caller arguments, copied fresh scalar/array/harray stores,
staged-AST integrity checks, local final/early returns, nested nonrecursive calls,
standalone value drop, returned-value receiver continuation, cleanup-safe caller
restoration, and typed arity/keyword/recursion/staging failures. `.5.1.3.1` then preserves the exact v1/v2
signature union through every native state boundary, validates sidecar identity and all seven invalid definitions,
and resolves variadic calls from the fixed-prefix minimum through an unbounded maximum. `.5.1.3.2` then copies all
evaluated frame arguments and binds extras as a fresh typed rest array; the unchanged neutral fixture, mixed/empty
identity, receiver chains, and typed failures pass. `.5.1.4.1` then preserves final-only `callback: codeblock`
metadata across every native state boundary and normalizes attached/parenthesized calls to one zero-positional
typed argument without promoting harrays. `.5.1.4.2` executes that argument against the current isolated function
frame, preserves static callable precedence, restores outer stores, returns chainable values, and reports typed
callback failures. Portable native resolution/loading `.5.2.1` then adds typed requests/options/results/errors,
deterministic direct candidate order, in-process byte reads, and strict UTF-8 preservation. PUC Lua and LuaJIT
consume the complete 14/9/4 contract. Automatic spec-defined function parsing `.5.2.2` resolves the bundled
grammar module-relatively, validates/compiles it once, executes it in process, and composes typed nodes through the
existing Unicode projector/body dispatcher without a raw scanner. Both ABIs pass 151/151 with status
`native-spec-defined-functions-v1`. Loaded-source `.5.2.3` retains exact identity/source/compiled state, maps the
three neutral source stages, and creates named/path-attributed engines at 153/153 with status
`native-spec-pipeline-v1`; no-drift `.5.2.4` closes parent `.5.2`. Planning `.5.3.0` separates exact outward
descriptor admission, one-emitter native-pipeline trace, and capability closeout. Decision `.5.3.0.1` adopts
final-codeblock descriptor v3 plus completion-time census admission; `.5.3.1` emits the exact three-variant union.
`.5.3.2` passes one caller-owned emitter across native IO, frontend/compiler/function/staged owners, engine
creation, and runtime without retained or hidden emitter state. Ordered sinks/filters/errors and result identity
pass 155/155 on both ABIs with status `native-full-pipeline-trace-v1`; `.5.3.3` closes exact no-drift and parents
`.5.3`/`.5`. Controlled/core planning `.6.1.0` measured offsets 0-39 and 99-104 at 45/46 on both ABIs. Typed
nested-path repair `.6.1.1` closes unchanged offset 20 and both windows at 46/46 with focused suites at 157/157.
Reusable executor `.6.1.2` validates before selection and retains every controlled result/failure at 160/160 per
ABI. Permanent core window `.6.1.3` then locks exact offsets 0-39 at 40/40 with endpoint 1/1 and raises both suites
to 161/161. Governed `.6.1.4` locks offsets 99-104 at 6/6 with endpoints `2,1,2,1,5,5`, raises both suites to
162/162, closes `.6.1`, and activates offsets 40-98 under `.6.2`. Planning `.6.2.0` measures that window at 50/59.
Action-edge `.6.2.1` then caches matching current-edge calls, skips passive-terminal re-search after the parent
dependency match, and preserves ordinary unrelated rule calls. Three HLink, two EBNF, and SimEnv cases pass
unchanged; both suites pass 163/163 and the window reaches 56/59. Receiver-copy `.6.2.2` then carries the one
evaluated fluent value through zero-argument `.copy()`, retains its runtime kind for later links, and closes the
hash-receiver fixture. Both suites pass 164/164 and the window reaches 57/59; flat-array hash splicing `.6.2.3` is
now complete. Direct and receiver `flat_array(...)` results splice ordered alternating tokens into `hash(...)` and
`harray(...)`, empty input yields an empty harray, and ordinary arrays remain one copied value. The unchanged
`pplugin_empty` returns `[{}]`; both ABIs reach 58/59. Public leading-trivia `.6.2.4` then moves cursor/register
state past only complete leading blank or `#` comment lines, preserves ordinary indexed reads, and closes unchanged
history. Both ABIs pass 165/165 and the window reaches 59/59. Successor remeasurement `.6.2.5` independently
validates all 105 fixtures, selects exact offsets 40-98, and confirms stable first/last order plus 59 passes and
zero failures on both ABIs. Permanent `.6.2.6` locks all 59 literal names, unchanged wrapped outputs, matches, and
exact byte/character endpoints at 166/166 per ABI. Final `.6.3` executes the complete ordered 105-case manifest
through both the production library and separate developer runner, preserves validation-only default use, and
locks success/fixture/manifest exits 0/1/2. Both ABI suites pass 167/167 with status `runtime-corpus-full`; parent
`.6` closes. Primary parser adapter `.7.1` now implements exact ADR `0023` options, strict UTF-8, native execution,
canonical JSON, stable phases/exits, and the independent canonical phase trace at 169/169 per ABI plus diagnostic
shared CLI 61x2. Admission `.7.2` now makes both process legs recurring and extends the matrix to 5x2x61. Status is
`runtime-corpus-primary-cli`; no-drift `.7.3` closes parent `.7`. Planning `.8.1.0` corrects the pre-descriptor-v3
scaffold scope, and `.8.1.1` now emits deterministic native Lua from exact fixed-v1/variadic-v2/
final-codeblock-v3 effective state. It exposes contract/version/identity metadata, portable errors, and direct/
traced value roles with canonical strict-UTF-8 JSON rendered as ASCII hex. `.8.1.2` now persists valid/corrupt
modules and proves exact fresh-process PUC Lua/LuaJIT load, result, trace, failure, and cleanup behavior;
`.8.2` adds exact ten-family plans, four rejections, authoritative root/nested dispatch, portable generated trace,
one isolated all-family module, and emitted variadic execution at 176/176 per ABI. Contract-sourced `.8.3` proves
the exact ordered interpreter-first 8/105 modules with metadata/plans/trace identity and cleanup in fresh PUC Lua
and LuaJIT hosts at 177/177 per ABI. Sole admission `.8.4` now expands the census to five-backend 80/0/0.

Rust is interpreted rather than generated Perl source, so the inspectable artifact is
the compiled rule table plus lifecycle/action expression AST rather than emitted handler
code. The Rust adapter still follows the same contract: it executes
`specs/user_function_definition.spec`, validates the returned nodes, strips definition
spans, dispatches normalized body parse jobs through the staged registry adapter, and
only then passes rule-only source to the core parser.

Spec import/composition is a separate backend conformance target once implemented. The
accepted design uses file-scope `import "path.spec" as alias` and
`include "path.spec"` directives. `import` creates a qualified namespace such as
`alias.Rule`; `include` performs a structured merge into the current unqualified
namespace. Implement this as parsed `.spec` composition, not raw text concatenation.
Backends must agree on resolution order, normalized spec identities, duplicate-name
diagnostics, import-cycle diagnostics, source provenance, and descriptor fingerprints.
Current shipped parsers do not yet accept these directives, so do not treat them as a
runtime requirement until the implementation leaf lands.

The remaining fallback boundary is not a backend pattern to copy. Malformed helper forms
already covered by the typed AST path report unresolved-helper metadata rather than host
calls. Retired helpers, non-DSL host-shaped statements, and a few narrow return payload
compatibility shapes remain fenced migration debt. Unknown typed calls and receiver
chains are reserved for user-defined function resolution and diagnostics, not broad
host-language fallback. In the Perl reference, return/value-position unknown calls
currently diagnose. Standalone registered calls/chains lower as `VALUE_DROP`, while
unregistered call-shaped statements remain raw compatibility debt. New backends should
follow the typed-AST model used by the Rust implementation from the start, including a
validated function registry before runtime resolution.

You do **not** need to read the Perl source code. Every behavioral contract is
specified in the documents below.

## Reading Order

### Step 1: Understand the Big Picture
Read the [ADR 0006](../../../docs/decisions/0006-multi-backend-vision.md) — the multi-backend
decision record. It defines the lockstep contract: same `.spec` files, same semantics,
same test corpus across all backends. Then read
[ADR 0022](../../../docs/decisions/0022-native-in-memory-backend-embedding.md), which makes
native host-process parse/compile/execute APIs primary and CLIs secondary adapters.

### Step 2: Learn the `.spec` Language
Read the [Formal `.spec` Grammar](formal-grammar.md). This is the definitive syntax
reference. A valid backend must accept exactly this language. No Perl bootstrap parser
knowledge is needed.

### Step 3: Understand Runtime Behavior
Read the [Runtime Semantics](runtime-semantics.md). This defines how `.spec` rules
execute: parse modes, lifecycles, explicit cursor controls, accumulators, edge dispatch, repetition
bounds, and determinism guarantees. Two independent implementations of this document
must produce identical parser behavior.

### Step 4: Implement the Helper Surface
Read the [Helper Contract Catalog](helper-contract-catalog.md). Every helper function
(100+ across 10 families) is documented with its signature, type contract, behavioral
semantics, and edge cases. Implement these helpers in your target language — they
are the building blocks users write in `.spec` lifecycle blocks.

### Step 5: Implement HandlerIR
Read the [HandlerIR Specification](../../../docs/knowledge/handler-ir-design.md). The
HandlerIR is the structured AST between the compiler and code generation. Your backend
writes an **emitter** that consumes HandlerIR nodes and produces runnable code in
your language. The JSON diagnostic backend (`_emit_handler_json`) proves the pattern.

The Rust backend currently executes an interpreted structural model
(`CompiledSpec`/`CompiledRule`) rather than direct generated Rust handlers. Its
generated-source path is tracked separately under `RUST-PARITY.8`: `.8.1`
split the work, `.8.2` added the minimal scaffold/compile-run proof, and
`.8.3.1` added a generated rule-family plan. `.8.3.2` made default/OR acode
families run directly, `.8.3.3` made AND single/sequential acode families run
directly while enforcing ordered non-repetition AND regex/acode sequence
semantics, and `.8.3.4` made AND/OR bcode families run directly with shared
blind-edge tail execution. `.8.3.5` closed the non-repetition matrix by making
generated-plan routing exhaustive for all six non-REP generated families and by
asserting that family coverage in the source-emitter matrix. `.8.4` added direct
generated execution for the four explicit REP subfamilies (`RepAcode`,
`RepBcode`, `RepAndAcode`, and `RepAndBcode`), including bounded repetition,
zero-progress termination, and same-position recursive-call guard coverage.
`.8.5` integrated the generated-source proof with the oracle corpus: the
source-emitter test still compiles and runs an all-family generated matrix, and
it now also compiles/runs a curated subset selected from the checked-in
`rust/linkedspec-runtime/tests/corpus/manifest.json`. That generated-source corpus subset includes
authored proof fixtures, terse helper/control/user-function fixtures, and
shipped `tclite`/`portmap` smokes. This is deliberately a subset proof; the
full 105-fixture corpus remains the Rust interpreter oracle gate unless a later
leaf explicitly broadens generated-source corpus coverage.
`RUST-PARITY.9` closed the Rust follow-on documentation state around that
boundary: interpreter parity is the 105-fixture corpus contract, while generated
source currently proves direct structural-family execution plus the curated
manifest subset.

The completed scoped Dart milestone follows the same parity ordering. `DART-BACKEND-PARITY`
landed interpreter-first: `.spec` parser, typed helper/action AST, compiled-spec
state, Dart runtime interpreter, then the manifest-backed corpus runner.
Generated Dart source was originally deferred until after interpreter/corpus parity. The split future lane is now
active: `.3.3.1` landed deterministic v1 emission/isolation and `.3.3.2` landed exact ten-family plan/direct
execution, four rejection codes, and portable trace roles. `.3.3.3` now admits the contract-sourced eight-case
interpreter-first host proof. The repo has a Dart backend package under
`dart/`, including package metadata, committed lockfile, public library entrypoint,
Dart-specific CLI entrypoint, compatibility corpus-runner entrypoint, and smoke tests. Its corpus layer loads the
manifest-backed corpus, rejects manifest drift, checks required fixture files and
expected JSON syntax, and the Dart library exposes `executeCorpusFixtures(...)`
for controlled manifest fixtures. That executable harness runs fixtures through
the Dart parser, compiler, and runtime engine, then compares engine output to the
backend-neutral expected value wrapped one level with structural JSON equality.
It supports named and bounded fixture selection through the library and opt-in
CLI `--execute` mode; without a selector, the corpus runner executes the full manifest in
order. `bin/corpus_runner.dart` is now the sole corpus-focused command; the primary
`bin/linkedspec_dart.dart` rejects corpus subcommands/options and follows the shared parser interface.
The checked-in 105-fixture manifest passes through Dart execute mode,
covering the starter proof-edge, autoexist, mutation, core terse runtime,
middle helper/control/receiver, shipped-spec/parser-smoke, and top-level
function groups. The top-level `fn` corpus fixtures route through the spec-defined function shell: Dart obtains
spec-produced `function_definition` nodes, feeds them through staged body
projection, and does not raw-scan `fn` source in the corpus runner. The final shipped-spec/parser-smoke window started
at 2/31 green, reached 7/31 green after the regex-dialect, helper/action, and
recursive/default-mode bridges, reached 13/31 green after the portmap result-shape bridge, reached 19/31 green
after the hlink delimiter/capture bridge, reached 22/31 green after the helper mutation/text-normalization bridge,
reached 24/31 green after the legacy accumulator, public-parser leading-trivia, and final no-drift closeout
leaves, and is now 31/31 green after the structural regex closeout. The parser-smoke group is closed. The
portmap/action-edge result-shape leaf is
done: Dart `array(...)` splices explicit `flat*` arguments, all five portmap fixtures pass, and `vhdl_library_use`
also passes. The hlink leaf is also done: Dart `call(...)` refreshes `retv`, append-style mutations update
scalar-held lists, all five hlink fixtures pass, and `tablegrep_simple_term` also passes. The helper mutation leaf
is also done: statement-form `substr(...)` / `regex_subst(...)`, explicit split replacement, and entry/local line
helpers make `simenv_multiline_value`, `lib_reader_sattribute`, and `lib_reader_cattribute` pass. The basic
legacy accumulator leaf is also done: Dart `push(Child)` now appends child returns to the current rule accumulator,
so `regdef_nested_register_fields` passes. The `ds_vhistory` public-parser bridge is done too: Dart now mirrors
Perl's leading blank/comment-line skip before the top rule, so `ds_vhistory_version_entry` passes without
weakening ordinary scalar-held indexed reads. The regex-dialect
bridge is now in place for POSIX classes, inline/scoped flags, possessive
markers, lower-bound quantifiers, and Python-style named captures. Scoped flag
groups are accepted by lifting their options to the Dart `RegExp`. The missing
helper/action bridge is also in place for direct capture-slice helpers,
diagnostic output helpers, logical helpers, `exit_now`, and quoted helper-call
delimiter parsing. The recursive/default-mode bridge is in place too: compiled
action edges carry resolved regex-dispatch metadata, edge-only child regexes are
folded into the parent alternation, and explicit aggregate resets are scoped to
the current rule invocation. The structural regex leaf is now closed too:
bounded Dart matchers handle the exact shipped Lispish `(?R)`, EBNF `\K` /
`(?&name)` / `(?(DEFINE)...)`, and spec.spec recursive block forms. Fixed `blkFN` and variadic `blkVFN`
function-definition capture shapes are both preserved; this is a bounded shipped-pattern bridge, not a claim of
general recursive-PCRE support. Action-edge `push(child, index)` preserves indexed child payloads. The Dart-specific
corpus CLI implementation is done, and `DART-BACKEND-PARITY.7.5` closed the scoped
interpreter-first milestone. A later strict-interface audit has shown that this
corpus-oriented command is not yet equivalent to the Perl parser CLI; it is not the
final cross-variant user CLI contract.
`FUTURE-PARITY-BACKLOG.1.2` creates the dedicated `JULIA-BACKEND-PARITY`
plan. `JULIA-BACKEND-PARITY.1.1` has completed Julia toolchain/package-layout preflight, `.1.2` has created the
minimal Julia package scaffold, `.1.3` has added manifest-backed corpus IO and drift detection, `.2.1` has
added source AST/data types with neutral JSON projection, `.2.2` has added the source parser, `.2.3` has added
frontend validation and strict syntax behavior, `.2.4` has added spec-shaped top-level `fn` shell projection, and
`.3.1` has added typed helper/action AST parsing, `.3.2` has added ActionIR contract resolution, `.3.3` has added
the user-function registry seam, `.3.4` has added compiled-spec state, and `.4.1` has added runtime regex matching
and match-state tracking. `.4.2` has added first compiled-rule dispatch, and `.4.3.0` has split helper/value work by
runtime mechanism. `.4.3.1` has added core scalar/array/hash stores, typed snapshots, assignments/access, checked
nested writes, and capture maps/positions. `.4.3.2` has added string/scalar and numeric helpers, regex flags,
aliases/symbol callees, invalid-input boundaries, and compatible receiver chains. `.4.3.3` has added copied array
pipelines, split/flatten/reducer bridges, and updated-value end mutations. `.4.3.4` has added copied hash views
and transformations, statement-only named set-key mutation, direct hash-index assignment, merge-slot resolution,
and explicit flat-style splicing. `.4.3.5` has added expression-valued blocks, attached/marker/inline controls,
deterministic while guards, immediate helper/receiver with-blocks, and scoped hash/array tree callbacks. The
`.4.3.6` closeout confirms helper/value no-drift at 567 assertions without a runtime correction. `.4.4` adds an
explicit LIFO cursor stack, entry/local anchor rewinds, synchronized live/register cursor updates,
character-based cursor/input helpers, and earliest usable non-consuming named-rule boundary capture. Full Julia
tests pass with 581 assertions and package status `runtime-cursor-boundary`. `.4.5.0` splits diagnostics/trace
before code; `.4.5.1` now adds structured runtime diagnostics with spec/top/rule/handler attribution and
successful-output preservation. Full tests pass with 588 assertions, status is `runtime-diagnostics`, and
`.4.5.2` now adds ordered levels, environment/config controls, structured events/scopes/decisions/logs/dumps,
stdout/route/mirror sinks with reset, and output-preserving traced entrypoints. Full tests pass with 617
assertions at that controls boundary. `.4.5.3` now adds rule/regex/dispatch/lifecycle/recursion/cursor/boundary
events with traced/untraced identity. Full tests pass with 631 assertions, status is `runtime-trace-events`, and
`.4.5.4` closes final diagnostics/trace no-drift without a source correction. `.5.1` then
resolves/compiles/executes the built-in ActionIR body adapter in stable queue
order, stitches neutral JSON `body_ast`, and passes 662 assertions with status `runtime-staged-registry`; `.5.2`
then resolves registered exact-arity calls before helper fallback with eager caller arguments, fresh typed local
stores, final/local returns, receiver continuation, standalone result drop, and structured recursion cycles. Full
tests pass with 671 assertions and status `runtime-user-functions`. `.5.3` preserves two spec-returned functions
through normalized payload/jobs, stitched bodies, compiled
registry order, public descriptor metadata, and runtime output. Full tests pass with 691 assertions; status remains
`runtime-user-functions` at that boundary. `.6.1` adds controlled library corpus execution with public result
records, manifest-to-runtime composition, one-level wrapped structural comparison, optional trace lines,
structured diagnostic retention, and all-fixture reporting. Full tests pass with 715 assertions; status is
`runtime-controlled-corpus`. `.6.2.0` splits the 99-fixture rollout into bounded selection/reporting, starter
0–39, middle non-function 40–67, shipped-spec/parser-smoke 68–98, and spec-defined function-shell owners;
`.6.2.1` then adds bounded selection/reporting at 745 assertions and status `runtime-corpus-selection`.
`.6.2.2` proves starter fixtures 0–39 green at 40/40 without a production correction. `.6.2.3` proves non-function
windows 40–56, 58–59, and 62–67 green at 25/25 unchanged while routing three top-level function cases. Full tests
pass with 757 assertions and status `runtime-corpus-middle` at that boundary. `.6.2.4.0` measures and splits the
shipped-spec/parser-smoke window at 10/31. `.6.2.4.1` adds the complete direct anonymous capture family, closes
three hlink delimiter cases, and routes EBNF logging to structural output. `.6.2.4.2.1` adds eager logical helpers,
closes three portmap cases plus tablegrep. `.6.2.4.2.3` centralizes helper regex flags and closes portmap constant.
`.6.2.4.2.2` adds trace-routed, parse-result-neutral diagnostic output and advances simenv/history beyond
unsupported `print`. `.6.2.4.3` scopes explicit aggregate resets per recursive rule invocation and closes all
three recursive top-rule cases. `.6.2.4.4` adds action-edge child-push result reuse/indexing, closes all four
spec.spec smokes, and routes EBNF quote-only statement mutation. `.6.2.4.5.1` adds immediate `exit_now(...)`
termination with explicit numeric status, default status `1`, and structured runtime attribution. Simenv now
executes its fatal branch instead of reporting an unsupported helper, exposing the earlier scalar-mutation
prerequisite under `.6.2.4.5.2`. Full tests pass with 801 assertions, status is `runtime-corpus-exit-now`, the
window remains 25/31 at that boundary. `.6.2.4.5.2` adds statement-context four-argument scalar regex mutation
with strict flags and `$n` expansion while preserving pure numeric slicing. Both EBNF, both lib_reader, and simenv
fixtures pass. Full tests pass with 808 assertions, status is `runtime-corpus-statement-mutation`, the window is
30/31 at that boundary. `.6.2.4.5.3` mirrors the public parser's leading blank/comment-line skip through Julia's
in-memory runtime cursor seam. History passes without weakening indexed reads. `.6.2.4.6` now locks the complete
offset-68/limit-31 window in one permanent test: stable endpoints, 31/31 exact outputs, and zero failures.
`.6.2.5` then compiles and caches `specs/user_function_definition.spec`, executes it over caller-provided source,
normalizes its neutral nodes, and composes the existing staged body parser and runtime registry. The corpus path
tries rule-only parsing first and falls back only after a source parse error. All three routed fixtures pass.
`.6.3` then locks complete manifest validation plus ordered execution at 99/99 exact outputs and enables unbounded
CLI execution. Full tests pass with 840 assertions and status `runtime-corpus-full`; `.6.4` has since added focused
optional-SDK verification, and `.7.1` owns public documentation closeout.

### Lua Backend Commands, Embedding, and Status

Lua's current native boundary is `runtime-corpus-primary-cli`: PUC Lua 5.4 is
the primary runtime, LuaJIT is the secondary ABI, both pass 177/177 native
tests, the focused primary command passes 61/61 under default and POSIX option
environments, and the complete corpus passes 105/105. The warmed shared matrix
passes the same command contract at 5 backends x 2 environments x 61 cases.

From the repository root, run the complete checkout-local proof with:

```bash
bash tools/run_lua_local.sh
```

For direct embedding, primary-command, and corpus examples, use
`tools/run_lua_project_data.sh puc ...` or its `luajit` leg. The wrapper builds
the ABI-specific PCRE2/filesystem adapters below managed repository scratch,
supplies `LUA_PATH` plus `LUA_CPATH` to the child, and cleans on exit. The complete,
copyable command sequence is in
[Native Spec Loading](../public-api/native-spec-loading.md#lua-primary-parser-command).
There is no LuaRocks or system-wide installation dependency; the tracked
checkout commands are executable, and native modules are never installed
globally. `tools/test_lua_project_data_storage.sh` is the recurring same-filesystem
proof for all 13 Lua allocation owners and both ABIs.

The primary command has no corpus/status subcommands or backend-only options;
the developer corpus runner remains separate. Planning `.8.1.0` corrects the original
v1/v2-only scope against descriptor v3; deterministic exact-v1/v2/v3 source
construction `.8.1.1` and fresh-process PUC Lua/LuaJIT proof `.8.1.2` are closed.
Exact ten-family execution `.8.2` and contract-sourced interpreter-first 8/105 fresh-host proof `.8.3` are also
closed. Final `.8.4` admits all 16 Lua capability rows at 80/0/0 and closes the backend handoff.

The Lua backend now has a dedicated full-parity plan. PUC Lua 5.4 is the primary
conformance runtime; LuaJIT is a secondary compatibility leg. The rollout began
by locking package/test/cache policy before code. The plan owns a native
in-process module, `linkedspec-lua` with the exact shared command interface,
typed source/ActionIR/compiled state, four value kinds, generic final-codeblock
equivalence, regex/match-state proof, staged functions, diagnostics/trace,
105/105 corpus, capability expansion, and generated-source v1. Installed LPeg
is evidence, not automatic proof that Lua regex behavior satisfies the neutral
contract.

The foundation policy uses `lua/src/linkedspec/`, a dependency-free
`lua/test/run.lua`, `lua/bin/linkedspec-lua`, and
`lua/bin/corpus_runner.lua`. Local commands prepend those source paths through
`LUA_PATH` and never write global package locations. No JSON package is
required: corpus IO now uses a small pure-Lua codec with explicit null,
array, and harray identity plus canonical object ordering. LPeg remains outside
the scaffold dependency set. Any future LuaRocks cache must use a root-derived
repository cache and any disposable work must remain below managed `TMPDIR`.
At the historical foundation
boundary, `require("linkedspec")` returned exact backend/status/entrypoint
identity, the still-unimplemented primary scaffold intentionally exited `2`,
and the developer corpus command only validated the 105-fixture manifest. That
10/10-per-ABI boundary did not claim parser execution; the current command,
corpus, and 173/173 proof above supersede it. Unicode is the character/code-point
model; strict UTF-8 is the selected byte encoding, and UTF-16/UTF-32 are not
auto-detected. The next historical layer added data-only source
ASTs for specs, functions, ordinary/staged spans, staged parse jobs, rules,
simple/bounded modes, all ten body variants, targets, and fluent calls. Private
node identities and typed JSON projection prevent arrays, harrays, and
codeblocks from being inferred from incidental table layout. Representative
provenance and every body variant round-trip on both runtimes. The public
`parse_spec(source)` producer parses rule paragraphs into those nodes. At that
checkpoint, 21 shipped specs and 102 rule-only corpus sources passed on PUC Lua and LuaJIT.
The other three corpus sources begin with top-level functions and remain owned
by spec-returned projection `.2.4`. Source validation is now also public:
`validate_spec(spec)` checks tops, duplicates, function registry collisions,
raw syntax, edge families/targets/slots, and regex structure;
`validate_spec(spec, { strict_syntax = true })` adds unused-rule rejection. That
checkpoint validated 21 shipped and 102 rule-only corpus sources on both runtimes. The
helper/control reservation inventory is exactly the current 246 public names and is
checked equal to Dart/Julia. Function-shell projection now consumes explicitly
typed `function_definition` / `function_definition_error` nodes returned by
`specs/user_function_definition.spec`; Lua does not raw-scan `fn` source.

The next Lua runtime layer consumes that compiled state directly in memory.
`runtime_engine(compiled, options)` plus `runtime_parse(engine, input)` (or the
`runtime_execute` alias) executes default, AND, OR, single, optional,
plus/star, and bounded rule families over the native PCRE2 matcher. Action and
blind edges transfer child results through `retv`; lifecycle payloads run in
applicable `I`, `LS`, `LE`, `IT`, `EX`, `LX`, `E` order. Rule-local bindings
are restored across child calls, recursion and zero-progress paths terminate,
`next()` advances the current rule iteration, and `exit_now(status)` stops with
a typed runtime error. Parse results retain the direct value, neutral
one-element output wrapper, byte/code-unit and character cursors, and lifecycle
events. PUC Lua and LuaJIT pass the same 66-test gate. This is the narrow
dispatch-facing boundary; broad helper/value behavior, staged function
execution, corpus execution, the primary CLI, and generated source remain
later owned work.

Helper/value breadth is deliberately ordered into separate Lua leaves before
implementation: four-kind stores/access plus entry/match reads; scalar/string;
numeric; arrays; harrays; codeblocks/controls/generic trailing blocks/tree
callbacks; capture/mark/input/cursor state; diagnostic output; then exhaustive
246-name and documentation no-drift. Each leaf depends only on earlier value
mechanisms and may split again before code. This keeps recognition of a helper
name distinct from executable parity. `.4.3.1` has since closed core values.
Scalar/string is recursively split: pure value transforms/comparisons/receivers
under active `.4.3.2.1`, then regex/split/statement mutation under `.4.3.2.2`.

Do not infer regex support from the host language name. Lua's native patterns
do not support lookbehind, but LinkedSpec's PUC Lua and LuaJIT modules both use
PCRE2 and permanently pass positive and fixed-width negative lookbehind. The
`spec.spec` form is the one-character assertion `(?<!\\)`. Dart's `RegExp`
implements ECMAScript semantics, and the real `spec_spec_minimal_rule` fixture
containing that pattern passes through Dart parse/compile/runtime. Rust's basic
`regex` crate needed a compatibility path only at an earlier milestone. The
current Rust parser, validator, and runtime use RGX, the project's roughly 98%
PCRE2-compatible engine with lookaround/backreference/subroutine support; the
historical basic-crate limitation does not describe current Rust behavior and
does not imply a Dart or Lua gap.

The first helper leaf now makes Lua's four value kinds explicit through
`runtime_value_kind(...)`: null/boolean/number/string scalars, arrays, harrays,
and codeblocks. Stores and reads copy mutable values. Bare assignment retains a
typed value in one observable binding; `set(name, value)` binds the evaluated scalar, array, harray, or codeblock
value. Zero-based array and
string-key harray access, append/hash-index assignment, and copy-on-write mixed
nested assignment are implemented without intermediate autovivification.
Current-edge `retv` dispatches its child before returning.

Lua also implements the complete entry/local match read family: text,
zero-based compact groups, named values/presence/maps, Unicode character
length/start/end, and 1-based start/end line/column helpers. Absent text/group/
length/span reads are null; absent group/map collections are typed empty
containers; named presence is zero; missing line/column uses origin `(1, 1)`.
The same 69-test suite passes PUC Lua and LuaJIT. The following non-case pure
scalar/string leaf adds lazy coalescing, definedness/emptiness, Unicode trim/
length/substrings, literal transforms/predicates, lexical comparisons, and
receiver chains. Its expanded suite passes 70/70 on both runtimes. The next two
closed leaves replace host-dependent Unicode casing and scalar-to-text behavior
with versioned, all-variant contracts.

ADR `0027` now pins that casing surface to Unicode 17.0.0 full Default Case Conversion. Exact official
UnicodeData/SpecialCasing/DerivedCoreProperties inputs generate a neutral contract with 1,563 lower and 1,581 upper
mappings, merged Cased/Case_Ignorable ranges, Final_Sigma context, and 12 fixtures. The offline checker is part of
the canonical local CI gate. Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT consume generated modules and pass the same
12 fixtures. Host case APIs are not the semantic authority.

The following scalar-to-text slice adds `linkedspec-scalar-text-v1`. `cat` now preserves strings, spells booleans
as `1`/`0`, uses stable finite decimal text (`-0.0` → `0`, `1.0` → `1`), and returns null when any argument is null,
array, harray, or codeblock. One neutral executable fixture covers the currently portable value surfaces on Perl,
Rust, Dart, Julia, PUC Lua, and LuaJIT; the contract also fixes codeblock as non-text without claiming that the
separately deferred explicit final-codeblock call syntax is already portable. Lua advances to 72/72 on both ABIs.

The original scalar numeric rollout adopted `linkedspec-scalar-numeric-v1`. At that milestone Perl, Rust, Dart, Julia, PUC Lua,
and LuaJIT used dedicated strict adapters and passed the same 55 direct canonical calls: finite decimal
numbers/strings, exact fixed or variadic arities, invalid-to-null results, numeric comparison truth, half-away
rounding, division/clamp fences, and floor signed modulo. General-purpose scalar conversion paths remain unchanged.
One composed checker proves the exact expected fixture value on all six runtime variants. Lua word aliases,
arithmetic/comparison symbol callees, and integer/float/bare-scalar receiver chains now share the evaluator;
number-returning links compose; ordinary comparison results now also feed compatible scalar/explicit-container continuations under TYPE23.3.15.5. July90/90 was historical; current focused checks use PUC5.5.1/LuaJIT, with declared5.4/full admission separate.
Strict copied-array sum/avg/median/range/min/max now work through explicit, bare-binding, and terminal receiver
forms on both Lua ABIs. Ordered `array(...)`/literal construction, explicit `flat`/`flat_array` call or terminal-
receiver splicing, ordinary nested array preservation, copied concatenation, and saved-source isolation raise the
focused gate to 92/92. Copied take/drop/zero-based slice/order/membership/stable uniqueness in direct and receiver
chains raise it to 93/93 without mutating their source. Copied selection `.4.3.4.2` is closed and scalar/regex
transform pipelines add delimiter-first terminal joins, literal/PCRE2 split, PCRE2 filtering, Unicode transforms,
and seven dropped-call rebindings at 95/95. `.4.3.4.3` is closed.
Typed rule accumulators, cached action-edge child reuse, whole/indexed implicit/explicit push, and uniform
append/end/split flow raise the dual-ABI gate to 98/98. Exact tagged-record construction reuses governed split,
evaluates carried fields once, copies nested values, returns `[tag, item, fields...]`, and raises the gate to 99/99.
All 34 non-callback array names and six numeric terminals are closed under `.4.3.4`. Copied harray construction
`.4.3.5.1` makes generic `flat` preserve runtime array/harray kind, adds direct/receiver `flat_hash`, keeps ordinary
nested maps intact, and splices only explicit flat ASTs; explicit harray-to-array list context uses deterministic
sorted key/value pairs. Lexical keys, copied values ordered by key, count, and null-aware membership compose through
function/receiver/array-chain forms and return `0`/`[]` for missing or wrong-kind sources. Both Lua ABIs pass
All 13 ordinary harray names close at 103/103 through `.4.3.5.5`: bare merge operands, later override, copied
set/rename/drop/pick values, deep source isolation, harray/array-view receiver chains, and named `set_key`/direct
harray mutation are implemented and public-result guarded. Codeblock/control/tree-callback parent `.4.3.6` is
now split: `.1` eager expression blocks, `.2` inline controls, `.3` statement controls, `.4` current built-in
contextual blocks/`with`, `.5` deterministic callbacks, and `.6` closeout. General user-function final blocks are
complete through `.5.1`. Five-backend callable recurring/public admission is complete under `.11.8.4`.
Lua explicit callable-codeblock construction and general bound invocation are current under
`FUTURE-PARITY-BACKLOG.11.8.1-.2`; emitted execution identity is current under `.11.8.3`, and the same consumer
is recurring on PUC Lua and LuaJIT under `.11.8.4`.
Eager blocks plus lazy inline controls pass 105/105: ordinary no-pair braces yield their last/local-return
value, non-final statement mutation is preserved, harray braces retain precedence, and yielded values enter
receiver dispatch. Inline `if`/`switch` evaluates only selected payloads, keeps false/null, evaluates switch
subjects once, treats bare case labels literally, and composes in assignment and fluent return slots. Structural
`i`/`elif` and `when`/`otherwise` aliases do not become inline values. Attached/marker if-family statements then
raise the gate to 106/106: one selected branch executes, nested marker boundaries and empty branches remain exact,
block-local return is preserved, and malformed/orphaned controls expose typed keyword/reason/rule fields. Portable
authoring keeps `i`/`elif` marker-only and `when`/`otherwise` attached-only; extra alias-shape acceptance in
Perl/Dart/Julia versus Rust is backlog `.5`. Attached and marker switch statements then raise the gate to 107/107:
complete structure validates before one-time subject evaluation; first matching case/default ranges execute;
bare labels, nested boundaries, empty bodies, and local return remain exact; malformed/orphaned controls stay
typed. Inline and statement switch share Perl-reference scalar equality: null equals empty text, booleans use
`0/1`, and aggregates are noncomparable. Rust/Dart/Julia boolean or aggregate drift joins backlog `.5`. Perl also
executes marker statements outside every branch while Rust/Dart/Julia/Lua skip them; `.5` owns that range boundary.
Attached while raises the gate to 108/108: its condition sees body mutation, false initial runs no body,
return remains owned by its action/expression block, Perl-reference `next` continues the loop, and a typed
rule-attributed guard fails only when the condition remains true after the configured body limit. Dart/Julia guard
timing and Rust/Dart/Julia `next` drift join backlog `.5`. Built-in final blocks/scoped `with` then raise both Lua
ABIs to 112/112: copied signature metadata admits attached and parenthesized helper/receiver forms; the optional
value or receiver evaluates first; copied results continue through compatible receiver chains; and exact prior or
absent uniform bindings restore after success, local return, and error. Callback work is split at
`.4.3.6.5.1.0`: reference authored-value repair `.1.1` is done; `.1.2` adds atomic copied/restored callback frames
and sorted harray walk/map/reduce at 113/113. `.5.2` shares the dispatcher with zero-based array-root traversal,
recurse-only-same-kind semantics, and exact Perl-oracle behavior at 114/114 on both Lua ABIs. Tree callbacks are
closed; no-drift/dependency routing `.4.3.6.6` closes the parent and advances capture-slice/mark/input/cursor
helpers `.4.3.7`. Audit `.4.3.7.0` splits input/cursor controls, anonymous capture, governed named marks/bridges,
placement-sensitive marker members, earliest-boundary lookahead, and no-drift. It also finds seven helpers in the
public mark reference outside the governed 239-name backend inventories; named-mark closure must resolve that
cross-backend inventory gap instead of creating a Lua-only extension. `FUTURE-PARITY-BACKLOG.17` now owns the
neutral contract, five-backend rollout, and independent gate hardening. Input/live-cursor `.4.3.7.1` now executes
all character-unit input and cursor projections plus parse-scoped LIFO save/restore and entry/local anchor rewinds;
consume-mode matching observes the synchronized rewound cursor. Anonymous capture `.4.3.7.2` adds all 16 stable,
location, and advancing reads over the same byte-safe registers, with character-unit results, valid-only mutation,
and a void setter. Independent earliest-boundary `.4.3.7.5` then adds cached compiled-rule seek, earliest
selection, non-consumption, EOF fallback, and unresolved/regex-free no-op behavior. PUC Lua and LuaJIT pass
117/117. Named-mark `.17.1` adopts the exact seven-helper contract and aligns Perl live/generated plus Rust
native/serialized/emitted/generated execution; Dart `.17.2` now consumes the same fixture through native,
generated-plan, emitted-state, and primary-CLI routes, with an exact seven-name family view and complete 214-test,
61x2-CLI, 105-corpus proof. Julia `.17.3` consumes that same artifact through native, generated-plan,
emitted-state, and primary-CLI routes with an exact seven-name family view, 1,414-assertion, 61x2-CLI, and
105-corpus proof.
Lua `.17.4` now uses one parse-scoped rule-label/byte-offset store and returns the unchanged native/serialized
result at 119/119 on PUC Lua and LuaJIT. `.17.5` admits the seven calls into the aligned 246-name shared inventory,
combines 105 corpus fixtures with the exact named-mark fixture, independently requires all 122 public Perl
contracts, and locks nine non-public exclusions. Parent `.17` closes. Lua `.4.3.7.3` extends the same store across
governed current/input/anonymous/copy writers, stable and valid-only advancing named spans, two-mark reads, and
both anonymous/named bridges at 120/120. Placement-sensitive `.4.3.7.4` then compiles preferred/compatibility
anonymous markers and named marks into typed preceding-slot events, executes them after slot actions and before
`LE`, preserves them through public source reconstruction, and passes 121/121 on PUC Lua and LuaJIT. Exhaustive
capture/cursor no-drift `.4.3.7.6` derives 62 unique capture/mark/input/cursor/control calls and finds exact 62/62
agreement across contracts, interpreter dispatch, and focused execution sources. Together with the four exact
placement-marker spellings, the parent closes at 121/121 on PUC Lua and LuaJIT. Native capture/cursor parity does
not imply generated Lua support: compiled-state preservation, direct generated execution, subset admission, and
capability closeout remain `.8.1-.8.4`. Diagnostic output `.4.3.8` now adds a per-parse `diagnostic_sink` callback
and typed `RuntimeDiagnosticOutputEvent` records carrying helper, rule, and exact message text. `print`, `say`, and
`print_each` evaluate once left-to-right, preserve Unicode/order, stay out of parse values, and remain quiet
without a sink; immediate typed `exit_now` is unchanged. PUC Lua and LuaJIT pass 122/122. Exhaustive `.4.3.9.0`
then probes every admitted name: 230 reach an owner, thirteen are intentional statement/receiver-only forms, and
eager `and`/`or`/`not` are the exact missing value family. `.4.3.9.1` now executes all three eagerly over established
Lua truthiness. Permanent `.4.3.9.2` drives all 246 names through parse/compile/runtime: 233 reach function-form
owners and the exact thirteen documented structural/receiver-only forms remain intentionally unsupported as
functions. Direct `call(rule)` result/`retv`/cursor behavior is focused, public status is
`runtime-helper-value-control`, both ABIs pass 125/125, and parent `.4.3` is closed. A source-history recheck also
corrects the audit's unreproducible duplicate-`or` note: every inspected revision has one inventory row. At that
historical handoff, the audit also recorded
pre-existing diagnostic transport/format differences under `FUTURE-PARITY-BACKLOG.5.1`, while Perl
`and`/`or` keyword lowering and five-backend logical truthiness/arity remained separately owned by `.5.2`; Lua
`.8.4` had satisfied their backend-parity prerequisite, but neither Lua-local closure was a false five-backend
normalization claim. Planning audit `.5.2.0` proved this was not one simple mismatch. At that audit boundary Perl
conditions used lazy host `&&`/`||` while direct logical values remained raw/broken; Dart short-circuited; Rust,
Julia, and Lua were eager. Truthiness had three profiles: Perl/Lua (`"0"` false, empty aggregates true),
Dart/Julia (all nonempty strings true, empty aggregates false), and Rust (`"0"` plus `"false"` false, empty
aggregates false). Native/generated execution agreed within each backend. Neutral/backend/generated/gate/public leaves `.5.2.1-.9` were
therefore dependency-ordered before implementation. Neutral `.5.2.1` now adopts ADR `0043` and the
executable `linkedspec-logical-helper-v1` contract: valid `and`/`or` take one or more operands, `not` takes exactly
one, all valid operands evaluate once left-to-right,
all results are booleans, and invalid arity fails before effects. Typed truth makes only null, false, numeric zero,
empty strings, and empty aggregates false; codeblocks are true without invocation. The executable contract checks
17 truth rows, ten helper cases, three eager-effect scenarios, receiver/lazy-control contrast, four invalid calls,
deterministic fixtures, and 22 semantic/topology mutations. Its ledger began deliberately at 0 complete / 8 pending before Perl,
Rust, Dart, Julia, Lua, generated/primary, recurring, and public leaves `.5.2.2-.9`. Perl `.5.2.2` consumes that
policy through typed ActionIR/runtime lowering across native/live/standalone-emitted execution. Rust `.5.2.3`
now routes helpers and lazy conditions through one `RuntimeValue::as_bool` seam, rejects arity before operands,
and proves native, serialized, generated-plan, direct-value, and compiled emitted roles. Dart `.5.2.4` now routes
helpers and lazy controls through `runtimeLogicalTruth`, rejects call shape before effects, evaluates every valid
operand once left-to-right, and proves native, normalized, generated-plan, compiled emitted, and primary roles.
Julia `.5.2.5` preserves its typed eager `_runtime_truthy` seam, rejects all four invalid arities before effects,
and proves native, normalized, generated-plan, compiled emitted, and primary roles with optional exact diagnostic
fields. Lua `.5.2.6` aligns `runtime_truthy` and pre-effect arity across native, reconstructed, generated-plan,
loaded emitted-module, and primary roles on PUC Lua and LuaJIT. Its expanded consumer passes 359/359 per ABI and
the complete Lua gate at that boundary was 177/177 per ABI plus CLI 63x2 and corpus 105/105. Generated/primary `.5.2.7` proves
every available direct/traced role across Perl, Rust, Dart, Julia, and Lua with exact values, eager effects,
failure/source metadata, and trace identity. Rust retains the intentional typed direct-value versus compatibility-
output-array signature. Shared case `success_logical_helpers_eager` passes all five commands in default and POSIX
environments. Recurring `.5.2.8` now locks one strict driver over that neutral checker, all six runtime consumers
and their exact native/generated roles, selected 5x2x1 primary case, and generated-source/capability/coverage
ledgers. Canonical local CI registers the same all-toolchain proof behind `LINKEDSPEC_RUN_LOGICAL_MATRIX=1`.
Public no-drift `.5.2.9` locks the authoritative guide/backend/status surface; the ledger is 8 complete / 0
pending and parent `.5.2` is closed. Explicit codeblock literals remain
separately owned by `.11`; the logical contract's
typed codeblock row does not activate that syntax.
Planning `.5.1.0` split diagnostic parity before behavior changes. Its historical probes found three important
reference hazards in the pre-repair transport: Perl evaluated `print_each` prefix/suffix inside its host loop,
host output bypassed the primary command's strict UTF-8 encoder, and lowered host `exit` bypassed canonical
invocation failure framing. Neutral contract `.5.1.1` then adopted ADR `0042` and the strict
`linkedspec-diagnostic-output-v1` fixture: one-plus/two-or-three arities before evaluation, once-only arguments,
typed scalar rendering, per-call/item Unicode events, quiet caller sinks, unchanged sink failure, immediate exit,
generated propagation, and an ADR `0024`-separate quiet primary projection. Its eight rollout rows deliberately
began pending. Perl `.2`, Rust `.3`, Dart `.4`, and Julia `.5` now consume the exact native contract through typed
invocation-local events, quiet defaults, preserved sink failure, and typed immediate exit. Dart and Julia both
use private carriers through their action/runtime wrappers so even a caller-thrown interpreter exception retains
its exact identity; Julia additionally removes rich helper text from low trace. Lua `.6` consumes all 109
neutral assertions on PUC Lua and LuaJIT, using the same private-carrier pattern for exact caller identity and a
distinct `RuntimeExitNow`. Generated/CLI `.7` propagated the same sink through every available emitted role and
locked the quiet primary projection. The topology-checked recurring six-consumer/native+generated/quiet-primary
gate `.8` prevents silent omission. Public no-drift `.9` aligns and checks the normative document set, closing the
diagnostic-output parent at 8 complete / 0 pending while capability remains 80/0/0.
Planning-only `.4.4.0` follows the completed Dart/Julia dependency order: `.4.4.1-.4` separately own neutral
structured runtime failures, ordered trace controls and caller-owned sinks, interpreter events, and runtime
no-drift. Full native loading, frontend, validation, compiler, function-shell, staged-dispatch, and runtime
propagation stays `.5.3`, after general staged functions `.5.1` and native loading `.5.2` create those owners.
Structured runtime diagnostic `.4.4.1` now exposes the same neutral fields on typed Lua exceptions. Optional
engine source identity, top-selection/input/lookup/execution stages, deepest child rule and handler preservation,
deterministic JSON, unchanged text, and successful-result identity pass 126/126 on both ABIs. `.4.4.2` now adds
typed ordered levels/config/events, documented environment controls, caller-owned stdout/route/mirror sinks,
reset/append, and result-neutral direct/config-wrapper parse scopes at 128/128. `.4.4.3` adds exact runtime
rule/regex/dispatch/recursion/lifecycle/cursor/boundary/mark-capture events at 129/129. No-drift `.4.4.4` closes
parent `.4.4`. Planning `.5.1.0` separates staged dispatch, fixed/variadic runtime, contextual-codeblock metadata/
runtime, and closeout. Minimal staged dispatch `.5.1.1` passes 130/130; fixed-v1 runtime `.5.1.2` passes 133/133.
Variadic-v2 state `.5.1.3.1` preserves the exact signature union and minimum/unbounded resolution at 136/136.
Fresh rest-array execution `.5.1.3.2` passes the exact neutral fixture and copied mixed/empty runtime proof at
139/139. Contextual final-codeblock metadata `.5.1.4.1` preserves exact shell/staged/registry state and contextual
normalization at 142/142 with public status `runtime-user-functions-contextual-codeblock-metadata-v1`.
Contextual execution `.5.1.4.2` then runs in the current function frame with cleanup-safe restoration, static
callable precedence, chainable results, and typed failures at 146/146; public status is
`runtime-user-functions-contextual-codeblock-v1`, parent `.5.1` is closed, native-loading split `.5.2.0` is done,
 portable resolve/load `.5.2.1` and cached automatic spec-defined parsing `.5.2.2` pass 151/151. Typed loaded-source
composition `.5.2.3` then passes 153/153 with status `native-spec-pipeline-v1`; `.5.2.4` closes parent `.5.2`,
exact descriptors `.5.3.1` and caller-owned full-pipeline trace `.5.3.2` then pass 155/155 with status
`native-full-pipeline-trace-v1`. No-drift `.5.3.3` closes parents `.5.3`/`.5`; controlled/core planning `.6.1.0`
and typed nested-path repair `.6.1.1` are complete at 46/46 across offsets 0-39 and 99-104. Reusable executor
`.6.1.2` passes controlled typed records at 160/160 per ABI; ordered core window `.6.1.3` permanently passes 40/40
at endpoint 1/1 and raises both suites to 161/161. Governed `.6.1.4` permanently passes 6/6 at endpoints
`2,1,2,1,5,5`, raises both suites to 162/162, closes `.6.1`, and activates `.6.2`; capability remains 64/0/0.
Explicit
`{|params| ...}` literals and
dynamic codeblock-variable calls remain `.11.8`.
ADR `0033` and
`FUTURE-PARITY-BACKLOG.16` separately close narrow zero-argument aliases. Neutral
contract `.16.1`, all five backend implementations through Lua `.16.6`, and public/capability admission `.16.7`
are complete at 64/0/0 with one recurring five-backend/two-Lua-ABI command. Rust, Dart, Julia, and Lua's pre-existing `.contains()` missing-argument outcomes are
separately owned by helper backlog `.5`. Lua proves public SpecFile JSON reconstruction on both ABIs, and emitter
core `.8.1.1` now serializes that exact fixed-v1/variadic-v2/final-codeblock-v3 state into deterministic native
Lua with metadata, errors, and direct/traced roles. Isolated PUC Lua/LuaJIT valid/corrupt load/run/cleanup proof
is closed under `.8.1.2`; `.8.2` adds authoritative ten-family root/nested dispatch, exact rejections, portable
trace, an isolated all-family host, and emitted variadic proof. `.8.3` adds exact contract-ordered interpreter-first
8/105 fresh-host values/metadata/plans/trace identity and cleanup. Capability ownership remains `.8.4`.
This also corrects the earlier Lua-only inert assignment scaffold expectation.
Perl's direct-value/arity boundary for zero or variadic flat/concat calls, negative
selection counts, Rust/Dart/Julia's three missing dropped-transform rebindings, invalid join sources, and implicit
child-push expression results, rename-to-existing-key policy, scalar/aggregate condition truthiness,
boolean/number or aggregate switch equality, and while guard/`next` behavior differ;
`FUTURE-PARITY-BACKLOG.5` owns those explicit normalization decisions. Callable arity is semantic: add/multiply/min/max are
purposefully unbounded, while subtraction/division/modulo and comparisons remain exact-arity. ADR 0030 now adopts
`fn name(fixed, ...rest) { ... }`: version-1 fixed functions stay exact; version-2 variadic definitions preserve a
neutral fixed-prefix/rest/min/max signature through staged records and descriptors, bind extras as a fresh typed
array, and reject keyword/overload/host-splat semantics. Perl, Rust, Dart, and Julia now consume the unchanged
fixture through grammar/spec projection, staged/outward records, native and generated execution, diagnostics, and
exact results. Lua `.5.1.3.1/.2` preserves and executes the native signature/rest contract, and `.5.3.1` now emits
the exact shared fixed-v1/variadic-v2/final-codeblock-v3 outward descriptor union. Generated preservation,
execution, and final census admission close under `.8.1-.4`; the callable signature is now admitted across all
six runtime variants.

The next Lua leaf reuses its in-process PCRE2 owner for helper regex values. Function and terminal-receiver
`matches` apply `i/m/s/x`, accept `g/o` as predicate no-ops, and return false for null/non-text input, non-regex
patterns, unknown flags, or invalid patterns. PUC Lua and LuaJIT pass 73/73; pure split remains separately owned.

The pure-split leaf then adds fresh typed arrays for literal and PCRE2 delimiters, preserves leading/trailing empty
fields, treats an empty literal delimiter as Unicode-scalar splitting, and advances safely around zero-width regex
matches. Function and string-receiver forms are equivalent and non-mutating. Both Lua ABIs pass 74/74; scalar
statement substitution remains a separate next mechanism.

The scalar-mutation leaf then spends dropped-statement context: four-argument `substr`/`regex_subst` with a bare
target mutates that scalar, while numeric `substr` remains pure. String and regex patterns share strict PCRE2
flags; `g` controls global replacement, `o` is a no-op, and `$0`/`$n` expand per match. Invalid pattern/flag
diagnostics carry the rule label, and zero-width global replacement advances by Unicode scalar. Both Lua ABIs pass
75/75; explicit array-target split replacement remains separately owned.

The explicit-array leaf then recognizes dropped `split(target, source, delimiter)` before pure evaluation.
It evaluates source and delimiter once, reuses the exact pure split policy, and replaces only the named typed array
store with a copy. Ordinary split calls remain harmless discarded expressions and source scalars stay unchanged.
Both Lua ABIs pass 76/76; shipped-corpus and public-surface no-drift remains the closing string-runtime leaf.

```lua
local source = [[
Top::
 /a/ -> Child
 E { return(retv) }

Child:
 /b/
 E { return("child") }
]]

local compiled = linkedspec.compile_spec(linkedspec.parse_spec(source))
local result = linkedspec.runtime_parse(linkedspec.runtime_engine(compiled), "ab")
assert(result.value == "child")
assert(result.output[1] == "child")
```

Lua embedding code can construct the neutral data model directly:

```lua
local linkedspec = require("linkedspec")
local ast = linkedspec.spec_ast

local spec = ast.spec_file({
  rules = {
    ast.rule({
      header = ast.rule_header({
        label = "Top",
        is_top = true,
        mode = ast.default_rule_mode(),
        rest = "/x/",
        line = 1,
      }),
      body = {
        ast.body_element({
          kind = ast.regex_body_kind({ pattern = "x" }),
          source = "/x/",
          line = 1,
        }),
      },
    }),
  },
})

local encoded = linkedspec.json.encode(ast.to_json(spec))
local restored = ast.from_json("SpecFile", linkedspec.json.decode(encoded))
assert(ast.top_rule(restored).header.label == "Top")
assert(linkedspec.validate_spec(restored) == nil)
```

The projection uses the same field names as the other variants, including
`functions`, `source_span`, `body_span`, `body_parse_job`, `parent_ast_path`,
`result_policy`, and `failure_policy`. Constructor lists must be dense and
one-based. Optional function payloads must already be typed JSON values; plain
Lua tables are rejected rather than guessed.

The rule parser recognizes simple/bounded modes, header-line regexes, action
and blind edges, grouped/indexed targets, lifecycle/plain blocks, markers,
multiline fluent continuations, receiver `when`/`otherwise` blocks, comments,
and permissive raw fallback. Nested scanning preserves braces inside both
single- and double-quoted strings. Because Lua strings may contain arbitrary
bytes, the public source seam rejects invalid UTF-8 before scanning; Unicode is
still the logical character model. Statement separation follows the universal
rule exactly:

```text
E {
  set_key(meta, "a", 1)
  set_key(meta, 'b', 2)
  return(meta)
}

E { set_key(meta, "a", 1); set_key(meta, 'b', 2); return(meta) }
```

The first block uses physical newlines. The second uses semicolons only between
multiple statements on one line; its last statement has no trailing semicolon.
Parsing remains permissive; callers opt into the separate validator. Validation
still does not imply compilation, runtime, corpus execution, or primary CLI
readiness.

The function-shell APIs are:

```lua
local nodes = linkedspec.definition_nodes_from_user_function_definition_output(output)
local projection = linkedspec.project_user_function_definition_asts(source, nodes)
local parsed = linkedspec.parse_spec_with_user_function_definition_asts(source, nodes)
local staged = linkedspec.parse_spec_with_staged_user_function_definitions(source)
```

Projection validates identifiers, params/arity, Unicode character-index spans,
exact source/body slices, staged payload and parse-job metadata, parser/top-rule
identity, result/failure policy, and diagnostic ownership. It normalizes paths
to `functions.<index>.body_source`, derives deterministic body-job IDs, replaces
function-span characters with spaces while preserving CR/LF, then parses the
remaining rules. The explicit projection API leaves `body_ast` absent; the automatic staged API executes and
stitches it. Empty node input never falls back to a raw function scanner, and the automatic API obtains nodes only
by executing the spec-owned grammar.

Lua now also exposes the typed ActionIR parser seam:

```lua
local block = linkedspec.parse_action_block([[
set_key(meta, "b", 2)
set_key(meta, "a", 1)
set_key(meta, "drop", 0)
set_key(meta, "stmt_hash", 4)
set_key(overlay, "a", 10)
set_key(overlay, "c", 3)
value_set = set_key(meta, "value_only", 9)
receiver_set = meta.set_key("receiver_only", 5)
]])

assert(block.kind == "action_block")
assert(#block.statements == 8)
assert(block.statements[7].expr.kind == "assign_scalar")
```

No semicolon is needed there because every statement occupies its own physical
line. Semicolons only separate multiple statements on one physical line, and
the last statement on that line has no following semicolon:

```text
set_key(meta, "b", 2); set_key(meta, "a", 1); return(meta)
```

`parse_action_block(source)`, `parse_action_statement(source)`, and
`parse_action_expression(source)` return structural records for value-drop
statements, calls and arguments, scalar/array/harray/codeblock values, regexes,
direct and nested access, scalar/append/hash/nested assignments, attached
controls, switch branches, and receiver chains. The nodes retain source text
and zero-based Unicode character spans; strict UTF-8 is only the Lua host
encoding at this boundary. `linkedspec.action_ast.to_json(node)` projects them
through typed JSON values. Unsupported expressions stay explicit `raw_perl`
nodes so the diagnostic layer can reject them without arbitrary Lua-global or
host-code fallback.

Single-quoted strings have the same universal DSL status as double-quoted
strings. For example, the second argument below is the literal `"|\\s`:

```text
substr(value, '"|\s', "", go)
```

Final codeblocks are parsed generically for helper calls, user-function-shaped
calls, and receiver methods. The attached form is the same call shape as an
explicit last `block_value` argument:

```text
func_helper_method(value) { return(value) }
func_helper_method(value, { return(value) })

value.func_helper_method() { return(value) }
value.func_helper_method({ return(value) })
```

The `.3.1` boundary parses structure only. Lua now layers typed ActionIR
contract resolution over those nodes:

```lua
local resolution = linkedspec.resolve_action_block_contracts(block)
assert(resolution.ok)

local alias = linkedspec.resolve_action_expression_contracts(
  linkedspec.parse_action_expression("gt(value, 0)")
)
assert(alias.contracts[1].source_name == "gt")
assert(alias.contracts[1].canonical_name == "num_gt")
assert(alias.contracts[1].family == "numeric")
```

`resolve_action_block_contracts`, `resolve_action_statement_contracts`, and
`resolve_action_expression_contracts` walk calls, receiver methods,
assignments, controls, nested arguments, block values, shapes, and access
indexes. Contracts record source/canonical name, family, surface, source span,
and positional/keyword counts. `action_contracts.to_json(value)` projects the
same fields as Dart and Julia.

`canonical_action_helper_name(name)` covers the current numeric, symbol, and
control aliases, including `=(target, value)` to `set`. The resolver and source
validator share the exact 250-name `action_call_names` inventory. Unknown or
non-current calls produce generic `unknown_helper`; structural fallback
produces `raw_perl`. Neither can fall through to a Lua global.

The optional `{ function_registry = registry }` resolver input checks
`registry:resolve_call(name, arity)` before helper fallback for ordinary
function-call surfaces. Exact matches become `family = "user_function"`;
registered wrong-arity calls produce `user_function_arity_mismatch`. This is
the stable `.3.3` integration seam, not a hidden Lua closure registry.

The concrete registry is now available:

```lua
local registry = linkedspec.user_function_registry_from_spec(spec)
local call = registry:resolve_call("normalize", 1)

assert(call.matched)
assert(registry:body_parse_jobs()[1].function_name == "normalize")
```

Registry construction snapshots ordered typed definitions, rejects duplicate
names, and preserves body source, payload, parse job, and optional ActionIR AST.
`stitch_function_body_ast(spec, job_id, body_ast)` validates the staged
`replace_field` / `body_ast` insertion contract and returns a new typed spec;
neither the source spec nor caller-owned AST is mutated.

Invocation preparation is intentionally data-only. Callers first evaluate each
argument, then pass the resulting scalar, array, harray, or codeblock values to
`prepare_user_function_invocation(...)`. It creates fresh local stores and
defensively copies aggregates and codeblock ASTs. It accepts neither a caller
store nor a Lua function, so host closures and implicit caller mutation cannot
cross this boundary. Unknown names, arity drift, ambiguous/cyclic values, and
recursion are typed failures; recursion reports stable rule and handler-source
identity. Function-body execution and staged dispatch remain later layers. The
dual-runtime gate now passes 50/50 on PUC Lua and 50/50 on LuaJIT.

Lua's compiler layer is now data-complete before matching. `compile_spec(spec)`
validates and snapshots the typed source by default, then produces ordered
effective rule/function state:

```lua
local compiled = linkedspec.compile_spec(spec)
local top = compiled:rule("Top")
local descriptor = compiled:to_descriptor_json()

assert(top.mode_metadata.is_repetition)
assert(descriptor.meta.descriptor_model == "compiled_descriptor_state")
assert(descriptor.spec.Top.handler.kind == "lua_interpreter_rule")
```

Each `CompiledRule` carries its source header, neutral mode metadata, regex
patterns, dependency refs, action/blind edges, lifecycle/plain payloads,
original body elements, parsed ActionIR, and registry-aware contract results.
Child regex slots are validated and resolved into structured
`CompiledDependencyRegexState` rows with zero-based indexes and combined-pattern
metadata. The compiler does not execute or host-compile those patterns yet.

`compiled:to_json()` exposes the typed internal effective state.
`compiled:to_descriptor_json()` exposes exactly the shared outward contract's
four keys: `spec`, `functions`, `dependency_regex_map`, and `meta`. Its model
identities are `compiled_descriptor_state`, `compiled_spec_state`, and
`compiled_dependency_regex_state`; ordered function records retain staged
payload/job/body-AST fields. Lua rule handlers are explicitly
`lua_interpreter_rule` / `compiled_state_only`, making the non-runtime boundary
visible rather than fabricating callable handlers. Source mutations after
compilation cannot alter the compiled snapshot. The dual-runtime gate passes
55/55 on PUC Lua and 55/55 on LuaJIT; regex/match-state work begins in `.4.1`.

Lua runtime matching now uses a narrow repository-owned PCRE2 C binding. LPeg
was evaluated and rejected for this role: it constructs PEG patterns but does
not parse LinkedSpec's governed PCRE syntax. No `rex_*` module is installed.
`tools/build_lua_native.sh` compiles the binding separately against the PUC Lua
and LuaJIT ABIs. `tools/run_lua_local.sh` places both builds under one unique
managed repository temporary tree and removes the tree on every exit, so no
binary/cache enters tracked or global Lua paths. The builder validates the
output filesystem before creation and after resolution; the targeted
`tools/run_lua_project_data.sh` wrapper supplies the same boundary for one ABI.
Matching remains in-process; it never shells out to `pcre2grep` or Perl.

Given a compiled rule, matching is direct:

```lua
local alternatives = linkedspec.compile_runtime_regex_alternation(
  compiled:rule("Top")
)
local match = alternatives:match("prefix évalue", 0, "seek")

if match then
  print(match.alternative_index, match:text(), match:char_start())
end
```

`seek` selects the earliest candidate at or after the strict-UTF-8 byte cursor
and breaks equal-position ties by source alternative index. `consume` anchors
the attempt at that cursor. PCRE2 consumes inline/scoped flags, POSIX classes,
Python/angle named captures, possessive quantifiers, recursion, and `\K`
directly; there is no Lua dialect normalization.

Typed match records preserve the stable zero-based alternative, full group
slots, compact participating captures, named captures, byte/code-unit spans,
Unicode character spans, 1-based line/column, and explicit zero-width state.
Typed immutable registers keep entry and local matches separate, seed a child's
entry from the caller's local match, track cursor/capture anchors, and detect
zero progress without confusing an absent match with `[0, 0)`. Invalid PCRE,
UTF-8 input, non-boundary offsets, and parse modes are typed failures. The gate
passes 60/60 on PUC Lua and 60/60 on LuaJIT and leaves no native artifact;
compiled rule dispatch remains `.4.2`.

Required-slot execution now addresses the authored alternative directly:

```lua
local required = linkedspec.match_runtime_regex_slot(
  alternatives,
  1,
  "aa",
  1,
  "consume"
)
assert(required.alternative_index == 1)
```

This operation is distinct from choice matching. Ordered and repeated-AND
execution supply the required index; OR/default continues to evaluate the full
alternation. `validate_compiled_regex_slot_identities` checks target-rule/child-
index identity at compiler, runtime-engine, emitted-source, and generated-plan
boundaries. Descriptor metadata and emitted v2 modules publish
`linkedspec-duplicate-regex-slot-identity-v1`; generated plans remain exactly
label/family rows. High trace emits `lua_runtime:regex_slot_selected` with rule,
selection role, target rule, and regex index. The same 15-role admission source
passes 112 assertions on PUC Lua and LuaJIT; the complete driver retains 177
package tests per ABI, primary 65/65 in both environments, and corpus 105/105.

The duplicate-slot recurring gate is
`tools/check_duplicate_regex_slot_identity_five_backend.sh`. It runs this shared
consumer on both Lua ABIs and composes the Perl, Rust, Dart, and Julia admissions,
selected primary case, and support ledgers in one omission-sensitive proof.

### Julia Backend Commands, Embedding, and Status

Julia is green at the accepted interpreter-first boundary: the complete validated corpus executes 105/105 with
exact checked-in output, full package tests pass with 1,040 assertions, and package/CLI status is
`runtime-corpus-primary-cli`. The primary product surface is the native `LinkedSpecJulia` module; the Julia CLI and corpus
runner are thin adapters over the same in-process parser/compiler/runtime path.

The Julia primary command now exposes ADR `0023`'s parser-oriented help and accepts only its exact source/input/
parser/trace flags. It rejects `status`, `corpus`, and all positional arguments with usage exit `2`; corpus work
remains in the separate runner. Named specs resolve through exact current path, current `NAME.spec`, repository
`specs/NAME.spec`, then deterministic authored fallback. File and inline content is loaded exactly. Rule-only and
spec-driven top-level-function source now execute through the native compiler/runtime with top-rule and trace
controls; cursor policy derives from each authored family. Success prints the direct top-rule value with
recursively sorted object keys and one newline.
Source compilation precedes input-file loading. Compilation, input-load, and invocation failures use stable stderr
headings and exit `1`; usage errors exit `2`. Native trace retains stdout/route/mirror, reset, quiet, and emoji
controls; the primary command now uses a separate canonical phase recorder. `.7.3.2.5` locks nine process families with
exact stdout/stderr/newline/file bytes and exit 0/1/2. `.7.3.3` closes honest local no-drift; global cross-backend
fixture identity has since closed under `FUTURE-PARITY-BACKLOG.1.5.4.3`.

The global unchanged-suite audit in `FUTURE-PARITY-BACKLOG.1.5.4.0` measured warmed Julia at 13/61. `.1.5.4.1`
now renders exact shared help, rejects malformed source/input bytes as UTF-8 without converting valid text, and
emits only the stable phase heading on primary stderr. Native structured exceptions retain diagnostic detail.
That boundary reached 42/61. `.1.5.4.2` now projects exact levels, UTF-8 counts, escaping, emoji, sinks, file
lifecycle, failures, and result framing independently of rich native trace, closing 61/61 default/POSIX.
`.1.5.4.3` now owns project warmup and closes the recurring four-backend matrix. The native rich diagnostics/trace
APIs remain available.

The boundary plus global matrix claim exact four-backend fixture identity, but not complete public capability
parity or generated Julia source. `.7.2` deliberately defers generated Julia source to the split
future source-emitter lane under `FUTURE-PARITY-BACKLOG.3`; Julia currently guarantees the interpreter and local
primary-command paths. A credible later emitter must own its scaffold/compile-run harness,
typed generated-family plan, direct structural-family execution, and curated corpus proof. Runtime diagnostics/
tracing now span frontend, compiler, function-shell, staged, and interpreter phases through one optional emitter;
the trace chapter documents the event families and examples. `JuliaFormatter` and `JET` are
optional local tools rather than parity prerequisites.

## Machine-readable capability census

Exact CLI identity and 105/105 interpreter output do not alone prove every public API and mdBook capability. The
broader current census lives in `capability_conformance/manifest.json` and is checked by:

```bash
perl tools/check_capability_conformance.pl
```

The current audit contains 17 capabilities x five admitted backends. All 85 states pass. The
`language.staged_ast_enrichment` row records the current portable annotation and its caller-authorized internal
carriers. Earlier non-pass boundaries remain below as rollout history, not as live gaps.

Portable `parse_job(...)` authoring is current across five backend sources and six runtime routes without adding an outward facade, schema, semantic/MCP, CLI, or README surface.

| Residual mechanism | Current classification | Owner |
| --- | --- | --- |
| Native named/file resolution | ADR `0026` and the 14/9/4 fixture fix portable names, exact paths, ordered roots, strict UTF-8, and typed stages. Perl, Rust, Dart, and Julia consume the contract directly; exact admission is closed. | closed `.1.6.4` |
| Full native pipeline trace | Perl, Rust, Dart, and Julia propagate a caller-owned emitter through frontend/compiler/function/staged/runtime phases. Dart's direct routed/quiet/failure proof and recurring gates are admitted. | closed `.1.6.5` |
| Generated parser source | Perl, Rust, Dart, Julia, and Lua pass contract v1. Rust compiles/runs 105/105. Dart, Julia, and Lua pass deterministic emission, ten-family direct dispatch/four rejections/trace roles, and exact contract-sourced interpreter-first 8/105 host admission; Lua uses fresh PUC Lua/LuaJIT hosts and exact v1/v2/v3 callable state. | closed `.3.5`; Lua admission `.8.4` |
| Punctuation-light zero-argument aliases | Six standalone markers and a terminal zero-argument receiver segment preserve their parenthesized typed twins without widening conditions or general calls. | closed `.16.7`; five-backend baseline 80/0/0 after Lua `.8.4`; current census 85/0/0 after staged recurrence `.14.7.8` |

Deprecated Perl plugin machinery is the sole explicit exclusion rather than a silent gap. Portable dedicated
`parse_job(...)` authoring is current; ambient provider/path loading remains forbidden, not deferred. Generic
first-class/dynamic callable-codeblock equivalence is already admitted. Rust now admits
typed callable-literal construction/state, exact dynamic invocation, and metadata-governed generic contextual
equivalence across native, serialized, generated-plan, and emitted-source execution. Dart `.11.5.1-.2` admit the
same inert explicit-literal construction/state plus dynamic invocation, copied/restored caller-context bindings,
typed result access, portable failures/recursion, and native/reconstructed/generated/emitted identity. Dart
`.11.5.3` adds exact final-only staged/descriptor metadata and generic contextual equivalence for typed functions,
helpers, receiver `with`, and tree traversal through the same evaluator. Julia `.11.6.1-.3` now admit the same
inert explicit-literal construction/state, dynamic invocation, generated reconstruction, semantic shape, exact
final-only staged/descriptor metadata, and generic contextual equivalence through one post-registry contract owner
and the existing evaluator. Lua `.11.8.1-.3` now implements the same literal, dynamic/contextual, and native/
reconstructed/generated/fresh-emitted behavior on both ABIs; `.11.8.4` still owns recurring admission. Semantic
introspection and thin MCP are separately complete. No backend is called complete while a current matrix state
remains partial or gap.

During the historical rollout, `FUTURE-PARITY-BACKLOG.1.6.6` closed the non-codegen census without claiming
complete backend parity. Its 57/1/2 boundary first advanced to 58/0/2 through strict recurring Rust generated-
source admission, when Dart and Julia were the two gaps; Dart admission then advanced it to 59/0/1.

That 57/1/2 statement was the source-audit boundary. `.3.1.0` added the missing independent Perl compile/run probe:
the captured text compiles, but stringifying/recompiling `LinkedRE::oredRE` detaches its `(?{$pos=N})` alternative
markers from `LinkedRE::or`'s lexical index. A match can consume input while generated action selection is skipped.
Perl was therefore corrected to partial. `.3.1.2` now reconstructs those alternations from canonical refs and passes
independent result/trace/identity/plan/error proof. `.3.1.3.0` then audited Rust against the now-concrete v1 roles:
its pre-contract scaffold was green for all families and eight fixtures. `.3.1.3.1` now supplies typed source
identity, contract/version metadata, structured emission/compile-load/validation/execution errors, and compatible
legacy adapters. `.3.1.3.2` now adds exact neutral plan strings and four rejections, direct v1 result projection,
and the three portable trace roles while preserving legacy accumulator/trace behavior. `.3.1.3.3` reruns complete
Perl/Rust gates and admits that baseline: census is 57/1/2, with Perl pass. `.3.2.0` subsequently adds a staged
full-manifest classifier that prepares every fixture through interpreter-first emission, writes 105 separate
generated modules/tests into one isolated Cargo crate, and passes host compile/run 105/105. Zero-failure closeout
`.3.2.1` finds no repair mechanism. `.3.2.2` makes the proof a strict recurring gate, passes
the complete Rust package and CLI gates, and promotes Rust generated source at census 58/0/2. Dart `.3.3.1` then
adds public compatibility/v1 emitters, stable metadata/errors, strict-UTF-8/Base64 payload embedding, and an
isolated temporary-package analyze/run proof. `.3.3.2` adds exact ten-family direct dispatch, four plan rejections,
portable trace roles, and an isolated all-family matrix. `.3.3.3` adds exact accepted-subset admission and promotes
Dart; the census is 59/0/1 with Julia the sole gap. `.3.4.1` then adds Julia's public compatibility/v1 emitters,
canonical effective-AST serialization, strict-UTF-8/ASCII-hex payload and identity embedding, typed portable
metadata/errors, direct/traced generated entrypoints, and an 18-assertion isolated include/run/corrupt-load proof.
`.3.4.2` then adds exact typed ten-family classification, four plan rejections, family-authoritative per-rule
dispatch, portable trace roles, and one isolated emitted all-family module. `.3.4.3` consumes the exact contract
subset, proves all eight interpreter values before emission, independently loads eight namespaced modules with
exact metadata/plans/trace identity, and promotes Julia. The then-live census was 60/0/0; punctuation-light
admission `.16.7` later advanced it to 64/0/0, and Lua `.8.4` now advances the live census to 80/0/0.

`FUTURE-PARITY-BACKLOG.3.0` turns that broad owner into an executable order. `.3.1.1` first fixes a versioned neutral
contract for emission, host compile/load, direct generated execution, exact result/error/source identity, trace,
family-plan validation, and manifest proof; `.3.1.2` repairs Perl and `.3.1.3.3` admits the aligned Perl/Rust
baseline. `.3.2.0` classifies Rust's full manifest 105/105 green, `.3.2.1` closes the empty repair inventory, and
`.3.2.2` completes strict recurring admission. Dart scaffold `.3.3.1` and exact family/direct execution `.3.3.2`
are closed; `.3.3.3` admits Dart and closes `.3.3`. Julia scaffold `.3.4.1` and family/direct `.3.4.2` are closed;
`.3.4.3` admits the contract-sourced corpus proof. `.3.5` rechecks all four focused proofs and adjacent complete
backend gates, closes `.3` at 60/0/0, and activates Lua planning. Because
the artifacts are host-language source, byte identity is not required; ADR `0023` requires equivalent operations
and observable behavior through idiomatic host APIs.

Contract v1 is checked by `perl tools/check_generated_source_contract.pl` and the canonical local gate. It names
ten family roles, four pre-execution plan-rejection cases, stable generated-source errors, one direct result/trace/
identity fixture, the accepted eight-case subset, and the 105-case primary oracle. Backend-native APIs and source
syntax are expected; semantic roles and observations are not allowed to drift.

Outward compiled descriptors are closed: all four variants expose the exact `spec` / `functions` /
`dependency_regex_map` / `meta` projection, aligned model identities, and the canonical outer function record
defined by `capability_conformance/outward_descriptor_contract.json`.

Structured runtime diagnostics are also closed: every native variant exposes stable stage/detail plus available
spec/top/rule/handler attribution without string scraping; Rust retains its original string methods as adapters.

ADR `0023` sharpens that limitation: Rust exports `source_emitter` publicly, so equivalent source-emission
capability is required before Julia can claim complete user-visible feature parity. Deferral remains valid
scheduling and does not weaken the 105/105 interpreter correctness gate; it does keep the full-parity claim open.

`JULIA-BACKEND-PARITY.1.1` through `.4.2` are complete. `Pkg` and `Test` use the source-bearing repository depot
through `tools/run_julia_project_data.sh`; supported commands no longer write precompile artifacts into an
operating-system temporary root or developer-home depot. The Julia package depends on `JSON3` for manifest and
expected-JSON parsing. Global
`JuliaFormatter` and `JET` packages are not installed today, so formatter/linter commands are optional until a
scaffold or verification leaf commits them as dev dependencies.

Run the complete focused Julia gate from the repository root:

```bash
bash tools/run_julia_local.sh
```

It covers package tests, primary CLI help and retired-subcommand rejection, corpus-runner help, and full 105/105
corpus execution. The shared
core gate remains SDK-independent unless explicitly opted in:

```bash
LINKEDSPEC_RUN_JULIA=1 bash tools/run_ci_local.sh
```

`LINKEDSPEC_JULIA_CMD` and `LINKEDSPEC_JULIA_DEPOT_PATH` select a non-default executable and writable depot.

The current Julia package layout is:

```text
julia/
  Project.toml
  Manifest.toml
  README.md
  src/LinkedSpecJulia.jl
  src/cli/LinkedSpecJuliaCli.jl
  src/corpus/CorpusManifest.jl
  src/spec/Ast.jl
  src/spec/Parser.jl
  src/spec/UserFunctionDefinitionShell.jl
  src/spec/Validator.jl
  src/action/ActionAst.jl
  src/action/ActionParser.jl
  src/action/ActionContracts.jl
  src/action/FunctionRegistry.jl
  src/compiler/CompiledSpec.jl
  src/parser/StagedParserRegistry.jl
  src/parser/UserFunctionDefinitionParser.jl
  src/runtime/Matching.jl
  src/runtime/Interpreter.jl
  src/trace/Trace.jl
  bin/linkedspec_julia.jl
  bin/corpus_runner.jl
  test/runtests.jl
```

The direct command surface is:

```bash
julia --project=julia -e 'import Pkg; Pkg.instantiate()'
julia --project=julia -e 'import Pkg; Pkg.test()'
julia --project=julia julia/bin/linkedspec_julia.jl --help
julia --project=julia julia/bin/linkedspec_julia.jl \
  --inline-spec $'Top::\n /x/\n E { return(hash("b", 2, "a", 1)) }\n' \
  --input x
julia --project=julia julia/bin/corpus_runner.jl --corpus rust/linkedspec-runtime/tests/corpus
julia --project=julia julia/bin/corpus_runner.jl --corpus rust/linkedspec-runtime/tests/corpus --execute
bash tools/check_julia_primary_cli.sh
```

The shown primary parse invocation prints `{"a":1,"b":2}` followed by one newline. Object keys are sorted at
every nesting level, independent of Julia `Dict` insertion order, and the serialized value is the direct top-rule
result rather than the corpus runner's one-level comparison wrapper. Newlines separate the example's statements;
semicolon is needed only between multiple statements on one physical line.

Operational failures have one of these first lines and exit `1`:

```text
linkedspec: parser compilation failed
linkedspec: input load failed
linkedspec: parser invocation failed
```

When a runtime failure carries structured context, stderr continues in stable order with the available
`owner_stage`, `summary`, `detail`, `spec_name`, `spec_path`, `top_rule`, and `rule_label` fields, then an `error:`
line. Compilation completes before `--input-file` is read, so an invalid spec is reported before a simultaneously
missing input file. Argument/selector/mode errors remain usage failures with exit `2` and the usage text.

Trace routing is independent of canonical result generation:

| Controls | stdout | trace file |
| --- | --- | --- |
| `--trace high` | trace, then JSON | none |
| `--trace high --trace-file run.log` | JSON only | trace (implicit `route`) |
| add `--trace-mode mirror` | trace, then JSON | the same trace bytes |
| add `--trace-mode stdout` | trace, then JSON | unchanged; truncated first only with `--trace-reset` |
| `--trace-mode route` without a file | JSON only | none; trace is discarded |

`--trace-reset` truncates a selected file before compilation even when the selected mode is `stdout` or the trace
level is `none`. `--trace-emoji` adds level-specific `🛑` / `ℹ️` / `🔎` / `🧭` / `🐞` / `🔥` prefixes to emitted
events; it does not cause a quiet trace level to emit.

The corpus commands validate `manifest.json`, case-count/name shape, missing/stale fixture directories, required
`input.spec` / `input.txt` / `expected.json` files, and expected JSON syntax over the checked-in 105-fixture corpus.
Bare `--execute` runs the complete manifest; named, offset, and limit selections remain available for diagnostics.
`julia/src/spec/Ast.jl` defines data records and JSON projection for
spec files, function definitions, source spans, staged parse jobs, rule headers/modes, body element variants, edge
targets, and fluent calls. `julia/src/spec/Parser.jl` exposes `parse_spec(...)`, which parses core `.spec` rule
paragraphs into those source AST types: headers/modes, regex slots, lifecycle blocks, action/blind-call edges,
fluent continuations, markers, comments, and block boundaries. `julia/src/spec/Validator.jl` exposes
`validate_spec(...)`, which validates parsed source ASTs for top-rule presence, duplicate labels/functions,
function registry collisions and reserved params, raw fallback lines, mixed edge families, grouped action blocks,
undefined references, regex-slot bounds, regex structure, and strict unused-rule behavior.
`julia/src/spec/UserFunctionDefinitionShell.jl` consumes the `function_definition` / `function_definition_error`
node shape produced by `specs/user_function_definition.spec`, validates source/body spans and staged sidecars,
normalizes `functions.<index>.body_source` parse-job paths, and strips function spans before rule parsing.
`julia/src/parser/UserFunctionDefinitionParser.jl` now exposes `parse_user_function_definition_asts(...)` and
`parse_spec_with_staged_user_function_definitions(...)`; these execute the checked-in definition spec over source
in memory, then reuse that projection. Direct `parse_spec(...)` remains rule-only rather than a Julia raw scanner.
`julia/src/action/ActionAst.jl` and
`julia/src/action/ActionParser.jl` expose `parse_action_block(...)`, `parse_action_statement(...)`, and
`parse_action_expression(...)` for typed helper/action structures: blocks, value-drop statements, calls, literals,
variables, direct/nested access, shape literals, assignments, receiver chains, trailing block arguments, block
values, structured controls, and raw fallback nodes. `julia/src/action/ActionContracts.jl` exposes
`resolve_action_block_contracts(...)`, `resolve_action_statement_contracts(...)`,
`resolve_action_expression_contracts(...)`, `canonical_action_helper_name(...)`, and
`is_known_action_ir_call_name(...)` for canonical helper/control contract records and generic
unknown-helper/raw diagnostics over those typed nodes. `julia/src/action/FunctionRegistry.jl` exposes ordered
`UserFunctionRegistry` entries, staged function-body parse-job queues, exact-arity user-call resolution, duplicate
name diagnostics, JSON projection, and immutable `body_ast` stitching; `ActionContracts.jl` can use that registry to
classify exact-arity user calls before helper fallback and diagnose wrong registered arities.
`julia/src/compiler/CompiledSpec.jl` exposes `compile_spec(...)`, `CompiledSpec`, `CompiledRule`,
`CompiledDependencyRegexState`, and `CompiledDescriptorState` for ordered compiled-rule state, dependency refs,
dependency-regex rows, mode metadata, lifecycle/action payload ASTs with registry-aware contracts, function registry
projection, and descriptor-shaped JSON with `julia_interpreter_rule` handlers marked `compiled_state_only`.
`parse_spec(...)`, `validate_spec(...)`, `compile_spec(...)`, function-shell projection/parsing, staged job
execution/stitching, and runtime execution accept the same optional caller-owned `LinkedSpecTraceEmitter`. Omitted
or disabled tracing is quiet; enabled low/medium events report balanced operation scopes and phase decisions through
the existing stdout/route/mirror/reset sink controls without changing spec, descriptor, or parse results.
`julia/src/runtime/Matching.jl` compiles stable zero-based regex alternatives and supports seek/consume selection,
full and compact capture vectors, named captures, zero-based code-unit spans, public character offsets,
line/column projection, cursor/capture anchors, separate entry/local match registers, and zero-progress detection.
Julia's native PCRE engine accepts the required named-capture, POSIX, flag, possessive, and recursive constructs
without a dialect-rewrite layer. `julia/src/runtime/Interpreter.jl` exposes `LinkedSpecRuntimeEngine`,
`runtime_parse(...)`, `runtime_execute(...)`, result/lifecycle/error records, and first execution over compiled
default/AND/OR/repetition families. It runs lifecycle order, action/blind children, `retv`, explicit returns,
narrow array/rule accumulators and capture reads, output projection, repetition bounds, zero-progress cutoffs, and
recursion guards in seek or consume mode. `.4.3.0` splits the broader evaluator into `.4.3.1` core
stores/captures, `.4.3.2` string/numeric,
`.4.3.3` array, `.4.3.4` hash, `.4.3.5` value/control/block/callback, and `.4.3.6` no-drift leaves. `.4.3.1` is now
implemented: scalar/array/hash stores, bare and typed snapshots, structural assignments/access, checked
no-autovivification nested writes, and entry/local capture maps/positions pass focused tests. `.4.3.2` is now
implemented too: current string/scalar and numeric helpers share canonical function/receiver dispatch, retain
regex flags, normalize JSON numbers, and return `nothing` for invalid arithmetic. `.4.3.3` is now implemented as
well: copied array helper/receiver pipelines, regex and split bridges, explicit flatten splicing, numeric reducer
terminals, typed split replacement, and updated-value end mutations pass focused tests. `.4.3.4` is now
implemented too: copied hash views and pure transformations, compatible receiver chains, statement-only named
set-key mutation, direct hash-index assignment, merge-slot resolution, explicit flat-style splicing, and nested-map
preservation pass focused tests. `.4.3.5` is now implemented too: expression-valued blocks with local returns,
attached/marker/inline controls, deterministic while guards, immediate helper/receiver with-blocks, scoped binding
restoration, and hash/array walk/map/reduce callbacks pass focused tests. `.4.3.6` owns final helper/value no-drift.
The closeout confirms runtime tests/status, mdBook contracts, live docs, and fact cards agree at 567
assertions; package status remains `runtime-value-control-tree`, and no runtime correction was required. `.4.4`
adds explicit LIFO cursor save/restore, entry/local anchor rewinds, character-based cursor/input helpers, and
earliest usable non-consuming boundary capture. Full tests pass with 581 assertions and status
`runtime-cursor-boundary`. `.4.5.0` splits diagnostics/trace into structured diagnostics, trace
controls/events/sinks, runtime instrumentation, and no-drift. `.4.5.1` implements exported neutral-field
diagnostic payloads on runtime exceptions while preserving successful output and richer child attribution.
`.4.5.2` implements trace levels/environment/config, event primitives, stdout/route/mirror sinks, parse-scope
routing, and traced entrypoints with default-quiet output preservation. `.4.5.3` implements internal rule, regex,
dispatch, lifecycle, recursion, cursor, and boundary events; `.4.5.4` closes final no-drift without a source
correction. `.5.1` is implemented through `julia/src/parser/StagedParserRegistry.jl`; `.5.2` now executes
registered user functions through `julia/src/runtime/Interpreter.jl`. It evaluates args before entering a fresh
scalar/array/hash store set, restores caller stores in `finally`, returns the final expression or first local
`return(...)`, composes compatible receiver chains, drops standalone results, and diagnoses exact-arity and
direct/mutual recursion failures. `.5.3` locks the neutral descriptor shape through runtime without a production
projection correction. `.6.1` adds the controlled corpus library surface described below; package status is now
`runtime-controlled-corpus`, and the full suite passes with 715 assertions. `.6.2.0` splits the manifest rollout
before behavior changes; `.6.2.1` bounded library/runner selection and reporting is active.

### Julia Controlled Corpus Execution

`execute_corpus_fixtures(...)` is the first executable Julia corpus surface. It deliberately composes existing
owners instead of creating a second parser or runtime:

1. `load_corpus_fixtures(...)` validates the format-1 manifest and loads every named fixture.
2. Each `input.spec` is parsed, validated/compiled, and executed by `LinkedSpecRuntimeEngine`.
3. Runtime `output` is compared structurally with the expected JSON wrapped exactly once.
4. Every fixture produces a result, even when earlier fixtures fail.

The one-level wrapper is important. If `expected.json` contains:

```json
{"body":" text ","cursor":10}
```

the required engine output is:

```json
[{"body":" text ","cursor":10}]
```

This matches the backend-neutral convention that the top-rule value occupies one output item. The fixture result
still exposes both `actual_value` (the object itself) and `actual_output` (the wrapped list).

A minimal controlled fixture directory looks like this:

```text
controlled-corpus/
  manifest.json
  boundary/
    input.spec
    input.txt
    expected.json
```

For example, `input.spec` can capture text up to a structural boundary:

```text
Top::
 /BEGIN/
 E {
   body = capture_until_boundary(Boundary)
   return(hash("body", body, "cursor", cursor_pos()))
 }

Boundary: /END/
```

The two statements in the multiline `E` block are separated by the newline. No line-ending semicolon is used:
semicolon is only an infix separator between adjacent statements on the same physical line.

Execute the corpus from Julia code:

```julia
using LinkedSpecJulia

execution = execute_corpus_fixtures("controlled-corpus")
println("passed: ", corpus_passed_count(execution), "/", length(execution.results))

for failure in corpus_failures(execution)
    println(failure.name, ": ", failure.failure)
end
```

For a traced controlled run:

```julia
execution = execute_corpus_fixtures(
    "controlled-corpus";
    trace_config = trace_config_enabled(LinkedSpecTraceDebug),
)

boundary = corpus_fixture_result(execution, "boundary")
for line in boundary.trace_lines
    print(line)
end
```

`CorpusFixtureExecutionResult` retains:

- fixture name and decoded expected JSON;
- actual value and wrapped output when runtime reached a result;
- match state and zero-based code-unit cursor;
- captured rendered trace lines when tracing was enabled;
- the structured `RuntimeDiagnostic` when execution produced one;
- failure text, or `nothing` on success.

Failure records distinguish parse, validation, compile, execute, no-match, output-mismatch, and unexpected
boundaries. `corpus_execution_passed(...)`, `corpus_passed_count(...)`, `corpus_failures(...)`,
`corpus_fixture_passed(...)`, and `corpus_fixture_result(...)` provide the common queries.

The optional `spec_parser` keyword remains a controlled parser-override seam. Ordinary calls try direct rule-only
`parse_spec(...)` first. If source parsing fails, the default path executes the checked-in user-function definition
spec and feeds its neutral nodes through staged body parsing. The three routed top-level function fixtures pass,
and the complete checked-in corpus is now 105/105 green after final exhaustive capability admission.

Native callers can use the source-driven composition directly:

```julia
using LinkedSpecJulia

spec_source = raw"""
fn normalize(value) { return(trim(value)) }

Top::
 /x/
 E {
   return(normalize(" ok "))
 }
"""

spec = parse_spec_with_staged_user_function_definitions(spec_source)
compiled = compile_spec(spec)
result = runtime_execute(LinkedSpecRuntimeEngine(compiled), "x")

println(result.output)
```

`parser_spec_source = ...` may be supplied when an embedding application keeps an alternate compatible definition
spec in memory. The default resolves the repository-owned `specs/user_function_definition.spec`; neither path
requires a subprocess or a raw Julia function scanner.

#### Selecting bounded Julia corpus runs

Library callers can execute named fixtures in caller-supplied order:

```julia
execution = execute_corpus_fixtures(
    "rust/linkedspec-runtime/tests/corpus";
    case_names = ["proof_edge_array_literal", "proof_edge_hash_literal"],
)
```

Or select a zero-based manifest window:

```julia
execution = execute_corpus_fixtures(
    "rust/linkedspec-runtime/tests/corpus";
    offset = 0,
    limit = 10,
)
```

Named selection rejects missing and duplicate names and cannot be mixed with a window. Windows reject negative or
non-integer offsets, non-positive or non-integer limits, and offsets outside the manifest. A limit larger than the
remaining fixture count stops at the manifest end.

The corpus runner exposes the same bounded surface:

```bash
julia --project=julia julia/bin/corpus_runner.jl \
  --corpus rust/linkedspec-runtime/tests/corpus \
  --execute --case proof_edge_array_literal

julia --project=julia julia/bin/corpus_runner.jl \
  --corpus rust/linkedspec-runtime/tests/corpus \
  --execute --offset 0 --limit 10
```

Each selected fixture prints `PASS <name>` or `FAIL <name>: <detail>`, followed by a summary. Exit status `0` means
all selected fixtures passed, `1` means at least one selected fixture failed, and `2` means argument, manifest, or
selection validation failed. Options also accept `--flag=value` form, and `--case` may be repeated.

Omitting `--execute` validates the complete manifest. Bare `--execute` runs all 105 fixtures; offset-only execution
runs from that offset through the manifest end. Selecting a subset never bypasses complete manifest drift checks.

The rollout is explicitly recoverable. `.6.2.1` has landed named and bounded selection/reporting; `.6.2.2` proves
starter fixtures 0–39 green at 40/40; `.6.2.3` proves the surrounding non-function helper/control fixtures 40–67
green at 25/25 while routing three top-level function fixtures; `.6.2.4.0` measures shipped-spec/parser-smoke
fixtures 68–98 at 10/31 and splits their mechanism owners; `.6.2.4.1` then closes anonymous capture execution and
moves the window to 13/31. `.6.2.4.2.1` then adds eager logical helpers and moves it to 17/31 while routing one
helper-regex flag residual; `.6.2.4.2.3` then closes it and moves the window to 18/31. `.6.2.5` has since closed
the spec-defined top-level function shells, and final capability admission has expanded the full-manifest gate to 105/105.
Those are workload boundaries, not an assumption that Julia shares Dart's historical failure causes.

#### Julia starter corpus proof

The first shipped window is a permanent package regression:

```bash
julia --project=julia julia/bin/corpus_runner.jl \
  --corpus rust/linkedspec-runtime/tests/corpus \
  --execute --offset 0 --limit 40
```

It reports 40 passes and zero failures, from `proof_edge_array_literal` through
`terse_2_2_5_2_attached_switch_blocks`. This proves the early proof-edge, autoexist, bare read/copy, assignment/
mutation, primitive, shape, block, and attached-control families against the checked-in expected JSON. No Julia
runtime correction and no fixture change was required. The package test locks the manifest count, both endpoints,
selected count, passed count, and empty failure ledger so later changes cannot silently lose that coverage.

The 40/40 result does not imply that later windows pass. The next proof closes the surrounding middle window.

#### Julia middle corpus proof

The middle non-function fixtures are permanent package regressions across three disjoint windows:

```bash
julia --project=julia julia/bin/corpus_runner.jl \
  --corpus rust/linkedspec-runtime/tests/corpus --execute --offset 40 --limit 17
julia --project=julia julia/bin/corpus_runner.jl \
  --corpus rust/linkedspec-runtime/tests/corpus --execute --offset 58 --limit 2
julia --project=julia julia/bin/corpus_runner.jl \
  --corpus rust/linkedspec-runtime/tests/corpus --execute --offset 62 --limit 6
```

The windows report 17/17, 2/2, and 6/6, for 25 passes and zero failures across helper, control, receiver,
assignment, with-block, and tree traversal behavior. No Julia runtime correction and no fixture change was
required. Manifest offsets 57, 60, and 61 are explicitly routed as
`terse_3_3_1_scalar_assignment_expressions`, `terse_3_3_4_assignment_expression_closure`, and
`terse_4_3_2_user_function_runtime`; their top-level `fn` source is now executed by `.6.2.5` through
`specs/user_function_definition.spec` and the existing staged body parser. The package regression locks all three
windows, their endpoints and counts, the empty failure ledger, and those exact routes; a separate three-case
regression now locks their exact outputs too.

#### Julia shipped-spec/parser-smoke split

The full final non-function window is measured before implementation:

```bash
julia --project=julia julia/bin/corpus_runner.jl \
  --corpus rust/linkedspec-runtime/tests/corpus --execute --offset 68 --limit 31
```

The initial result is 10 passes and 21 failures. Julia already passes both tclite cases, Lispish, both raw hlink
cases, portmap slice, regdef, VHDL library use, and the empty plugin/library smokes. The failures are split before
source changes:

- `.6.2.4.1` adds anonymous capture-boundary helpers and closes all three hlink delimiter cases. EBNF logging
  advances to the structural-output group under `.6.2.4.4`.
- `.6.2.4.2.1` owns logical helpers blocking four portmap cases and tablegrep; `.6.2.4.2.2` owns diagnostic-output
  helpers blocking simenv and history.
- `.6.2.4.3` owns three already-executing recursive top-rule output mismatches.
- `.6.2.4.4` owns EBNF/spec.spec structural outputs and must split again if independent mechanisms emerge.
- `.6.2.4.5` owns two lib_reader quote-normalization mismatches; `.6.2.4.6` later owns and closes final 31/31
  no-drift.

The checked-in expected JSON remains the Perl/Rust oracle. Dart's completed shipped-smoke facts are useful
mechanism references, but Julia leaves establish their own root causes rather than copying Dart's historical path.

The direct anonymous capture family now uses Julia's existing rule-local match register. `start_capture_slice()`
sets the origin; `capture_slice*` reads to the current match start, `*_until_cursor*` reads to the live cursor, and
`*_rest*` reads to input end. Location readers are character-based, and `capture_take*` advances the origin only
after a valid read. Focused Unicode/newline tests lock endpoint, length, position, line/column, and destructive
behavior. All three hlink delimiter fixtures pass; a permanent corpus regression preserves them and ensures EBNF
logging is routed as an output mismatch rather than an unsupported helper. At that boundary, the window is 13/31
and package status is `runtime-corpus-capture-boundaries`.

Julia logical `and`/`or`/`not` are eager value helpers: all arguments evaluate before truthiness composition. They
are not lazy branch constructs in this backend; use `if`/`switch` when skipped branches must remain unevaluated.
Julia applies its existing scalar/number/string/aggregate truthiness and Rust-compatible
empty arities (false/false/true). Three portmap cases plus tablegrep pass. `portmap_constant` reaches output
comparison but remains `?bare:` because helper `matches(..., /^\d/io)` passes Perl's no-op `o` flag to Julia
`Regex`; `.6.2.4.2.3` owns that precise compatibility bridge.

Helper regex literals now spend one strict compiler seam: `i`, `m`, `s`, and `x` reach Julia `Regex`; execution-
only `g` and Perl compile-once `o` are compile-time no-ops; unknown flags and invalid patterns still fail closed.
Both `matches(...)` and regex-delimiter `split(...)` use the seam. Portmap constant passes exact checked-in output,
and the window is 18/31 at that boundary.

At the historical `.6.2.4.2.2` boundary, diagnostic `print(...)` and `say(...)` concatenated evaluated values,
with `say(...)` adding a newline; `print_each(...)` walked an array with optional prefix and suffix text. Julia
then emitted these messages through a configured low-level trace sink, returned no parse value, and remained
quiet when tracing was absent or disabled. `simenv_multiline_value` reached unsupported `exit_now`, and
`ds_vhistory_version_entry` reached the known leading-trivia output mismatch. The permanent regression rejects
renewed unsupported-`print` failures. The full window remained 18/31, full tests passed with 780 assertions, and
status was `runtime-corpus-diagnostic-output`; later leaves closed both residuals. Current Julia diagnostic output
uses ADR `0042`'s separate caller-owned typed event sink and never low trace.

Recursive rule calls now carry a first-reset binding snapshot for explicit `set(array(...), ...)`,
`set(hash(...), ...)`, and explicit split-target replacement. Child exit restores the caller's prior typed binding,
while ordinary undeclared `push(...)`/append mutations remain caller-visible; registered user functions retain
their separate whole-store isolation. This closes the body-recursive, nested top-LX, and top-LX sequence fixtures.
The full window is 21/31, full tests pass with 785 assertions, status is
`runtime-corpus-recursive-rule-scope` at that boundary.

Action-edge child-push forms now give a compiled-rule first argument child-call precedence and reuse the current
edge's cached child result. `push(Child)`, `push(Child, target)`, `push(Child, index)`, and
`push(Child, target, index)` append whole or zero-based indexed values without re-searching the consumed token.
All four spec.spec smokes pass. Both EBNF cases now retain complete structures and are locked at quote-only
statement-mutation residuals under `.6.2.4.5.2`. The full window is 25/31, full tests pass with 793 assertions,
status is `runtime-corpus-action-edge-child-push` at that boundary.

`exit_now(...)` now terminates Julia parser flow immediately. Its optional first argument is evaluated as a
numeric status, with absent or nonnumeric status defaulting to `1`; the thrown runtime exception includes the
current rule and retains the established structured top/rule/spec diagnostic attribution. Simenv now executes
`exit_now(1)` in `begin_end_blocks`, proving the control helper while exposing its earlier statement-form
`substr(...)` mutation prerequisite. The full window remains 25/31, full tests pass with 801 assertions, status is
`runtime-corpus-exit-now` at that boundary.

Statement-context four-argument `substr(...)` / `regex_subst(...)` now mutates a bare Julia scalar target before
pure helper fallback. The strict helper compiler preserves `i`/`m`/`s`/`x`, applies global `g`, accepts no-op `o`,
and replacement text expands `$n` captures. Numeric `substr(value, start, width)` remains pure even when discarded.
Both EBNF, both lib_reader, and simenv fixtures now pass exact oracle output. The full window is 30/31, full tests
pass with 808 assertions, and status is `runtime-corpus-statement-mutation` at that boundary.

Julia's public in-memory `runtime_parse(...)` entrypoint now begins after only leading blank lines and leading `#`
comment lines, matching the Perl wrapper and Dart backend. A focused minimal proves the history boundary while an
ordinary scalar-held `payload[1]` still returns its indexed item. `ds_vhistory_version_entry` passes. The final
no-drift leaf adds one permanent complete-window test; the complete shipped-spec window is 31/31. Spec-driven
function-definition parsing then closes the three routed top-level function fixtures without a raw Julia scanner.
The full-manifest gate now executes all 105 fixtures in order with exact output and zero failures. Full tests pass
with 1,040 assertions and status is `runtime-corpus-primary-cli`.

### Dart Backend Commands

Run the focused Dart gate from the repository root:

```bash
bash tools/run_dart_local.sh
```

That command runs Dart formatting, analyzer checks, all 160 Dart tests,
shared Dart primary-CLI help, a bounded corpus-runner smoke, 61/61 default, 61/61 POSIX, and full 105-fixture corpus
execution. To include Dart in
the canonical local gate on a machine with a Dart SDK, opt in explicitly:

```bash
LINKEDSPEC_RUN_DART=1 bash tools/run_ci_local.sh
```

Direct Dart commands live under `dart/`:

```bash
bash ../tools/run_dart_project_data.sh test
bash ../tools/run_dart_project_data.sh run bin/linkedspec_dart.dart --help
bash ../tools/run_dart_project_data.sh run bin/linkedspec_dart.dart --spec Lispish --input '(hello world)'
bash ../tools/run_dart_project_data.sh run bin/corpus_runner.dart --corpus ../rust/linkedspec-runtime/tests/corpus --execute
```

Current Dart parity is interpreter-first and corpus-green. `DART-BACKEND-PARITY.7.2`
deliberately defers generated Dart source to a future source-emitter lane with its
own scaffold, generated family plan, direct structural-family execution proof, and
curated corpus subset. Dart's backend-local corpus CLI implementation closed in
`DART-BACKEND-PARITY.7.4`, and `DART-BACKEND-PARITY.7.5` closed the scoped
Dart milestone. The later strict-interface audit recorded the old primary command at 0/61.
`FUTURE-PARITY-BACKLOG.1.5.3.1` now passes the exact 29-case argument/loading/failure subset in both
default and POSIX environments while preserving `bin/corpus_runner.dart`. The new boundary is case-sensitive,
non-abbreviating, positional-free, strict UTF-8, deterministic for named/file/inline source resolution, and
compile-before-input phase ordered. `.1.5.3.2` now composes the existing staged parser, validator/compiler,
direct-value runtime, top-rule/global-mode controls, and recursively canonical JSON. `.1.5.3.3` adds the portable
CLI trace independently of rich Dart tracing and reaches 61/61 in both environments; `.1.5.3.4` makes both legs
recurring, proves the broader gate, and closes the Dart primary-command parent.

Dart
also has source-level AST/data types and staged parse-job sidecars that round-trip
through JSON with the Rust/mdBook field names. The Dart core `parseSpec(...)`
parser now produces those source AST types for rule paragraphs, headers/modes,
regex literals, lifecycle blocks, action/blind-call edges, fluent continuations,
markers, comments, and nested block boundaries, with tests over all checked-in
`specs/*.spec` files and rule-only corpus specs. Dart `validateSpec(...)` then
checks top-rule presence, duplicates, source-AST edge consistency, target
references/indexes, regex structure, malformed raw body lines, and strict-mode
unused rules. Dart also has the first function-shell projection layer:
`parseSpecWithUserFunctionDefinitionAsts(...)` consumes the
`function_definition` / `function_definition_error` nodes returned by
`specs/user_function_definition.spec`, validates source/body spans and staged
`body_payload` / `body_parse_job` sidecars, normalizes source-order parent paths
and parse-job ids, strips returned definition spans before rule parsing, and
attaches ordered `FunctionDefinition` records. This is not a Dart raw scanner for
`fn` source. The corpus runner now obtains the semantic node list by executing
`specs/user_function_definition.spec` through Dart runtime shell code and then
feeds those nodes through staged function-body projection.

Dart now also has a typed ActionIR parser seam. `parseActionBlock(...)`,
`parseActionStatement(...)`, and `parseActionExpression(...)` produce structural
nodes for helper/action code: action blocks, value-drop statements, calls,
positional and keyword arguments, primitive and regex literals, variables,
indexed/nested access, array/hash shape literals, scalar/array/hash/nested
assignments, expression-valued blocks, attached `if`/`when`/`elseif`/`else` /
`otherwise`, `while`, `switch`/`case`/`default`, receiver-dot fluent chains, and
trailing block arguments. Unsupported expressions remain explicit `raw_perl`
nodes for diagnostics. Dart also has ActionIR contract resolution:
`resolveActionBlockContracts(...)`, `resolveActionStatementContracts(...)`, and
`resolveActionExpressionContracts(...)` walk the typed nodes and record current
canonical helper/control contracts for calls, receiver methods, structural
assignments, controls, nested arguments, block values, shapes, and access
expressions. Non-current helper-looking calls produce generic diagnostics rather
than host-language fallback. Dart also has the first user-function registry seam:
`UserFunctionRegistry.fromSpec(...)` / `fromFunctions(...)` preserve ordered
`FunctionDefinition` records, expose their staged function-body parse jobs, keep
`body_payload`, `body_parse_job`, and any stitched `body_ast`, and let the ActionIR
contract resolver classify exact-arity user-function calls before helper fallback.
Wrong-arity registered calls diagnose as user-function arity errors.

Dart now also has the minimal staged parser registry in
`dart/lib/src/parser/staged_parser_registry.dart`. `executeStagedParseJobs(...)`
normalizes and stable-sorts jobs by parent AST path, source span, and job id,
resolves `actionir-body.spec` to `builtin:actionir-body.spec`, loads the fixed
built-in adapter digest, compiles top rule `action_block`, and executes the body
text through Dart's ActionIR block parser. `dispatchFunctionBodyParseJobs(...)`
and `parseSpecWithStagedUserFunctionDefinitionAsts(...)` stitch the returned
`action_block` JSON into each function definition's `body_ast`. This is still
the narrow function-body provider, not general public `parse_job(...)` authoring
or recursive staged queues.

Dart now also has a compiled-state model in `dart/lib/src/compiler/compiled_spec.dart`.
`compileSpec(...)` validates source ASTs by default and returns `CompiledSpec`
state with `definition_order`, `compiled_rule_order`, `rules_by_label`,
`redefined_rule_labels`, carried user-function registry data, per-rule regexes,
dependency refs, mode metadata, action/blind edges, lifecycle/plain/edge
`ActionBlock` payloads, and registry-aware ActionIR contract results. Its
`CompiledDependencyRegexState` derives structured child-regex dispatch data, and
`CompiledDescriptorState` projects the public descriptor shape with `spec`,
`functions`, `dependency_regex_map`, and `meta`.

Dart now has the first runtime matching layer in `dart/lib/src/runtime/matching.dart`.
`RuntimeRegexAlternation` consumes ordered compiled-rule regex lists and supports
`seek` versus `consume` matching while preserving stable alternative indexes.
`RuntimeRegexMatch` records capture-only groups, named captures, code-unit spans,
char-offset and line/column projections, and zero-width/progress checks.
`RuntimeMatchRegisters` keeps entry and local match state separate for child
dispatch and tracks the parser cursor.

Dart also has the first runtime rule interpreter in `dart/lib/src/runtime/interpreter.dart`.
`LinkedSpecRuntimeEngine` consumes `CompiledSpec` state and executes default,
AND, OR, and repetition rule families with action-edge and blind-call child
dispatch, entry/local match handoff, lifecycle blocks, explicit returns, `retv`,
accumulator collection, bounded repetition, zero-progress cutoffs, and recursion
cutoffs. Normal runtime entry now derives cursor discipline and structural
composition directly from the entered rule: AND consumes and sequences, while
OR/default seeks and chooses. A nested action edge, blind edge, direct call, or
recursive call re-enters through the child rule and therefore cannot inherit the
parent's cursor policy. The same derivation is used by in-memory, loaded, and
normalized-`SpecFile`-JSON execution, and rule trace scopes expose the policy
spent at each entry. Generated-source v1 remains behind its explicit global/
compact-pipe compatibility adapter until Dart generated-source v2 migration.
Its core ActionIR evaluator now also preserves scalar, array, hash,
null, boolean, and number shapes through assignment and wrapper snapshots;
supports `array(...)`, `hash(...)`, `copy(...)`, `set(hash(...), ...)`,
hash-index mutation, nested reads, non-numeric map keys, regex literals as
values, and nested value-path assignment with no-autovivification failure
behavior; and exposes the named/map/length/start/end `entry_*` / `match_*`
capture helper family. It now also executes current string/scalar helpers,
explicit `str_*` lexical comparisons, numeric arithmetic/reducer/comparison
helpers, numeric word aliases, arithmetic/comparison symbol callees, and
compatible string/number receiver chains. It also executes array helper family
breadth, bare array working-variable receiver chains, regex split/filter
bridges, delimiter-first `join_values`, array numeric reducers, and
updated-value array end mutations. It also executes hash helper family breadth,
bare hash working-variable receiver chains, statement/value mutation boundaries,
direct hash-index assignment values, bare typed base/overlay `merge_hash`, and explicit
flat-style hash splicing inside `hash(...)`. It also executes expression-valued
blocks with block-local `return(...)`, attached and inline structured controls,
helper/receiver `with` trailing blocks, and hash/array tree traversal receiver
callbacks with scoped callback bindings. It also treats empty array/hash returns
as successful non-null rule matches, uses child-rule match bits for blind
dispatch, and executes marker-form `if(...)` / `elseif(...)` / `else()` /
`endif()` statement chains as grouped branches. It also preserves assignment
expressions inside helper arguments, supports plain fallback values in inline
`if(...)`, evaluates single-argument numeric aggregate reducers through
aggregate-aware reads, and follows scalar-held list/map readback for
bare `name` and `copy(name)` through that same typed value. It now also executes explicit cursor
controls: `save_cursor()` / `restore_cursor()` for stack-based cursor restore,
`rewind_match_start()` / `rewind_entry_start()` for lifecycle-anchor rewinds,
`capture_until_boundary(rule[, ...])` for non-consuming structural boundary
capture, and char-based cursor/input helpers such as `cursor_pos`,
`cursor_rest`, `input_slice`, and `input_end_pos`. Dart runtime failures now
carry a structured `RuntimeDiagnostic` on `RuntimeInterpreterException`, with
the neutral diagnostic fields `type`, `stage`, `owner_stage`, `summary`,
`detail`, `top_rule`, `rule_label`, `handler_source_label`, and optional
`spec_name` / `spec_path`. Successful parse output remains unchanged.
Dart now also has the trace-control layer: ordered trace levels,
`LinkedSpecTraceConfig`, structured event/scope primitives, stdout/routed-file/
mirror sinks with reset/truncate behavior, and `parseWithTrace(...)` /
`executeWithTrace(...)` entrypoints that preserve parse output while emitting a
parse-scope event. Dart runtime tracing now also emits rule scopes, regex
match/no-match decisions, action/blind child-dispatch decisions, lifecycle block
marks, cursor-control marks, recursion-cutoff decisions, and
`capture_until_boundary(...)` source-boundary marks while keeping untraced
execution output-compatible. The diagnostics/trace no-drift sweep is closed.
Dart also executes registered exact-arity user-function calls before helper
fallback: arguments are eager in the caller, params bind into fresh
function-local scalar/array/hash stores, results come from the final expression
or local `return(...)`, receiver chains can continue from returned values,
standalone calls discard their results, and direct/mutual recursion is
diagnosed. Dart also preserves staged user-function descriptor shapes across
parsed functions, compiled registry jobs, descriptor records, and runtime output.
Dart cursor descriptor v1 is also current: root metadata identifies
`linkedspec-rule-local-cursor-v1`, and each rule projects authored family,
derived cursor policy, normalized ownership, and exact ordered semantic edge
rows from compiled state. Direct, normalized `SpecFile`-JSON, and file-loaded
projections agree; the descriptor carries no independent cursor field and has
no decoder that could override runtime behavior. Generated-source v2 is now
current too: fresh emitted modules retain only ordered label/family rows, derive
all ten cursor/structure policies, and reject v1 before payload reconstruction
with exact contract identities and `.spec` regeneration guidance.
Dart's public execution boundary is now rule-local too. `LinkedSpecRuntimeEngine(compiled)`,
`loaded.createEngine()`, corpus execution, and the staged function parser expose no caller-global mode. The
primary command omits the option and request-trace field, while retired `--parse-mode` invocations return the
exact structural-migration usage error. One exact 15-role consumer now composes native, normalized, loaded,
descriptor, emitted/generated, trace, mixed/recursive, structural, removal, primary, and all portable diagnostic
roles once. Complete Dart cursor proof is 271 package tests; its 65-case admission plus the repeated-action
recurring projection now cover the current 66-case primary manifest in both
environments, and 105/105 corpus fixtures. Neutral governance was 67 files, 4 complete / 4 pending, and 39
mutations at Dart admission; parent `.9.1.5` is closed.

Julia's first cursor-convergence slice is now current at the typed frontend/compiler boundary. `RuleMode("Pipe")`
is OR/default rather than AND, while compact `&` remains AND; `rule_family(...)` and `cursor_policy(...)` expose
the immutable derivation. The parser retains complete-line or header-rest bare references as
`BareEdgeBodyElementKind`, including nullable authored indices, target groups, blocks, fluent chains, source text,
and forward declarations. Lifecycle tokens keep lexical priority, and indexed explicit blind calls retain their
index long enough to fail validation instead of silently losing the suffix. Whole-spec validation derives blind
ownership for bare AND members and action ownership for bare OR/default members, rejects the six governed invalid
forms with exact portable stage/code/fields, and compiled state lowers valid bare members into its existing typed
blind/action tables. The contract-driven Julia suite passes 353 assertions over all 36 family rows, all 18 edge
rows, all six ownership sets, JSON roundtrips, and physical-line boundaries. Runtime `.9.1.6.2` now adds 104
execution assertions across all 36 families on live/normalized routes, all eight parent-child mechanisms, both
structural replacements, loaded-default execution, recursion, and trace attribution. Normal AND consumes and
sequences; OR/default seeks and chooses; every child entry rederives. Descriptor `.9.1.6.3` is cursor v1: root metadata
has no global mode, and each rule projects normalized family, derived policy, ownership, and exact ordered
ownership/target/child-index/block/fluent rows. Direct, normalized `SpecFile`-JSON, and loaded descriptor bytes
agree across a focused 809-assertion suite, including all valid and invalid neutral edge cases. Generated-source
`.9.1.6.4` now emits v2/format 2 with the same minimal label/family plan, derives all five seek/five consume
policies, rejects v1 before payload reconstruction, and removes the private v1 adapter. Public option removal
`.9.1.6.5` now removes engine state plus engine/loader/corpus/primary overrides. Legacy dynamic API spellings fail
before input/user code with `prepare_options/parse_mode_override_removed`; the primary flag fails at usage exit 2,
help and request trace omit the field, and `--top-rule` remains independent. Low-level seek/consume matcher
primitives remain. One exact 15-role consumer now composes native, normalized, loaded, descriptor, emitted/
generated, trace, mixed/recursive, structural, removal, primary, and diagnostic roles once. Complete Julia passes
3,291 package assertions, the ten-family real-process checker, the shared 66-case primary manifest twice, and
105/105 corpus fixtures. Neutral governance is 67 files, 5 complete / 3 pending, and 44 mutations. Cursor parent
`.9.1.6` is closed.
Dart corpus parity has started with controlled manifest fixtures and now has safe
named/bounded execution selection for shipped-corpus batching. The first 40
manifest fixtures, the non-`fn` middle fixtures, and the three top-level `fn`
fixtures pass in bounded execute mode.
The remaining shipped-spec/parser-smoke window is split after a diagnostic run
and is now 31/31 green. The basic regex-dialect bridge, helper/action bridge,
recursive/default-mode parser-smoke bridge, portmap result-shape bridge, and
hlink delimiter/capture bridge are done; the helper mutation/text-normalization
bridge is also done, the legacy accumulator bridge closes `regdef_nested_register_fields`, and the public-parser
leading-trivia bridge closes `ds_vhistory_version_entry`. Final parser-smoke no-drift closeout, bounded
structural regex work, routed top-level `fn` corpus-shell execution, and the full shipped 105-fixture Dart corpus
gate are done; the next Dart leaf wires that green gate into the local verification story.

### Step 6: Validate Against the Test Corpus
Run your backend against the manifest-backed corpus under
`rust/linkedspec-runtime/tests/corpus/`. The corpus root has a `manifest.json`
with `case_count` and the ordered `cases` list; every manifest entry has an
`input.spec`, `input.txt`, and `expected.json`. Your backend is compliant with
the current corpus gate when it produces structurally equivalent output for
every manifest entry, and its runner rejects missing fixture directories or
stale extra fixture directories.

For the Dart backend, the focused local gate is:

```bash
bash tools/run_dart_local.sh
```

The core local CI gate remains independent of Dart SDK availability by default; set
`LINKEDSPEC_RUN_DART=1` when invoking `tools/run_ci_local.sh` to include the Dart gate.

The checked-in Rust corpus is kept green while parity work lands incrementally. It now has
105 fixtures, including the `with(...) { ... }` helper, `.with() { ... }` receiver trailing block case, hash-tree traversal receiver block case, array-tree traversal receiver block case, and six exhaustive capability cases; the two minimal shipped `tclite.spec` cases restored by the
default-mode repetition parity work; the shipped `Lispish.spec` `lispish_x_y` case now
migrated to direct nested access; the first `hlink_substitution` raw-string cases plus the
JSON-safe `{abc}` curly-brace delimiter case and the neutral bracket/mixed delimiter cases;
`lib_reader.spec` scalar-attribute and
comma-list attribute cases; `portmap.spec` bare, bit, slice, constant, and concatenation
cases; `ebnf.spec` expression-rule and logging-annotation payload cases; four `spec.spec`
smokes for minimal rules, action edges, user-function definitions, and comments; seven
RTL/plugin/legacy safety smokes covering `regdef`, `tablegrep`, `simenv`, `vhdl`,
`ds_vhistory`, empty `pplugin`, and empty `tkgui`; terse receiver-chain fixtures for
arrays, hashes, strings, numbers, aggregate wrapper quoting, block-valued receivers, and array-tree traversal;
numeric word aliases; arithmetic/comparison symbol callees; the terse bare-read `name`
fixture for scalar reads, scalar mutation targets, and scalar-held shape payloads;
explicit string comparisons; assignment-expression fixtures; and the shared Perl/Rust
user-function runtime fixture; plus recursive top-rule/body value fixtures for wrapper-body
recursion, nested top-rule `LX` recursion, and top-rule sequence recursion.
`RUST-PARITY.7.4` finalized the corpus guard: the generator writes
`manifest.json`, and the Rust runner fails malformed manifests, duplicate case
names, missing manifest entries, or stale extra fixture directories. The richer
legacy/plugin mismatches above remain follow-up blockers until a narrower parity
owner promotes them safely.

## Architecture Overview

```
.spec file
    │
    ▼
┌─────────────────────────┐
│  Compiler (language-     │
│  specific but spec-      │
│  driven — see spec.spec) │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│  Parsed .spec +          │  ← typed AST/IR, never raw textual helper rewrites
│  helper/action AST       │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│  ActionIR Lowering       │  ← Backend-neutral (helpers → canonical events)
│  (100+ helpers, 10       │
│   families)              │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│  HandlerIR               │  ← The decoupling seam
│  (10 variant kinds,      │
│   structured AST)        │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│  Backend Emitter         │  ← YOUR CODE HERE
│  (Rust / Dart / Julia /  │
│   Lua)                   │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│  Runtime                 │  ← Language-specific runtime
│  (regex engine, memory   │
│   model, I/O)            │
└─────────────────────────┘
```

## What the Perl Reference Provides

The Perl implementation is the **reference** — the canonical behavioral oracle.
It provides:

- A working compiler pipeline you can study for architecture understanding.
- `spec.spec` — a self-hosted grammar that can bootstrap a new compiler.
- An active `fn name(args) { ... }` definition surface owned by `spec.spec` and projected
  through the descriptor `functions` registry. The Perl reference currently uses a
  temporary pre-bootstrap extraction bridge; do not copy that bridge as the language
  contract. The accepted MVP is exact-arity, pure value/block functions with fresh
  function-local scope, no implicit caller capture, and registry resolution before
  unknown-helper fallback. Calls execute in value positions and compatible receiver
  chains; registered standalone calls compute and discard through `VALUE_DROP`. Recursion
  and unsupported function-body forms are diagnostics, not raw fallback.
- The Rust backend's parsed and compiled state records the same top-level function
  registry shape with parsed body `CodeBlock` values, and its runtime resolves registered
  calls before helper fallback with fresh function-local stores, receiver-chain
  continuation, standalone discard, and recursion diagnostics. The accepted MVP stops at
  explicit-paren, braced `fn` definitions; alternate spellings, omitted zero-arg parens,
  brace-less forms, statementful/caller-mutating functions, recursion support,
  closures/lambdas/currying, and namespaces remain deferred.
- `t/phase0_regression.t` — comprehensive regression tests.
- Phase 0 descriptor checks require all shipped specs to compile at `language_agnostic_ready_ratio == 1.0000`.

## What You Must Build

1. **`.spec` parser** — reads `.spec` files and produces parsed rule entries.
   Can be bootstrap-driven (hardcoded grammar) or self-hosted (parse spec.spec
   with itself, once bootstrapped).

2. **Staged parse-job model** — records source-provenance payload text, parser spec id,
   optional top rule, parent AST path, payload kind, result insertion policy, and failure
   behavior. Parser resolution must be deterministic and diagnostics must report both the
   selected next-stage parser and the original parent source span.

   The current portable authoring marker is exact scalar assignment-form
   `target = parse_job(source_bound_text, hash(literal options))`. It creates a marker value plus sidecar metadata
   rather than executing the next parser inline, and it can select only caller-frozen already-compiled authority.

3. **Staged parser registry and queue** — resolves parser spec ids deterministically,
   caches compiled next-stage parsers by content/version/capability fingerprints,
   dispatches jobs in stable queue order, isolates runtime contexts, stitches results,
   and diagnoses cycles.

4. **Spec import/composition graph** — once implemented, loads file-scope `import` and
   `include` directives as parsed `.spec` dependencies with aliases, structured namespace
   merges, cycle diagnostics, source provenance, and descriptor fingerprints.

5. **Helper/action AST parser** — parses lifecycle/action helper code into typed
   expression and statement nodes. Calls, literals, variables, blocks, direct
   access, assignments, and receiver-dot chains must be represented structurally.
   Text-to-text helper rewriting is not a conforming design for new backends.

6. **User-function registry and resolver** — records top-level `fn name(args) { body }`
   definitions as validated AST-backed records before runtime. The registry must preserve
   definition order, expose definitions by name, reject helper/rule/reserved-name
   collisions, and resolve exact-arity value calls before unknown-helper fallback.

7. **Compiler** — transforms parsed entries and helper/action AST nodes into
   HandlerIR nodes. You can reuse the ActionIR lowering approach, but the input to
   lowering is structured AST/IR rather than raw helper source text.

8. **HandlerIR emitter** — consumes HandlerIR nodes and produces runnable code
   in your target language. Must handle all 10 variant kinds.

9. **Runtime** — the execution engine:
   - Regex engine with position tracking (equivalent to `//gcp` and `\G` anchoring).
   - Accumulator model (arrays, hashes, scalars).
   - Lifecycle execution engine (I/LS/LE/E/EX/IT/LX ordering).
   - Explicit cursor controls: `save_cursor()` / `restore_cursor()` stack
     semantics plus `rewind_match_start()` / `rewind_entry_start()` anchor
     rewinds.
   - Zero-width/lookahead boundary support through
     `capture_until_boundary(rule[, ...])` for non-consuming structural boundary
     detection and capture.
   - Zero-progress guard.

10. **Test harness** — runs `tests/corpus/` entries and compares output to
   `expected.json`.

## Practical Notes

### Regex Engine
The biggest implementation dependency. LinkedSpec requires:
- Position-tracked matching (set/query current match position).
- Ungrounded matching (match anywhere) and anchored matching (match at position).
- Identification of **which** alternative matched in a group.
- Capture groups (indexed and named).

If your target language's regex engine doesn't support embedded code position
tracking, you may need to iterate alternatives individually rather than
compiling a combined alternation.

### Memory Model
LinkedSpec uses mutable working variables (scalars, arrays, hashes) within
rule scope. These are assignment-backed, not functional. Your runtime needs
a variable store per rule invocation.

### Determinism
All operations must be deterministic. Specifically:
- No random number generation.
- Hash key iteration must be sorted (not insertion-order or random).
- First-match-wins for OR dispatch.

## Specification Index

| Document | Location | What it defines |
|---|---|---|
| Multi-backend ADR | `docs/decisions/0006-multi-backend-vision.md` | Vision, lockstep contract, reach matrix |
| Formal `.spec` Grammar | `docs/linkedspec-book/src/appendix/formal-grammar.md` | Accepted `.spec` syntax |
| HandlerIR Spec | `docs/knowledge/handler-ir-design.md` | HandlerIR node structure and emitter contract |
| Helper Contract Catalog | `docs/linkedspec-book/src/appendix/helper-contract-catalog.md` | Every helper's behavioral contract |
| Runtime Semantics | `docs/linkedspec-book/src/appendix/runtime-semantics.md` | Parse modes, lifecycles, dispatch |
| Test Corpus | `rust/linkedspec-runtime/tests/corpus/` | Manifest-backed language-neutral compliance tests |

## Handoff Checklist

Before starting a new backend, verify:
- [ ] You've read all six specification documents above.
- [ ] You understand the `.spec` language syntax (formal grammar).
- [ ] You understand the runtime execution model (runtime semantics).
- [ ] You can implement all 100+ helpers (helper catalog).
- [ ] You can implement a HandlerIR emitter for all 10 variant kinds.
- [ ] You have a regex engine capable of position-tracked alternation matching.
- [ ] You've studied the test corpus format and know how compliance is measured.
- [ ] You understand that `.spec` files are the universal contract — no
      per-backend dialects.

### Rule-call result read composition

Existing rule calls already return values usable by compatible methods. The
next bounded target adds direct Array/Hash brackets after ordinary static calls.
Perl supports direct static rule-call brackets through its existing typed reader
and unchanged child-handler ABI. Rust now also applies its existing selected-kind
guard to bare static call results, preserving child invocation and bound callable
counts. Perl native/fresh and Rust native/restored/plan focused controls pass. Dart also
preserves the static-call selected-kind guard across native/restored/plan, with
original bound callable counts and typed function fences. Julia also preserves
the target across native/reconstructed/plan/fresh same-process Module with its
existing child invocation and typed function boundary. Installed PUC Lua 5.5.1/
LuaJIT also preserve static-call selected-kind guards across native/restored/plan/
fresh loaded modules, retaining caller/function policies and interpreter chunk
limits. Declared Lua 5.4 remains separately owned. The closed named-read prerequisite
also preserves frozen write AST/diagnostics. Independent backend work preserves invocation/cursor/error/callable
authority; no peer or portable admission follows from the Perl intake.

### Gap and incoming-slot record field composition

The next bounded target lets existing zero-argument gap/slot record helpers feed
ordinary Hash brackets directly. Perl now admits the two existing zero-argument record sources through its typed
field reader and unchanged readonly helper ABI; native/fresh field/default/guard/
context-error/function/deferred controls pass. Rust also applies the existing
selected-kind guard to these two zero-argument record sources; native/restored/
generated-plan field/default/guard/context/function/arity controls pass. Rebuild
Rust applications with the updated runtime. Dart also guards the existing canonical
zero-argument record sources across native/restored/generated-plan; its field,
default, context-error and function controls pass. Dart55.0 also enforces zero
arguments for all four gap/slot readers through existing typed arity diagnostics;
function-state priority and trailing-body compiler rejection remain. An established completed fluent-record source
supplies the computed-read oracle; legacy named first-consumer policy stays
qualified. Independent backend work preserves gap owner/phase/lifecycle/metadata/
typed errors/function/deferred and generated-format authority.

Julia also applies its existing selected-value operand guard to ordinary
zero-argument gap/slot field reads across native/reconstructed/generated-plan/
fresh same-process Module. Gap-context failures and function-state restrictions
remain; no full context or portable admission follows.

Installed PUC Lua 5.5.1/LuaJIT likewise guard ordinary zero-argument gap/slot field
reads across native/restored/plan/fresh loaded modules. Typed unavailable context,
function-state restrictions and strict reader arity remain, with no added chunk
locals. Declared Lua 5.4 and full context/portable admission stay separate.

### Cursor rewind result composition

The next bounded addition composes the existing Number result of the two zero-
argument rewind helpers. A descriptor-qualified explicit action-edge bound twin
preserves entry/local anchors, source-before-consuming-operand values, defaults,
guards and signed Array recovery on native/fresh Perl; direct forms fail. The
ordinary eager cursor-statement local-return prerequisite is now repaired and
targeted-checked on native/fresh Perl; regenerate affected emitted parsers. The
rewind Number value-source roles are now also implemented/targeted-checked in
Perl across native/fresh with original cursor ABI and pure-function restrictions.
Direct Number/default/guard/Array recovery flows pass. Rust also now returns
character-based rewind Numbers and applies the existing result guards across
native/restored/plan; rebuild its runtime/apps. All four Rust cursor controls now
reject surplus arguments before argument evaluation, retaining pure-function
priority and the compiler rejection of trailing bodies. Dart now returns and
composes validated character Number results on native/restoredSpec/plan with
null absent anchors. Its four cursor controls now reject surplus arguments
before physical effects, preserving function priority and trailing compile
rejection. Rebuild Dart runtime/apps. Julia now also composes validated
character rewind Numbers across native/restoredSpec/plan/fresh Module with null
absent anchors; rebuild its runtime/apps. Its four cursor controls now reject
surplus arguments before effects, retaining function priority and trailing
compiler rejection. Installed PUC Lua5.5.1/LuaJIT also now return and compose
validated character rewind Numbers, retaining existing arity/errors/null controls.
Rebuild Lua runtime/apps. These recorded bounded outcomes retain host/context
limits; declared Lua5.4 and full admission remain separate.
A separately owned default-parent rewind cycle requires ordinary progress
authority before admission. No anchor/absence/stack/transaction/callback/schema
or portable admission changes follow from this selection.

The Knowledge Map remains derivable from committed fact cards. Its generator
currently writes the live file directly; wait for generation to finish before
reading or staging it. Atomic publication is owned by the scheduled document
maintenance repair before admission.

The bounded gap String addition now works in Perl: gap_text/gap_kind preserve
String methods and use actual-kind direct guards and read/recovery roles.
Native/fresh shared/empty/tail/Unicode/operand skips/with Array-Hash-Bool and
function/context/legacy controls pass. Regenerate affected emitted Perl parsers.
Rust now also applies the existing gap String operand guards on native/restored/
plan, preserving already-working recovery/Unicode/with kinds/context/function/
arity behavior; rebuild runtime/apps. Dart also now uses these gap String guards
on native/restoredSpec/plan while preserving its already-working recovery/kinds/
Unicode/errors; rebuild its runtime/apps. Julia now applies the same bounded
guards across native/restoredSpec/plan/fresh Module, preserving already-working
kinds/recovery/errors; rebuild runtime/apps. Installed PUC Lua5.5.1/LuaJIT now
also apply the two canonical-zero source guards across native/restoredSpec/plan/
fresh module, preserving working kinds/recovery/errors without new interpreter
chunk locals. Rebuild Lua runtime/apps; declared5.4/full admission remain separate.
Bounded57 outcomes are recorded. Existing gap
state, contexts, errors, function restrictions and raw named policies stay; full
admission remains separate.

The bounded feature58 composes existing unambiguous explicit-value push
snapshots through reads and compatible methods. Perl's Hash payload producer58.0
is now repaired through the complete existing typed push owner, retaining local
returns, snapshots, kinds and function-local scope. Regenerate affected emitted
Perl parsers. Bounded Perl direct reads58.1.1 now use the guarded explicit-value
source role and current typed reads, preserving the ten-output subset and eight
excluded AST/error forms. Fluent58.1.2 now initializes the same guarded snapshots
through current value dispatch; full twelve-result native/fresh execution passes.
Previously healthy copy/logical/with/transitions remain, with source-once/local
returns/function scope preserved. Regenerate affected emitted Perl parsers.
Rust now guards direct and selected explicit push snapshot consumers on native/
restored CompiledSpec/plan, preserving already-working full target/scope/order/
copy/logical/with/source-error behavior. Rebuild Rust runtime/apps.
Dart now also guards direct Array/selected String push results on native/restored
SpecFile/plan, preserving its already-working Bool/full target/order/scope/with
behavior and original action-edge child dispatch. Rebuild Dart runtime/apps.
Julia now also uses the bounded guards on native/restoredSpec/plan/fresh Module,
preserving its already-working Bool/full target/order/scope/with behavior.
Rebuild Julia runtime/apps. Installed PUC Lua5.5.1/LuaJIT now also guard these
results across native/restoredSpec/plan/fresh module with no new interpreter
chunk locals; rebuild runtime/apps. Bounded58 outcomes are recorded, with
declared5.4/full admission separate. Each peer was assessed
independently; child-push/all-bare/numeric source ambiguities and implicit results,
grouping/deferred/schema/full admission stay separately owned.

The bounded feature59 composes existing canonical `set(name,value)` stored
typed results through direct reads and guarded consumers.
Perl now materializes canonical set results through current reads/kind guards:
full12/native/fresh, operand skips/order/functions/codeblock values/RHS errors
pass. Regenerate affected emitted Perl parsers. Rust now also guards canonical
set results on native/restored CompiledSpec/plan, preserving already-working
full target/read/order/scope/codeblock behavior; rebuild runtime/apps. Rust now
also retains actual container guards after ordinary receiver defaults, including
selected prefixes and pre-with guards. Scalar/empty/lazy/preflight and unknown
unbridged bound-call behavior stay. Free-helper result guards remain owned by
selection21 after59.5 with separate domain assessment. Dart now also guards
canonical set sources on native/restoredSpec/plan, preserving already-working
Bool/full target/order/scope/codeblock/error/alias behavior; rebuild runtime/apps.
Julia now also guards canonical set sources on native/restoredSpec/plan/fresh
Module, preserving already-working Bool/full target/order/scope/codeblock/error/
alias behavior; rebuild runtime/apps. Installed PUC Lua5.5.1/LuaJIT now also
guard these results on native/restoredSpec/plan/fresh module, with no new
interpreter chunk locals. Rebuild runtime/apps. Bounded59 outcomes are recorded;
owned free-source selection21 follows, with declared5.4/full admission separate.
Ordinary assignment copy/alias rules, operators/grouping/aliases/deferred/schema
authority and full admission remain separate.

Feature60 owns canonical free `coalesce`/`coalesce_nonempty` result guards. Public
Perl/Rust primitive values, compatible methods, selected reads, lazy skipping,
snapshot order and function scope already work. Direct incompatible consumers
also expose gaps with published Scalar inputs: operands/with bodies run, and
some Perl guards previously runtime-failed despite ready metadata. Perl now guards
canonical ordinary free-default results through native/fresh execution. Incompatible
operands/later with bodies skip, while valid null/empty-container with inputs run;
healthy kinds/laziness/order/snapshots/functions/errors stay. Regenerate emitted Perl.
Rust now also guards these canonical free results on native/restored CompiledSpec/
in-process plan, preserving valid null/empty with inputs, source order and unknown
bound-call policies. Rebuild Rust apps/runtime. Dart now also guards canonical free
results on native/restoredSpec/plan and retains actual-kind guards after receiver
defaults select containers. Valid null/empty with inputs, laziness/order/scope stay;
rebuild Dart apps/runtime. Julia now also guards free and receiver-default results
across native/restoredSpec/plan/fresh Module, preserving legitimate null/empty with,
order/scope/errors. Rebuild Julia apps/runtime. Installed PUC Lua5.5.1/LuaJIT also
guard these free and receiver-default results across native/restoredSpec/plan/fresh
module, without new interpreter chunk locals. Rebuild Lua apps/runtime. Bounded60
outcomes are recorded; next feature selection22, declared5.4/full admission separate. Completed-value guarded receiver bridges work. Free signatures, qualified aggregate compatibility and full domain/
context/portable admission remain separate.

Feature61 targets retained Array/Hash constructor result composition. Perl already
preserves primitive values, direct reads, selected/completed guards, order/function/
with and needed-error controls. Retained ordinary constructor results now guard
incompatible consumers through native/fresh execution, skipping their arguments
and later with bodies while retaining legitimate empty/null inputs. Computed Hash
keys now use typed value lowering, preserving key/value order, local returns,
snapshots, function scope and original bare/literal key policy. Perl's separate
comparator-scope defect is repaired: sorting remains correct with legal working/function names `a` and `b`,
preserving their values, input arrays and scalar kinds. Native and freshly emitted
parsers pass focused scope/kind/order checks.
Regenerate emitted Perl parsers. Rust now also guards retained ordinary constructor
results through native/restored compiled specs/in-process plans, preserving source
effects, intermediate actual kinds and valid empty/null with. Computed keys/order/
snapshots/functions already work; its producers remain unchanged. Rebuild Rust
applications/runtime. Dart also guards retained ordinary constructors through
native/restored specs/in-process plans; source effects, intermediate kinds,
legitimate empty/null with and already-working computed keys stay. Rebuild Dart
applications/runtime. Julia also guards retained ordinary constructors across
native/restored specs/plans/fresh modules, preserving source effects, intermediate
kinds, valid empty/null with and already-working computed keys/order/scope.
Rebuild Julia applications/runtime. Installed PUC Lua5.5.1/LuaJIT also guard
retained constructors on native/restored specs/plans/fresh modules, with source
effects, intermediate kinds, empty/null with and computed keys/order/scope intact.
No new interpreter chunk locals; rebuild Lua applications/runtime. Bounded61
outcomes are recorded; next feature selection23.1.23. Declared Lua5.4 and full
admission remain separate.
No constructor producer/selector/pair-splice/copy/signature/schema expansion or
complete portable admission follows.


Feature62 guards canonical ordinary free String-helper results on Perl, Rust,
Dart, Julia and installed PUC5.5.1/LuaJIT2.1.1788460057. Incompatible Array/Hash
consumers skip their arguments and later immediate `with` bodies. Source effects,
actual scalar kinds, compatible methods, split/select bridges and legitimate
null/empty `with` inputs remain intact. Perl's confirmed fresh-package symbolic
host Hash case returns null with both empty and seeded host data; this does not
establish general host isolation. Regenerate emitted Perl and rebuild backend
applications/runtime. Recorded native/restored/plan/fresh routes remain qualified
by backend; declared Lua5.4, complete domains and full portable admission remain open.

Canonical receiver String prefixes retain the same guards on Perl, Rust, Dart,
Julia and both tested Lua hosts. String-to-Array-to-incompatible-Hash paths now
skip rejected operands and later immediate `with` bodies, including the form
without a with tail. Perl's former unsupported bridge is explicitly ready and
its no-with form compiles. Source effects, actual kinds, valid selected-entry
methods and legitimate null/empty with inputs remain intact. Original producers,
signatures, domains, malformed forms and unrelated contexts stay with their
existing contracts. Regenerate emitted Perl and rebuild backend applications.
All bounded free-source and receiver-prefix outcomes are recorded; complete
source/domain/context/portable admission remains separate.


Feature63 guards canonical free arithmetic and short Number-prefix results in
all five backends on their recorded routes/hosts, including intermediate Array
bridges and rejection before later with bodies. Sixteen value observations and
original healthy/error controls stay exact; Julia/Lua also check fresh emitted
modules. Direct Number-before-with rejection already worked on Dart/Julia/Lua
and remains intact. Source effects, kinds, valid null/empty with, numeric domains/
arity and min/max reducer overloads remain. Lua uses installed PUC5.5.1/LuaJIT;
declared5.4/full source/domain/context admission remains separate. Regenerate
emitted Perl and rebuild native apps/runtime. Remaining feature selection follows.


Feature64 guards canonical free numeric comparison and short-prefix results in
all five backends on recorded routes/hosts, including Array bridges and rejection
before later with bodies. Eighteen value programs/original healthy-error controls
stay exact, including valid Number0/1 with. Direct comparison-with rejection
already worked on Dart/Julia/Lua and remains intact. Perl metadata is ready;
native/restored compiled-spec/SpecFile/plan controls pass, with Julia/Lua also
checking fresh emitted modules. Lua uses installed PUC5.5.1/LuaJIT; declared5.4/
full source-domain-context admission remain separate. The six-helper reference
lists existing signatures and true/false examples. Regenerate emitted Perl and
rebuild native apps/runtime. Remaining feature selection follows.


All five bounded feature65 backends retain eager Boolean source and ordinary
logical prefix guards through Array bridges and later immediate with bodies.
Rust receiver prefixes/direct guards and Dart/Julia/Lua direct guards already
worked; bridge guards now persist on recorded routes. Rejected consumers skip
operands/bodies; valid false/null/empty with and returned Arrays stay. Regenerate
emitted Perl parsers and rebuild Rust/Dart/Julia/Lua apps/runtime. Focused native,
restored, generated-plan and the recorded fresh Perl/Julia/Lua routes pass with
original source errors preserved. Lua uses installed PUC5.5.1/LuaJIT; declared5.4
and canonical full source/domain/context admission remain separate.


All five bounded feature66 backends retain lexical comparison source/ordinary
prefix guards through Array bridges and later immediate with bodies. Dart/Julia/
Lua direct guards already worked; bridge guards now persist on recorded routes.
Rejected consumers skip operands/bodies; Perl numeric1-0 versus peer Bool flags/
copies and legitimate zero/false/null/empty with stay. Regenerate emitted Perl
and rebuild Rust/Dart/Julia/Lua apps/runtime. Focused native/restored/plan/error
and recorded fresh Perl/Julia/Lua routes pass with original source errors preserved.
Lua uses installed PUC5.5.1/LuaJIT; declared5.4, existing null/Unicode qualifications
and canonical full source/domain/context admission remain separate.


Perl, Rust, Dart, Julia and installed Lua feature67 retain definedness source/ordinary zero-operand prefix
guards through Array bridges and later immediate with. Rejected consumers skip
operands/bodies; Perl native numeric-slot/text versus peer Bool/copy/default
compatibility and legitimate false/null/empty with stay. Regenerate emitted Perl
parsers and rebuild Rust/Dart/Julia/Lua apps/runtime. Focused native/fresh Perl
readiness/error and Rust/Dart/Julia/Lua native/restored/plan/nearest controls pass,
with fresh Julia/Lua modules and strict Julia Bool/depwarn. Lua proof uses available
PUC5.5.1/LuaJIT, with no new interpreter chunk locals. Declared5.4 and full
source/domain/context admission remain separate.


The family67 recorded nearest checks passed; their original packets omitted named
direct fixture data. Completed repair67.6 supplies an immutable historical-input
companion and six fresh passing focused cases with before/after identities. The
original observations remain unchanged, and missing original runtime-time hashes
are not retroactively claimed. Perl68.1 may resume. Broader earlier-capture input
review23.4.2 remains required before admission; runtime behavior is unchanged.


Perl, Rust, Dart, Julia and installed Lua feature68 keep emptiness source/ordinary zero-operand prefix guards
through Array bridges and immediate with. Incompatible operands/bodies skip;
legitimate false/null/empty with, repeated predicates, Perl numeric1-0 versus Rust/Dart/Julia/Lua
Bool/copy/default and source snapshots stay. Regenerate emitted Perl parsers and
rebuild Rust/Dart/Julia/Lua apps/runtime. Focused native/fresh Perl readiness/error and
Rust/Dart/Julia/Lua native/restored/plan/nearest checks pass, plus fresh Julia/Lua
modules, owned Rust formatting/Dart analysis and strict Julia Bool/depwarn. Lua
uses installed PUC5.5.1/LuaJIT with no new interpreter chunk locals. Declared5.4,
broader SESSION16 and full admission remain separate.


Perl, Rust, Dart, Julia and installed Lua feature69 retain has_key free-source/ordinary one-key prefix guards
through Array bridges and immediate with. Rejected operands/bodies skip; source/key
SKC snapshots, null-source key evaluation, numeric0-1/copy/default/repeated predicates
and legitimate false/null/empty with stay. Regenerate emitted Perl parsers and
rebuild Rust/Dart/Julia/Lua apps/runtime. Focused Perl native/fresh/readiness/error and
Rust/Dart/Julia/Lua native/restored/plan/null-source/nearest checks pass, plus fresh
Julia/Lua modules, strict numeric identity/Julia depwarn and selected Rust/Dart
format-analysis. Lua uses installed PUC5.5.1/LuaJIT with no new interpreter chunk
locals. Declared5.4, full source/key domains and portable admission remain separate.
Independent copied-null assessment found key/error suppression on
Rust/Dart/Julia/installed Lua; the bounded repairs below address those observations. Perl69.6.1 now retains rejection across canonical
ordinary presence/copy chains, skipping later keys/bodies with or without a
trailing with while preserving legitimate nullable key effects and numeric flags.
Focused11/nearest presence-null-copy/source18/syntax and bound public lowering
checks pass; regenerate emitted Perl parsers. Rust69.6.2 also restores nullable
has_key after copies/legitimate null results, including key errors, while earlier
incompatible consumers still exit immediately. Native/restored/plan11, nearest
presence24/copy6 and owned formatting pass; rebuild Rust apps/runtime. Dart69.6.3
also admits canonical nullable presence through its common/scalar guards and removes
the obsolete first-step flag. Native/restoredSpec/plan11, nearest presence24/copy4,
fatal analysis and owned formatting pass; rebuild Dart apps/runtime. Julia69.6.4
also admits canonical nullable presence through both guards. Native/restoredSpec/plan/
fresh-module55 strict-kind assertions and nearest presence116/copy12 pass under strict
depwarn with qualified precompile-only notices; rebuild Julia apps/runtime. Safe Lua69.6.5
also admits canonical nullable presence through both guards, with no new interpreter
chunk locals. Both installed PUC5.5.1/LuaJIT pass55 strict JSON-kind checks on four
routes, nearest presence116/copy four programs/twelve route observations/loadfile and
version checks; rebuild Lua apps/runtime. All bounded69/69.6 outcomes are recorded.
Declared5.4, general isolation and full admission remain open.


String-predicate source/prefix guards70 are frozen separately from existing scalar
result handoff. The initial Perl assessment exposed bounded free-call/with normalization/receiver
bridge readiness gaps; compatible values, source-operand SOC snapshots and producer
domains remain healthy. Independent all-backend producer controls retain numeric
text flags and Perl numeric versus native Boolean matches, strict arithmetic/null/
empty/i behavior. Each backend independently baselines guards before implementation;
no producer/regex-domain/context/schema or complete portable admission is implied.


Perl70.1 now preserves String-predicate source/prefix guards through bridges and
immediate with. Rejected consumer operands/bodies skip while source-operand effects,
numeric flags, copies/defaults/strict arithmetic and valid with results remain.
The existing regex producer and literal flags are unchanged. Focused native/fresh
22-case/readiness/error checks, selected nearest checks and18 excluded syntax
fences pass. Regenerate emitted Perl. Remaining backend guard baselines and
full domain/context/portable admission remain separate.


Rust70.2 retains canonical String-predicate free-source/ordinary one-operand guards
through bridges and immediate with. The existing matches regex-literal operand is
recognized in its pattern position, preserving flags, numeric text predicates and
Boolean matches. Source-operand SOC snapshots/copy/default/strict arithmetic and
valid with results remain; incompatible operands/later bodies skip. Focused23
tests pass on native/restored-spec/generated-plan routes, with eighteen unchanged
public syntax observations, selected nearest checks and owned formatting. Rebuild
Rust applications/runtime. Remaining peers and full admission remain separate.


Dart70.3 retains canonical String-predicate source/prefix guards through bridges
and immediate with. The common kind guard skips incompatible operands/later
bodies while preserving numeric text flags, Boolean matches, existing literal
regex/modes, SOC snapshots and valid with results. Focused23 tests pass across
native/restored-spec/generated-plan routes with fifteen original healthy values,
one source error and eighteen unchanged public syntax observations. Selected
nearest checks, fatal owner/test analysis and scoped formatting pass. Rebuild
Dart applications/runtime. Safe Lua and full admission remain separate.

At the original feature70.3 boundary, Dart/Julia/Lua and shared fixtures required
manual checklist review. Task23.4.3 extends the task-evidence shape gate to all
owned backend directories and `tests/`, with recurring isolated-index rejection
and complete-evidence controls. See [task-evidence coverage](../development/local-ci-and-regression.md#task-evidence-coverage).
This checks staged evidence shape; focused feature results retain their original
scope and do not establish full runtime admission.


Julia70.4 retains canonical String-predicate source/prefix guards through bridges
and immediate with. Existing literal regex operands/modes, numeric text flags and
Boolean matches remain; source-operand SOC snapshots and valid with results stay.
Incompatible operands/later bodies skip. Focused111 strict Number-versus-Bool
assertions pass on native/restored-spec/generated-plan/fresh-module routes, with
fifteen original healthy values, one source error and eighteen unchanged public
syntax observations. Nearest271/strict depwarn and anchored precompile-only stderr
checks pass. Rebuild Julia applications/runtime. Declared Lua5.4/full admission
remain separate; the original checklist review preceded the task23.4.3 gate extension.


Safe Lua70.5 retains canonical String-predicate source/prefix guards through bridges
and immediate with, inside the existing receiver namespace without new interpreter
chunk locals. Both installed PUC5.5.1/LuaJIT2.1.1788460057 pass111 strict JSON-kind
checks on four routes; fifteen healthy values, the needed source error and eighteen
public syntax observations stay exact. Nearest predicate fixture/free86/bridge66/
presence116/loadfile/version checks pass with empty accepted-nearest-version stderr.
Existing flags/regex/SOC/copy/default/numeric/valid with remain; incompatible operands
and later bodies skip. Rebuild Lua applications/runtime. All bounded70 outcomes are
recorded; declared5.4/general isolation/full admission remain separate.


Contains source/prefix guards71 are frozen after bounded String-predicate70.
Reference intake distinguishes healthy numeric/equality/snapshot results from
free/with/bridge guard gaps, inconsistent null prefixes and copied rejection.
Perl producer71.0 now preserves typed block operands: mutation-yielding blocks
return their values, and source/needle binding errors reach execution. Focused
native/fresh13/nearest/source-fence/syntax checks pass; regenerate emitted Perl.
Independent guards71.1-.5 follow, then mandatory copied-null/
rejection assessment71.6 before unrelated selection. No peer failure, new equality/
copy policy or full domain/context/portable admission follows from the reference.


Perl71.1 now preserves contains source/prefix actual-kind guards through immediate
with and Array bridges. Shared23 plus three retained null-prefix controls pass
native/fresh, with numeric flags/source-needle SOC snapshots/healthy errors exact.
Leading literal/block null now retains numeric0 and needle effects, matching
selected/free null; later Array consumers stay guarded. Focused nearest/fences/
syntax pass. Regenerate emitted Perl. Rust71.2/other peers independently follow;
P1 copy71.6 and general isolation/domain/context/full admission remain separate.


Rust71.2 preserves contains source/prefix actual-kind guards on native/restored
CompiledSpec/in-process plan routes. Shared23/null-prefix3/source scaffold27 and
nearest membership/null-key/String-predicate checks plus owned fmt pass. Existing
numeric flags/SOC/null-prefix effects/error/public shapes remain exact; later
incompatible operands/bodies skip. Rebuild Rust apps/runtime. Dart71.3 follows
independently; P1 copy71.6/general isolation/domain/context/full admission remain.


Dart71.3 preserves contains source/prefix actual-kind guards on native/restoredSpec/
in-process plan routes. Shared23/null-prefix3/null-plus-with2/source scaffold29 and
nearest membership/null-key/String-predicate28 pass, plus fatal owner/new-test
analysis and scoped formatting. Numeric flags/SOC/null effects/error/public shapes
stay exact; incompatible operands/later bodies skip. Rebuild Dart apps/runtime.
Julia71.4 follows independently; P1 copy71.6/general isolation/full admission remain.


Julia71.4 preserves contains source/prefix actual-kind guards on native/restoredSpec/
plan/fresh Module routes. Shared23/null-prefix3/null-plus-with2/source scaffold141
and nearest membership12/null-key36/String-predicate111 pass with strict numeric
kinds and depwarn checking. Existing SOC/null effects/error/public shapes stay;
incompatible operands/later bodies skip. Rebuild Julia apps/runtime. The installed
Lua and copied-null outcomes follow below; general isolation/full admission remain.


Safe Lua71.5 preserves contains source/prefix guards on installed PUC5.5.1/LuaJIT
native/restoredSpec/plan/fresh module routes. Shared23/null-prefix3/null-plus-with2/
source scaffold141 pass per host; nearest membership/null-key/String-predicate111/
loadfile/version checks pass with empty stderr. Existing namespace/no new chunk
locals; numeric flags/SOC/null effects/error/public shapes stay. Rebuild Lua apps/
runtime. All primary71 outcomes are recorded; the copied-null assessment and
bounded repairs below are also recorded. Declared5.4/general isolation/
domain/context/full admission remain separate.


The shared11 copied-null contains controls distinguish legitimate null from
rejection, source snapshots, copy depth and needed needle errors. The bounded
repairs below address Perl rejection loss through copy and peer nullable-needle
suppression. Each backend independently baselined the controls before its change.
Full source/domain/context/portable admission remains separate.


Perl71.6.1 now retains canonical contains/copy rejection before later needles and
with bodies, including no-with chains. Legitimate copied-null needle effects and
required errors stay. Unchanged11/nearest contains-presence-copy60/source18/syntax
and three input-bound public lowerings pass; regenerate emitted Perl parsers.
The independent peer outcomes follow; general isolation/full admission stay separate.


Rust71.6.2 restores copied-null contains after copies/valid null results on native/
restoredSpec/in-process plan, including needed needle errors. Earlier incompatible
consumers still exit before later effects. Unchanged11/nearest contains-presence-
copy-null-with46/owned formatting pass; rebuild Rust apps/runtime. General
isolation/full admission stay open.


Dart71.6.3 restores copied-null contains through common/scalar guards on native/
restoredSpec/plan, including needed needle errors; earlier incompatible consumers
still exit before later effects. Unchanged11/nearest contains-presence-copy44/fatal
analysis/new-normal and verbatim changed-member formatting pass. Rebuild Dart
apps/runtime. Whole-SDK formatting/general isolation/full admission stay separate.


Julia71.6.4 restores copied-null contains through common/scalar guards on native/
restoredSpec/plan/fresh Module with strict Number-versus-Bool identity. Earlier
rejected consumers still exit, and the separate call-index mutation restriction
stays. Unchanged55/nearest contains-presence-copy208/strict depwarn checks pass
with qualified package-precompile notices only. Rebuild Julia apps/runtime;
general isolation/full admission remain separate.


Safe Lua71.6.5 restores copied-null contains through common/scalar guards using
the existing namespace, with no new interpreter chunk locals. The separate
index mutation restriction and earlier rejection exits stay. Both installed
PUC5.5.1/LuaJIT pass55 strict JSON-kind checks on native/restoredSpec/plan/fresh
module, nearest contains141/presence-copy55/copy four programs twelve route
observations/loadfile/versions with empty accepted-nearest-version stderr.
Rebuild Lua apps/runtime. All bounded71/71.6 outcomes are recorded; declared5.4,
general isolation and full admission remain open.


Index source/prefix campaign72 is frozen after bounded71/71.6. Reference probes
distinguish correct numeric/null/snapshot/bridge controls from rejection/with
gaps and formerly uncompilable block operands. Perl typed-operand producer72.0
now passes15 native/fresh controls/nearest index-contains-push26/source18/syntax;
block operands yield values and required errors reach execution with actual
warning-free fresh loading. Perl canonical source/prefix guards72.1 now pass19
native/fresh controls, including leading nullable needle/default effects and
ready receiver bridges; nearest/source18/syntax/public lowering checks pass.
Regenerate emitted Perl. Rust72.2 now passes20 native/restoredSpec/in-process-plan
tests with numeric0/null identity and retained rejection; two added null-prefix/
with controls pass original/repaired epochs, nearest31/final owned fmt pass.
Rebuild Rust apps/runtime. Dart72.3 now passes22 native/restoredSpec/plan tests,
including null-prefix/with preservation, nearest34/fatal analysis/scoped formatting
with empty stderr; common kind guards retain rejection and leading nullable
index effects. Rebuild Dart apps/runtime. Julia72.4 now passes106 strict assertions
on native/restoredSpec/plan/fresh Module, nearest183/strict depwarn with qualified
precompile notices only; its separate mutation-index restriction stays. Rebuild
Julia apps/runtime. Lua72.5 passes106 strict checks per installed PUC5.5.1 and
LuaJIT2.1.1788460057 host on native/restoredSpec/plan/fresh module. Nearest index/
null-key programs, contains141/loadfile/version checks pass with empty stderr. Existing namespace/no new chunk
locals and separate mutation restriction stay; rebuild Lua apps/runtime. All
bounded primary72 outcomes are recorded. Mandatory copied-null/rejection assessment
72.6 follows before unrelated selection. No peer failure or complete admission
is inferred from reference observations.


Copied-null index assessment72.6.0 independently finds Perl rejection loss through
copy and peer nullable-needle/error suppression after receiver copy. Reference
rejection-state repair72.6.1 precedes Rust/Dart/Julia/safe Lua nullable index fixes.
Shared12 and two unchanged original null diagnostics distinguish those states,
strict index0/null values and source snapshots. Full admission remains separate.


Perl72.6.1 retains canonical index/copy rejection before later needles/defaults
and with bodies, including no-with chains. Legitimate copied-null needle effects
and required errors remain. Same14/nearest53/source18/syntax/public3 pass;
regenerate emitted Perl. Independent Rust72.6.2 then Dart/Julia/safe Lua nullable
index repairs precede unrelated selection; general isolation/admission separate.


Rust72.6.2 restores copied-null index needles/errors on native/restoredSpec/plan,
including repeated and valid-null-result copies. Earlier incompatible consumers
still exit before later effects. Same14/nearest index-contains-copy-null-with39/
owned formatting pass; rebuild Rust apps/runtime. Separate Dart/Julia/safe Lua
nullable index repairs precede unrelated selection; general admission open.


Dart72.6.3 restores copied-null index needles/errors through common/scalar guards
and removes obsolete index-only firstCall state. Source/scalarResult assignment/
with/preflight stay; same14/nearest37/fatal analysis/new-normal/one-owned-member
formatting pass with empty stderr. Rebuild Dart apps/runtime. Separate Julia/safe
Lua nullable index repairs precede unrelated selection; full admission remains open.


Julia72.6.4 restores copied-null index needles/errors through common/scalar guards.
Separate Array-end call_index restriction and source/scalar_result assignment/with/
preflight stay. Same70 strict-kind assertions/nearest173/strict depwarn pass with
qualified precompile/cache-lock notices and injected-warning rejection. Rebuild
Julia apps/runtime. Safe Lua remains before unrelated selection; admission separate.


Safe Lua72.6.5 restores copied-null index through both guards in the existing
namespace, retaining separate loop-index mutation restriction and source/scalar
assignment/with behavior. Installed PUC5.5.1/LuaJIT2.1.1788460057 pass70 strict
checks per host/four routes, nearest index106/contains-copy55/value-copy four
programs/twelve route observations/loadfile/versions with empty accepted stderr.
Rebuild Lua apps/runtime. All bounded72/72.6 outcomes recorded; remaining method
selection follows. Declared5.4/general isolation/full admission remain separate.


Count source/prefix campaign73 is frozen after bounded72/72.6. Reference probes
separate healthy numeric/snapshot/bridge controls from rejection/with gaps and
ready-but-uncompilable block sources. Perl typed-source73.0 precedes independent
backend guards73.1-.5; copy/source/rejection assessment73.6 follows before unrelated
selection. No peer failure, domain normalization or full admission is inferred.


Perl73.0 repairs Count block sources through the existing typed argument owner
and delegates direct terminal block receivers to that same producer. The legacy
emitter stays; fourteen native/fresh groups, nearest28/source18/syntax and three
public typed lowerings pass. An intermediate12PASS2RED receiver bypass is retained
and resolved. Regenerate emitted Perl. Count source guards73.1 then peers and
P1 copy/source assessment73.6 remain before unrelated selection/admission.

Perl73.1 and Rust73.2 Count source/prefix guards are implemented with focused
checks. Rust native/restored/generated-plan and independently compiled emitted
controls preserve source snapshots/errors, zero, compatible bridges and legitimate
null-with behavior while rejecting incompatible consumers before operands and
later bodies. Prior Count results retain their kind guards; initial Count source
fallbacks stay. Rebuild Rust applications/runtime for the repair.

At73.2, Rust's frozen diagnostic returned4 for both `count("text")` and
`"text".count()`, against the Perl reference's0; mandatory P1 assessment73.6 was
assigned resolution before unrelated selection. The Rust capsule retains direct inputs
and actual outputs but not the first host crates' generated manifest/lock/module
bodies; admission input-custody23.4.2 owns that qualification.

Dart73.3 now passes native/restored/generated-plan and independently compiled
emission controls. Canonical Count results join actual-kind guards; only initial
Count source consumption without a prior result owner keeps its common-guard
exception. Scalar-result state/guards and copied-null index behavior stay intact.
The frozen diagnostic matches the reference's six zeros and copied-null null.
Direct generated host modules, manifest, runner, resolved lock and package config
are retained before host execution; complete transitive generation closure is
not inferred. Selected Count/length/copied-null index, fatal targeted analysis
and scoped formatting pass. Rebuild Dart applications/runtime for the repair.
Julia73.4 now passes native/restored/generated-plan/fresh Module controls and
selected Count/length/copied-null index checks with strict numeric-kind equality
and deprecation handling. Its canonical Count guard preserves initial-source and
scalar-result rules plus the separate Array-end mutation restriction. Source
shapes, the reference-matching diagnostic and observed route-specific error
message/class/selected fields freeze before production. Existing native generic
diagnostics and generated execution wrappers stay distinct. Fresh Modules share
a process/runtime; no independent package-isolation claim follows. Rebuild Julia
applications/runtime for the fix.

Installed Lua73.5 now passes independent PUC5.5.1/LuaJIT2.1.1788460057 native,
restored, plan and fresh-module Count controls plus selected Count/length and
copied-null index checks. The existing namespace admits canonical Count without
new interpreter chunk locals. Initial source/scalar-result rules and the separate
loop-index mutation gate stay. Actual source/domain/observed error fields freeze
on both hosts before shared expectations are selected. Final and compatibility
stderr are empty; loadfile and three runner registration lines pass. Modules
share a host process/runtime and transient native module bodies are not retained;
complete input custody remains separate. Rebuild Lua applications/runtime for the
fix. All bounded primary73 outcomes are recorded; mandatory P1 assessment73.6.0,
including Rust's owned String discrepancy, is next before unrelated selection.
Declared5.4, registration, complete input custody, general isolation, source/context
and full23.4 admission remain open.


Count/copy/source assessment73.6.0 now freezes finite independent observations
across the recorded routes/hosts. The remaining P1 repairs are explicit: Perl
copy folding loses rejection before defaults/with; its distinct logical-producer
route also loses Count rejection with or without copy. Rust's len delegation
counts non-array Strings/Numbers/Booleans/nonempty Hashes where Count's source
policy returns zero. Dart/Julia/installed Lua instead reject initial Boolean
receiver Count at their scalar guard where the reference returns Number0.
Produced/copied Boolean rejection already works and must remain.

Perl73.6.1 now preserves canonical Count rejection through ordinary copy and
repeated copies using the existing rejection flag. Nineteen focused native/fresh
controls pass, including legitimate null/default/with, Number0, source errors,
snapshots and function state. Regenerate emitted Perl. The separate logical
producer repair73.6.6 is next; it is not closed by the copy fix. A longer added
receiver/copy program exposed pre-execution compilation work; P2 owner73.7
retains its original interrupted evidence and schedules bounded diagnosis/repair
after the six P1 Count repairs, before full23.4.

Perl73.6.6 now retains canonical Count rejection through eager logical producers
with and without copy/with. Fourteen native/fresh groups pass, preserving valid
null/zero, real Bool results, eager operands/errors, source snapshots, function
scope and malformed-shape preflight. Regenerate emitted Perl. Rust73.6.2 and
peer Boolean source73.6.3/.4/.5 are next; full admission and P2 scaling73.7 remain
separate.

Rust73.6.2 now restores Count's Array-only source fallback: accepted non-array
initial/free sources return Number0 while copied/produced receiver guards remain.
General length behavior is preserved. Twenty native/restored/plan and independently
compiled emitted controls, the current Count diagnostic and Count/length pass.
Actual first Cargo source/manifest/resolved-lock/module inputs are retained;
the initial archive-path setup failure gets no extra behavioral credit. Rebuild
Rust applications/runtime. Dart/Julia/installed Lua initial Boolean source3/4/5
remain next. Earlier custody gaps, full transitive/native closure, registration,
general isolation, P2 scaling73.7 and full23.4 remain separate.

Dart73.6.3 now admits only initial Boolean Count sources at the scalar guard,
reusing the existing one-step permission while preserving state assignments.
Twenty-five native/restored/plan/compiled-emitted controls move22PASS3RED to25PASS;
produced/copied Boolean and unowned Array rejection, source-once/zero/error/function
controls stay. Fatal targeted root/fresh analysis, Count/length2, index-copy1 and
owned loop/new-file formatting pass. Actual direct inputs are retained; complete
native/transitive closure stays separately owned. Rebuild Dart runtime/apps.
Julia4/Lua5 remain next. P3 formatting73.8 owns the two unrelated free-default/set
member layout changes after the P1s/P2, before full23.4.

Julia73.6.4 now applies the same existing initial-source permission at its
Boolean scalar guard. Twenty-five native/restored/plan/fresh-module groups pass
after four independent baseline failures, including Boolean function parameters.
Scalar-result state and the separate Array-end loop-index mutation gate stay
intact. Actual declared source/project/normal inputs and emitted modules before
loading are retained. Strict deprecation handling and nearest Count/length and
copied-null index checks pass. Fresh modules share the current Julia process;
full transitive/native custody and independent isolation remain separately owned.
Rebuild Julia applications/runtime. The director has resumed PNT; installed Lua5
is now focused-checked as described below, before P2 scaling73.7 and
P3 formatting73.8; full admission remains open.

Repair order is73.6.1,73.6.6,73.6.2,73.6.3,73.6.4,73.6.5 before unrelated
selection. Valid null/zero and copied-kind controls distinguish these gaps from
blanket null suppression. Actual Rust native/emitted Cargo source, manifest and
lock inputs precede first runs; verified input archives preserve them afterward.
The readonly finite review rejects route/kind/input/archive corruptions. These
are assessed repair obligations, not completed fixes or full portable admission;
transitive/native custody, general isolation, registration and declared5.4 stay
with their existing owners.


Installed Lua73.6.5 now applies that initial-source exception at its Boolean
scalar guard too. Both installed hosts independently pass25 shared groups on
native/restored/plan/fresh-module routes after four original failing groups.
For example, `{false}.count().add(1)` returns Number1 and
`{true}.count().with(){return(value.add(1))}` returns Number1, while
`copy(false).count()` and `and(false).count()` still reject with null.
The exception belongs only to the initial Count step without prior result
ownership; it does not grant Array operations to arbitrary Boolean values.

Scalar state and the separate loop-index mutation restriction remain intact;
no interpreter chunk local is added. Count/length and copied-null index controls,
loadfile and the three-line normal registration pass with empty final stderr.
Actual declared source/fixture/wrapper inputs and pre-load emitted modules are
retained. Fresh modules share each host process; full native/transitive custody,
independent isolation, registration, declared Lua5.4 and full admission remain
open. Rebuild Lua applications/runtime. All six concrete P1 Count repairs are
implemented with focused checks; P2 compiler73.7 then P3 Dart formatting73.8
follow before full23.4.


Count-specific compiler diagnosis73.7 now restores the exact original long
receiver/repeated-copy source as a maintained regression. Its native/fresh result
is `[null,"S"]`, with later rejected operands/defaults/with skipped and readiness,
cursors and warnings preserved. Public compiler stages complete after a separately
qualified bootstrap warmup. A private single-condition control identifies the
legacy generated-source round trip avoided by the earlier Count copy repair;
this leaf adds no production compiler change. Short cold-start stops are not
source-scaling evidence. General compiler performance and full custody/admission
remain unassessed. P3 Dart formatting73.8 is next before full23.4.

PNT has resumed. Dart formatting73.8 now aligns the free-default and canonical-set
source predicates with the current formatter. The complete runtime owner formats
with zero changes; fatal targeted analysis and existing default/set rejection,
lazy-order and snapshot controls pass on native, restored and generated-plan
routes. This layout repair preserves the predicates and all other runtime bytes.
The owned artifact-growth review23.4.8 precedes unrelated feature selection;
full admission remains separate.


## Length continuations across the five backends

Ordinary `length(value)` and `value.length()` results retain their actual kinds.
The existing producer keeps its Number/null values: `length("tail").add(1)` is `5`,
`length("").coalesce(7).add(1)` is `1`, and
`length(undef).with(){return("recovered")}` returns `recovered`.
A valid null result remains available to `with`, copy and eager logical methods.

An incompatible consumer should reject before evaluating its operands and skip
later continuation bodies. For example:

```text
length("tail").take(1).copy().with(){return("ran")} # Perl: null
length("tail").set_key("k",1)                     # Perl: null
length("tail").cat(",tail").split(",").last()     # tail, explicit bridge
```

Perl74.1 now implements those guards. The first two examples return null and
skip rejected operands and later bodies, including across copy and eager logical
links. The old Hash fallback could read host `main::4`; empty/outer/main seed
controls now all reject without changing host data. Regenerate previously emitted
Perl modules to obtain this fix. The Number/null producer and its conversion
rules are unchanged.

```text
order="";
result=length("tail").take({order=cat(order,"A");1})
  .copy().and({order=cat(order,"D");true})
  .with(){order=cat(order,"W");return("ran")};
return([result,order]); # Perl: [null, ""]
```

Valid null and zero continue through ordinary eager logical and with semantics:
`length(undef).copy().and(true)` and `length("").copy().and(true)` both return
Boolean `false`; their operands and later with bodies still run. This distinguishes
actual null/zero data from an earlier rejected consumer.

The unchanged Perl normal passes nineteen groups after ten original failures;
nine original healthy programs remain exact. Direct Count/length/logical
preservation checks pass. Rust74.2, Dart74.3 and Julia74.4 also implement the
guards with independent focused checks; installed Lua74.5 now does too. Preserve each
backend's producer domains. No new method, signature, conversion policy or schema
is introduced.

A follow-up Perl74.6 check distinguishes initial Count input from an existing
Length result. `count(4)` and `4.count()` still return Number `0` under Count's
existing fallback. `length("tail").count()` now returns null and skips a later
with body: the Number `4` is already produced data, so it must satisfy Count's
Array-only consumer guard. This also holds for produced null/zero and across
copy/eager logical links. An explicit Array bridge still works:
`length("x").with(){return([1,2])}.count()` returns `2`. The separate unchanged
eight-group regression passes after four original failures; the original19
preservation checks remain required. No Count or Length producer rule changes.


Sixteen finite programs retain compatible Number/null flow, effects/snapshots,
source errors, malformed receiver preflight, functions, copy/logical state and
bridges. Actual public observations and supplemental modules survive in
`docs/checkpoints/length-selection-2026-11-05/`; the readonly recovery reader also
checks three corruptions. Initial and supplemental capture boundaries differ;
this is not complete native/transitive custody or independent-process isolation.
Two independently observed Perl `count_keys` guard gaps are owned P1 family75
immediately after74, before unrelated selection. Full admission stays pending.


Rust74.2 applies Length source guards in both direct and trailing-with execution,
including the produced-Length/initial Count distinction above. Its twenty-four
authored source programs now agree on native, restored, generated-plan and
independently compiled emitted routes. For example,
`length("tail").take(1).copy().and(true).with(){return("ran")}` returns null and
skips later effects, while legitimate null/zero still follow ordinary eager
logical and with behavior. Count's independent initial zero fallback remains.

Twelve original healthy observations are unchanged, and the separately observed
Rust scalar/Array source profile matches `[1,1,1,2,2,null]`. The twenty-four
emitted module texts are byte-identical before and after this runtime repair.
Rebuild Rust applications/runtime to use it; no generated format changes.
Final Length and directly dependent Count/length checks pass forty-four groups.
Retained actual Cargo inputs, raw results and replay qualifications are in
`docs/checkpoints/length-guard-rust-2026-11-06/`. Dependency warnings retain their
existing upstream owner. Full native/transitive custody, canonical selection,
general isolation, remaining backends and full admission stay pending.


Dart74.3 now follows the same bounded guard contract. The twenty-four authored
programs pass on native, restored, generated-plan and separate emitted routes;
twelve original healthy observations stay exact. Length results reject Array/
Hash-only consumers before operands and later bodies, while legitimate null/zero,
copy/eager logical behavior and explicit bridges retain their existing semantics.
Initial Count zero remains separate from already produced Length data.

The independently observed Dart source-domain profile is also
`[1,1,1,2,2,null]`; its producer and conversion rules are unchanged. Twenty-four
emitted module bodies are byte-identical before and after: rebuild Dart apps/runtime.
Final Length and directly dependent Count/length checks pass forty-five groups,
with fatal targeted analysis and full owned-file formatting clean. Actual direct
inputs and raw results are retained under
`docs/checkpoints/length-guard-dart-2026-11-06/`. The installed Lua assessment is described below; full custody, isolation,
selection and admission remain pending.


Julia74.4 now implements these Length guards on native, restored, generated-plan
and fresh emitted Module routes. For example,
`length("tail").count().copy().with(){return("ran")}` returns null and skips
the body, while `4.count()` remains Number `0`. An explicit Array bridge such as
`length("x").with(){return([1,2])}.count()` still returns `2`. Valid null/zero,
eager logical effects, source snapshots and existing error wrappers are preserved.

All twenty-four authored programs pass; twelve original healthy observations stay
exact. Julia independently freezes its source-domain profile as
`[1,1,1,2,2,null]`. Its scalar state, initial Count permission and the separate
Array-end mutation restriction are unchanged. Twenty-four emitted module bodies
and parsed inputs are byte-identical before/after; rebuild Julia apps/runtime.
The focused Length/Count checks pass 220 assertions with strict deprecation checks.
Actual declared direct inputs and complete raw evidence survive under
`docs/checkpoints/length-guard-julia-2026-11-06/`. Fresh Modules share a process and
runtime; independent isolation, full native/transitive custody, canonical discovery
and full admission remain pending.


Installed PUC Lua5.5.1 and LuaJIT2.1.1788460057 now implement the same bounded
Length guards after independent baselines. For example,
`length("tail").take(1).copy().and(true).with(){return("ran")}` returns null and
skips later effects. `length(undef).with(){return("recovered")}` still returns
`recovered`, and initial `4.count()` remains Number `0`. The source-domain profile
is independently `[1,1,1,2,2,null]` on both hosts; existing conversion rules stay.

Each host passes all twenty-four authored programs across native, restored,
generated-plan and fresh emitted routes. Twelve original healthy observations
remain exact per host. The new Length checks, nearest Count guards and Count/length
receiver examples pass; existing scalar state and Array-end mutation restrictions
stay unchanged. Twenty-four emitted module bodies and parsed inputs per host are
byte-identical before/after: rebuild Lua applications/runtime. Actual declared
inputs and full raw evidence are retained under
`docs/checkpoints/length-guard-lua-2026-11-06/`.

All five backends now have bounded Length implementations with focused checks.
Full admission, native/transitive custody, canonical discovery and independent
isolation remain pending; the installed-host result does not verify declared
Lua5.4. The next owned defect is key-count (`count_keys`) continuation guards.


## Key-count guards and current Perl prerequisites

The next owned target is `count_keys(value)` and `value.count_keys()` result flow.
Hash counts already feed scalar methods: `count_keys({"k":1}).add(1)` returns `2`.
A legitimate zero still enters `with`:
`count_keys({}).with(){return("recovered")}` returns `recovered`. Explicit Array/
Hash/String bridges retain their existing behavior and source snapshots.

A produced count is Number data. The target for
`count_keys({"k":1}).take(1).with(){return("ran")}` is null with the body skipped;
the assessment-era Perl runs the body. `count_keys({"k":1}).count()` also
returned zero instead of rejecting the Array-only consumer;75.1 now repairs both. Initial CountKeys source policy
and already-produced result consumption must remain distinct.

The assessment retains twenty-two finite programs. Seven original preservation
programs and an additional initial-source continuation control are healthy;
twelve programs expose guard gaps. At the assessment boundary two producer
prerequisites required repair: mutating value blocks emitted invalid Perl, and
Boolean/Array sources raised `Not a HASH reference` where zero is documented.
Both are now focused-checked in75.0.1 and75.0.2 before ordinary Perl guards75.1. The aborted domain probe
is not treated as a valid profile. Independent Count/source/Hash controls identify
the exact causes without changing production code during the assessment.

A wrong `set_key` continuation on computed CountKeys Number2 also reads host
`main::2`. Exact public-substitution and emitted-module controls reproduce that
read with unchanged localized host data. Perl75.1 owns null/skipped-effect seed
regressions; this finding is limited to those carriers and that numeric namespace.
Actual inputs, full raw outputs, modules and readonly recovery are retained under
`docs/checkpoints/key-count-selection-2026-11-06/`.

Perl75.1 is now focused-checked below; next independently assess
Rust75.2, Dart75.3, Julia75.4 and installed Lua75.5. Preserve their own producer/
source domains, signatures, copy depths and mutation restrictions. Full native/
transitive custody, general isolation, canonical discovery and admission remain
pending; no peer failure or declared Lua5.4 support is inferred.

A separate producer check distinguishes numeric input from a Hash binding name:
`count_keys(4)` at the assessment boundary emits a host Hash lookup and returns `1` when seeded
`main::4` has one key. Empty and outer-only seeds return `0`. Both exact public
and emitted-module carriers reproduce this, with host data unchanged. Domain
repair75.0.2 therefore includes numeric-literal classification as well as the
Boolean/Array dereference errors. The empty-process zero observation alone does
not establish the documented numeric-input policy. Broader bare/absent binding
isolation remains separately owned.


Perl typed-source75.0.1 now repairs the value-block compilation prerequisite.
Free CountKeys arguments and canonical zero-extra terminal block receivers use
the same typed source owner. For example,
`count_keys({items=[];push(items,"x");{"k":items.count()}})` returns `1`.
`{items="text";push(items,"x")}.count_keys()` now loads successfully and raises
the required binding error during execution; later defaults cannot mask it.

The unchanged nine-case regression passes after four original failures. Five
healthy observations remain exact, including source-once/order/in-place Hash
snapshots, function parameters and malformed receiver preflight. The new and
nearest Count checks pass twenty-eight groups; only the four failing cases'
emitted modules change. Regenerate emitted Perl. Actual first inputs, full raw
channels and pre-run modules are retained under
`docs/checkpoints/key-count-typed-source-2026-11-06/`.

Perl source-domain75.0.2 now implements the documented initial zero policy.
Computed sources are dereferenced only when they are Hash references; the named
Hash shortcut requires an identifier, so numeric4 stays data. For example,
`count_keys(false)`, `[1].count_keys()` and `count_keys(4)` return `0`, while
`count_keys({"a":1,"b":2})` and a named working Hash still count two keys.

The unchanged23 regression moves ten passing/thirteen failing groups to23PASS.
All ten healthy complete observations remain exact. Twelve localized public/
emitted numeric4 seed controls now return zero with host data unchanged;
non-Hash source-once/order/compatible-add controls complete normally. The final
domain23, typed-source9 and Count-length5 checks pass37 groups. Regenerate emitted
Perl. Actual first inputs, full channels, modules and readonly recovery live in
`docs/checkpoints/key-count-domain-perl-2026-11-06/`.

The original aborted assessment aggregate remains historical;75.1 captures a
valid current profile before its guard edits. Full source/context/transitive custody, legacy
bare/absent binding scope, general isolation/discovery/admission remain separate.


## Ordinary Perl key-count guards

Perl75.1 now guards canonical free CountKeys results and ordinary zero-extra
literal/binding/block prefixes through the existing actual-kind dispatcher.
Incompatible Array/Hash consumers return null before their operands and later
copy/logical/with effects. Produced Number/zero cannot regain Count's initial
zero fallback. For example, `count_keys({}).count()` is null, while
`count_keys({}).with(){return([1,2])}.count()` is2 through an explicit Array bridge.

Initial source zero remains distinct. `false.count_keys().coalesce(7)` now gives0
and `[].count_keys().cat("!")` gives"0!". Later default/text routing no longer
places a Hash guard before that initial producer. Existing Count/Length/numeric/
default results retain strict incompatible-consumer behavior.

The corrected unchanged26-case regression moves thirteen passing/thirteen
failing groups to26PASS: twenty-five ready cases and one excluded function
profile. All thirteen healthy complete observations stay exact. Six exact public/
emitted Number2 host-seed controls now return null without host mutation. Final
guard26/domain23/typed9/Length-Count8/Count-length5=71 focused groups and syntax
pass. Actual first inputs, original/calibrated outputs, modules/carrier, full raw
channels and readonly recovery live under
`docs/checkpoints/key-count-guard-perl-2026-11-06/`. Regenerate emitted Perl.

At this historical75.1 boundary, registered-function prefixes retained their old
route and one Boolean-function continuation stayed null/unready/count_keys.
Callable75.6.1 below independently resolves that observation as a continuation
defect: the terminal Boolean-function count already returns0/ready. Ordinary
peer repairs and installed Lua callable75.6.5 below remain focused-checked.
Full source/context/native-transitive custody, general isolation, legacy
bare/absent bindings, discovery, declared Lua5.4 and full23.4 remain separate.


## Ordinary Rust key-count guards

Rust75.2 independently reproduces twelve failures in the shared22 target before
repair. For example, wrong free consumers yield empty Array/Number1/AKV effects,
and the receiver guard runs SAW. Its free/receiver source-domain profile is two
copies of[0,0,0,0,0,0,2]; needed source errors propagate with the existing generated
wrapper. These are Rust observations, with no imported Perl policy.

Canonical positional free-one/zero-extra prefixes now retain numeric result
ownership in both direct fluent and trailing-with dispatch. Initial source zero
stays distinct from already-produced Count/CountKeys consumption. Incompatible
operands/later copy/logical/with effects remain skipped; zero/explicit bridges/
source snapshots/order/functions/preflight/needed errors stay healthy.

Unchanged22 groups move ten passing/twelve failing to22PASS on native/restored/
plan/compiled emitted routes; all ten healthy observations stay exact. Actual22
emitted modules and serialized inputs are byte-identical. Normal22 plus direct
Count-length1/Count guards19/Length24=66 focused groups and scoped formatting pass.
Rebuild Rust apps/runtime; there is no generated-format or source-regeneration
requirement. Actual declared Cargo inputs, module/serialized bodies and full raw
channels live under `docs/checkpoints/key-count-guard-rust-2026-11-06/`.

The older Length reader remains source-bound to its accepted historical commit;
current Length checks are separate. Dart75.3 and Julia75.4 are focused-checked
below; installed Lua75.5 is also focused-checked and installed Lua callable75.6.5 is focused-checked below. Full source/context/native-
transitive custody, general isolation, canonical discovery and full23.4 admission
remain separate; no host-seeding or declared Lua5.4 claim follows.


## Ordinary Dart key-count guards

Dart75.3 independently reproduces twelve guard gaps in the shared22 target.
Its source profile differs from Rust: free sources give[0,0,0,0,0,0,2], receiver
sources give[0,0,null,0,0,0,2]. In particular, `count_keys(false)` returns0 while
`false.count_keys()` remains null. That existing scalar boundary is preserved.

Canonical free-one/zero-extra CountKeys roles now join kind guards before Count
initial-source permission. A separate one-step KeyCount permission skips only
the common guard; scalarResult initialization/assignments/scalar guard and Count
flag consumption stay intact. Produced counts reject incompatible Array/Hash
operands and later copy/logical/with bodies. Zero, explicit bridges, source
snapshots/order, functions, preflight and needed errors remain healthy.

Unchanged22 groups move ten passing/twelve failing to22PASS across native/
restored/plan/fresh modules. All ten healthy complete observations remain exact,
including error class/diagnostic/wrapper. Actual22 emitted modules/parsed inputs
are byte-identical. New22/Count-length2/Count guards19/Length24=67 focused groups,
fatal targeted root/fresh analysis and scoped formatting pass. Rebuild Dart apps/
runtime; no generated-format or source-regeneration change is needed. Actual
direct inputs and complete raw channels are retained under
`docs/checkpoints/key-count-guard-dart-2026-11-06/`.

The original Length reader remains bound to its accepted historical source;
current Length tests remain separate. Julia75.4 and installed Lua75.5 are focused-
checked below, with loop-index rights preserved; installed Lua callable75.6.5 is focused-checked below. Full source/context/native-transitive
custody, general isolation, canonical discovery/callable75.6 and full23.4 admission
remain separate; no Boolean policy normalization or Dart host-seeding is claimed.


## Ordinary Julia key-count guards

Julia75.4 independently reproduces twelve guard gaps in shared22 controls before
repair. Its free source profile is[0,0,0,0,0,0,2], receiver profile
[0,0,null,0,0,0,2]. `count_keys(false)` returns0 while `false.count_keys()` remains
null under the existing scalar boundary. Needed source errors preserve native/
restored diagnostic/class and generated exception/message wrapper.

Canonical positional free-one/zero-extra CountKeys roles now join common kind
ownership before Count initial-source permission. A distinct first-step KeyCount
permission skips only common guard. scalar_result initialization/assignments/
scalar guard, Count permission, enumerate/call_index and the separate Array-end
mutation restriction stay intact. Already-produced counts reject incompatible
Array/Hash operands and later copy/logical/with bodies; legitimate zero, explicit
bridges, source snapshots/order, functions and preflight stay healthy.

Unchanged22 groups move ten passing/twelve failing to22PASS across native/
restored/plan/fresh Modules; all ten healthy complete observations remain exact.
Actual22 emitted modules/parsed inputs are byte-identical. Current126/Count-length6/
Count guards92/Length122=346 focused assertions pass with strict depwarn and empty
stderr. One normal include is registered. Rebuild Julia applications/runtime;
no source-regeneration/format change. Actual declared first inputs and full raw
channels recover under `docs/checkpoints/key-count-guard-julia-2026-11-06/`, with
six original and four additional effective corruption controls.

The original Length reader remains bound to its acceptedfbe625974 source;
current Length testing remains separate. Fresh Modules share process/runtime.
Rust/Dart Count ownership75.7 and installed Lua75.5 are focused-checked below;
installed Lua callable75.6.5 is focused-checked below; full admission remains separate.
Full source/context/native-transitive custody, general isolation, canonical
discovery/declared Lua5.4 and full23.4 remain separate; no host-seeding claim.

A separate preservation check caught free Count-produced Numbers regaining
KeyCount initial-source zero in the first candidate, including a later with body.
Receiver Count forms already rejected. Excluding canonical free Count ownership
from that initial permission fixes both failing programs; a third authored group
preserves initial Number/free-key zero and Boolean receiver null. Maintained25
programs pass126 assertions, with all25 module/parsed bodies unchanged. Original22
phases/producer patch stay immutable; separate ownership/final-current epochs and
the current-producer patch retain the correction. No prior peer failure is inferred.


## Peer Count-owned-source preservation

Rust/Dart75.7 independently checks the Count-to-CountKeys concern raised by the
first Julia candidate. Both existing implementations already exclude free Count
ownership before initial KeyCount permission, including Rust's direct/trailing-
with paths. New3 programs pass on native/restored/plan/emitted routes on each
backend: free/receiver Count1/0 rejects, later with skips, and initial literal/
free-key/empty Hash zero remains valid. No peer runtime defect is demonstrated.

The separate3 now joins both original22 normals. Each passes25 cases on native/
restored/plan routes, with its existing independent Boolean source profile.
Both runtime source files remain byte-identical to activation50e5933f5. Scoped
formatting and Dart fatal analysis pass. Actual new3 modules/inputs, declared
source/manifest/lock/config/writer inputs and complete raw channels recover under
`docs/checkpoints/count-key-ownership-peers-2026-11-06/`; five corruption controls
reject. Emitted execution in this review covers new3. Full native/transitive
custody, general isolation/source-context discovery/callable/full23.4 remain
separate. Installed Lua75.5 below retains scalar/Count/index mutation rights and
the explicit Count-owned-source controls; installed Lua callable75.6.5 is focused-checked below, with no declared5.4 inference.


## Ordinary installed Lua key-count guards

Lua75.5 independently observes25 programs on both PUC5.5.1 and
LuaJIT2.1.1788460057 before production: thirteen healthy and twelve guard failures.
Free sources give[0,0,0,0,0,0,2], receiver sources[0,0,null,0,0,0,2]. In particular,
free Boolean CountKeys returns0 and receiver Boolean CountKeys remains null.
Both installed hosts agree only after independent observation; native/generated
error message/code/flags and diagnostic stage remain on their existing profiles.

Canonical free-one/zero-extra CountKeys roles now enter common kind ownership
before Count permission. Distinct initial KeyCount permission skips only common
guard and excludes free Count ownership. scalar_result, Count permission, loop
index and the separate Array-end mutation restriction stay exact. The helper
uses the existing namespace and adds no interpreter chunk locals. Produced counts
reject incompatible operands/later copy/logical/with; legitimate zero, explicit
bridges, snapshots/order, preflight and needed errors stay healthy.

Unchanged25 groups13PASS12RED become25PASS/four routes per host. All thirteen
healthy observations remain exact; actual25 emitted modules/parsed inputs per
host stay byte-identical. New126/Count guards92/Length122 checks plus two Count/
length programs on native/plan/fresh pass on each host, with empty final stderr.
Interpreter/runner loadfile checks and three registration lines pass. No unsafe
full runner, formatter or declared5.4 execution. Rebuild Lua applications/runtime;
no source-regeneration/generated-format migration is required.

Actual declared first inputs, pre-run modules/parsed data and all full raw
channels recover under `docs/checkpoints/key-count-guard-lua-2026-11-06/`;
seven effective corruption controls reject. The older Length reader remains bound
to acceptedf5e2350ba, with original proof untouched and current tests separate.
Fresh modules share process/runtime; full native/transitive/toolchain custody,
general isolation/source-context discovery/callable/full23.4 stay separate.
Ordinary guards and bounded callable children are focused-checked across five backends
on recorded hosts. Parent/full admission and named source/context exclusions remain separate.


## Perl function-result CountKeys composition

Callable75.6.1 removes the registered-function-only bypass from the existing
CountKeys result guards. Function calls still use their established typed value
owner; parser, signatures, function scoping and copy depth do not change.
Compatible Hash-function counts now feed numeric/text methods, reject wrong
Array/Hash/Count/CountKeys consumers before their operands, and retain rejection
through copy/logical/immediate with. Source evaluation occurs once before count
snapshot and later operands; valid zero and explicit bridges remain valid.

The separate Boolean terminal probe returns0/ready, distinguishing an earlier
continuation defect from a source-domain exclusion. Its numeric continuation now
returns1/ready. Independently frozen malformed-arity and needed native/generated
binding-error profiles remain exact. The unchanged16-case normal moves7PASS9RED
to16PASS on native/freshly emitted Perl; all seven healthy semantic observations
stay exact. The original inline-two-definition setup failure, corrected15 intake,
terminal discriminator, exact normal epochs and source/module/handler inputs are
retained under `docs/checkpoints/key-count-callable-perl-2026-11-06/`.
Regenerate emitted Perl. Independent Rust75.6.2 is checked below; Dart75.6.3 is checked below; Julia75.6.4 is checked below; installed Lua75.6.5 is checked below. Peers/full admission,
transitive custody and general isolation stay with their existing owners.


## Rust function-result CountKeys preservation

Callable75.6.2 independently confirms existing Rust behavior; no runtime, parser,
compiler, signature or generated-format repair is needed. All 16 source programs
pass on native, reconstructed CompiledSpec, generated-plan and freshly compiled
emitted execution. Hash-function counts retain source-once/count snapshots and
actual-kind guards through copy/logical/with and explicit bridges. Terminal
Boolean count 0, composed result 1 and malformed-arity [null,""] are observed independently;
required binding errors retain native/restored text and the generated wrapper
on plan/fresh routes. No Perl error/domain profile is imported.

The regression covering 16 cases passes on native/restored/plan; existing 25 ordinary CountKeys checks
and four pure-function context checks also pass. Scoped rustfmt and six readonly recovery
corruptions pass. Actual own Cargo source/lock inputs and 16 pre-use module/
serialized inputs/full channels are retained under
`docs/checkpoints/key-count-callable-rust-2026-11-06/`. Rust production source
is byte-identical to the clean activation. This is healthy preservation, not a
product RED/GREEN or a new Rust implementation claim.

Dart75.6.3 is checked below; Julia75.6.4 is checked below; installed Lua75.6.5 is checked below with its own function-result/source/error profiles. Full
source/context/native-transitive custody, general isolation, discovery and full
23.4 admission remain separately owned.


## Dart function-result CountKeys preservation and source qualification

Callable75.6.3, completed through acquisition child75.6.3.1, independently
confirms 12 compatible targets and four Dart profiles over 16 source programs on
native, reconstructed SpecFile, generated-plan and fresh emitted execution.
No runtime, parser, signature or generated-format repair is needed. Hash-function
counts preserve source-once snapshots, actual-kind/copy/logical/with guards and
explicit bridges. Boolean-function terminal/composed receivers remain null/null;
free CountKeys(Boolean-function).add(1) remains1. Native/restored required errors
retain full RuntimeInterpreterException diagnostics; plan/fresh retain the
GeneratedSourceException wrapper. Malformed arity skips all effects.

The first capture declared Dart/pub/config inputs but missed the direct grammar
read by the default function loader. Original intake/normal/direct epochs remain
partial and unchanged. Qualified companions capture
`specs/user_function_definition.spec` before use and pass its exact immutable
string through the published parserSpecSource argument, recording the actual
string before SDK calls. All 16 observations and module/parsed bodies remain
exactly equal to the original; the current qualified normal16/direct29 and fatal
analysis/scoped format pass. Six source/profile/module recovery corruptions reject.
The new private probe also rejects an empty phase path before filesystem effects.
Details/actual inputs are in
`docs/checkpoints/key-count-callable-dart-2026-11-06/`.

The same review names Rust's compile-time include_str! grammar asset as missing
from its saved declaration; observed Rust behavior remains valid, with that build
input/native-cache leg explicitly open. Direct asset closure4.2 and broader
native/transitive/cache provenance under SESSION5 remain before admission.
These limits do not imply a runtime failure or a recovered original first input.
Julia75.6.4 is checked below; installed Lua75.6.5 is checked below; full23.4 remains separate.


## Julia function-result CountKeys preservation

Callable75.6.4 independently confirms existing Julia behavior on sixteen authored
programs/four routes: native, restored SpecFile, generated plan and fresh Module.
No runtime, parser, signature or generated-format repair is needed. Hash-function
counts preserve numeric/text continuations, source-once snapshots, incompatible
Array/Hash/Count/CountKeys guards, later copy/logical/with absorption and explicit
bridges. Boolean-function terminal/composed receivers independently stay null/null;
free CountKeys(Boolean-function).add(1) stays1. Malformed arity skips all effects.
Native/restored required binding errors retain RuntimeInterpreterException text and
the recorded diagnostic fields/stage; plan/fresh retain GeneratedSourceException.

The public parser_spec_source option receives the exact supporting grammar string
from specs/user_function_definition.spec. The original acquisition declares and
captures that asset before invocation and records the actual string before SDK use.
Direct strict-depwarn proof passes84 callable,126 ordinary CountKeys and27 pure-
function-context assertions, with empty stderr. All16 original observations and
actual emitted modules/parsed bodies stay identical; six effective readonly
recovery corruptions reject. The new regression is included once in the runner.
No emitted-source regeneration is required by this preservation-only change.

Actual first inputs, producer bytes, modules/parsed inputs and full channels are
retained under docs/checkpoints/key-count-callable-julia-2026-11-06/. This is finite
healthy preservation, not product RED/GREEN or portable admission. Julia binary,
external packages/depot/cache/full transitive provenance, source-context discovery,
general process isolation and full23.4 remain separately owned. Fresh Modules share
runtime/process. Installed Lua75.6.5 is checked below with independently acquired host profiles.


## Installed Lua function-result CountKeys preservation

Callable75.6.5 independently confirms existing behavior on PUC5.5.1 and
LuaJIT2.1.1788460057. Each host preserves16 authored programs on native, restored
SpecFile, generated-plan and fresh-module routes. No runtime, parser, signature or
generated-format repair is needed. Hash-function counts preserve numeric/text
flow, source-once/count snapshots, incompatible operand/body skips, copy/logical/
with absorption and explicit bridges. Each independently observed Boolean-function
terminal/composed receiver remains null/null; free Boolean CountKeys plus1 stays1.
Malformed arity skips all effects. Needed errors retain their native/generated
text, code, flags and diagnostic stage in separate source-bound host profiles.

The original acquisition declares specs/user_function_definition.spec before host
invocation. It prints the actual immutable string before using the public
user_function_definition_ast_parser_from_spec_source constructor, then supplies
that explicit parser to composition. The new regression does the same. Each host
passes84 callable and126 ordinary CountKeys checks with empty stderr; loadfile-only
interpreter/full-runner syntax checks pass and one three-line normal group is added.
All16 original observations and actual module/parsed bodies per host remain exact.
Eight effective recovery corruptions reject. Actual first inputs/producer/full
channels are retained under docs/checkpoints/key-count-callable-lua-2026-11-06/.

This is finite healthy preservation, not product RED/GREEN or new implementation.
No emitted-source regeneration, unsafe full-runner execution, formatter or declared
Lua5.4 proof is claimed. Fresh modules share runtime/process. Native-build/binary/
cache/transitive provenance, source/context discovery, general isolation and full
23.4 admission remain separately owned. All bounded callable backend children now
have focused outcomes; remaining-family selection23.1.36 resumes from clean Git.


## Selected Hash-view guards and a separate Perl copy gap

Selection23.1.36 retains existing compatible sorted_keys/sorted_values Array
results: ordered keys/values, nested kinds, snapshots, Array/String bridges and
valid empty-Array with already work. Wrong Hash consumers expose seven Perl
failures across original16 full-source controls. Free sources raise native/fresh
Not-a-HASH-reference errors; two literal receiver forms keep raw DSL and fail to
compile despite ready descriptors. Family76 owns the canonical free-one/zero-extra
source/prefix guards, preserving original producers, domains, order and copy depth.
Peers must be independently assessed before any repair verdict.

An independent constructor/copy control also exposes rejection-state loss. At
selection36, copy(["a"]).set_key("k",1).with(){return("ran")} returned"ran";
the incompatible Hash operand is skipped, but the later body runs. A later
coalesce fallback can also run. Array-constructor rejection stays null and skips
its body. Minimal copy6 verifies three failures and three healthy native/fresh
controls at unchanged declared runtime inputs. Legitimate copy(undef).with remains
valid and must still run; treating every null as rejection would be wrong.
P1 Perl76.0 repairs this copy-root/zero-extra copy-prefix gap below, before view76.1.
Earlier Count-copy proof covered another source role, not generic copy closure.

Frozen view15 projects original14 unchanged sources plus a separately qualified
constructor control; it is not one original15 execution. Copy6 stays separate.
The malformed extra-operand receiver remains an unready nonadmitted profile.
Actual inputs, observer, module/handler bodies, complete channels and original
reviewer failure survive under docs/checkpoints/hash-view-selection-2026-11-06/.
A separate qualified readonly reviewer adds an explicit typed-object check and
rejects eight evidence corruptions. This is selection and instrument qualification;
no production repair, peer/full-domain/native-transitive/isolation/admission proof
is implied. Full verification remains deferred until feature coverage.


## Perl copy result rejection state

Perl76.0 retains rejection in canonical free-copy results and zero-extra first
copy prefixes. Wrong-kind consumers skip their operands and later defaults,
repeated copies, eager logical operands and immediate with bodies. Legitimate
copied null, numeric-domain null and empty Arrays still permit their valid
operations. The original typed copy producer, copy depth, signatures, source
snapshots/errors and existing scope/callback/deferred boundaries are preserved.
Regenerate affected emitted Perl; generated format and schema are unchanged.

New12 unchanged-source native/fresh groups move seven healthy/five RED to12PASS.
An intermediate candidate11PASS/1logical compile regression remains preserved;
copy also needs the existing guarded logical consumer emitter. All seven original
healthy semantic observations (including diagnostics/cursors/metadata/warnings)
remain exact. Final/direct emitted module and handler bodies agree byte-for-byte
for all12 sources. The selected five files pass92 top-level TAP tests, including
free/receiver copy, constructor and Count-copy regressions; syntax checks pass.

A one-source same-path control removes only copy from guarded logical ownership
and reproduces native/fresh compile RED. Restoring the exact final owner yields
GREEN with operands/body skipped; the checkout owner remains unchanged. Six
readonly evidence corruptions reject. Complete original/failed/final/direct/
control inputs, producers, module/handler strings and full command channels are
retained in docs/checkpoints/copy-result-guard-perl-2026-11-06/.

This is focused Perl implementation proof. The new standalone normal is
`t/copy_result_guard_composition.t`; explicit canonical registration23.4.1 and
full native/cache/transitive custody, source-context discovery, general isolation,
unassessed peers and full23.4 admission remain separately owned. The independent
Perl Hash-view76.1 outcome follows below; no view or peer repair is inferred from
the copy fix alone.

## Perl ordinary Hash-view result guards

Perl76.1 guards the Array results of canonical ordinary free-one sorted_keys/
sorted_values calls and zero-extra first receiver prefixes. A wrong Hash consumer
returns null and skips its operands, later copies, logical operands and immediate
with bodies. For example,
`sorted_values({"a":1}).set_key("k",1).copy().with(){return("ran")}` stays null.
Compatible Arrays, selected values and explicit bridges retain their actual kinds;
`sorted_keys({}).with(){return(value.count())}` still returns0 with its body run.
The original view producers, key ordering, copy depth, source-once snapshots,
source domains, arities and needed errors remain unchanged. Regenerate emitted Perl.

Actual shared15 at the post-copy compiler has eight healthy/seven RED programs;
the repaired same15 all pass native/fresh. Eight healthy semantic observations and
actual after/direct emitted module/handler bodies are preserved. Five independently
frozen Perl source/arity/error profiles remain unchanged. Malformed extra-argument
forms stay nonadmitted; raw/registered-function receiver compatibility routes are
outside this new prefix role. A one-role source inverse reproduces the reference
error; exact restoration returns null with operands skipped. Eight readonly
recovery corruptions reject.

The first nearest check exposed one obsolete scalar-isolation expectation.
Existing Length74.1 ownership makes `"abc".length().sorted_values()` null because
the Number result rejects a Hash consumer. The free producer's
`sorted_values(length("abc"))` still returns[]. Actual same-path activation/current
controls return[null,[]] with byte-identical emitted bodies. Correct exactly that
fixture expectation; retain the failed first run. The qualified same four files
pass67 top-level tests: new views15, scalar-isolation15, copy12 and constructor25,
including the existing localized host-Hash seeds. No introduction date is inferred.

Evidence, actual source/instrument/input archives, modules and full channels:
docs/checkpoints/hash-view-result-guard-perl-2026-11-06/REVIEW.md. This is focused
Perl proof. New standalone normal `t/hash_view_result_guard_composition.t` needs
canonical registration23.4.1; full native/cache/transitive custody, process isolation,
source/callable context closure, complete cross-backend admission and full23.4 remain
separate. Independent Rust76.2 and Perl follow-up76.6 outcomes follow below. The
later Perl comparison identifies and corrects initial-input regressions that this
first fifteen-source result-guard proof did not cover.

## Rust ordinary Hash-view result guards

Rust76.2 retains canonical positional free-one sorted_keys/sorted_values and
zero-extra first receiver views inside both direct-fluent and trailing-with guards.
Wrong Hash consumers skip operands and later copy/logical/with activity.
`sorted_keys({"a":1}).set_key("k",1)` returns null, and a following copy/with body
keeps that rejection. Original ordered producers, copy depth, source snapshots,
signatures and needed errors are preserved.

Keep initial-source policy separate from produced ownership. Initial Number/null/
Array view receivers retain[]; `undef.sorted_values().with(){return(value.count())}`
returns0 with its body run. Once an Array has been produced, later consumers use
its actual kind before Count/CountKeys initial-source exceptions. Existing guarded
sources retain their prior permissions. Unknown/keyword/traversal and registered-
function receiver compatibility stay outside this new role.

Actual shared15 has eight healthy/seven RED on native/restored/generated-plan/
compiled emitted routes. Five own source profiles and two initial-receiver fences
are acquired in separate original epochs. The unchanged22 maintained normal moves
15healthy7RED to22PASS; a subsequent single22 four-route epoch is GREEN. All15
healthy observations and actual22 serialized inputs/emitted module bodies remain
exact. Rust malformed profiles retain ran/AW and the free Array-source[] fallback;
Perl's distinct profile is not imported. Required source errors keep the existing
generated wrapper. Constructor24/copy6 add30 direct tests, total52; scoped formatting
and eight readonly recovery corruptions pass.

Rebuild Rust apps/runtime. Emitted module bytes, serialization and generated format
remain unchanged. Actual own/Cargo/source/grammar inputs precede compilation,
including the public parser's embedded user_function_definition.spec; native/fresh
inputs/modules and complete raw channels survive under
docs/checkpoints/hash-view-result-guard-rust-2026-11-06/REVIEW.md. Earlier grammar
omissions and full native/cache/transitive/toolchain custody remain4.2/SESSION5-owned.
New normal registration23.4.1, isolation, source/registered-function contexts,
complete peer admission and full23.4 remain separate. Independent Perl76.6
closes its initial-receiver gap below using actual Perl evidence; Rust observations
do not establish its policy. Dart76.3, Julia76.4 and installed Lua76.5 below retain
their own independently acquired source fences.

## Perl first-view policy restoration and numeric source boundary

Perl76.6 corrects eight regressions introduced by76.1's result-guard admission.
Same-path original/current owner controls, with the same surrounding own SDK,
show initial Number/null views changed[] to null, initial Array errors were
suppressed, and two null-source with bodies stopped running. Five valid Hash/
produced Count/CountKeys/Length controls remain correct. The original input-policy
preservation statement lacked these distinguishing receiver controls.

Keep a terminal first view on its original producer. For a longer chain, lower
that first producer once, then guard the resulting Array and later links. Prior
produced/selected/copy/size/logical owners retain their guards. Thus
`undef.sorted_keys().with(){return(value.count())}` again returns0 with its body
run; `[1].sorted_values()` keeps its original source error. Wrong Hash consumers
of a valid view still skip operands, copies, logical links and later bodies.

The original numeric shortcut also exposed a blocking host read. Literal receiver,
free and computed numeric sorted_keys sources select keys from main::3 under the
measured seeded state; current free/computed forms still did so before repair.
Exclude Number ASTs from the named-Hash shortcut and require a reference before
computed dereference. `sorted_keys(3)`, `3.sorted_keys()` and
`sorted_keys(length("abc"))` now keep[] across localized empty/outer/main states.
Actual host values remain unchanged; named Hash keys remain[a,b]. References keep
their old domain/error behavior. This closes those exact numeric probes; broader
bare/absent/other-helper isolation remains SESSION17-owned.

The unchanged17 normal has11 failing groups before and17PASS after; direct view15,
scalar-isolation15 and copy12 make four files59 passing top-level tests. All13
original semantic observations are restored, with only generated eval serials
normalized;12 healthy pre-change observations and25 actual final/direct module+
handler pairs remain exact. Eight readonly recovery corruptions reject. Exact
source/grammar/SDK/fixture inputs, module/handler bodies and full channels survive
at docs/checkpoints/hash-view-receiver-policy-perl-2026-11-06/REVIEW.md.

Regenerate affected emitted Perl, including modules emitted with76.1. The schema
and generated format stay unchanged. Full native/cache/transitive custody, source/
registered-function contexts, general isolation, normal registration23.4.1 and
full23.4 admission remain separate. Dart76.3, Julia76.4 and installed Lua76.5
independently retain their own initial-source and error/arity profiles below.

## Dart ordinary Hash-view result guards

Dart canonical ordinary free-one sorted_keys/sorted_values and zero-extra first
receiver views now retain Array-result guards before incompatible Hash consumers.
For example, `sorted_keys({"a":1}).set_key("k",1)` returns null and skips the
consumer operands; later `.copy().with(){return("ran")}` and logical operands
retain rejection. Compatible ordered views, selected nested kinds, explicit
bridges, source-once snapshots and needed errors keep their original behavior.

Initial producer permission is separate: Number/null/Array initial views retain[];
`undef.sorted_values().with(){return(value.count())}` returns0 with its body run.
A previously produced Count/CountKeys/Length Number still rejects a Hash view and
returns null. Valid Hash/empty-view bodies run. Own malformed receiver extra
operand remains ran/AW, free extra remains ran/W; these excluded profiles are
preservation observations, not new supported signatures or peer normalization.

Original33 public source programs on native/restored/generated-plan/independently
loaded emitted modules show26 healthy/seven RED. The same new normal33 becomes
33PASS, final direct constructor/copy/receiver-arity dependents pass62 and fresh33
passes. All19 own source/error/arity profiles and33 actual emitted/parsed pairs
remain exact. Final fatal scoped analysis, format and eight readonly recovery
corruptions pass. The first format RED and two reader-instrument failures remain
separate; final reader exits0 with empty own stderr. Failed traceback channels use
lossless compressed transport; separate publication recovery preserves that result
and rejects two capsule corruptions. Actual grammar input precedes
SDK use through the published explicit parserSpecSource parameter. Full raw
epochs, producer versions and exact declared inputs survive at
docs/checkpoints/hash-view-result-guard-dart-2026-11-07/REVIEW.md.

Rebuild Dart applications against the updated runtime; emitted module bytes and
format stay unchanged. Source/registered-function contexts, general isolation,
normal registration23.4.1, full native/cache/transitive custody4.2/SESSION5 and
full23.4 remain separate. Independent Julia76.4 and installed Lua76.5 outcomes
below retain their own source/arity/error profiles and actual grammar inputs.

## Julia ordinary Hash-view result guards

Julia canonical ordinary free-one sorted_keys/sorted_values and zero-extra first
receiver views now retain Array-result guards. For example,
`sorted_keys({"a":1}).set_key("k",1)` returns null and skips consumer operands;
later copy/logical/with links retain rejection. Ordered compatible Arrays, nested
selected kinds, explicit bridges, source-once snapshots and needed errors stay.

Initial Number/null/Array views keep[];
`undef.sorted_values().with(){return(value.count())}` returns0 with its body run.
Produced Count/CountKeys/Length Numbers still reject Hash views and stay null.
Valid Hash/empty-view bodies run. Both own malformed extra-operand profiles retain
ran/AW, independently of Dart's free W; these are preservation observations, not
new supported signatures. Original producers/depth, scalar_result boundaries and
enumerate/call_index mutation policy stay unchanged. Registered-function receiver,
unknown, keyword, traversal and non-with trailing forms gain no new view role.

Original33 public source programs on native/restored/generated-plan/fresh Modules
show26 healthy/seven guard failures. Same normal33 completes156PASS28FAIL before
and184PASS after repair; direct constructor/copy dependents total315 passing
assertions under strict depwarn. All19 own profiles and33 actual emitted-parsed
pairs remain exact across four phases. First readonly recovery/eight effective
corruptions pass with empty decoded own stderr. Direct stderr is empty; after's
separate stderr is successful package precompilation. Actual grammar precedes SDK
use through the public explicit parser_spec_source argument. Exact inputs, source
patches, modules and complete raw epochs survive at
docs/checkpoints/hash-view-result-guard-julia-2026-11-07/REVIEW.md.

Rebuild Julia applications/runtime; emitted module bytes and format stay unchanged.
Fresh Modules share runtime/process. Full native/cache/transitive custody4.2/
SESSION5, source/registered-function contexts, general isolation, canonical
registration23.4.1 and full23.4 remain separate. Installed Lua76.5 below retains its
own host profiles and actual grammar before SDK use; declared Lua5.4 remains separate.

## Installed Lua ordinary Hash-view result guards

PUC5.5.1 and LuaJIT2.1.1788460057 independently support canonical ordinary free-one
sorted_keys/sorted_values and zero-extra first-view Array-result guards.
`sorted_keys({"a":1}).set_key("k",1)` returns null and skips the consumer operands;
later copy/logical/with retains rejection. Ordered compatible Arrays, nested
selected kinds, explicit bridges, source-once snapshots and needed errors stay.

Each host preserves initial Number/null/Array views[];
`undef.sorted_values().with(){return(value.count())}` returns0 with its body run.
Produced Count/CountKeys/Length Numbers still reject Hash views and stay null.
Valid Hash/empty-view bodies run. Both own malformed extra-operand profiles remain
ran/AW, independently of Dart's free W; these are preservation observations, not
new signatures. Use the existing namespace with no added interpreter chunk locals;
scalar_result boundaries, loop-index Array-end mutation rights and producers stay.
Registered-function receiver, unknown, keyword, traversal and non-with trailing
forms gain no new view role.

Each original33/four routes exposes26 healthy/seven guard failures. Same normal33
completes184 checks28failures before and184checks0failures after. Direct new184/
constructor116 give300 counted checks per host, plus12 actual value-copy rows
and passing receiver-arity controls. Each19 own profiles/33 actual emitted-parsed
pairs remain exact across four phases; direct stderr is empty. First readonly
recovery/eight effective corruptions pass with empty decoded own stderr. The
actual grammar is retained before SDK use and supplied through the public explicit
parser constructor. One safe runner group and loadfile checks; the full runner
is not executed. Exact input/source patches/modules/full channels survive at
docs/checkpoints/hash-view-result-guard-lua-2026-11-07/REVIEW.md.

Load the updated runtime in Lua applications; emitted bytes and format stay
unchanged per host. Fresh modules share runtime/process. Full native/cache/
transitive custody4.2/SESSION5, source/registered-function contexts, general
isolation, canonical registration23.4.1, declared Lua5.4 and full23.4 remain
separate. All bounded76 backend/source-policy children have focused outcomes;
remaining-family selection23.1.37 below freezes the next bounded repair.

## Selected Hash-valued helper result guards

Selection37 retains one actual original32 public Perl intake at activation795e8c1a.
Its28 eligible unchanged programs contain15 failures and13 healthy controls:
five free incompatible Array consumers return[], five literal receivers retain
raw DSL and compile-fail, three later-body chains run W/D, and two composed
required-error programs compile-fail before their terminal producer's binding
error. Compatible Hash consumers, bridges, nested kinds, variadic keys, source
snapshots, valid empty Hash with and constructor rejection remain healthy.
Four zero-key drop_keys/pick_keys forms are unready/unresolved-helper profiles,
kept outside the shared28 fixture. These are finite authored observations.

The public substitution and actual handlers distinguish legacy take fallback/raw
DSL from the constructor's retained rejection marker. Existing own Perl source/
prefix/retained/copy/with classifications omit these pure Hash-valued roles.
Family77 has independent Perl1/Rust2/Dart3/Julia4/installed Lua5 children.
Perl's preflight outcome follows below; the peer assessments remain pending.
Each first acquires its own unchanged28 and actual initial Number/null/Array,
arity/key-list and required-error policies before production. Preserve source
capture/order, splices, copy depth, mutation and collision differences; keep rename
destinations absent. No peer defect is inferred from Perl.

Evidence: `docs/checkpoints/hash-value-result-selection-2026-11-07/REVIEW.md` and
readonly `review.py`. Actual first inputs/grammars/instruments/full channels and32
emitted module/native handler pairs are retained; first recovery/eight evidence
corruptions pass with empty stderr. The frozen first contract has a backlog-name
erratum in REVIEW: collision normalization remains FUTURE-PARITY-BACKLOG.5.
No SDK production edit, domain/signature/context/deferred/registered-function
expansion, general isolation/native-transitive custody or full23.4 admission.

### Perl preflight: source isolation before composition

Perl77.1.0 retains actual76 programs: unchanged28 targets plus48 independent own
source/shape fences. The shared15 failures/13 healthy controls remain. Number3/
null sources have finite fallback Hashes; Array[1] sources raise existing native/
fresh HASH-reference errors; legitimate null-source with runs W. Existing produced
Count/CountKeys/Length guards returnnull/skip A/W. Extra merge free/receiver stays
ready1 and runs SAW, whereas set_key/rename_key extras and zero-key drop/pick are
unready. Keep these own profiles separate from canonical family77 authority.

Suspicious scalar dereferencing in the actual extra-merge substitution prompted
ten unchanged Number3 sources under localized empty/outer/main host3 states.
Every free/receiver merge_hash/set_key/rename_key/drop_keys/pick_keys source reads
unrelated main::3 entries into native/fresh results only when that Hash is
populated. Empty/outer controls keep the clean fallback, and both host maps are
unchanged before/after. The initial producer inspection finds defined-only computed dereferencing;
source77.0 below also qualifies literal Number named-Hash shortcuts. This is a confirmed bounded source defect,
not a legitimate input policy to preserve.

Immediate P1 source-isolation77.0 precedes composition77.1.1 and independent
peers. Preserve clean fallbacks, wrong-reference errors, actual named Hashes,
source/key/value/overlay order/snapshots, splices, depth, collision and mutation
contracts. No SDK edit occurs in preflight. Its first readonly recovery/eight
effective evidence corruptions pass with empty stderr; actual86 artifact pairs
mean76 first-intake pairs plus10 reused source pairs in the localized acquisition.
The frozen48 own profiles and separate ten-source host-isolation targets retain
their original inputs/full channels. Evidence and historical reader:
`docs/checkpoints/hash-value-result-guard-perl-2026-11-07/PREFLIGHT.md` and
`review_preflight.py`. General SESSION17 isolation, native/cache/transitive
custody4.2/SESSION5, registration, peer verdicts and full23.4 remain separate.

## Perl bounded Hash-helper source isolation

Source77.0 fixes the observed host reads before composition77.1.1. Two routes
need separate guards: computed/String values reach defined-only dereferencing,
while literal Numbers enter named-Hash shortcuts and emit%3/reference-to-%3.
The first edit protects computed/String controls but leaves11 failures; that
original partial epoch stays intact. The final edit reuses76.6's Number-AST
exclusion locally in merge_hash/set_key/rename_key/drop_keys/pick_keys shortcuts
and guards non-reference copying/access. Global extractors, original arity,
key splices, copy depth, collision and statement/operator mutations stay intact.

The unchanged normal64 contains16 localized targets plus48 own source/shape
profiles, intentionally reusing ten source texts across target/policy groups.
Actual14RED becomes64PASS. Number3 pick/drop source-key effects remain SK; null
remains S. All48 original public projections, including Array errors/null-with W/
size guards/extra shapes, stay exact with only eval serials normalized. All host
maps remain unchanged. Exact old/fixed images at one private path reproduce
14RED/64PASS while the checkout stays fixed; four direct files pass93 top-level
tests, including existing set/pick/drop and generated FATAL-warning controls.

All64 actual emitted-module/native-handler pairs match old versus inverse and
final versus restored/direct. First readonly recovery/eight evidence corruptions
pass with empty stderr. Full original/partial/final/private/direct raw channels,
input bytes/modes and actual source images are retained under
`docs/checkpoints/hash-helper-source-isolation-perl-2026-11-07/REVIEW.md` and
`review.py`. The original preflight mechanism prose is explicitly qualified;
no failed epoch or fixture is overwritten. The partial outer wrapper traceback
is disclosed as a tool-result transcription; complete inner channels are kept.

Regenerate Perl parsers emitted before this repair; old emitted code keeps its
producer. Metadata/format v2 are unchanged. This bounded source result does not
close general SESSION17 isolation, native/cache/transitive custody, registration
4.1, peer source policies or full23.4. Clean composition77.1.1 next reacquires
unchanged28/own48 before result-guard edits; independent peers follow.

## Perl pure Hash-valued helper result composition

Perl77.1.1 follows source77.0. Ordinary selected merge_hash/set_key/rename_key/
drop_keys/pick_keys free/receiver roles now retain existing actual-kind and
rejection guards through copy/logical/with. Canonical selected arities remain
merge2/1, set/rename3/2 and drop/pick with at least one key. An initial helper
runs once through its original producer before guarding the result; earlier
retained/view/copy/constructor/size owners keep their own guard permission.
Source77.0's numeric-name/dereference barriers and all original producers remain.

Actual unchanged89 groups comprise shared28 plus13 own initial/earlier-source
targets and48 original public policy projections. Original15RED becomes89PASS.
All74 before-healthy projections remain exact with only eval serials normalized,
including complete Array-with error locations/stages. Initial Number3 helper-with
retains Hash counts/W; prior views/copy/Array constructors reject merge before
A/W. Needed composed source/value errors now equal their terminal controls,
instead of failing compilation. Bool/null values, source-once snapshots, empty
Hash with and source/arity/copy/collision/mutation boundaries remain intact.

Exact old/current images at one private path reproduce15RED/89PASS while the
checkout stays fixed. Direct four files185 pass: new89, source0 isolation64, view
result15 and initial-view source17. All89 actual emitted-module/native-handler
pairs equal old/inverse and current/restored/direct. First readonly recovery/
eight effective corruption controls pass with empty stderr. Complete commands/
channels/actual source images and pre-use own SDK/three conservative grammar/
test/input bytes/modes are retained; the separate direct producer declares both
additional view-source fixtures before use.

Evidence: `docs/checkpoints/hash-value-composition-perl-2026-11-07/REVIEW.md` and
readonly `review.py`. Regenerate previously emitted Perl; metadata and format v2
are unchanged. Rust77.2 then Dart3/Julia4/installed Lua5 assess shared28 and their
own source/arity/error policies independently. No unknown/keyword/traversal/
non-with trailing/deferred/registered receiver/context/domain/signature promotion,
general isolation/native custody/registration4.1 or full23.4 admission follows.


### Rust pure Hash-helper result guards

Rust77.2 independently acquires unchanged28 plus61 own source/shape/prior-owner
controls before edits. All four public routes reproduce13 failures/76 healthy
controls; the unchanged89 ordinary normal is76PASS/13FAIL. Actual compiled actions
contain canonical Hash helper sources and typed take operands. The engine's direct
fluent and trailing-with source-role lists omit these results before existing
actual-kind guards; legacy dispatch evaluates A and later AW/ADW work.

Canonical positional free sources and first receiver prefixes now enter the
existing persistent guards. First-helper source permission applies only without
an earlier retained/view/size/copy/constructor owner. No producer, source fallback,
arity, key/splice/depth/collision, statement/operator mutation or schema changes.
Registered-function receivers, keyword/unknown/traversal/non-with trailing and
deferred/callback roles remain on their original routes.

The unchanged89 normal and post-change four routes pass; all76 originally healthy
observations stay exact. Rust's four required source/value error controls already
propagated before repair and remain exact, including the generated wrapper. Own
initial merge controls ignore Number/null/Array and yield overlay Hashes; set/
rename/drop retain original Number/Array/null; pick yields null. Initial with
bodies still execute W. Six extra-argument SATW/four zero-key AW controls stay
unchanged. Six earlier result owners reject merge before A/W. These independent
profiles do not adopt Perl's source/arity/error policy.

Rebuild Rust applications/runtime; actual emitted modules and serialized format
are unchanged. Full source/context, native/cache/transitive custody4.2/SESSION5,
normal registration4.1, declared-host coverage and full23.4 admission stay separate.
Evidence: docs/checkpoints/hash-value-result-guard-rust-2026-11-07/REVIEW.md.


Two initial Rust private controls fail compilation before tests because the own
runtime embeds cli_conformance/cases/help/stdout.txt. Both attempts/raw channels
remain retained and are not semantic RED. A separate qualified producer declares
the actual help input before build and requires89 distinct frames/test counts;
old/current images at one private own-Rust path give76PASS/13FAIL and89PASS, with
four public routes. The checkout candidate is never replaced. Original public
runs have real semantic observations but omit that first-use help input; disclose
the historical edge under4.2 rather than retroactively asserting complete custody.

Qualified canonical direct141 and scoped rustfmt pass. First authoritative readonly
recovery returns0/empty stderr with nine effective corruption controls, including
rejection of an actual compiler failure as semantic RED. All76 healthy observations
and89 actual serialized/module pairs remain exact across original and qualified
epochs. Independent Dart77.3 follows the clean boundary/daily artifact check;
full verification/admission remains separate.


### Dart pure Hash-helper result guards

Dart77.3 independently acquires shared28 plus61 own source/shape/prior-owner
controls before interpreter edits. Native/restored SpecFile/generated-plan/fresh
execution shows13 failures/76 healthy observations; unchanged89 ordinary tests
are76PASS/13FAIL. Both free and receiver wrong take forms return[] with A, and
later bodies run AW/ADW. Required source/value errors already propagate. Actual
parsed/module inputs retain canonical sources; ActionFluentChain's source-role
list omits Hash-helper results before the existing value dispatcher kind guard.

Canonical positional source/first-prefix roles now retain that actual-kind and
rejection guard. A single first-helper source permission excludes earlier
retained/view/size/copy/constructor owners and keeps the scalar Boolean boundary.
Producers/source/arity/keys/splices/depth/collision/mutation are unchanged; no
unknown/keyword/traversal/non-with trailing/deferred/callback or unassessed
registered-function receiver expansion. Own merge ignores Number/null/Array and
yields overlay Hash; set/rename/drop retain original Number/Array/null; pick
returns null. Initial with W/count0 (merge1), six malformed SATW, four zero-key AW
and six earlier-owner guards remain exact. These are independent compatibility
fences, not new portable source/signature authority.

Unchanged89 and all four public routes PASS; all76 healthy observations/65 own
profiles and89 actual parsed/module pairs stay exact. Required errors retain full
native/restored RuntimeInterpreterException diagnostics and generated framing.
Exact old/current images at one private own-Dart SDK path give13RED/89PASS with
actual89 frames/counts and resolved private routing checked before use; checkout
owner never swapped. Direct five files151, fatal scoped analysis, zero-change
format, candidate identity and first readonly0/empty stderr/eight effective
corruptions PASS. Actual grammar bytes precede SDK compilation/calls and are
passed explicitly; actual emitted/parsed inputs precede fresh loading.

Rebuild Dart applications; emission and serialized format stay unchanged. Full
source/context, native/cache/transitive/toolchain custody4.2/SESSION5, general
isolation, registration prerequisites, declared-host coverage and full23.4 remain
separate. Evidence: docs/checkpoints/hash-value-result-guard-dart-2026-11-07/REVIEW.md.
Independent Julia77.4 follows clean landing, then installed Lua77.5.


### Julia pure Hash-helper result guards

Julia77.4 independently acquires unchanged28 plus61 own source/shape/prior-owner
controls on actual installed1.12.7. All89/four routes expose13 failures/76 healthy;
normal458PASS52FAIL confirms actual source roles are missing before the existing
kind guard. Initial Number/null/Array policies are frozen before production.
Canonical positional merge2, set/rename3 and drop/pick>=2 including receivers now
retain result ownership, with one initial source permission before view/size roles.
Earlier owners, scalar_result assignments/guard, call_index mutation rights and
complete Hash producer bodies remain unchanged.

First partial repair498PASS12FAIL is retained. Actual parse_action_block produces
with block_value, while compile_spec payloads normalize it into codeblock_argument.
Admit only that existing single contextual with operand; explicit deferred
literals/other callbacks and unknown/keyword/traversal/non-with trailing forms gain
no new role. Complete normal510PASS and direct825PASS preserve all76 healthy
observations/65 own profiles/89 actual parsed-module pairs. Six extras retain
SATW, four zero-key profiles AW; needed native/restored diagnostics and generated
framing stay exact. These finite fences establish no portable fallback authority.

Exact old/current private SDKs at one path, with compiled modules disabled and
actual module path verified, reproduce13RED/89PASS with all89 frames. Actual own
inputs/grammar/instruments precede SDK use, artifacts precede execution, full
channels are gzip from first storage. One local runner include/current-candidate
comparison passes. Original first reader fails its manifest1.12.6 host assumption;
every actual captured executable reports1.12.7. Preserve that reader/failure/seal;
separate observed-version reader first returns0/empty stderr/eight effective
corruptions. No failed epoch is called passing.

Rebuild Julia applications/runtime; emitted/parsed formats stay unchanged. Fresh
Modules share runtime/process. Full source/context/native/cache/transitive custody
4.2/SESSION5, general isolation, canonical admission23.4.1 and full23.4 stay separate.
Independent installed Lua77.5 follows clean landing. Evidence:
`docs/checkpoints/hash-value-result-guard-julia-2026-11-07/REVIEW.md`; readonly
`review_observed_version.py` recovers historical proof, not future runtime state.


### Installed Lua pure Hash-helper result guards

Lua77.5 independently acquires89/shared28 plus61 source/shape/prior-owner controls
on each actual PUC5.5.1/LuaJIT2.1.1788460057 host before production. Each exposes13
guard failures/76 healthy observations; unchanged normal510 checks52 failures.
Own compiled with ASTs retain block_value, and the kind-preserving public projector
confirms ordinary operands suffice; no Julia contextual-node exception is imported.
The existing namespace now admits canonical merge2, set/rename3, drop/pick>=2
including receivers, with one first-helper source permission before view/size roles.
No interpreter chunk locals, scalar-result or loop/index mutation changes are added;
entire Hash producer bodies and source/key/splice/depth/collision policies stay.

Each unchanged89/four routes now510 checks0 failures. Direct new510/view184/
constructor116 gives810 counted checks plus12 copy observation rows and passing
receiver-arity controls, with empty stderr. Each exact old/current SDK at one
private path reproduces13RED/89PASS with all89 frames and actual runtime source
verified. All76 healthy observations/65 profiles/89 parsed-module pairs remain
exact per host across six phases. Initial Number/null/Array outcomes/with counts,
six SATW extra profiles, four AW zero-key profiles, six earlier result-owner guards
and full native/generated needed-error fields remain exact. These are finite
preservation fences, not new portable fallback or signature authority.

Published low-level native build/project-data interfaces capture actual own source/
grammar/instruments before build/use and three actual native products before SDK
loading. Full SDK/reader channels are gzip-first; emitted/parsed inputs precede
execution. First readonly recovery0/empty stderr/eight effective corruptions and
one-time current/direct candidate identity pass; no failed epoch/qualification.
The private source/native outputs are removed only after byte/mode recovery.

Load updated runtime in apps; emitted/parsed formats stay unchanged. Fresh modules
share runtime/process; no cross-host byte or general isolation claim. Full source/
context/native/cache/transitive/toolchain custody4.2/SESSION5, canonical registration
23.4.1, declared Lua5.4 and full23.4 remain separate. All bounded77 backend outcomes
have focused proof; remaining-feature selection23.1.38 owns the next clean PNT
step. Evidence: `docs/checkpoints/hash-value-result-guard-lua-2026-11-07/REVIEW.md`;
readonly review.py there recovers historical proof, not a future runtime verdict.


## Selected Array transform result guards

Selection23.1.38 independently acquires37 unchanged public Perl programs for
ordinary take/take_last/drop_front/drop_back/slice/sorted/reversed/concat_arrays
results. All37 report ready1/raw0/fallback0/unresolved0, but19 targets fail: eight
free and three later-tail programs raise Not a HASH reference; eight literal
receiver chains retain DSL and fail handler/module compilation. Eighteen healthy
controls preserve eight compatible transforms, selected String/Hash bridges,
nested kinds/source, once/snapshot order, empty with, four needed source/count
errors and constructor rejection. Actual substitution shows a nonempty-ref copy
where the constructor oracle uses a HASH test plus retained rejection state.
MethodLowering.pm's ordinary free/prefix/retained/copy/logical/with lists omit the
eight Array transform roles. No producer change or peer verdict is made here.

Frozen shared37 and scoped contract own family78. Each backend first acquires its
own unchanged targets and initial Number/null/Hash, optional/excluded-arity,
needed-error and earlier-owner fences. Preserve first producer policy separately
from result ownership, source/order/snapshots/count/start coercion/sort/depth/
splices and all mutation. Other transforms, list-splice/alias/unknown/keyword/
traversal/non-with trailing/deferred/unassessed callable contexts stay outside.
Independent Perl78.1 follows clean selection landing; full23.4 remains separate.

Actual own Perl/three conservative grammars/instruments/inputs precede public SDK
use. All37 emitted modules/native handlers and complete gzip-first channels are
retained; modules precede fresh loading, handlers precede native execution after
Get builds them. Original first reader fails on absent fresh_error for unloaded
modules; second reader recovers positive evidence then fails its first malformed
error-record counterfactual. Both failures/readers/seals remain unchanged. Separate
strict-error-shape reader first returns0/empty stderr/nine effective corruptions;
no source/target/observation is rewritten. Fresh modules share runtime/process;
full native/cache/transitive/toolchain custody4.2/SESSION5, isolation/context/
registration/full23.4 admission remains separate. Evidence:
`docs/checkpoints/array-transform-result-selection-2026-11-07/REVIEW.md`; readonly
`review_typed_errors.py` there recovers historical proof, not a current runtime or
peer verdict.

### Dart Array-transform result assessment

Dart78.3 independently acquires the unchanged37 and104 authored Dart source/arity/
earlier-owner controls on native, restored SpecFile, generated-plan and full
emitted-fresh routes. Nineteen original targets evaluate incompatible Hash
consumer operands (KV), with three later tails also running KVW/KVDW. Constructor
rejection is already healthy. Canonical ordinary transform results now join the
existing persistent actual-kind dispatcher; an initial receiver transform keeps
its source policy without overriding earlier produced or copied owners.

All141 targets pass on the four routes, preserving122 healthy observations and108
complete own/error profiles. Seven initial Number/null/Hash source families yield
empty Arrays; concat_arrays retains that source as an element. Optional defaults,
sixteen excluded extra-arity profiles, six earlier owners, source order/snapshots,
nested Bool/null/Number values, valid empty with and all four needed-error frames
remain unchanged. These finite fences do not define portable input policies.

The exact old/current interpreter images at one private Dart package path reproduce
19 failures/141 passes with actual package routing and full frames checked. Selected
direct292, scoped fatal analysis/format and the first readonly recovery with eight
effective corruptions pass. Formatting changes layout only; the final formatted
source has its own four-route acquisition. All141 parsed/module pairs are byte
equal across initial and repaired acquisitions. Own source/grammar/instruments
precede SDK use; emitted/parsed artifacts precede fresh execution; all channels
are retained. Full native/cache/transitive/toolchain custody4.2/SESSION5, isolation,
source/context/admission and full23.4 remain separate.

Rebuild Dart applications with the updated package; emitted/serialized formats
stay unchanged. Julia78.4 has its independent outcome below. Evidence:
`docs/checkpoints/array-transform-result-guard-dart-2026-11-10/REVIEW.md`; its readonly
reader recovers this historical outcome rather than declaring a future runtime
healthy.

Julia's prospective fixture review identifies one limit in that Dart packet:
the additional direct292 test stream is retained, but its root inventory omits
explicit bindings for older with/Hash test fixtures outside dart. Own141 inputs,
four-route artifacts and the private inverse remain bound. Task23.4.20 supplies a
separate qualified unchanged292 run with those fixture/grammar/owned source inputs
captured before SDK use. The exact original command and all eleven printed result/
grammar stream families agree. Actual original missing-six binding RED/qualified
PASS, original packet/source preservation, first readonly/eight corruptions and
current input identities pass. No runtime/test code changes. Older Git fixtures
do not establish the omitted original first-use identities, which remain unknown.
Original archives, streams, readers and hashes stay unchanged; append-only
explanation points to
`docs/checkpoints/dart-direct-input-qualification-2026-11-10/REVIEW.md`.
Full native/cache/transitive/toolchain custody4.2/SESSION5 remains separate.

### Julia Array-transform result assessment

Julia78.4 independently acquires unchanged37 plus119 authored own controls on
native, restored SpecFile, generated-plan and full emitted-fresh routes. The
original nineteen guard gaps retain Arrays through set_key with KV and later
KVW/KVDW, while constructor rejection already works. Canonical result ownership
now joins the existing persistent guard. One initial-transform permission excludes
earlier retained/constructor/copy/size/view/Hash/Array-result owners. Only the
already compiled single contextual with operand is admitted; deferred literals,
other callbacks, aliases, traversal and broader contexts gain no authority.

The unchanged156 suite moves from827PASS/76FAIL to903PASS, preserving137 healthy
observations and123 full own/error profiles. Seven initial Number/null/Hash source
families yield empty Array/count0W; concat_arrays preserves its source element/
count2W. Ten optional forms, sixteen excluded extra-arity profiles and six earlier
owners retain their policies. Julia's free sorted/reversed extras evaluate A;
Dart's corresponding free extras skip it. Fifteen additional source/count/start/
concat-operand error controls and the original four errors retain full native/
generated framing. These finite fences define no portable input or arity policy.

Selected direct1728 passes, with explicit external fixture bindings captured before
use. Exact old/current interpreters at one private package path, compiled modules
disabled and actual module path checked, reproduce19RED/156PASS and all original/
repaired frames. All156 parsed/emitted pairs remain byte equal across six epochs.
The first readonly recovery returns0/empty stderr and rejects nine corruptions,
including an omitted direct fixture binding. Every declared current direct input
also matches its actual captured identity. Version coherence derives from actual
invocations, not the manifest creation version. The first repaired package run's
stderr reports successful precompilation; selected direct/current-private stderr
is empty. No output is suppressed.

The source adds70 guard/classifier lines and one normal-runner include; producer
bodies, scalar_result and enumerate/call_index mutation policy remain unchanged.
Rebuild Julia applications/runtime; emitted/parsed format stays unchanged. Full
native/cache/transitive/toolchain custody4.2/SESSION5, isolation, source/context/
registration and full23.4 remain separate. Dart input qualification23.4.20 now
supplies its separate new bound epoch; installed Lua78.5 has its own outcome below. Evidence:
`docs/checkpoints/array-transform-result-guard-julia-2026-11-10/REVIEW.md`; its readonly
reader recovers this historical finite result rather than declaring a future
runtime or peer healthy.

### Installed Lua Array-transform result assessment

Installed Lua78.5 independently acquires unchanged37 plus119 own controls on
Lua5.5.1 and LuaJIT2.1.1788460057, each through native, restored SpecFile,
generated-plan and full emitted-fresh routes. Each original interpreter exposes
nineteen guard gaps: Arrays reach incompatible Hash consumers with KV, and later
tails run KVW/KVDW. Constructor rejection already works. Canonical result ownership
now joins the existing persistent guard, with one initial-transform permission
that excludes earlier result owners. Producers and scalar_result remain unchanged;
namespace fields avoid additional interpreter chunk locals. Public compiled with
operands are block_value, so no contextual-node exception is needed.

Each host's unchanged156 moves903 checks/76 failures to903 checks/zero failures,
preserving137 healthy cases/123 full profiles. Seven initial Number/null/Hash source
families yield empty Array/count0W; concat_arrays preserves its source element/
count2W. Optional defaults, all sixteen excluded extra-arity effects, earlier owners
and all nineteen needed-error records remain exact. These compatibility fences
define no portable wrong-kind or arity policy.

Selected direct checks pass1713 counted checks plus twelve with observations and
three fences per host, with empty stderr. Exact old/current interpreters at one
private SDK path reproduce19RED/156PASS and full original/repaired observations;
actual loaded owner paths are checked. All156 parsed/emitted pairs per host stay
byte equal across six epochs. First readonly recovery returns0/empty stderr and
rejects nine corruptions, including an omitted direct fixture binding. Every
current declared direct input matches its captured bytes/modes.

Own source/fixture/grammar/instrument inputs precede documented native build/use;
three real native products per host/epoch precede SDK loading. Actual emitted/
parsed inputs precede execution. Full channels, exact executable versions and
recoverable files/modes survive. Reload applications with the updated Lua runtime;
emitted/serialized formats stay unchanged. Declared Lua5.4, full native/cache/
transitive/toolchain custody4.2/SESSION5, isolation, broader source/context/
registration and full23.4 remain separate. All bounded family78 backend outcomes
have focused proof; this does not close whole-feature admission. Evidence:
`docs/checkpoints/array-transform-result-guard-lua-2026-11-10/REVIEW.md`.

## Selected pure Array-pipeline result guards

Selection23.1.39 freezes36 ordinary existing-contract programs for split_each,
trim_each, filter_nonempty, lowercase_each, uppercase_each, uniq and filter_match.
Original public Perl native/full emitted-fresh observations expose17 failures:
ten free/later Arrays reach set_key's unguarded Hash copy; seven literal receiver
chains retain DSL and fail handler/module compilation. Those seven descriptors
are ready0/unresolved1 naming their pipeline helper; the other29 are ready1 with
zero raw/fallback/unresolved counts. Metadata is preserved rather than normalized.

Nineteen healthy controls preserve compatible free/receiver results, selected
String/Number kinds, once/snapshot source order, valid empty with, pure-value
source preservation, standalone writeback and all four needed source/delimiter
errors. Actual substitutions contrast the pipeline's unguarded Hash copy with
constructor HASH-kind rejection. Ordinary MethodLowering result-role/retained/
copy/logical/with classifications omit these seven pipeline families.

First readonly recovery returns0/empty stderr and rejects eleven effective
corruptions. Actual source/three grammars/instruments precede SDK use; modules
precede fresh loading, and handlers constructed inside public Get are captured
before execution. All36 module/handler pairs, full channels, exact source/Git/modes,
metadata/values/errors/warnings and missing fresh fields after failed load survive.
The unchanged36 shared targets and scoped contract now belong to family79, with
five independent backend leaves starting Perl79.1 after clean selection landing.
No production or peer repair is claimed. Full native/cache/transitive/toolchain
custody4.2/SESSION5, isolation, complete source/context/registration/declared5.4 and
full23.4 remain separate. Evidence:
`docs/checkpoints/array-pipeline-result-selection-2026-11-10/REVIEW.md`.

### Pure-pipeline result guards across recorded backends

Perl79.1.1, Rust79.2, Dart79.3, Julia79.4 and installed Lua79.5 guard canonical results of all seven pure pipeline helpers before incompatible consumers.
Initial producers, Perl source79.0's Number fence and earlier owners retain their original policies.
The [pipeline reference](../dsl/value-container-flow-helper-reference.md) gives tested value/effect examples.
Perl244/private18RED/direct384; Rust173/private11RED/direct374/nine controls; Dart173/private19RED/direct318/eleven controls; Julia173(1006 checks)/private19RED/direct1921/eleven controls; each Lua173(1006 checks)/private17RED/direct1921/eleven controls pass repaired routes.
Perl preserves225 full projections/one descriptor advance; Rust162 records/eleven targets; Dart and Julia154 records/nineteen targets each; each installed Lua156 records/seventeen targets.
Perl retains240 actual source pairs/four syntax exclusions per normal; Rust/Dart/Julia/Lua retain173 serialized-or-parsed/module pairs per acquired epoch.
Regenerate older Perl, rebuild Rust/Dart/Julia and reload Lua. Safe Lua pattern-operand errors use valid text; native formatter/declared5.4/full source/context/native admission stay open. Perl callable first-call arity79.6.1.1 is focused-checked:125 groups/private18RED-repaired125/direct6+66/readonly eleven controls; original178 preserves169 projections and changes nine receiver arities, retaining678 new source pairs.Perl result79.6.1.2 adds188PASS/private30RED-current188,27 supported targets/three separate pattern-readiness movements/158 preserved,940 source pairs/qualified direct441 (1876 artifacts)/first readonly14 controls/current121 identities. Original direct review-input drift failure stays retained without PASS credit; valid function signatures reuse terminal producers, invalid signatures/pattern normalization remain. Safe shared37 excludes Perl malformed literals; Rust callable79.6.2 adds194/four routes/private11RED-current194/direct383/first readonly13 controls/current793 identities: eight supported targets, three separately qualified pattern compatibility movements,183 preserved;388 source pairs/776 normal inputs/seven trace inputs retained. New captures persist/readback before restoration; ordinary historical restore-before-persist claims are qualified and P1 audit4.24 precedes admission. Dart callable79.6.3 adds194/four routes/private19RED-current194/direct383/first readonly17 controls/current497 identities:16 supported targets/three separately qualified pattern compatibility movements/175 full-wire records preserved,388 pairs/776 normal inputs/seven trace inputs. Four interpreter insertions/four deletions; complete available runtime/generated toJson fields and new persist/read/compile/restore order retained. Historical Rust/Dart custody claims stay qualified under P1 audit4.24. Julia callable79.6.4 adds194/four routes776PASS/private20RED-current194/direct1866 assertions/first readonly17 controls/current482 identities:17 supported targets/three separate pattern compatibility movements/174 full-wire records exact. Four interpreter insertions/two deletions and one runner include preserve invocation/producers/formats.1164 own pairs across six epochs plus189 direct prior pairs (1353 total)/eight trace inputs retain new persist/read/restore/compile order and complete available error maps. Native/cache/transitive/source/context/full admission remains separate; installed Lua callable79.6.5 now has each194/four routes1164PASS/private19RED-current194/direct2254/first readonly18 controls/current500 identities:16 supported targets/three separate pattern compatibility movements/175 full records exact. Four interpreter insertions/two deletions/one runner group/no chunk locals;1353 pairs/eight qualified AST-runtime traces per host and byte-exact native products before every load. First trace1 is retained without complete credit; tagged-array qualification passes. Full public error JSON plus outer native fields remain, with new parsed persistence before compile/restore. All bounded ordinary/callable pipeline lanes are focused-checked; parent/full23.4 admission stays separate.
Evidence: `docs/checkpoints/array-pipeline-composition-perl-2026-11-10/REVIEW.md`; `docs/checkpoints/array-pipeline-result-guard-rust-2026-11-11/REVIEW.md`; `docs/checkpoints/array-pipeline-result-guard-dart-2026-11-11/REVIEW.md`; `docs/checkpoints/array-pipeline-result-guard-julia-2026-11-11/REVIEW.md`; `docs/checkpoints/array-pipeline-result-guard-lua-2026-11-11/REVIEW.md`; callable qualification: `docs/checkpoints/array-pipeline-callable-selection-2026-11-11/REVIEW.md`; Perl intake/setup qualification: `docs/checkpoints/array-pipeline-callable-perl-2026-11-11/INTAKE.md`; first-call arity proof: `docs/checkpoints/array-pipeline-callable-arity-perl-2026-11-11/REVIEW.md`. Callable result proof: `docs/checkpoints/array-pipeline-callable-result-perl-2026-11-11/REVIEW.md`. Rust callable proof/order qualification: `docs/checkpoints/array-pipeline-callable-rust-2026-11-11/REVIEW.md`. Dart callable proof: `docs/checkpoints/array-pipeline-callable-dart-2026-11-11/REVIEW.md`. Julia callable proof: `docs/checkpoints/array-pipeline-callable-julia-2026-11-11/REVIEW.md`. Installed Lua callable proof: `docs/checkpoints/array-pipeline-callable-lua-2026-11-11/REVIEW.md`.
Perl callable Array-transform78.6.1.2 is implemented with15 insertions/two deletions through the original terminal producers and valid fixed/rest signatures. Qualified312 groups pass:43 supported result/source-order targets, three separately disclosed initial-source compatibility readiness movements and266 fully preserved observations. Original288 records/source bodies and sixteen positive terminal source/order controls pass before production. Same-path old control reaches312 and fails43 targets plus the three metadata controls; current312 passes. Direct original212 ordinary-transform/188 callable-pipeline groups and syntax pass with2008 retained API artifacts. Historical recovery retains1872 pairs, qualified readonly0/seventeen controls/current165 named identities; original reader1/Git-full-mode qualification remains, without chmod or changed SDK observations. The first post-change actual3 result and original fixture/normal/classification remain intact; qualification changes only those three readiness projections, with no product-RED or portable input-kind credit. Selection23.1.41/frozen Perl intake78.6.1.0 retain their original evidence and literal-constructor qualification; initial-literal inventory1.2.1.3.1, excluded-shape inventory1.2.1.4.3 and open concat selection42 remain separate. Independent peers follow the clean Perl slice; full admission is pending. Perl modules precede fresh loading; standalone source dumps follow internal native compilation and precede invocation, with native precompile/historical closure owned by4.2/SESSION5. Evidence: docs/checkpoints/array-transform-callable-result-perl-2026-11-11/REVIEW.md. First staged task-collection pressure is retained; only this leaf's new commentary is routed with original contracts exact. Approved bounded headroom4.27 now renews52253 task bytes from closed SPEC-LANG-REFERENCE:45 ordered IDs/42 closed pointers/three unchanged bodies/full71681-byte tail and46 exact public queries/ten corruption controls remain. Tools/limits are unchanged. Independent Rust78.6.2 has a bounded five-insertion/four-deletion transform-classifier repair and passing312 public four-route comparisons:20 supported targets, three separately disclosed initial-source continuation movements and289 preserved records. All96 initial terminal/first-with policies remain exact; no portable wrong-input admission follows. Original normal20RED/292PASS, failed comparisons/diagnostic and exact83-byte original launcher notice are retained in docs/checkpoints/array-transform-callable-rust-2026-11-11/QUALIFICATION.md. Qualified same-path23RED-current312/direct701 and first full readonly0/23 controls/current825 pass;624 parsed/compiled/module triples remain exact. Rebuild Rust applications. Independent Dart78.6.3 now has a classifier4/4 repair:312/four routes/28 supported targets/three separate initial-source compatibility/281 preserved and104 initial policies exact, including Boolean receiver-null/free-empty. Same-path31RED-current312/direct647/qualified readonly0 with24 controls/current510 pass;624 parsed-module pairs/1248 normal inputs/nine trace inputs remain. Original reader1 from JSON-comparing bytes is preserved; qualified reader changes only that raw-channel control. Exact outer83-byte launcher notice is retained under SESSION7; actual Dart native/fresh stderr empty, final PGID uncaptured. Complete available error maps and new parsed-before-compile/restore order survive; rebuild Dart applications. Independent Julia78.6.4 now has a classifier4/2 repair and one runner include:312/four-route1248 assertions,28 supported targets/three separate initial-source compatibility/281 preserved/104 initial policies exact. Boolean receiver-null/free-empty and both free/receiver sorted-reversed excess SXKVW remain. Same-path31RED-current312/direct2927 assertions/first full readonly0 with24 controls/current519 pass;1872 pairs/nine traced parsed inputs retain full public error maps and new first-use order. Actual successful root precompile and expected old Test stderr remain exact; older direct transient strings receive no new native/artifact-custody credit. Rebuild Julia applications. Installed Lua78.6.5 now has classifier4/2 plus one three-line runner group/no chunk locals: each host312/four routes/1872 checks/28 supported targets/three separate initial compatibility/281 preserved/104 initial policies exact. Same-path31RED-current312/direct3939 and qualified2 readonly0 with26 controls/current531 pass;1872 pairs/nine traces/two native field probes per host survive. Full published error JSON/text and named outer flags stay exact; raw-field projection/absence is explicit, with broader historical observability4.28 owned before admission. Original setup1 and two reader1 outcomes remain with minimal separate qualifications;58 archived exact plain duplicates retire without proof loss. Reload Lua applications. Open concat selection42 now retains84 valid-Array Perl programs/66 contract passes/18 terminal-supported continuation failures,84 actual module-dump pairs/first readonly14/current126. Frozen bounded80 owns independent backend repairs; no production change or peer verdict. The helper catalog documents its existing multi-Array purpose and qualified single-Array Perl terminal support. Perl80.1 now has focused504/26 supported targets/four separate compatibility/474 preserved and80 initial policies exact, with SDK5/4 result-role bounds only. Same-path old30-current504/direct1028/first strict readonly25/current186 pass;3024 epoch pairs plus four original-owner signature-oracle pairs survive. Original before28/after2 capture1/comparator1/qualification1 and original-v1 data remain with separate minimal qualifications. Two legacy excess-operand continuations retain terminal SX; two still-rejected function requests retain bad-callee/TU attribution, with no non-Array or invalid-function admission credit. Headroom29 now preserves25 ordered IDs/22 closed pointers/three unchanged bodies/full22339-byte tail and renews48937 task bytes through the existing unpartitioned REPO-HYGIENE epoch. All26 public queries/first readonly10/current identity0 pass; limits/tools/runtime remain unchanged. Independent Rust80.2 now has a two-line selector/comment repair:504 four-route records pass, with16 supported targets/two separate legacy operand continuations/486 fully preserved records. All80 initial policies/eight invalid signatures stay exact. Same-path old18RED-current504/combined direct1205/qualified2 readonly25/current871 pass;504 before-after parsed/compiled/emitted triples stay exact. Original producers/function dispatch/signatures/formats remain unchanged; rebuild Rust applications. Complete native/cache/toolchain/OS/transitive closure stays4.2/SESSION5. The first direct1/ordinary193+2 failure is retained; two extra ordinary expectations outside504 are qualified through exact terminal/composed old/current probes, and only missing508 checks then pass. Independent Dart80.3 is now focused-checked with a one-line result-arity guard:508/four routes/20 supported/four separate legacy operand continuations/484 exact records,80 initial/eight invalid signatures preserved; same-path old24-current508/direct1155/first readonly9/current521/format pass.1016 parsed/module pairs and2032 normal snapshots retain complete available error JSON and authored source identities. Rebuild Dart applications. Bounded monitor23.4.30.1 now records HEAD102ec3446/cached origin4683555e at1,257,281,519 bytes,242,718,481 below trigger; actual native index/qualified verify and12 corruption controls pass, with original filename failure retained. Full native/raw/toolchain durability remains4.2/SESSION5. Remeasure after the monitor commit, then independent Julia/Lua while margin permits; canonical publication preempts cadence near the budget. Director publication steering monitors outgoing packed bytes after each leaf and pushes around1,500,000,000 bytes even mid-batch/PNT, with clean exact-HEAD canonical CI before every push. Evidence: docs/checkpoints/array-concat-open-arity-dart-2026-11-12/REVIEW.md. Rust evidence: docs/checkpoints/array-concat-open-arity-rust-2026-11-12/REVIEW.md. Evidence: docs/checkpoints/task-headroom-hygiene-2026-11-12/REVIEW.md. Evidence: docs/checkpoints/array-concat-open-arity-perl-2026-11-12/REVIEW.md. Full23.4/native4.2/SESSION5/historical4.24/source/context/isolation/registration/SESSION7/formatter/declared5.4 remain open. Evidence: docs/checkpoints/array-concat-open-arity-selection-2026-11-12/REVIEW.md. Evidence: docs/checkpoints/array-transform-callable-lua-2026-11-12/REVIEW.md. Evidence: docs/checkpoints/array-transform-callable-julia-2026-11-12/REVIEW.md. Evidence: docs/checkpoints/array-transform-callable-dart-2026-11-12/REVIEW.md. Evidence: docs/checkpoints/task-headroom-spec-reference-2026-11-11/REVIEW.md.
