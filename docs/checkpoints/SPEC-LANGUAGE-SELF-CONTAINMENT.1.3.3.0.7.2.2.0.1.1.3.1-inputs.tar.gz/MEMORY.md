# MEMORY

- activation_commit: `80ecf47f258a7f23a59598a1c5500a34fe662a7c` — clean basic regex provenance activation base.
- latest_completed_leaf: `SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.2.2.0.1.1.0 - retain basic regex match provenance`.
- active_work_unit: `SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.2.2.0.1.1.3` (pending) — selected consumer/render proof input closure.
- next_action: Activate P1 .1.1.3 to freeze/re-measure actual selected consumer/render inputs and distinguishing controls; preserve original transcripts. Statement frames .1.1.1 follows its clean acceptance.
- in_flight_uncommitted: none; basic regex hooks, complete proof and documentation are committed; no background job remains.
- blockers: No access/decision blocker. Matches and attached/marker/value/null/while executors are repaired; control parent/order and raw-expression reporting are reconciled; quoted/comment readiness .7.2/.3 precedes dispatcher/full execution. Other startup repairs remain separate.
  Wrapper startup .7 remains open; recovery/purge stay prohibited.
- current_task_index_contract: checker-owned closed-state markers live only between the stable sentinels after the
  active table; the task metadata doctrine inventories all consumers, permits arbitrary frontier-row rewrites,
  and requires every exact current task ID to be unique across partitioned and unpartitioned storage.
- current_write_vivification: `linkedspec-write-vivification-v1` is implemented on all five backends with one typed expression-segment AST,
  evaluated string/integer harray/array selection, dense atomic creation, post-evaluation snapshots, detached
  results, exact diagnostics/spans and invocation-local absent/null presence. The neutral validator rejects 105 mutations;
  all three frozen read exclusions now run through Perl lowering; .89 verifies non-creating native/fresh generated reads. Other runtimes preserve writes through supported serialized/reconstructed/
  generated/emitted carriers. Portable capability `language.nested_write_vivification` is admitted by `.19.7`;
  exact six-runtime recurrence is complete under `.19.8`, and public teaching/no-drift is closed under `.19.9`.
- current_map_leaves_mutation: `linkedspec-map-leaves-mutation-v1` is implemented on all five backends with one bang-only mutation AST,
  resolved receiver identity guard, root-kind original-shape traversal, copied frames, atomic rebind, detached
  result, post-commit continuation, exact diagnostics/exclusions, and 167 base mutations. Known gaps affect Rust final assignments
  and substitution, plus Perl callback substitution (startup .58/.59). The typed node survives supported
  reconstructed/generated/emitted carriers; admitted guard tests remain bounded to their covered routes.
  The Lua suite passes 530 assertions per ABI. Portable capability
  `language.map_leaves_receiver_mutation` is admitted by `.19.7`; exact six-runtime recurrence is complete under
  `.19.8`, and public teaching/no-drift is closed under `.19.9`.
- current_rule_entry_dispatch_invariant: selecting a rule enters its handler and starts its mode-driven execution;
  entry alone never tests that rule's own regex. An outgoing `->` match edge selects its target rule's regex. Rust now has
  both the direct-entry negative lock and a zero-regex-parent positive trace with typed `target_rule=Done`; the
  shared corpus has no controlled inert `/x/ -> Done` root; two Perl generations and complete Rust/Dart/Julia/
  PUC-Lua/LuaJIT 105-case corpus routes are green. Root selection passes its exact five-backend/six-runtime driver,
  recursive observation passes all six routes, the repository-managed Rust trace target passes 12/12, and exact
  staged canonical signoff plus both 66/66 CLI environments and Phase 0 1,032/1,032 are green.
- canonical_ci_execution: use approved host execution for `tools/run_ci_local.sh`; nested macOS containment
  requires it. See `docs/knowledge/project-data-process-locality-proof.md`.
- current_rust_launch_evidence: Newer-OS controlled diagnosis/conditional repair is pending under startup .81; see `docs/knowledge/macos-rust-first-launch-validation-latency.md`.
- current_mutation_composition_contract: `linkedspec-write-map-leaves-composition-v1` digest-binds both unchanged
  mechanisms across eight writes, six callback cases, one continuation, and 592 current composition mutations;
  Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT execute both halves through one governed recurring driver. Zero-regex
  `Top:: -> Done` lets the parent loop select and match `Done`'s regex, not an inert parent one.
- current_map_leaves_scope_resolution: option A preserves pure functions. Helper-mediated rejection uses inline
  explicit-target `set(tree, ...)`; post-commit receiver-write proof uses caller-scoped `.with()`. No implicit
  caller capture or arbitrary user-defined bang method is admitted.
- current_mutation_public_no_drift: `.19.9` closes public no-drift; current inventory is 71 Markdown files / 14 governed documents / eleven
  authority-bound example classes / ten stale-current denials / 50 isolated public-checker mutations. Capability
  governance independently pins the owner and exact-one CI registration through four mutations.
- current_core_state: typed source is 14/0/231; recognition 138/250/58; progressive 9/9/116 plus public
  6/12/10/60; gap 9/0/63 plus public 8/15/10/34; staged 9/9/123 plus public 6/17/10/129; capability 100/0/0;
  semantic introspection 9/0/128.
- standing_contracts: all durable paths are repo-relative; all project data stays on the repository filesystem; Only LinkedSpec is writable; every other Git repository is read-only (director September27; see AGENTS and the incident record).
  README remains bounded; ordinary leaves use focused proof and designated infrastructure/public/push boundaries
  use exact staged canonical CI; task-tree/index, Knowledge Map, mdBook, and bounded live/history move in lockstep.
- current_engineering_notes_capacity: ADR0122 admits43 files /42 manifest lines /25410 bytes; latest manifest42 lines/25409 bytes remains within its exact bound.
  Diagnosis rollover segment4965 preserves231 lines/25099 bytes from clean012038a637; prior immutable rows/bytes remain exact.
- current_change_history_capacity: ADR0122 admits47 files /46 manifest lines /26255 bytes; latest manifest45 lines/25679 bytes remains bounded.
  Diagnosis rollover segment4967 preserves212 lines/21636 bytes from clean012038a637; prior immutable rows/bytes remain exact.
- dependency_boundary: RGX public integration only; it owns PGEN. No internal inspection/analysis, patches, separate PGEN procedure or unrelated pin changes. September26 authorizes only reviewed f6e5acdc for LS-004.
  Normal documented builds remain authorized; retain caches. Startup .80.1-.4 may observe public behavior or track upstream repairs, not investigate dependency internals.
- latest_bootstrap_read: ADR0123 targets 2–5 minute startup plus thorough task-specific reading. Separate audit remains 89/143 and .1.90. Document integration and .46/.47/.49/.86.1/.86.2 are verified; Perl .86.4.2.4 corrects the regex-type premise; .86.4.3 owns supported helper validation (verified); .86.4.6 verifies helper splitting; .86.4.7 verifies quoted subjects; .86.4.4.1 owns grouped-operand repair .86.4.8; .86.4.8.1 rejects incompatible lookahead and .86.4.8.2 verifies grouped repair; .86.4.4.2.1 fixes generated Trace and .86.4.4.2.2 closes bounded public recomposition; .87 owns four helper/grouping follow-ups. No downstream application acceptance claim.
