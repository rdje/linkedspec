# Capability conformance inventory

`manifest.json` is the machine-readable census of current user-observable LinkedSpec capabilities across the five
admitted backends. It complements, rather than replaces, the executable 105-fixture interpreter corpus and the
66-case primary CLI manifest.

## Language closure definition

`language_closure_contract.json` freezes operation/scope/reference structure and scoped determinism,
progress/resources, failure publication and ambient non-authority as `linkedspec-language-closure-v1`.
It binds sixteen existing authorities through 90 semantic anchors (original 66 plus24 inherited-policy anchors), seven
authored operation categories and eight distinct scopes. It preserves partial/unassessed obligations,
compatibility exclusions and caller-owned source/registry/sink authority. It changes no runtime admission.

```sh
bash tools/run_python_project_data.sh tools/check_language_closure_contract.py
```

The independent closed schema checks exact identities, scope/effect/result relationships and proof owners.
Each anchor is SHA-256 of UTF-8 JSON with sorted object keys, compact separators, literal Unicode and finite
numbers; unselected historical rollout metadata is outside that digest. Its636 reason-sensitive mutations and
four controls reject weakening, selected-source drift and missing/duplicate CI registration. This is structural
governance, not execution of an authored objective or its adversarial proof requirements. Resource/source-detail
and lexical-order repairs retain their owners/prerequisites. Independent definition reconciliation is complete under .1.2.4; composed-objective
execution/admission remains pending. The dated audit/checkpoint under tests/language-readiness and docs/checkpoints
compares committed baselines, matrix/checker syntax, external repair-task bytes and rendered claims. No global bound, timing guarantee or sandbox proof follows.
The dated readable review is docs/language-readiness/closure-policy-boundaries.md.

The stable row `runtime.top_rule_and_parse_mode_controls` describes explicit entry selection, then the first
authored marker or rule, plus intrinsic AND-consume / OR-default-seek and independent child policy. Its historical
identifier is retained; public/global overrides are removed. The row now cites the root-selection and cursor
authorities directly. The capability checker pins the description, category, source references, authority IDs,
selection precedence and four cursor-policy fields, with fifteen reason-sensitive mutations including the old
accepted-override claim. The census and runtime behavior remain unchanged.


## Bounded composed objective fixtures

`composed_objective_contract.json` freezes `linkedspec-composed-objectives-v1` at16 cases/3 grammar sources/
eight dimensions, retaining23 original probe identities. The explicit fixture expectations and independent
ASCII/shape/event checker preserve booleans, order, quiet delivery, exit, caller-error identity, arity and
actual-object detachment requirements. Run:

```sh
bash tools/run_python_project_data.sh tools/check_composed_objective_contract.py
```

The140 structural,16 observation and44 producer-report falsifiers plus four controls establish neutral
governance; the checker executes no DSL or admits a runtime. Native evidence remains producer-owned beside
private predicates. Exact CI registrations and historical-byte normalization preserve original proof.
`docs/language-readiness/composed-objective-governance.md` records the boundary; P1 Perl repair .1.3.3.0
precedes execution .1.3.3.1. All wider repairs and realistic-format requirements remain separate.

## Standalone lifecycle block

`standalone_lifecycle_block_contract.json` closes the exact shorthand from ADR `0094`: a standalone rule-body
`{ ... }` normalizes to lifecycle `I`, preserves actual source/opening line and explicit-twin ActionIR semantics,
orders duplicates, keeps earlier brace owners, rejects malformed twins, and leaves legacy plain carriers inert.
Its six runtime routes plus the permanent self-hosted grammar run through
`bash tools/check_standalone_lifecycle_block_five_backend.sh`. At that feature's admission boundary, the resulting
18-row capability census was 90 pass / 0 partial / 0 gap. Mutation admission `.19.7` has since added two exact
language-runtime rows, so the current census is 20 capabilities and 100 pass / 0 partial / 0 gap.

## Neutral write vivification

`write_vivification_contract.json` freezes the backend-neutral nested-write direction from ADR `0036` without
itself admitting a public capability. Ordinary `IDENTIFIER[SEGMENT]... = VALUE` syntax lowers to one neutral
`assign_nested_access` shape whose segment kind comes from the evaluated expression: string selects harray and
nonnegative integer selects dense array. The fixture fixes missing-container creation, absent-versus-null,
left-to-right segments then RHS, same-binding side effects before the isolated snapshot, copy-on-write commit,
detached results, read exclusions, and exact Unicode-scalar syntax/structural diagnostics. Run:

```bash
bash tools/run_python_project_data.sh tools/check_write_vivification_contract.py
```

The checker validates five AST cases, seven syntax failures, 11 successful writes, 16 structural failures, three
expression failures, three non-creating reads, detachment, eight writes from the shared composition fixture, and
105 rejected base mutations. Perl, Rust, Dart, Julia, and shared Lua now consume this unchanged contract through
typed native and supported reconstructed/generated/emitted carriers; PUC Lua and LuaJIT execute the shared Lua
consumer independently. `.19.7` admits `language.nested_write_vivification` with exact production/test references
for all five backends and immutable composition-authority linkage. Exact six-runtime recurrence is complete under
`.19.8`; `.19.9` closes current public no-drift without rewriting this frozen authority.

## Neutral `map_leaves!` receiver mutation

`map_leaves_mutation_contract.json` freezes the other backend-neutral half of ADR `0036` without itself admitting
a public capability. It reserves exactly `IDENTIFIER.map_leaves!() { ... }`, gives that surface a dedicated
`receiver_mutation_chain` AST, and requires the receiver to resolve to one existing harray/array uniform-binding
identity. Mapping traverses a detached original-shape snapshot with the current root-kind recursion rule, copied
callback fields and stable paths, result replacement, and replacement-subtree non-revisit. Complete success commits
once and returns a detached root; callback failure leaves the receiver unchanged.

The active receiver identity is write-protected while callbacks run. Direct, nested-write, nested-bang, and helper-
mediated writes to it receive one typed `receiver_mutation_reentrant` diagnostic before the attempted write. A
same-spelling shadow binding and unrelated bindings remain independent. Ordinary fluent continuation begins after
commit against the detached return, so a continuation failure does not roll back the completed bang call. Run:

```bash
bash tools/run_python_project_data.sh tools/check_map_leaves_mutation_contract.py
```

The checker validates four syntax forms, fourteen exact syntax failures, five exclusions, ten successful state-
machine cases, eight pre-commit failures, continuation/shadow/guard-release/non-bang/detachment proof, six shared
callback compositions, one post-commit continuation composition, 167 base mutations, and 593 composition
mutations at the original freeze boundary. The pure-function-preserving carrier correction retains every
observation and yields 592 current composition mutations. Perl consumes the exact contract under `.19.2.2`, with
permanent direct proof in `t/map_leaves_mutation_perl_contract.t`; Rust, Dart, Julia, and shared Lua consume the
same authority through typed native and supported reconstructed/generated/emitted carriers, with PUC Lua and
LuaJIT independently executing the shared Lua consumer. `.19.7` admits
`language.map_leaves_receiver_mutation` with exact production/test references on all five backends. The byte-
identical non-bang control remains unchanged; exact six-runtime recurrence is complete under `.19.8`, and final
public-current no-drift is closed under `.19.9`.

## Neutral write/receiver-mutation composition

`write_map_leaves_composition_contract.json` binds the two neutral authorities by contract identity, root-
relative path, and canonical-JSON digest. It is a fixture consumed by both existing checkers, not a third
executable entrypoint. Eight nested writes prove callback-local vivification, replacement-subtree non-revisit,
unrelated success, unrelated effects across a later callback failure, write-local structural rollback with
completed RHS effects, same-receiver guard precedence before segment/RHS evaluation, distinct same-spelling
shadow identity, and a receiver write reached after commit and guard release.

The composition keeps the two atomicity domains distinct. `map_leaves!` commits only its rebuilt receiver after
all callbacks succeed; ordinary writes to unrelated identities commit or fail under the nested-write contract.
Consequently a later callback failure preserves earlier unrelated writes, while an unrelated nested-write failure
aborts the receiver commit and propagates its unchanged diagnostic. A continuation-side write failure occurs
after the receiver commit and cannot roll it back.

Run both existing authorities:

```bash
bash tools/run_python_project_data.sh tools/check_write_vivification_contract.py
bash tools/run_python_project_data.sh tools/check_map_leaves_mutation_contract.py
```

The exact composed fixture has a non-bang control returning `{"leaf":[]}` on all six runtime routes. Perl, Rust,
Dart, Julia, PUC Lua, and LuaJIT execute the bang form and its nested-write composition. The composition remains a
dependency shared by the two admitted capability rows rather than a third capability. The capability checker pins
both neutral authority IDs, formats, freeze statuses, canonical JSON digests, exact row order, five backend proof
sets, and the Lua dual-ABI note through 16 rejected admission mutations. `.19.8` now supplies the recurring
composed driver; `.19.9` closes final public-current examples and no-drift.

## Recurring mutation proof

Run the exact repository-routed recurrence with:

```bash
bash tools/check_mutation_six_runtime.sh
```

The driver validates the write authority and bang/composition authority first, then executes Perl, Rust, Dart,
Julia, PUC Lua, and LuaJIT consumers in that fixed order before generated-source, capability, and language-
coverage ledgers. It enters the project-data environment before invoking toolchains. The Dart leg refreshes
locked package metadata through routed `pub get --offline`; it does not consult the network or a global cache.

`tools/check_capability_conformance.pl` binds the recurring owner, driver, canonical opt-in switch, storage
initializer, all three historical artifact IDs/statuses/canonical JSON digests, exact command and route order,
support-ledger order, executable state, and exact-one canonical-CI registration. Seventeen rejected recurring
mutations cover authority omission/order/digest/status, route omission/substitution/order, support omission/order,
storage substitution, owner state, driver omission, CI omission/duplication, and live artifact status/digest drift.
Canonical CI always requires, path-audits, and syntax-checks the driver; `LINKEDSPEC_RUN_MUTATION_MATRIX=1`
executes it exactly once. This recurring boundary changes no capability row, frozen authority byte, production
behavior, or public-current example.

## Public mutation surface

`tools/check_mutation_public_surface.py` binds the current public teaching back to the three frozen authorities.
It inventories the bounded root/component/mdBook Markdown surface, requires exact current anchors in every
mutation-owning document, verifies examples for creation, dense arrays, conflicts, evaluation order, original-
shape traversal, callback fields, receiver identity, rollback, detachment, composition, and post-commit
continuation, and rejects stale unsupported/non-vivifying claims. It deliberately excludes task, decision,
Knowledge, and history records from its stale-current scan so historically accurate freeze/rollout evidence is
not rewritten. Run:

```bash
bash tools/run_python_project_data.sh tools/check_mutation_public_surface.py
```

Canonical local CI tracks and runs this checker on every invocation. The capability checker pins its `.19.9`
owner, repository-relative path, and exact-one CI execution. This adds documentation no-drift proof only: both
capability rows remain unchanged at the 20-capability / 100-pass / 0-partial / 0-gap census.

`mcp_semantic_transport_contract.json` (`linkedspec-mcp-transport-v1`) is the single backend-neutral machine
contract for LinkedSpec's modern MCP `2026-07-28` stdio projection. Its root-relative artifact inventory pins the
closed JSON Schema 2020-12 envelope/tool definitions, four semantic payloads, 35 canonical LF-framed JSON-RPC
messages, ten exact raw-byte inputs, ten lifecycle cases, four indistinguishable handle states, four deployment-
policy cases, the deterministic materializer, the independent validator, and its 76-case mutation corpus. The five native server identities share these exact
files; PUC Lua and LuaJIT consume the same Lua identity and implementation. Run:

```bash
bash tools/run_python_project_data.sh tools/materialize_mcp_semantic_transport_contract.py
bash tools/run_python_project_data.sh tools/check_mcp_semantic_transport_contract.py
```

The materializer rejects duplicate source keys, unresolved schema references, topology/count drift, native
semantic-response digest drift, text/structured-content mismatch, handle/policy dispatch drift, noncanonical or
oversized frames, stale generated JSONL, and any artifact digest change. `--write` is the explicit regeneration
mode; `--print-digests` reports reviewable bootstrap/update hashes. The separate checker never imports or executes
the materializer. It implements the exact JSON Schema 2020-12 keyword profile, independently proves 28 accepted
plus seven deliberately rejected frames, raw-input error ownership, native/restricted payload identity, handle/
policy outcomes, and ten lifecycle transitions, then rejects 76 named mutations across every artifact and its own
wiring. Neither executable is an MCP server.

Perl leaves `FUTURE-PARITY-BACKLOG.10.9.2.1-.2` now consume the bundle without reading it at runtime: a
deterministic generated private binding plus strict schema/wire runtimes feed an in-process
`LinkedSpec::MCPServer`. The public server accepts only an already-created native index and provides decoded or
caller-owned stdio dispatch; it does not add a facade/CLI, source bootstrap, filesystem contract read, compilation,
execution, or semantic cache.

`mcp_implementation_admission.json` (`linkedspec-mcp-implementation-admission-v1`) is deliberately separate from
the normative transport contract. It records five native implementation rows and six runtime-admission rows,
because one Lua source must qualify independently on PUC Lua and LuaJIT. Current exact state is all 5/5
implementations and 6/6 runtimes complete, with shared `thin_mcp_transport` rollout complete under
`.10.9.7.1.1.3`.
The shared Lua consumer runs unchanged on both ABIs; each implementation parent is composition-closed. The ledger
pins the unchanged transport root digest, exact
case counts, source owners, proof owners, and one twelve-role admission topology per runtime. Run:

```bash
bash tools/run_python_project_data.sh tools/check_mcp_implementation_admission.py
PERL5LIB= prove -Iperl t/mcp_server_perl_admission.t
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test mcp_server_rust_admission
cd dart && bash ../tools/run_dart_project_data.sh test test/mcp_server_dart_admission_test.dart
bash tools/run_julia_project_data.sh --project=julia -e 'using LinkedSpecJulia, Test; const REPO_ROOT=pwd(); include("julia/test/mcp_server_julia_admission_test.jl")'
bash tools/run_lua_project_data.sh puc lua/test/mcp_server_lua_admission_test.lua
bash tools/run_lua_project_data.sh luajit lua/test/mcp_server_lua_admission_test.lua
bash tools/check_mcp_six_runtime.sh
```

The checker rejects 141 ledger, status, ownership, cross-ledger, recurring-driver, source-authority, all-twenty,
role, skipped-proof, tracked-input, and
canonical-order mutations. Each admission consumer composes existing public-server behavior and neutral artifacts
exactly once per role; it compares results to direct native capabilities/query and does not become a second
semantic or wire oracle. The identity roles prove capabilities plus all nineteen governed semantic queries on
all six runtimes. Executable `tools/check_mcp_six_runtime.sh` composes the neutral checker, materializer and
independent transport validator, all five generators, all six consumers, admission ledger, and three-case
primary no-drift matrix in one rooted fail-fast order. Canonical CI requires and syntax-checks it unconditionally;
`LINKEDSPEC_RUN_MCP_MATRIX=1` opts into execution. Production MCP source remains fenced from parser construction, descriptors,
substitution handlers, parser-source dumps, trace, shell/process/network execution, and arbitrary path reads. The
only documented Perl production `sysopen` is fail-closed `/dev/urandom` for handles; Rust uses locked OS entropy,
Dart uses core secure randomness, Julia uses `RandomDevice`, and Lua uses its package-private OS entropy seam, all
without filesystem authority.

Canonical local CI requires the manifest, all subordinate neutral artifacts, the implementation ledger, and every
program/test above. It runs neutral validation and all five generated bindings before Perl/Rust/Dart/Julia focused
proof and the dual-ABI Lua consumers; each Rust/Dart/Julia/Lua admission precedes the admission-ledger checker, and
Perl admission follows it.
The separate recurring gate and checker reject omissions, reversed order, partial promotion, owner disagreement,
unrouted/non-executable execution, and incomplete all-twenty evidence, so neither stale generated bytes nor
partial status movement can bypass contract and admission validation.

No-change closeout `FUTURE-PARITY-BACKLOG.10.9.7.1.1.4` reruns this exact chain from clean `de46b26a` without a
replacement oracle or status movement. Focused and canonical opt-in proof remain green at semantic 6/20/110,
MCP 35/10/10/76, 5/5 implementations, 6/6 runtimes, complete/141 governance, and primary 30/30; Phase 0 passes
1,031/1,031 in 655 seconds. It closes implementation parents `.10.9.7.1.1` and `.10.9.7.1`.

Final no-change closeout `FUTURE-PARITY-BACKLOG.10.9.7.2` independently recomposes the same committed chain from
clean `77ceb921`. Focused proof and the canonical MCP opt-in remain green through all seven doctrines, primary
CLI 66x2, Phase 0 1,031/1,031, the complete optional six-runtime recurrence, ledger 141, and primary 30/30.
Parents `.10.9.7` and `.10.9` are closed without protocol, implementation, ledger, behavior, or authority
movement. Public no-drift `.10.10` subsequently closes semantic rollout at 9/9.

No-change closeout `FUTURE-PARITY-BACKLOG.10.9.2.4` runs this exact committed chain again rather than adding an
umbrella proof. Its focused and canonical recomposition are green from clean `28f84826`, and parent `.10.9.2` is
closed. The ledger correctly stays at Perl 1/5 implementations + 1/6 runtimes with shared rollout pending.

Rust, Dart, and Julia each implement their own generated binding, native decoded server, and strict wire without
altering the transport contract. Their exact admissions advanced only their implementation/runtime rows. Dart,
Julia, and shared Lua implementation parents are closed; recurring `.10.9.7.1.1.4` closes the routed
implementation/promotion parents, and `.10.9.7.2` closes the recurring/MCP parents without changing the
transport contract or ledger state.

`semantic_introspection_contract.json` (`linkedspec-semantic-introspection-contract-v1`) makes ADRs `0049` and
`0050` executable before any backend is admitted. Its neutral model fixes `linkedspec-semantic-model-v1` and
`linkedspec-semantic-query-v1`: exact record/relation/fact vocabularies, staged payload/job/result records,
snapshot-local ids/order, value and target shapes, request/response envelopes, deterministic directional
traversal, page/record/relation/depth budgets, source ceilings/redactions/UTF-8 spans/digests, failed-compilation
and caller-owned runtime snapshots, explanations, rollout inventory, and the handle-only MCP boundary. Run
`bash tools/run_python_project_data.sh tools/check_semantic_introspection_contract.py`; the checker derives 20 digest-locked responses across
six fixture groups and reports 128 rejected mutations. Static rule facts are independently derived from
`rule_local_cursor_contract.json`: default/OR family normalizes to `or`/`seek`, rules without compiled edges use
`none`, and a failed default-family bare edge retains family-derived `action`. Three coordinated model-plus-hash
mutations prove response-digest self-consistency cannot hide those facts. Generated artifact identity/family is
also cross-checked against that contract's generated-source-v2 authority: the calls fixture emits `default`, and
both illegal and coordinated valid-but-wrong family mutations fail. Every semantic spec name is independently
derived from its caller-registered fixture logical name after removing `.spec`; the calls snapshot is therefore
`calls_and_staging`, and direct plus coordinated old-name mutations fail. Neutral rollout is 9 complete / 0 pending;
native backend admission is 6 complete / 0 pending. The public contract requires 28 current surfaces, nine worked
example families, both recurring drivers, and the accepted-but-unscaffolded companion-book boundary. No parser,
compiler, runtime, descriptor, generated-source,
CLI, trace, or MCP behavior was added by the neutral contract. Recurring leaf `.10.8` adds behavior-free
composition: one `tools/check_semantic_introspection_six_runtime.sh` driver runs the six exact admitted
consumers, three existing primary no-drift cases, and generated/capability/language ledgers; canonical execution
is opt-in through `LINKEDSPEC_RUN_SEMANTIC_MATRIX=1`. Seven recurring mutations lock that topology and only the
recurring rollout row advances. Direct proof passes Perl 18, Rust 1/1, Dart 1/1, Julia 416, Lua 408 per ABI,
all 30 primary legs, and all three support ledgers. Behavior-free Perl audit `.10.3.0` maps strict source,
descriptor, typed ActionIR, staged, structured failure, generated-plan, and missing runtime-observation authorities.
Perl foundation `.10.3.1` implements opaque in-memory construction, strict source normalization/mapping, and
immutable compiled-or-failed outcomes. Static leaf `.10.3.2.1` adds a private clone-safe projection whose graph,
privacy full/limited, failed-compilation, and runtime-static records/relations deep-equal the neutral model after
source references are materialized. `PERL5LIB= prove -Iperl t/semantic_index_perl_static_projection.t` checks
deterministic ids/order, duplicate and self-indexed slots, normalized failure evidence, immutable copies, JSON
booleans, and absence of host-object/path leakage. Calls leaf `.10.3.3.1.1` adds a second recurring private test:
`PERL5LIB= prove -Iperl t/semantic_index_perl_calls_projection.t` deep-equals all 22 corrected records and 25
relations, locks source-preorder/nested calls, resolution evidence, shapes, staged direction, shared generated-v2
identity, Unicode coordinates, interleaved function masking, immutable plain-data copies, and absence of host IR or
generated implementation text. Query leaf `.10.3.4` adds
`PERL5LIB= prove -Iperl t/semantic_index_perl_query.t`: native `$index->capabilities` and `$index->query(...)`
match all 19 static canonical response digests, plus strict request/error, privacy, paging, traversal, budget/cost,
clone/silence, and no-recompile/no-path proof. Runtime leaf `.10.3.5` adds typed invocation-local slot/result
capture plus immutable post-execution derivation. `PERL5LIB= prove -Iperl
t/semantic_index_perl_runtime_observation.t` matches the twentieth exact response across native, loaded,
captured/emitted generated direct/Get/traced, and validated-plan roles while proving failure identity and
trace/diagnostic non-interference. Composed admission `.10.3.6` adds
`PERL5LIB= prove -Iperl t/semantic_introspection_perl_admission.t`: one exact 12-role consumer covers source
normalization, all compiled/failed/runtime snapshots, direct/loaded/generated/traced observations, native and
neutral JSON, every one of the 20 response digests, privacy/page/budget/error/explain behavior, no-execute
immutability, and stale-host-leak denial. The checker requires its path, ordered role inventory, canonical driver,
tracked registration, Perl admission/rollout promotion, and eight new path/role/driver/registration/admission
mutations. Rust composed admission `.10.4.6` adds
`cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test semantic_introspection_rust_admission`:
the same 12 exact-once roles compose Rust source normalization, compiled/failed/runtime snapshots, loaded and
reconstructed execution, generated-plan and source-emitter direct/traced routes, typed and neutral JSON, all 20
digests, bounded query behavior, immutability, and host-leak denial. Eight Rust-specific topology mutations lock
its path, roles, driver, canonical registration, native status, and Rust-only rollout promotion. Dart composed
admission `.10.5.6` adds `dart test test/semantic_introspection_dart_admission_test.dart`: the same ordered 12
exact-once roles cover strict bytes/text, compiled/failed/runtime snapshots, loaded and JSON-reconstructed state,
generated-plan/public-helper/standalone-emitted direct and traced execution, native/neutral JSON, all 20 digests,
bounded query behavior, immutability, and host-leak denial. Eight Dart-specific topology mutations lock its path,
roles, driver, canonical registration, native status, and Dart-only rollout promotion. Perl, Rust, and Dart are
admitted. Julia composed admission `.10.6.7` adds
`julia --project=julia --startup-file=no --history-file=no --compiled-modules=no
julia/test/semantic_introspection_julia_admission_test.jl`: the same ordered 12 exact-once roles compose strict
text/bytes, every compiled/failed/runtime snapshot, loaded and JSON-reconstructed state, generated-plan/public-
helper/fresh and standalone emitted direct/traced routes, typed/neutral JSON, all 20 digests, bounded queries,
immutability, and host-leak denial. Eight Julia topology mutations lock its path, roles, driver, canonical
registration, native status, and Julia-only rollout promotion. Lua composed admission `.10.7.7` adds
`lua/test/semantic_introspection_lua_admission_test.lua`: the same ordered 12 exact-once roles run unchanged on
PUC Lua and LuaJIT, compose all native/loaded/reconstructed/generated/emitted/traced/isolated routes and all 20
digests, and deny stale host state. Nine Lua-specific topology mutations independently lock both ABI statuses,
the identical consumer path/roles/driver, canonical registration, and Lua-only rollout promotion. Perl, Rust,
Dart, Julia, PUC Lua, and LuaJIT are admitted.

Run its structural and ownership gate from the repository root:

```bash
perl tools/check_capability_conformance.pl
```

Statuses mean:

- `pass`: current source plus executable evidence supports the contract;
- `partial`: an implementation or proof boundary is incomplete and has an explicit task owner;
- `gap`: the documented capability is absent and has an explicit task owner.

Every capability lists canonical contract sources and backend-specific evidence paths. The checker rejects unknown
fields/statuses/backends, duplicate ids, missing evidence paths, unowned partial/gap states, missing task-tree owner
ids, absolute paths, and stale or unowned exclusions. Current language behavior belongs in `capabilities`;
deprecated or genuinely not-yet-adopted directions belong in `excluded_or_future`.

The manifest's exclusion ledger is schema v2 and currently contains exactly one governed record. Deprecated
Perl-only plugin machinery is explicit `legacy` under pending `FUTURE-PARITY-BACKLOG.6` with null
`retention_authority`; an open legacy owner does not need one. A legacy record whose owner is completed is legal
only when a tracked, repository-relative durable authority explicitly retains it. Portable parse-job authoring is
current and therefore absent from this ledger.

Behavior-free audit `.14.7.0` historically left the then-current exclusions and 80/0/0 census unchanged. It separates the current
one-depth function-body adapter from general authoring, typed provenance, several parser families, policy
semantics, and recursive queues, then assigns those exact capabilities to `.14.7.1-.10`. Public authored closeout
`.14.7.9` now supplies the required proof and removes the satisfied parse-job exclusion.

The checker derives unique task ids and leading status enums from tracked task sources, locks the exact record and
order, and rejects schema/classification/retention/status/content/resurrection drift through 19 in-memory
mutations. Completed semantic-introspection/MCP, rule-local cursor, and parse-job authoring work are deliberately
absent rather than preserved as stale future narratives. At the original exclusion-correction boundary, the 16
capability rows and their 80/0/0 backend-state census did not change. Staged-AST recurrence later added the
seventeenth all-pass row, making the current census 17/85; public admission renamed that row without changing its
85 pass cells.

Capability exclusion freshness is public-closed under `FUTURE-PARITY-BACKLOG.24`. The same checker binds 12
governed public/continuity/retrieval projections plus ten path-scoped stale-current denials and rejects six public
mutations without duplicating the manifest's 24 semantic mutations.

`outward_descriptor_contract.json` is the executable shared schema for the public compiled-descriptor projection.
Its `required_meta_keys` remains the explicitly named `legacy_global_v0` default for unmigrated backends, while
`meta_contract_variants.rule_local_cursor_v1` requires `cursor_contract`, forbids `parse_mode`, and fixes the v1
identity for migrated backends. Perl consumes that variant as of `.9.1.3.3`, Rust as of `.9.1.4.4`, Dart as
of `.9.1.5.3`, Julia as of `.9.1.6.3`, and Lua on both supported ABIs as of `.9.1.7.3`.
Its `function_record_variants` object is the authoritative three-way union: fixed-v1 stores `params`/`arity`,
variadic-v2 stores `signature`, and final-codeblock-v3 stores `params`/`arity` plus exact final-only
`parameter_kinds`. `tools/check_callable_signature_contract.py` rejects schema/order/version/storage/policy drift.
Perl, Rust, Dart, Julia, and Lua descriptor tests consume the applicable exact variants so a backend-specific
serialization convention cannot silently become public API. Final-codeblock-v3 admission by Perl and Lua does not
promote the separately future generic callable-codeblock capability.

`rule_local_cursor_contract.json` makes ADR `0044` executable before behavior rollout. Run
`bash tools/run_python_project_data.sh tools/check_rule_local_cursor_contract.py` to validate 36 exact rule-family spellings, 18 bare/explicit/
indexed/grouped/block/fluent/reserved edge cases, six post-normalization ownership sets, eight parent/child call
mechanisms, both structural replacements for retired global cross-combinations, exact API/CLI removal diagnostics,
per-rule descriptor metadata, generated-source v2 family derivation, and the dependency-ordered migration ledger.
The checker currently owns an exact 72-file migration inventory and rejects 56 representative semantic, topology,
diagnostic, generated, consumer-omission, recurring-gate, inventory, and admission mutations. A 14-role Perl consumer composes
live default/AND, descriptor v1, emitted v2, generated direct/trace, loaded spec, mixed parent/child, recursion,
both structural replacements, dynamic removal, primary command, and all portable diagnostic codes. Canonical CI
runs that consumer. A separate 15-role Rust consumer composes native default/AND, ordinary serialized, loaded,
descriptor-v1, emitted-v2, generated direct/trace, mixed/recursive, structural, static-removal, primary, and
portable-diagnostic projections. The checker requires every role marker plus the canonical/default-to-optional-
Rust driver topology. A separate 15-role Dart consumer composes native default/AND, normalized, loaded, descriptor,
emitted/generated direct/trace, mixed/recursive, structural, static-removal, primary, and diagnostic roles. The
checker locks each marker, the complete Dart test command, canonical tracked input, and optional backend-driver
registration. A separate 15-role Julia consumer composes the same normalized topology over current Julia native,
loaded, descriptor-v1, emitted/generated-v2, trace, composition, removal, primary, and diagnostic projections.
The checker locks its markers, complete package driver, canonical tracked input, and optional backend registration.
One Lua consumer composes the same 15 normalized roles and runs unchanged on both PUC Lua and LuaJIT. The checker
locks its markers, both backend-driver invocations, canonical tracked input, and optional backend registration.
`neutral_contract_and_inventory`, `perl_reference`, `rust_parity`, `dart_backend`, `julia_backend`,
`lua_dual_abi`, `recurring_five_backend_gate`, and `public_no_drift` are complete, so rollout is
8 complete / 0 pending. Run
`bash tools/check_rule_local_cursor_five_backend.sh` for the recurring Perl/Rust/Dart/Julia/PUC-Lua/LuaJIT
composition, selected 5x2x5 primary projection, and support ledgers. Canonical local CI exposes the same
all-toolchain leg behind `LINKEDSPEC_RUN_CURSOR_MATRIX=1`. The public contract requires current README, guide,
API/backend, roadmap, task, architecture, mdBook, ADR, and Knowledge Map surfaces and rejects exact stale-current
claims; the checker rejects 60 semantic, topology, recurring, public, and rollout drift mutations. The shared generated-source-v1
capability ledger remains the semantic convergence baseline while current Perl, Rust, Dart, Julia, and Lua
emitters use v2. Lua's dedicated dual-ABI generated-v2 proof passes 106 assertions per ABI under `.9.1.7.4`;
its composed admission now passes 119 assertions per ABI under `.9.1.7.6`.

`typed_source_location_contract.json` (`linkedspec-typed-source-location-v1`) makes ADR `0056` executable and
governs each internal runtime admission without creating authored typed-value syntax. Run:

```bash
bash tools/run_python_project_data.sh tools/check_typed_source_location_contract.py
```

The neutral artifact fixes three decoded sources, seven Unicode-scalar/line/column/UTF-8 conversions, six direct
spans, three derived-text provenance cases, eight invocation transitions, eight transaction transitions,
33 recursive-observation transitions, six detached observations, and four zero/one/two-regex structural cases.

It also maps the exact 92 current source-boundary helpers onto one algebra. The current Perl inventory contains
seven callable compatibility aliases. Two similarly named values—`capture_take_slice` and
`capture_take_slice_len`—are internal contract/scanner ids whose recognized spellings remain canonical
`capture_take()` and `capture_take_len()`; they are not extra callable aliases.

The checker derives coordinates and text independently, executes all three state machines, cross-checks current
Lua helper authority and the Perl alias/internal-id seams, locks 33 diagnostics, and verifies canonical tracked
execution. Governance reached 75 mutations at the all-runtime admission boundary. Eleven earlier mutations govern
the broad recurring topology: five backend groups
map to exact Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT runtime routes, followed by generated-source, capability,
and language-coverage ledgers. Run the complete recurring proof with:

```bash
bash tools/check_typed_source_location_six_runtime.sh
```

Canonical local CI requires and syntax-checks that driver; `LINKEDSPEC_RUN_TYPED_SOURCE_MATRIX=1` opts into its
all-toolchain execution. Current governance is 231 mutations and rollout is 14 complete / 0 pending across 14 legs:
the neutral contract, public structure, unchanged neutral/public recomposition, and the Perl, Rust, Dart, Julia,
PUC Lua, and LuaJIT internal
runtime admissions are complete. Transaction safety projects the separately owned complete recognition authority;
the two Lua ABIs share one rollout leg because they execute the same consumer
source independently through distinct runtimes. Final program-wide owner `FUTURE-PARITY-BACKLOG.14.8` composes
all six existing recurring authorities and completes `recurring_public_no_drift` without adding another row.

Executable neutral observation selected
`value = observe_recognition(observation, call(Child))`: one bare rule-local harray target and one unevaluated
static call. The ordinary child payload remains the expression result; a separate recursively detached nine-field
harray records entry, terminal selected match, accepted-only exit, outcome, and numeric lineage. Existing harray
field access is the complete carrier projection. Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT now admit the form
through dedicated private nodes, fail-closed static policy, the existing invocation authority, and
ordinary/generated execution. Rust, Dart, Julia, and shared Lua additionally lock serialized reconstruction,
generated-plan execution, and independently compiled, analyzed, or loaded emitted source. Dart retains UTF-16
code-unit registers; Julia retains zero-based UTF-8 code-unit registers; Lua retains zero-based UTF-8-byte
registers; all convert only at the typed Unicode-scalar boundary. Dedicated recurrence now runs those five exact
sources over six ordered routes, then all three support ledgers:

```bash
bash tools/check_recursive_observation_six_runtime.sh
```

Canonical CI exposes the same route behind `LINKEDSPEC_RUN_RECURSIVE_OBSERVATION_MATRIX=1`. Eleven topology/storage
regressions plus one recurrence regression promote only `recursive_observation`. The public closeout then binds
six current projections, rejects six stale claims, and guards ten facade/API/schema surfaces through 27 further
mutations. Recursive-observation public projection/no-drift is current without a new public API; its own rollout row remains complete.
Combined typed authoring-model governance is complete at 14/14 under the composed six-runtime proof.
Governance is 231. No public
helper/value, descriptor/generated schema, semantic/MCP field, CLI, or README behavior moved.

Run `bash tools/check_typed_authoring_model_six_runtime.sh` for the fail-fast composition of typed-source values,
recognition transactions, recursive observation, typed gaps, progressive dispatch, and staged-AST enrichment.
Canonical CI exposes the same route through `LINKEDSPEC_RUN_TYPED_AUTHORING_MODEL_MATRIX=1`.

`progressive_span_dispatch_contract.json` (`linkedspec-progressive-span-dispatch-v1`) is the executable neutral
authority for the reserved private expression
`value = dispatch_span("expr-v1", "Expr", span)`. Two normalized string literals select one immutable
pre-registered compiled parser and allowed top rule; one bare local four-field harray supplies a direct
same-source span. The child uses a globally rebased bounded view, receives intersected capabilities and stricter
ceilings plus the same cancellation/deadline/remaining budget, cannot mutate parent semantic state or establish
parent progress, and returns only a detached payload. Exact/non-decreasing same-identity cycles, uncommitted
recognition, implicit loading, live handles, and every fallback/retry path fail closed. Run:

```bash
bash tools/run_python_project_data.sh tools/check_progressive_span_dispatch_contract.py
bash tools/check_progressive_span_dispatch_six_runtime.sh
```

The checker executes 2 sources / 8 view cases, 6 authority, 6 cancellation, 8 chain, and 4 execution cases; guards
9 Rust, 8 Dart, 9 Julia, and 9 Lua implementation paths plus 10 outward paths with zero backend guards; locks 26
diagnostics; and rejects 116 contract mutations plus 60 public omission/injection mutations over six documents,
12 stale-current denials, and the same 10 outward paths. Rollout is neutral + Perl + Rust + Dart + Julia + PUC Lua + LuaJIT + recurring + public no-drift: 9/9 complete, with the intrinsic still private and all ten outward surfaces absent.
The separate
typed recurrence driver binds five immutable backend source groups to six ordered runtime routes because the
shared Lua consumer runs independently on both ABIs, then executes typed-source, generated-source, capability,
and language support ledgers. Canonical CI requires, path-audits, syntax-checks, and exposes that driver only
through `LINKEDSPEC_RUN_PROGRESSIVE_SPAN_MATRIX=1`. This promotes only typed `progressive_span_dispatch`;
the public closeout binds that committed driver to behavioral recurrence and completes public no-drift. The
rejected recognition effect retains current node `PROGRESSIVE_DISPATCH_SPAN` and no call row, while ten
facade/schema/semantic/MCP/CLI/README paths continue to deny outward exposure.

`staged_ast_enrichment_contract.json` (`linkedspec-staged-ast-enrichment-v1`) is the executable neutral authority
for current returned-AST enrichment through exact authored
`target = parse_job(source_bound_text, hash(literal options))`. It freezes one inert
`STAGED_PARSE_JOB_MARKER` plus `staged_parse_job_v2` sidecar, typed direct and ordered-derived source provenance,
caller-completed alias/provider/search-root resolution, immutable pre-registered parser/cache authority,
deterministic breadth-first recursive scheduling, four result policies, three failure policies, strict
decreasing-chain and resource ceilings, detached results, portable diagnostics, carrier obligations, dormant
backend routes, rollout, exact downstream ownership, and the unchanged function-body-v1 adapter. Run:

```bash
bash tools/run_python_project_data.sh tools/check_staged_ast_enrichment_contract.py
bash tools/check_staged_ast_enrichment_six_runtime.sh
```

The independent checker executes 4 registry entries, 8 provenance, 8 resolution/6 authority, 10 cache,
4 queue/3 isolation, 4 result-policy, 3 failure-policy, 10 chain, and 5 detachment cases. It locks five backend
consumers over six runtime routes, 37 diagnostics, 9 rollout legs, and 35 exact owners, then rejects 123 neutral
mutations plus 129 reason-checked public omission/stale/injection mutations. Neutral, Perl, Rust, Dart, Julia, PUC
Lua, LuaJIT, recurrence, and public no-drift rollout are all complete.
The recurring driver binds five immutable backend source groups to six ordered runtime routes, then runs typed,
generated-source, capability, and language ledgers; canonical CI exposes it only through
`LINKEDSPEC_RUN_STAGED_AST_ENRICHMENT_MATRIX=1`. Each admitted consumer is registered
exactly once in ordinary/canonical proof and proves native, reconstructed, validated generated-plan, and
independently loaded emitted execution through fresh host-only authority without serializing live state. Julia's
491/491 consumer now runs once in ordinary and canonical proof across the same four production routes; each run
starts a fresh registry/cache/recursive authority after the parent result. One shared Lua-5.1-compatible consumer
runs at 888/888 on PUC Lua and LuaJIT through the same four fresh-authority carriers and is registered exactly once
per ABI in ordinary/canonical proof. The capability census includes the all-pass
`language.staged_ast_enrichment` row at 17 capabilities / 85 pass states, and the satisfied general-authoring
exclusion is absent. The staged-AST contract is 9/9 complete: portable exact-assignment `parse_job(...)` authoring is current while all ten unrelated outward surfaces remain absent.
Generated format, facade/schema/semantic/MCP/CLI/README, and unrelated outward behavior have not moved.
Independent closeout `.14.7.10` reruns that exact recurring program and its support ledgers unchanged, corrects
only bounded current prose, and closes the staged parent. Capability truth remains 17 rows / 85 pass states / one
legacy exclusion; final `.14.8` now makes typed truth 14/0/231 without changing staged behavior.

`inter_match_gap_capture_contract.json` is the neutral authority for named regex slots and lossless
prefix/interstitial/tail context. Inter-match gap public admission is current with four shared calls and unchanged outward facade, descriptor, semantic, MCP, CLI, and README surfaces. Julia `.5.1-.5.5` and shared Lua `.6.1-.6.5` implement and admit their exact nine-role paths without widening those guarded surfaces.
Run `bash tools/run_python_project_data.sh tools/check_inter_match_gap_capture_contract.py` for the always-on
neutral proof or `bash tools/check_inter_match_gap_capture_six_runtime.sh` for the repository-routed ordered
governance route. The latter executes the complete neutral, Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT rows;
the nine-leg rollout is 9 complete / 0 pending and the checker rejects 63 semantic/topology corruptions plus ten
  Rust, ten Dart, ten Julia, and sixteen Lua admission/regression mutations. Public no-drift binds exactly eight
  documents, fifteen stale-current denials, ten outward guards, and 34 reason-checked text/surface mutations.
`FUTURE-PARITY-BACKLOG.14.5.1` binds that unchanged 9/0/63 plus 8/15/10/34 authority to the existing detached
same-source half-open `gap_span` representation. Run `bash tools/check_typed_gap_composition_six_runtime.sh` to
check the typed contract, the complete six-runtime gap route, recognition ownership, and generated/capability/
language ledgers in order. Canonical CI exposes the exact route behind
`LINKEDSPEC_RUN_TYPED_GAP_COMPOSITION_MATRIX=1`. Twelve new mutations lock cross-contract identity, counts,
projection, storage, route, canonical registration, and completion of only `lossless_gap_composition`.
Perl `.2.1-.2.3` implement authored/static metadata, private native-live behavior, and independently loaded
generated parity; `.2.4` admits that existing consumer without an outward API. Its four private accessor nodes are synchronized as recognition `source_read`
effects at 138 total rows after private Perl progressive admission; `.7.2` admits their call names at 250 shared
calls and 126 public Perl contracts.
Typed-source composition is current without a second implementation owner. Rust `.3.1-.3.4` implement authored/static/compiled metadata, invocation-local native
state, ordinary reconstruction, compatible descriptor projection, separate generated-plan parity, and independently
compiled emitted proof. `.3.5` adds a real primary-command mixed-separator case, requires all nine Rust roles
exactly once, and admits the consumer ordinarily, canonically, and after Perl in the rooted route. Generated plan
v2 stays exact `{label,family}`; no public facade, capability, typed-source, semantic/MCP, CLI, README, or later
runtime surface moves.

No public `Position`/`Span` value, descriptor or generated schema, semantic/MCP projection, or source-authority
elevation is claimed by these internal typed-source runtime admissions. Recognition transaction spelling and
behavior are current on Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT under the separate ledger described next.

`recognition_transaction_contract.json` (`linkedspec-recognition-transaction-v1`) makes the accepted bounded-
recognition transaction, effect, invocation-mark, and cursor-progress semantics executable and records exact
runtime admission. Run:

```bash
bash tools/run_python_project_data.sh tools/check_recognition_transaction_contract.py
```

The checker also binds three exact public transaction pages to neutral + Perl + Rust + Dart + Julia + PUC Lua +
LuaJIT + recurring + public no-drift 9/9 complete, rejects twenty-six stale milestone/current claims,
and executes forty-five public-sequence mutations in memory. That projection is distinct from 58 semantic and
recurring-topology mutations.

The independent checker derives all 134 current ActionIR node kinds from the Perl contract authority and all 250
current call names from matching Dart, Julia, and Lua inventories. The artifact assigns one base effect to each
of those rows plus four dedicated `RECOGNITION_*` nodes under the closed nine-allowed/eleven-rejected
lattice. It separately executes 8 positive / 17 negative token cases, six recursive fixed-point effect graphs,
six invocation-mark cases, eight cursor-only progress cases, and fifteen portable diagnostic records, then rejects
58 exact drift mutations. This 134-node census is distinct from the 126 public identifier-shaped Perl contracts
reported by `tools/check_language_capability_coverage.pl`.

Canonical CI requires the tracked artifact/checker and runs the same project-data-routed command unconditionally.
It executes each Perl, Rust, Dart, and Julia consumer once and the unchanged Lua consumer once per ABI. Rollout is
neutral + Perl + Rust + Dart + Julia + PUC Lua + LuaJIT + recurring + public no-drift 9/9 complete.
The four exact transaction forms are current on Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT; exact recurring and public no-drift proof is current.

Run the fail-fast recurring composition with:

```bash
bash tools/check_recognition_transaction_six_runtime.sh
```

It validates the neutral checker first, executes the five source groups through exact Perl, Rust, Dart, Julia,
PUC Lua, and LuaJIT routes in order, and finishes with generated-source, capability, and language-coverage ledgers.
All data is routed through repository-derived storage. Canonical CI exposes the same all-toolchain proof behind
`LINKEDSPEC_RUN_RECOGNITION_TRANSACTION_MATRIX=1`.

One shared Lua-5.1-compatible final-path consumer now executes 246 assertions independently on PUC Lua and LuaJIT.
It covers the private 187-assertion invocation/mark/token authority plus four non-eager nodes, recursive effects,
cursor-only progress, and native/reconstructed/generated-plan/emitted carriers. Ordinary discovery and canonical
CI each run it once per ABI; the private authority and runtime adapter remain absent from the facade. Governance
rejects 22 authority, 19 integration, and 22 admission mutations. The earlier 12 dormancy mutations remain durable
historical RED evidence, not current topology.

`root_rule_selection_contract.json` (`linkedspec-root-rule-selection-v1`) makes ADR `0046` executable without
claiming markerless execution before the
backends admit it. Run `bash tools/run_python_project_data.sh tools/check_root_rule_selection_contract.py` to validate explicit selector > first
authored `::` > first authored `:` precedence, eight successful selections, three structural/selector failures,
three strict-unused graph cases, authored `is_top` identity, native/loaded/reconstructed/generated/emitted/trace/
primary projections, and the exact five-backend audit. The checker topology-locks the Perl core/routes consumers,
the exact 15-role Rust, Dart, Julia, and Lua admission consumers, configured CI/backend execution, first-marker/
markerless/explicit/unknown primary cases, and default/explicit request trace. Final admission adds the composed
six-runtime recurring gate, a 24-document public contract, and both roadmap projections as required current-state
inputs while rejecting 54 semantic, topology, recurring, public, and rollout drift mutations. Rollout is 7
complete / 0 pending: neutral decision, composed Perl, Rust, Dart, Julia, dual-ABI Lua, and final recurring/public
no-drift are admitted. Perl records marker-
optional validation, exact explicit/first-marker/first-rule resolution, markerless fallback, immutable descriptor
`is_top`, and the same resolution across loaded, generated-direct, generated-traced, and generated `Get` execution. Generated artifacts
retain ordered authored entry state separately from their minimal label/family plan, and an invocation-local
selector overrides an emission-time configured selector. Root-selection established 65 reference-first cases,
including exact first-marker and markerless-default bytes beside explicit and unknown selection; repeated-action
recurring proof adds the 66th shared case. Rust now carries
the same marker-optional resolver through native, loaded, serialized/reconstructed, generated direct/traced, and
emitted direct/traced execution. Existing generated signatures remain intact; option-bearing siblings accept
per-invocation `ExecutionOptions`, return portable zero/unknown selection failures, and keep the selector out of
authored descriptor identity and the minimal family plan. One omission-sensitive Rust consumer composes all 15
neutral, native, loaded/reconstructed, generated/emitted, descriptor, diagnostic, trace, and primary roles exactly
once; the Rust primary command passes all 66 cases in default and POSIX option environments. Dart now has the same
exact 15-role admission topology across loaded/normalized/generated/emitted/trace/diagnostic paths. Its package-
wide driver passes 270 tests, the shared command passes 65/65 in both option environments, and the corpus passes
105/105. Julia core `.4.1` consumes every neutral selection/failure/strict row, accepts markerless
one-or-more-rule sources, reports portable zero/unknown failures, and publishes the descriptor contract without
advancing rollout; native/root-primary proof is exactly 32/65 twice with only the 33 cursor-owned cases remaining.
Julia route `.4.2` proves loaded/normalized and generated/emitted direct/traced execution, low requested/effective/
basis trace, portable loader/generated failures, and plan-first rejection through 57 assertions. Dart cursor
admission is clean at `7aa9c578`; Julia cursor `.9.1.6` now implements and composes exact normalization, live
execution, descriptor v1, generated-source v2, public/CLI option removal, and one 15-role admission. Shared Julia
primary is exact at 65/65 twice. Julia root admission `.4.3` composes the contract through one exact 15-role
consumer; its authored selection fixtures use entry lifecycle returns so the result proves which rule was entered
rather than merely which successful match exited. Lua/LuaJIT use the same exact source on both ABIs. Run
`bash tools/check_root_rule_selection_five_backend.sh` for the recurring native/composed proof and selected
5x2x6 primary projection; canonical CI exposes it behind `LINKEDSPEC_RUN_ROOT_RULE_MATRIX=1`.
The final root-selection ledger is 7 complete / 0 pending.

`duplicate_regex_slot_identity_contract.json` (`linkedspec-duplicate-regex-slot-identity-v1`) makes ADR `0047`
executable before backend repair. Duplicate regex text remains legal and never replaces typed target-rule plus
regex-index identity. Ordered execution matches its already-required structural slot; repeated AND resets that
sequence per iteration. Choice evaluates all eligible slots, prefers the earliest start, and breaks equal-start
ties toward the first authored slot. Five exact fixtures cover same-rule ordered and choice duplicates, repeated
duplicates, a non-duplicate repeated control, and cross-target duplicates. The contract also fixes two portable
invariants, descriptor and trace identity, unchanged generated-source v2/format 2, the six-runtime mechanism
inventory, migration paths, and the seven-leg rollout. Run
`bash tools/run_python_project_data.sh tools/check_duplicate_regex_slot_identity_contract.py`; it independently evaluates the selection model
and reports 59 rejected mutations spanning semantic, fixture, diagnostic, artifact, inventory, rollout,
recurring, public, closure, admission, and CI drift.
mutations. Perl `.2` is composed-admitted through 12 exact roles. Rust `.3` is composed-admitted through 15 exact
roles covering native, reconstructed, loaded, descriptor, emitted/generated, native/generated trace, primary,
all five neutral fixtures, and typed diagnostics. Rust matches required slots directly, retains combined choice,
publishes descriptor/emitted contract identity, and keeps generated v2 plans minimal. Dart `.4` is composed-
admitted through the same 15-role shape over direct authored-alternative matching, normalized-spec generated
payload, descriptor/emitted/trace identity, primary, and diagnostics. Julia `.5` is now admitted through a
module-isolated 15-role consumer over direct authored-alternative matching,
normalized-spec generated payload, descriptor/emitted/trace identity, primary, and diagnostics. Dual-ABI Lua
`.6` runs one unchanged 15-role consumer on PUC Lua and LuaJIT, replaces required-pattern/reindex with direct
authored-alternative matching, and preserves normalized-spec generated v2. The recurring driver
`tools/check_duplicate_regex_slot_identity_five_backend.sh` composes all six runtime legs, the selected 5x2x1
primary case, and generated/capability/language-coverage support ledgers. Governance is closed at
7 complete / 0 pending with 59 rejected mutations.

`repeated_action_result_contract.json` (`linkedspec-explicit-repetition-action-result-v1`) makes ADR `0048`
executable across all admitted backends. It fixes eight exact mode rows for `*`, `+`, `?`, bare `OR`,
`OR+`, exact/up-to bounded OR, and scalar pipe, plus ten cases for duplicate priority, nested/null values, fluent
returns, zero/below-minimum bounds, lifecycle authority, duplicate pipe, and blind bare-OR classification. Run:

```bash
bash tools/run_python_project_data.sh tools/check_repeated_action_result_contract.py
PERL5LIB= prove -Iperl t/repeated_action_result_perl_contract.t
bash tools/check_repeated_action_result_five_backend.sh
```

The checker independently evaluates results, cursors, and selected-slot order, locks exact source bytes,
descriptor and generated-source-v2 family facts, trace/route topology, the checked-in distinct-OR corpus bundle,
six-runtime mechanism inventory, exact recurring topology, and migration ownership, and rejects 44 drift
mutations. The Perl consumer composes ten roles: neutral model, live modes, special cases, loaded source,
descriptor, emitted source, generated direct, generated trace, primary CLI, and corpus bundle. Rust, Dart,
Julia, PUC Lua, and LuaJIT each run their exact 15-role admission; the shared Lua source runs once per ABI. The
recurring driver composes those six runtime legs, the contract-projected
`success_explicit_repeated_action_results` case through five commands in default and POSIX environments, and the
generated-source/capability/language-coverage ledgers. Canonical local CI runs the neutral checker and Perl
consumer unconditionally and exposes the all-toolchain composition behind
`LINKEDSPEC_RUN_REPEATED_ACTION_RESULT_MATRIX=1`. Repeated-action rollout is closed at 8 complete / 0 pending;
the public contract covers 25 current documents, denies 12 stale claims, and the checker rejects 54 drift mutations.
The exact recurring proof is `tools/check_repeated_action_result_five_backend.sh`.

The Julia cursor preflight recorded the historical starting differences without advancing rollout: compact `|`
was generated AND, every engine owned global seek, 11 edge rows remained raw, parent-child agreement was 5/8,
structural agreement was 1/2, and descriptor/generated cursor identities were absent. Current `.1-.4` proof now
covers all 36 family spellings, all 18 edge rows, 8/8 parent-child, 2/2 structural, cursor descriptor v1, and
generated-source v2 with contract-before-payload rejection. Public removal then deletes global engine/loader/
corpus/primary ownership while retaining low-level matcher primitives and targeted legacy diagnostics. Package
progression is 3,291, shared primary is 65/65 twice, corpus is 105/105, and governance was 67 / 5+3 / 44 at
Julia admission. Lua admission later advanced the ledger to 69 / 6+2 / 49, root-governance scanning moved the
inventory to 71, recurring admission established 72 / 7+1 / 56, the Julia duplicate-slot proof path advanced it
to 73, and duplicate-slot public governance added two parse-mode-chapter scanner paths under `.9.1.9`. Final
public no-drift closes the current boundary at 74 / 8+0 / 60 after the bounded root README routes its former
`parse_mode` migration detail to canonical owners.

Dart core leaf `.9.1.1.2.3.1` closes the preflight's 64/65 boundary: validation now
accepts markerless one-or-more-rule sources, one compiled resolver implements the exact precedence, native and
65x2 primary execution use it, zero/unknown selection failures have portable identities, strict-unused stays an
authored-edge analysis, and descriptors publish immutable `is_top` plus the root contract identity. Route leaf
`.3.2` proves loaded/normalized and generated/emitted direct/traced execution, low requested/effective/basis trace,
portable route failures, and stale-contract-first ordering without changing v2 identity. Admission `.3.3` adds one
contract-declared 15-role consumer, exact driver/case registration, and five additional omission mutations; Dart
is therefore admitted and rollout is 4 complete / 3 pending.

Julia admission `.4.3` applies the same omission-sensitive 15-role topology to the already-admitted core and
route mechanisms, including loaded/reconstructed, generated/emitted direct and traced, immutable descriptor,
portable diagnostics, selected-rule runtime failure identity, primary selection, and exact shared request-trace
bytes. The canonical and Julia package drivers own the consumer, and five additional mutations prevent its role,
consumer, shared-primary, driver, or rollout identity from silently regressing.
Focused composition passes 137; package 3,428, primary 65x2, corpus 105, and canonical Phase 0 1,031 in 616
seconds pass.

Perl preflight assigns the ten shared manifest/help/usage/trace byte fixtures to the reference migration leaf
`.9.1.3.5`: removing the reference option affected 35 cases in the then-63-case suite that local CI always
runs twice. That reference-first migration is now implemented; shared CLI documentation and final symmetric
five-backend admission remain `.9.1.8`-owned. This keeps
main green without an ignored flag, hidden compatibility route, or skipped case while backends roll forward in
dependency order.

`scalar_text_contract.json` fixes the portable `cat` conversion boundary across Perl, Rust, Dart, Julia, PUC Lua,
and LuaJIT. It preserves strings, spells booleans as `1`/`0`, normalizes finite decimal text, and makes null plus
the non-text value kinds propagate null. The executable fixture covers current portable source values; codeblock is
normatively non-text while explicit final-codeblock call syntax remains separately owned.

`diagnostic_output_contract.json` adopts ADR `0042`'s backend-neutral `print`/`say`/`print_each` event boundary
without claiming backend admission early. It fixes exact one-plus/two-or-three arities, arity-before-evaluation,
once-only left-to-right effects, diagnostic scalar rendering, call/item grouping, newline and decoration text,
empty/wrong-kind behavior, Unicode order, structural-result neutrality, quiet execution, synchronous caller sink
failure, immediate `exit_now`, generated propagation, and the quiet ADR `0024` primary-CLI projection. Validate
the 11 rendering rows, five invalid arities, six semantic scenarios, and the exact rollout ledger
offline with `bash tools/run_python_project_data.sh tools/check_diagnostic_output_contract.py`. The checker independently evaluates the model and
rejects 20 representative semantic, topology, public-document, and admission drift mutations. All five native
legs, generated/primary propagation, recurring admission, and public no-drift are complete: 8 complete / 0 pending.
The public contract additionally requires 16 current documentation surfaces and rejects nine exact stale
claims, so an old direct-host-output or pending-generated caveat cannot silently return. Run
`bash tools/check_diagnostic_output_five_backend.sh` for the composed Perl/Rust/Dart/Julia/PUC-Lua/LuaJIT native+
generated proof, selected quiet five-command/default-POSIX case, and generated-source/capability/corpus ledgers.
Canonical local CI registers that all-toolchain leg behind `LINKEDSPEC_RUN_DIAGNOSTIC_MATRIX=1` while auditing its
schema, topology, syntax, and tracked inputs on every ordinary run.

`scalar_numeric_contract.json` fixes strict scalar numeric helper inputs, arities, invalid-to-null results, numeric
comparison truth, half-away rounding, min/max/clamp, division, and signed integer modulo. Its deterministic case
list also renders one backend-neutral `.spec` fixture. Validate schema, independent evaluator results, and rendered
source offline with `bash tools/run_python_project_data.sh tools/check_scalar_numeric_contract.py`. Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT
consume the unchanged 55 cases; `bash tools/check_scalar_numeric_six_runtime.sh` is the composed admission proof.

`logical_helper_contract.json` adopts ADR `0043`'s backend-neutral `and`/`or`/`not` value contract without
claiming backend admission early. `and` and `or` require at least one positional argument; `not` requires exactly
one. Invalid arity produces `helper_arity_mismatch` before any argument runs. Valid calls evaluate every argument
once left-to-right and return a real boolean, while `if`/`switch`/`while` remain lazy controls over the same typed
truthiness seam. Null, false, numeric zero, empty strings, and empty arrays/harrays are false; all other finite
numbers, nonempty strings (including `"0"` and `"false"`), nonempty aggregates, and codeblock values are true.
Testing a codeblock does not invoke it. The codeblock row is model/backend-unit evidence only until the separately
owned first-class literal program lands; this contract does not activate `{|...| ... }` syntax.

Run `bash tools/run_python_project_data.sh tools/check_logical_helper_contract.py` to validate 17 truthiness rows, ten helper cases, three eager
effect scenarios, receiver and lazy-control contrast, four pre-effect arity failures, deterministic embedded
fixtures, exact projection obligations, and 26 semantic/topology/public drift mutations. Perl consumes the neutral
artifact through typed ActionIR/runtime proof; Rust uses
its shared typed truth/arity seam plus native, serialized, generated-plan, and emitted proof; Dart uses one typed
helper/control seam plus native, normalized, generated-plan, standalone-emitted, and primary proof. Julia
preserves its typed eager helper/control seam and adds native, normalized, generated-plan, standalone-emitted,
primary, and exact diagnostic proof. Lua consumes the same contract through native, reconstructed, generated-plan,
emitted-module, primary, and exact diagnostic proof on PUC Lua and LuaJIT. Run
`bash tools/check_logical_helper_five_backend.sh` for the strict recurring composition: the checker, all six
backend/runtime consumers with their exact native/generated roles, `success_logical_helpers_eager` through the
5x2 selected primary matrix, and generated-source/capability/coverage ledgers. Canonical local CI exposes the
same all-toolchain leg with `LINKEDSPEC_RUN_LOGICAL_MATRIX=1`. Public no-drift additionally locks 20 authoritative
documents and 13 forbidden current claims. The current ledger is 8 complete / 0 pending and parent `.5.2` is
closed.

`callable_signature_contract.json` adopts the definition-time variadic user-function contract without claiming
cross-backend admission early. It selects `fn name(fixed, ...rest) { ... }`, keeps version-1 fixed definitions exact,
defines version-2 signature objects whose outward placement is sourced from the descriptor union, binds extras as one fresh typed array, rejects keyword/overload/host-splat
semantics, and locks representative purpose-specific helper/method arities. Validate its schema, definitions,
bindings, diagnostics, and deterministically rendered future `.spec` fixture with
`bash tools/run_python_project_data.sh tools/check_callable_signature_contract.py`. Perl, Rust, Dart, Julia, and Lua consume the unchanged
source/result/record contract through native and generated execution. Lua's exact signature/runtime and outward
descriptor variants close under `.5.1/.5.3.1`, while emitted variadic execution closes under `.8.2` and final
five-backend admission under `.8.4`.

`callable_codeblock_contract.json` defines the portable first-class callable-codeblock boundary and its exact
current/future public projection. Exact `{|fixed, ...rest| body }` syntax constructs deferred typed codeblock data; `cb(args)`
uses caller-time stores, temporary copied parameter bindings, block-local return, and static callable precedence.
Ordinary `{ statements }` remains an eager block value, while empty and top-level-colon brace forms remain harray
literals. The contract also fixes diagnostics, exact final-only `name: codeblock`, eight contextual helper/
user-function/receiver forms, and a deterministic future `.spec` fixture. Validate the schema, parser/classifier
model, neutral invocation model, and fixture offline with
`bash tools/run_python_project_data.sh tools/check_callable_codeblock_contract.py`. That checker also locks the
five-backend/two-Lua-runtime recurring topology, satisfied-exclusion absence, and 25 public documents through 23
rejected governance mutations. The original 22 topology/route/status/public mutations remain exact; mutation 23
requires sole-facing project status to say 25 and rejects its stale 24 claim. Run
`bash tools/check_callable_codeblock_five_backend.sh` for the ordered neutral,
Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT composition; canonical CI exposes the same all-toolchain leg through
`LINKEDSPEC_RUN_CALLABLE_CODEBLOCK_MATRIX=1`. Perl consumes the
literal and invocation subset
through `prove -Iperl t/callable_codeblock_literal_contract.t`: exact AST/spans, inert canonical generated data,
assignment/copying, user-function preservation, dynamic caller execution, temporary fixed/rest restoration,
standalone discard, receiver continuation, static precedence, and typed failures pass. Generic Perl final-block
normalization audit `.11.3.3.0` found the declaration gap, ADR 0032 closes it in `.11.3.3.1`, and `.11.3.3.2`
preserves metadata plus executes equivalent attached/parenthesized helper/user-function/receiver contextual forms.
Perl construction, invocation, normalization, and closeout `.11.3` are complete. Rust `.11.4.1-.2` consume the
literal and dynamic-invocation subsets: exact brace classification, the same eight-field typed record and
fixed/rest signature, Unicode-coordinate spans, inert construction, compiled JSON/generated-source preservation,
semantic `codeblock` shapes, caller-context execution, copied/restored parameters, chaining/discard, static
precedence, and exact typed failures/ordered recursion pass without a host closure. Rust generic final-block
equivalence is complete through `.11.4.3`. Dart `.11.5.1-.3` likewise complete construction, dynamic invocation,
and generic final-block equivalence. Julia `.11.6.1-.3` now complete construction, bound-variable invocation, and
generic final-block equivalence through one signature-governed normalizer and the existing evaluator. Lua's
declared contextual forms, inert explicit literal construction, and ordinary bound-value invocation are current
through `.11.8.1-.2` on both ABIs, including exact failures and ordered recursion. Independently emitted execution
identity is current under `.11.8.3`. Five-backend callable recurring/public admission is complete under
`.11.8.4`; `future.generic_final_codeblock` is removed because no callable route or admission gap remains.
At callable admission, the established 16-capability census remained 80 pass / 0 partial / 0 gap because that
slice completed the separately excluded callable feature rather than inventing an unrelated row. Staged-AST
recurrence later adds the current seventeenth all-pass private capability row.

`complete_named_mark_contract.json` fixes the seven documented current named-mark helpers that were absent from
every governed backend inventory: entry/local start/end writers, line/column readers, and explicit clear. The
contract requires symbolic bare mark names, rule-label isolation, character-based public positions and locations,
and undef/zero behavior for absent reads and existence checks. Its exact Unicode parent/child fixture also proves
that a child cannot overwrite an identically named parent mark. Validate the schema, independent location model,
fixture rendering, and three drift mutations with `bash tools/run_python_project_data.sh tools/check_complete_named_mark_contract.py`. Perl
consumes the unchanged fixture through `prove -Iperl t/complete_named_mark_contract.t`, including live and
standalone generated execution. Rust consumes it through
`cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test complete_named_mark_contract`, including
native, serialized, emitted-plan, and generated execution. Dart consumes the same artifact through
`cd dart && dart test test/complete_named_mark_contract_test.dart`, including native, generated-plan,
emitted-state reconstruction, and primary-CLI execution. Its seven-name exact family view is retained after all
seven names join the aligned 250-name shared inventory. Julia consumes the same artifact through
`LINKEDSPEC_JULIA_CMD=/opt/homebrew/bin/julia bash tools/run_julia_local.sh` plus its focused exact contract. Lua
consumes it through `bash tools/run_lua_local.sh`, including native and serialized `SpecFile` reconstruction on
PUC Lua and LuaJIT. All five backends therefore resolve the seven helpers, and `.17.5` admits them into the shared
inventory. `tools/check_language_capability_coverage.pl` supplements the 105 corpus fixtures with this exact
fixture and the executable public gap example, independently checks all 126 public identifier-shaped Perl
contracts, and rejects fourteen explicitly classified compatibility, legacy, internal, and grammar-owned names
so a symmetric omission cannot remain invisible.

`punctuation_light_zero_arg_contract.json` adopts ADR `0033`'s narrow syntax aliases without turning LinkedSpec
into a general parenthesis-free call language. It locks six standalone bare zero-argument markers, generic bare
final receiver segments, exact normalized AST equivalence with parenthesized forms, ordinary-identifier retention,
condition/helper/intermediate-receiver/trailing-block exclusions, existing method-contract resolution, and one
deterministically rendered portable `.spec` fixture. Validate the 6 standalone, 4 receiver, 6 invalid, and fixture
cases offline with `bash tools/run_python_project_data.sh tools/check_punctuation_light_zero_arg_contract.py`. Perl consumes the contract through
`prove -Iperl t/punctuation_light_zero_arg_contract.t`, covering typed AST equivalence, final-only receiver
parsing, unchanged exclusions and method resolution, canonical `next` lowering, and live plus standalone
generated execution. Rust consumes the same syntax/AST cases through
`rust/linkedspec-runtime/tests/punctuation_light_zero_arg_contract.rs`, including exact native, serialized,
emitted-source, generated-plan, and rebuilt-CLI fixture results. Dart consumes the same cases through
`dart/test/punctuation_light_zero_arg_contract_test.dart`, including exact native, generated-plan, emitted-state,
and CLI fixture results. Julia consumes the same cases through
`julia/test/punctuation_light_zero_arg_contract_test.jl`, including exact native, generated-plan, emitted-state,
and CLI fixture results. Rust, Dart, and Julia's pre-existing `.contains()` missing-argument outcomes remain helper
drift owned by `FUTURE-PARITY-BACKLOG.5`; each alias preserves its backend's parenthesized outcome. Lua consumes
the same AST/negative/native fixture cases inside `lua/test/run.lua` on PUC Lua and LuaJIT, including public
SpecFile JSON reconstruction; its matching `.contains()` drift is also owned by `.5`. Generated Lua source closes
independently through exact emitter/family/subset proof `.8.1-.8.3`; the punctuation-light row relies on its exact
AST/native/serialized proof and does not claim that this one fixture separately runs through emitted Lua. The
current syntax is admitted for all five backends under `language.punctuation_light_zero_argument_aliases`. The
composed recurring proof is `bash tools/check_punctuation_light_five_backend.sh`; it exercises Lua on both ABIs
without conflating serialized-state reconstruction with generated-source execution.
The JSON key `future_fixture` is retained as the version-1 schema name; the fixture itself is now admitted current.

`uniform_binding_contract.json` adopts the selector-free one-binding target contract before backend behavior
changes. A bare identifier reads its current scalar, array, harray, or codeblock value; `set(name, value)` returns
that binding's post-assignment typed value; mutable helpers use bare targets and return updated values; absent
array/harray mutations create only the required kind; incompatible existing kinds fail with
`binding_kind_mismatch`. Static rule names retain precedence for ambiguous `push(name, target)` syntax, while
three-argument `split(name, source, delimiter)` is the mutable form and two-argument `split(source, delimiter)` is
pure. Exact `array(IDENTIFIER)` / `hash(IDENTIFIER)` calls are removed and reject with
`aggregate_selector_removed`, even when a one-element constructor was intended (`[IDENTIFIER]` is the replacement).
Zero/multi/quoted/computed constructor calls remain separately valid under version 1. Validate 11 migrations,
seven execution cases, six invalid selectors, eight constructor classifications, and deterministic future source/
results offline with `bash tools/run_python_project_data.sh tools/check_uniform_binding_contract.py`. Perl `.12.1.2`, Rust `.12.1.3`, Dart
`.12.1.4`, Julia `.12.1.5`, and Lua `.12.1.6` execute the contract. All tracked file-backed and embedded sources
are migrated. Perl `.12.1.8.1`, Rust `.12.1.8.2`, Dart `.12.1.8.3`, Julia `.12.1.8.4`, and Lua `.12.1.8.5`
hard-reject the removed exact selectors before execution. Cross-variant `.12.1.8.6` locks their shared contract,
boundaries, and zero runtime compatibility. The uniform-binding selector retirement is admitted by `.12.1.9`.
Follow-up `.12.1.10` extends its recurring public checker to all immediate component READMEs. The current 70-file
inventory is locked at 36 classified removed/history references and zero current examples. The constructor
guide's explicit single-bare-value rejection is included in that inventory. Explicit bare-binding anchors remain
required in the Rust, Dart, Julia, and Lua READMEs.
Closed follow-up `.12.1.11` reconciles older statement-only array-end result prose and Perl value-position lowering
with the already-admitted updated-value contract. `bash tools/run_python_project_data.sh tools/check_uniform_binding_mutation_result_surface.py`
gates the public book/backend summaries, current backend fact anchors, and explicitly classified historical cards.

`generated_source_contract.json` is the versioned semantic contract for host-language source emission. It fixes
compiled-spec-plus-identity input, deterministic source markers, independent compile/load, execute and traced-
execute roles, the ten structural families, plan rejection, stable generated-source errors, one direct behavior
fixture, the accepted eight-case generated subset, and the 105-case interpreter oracle. It explicitly does not
require identical host API names, source syntax, or bytes. Run:

```bash
perl tools/check_generated_source_contract.pl
```

The census intentionally records proof quality separately from implementation belief. Passing the 105-case corpus
does not by itself prove every helper and API described by the mdBook; `FUTURE-PARITY-BACKLOG.1.6.1` owns that
coverage mapping. Generated source was first owned by `FUTURE-PARITY-BACKLOG.3` and Lua completion by
`LUA-BACKEND-PARITY.8`. `.3.1.0` demonstrated
why execution proof matters by exposing Perl's lost dependency indexes; `.3.1.2` repairs that mechanism and passes
focused contract proof. Rust v1 identity/metadata/errors plus exact neutral plan/direct result/trace roles align.
Admission `.3.1.3.3` promotes Perl to pass. Rust's staged full-manifest classifier is an unconditional recurring
105/105 gate, and `.3.2.2` admits it. Dart `.3.3.1-.3` and Julia `.3.4.1-.3` bind deterministic ten-family source
to the exact accepted eight-case interpreter-first isolated-host proof and are admitted. Lua `.8.1-.8.3` now adds
exact v1/v2/v3 emission, dual-ABI isolation, ten-family execution, and the same contract-ordered 8/105 proof in
fresh PUC Lua/LuaJIT hosts; the checker owns Lua's path/order/proof/trace/cleanup registration. Sole admission
owner `.8.4` now adds Lua to every row in one all-pass expansion. The current census is 80 pass / zero partial /
zero gap across five admitted backends, and the satisfied Lua-backend and variadic-function exclusions are retired.
