# USER GUIDE - ActionIR `ControlFlow.pm`
This guide covers the statement-level control-flow lowering implemented by `perl/LinkedSpec/ActionIR/ControlFlow.pm`.

Post-`SPEC-FORMAT-TERSE.8.3` / `.8.4` status:
- control-flow syntax remains current, but this root guide still contains older helper spellings inside branch bodies,
- read `assign(...)`, `array_copy(...)`, `hash_copy(...)`, `push_value(...)`, `push_nonempty(...)`, `concat(...)`, scalar-slot wrappers, and short wrapper aliases here as historical unless a section explicitly marks current guidance,
- current branch-body examples use `target = value`, `set(...)`, `push(...)`, `copy(...)`, `cat(...)`, aggregate wrappers, and bare scalar reads.

Read this when you want canonical `if/else` flow, switch/case branching, and helper-based output statements inside those branches.
For exact DSL-to-Perl examples for every control-flow marker and emitted branch shape discussed here, also read [`USER_GUIDE_ActionIR_EmittedPerlReference.md`](USER_GUIDE_ActionIR_EmittedPerlReference.md).

Logical target/current boundary (2026-07-17): ADR `0043` is current on all five backends and every admitted
generated role. One typed policy makes null, false, numeric zero, empty strings, and empty arrays/harrays false;
nonzero finite numbers, all nonempty strings (including `"0"` and `"false"`), nonempty aggregates, and codeblocks
are true. Testing a codeblock does not invoke it. `and`/`or` are eager value helpers with at least one argument and
`not` is an exact-one helper. Invalid arity raises `helper_arity_mismatch` before any operand runs. The controls
documented here remain lazy over the same truthiness: only the selected branch/body executes.

For example, this records both eager logical effects but skips the unselected control branch:

```text
Top::
 /x/
 E {
   seen = []
   ready = or(true, { push(seen, "or-second"); return(false) })
   complete = and("0", { push(seen, "and-second"); return(true) })
   result = if(ready, { return(not(false)) }, { push(seen, "skipped"); return(false) })
   return(hash("complete", complete, "result", result, "seen", copy(seen)))
 }
```

The result is `{"complete":true,"result":true,"seen":["or-second","and-second"]}`. By contrast, invalid
`and()` and `not(false, true)` calls fail before evaluating any supplied operand. Perl uses
`LinkedSpec::RuntimeLogical`; Rust, Dart, Julia, and Lua use their typed runtime seams. Native,
normalized/reconstructed, generated direct/traced,
and primary-command projections all retain the same values, effects, and arity outcome.

Method-DSL migration note:
- fluent-versus-structured authoring equivalence is intended to hold inside these branch bodies too,
- so `if(...)` / `elseif(...)` branches and `switch(...)` / `case(...)` action bodies are part of the same method-like DSL equivalence target,
- and supported general-`return(...)` branch-local method slices are now regression-locked on both the fluent and structured surfaces,
- including the corresponding lifecycle surfaces (`I`, `LS`, `LE`, `E`, `EX`, `IT`, and `LX`, with `LX.if(...).m(...).endif()` versus `LX { if(...); m(...); endif() }` as representative examples, plus the parallel switch/case forms),
- and supported multi-step helper sequences inside action-edge branch bodies are regression-locked there too,
- and that same supported multi-step helper-sequence equivalence is regression-locked on lifecycle branch bodies too,
- and inline composite `switch(..., case(...), default(...))` method forms are regression-locked between fluent and structured authoring on both action-edge and lifecycle surfaces,
- even when the docs show only representative branch examples.

Syntax status note:
- the examples in this guide show the currently supported control-flow surface,
- but that surface is not being treated as final UX law,
- and the roadmap now explicitly keeps a control-flow syntax revisit open so we can reduce friction around marker-style forms like `else();` and `endif()`,
- investigate more natural semicolon-light or brace-delimited branch syntax,
- and evaluate inline composite `if(...)` forms similar in spirit to inline composite `switch(...)`.
- that semicolon-light direction is only for canonical method-like DSL blocks,
- not for a mixed raw-Perl-plus-DSL authoring model,
- because raw Perl in `.spec` is now being treated as obsolete authoring that should be rejected and migrated away.
- an agreed pre-implementation design note is now also tracked:
  - keep one branch header mapped to one body carrier,
  - do not mix inline branch actions and attached branch blocks on the same `case(...)`, `default()`, `if(...)`, or `elseif(...)`,
  - do not pursue chained branch-body syntax like `case(value, m1(...).m2(...))`,
  - treat `case(value, { ... })` as the preferred first structured inline-switch extension,
  - `case(value) { ... }` and `default() { ... }` are now supported switch sugar on both inline composite and structured marker-style switch surfaces,
  - `switch(expr) { case(value) { ... } default { ... } }` is now supported too as the block-bodied outer sibling of the inline composite switch attached-branch-block surface,
  - and that same outer switch form now also accepts plain marker branches such as `case(value) ... default ...` inside the outer block, not only per-branch attached blocks,
  - and that same outer switch form now also allows mixed per-branch carriers such as `case("A") { ... } case("B") ... default { ... }` on both structured and final-call fluent surfaces,
  - and that same outer switch form is now also available as the final call on fluent action-edge and lifecycle chains, not only inside structured outer blocks,
  - treat inline composite `if(cond, action1(...), ..., elseif(cond2, ...), else(...))` as the first `if(...)` step, with the matching attached-block composite form `if(cond) { ... } elseif(cond2) { ... } else() { ... }` now landed on structured block surfaces and as the final call on fluent action-edge and lifecycle chains,
  - that same attached-block composite `if(...)` family now also allows mixed per-branch carriers such as `if(cond) { ... } elseif(cond2) ... else { ... }`,
  - and treat marker-style `if(...) ... endif()` / `switch(...) ... endswitch()` as structured-block-context syntax rather than as a free-standing fluent surface.
- Structured block contexts for those marker-style forms include:
  - top-level action-edge `{ ... }` blocks,
  - lifecycle blocks such as `I { ... }`, `LS { ... }`, `LE { ... }`, `E { ... }`, `EX { ... }`, `IT { ... }`, and `LX { ... }`,
  - and nested structured branch bodies such as `case(value, { ... })` and `case(value) { ... }`.

## What this module is responsible for
This module lowers:
- `if(...)` and alias `i(...)`
- `elseif(...)` and alias `elif(...)`
- `else()` / bare `else` in structured block contexts
- `endif()`
- `switch(...)`
- `case(...)`
- `default()` / bare `default` in structured block contexts
- `endcase()`
- `endswitch()`
- `say(...)`
- `print(...)`
- `print_each(...)`
- `return_undef()`
- `next()`

It also supports three switch surfaces:
1. marker-style flow (`switch() case() default() endswitch()` with optional semicolons on both action-edge structured blocks and lifecycle `I`, `LS`, `LE`, `E`, `EX`, `IT`, and `LX` blocks), including attached branch-block sugar such as `case(value) { ... }`, `default() { ... }`, and `default { ... }`, and
2. inline composite switch arguments (`switch(expr, case(...), default(...))`), including both `case(value, { ... })` / `default({ ... })` and attached `case(value) { ... }` / `default() { ... }` / `default { ... }` branch-body forms, and
3. a block-bodied outer switch form (`switch(expr) { case(value) { ... } default { ... } }`) that lowers through the same canonical path as the inline composite switch attached-branch-block baseline, while also accepting plain marker branches such as `case(value) ... default ...`, mixed per-branch carrier chains such as `case("A") { ... } case("B") ... default { ... }`, and the same outer block as the final call on fluent action-edge and lifecycle chains.

It also supports three `if(...)` surfaces:
1. marker-style flow (`if(...) ... elseif(...) ... else() ... endif()`) in structured block contexts,
2. inline composite flow (`if(cond, action1(...), ..., elseif(cond2, ...), else(...))`) plus its structured branch-body form `if(cond, { ... }, elseif(cond2, { ... }), else({ ... }))`, and
3. structured attached-block composite flow (`if(cond) { ... } elseif(cond2) { ... } else() { ... }`) on action-edge and lifecycle block surfaces, with `else { ... }` accepted as the lighter final-branch alias, mixed per-branch carrier chains such as `if(cond) { ... } elseif(cond2) ... else { ... }` supported too, and the same family available as the final call on fluent action-edge and lifecycle chains.

For the structured branch-body `if(...)` surfaces in items `2` and `3`, nested switch flow is now part of the supported structured-context contract too. That includes:
- marker-style `switch(...) ... case(...) ... default() ... endswitch()`, and
- inline-composite `switch(...)` forms, including attached switch-branch sugar such as `case(value) { ... }` / `default() { ... }`.

Those nested switch forms can now live inside composite-`if(...)` branch bodies without dropping out of canonical rewrite readiness.
That nested inline-composite `switch(...)` coverage inside composite-`if(...)` branch bodies now explicitly includes broader multi-`case(...)` shapes too, not only the simpler single-`case(...)` form.
That same composite-`if(...)` nested marker-switch contract now explicitly includes the deeper `if/elseif/else` branch shape too, not only the simpler `if/else` shape.
That same deeper composite-`if/elseif/else` branch shape is now regression-locked for nested inline-composite `switch(...)` flow too, not only nested marker-style `switch(...) ... endswitch()` flow.
That same deeper composite-`if/elseif/else` branch shape now explicitly includes the broader multi-`case(...)` nested inline-composite `switch(...)` form too, not only the simpler single-`case(...)` nested inline-switch shape.
That same deeper composite-`if/elseif/else` branch shape now explicitly includes the broader multi-`case(...)` nested marker-style `switch(...) ... endswitch()` form too, not only the simpler single-`case(...)` marker-switch shape.
Marker-style `if(...) ... endif()` and marker-style `switch(...) ... endswitch()` are also intended to allow arbitrarily deep mutual nesting in structured block contexts. The current regression suite locks a representative deeper alternating chain across action-edge and the full lifecycle family, and that same deeper alternating contract is now pinned inside attached switch branch blocks plus both structured inline and attached-block composite `if(...)` branch bodies too, so there is no DSL-fixed semantic nesting cap here beyond normal recursion/resource limits.

## `if / elseif / else / endif`
These are statement markers, not Perl block keywords.
In structured helper-only blocks and structured lifecycle `I`, `LS`, `LE`, `E`, `EX`, `IT`, and `LX` blocks, semicolons are accepted but not required between top-level method statements.

### Basic form

```text
if(condition)
  ...
endif()
```

### With else branch

```text
if(condition)
  ...
else()
  ...
endif()
```

### With elseif/elif

```text
if(condition_a)
  ...
elseif(condition_b)
  ...
else()
  ...
endif()
```

Alias form:

```text
i(condition_a)
  ...
elif(condition_b)
  ...
endif()
```

## Common `if` use cases
### Flush a working array only when it has content

```text
if(is_nonempty(array(word)))
  push(array(tail), join_values("", array(word)));
  set(array(word), []);
endif()
```

### Return different payloads depending on accumulator state

```text
if(is_nonempty(array(tail)))
  return(array(scalar(head), array_copy(array(tail))));
else()
  return(array(scalar(head), undef));
endif()
```

### Optional return

```text
if(is_nonempty(array(items)))
  return(array_copy(array(items)));
else()
  return_undef();
endif()
```

## `switch / case / default / endswitch`
Switch is useful when the same driving value controls multiple branches.

### Marker-style switch

```text
switch(scalar(kind))
  case("SPACE")
    ...
  case("COMMENTS")
    ...
  default()
    ...
endswitch()
```

Optional `endcase()` is supported when you want to close a case explicitly before opening the next one, but it is not required in most normal flows.

### Regex case matching
`case(...)` is not limited to literal equality tests. Regex cases are also supported.

Example:

```text
switch(scalar(token))
  case(/^BEGIN_/)
    say("begin token");
  case(/^END_/)
    say("end token");
  default()
    say("other token");
endswitch()
```

Use regex cases when the branch logic is classification-by-pattern rather than classification-by-exact-value.

### When switch is a good fit
Use switch when:
- all branches are based on one driving value,
- you have multiple equality or regex cases,
- repeated `elseif(eq(...))` would be noisier than a single dispatch block.

## Inline composite switch
Inline switch keeps the case structure inside one expression.

Example:

```text
switch(
  scalar(op),
  case("|", push(pipe_operator, rule)),
  case("&", say("amp")),
  default(say("Error"), return_undef())
)
```

Use this when:
- the branch actions are short,
- the branch structure is simple,
- you want the dispatch logic compact and local.

The first structured branch-body extension is supported too:

```text
switch(
  scalar(op),
  case("|", {
    push(pipe_operator, rule)
    say("pipe")
  }),
  default({
    say("Error")
    return_undef()
  })
)
```

Current direction note:
- the current composite baseline remains `switch(expr, case(...), default(...))` with explicit action lists,
- `case(value, { ... })` and `default({ ... })` are now supported as the first structured inline-switch branch-body extension,
- attached-block switch sugar `case(value) { ... }` and `default() { ... }` is now supported too, on both inline composite and structured marker-style switch surfaces,
- the block-bodied outer switch form `switch(expr) { case(value) { ... } default { ... } }` is now supported too, and lowers equivalently to the inline composite switch attached-branch-block surface,
- and that same outer switch form now also accepts plain marker branches such as `case(value) ... default ...` inside the outer block, not only per-branch attached blocks,
- and those attached switch branch blocks can now carry nested marker-style flow such as `if(...) ... endif()` while staying fully language-agnostic-ready,
- and they now have explicit regression coverage for nested marker-style `switch(...) ... case(...) ... default() ... endswitch()` flow too,
- and they now have explicit regression coverage for the broader multi-`case(...)` nested marker-style `switch(...) ... endswitch()` shape too,
- and the two supported inline-switch structured branch-body carriers `case(value, { ... })` / `default({ ... })` and `case(value) { ... }` / `default() { ... }` are now regression-locked in parity for that broader nested marker-switch shape too,
- and those same two inline-switch structured branch-body carriers are now regression-locked in parity for nested composite `if(...)` / `elseif(...)` flow too,
- and those same two inline-switch structured branch-body carriers are now regression-locked in parity for nested composite `if(...)` / `elseif(...)` flow carrying that deeper alternating marker `if(...) ... switch(...) ... endif()` nesting shape too,
- and those same two inline-switch structured branch-body carriers are now regression-locked in parity for the broader multi-`case(...)` nested marker-switch shape inside nested composite `if(...)` / `elseif(...)` flow too,
- and those same two inline-switch structured branch-body carriers are now regression-locked in parity for the broader multi-`case(...)` nested inline-composite `switch(...)` shape inside nested composite `if(...)` / `elseif(...)` flow too,
- and those same two inline-switch structured branch-body carriers are now regression-locked in parity for the deeper alternating marker `if(...) ... switch(...) ... endif()` nesting shape too,

## Attached-block outer switch
This is the lower-friction structured outer-body form:

```text
switch(scalar(op)) {
  case("|") {
    say("pipe")
    return_undef()
  }
  default {
    say("miss")
    return_undef()
  }
}
```

Use this when:
- you want a structured switch body without a trailing `endswitch()` marker,
- you still want each branch body to stay on the canonical method-like DSL surface,
- and the block should behave like the structured outer sibling of the existing inline composite switch forms rather than like marker-style switch syntax with hidden raw Perl.

The outer block accepts both of these styles:

```text
switch(scalar(op)) {
  case("|")
    say("pipe")
    return_undef()
  default
    say("miss")
    return_undef()
}
```

```text
switch(scalar(op)) {
  case("|") {
    say("pipe")
    return_undef()
  }
  default {
    say("miss")
    return_undef()
  }
}
```

The same surface now works as the final fluent call too:

```text
/a/ -> Top.switch(scalar(op)) {
  case("|")
    say("pipe")
    return_undef()
  default
    say("miss")
    return_undef()
}
```

```text
I.switch(scalar(op)) {
  case("|")
    return_undef()
  default
    return_undef()
}
```

And mixed per-branch carriers are supported too:

```text
switch(scalar(op)) {
  case("|") {
    declare(array, events)
    return_array(semantic_annotation, hash("items", array(events)))
  }
  case("&")
    say("amp")
    return_undef()
  default {
    return_undef()
  }
}
```

The same mixed-carrier outer switch also works as the final fluent call:

```text
/a/ -> Top.switch(scalar(op)) {
  case("|") {
    declare(array, events)
    return_array(semantic_annotation, hash("items", array(events)))
  }
  case("&")
    say("amp")
    return_undef()
  default {
    return_undef()
  }
}
```
- and the marker-style outer switch structured branch-body surfaces are now regression-locked in parity for that same deeper alternating marker `if(...) ... switch(...) ... endif()` nesting shape too, across plain branch markers and attached branch blocks,
- and those same marker-style outer switch structured branch-body surfaces are now regression-locked in parity for nested composite `if(...)` / `elseif(...)` flow too,
- and those same marker-style outer switch structured branch-body surfaces are now regression-locked in parity for nested composite `if(...)` / `elseif(...)` flow carrying that deeper alternating marker `if(...) ... switch(...) ... endif()` nesting shape too,
- and those same marker-style outer switch structured branch-body surfaces are now regression-locked in parity for the broader multi-`case(...)` nested marker-switch shape inside nested composite `if(...)` / `elseif(...)` flow too,
- and those same marker-style outer switch structured branch-body surfaces are now regression-locked in parity for that same broader multi-`case(...)` nested inline-composite `switch(...)` shape inside nested composite `if(...)` / `elseif(...)` flow too,
- and attached switch branch blocks are now regression-locked in parity across the two outer switch families themselves for that same deeper alternating marker `if(...) ... switch(...) ... endif()` nesting shape too,
- and that same outer-switch-family attached-branch parity is now regression-locked for nested composite `if(...)` / `elseif(...)` flow carrying that deeper alternating marker `if(...) ... switch(...) ... endif()` nesting shape too,
- and the structured marker-style outer switch surface is now regression-locked in parity across its plain branch-marker form and attached-block switch branch sugar for that broader nested marker-switch shape too,
- and attached switch branch blocks are now regression-locked in parity across the two outer switch families themselves for that broader multi-`case(...)` nested marker-switch shape too,
- and attached switch branch blocks are now regression-locked in parity across the two outer switch families themselves for the broader multi-`case(...)` nested inline-composite `switch(...)` shape too,
- and attached switch branch blocks are now regression-locked in parity across the two outer switch families themselves for nested composite `if(...)` / `elseif(...)` flow too,
- and they now have explicit regression coverage for nested composite `if(...)` forms too, including both inline composite and attached-block inner `if` surfaces,
- and they now have explicit regression coverage for parity between structured inline composite `if(...)` branch-block bodies and attached-block composite `if(...)` branch bodies too, even when those deeper `if/elseif/else` branches themselves carry nested inline-composite `switch(...)` flow,
- and that same deeper attached-switch parity now has explicit regression coverage for nested marker-style `switch(...) ... endswitch()` flow inside those deeper `if/elseif/else` branches too,
- and that same attached-switch parity now has explicit regression coverage for the broader multi-`case(...)` nested inline-composite `switch(...)` shape inside those deeper `if/elseif/else` branches too,
- and that broader multi-`case(...)` nested inline-switch parity now spans both inline composite and marker-style outer switch families too,
- and that same deeper attached-switch parity now has explicit regression coverage for the broader multi-`case(...)` nested marker-style `switch(...) ... endswitch()` shape too, across both inline composite and marker-style outer switch families,
- and attached switch branch blocks are now directly regression-locked across the two outer switch families for that broader multi-`case(...)` nested inline-composite `switch(...)` shape inside nested composite `if(...)` / `elseif(...)` flow too,
- and attached switch branch blocks are now directly regression-locked across the two outer switch families for that same broader multi-`case(...)` nested marker-style `switch(...) ... endswitch()` shape inside nested composite `if(...)` / `elseif(...)` flow too,
- and they now have explicit regression coverage for nested inline-composite `switch(...)` forms too, on both inline composite and marker-style outer switch surfaces,
- and that nested composite-`if(...)` coverage now explicitly includes the deeper `elseif(...)` branch shape too,
- and that nested inline-composite `switch(...)` coverage now explicitly includes broader multi-`case(...)` shapes too,
- and composite `if(...)` branch bodies now also have explicit regression coverage for broader nested multi-`case(...)` marker-style `switch(...) ... endswitch()` flow, across both structured inline branch-block and attached-block `if(...)` forms,
- and those same composite `if(...)` branch bodies now also have explicit regression coverage for the deeper `if/elseif/else` branch shape with nested marker-style `switch(...) ... endswitch()` flow,
- and those same deeper composite `if/elseif/else` branch bodies now also have explicit regression coverage for nested inline-composite `switch(...)` flow,
- but mixed forms like `default(action1(...)) { action2(...) }` are intentionally out of scope,
- because each branch should have exactly one body carrier.

Nested structured flow example:

```text
switch(
  scalar(op),
  case("|") {
    if(scalar(on))
      say("pipe")
      return_undef()
    else()
      return_undef()
    endif()
  },
  default() {
    return_undef()
  }
)
```

That same nested marker-flow pattern is also supported on the marker-style switch surface:

```text
switch(scalar(op))
  case("|") {
    if(scalar(on))
      say("pipe")
      return_undef()
    else()
      return_undef()
    endif()
  }
  default() {
    return_undef()
  }
endswitch()
```

Nested marker-style switch inside an attached branch block is also supported:

```text
switch(
  scalar(op),
  case("|") {
    switch(scalar(mode))
      case("x")
        say("x")
        return_undef()
      default()
        return_undef()
    endswitch()
  },
  default() {
    return_undef()
  }
)
```

## Inline composite `if(...)` design direction
The first inline composite `if(...)` slice is now supported.

Supported form:

```text
if(
  scalar(on),
  action1(...),
  action2(...),
  elseif(scalar(alt_on), action3(...), action4(...)),
  else(action5(...), action6(...))
)
```

This is the supported first-step compact form. It lowers through the same control-flow path as the older marker-style baseline:

```text
if(scalar(on))
  action1(...)
  action2(...)
elseif(scalar(alt_on))
  action3(...)
  action4(...)
else()
  action5(...)
  action6(...)
endif()
```

Structured branch-body extension:

```text
if(
  scalar(on),
  {
    action1(...)
    action2(...)
  },
  elseif(scalar(alt_on), {
    action3(...)
    action4(...)
  }),
  else({
    action5(...)
    action6(...)
  })
)
```

That structured inline-composite `if(...)` form is now supported too. It uses the same one-header / one-body-carrier rule as the structured inline-composite `switch(...)` branch-body extension, and it reuses the normal semicolon-light structured statement splitter inside each branch body.

Lifecycle-family note:
- the inline composite control-flow surfaces in this guide are no longer only `LX` proof points,
- action-list and structured branch-block forms for inline composite `if(...)` and `switch(...)` are now regression-locked across `I`, `LS`, `LE`, `E`, `EX`, `IT`, and `LX`,
- and the guide continues to show `LX` examples only because they are representative, not because the support stops there.

Longer-term ergonomics may move toward attached-block forms:

```text
if(scalar(on)) {
  action1(...);
  action2(...)
} elseif(scalar(alt_on)) {
  action3(...);
  action4(...)
} else() {
  action5(...);
  action6(...)
}
```

That attached-block form is now part of the supported structured-block surface, and the same shape is now also supported as the final call on fluent action-edge and lifecycle chains.

```text
/a/ -> Top.if(scalar(on)) {
  action1(...)
} elseif(scalar(alt_on)) {
  action2(...)
} else {
  action3(...)
}
```

```text
I.if(scalar(on)) {
  action1(...)
} elseif(scalar(alt_on)) {
  action2(...)
} else {
  action3(...)
}
```

The later syntax work that still remains is mainly about further punctuation cleanup and other ergonomics, not about whether attached-block `if(...)` exists at all.

That same attached-block composite family is no longer all-or-nothing about branch carriers. Representative supported shapes now include:

```text
if(scalar(on)) {
  action1(...)
} elseif(scalar(alt_on))
  action2(...)
else {
  action3(...)
}
```

```text
/a/ -> Top.if(scalar(on)) {
  action1(...)
} elseif(scalar(alt_on))
  action2(...)
else {
  action3(...)
}
```

One punctuation-reduction slice has already landed for marker-style flow too: in structured block contexts, the zero-arg markers `else`, `endif`, `default`, `endcase`, and `endswitch` are now accepted as bare-keyword aliases for `else()`, `endif()`, `default()`, `endcase()`, and `endswitch()`.

That same punctuation-light treatment now explicitly covers fluent chains too. The shorter marker spellings are not limited to tiny toy cases; they are meant to be readable in ordinary multi-step flows as well.

Worked fluent `if / elseif / else / endif` example:

```text
/a/ -> Top
  .if(scalar(on))
  .declare(array, events)
  .push_value(array(events), hash("kind", "on"))
  .return(array_copy(array(events)))
  .elseif(scalar(alt_on))
  .say("alt branch")
  .return(hash("kind", "alt"))
  .else
  .say("no branch matched")
  .return_undef()
  .endif
```

That example uses the lighter `.else` and `.endif` spellings, but it lowers through the same canonical path as the older `.else()` and `.endif()` forms.

Worked fluent `switch / case / default / endcase / endswitch` example:

```text
LX
  .switch(scalar(kind))
  .case("OPEN")
  .declare(array, parts)
  .push_value(array(parts), hash("kind", "open"))
  .return(hash("parts", array_copy(array(parts))))
  .endcase
  .case("CLOSE")
  .say("closing token")
  .return(hash("kind", "close"))
  .endcase
  .default
  .say("unexpected token")
  .return_undef()
  .endcase
  .endswitch
```

That example uses the lighter `.default`, `.endcase`, and `.endswitch` spellings. They lower through the same canonical path as `.default()`, `.endcase()`, and `.endswitch()`. `endcase` remains optional in many flows, but it is shown here deliberately because explicit branch closeout can make longer fluent switch chains easier to read.

## `say(...)`
`say(...)` produces one diagnostic event whose message is the concatenated scalar text plus one newline.

Examples:

```text
say("(Lispish) -E- Syntax Error")
say("entered rule ", scalar(rule_name))
```

Use it when you want a simple line-oriented diagnostic delivered to the embedding caller.

## `print(...)`
`print(...)` produces one diagnostic event without adding a newline.

Examples:

```text
print("begin_end_blocks: BEGIN (", scalar(IMATCH), "\n")
print("Object ", cur_object[1], "\n")
print("token=", scalar(token), " type=", retv["type"], "\n")
```

Use it when:
- you want full control over line endings,
- you want to assemble richer diagnostics,
- you are porting older debug-print rules into canonical helper flow.

## `print_each(array(target), prefix, suffix?)`
`print_each(...)` produces one ordered diagnostic event per item in a working array, with optional text before and
after each item.

Examples:

```text
print_each(array(matches), "match:<<", ">>\n")
print_each(array(tokens), "token=", "\n")
print_each(array(debug_rows), "")
```

The first argument must name an array container. The second argument is prepended to each item. The optional third
argument is appended; include `"\n"` there when you want line-oriented messages. `print_each` requires exactly two or three
arguments. It evaluates the target, prefix, and suffix exactly once left-to-right before delivering any
item; an omitted suffix is empty text.

Use it when:
- you have already accumulated child results or debug fragments in an array,
- you want canonical ActionIR metadata for iterable debug output,
- you are replacing older raw loops like `print "...$_..." foreach (@matches)`.

All three helpers validate arity before argument effects and return no structural parser value. A native or
generated embedding API may install one caller-owned `RuntimeDiagnosticOutputEvent` sink for an invocation. Each
event contains the helper name, current rule label, and Unicode message. Omitting the sink is quiet, a sink failure
propagates unchanged, and `exit_now(status)` remains distinct typed immediate control. Rich diagnostic events do
not enter parse results, native/generated trace, primary-command stdout, or stderr. See the mdBook
[value/container helper reference](docs/linkedspec-book/src/dsl/value-container-flow-helper-reference.md#debug-output-helpers)
for complete Perl, Rust, Dart, Julia, and Lua API examples.

## `return_undef()`
This is the explicit helper for returning `undef` in canonical control-flow.

Example:

```text
if(is_nonempty(array(assigns)))
  return(hash("name", scalar(block_namei), "content", array_copy(array(assigns))));
else()
  return_undef();
endif()
```

Use it when the “no result” case is a deliberate branch outcome.

## `next()`
This is the explicit helper for skipping the current action path with the runtime `next` statement while staying on canonical ActionIR metadata.

Example:

```text
comment: /#.*\n/

Top::
 -> Item    {push(Item)}
 -> comment {next()}
```

Use it when an edge should consume or recognize something, such as a comment, but should not add a value to the current accumulator. Bare `next` is still recognized for old specs, but `next()` is the preferred spelling for new backend-neutral authoring.

## Worked examples
### Example: simple presence guard

```text
if(is_nonempty(array(items)))
  return(array_copy(array(items)));
else()
  return_undef();
endif()
```

### Example: recursive-head/tail finalizer

```text
if(scalar(has_head))
  if(is_nonempty(array(tail)))
    return(array(scalar(head), array_copy(array(tail))));
  else()
    return(array(scalar(head), undef));
  endif()
else()
  return(array(undef));
endif()
```

### Example: classify child return types

```text
switch(retv["type"])
  case("SPACE")
    assign(array(word), array());
  case("COMMENTS")
    return_undef();
  default
    push_value(array(word), retv["content"]);
endswitch
```

### Example: compact inline switch

```text
switch(
  retv["type"],
  case("SPACE", assign(array(word), array())),
  case("COMMENTS", return_undef()),
  default(push_value(array(word), retv["content"]))
)
```

### Example: regex-driven switch

```text
switch(scalar(token))
  case(/^\\?/)
    say("tag token");
  case(/^[A-Z_]+$/)
    say("identifier-like token");
  default()
    say("fallback token");
endswitch()
```

## Recommendations
- Use helper flow markers, not raw Perl `if (...) { ... }`, when authoring `.spec` control flow.
- Raw Perl control-flow bodies are legacy migration debt, not part of the intended long-term `.spec` surface.
- Keep nested `if(...)` blocks readable; deeply nested branch stacks are still harder to maintain than assigning an intermediate flag.
- Prefer inline switch only when each branch is short. Use marker-style switch for longer bodies.
- Use `say(...)`, `print(...)`, and `print_each(...)` for diagnostics instead of embedding raw output statements if backend-neutrality matters.

## Related guides
- Condition expressions: [`USER_GUIDE_ActionIR_FlowExpr.md`](USER_GUIDE_ActionIR_FlowExpr.md)
- Legacy capture/backtrack helpers: [`USER_GUIDE_ActionIR_Contracts.md`](USER_GUIDE_ActionIR_Contracts.md)
