# USER GUIDE: Rule Modes And Split Boundaries
This guide covers the current rule-shape surface, including explicit `OR`, explicit `OR+`, explicit `AND+`, bounded `OR{...}`, and bounded `AND{...}` labels.

Read this when you want to understand:
- what rule-label sigils already mean today,
- how much of that surface is already part of the supported contract,
- and what `@capture_slice` actually does when you need split-like staged extraction.

## Current Rule Label Surface
Today, rule labels support a small, explicit set of suffix modes.

Baseline labels:

```text
top_rule::
regular_rule:
```

Current mode suffixes:

```text
sequence_rule:&
choice_rule:|
one_or_more_rule:+
zero_or_more_rule:*
optional_rule:?
explicit_sequence:AND
explicit_repeated_choice_shorthand:OR+
explicit_repeated_sequence:AND+
explicit_repeated_choice:OR
bounded_choice_exact:OR{2}
bounded_choice_range:OR{2,4}
bounded_choice_open_max:OR{2,}
bounded_choice_open_min:OR{,4}
bounded_sequence_exact:AND{2}
bounded_sequence_range:AND{2,4}
bounded_sequence_open_max:AND{2,}
bounded_sequence_open_min:AND{,4}
```

Those are the current supported sigils. They are not placeholders for future grouped syntax. They are the current surface.

## What Each Current Mode Means
### Default rule shape
The default label shape stays on the current repeated-alternative extraction model.

Examples:

```text
top_rule::
 -> section_header
 -> section_body
 -> section_footer
```

```text
token_stream:
 /.../ -> token
 -> comment
 -> whitespace
```

Treat that as the current baseline LinkedSpec rule model. It is the baseline we should keep explicit and stable before layering richer grouped repetition on top.

For authoring purposes, the clearest mental model is that bare `rule:` belongs to the same repeated-choice family as:

```text
rule:OR
rule:OR+
rule:OR{1,}
```

and conceptually corresponds to `OR+`.

That mapping matters because:
- bare `rule:` is the historical default repeated-alternative behavior,
- `rule:OR` is now the explicit worded spelling for that same repeated-choice family when you want to say it out loud without adding numeric bounds,
- `rule:OR+` is now the explicit shorthand spelling for that same repeated-choice family when you want repetition punctuation made visible in the label,
- `rule:|` is the separate single-choice dispatch surface,
- and the worded `OR{...}` family makes the same repeated-choice family explicit when you need bounds.

Representative equivalence example:

```text
item_list:
 /[A-Za-z_]\w*/ -> item_list
 /"(?:[^"\\]|\\.)*"/ -> item_list
```

is the same repeated-choice idea as:

```text
item_list:OR
/[A-Za-z_]\w*/ -> item_list
/"(?:[^"\\]|\\.)*"/ -> item_list
```

and:

```text
item_list:OR+
 /[A-Za-z_]\w*/ -> item_list
 /"(?:[^"\\]|\\.)*"/ -> item_list
```

and:

```text
item_list:OR{1,}
 /[A-Za-z_]\w*/ -> item_list
 /"(?:[^"\\]|\\.)*"/ -> item_list
```

`rule:OR`, `rule:OR+`, and `rule:OR{1,}` are explicit grouped-rule spellings. Bare `rule:` remains the historical default surface for that same repeated-choice baseline rather than a promise that every low-level emitted handler path is textually identical.

### `:&` ordered sequence
`:&` means ordered sequence.

Representative shape:

```text
pair:&
 /[A-Za-z_]\w*/ -> key
 /\s*=\s*/
 /[^,\n]+/ -> value
```

Use it when the rule should succeed only if the expected pieces arrive in sequence.

### `:AND` explicit ordered sequence
`AND` means ordered sequence too, with the same ordered-sequence contract as `:&`.

Representative shape:

```text
pair:AND
 /[A-Za-z_]\w*/ -> key
 /\s*=\s*/
 /[^,\n]+/ -> value
```

Use it when you want the ordered-sequence family spelled out explicitly instead of using the shorter `:&` sigil. It is the worded sibling of the existing ordered-sequence baseline, not a repeated-sequence form.

### `:AND+` explicit open-ended repeated sequence
`AND+` means open-ended repeated ordered sequence with the same min-one repetition contract as `AND{1,}`.

Representative shape:

```text
assignment_stream:AND+
 /[A-Za-z_]\w*/ -> assignment_stream
 /\s*=\s*/
 /[^,\n]+/ -> assignment_stream
```

Use it when you want the whole ordered sequence to repeat one or more times and you want that grouped repetition spelled out explicitly without switching to numeric bounds.

### `:|` choice
`:|` means single-choice dispatch.

Representative shape:

```text
item:|
 /"(?:[^"\\]|\\.)*"/ -> quoted_string
 /\d+/ -> integer_literal
 /[A-Za-z_]\w*/ -> bare_identifier
```

Use it when the rule is a choice among alternatives rather than an ordered chain.

### `:+` one or more
`:+` is the current one-or-more repetition surface.

Representative shape:

```text
argument_list:+
 /[A-Za-z_]\w*/ -> argument_item
```

Think of it as the current repetition mode for “repeat until this rule stops matching, but require at least one successful iteration.”

### `:*` zero or more
`:*` is the current zero-or-more repetition surface.

Representative shape:

```text
separator_noise:*
 /\s+/
 /#.*\n/
```

Use it when the rule may match nothing at all and that still counts as success.

### `:?` zero or one
`:?` is the current optional repetition surface.

Representative shape:

```text
optional_trailing_comment:?
 /#.*$/
```

Use it when the rule should either match once or not match at all.

### `:OR` explicit repeated choice
`OR` means open-ended repeated choice with the same min-one repeated-choice contract as `OR{1,}`.

Representative shape:

```text
token_stream:OR
 /[A-Za-z_]\w*/ -> token_stream
 /"(?:[^"\\]|\\.)*"/ -> token_stream
 /'(?:[^'\\]|\\.)*'/ -> token_stream
```

Use it when you want the repeated-choice family spelled out explicitly without adding numeric bounds. It is the explicit worded sibling of the historical bare `rule:` baseline and the bounded `OR{1,}` form.

### `:OR+` explicit open-ended repeated choice shorthand
`OR+` means open-ended repeated choice too, with the same min-one repeated-choice contract as `OR` and `OR{1,}`.

Representative shape:

```text
token_stream:OR+
 /[A-Za-z_]\w*/ -> token_stream
 /"(?:[^"\\]|\\.)*"/ -> token_stream
 /'(?:[^'\\]|\\.)*'/ -> token_stream
```

Use it when you want the repeated-choice family spelled out with repetition punctuation instead of the bare worded `OR` form. It does not introduce a different execution model; it is the explicit shorthand sibling of `OR` and `OR{1,}`.

### `:OR{N}` exact bounded repeated choice
`OR{N}` means repeated alternative extraction with an exact required count.

Representative shape:

```text
pair_of_hex_digits:OR{2}
 /[0-9A-Fa-f]/ -> pair_of_hex_digits
```

Use it when the rule should match exactly `N` repeated choice iterations.

### `:OR{N,M}` bounded repeated choice
`OR{N,M}` means repeated alternative extraction with both a lower and upper bound.

Representative shape:

```text
up_to_three_flags:OR{1,3}
 /--debug/ -> up_to_three_flags
 /--trace/ -> up_to_three_flags
 /--strict/ -> up_to_three_flags
```

Use it when the rule should succeed only after at least `N` iterations and should stop collecting after `M`.

### `:OR{N,}` open-ended repeated choice
`OR{N,}` means repeated alternative extraction with a required minimum and no DSL-level upper bound beyond the current large internal repeat sentinel.

Representative shape:

```text
two_or_more_items:OR{2,}
 /[A-Za-z_]\w*/ -> two_or_more_items
 /"(?:[^"\\]|\\.)*"/ -> two_or_more_items
```

Use it when the rule should require at least `N` iterations but otherwise behave like the current repeated-alternative model.

### `:OR{,M}` upper-bounded repeated choice
`OR{,M}` means repeated alternative extraction with an implicit lower bound of `0` and an explicit upper bound of `M`.

Representative shape:

```text
optional_pair:OR{,2}
 /[A-Za-z_]\w*/ -> optional_pair
```

Use it when zero matches are allowed but you still want to cap how many alternative hits can be collected.

### `:AND{N}` exact bounded repeated sequence
`AND{N}` means ordered-sequence matching with an exact required repetition count.

Representative shape:

```text
pair_twice:AND{2}
 /[A-Za-z_]\w*/ -> pair_twice
 /\s*=\s*/
 /[^,\n]+/ -> pair_twice
```

Use it when the same ordered sequence must succeed exactly `N` times in a row.

### `:AND{N,M}` bounded repeated sequence
`AND{N,M}` means ordered-sequence matching with both a lower and upper repetition bound.

Representative shape:

```text
directive_triplets:AND{2,4}
 /BEGIN\b/ -> directive_triplets
 /\s+/
 /END\b/ -> directive_triplets
```

Use it when the whole sequence must repeat at least `N` times and at most `M` times.

### `:AND{N,}` open-ended repeated sequence
`AND{N,}` means ordered-sequence matching with a required minimum and no DSL-level upper bound beyond the current large internal repeat sentinel.

Representative shape:

```text
two_or_more_pairs:AND{2,}
 /[A-Za-z_]\w*/ -> two_or_more_pairs
 /\s*=\s*/
 /[^,\n]+/ -> two_or_more_pairs
```

Use it when at least `N` full sequence iterations are required but more are allowed.

### `:AND{,M}` upper-bounded repeated sequence
`AND{,M}` means ordered-sequence matching with an implicit lower bound of `0` and an explicit upper bound of `M`.

Representative shape:

```text
optional_pairs:AND{,2}
 /[A-Za-z_]\w*/ -> optional_pairs
 /\s*=\s*/
 /[^,\n]+/ -> optional_pairs
```

Use it when zero full sequence iterations are allowed but you still want a hard cap on how many whole sequence groups get consumed.

## Worked Repeated-Choice Examples
### Example: explicit open-ended repeated choice

```text
token_stream:OR
 /[A-Za-z_]\w*/ -> token_stream { $token_stream = $LMATCH }
 /"(?:[^"\\]|\\.)*"/ -> token_stream { $token_stream = $LMATCH }
 /'(?:[^'\\]|\\.)*'/ -> token_stream { $token_stream = $LMATCH }
```

What this means:
- at least one alternative hit is required,
- the rule keeps collecting repeated choice matches until no configured alternative matches any longer,
- and this is the explicit worded spelling for the same repeated-choice family that the historical bare `token_stream:` label belongs to.

### Example: exact repeated token pair

```text
hex_pair::OR{2}
 /[0-9A-Fa-f]/ -> hex_pair { $hex_pair = $LMATCH }
```

What this means:
- the rule runs the current alternative-choice machinery repeatedly,
- it must succeed exactly two times,
- and the returned collected value reflects exactly two matched iterations.

### Example: bounded repeated directive list

```text
directive_group:OR{2,4}
 /@include\b/ -> directive_group { $directive_group = $LMATCH }
 /@define\b/ -> directive_group { $directive_group = $LMATCH }
 /@pragma\b/ -> directive_group { $directive_group = $LMATCH }
```

What this means:
- fewer than two successful iterations fail the rule,
- two, three, or four successful iterations pass,
- the fifth possible match is not consumed by this rule because the configured maximum has already been reached.

### Example: coarse repeated extraction with open upper bound

```text
coarse_segment:OR{2,}
 /BEGIN\b/ -> coarse_segment { $coarse_segment = $LMATCH }
 /END\b/   -> coarse_segment { $coarse_segment = $LMATCH }
```

What this means:
- the rule needs at least two anchor hits,
- after that it keeps behaving like repeated alternative extraction,
- and it stays useful for coarse first-pass segmentation before a second-pass parse.

### Example: zero-to-two optional capture anchors

```text
optional_markers:OR{,2}
 /START\b/ -> optional_markers { $optional_markers = $LMATCH }
 /STOP\b/  -> optional_markers { $optional_markers = $LMATCH }
```

What this means:
- zero matches are acceptable,
- one or two matches are also acceptable,
- but the rule will not keep collecting beyond two matches.

## Worked Bounded-AND Examples
### Example: exact repeated key/value pairs

```text
pair_list:AND{2}
 /[A-Za-z_]\w*/ -> pair_list { $pair_list = $LMATCH }
 /\s*=\s*/
 /[^,\n]+/ -> pair_list { $pair_list = $LMATCH }
```

What this means:
- the rule does not repeat individual alternatives,
- it repeats the whole ordered sequence,
- and the returned collected value is grouped by full sequence iteration rather than flattened as one repeated-choice stream.

### Example: two-to-four repeated BEGIN/END marker groups

```text
segments:AND{2,4}
 /BEGIN\b/ -> segments { $segments = $LMATCH }
 /.*?\n/
 /END\b/   -> segments { $segments = $LMATCH }
```

What this means:
- fewer than two full `BEGIN ... END` groups fail the rule,
- two, three, or four full groups pass,
- and the fifth possible group is left for later parsing because this rule has already reached its configured maximum.

### Example: zero-to-two optional sequence groups

```text
optional_assignments:AND{,2}
 /[A-Za-z_]\w*/ -> optional_assignments { $optional_assignments = $LMATCH }
 /\s*=\s*/
 /[^,\n]+/ -> optional_assignments { $optional_assignments = $LMATCH }
```

What this means:
- zero full sequence groups are acceptable,
- one or two full groups are also acceptable,
- but the rule will not keep consuming beyond two complete ordered groups.

### Example: explicit open-ended repeated sequence shorthand

```text
assignment_stream:AND+
 /[A-Za-z_]\w*/ -> assignment_stream { $assignment_stream = $LMATCH }
 /\s*=\s*/
 /[^,\n]+/ -> assignment_stream { $assignment_stream = $LMATCH }
```

What this means:
- the whole ordered sequence must succeed at least once,
- after the first full sequence group it keeps repeating the same ordered-sequence contract,
- and this is the shorthand grouped spelling for the same family as `AND{1,}`.

## Blind Calls: Direct Rule Invocation with `=>`
Blind calls are the other rule-body edge family.

They look like this:

```text
=> child_rule
```

and they mean something different from:

```text
-> child_rule
```

The short version is:
- `-> child_rule` is regex-slot oriented,
- `=> child_rule` is parser-step oriented.

### What `=> child_rule` does
When a rule uses blind calls, the parent rule is not selecting one of its own regex entry slots for that step.

Instead, it directly invokes another rule as a parser step and works with that child rule's result.

That is why blind calls are useful for wrapper and orchestration rules.

Representative shape:

```text
record:AND
 => header
 => body
 => trailer
```

The practical reading is:
- first call `header`,
- then call `body`,
- then call `trailer`,
- and treat the parent rule as the composition shell around those child parsers.

### Post-call processing after `=> child_rule`
Blind calls can also postprocess the AST/value returned by the child call.

These supported forms now all belong to the blind-call surface:
- `=> child_rule`
- `=> child_rule { ... }`
- `=> child_rule.method(...)`
- `=> child_rule .method(...).method2(...)`

The semantic center is still the same:
- first do `call(child_rule)`,
- store that child result as the current blind-call entry,
- then run any attached block or fluent post-call steps against that current entry.

So a fluent blind-call chain is now explicit sugar for post-call processing that would otherwise live in a block.

Example:

```text
wrapper::AND
 => child .return(array("?wrapper:", array_copy(array(wrapper))))
```

is equivalent in lowered meaning to:

```text
wrapper::AND
 => child { return(array("?wrapper:", array_copy(array(wrapper)))) }
```

The same idea extends to longer chains:
- `=> child .m1(...).m2(...)`
- means “call `child`, then run `m1(...)`, then run `m2(...)` on the current blind-call entry”.

### `-> child_rule` versus `=> child_rule`
This distinction is worth keeping very explicit.

`-> child_rule` means:
- let the enclosing rule select through its action-edge matcher,
- using the regex slot declared by `child_rule` (slot zero when no index is written),
- and run this edge's action with that selected match.

`=> child_rule` means:
- invoke `child_rule` directly as a parser step,
- without treating this step as one of the current rule's own regex-slot action edges.

That is why blind calls feel more like parser orchestration than regex-slot dispatch.

### One Rule Should Use One Edge Family
One current contract rule is strict:
- do not mix `-> ...` action edges and `=> ...` blind calls inside the same rule.

This is invalid today:

```text
bad_rule:
 /.../
 -> child_a
 => child_b
```

Use one style or the other for a given rule body.

Current frontend validation now rejects that mixed rule shape before bootstrap parse on both:
- multiline rule paragraphs,
- and same-line packed rule paragraphs.

### Why Mixing `->` And `=>` Is A Bad Fit
This rule is not just stylistic.

The two edge families describe two different execution models.

`-> child_rule` means:
- this rule is driven by action-edge selection,
- the named target rule and optional index identify the regex slot to select,
- and the enclosing rule runs the corresponding action after that target slot matches.

`=> child_rule` means:
- this rule is acting as a composition shell,
- the parent directly invokes another parser step,
- and the child rule, not the parent regex list, is doing the real match work for that step.

Blind calls do not use regex-slot indexing:
- `=> child_rule` is valid,
- `=> { ... }` is invalid because a blind call must still name a child rule,
- `=> child_rule-extra` is invalid because blind-call targets stay plain word rule names,
- `=> child_rule[0]` is invalid,
- and regex-slot selection stays on the action-edge side as `-> child_rule[idx]`.

So if one rule mixes both families, several semantic questions become muddy very quickly:
- is the rule mainly regex-slot driven or parser-call driven?
- what is supposed to own input progress at that point: the parent regex slot or the child parser?
- what should repeated grouping mean when one step is a local regex dispatch and the next step is a direct child-rule call?
- what should the parent return shape mean when part of the rule is edge-following and part of it is direct orchestration?

That is why the current contract stays strict:
- one rule, one execution model.

If the rule is mainly selecting explicitly targeted regex slots, use `->`.

If the rule is mainly orchestrating child parsers as building blocks, use `=>`.

That division keeps the authoring model easier to read, the runtime handler families simpler, and the resulting parser behavior much less surprising.

### Best Current Blind-Call Shapes
The most clearly documented blind-call shapes today are:
- ordered-sequence wrappers,
- repeated ordered-sequence wrappers,
- and single-choice wrappers.

#### Ordered sequence wrapper

```text
record:&
 => header
 => body
 => trailer
```

or, spelled out:

```text
record:AND
 => header
 => body
 => trailer
```

This is the cleanest blind-call authoring pattern today.

It is a good fit when:
- each child rule already owns its own anchors and local parsing,
- and the parent rule exists mainly to say “these child parsers must succeed in this order.”

#### Repeated ordered-sequence wrapper

```text
chunk_stream:AND+
 => chunk_header
 => chunk_body
```

or with bounds:

```text
chunk_stream:AND{2,4}
 => chunk_header
 => chunk_body
```

This is the natural continuation of the sequence-wrapper family when the whole blind-call sequence should repeat as one group.

#### Single-choice wrapper

```text
atom:|
 => quoted_string
 => integer_literal
 => bare_identifier
```

This is the cleanest blind-call choice pattern today.

It is a good fit when:
- the parent rule is really a wrapper around several child parsers,
- the children already know how to parse themselves,
- and the parent just needs to try them in order and keep the first one that succeeds.

### Why Blind Calls Exist
Blind calls make the most sense when the parent rule is mainly composition logic.

That happens in patterns like:
- wrapper rules,
- staged outer orchestration,
- and coarse-to-fine parsing where child rules own the real local anchors.

Do not call this blind-call surface “super split.” The historical term refers to automatic
inter-match gap capture in repeated OR/default rules with action edges, described below. It is not a
blind-call mode.

Representative staged-orchestration sketch:

```text
segment_pass:AND
 => segment_open
 => segment_payload
 => segment_close
```

The point of that shape is not that the parent has its own rich regex story.

The point is that:
- `segment_open`, `segment_payload`, and `segment_close` already know how to parse their own anchored regions,
- and the parent rule exists to compose those parser steps into one coarser result.

That makes blind-call useful for the kind of multi-pass extraction workflow where you first isolate chunks and then parse those chunks more deeply in a second pass.

### Repeated-Choice Blind Calls
Repeated-choice blind-call is now part of the supported current surface too.

One important design point is already clear, though:
- blind-call does **not** implicitly switch a rule into ordered-sequence behavior,
- `=> child_rule` only says “compose by calling child parsers as parser steps,”
- and the rule label still decides whether those steps are composed as sequence, choice, or repeated choice.

So:
- if you want sequential orchestration, say it explicitly with `:&`, `:AND`, `:AND+`, or `:AND{...}`,
- if you want wrapper choice, say it explicitly with `:|`,
- and do not treat bare `rule:` with blind calls as meaning “AND by default.”

So the current guidance is:
- if you want blind-call orchestration, prefer the ordered-sequence blind-call family (`:&`, `:AND`, `:AND+`, `:AND{...}`),
- if you want one wrapper choice among child parsers, prefer `:|`,
- and if you want repeated-choice blind-call behavior, prefer the explicit `:OR`, `:OR+`, or `:OR{...}` spellings when you want to make that intent obvious at a glance.

The repeated-choice blind-call family now means:
- bare `rule:` with `=> child_rule` follows the repeated-choice baseline,
- `rule:OR` is the explicit worded repeated-choice blind-call spelling,
- `rule:OR+` is the explicit shorthand repeated-choice blind-call spelling,
- `rule:OR{...}` is the bounded repeated-choice blind-call spelling,
- and `rule:+` stays the compact one-or-more repeated-choice spelling.

Representative repeated-choice blind-call shape:

```text
chunk_stream:OR
 => chunk_header
 => chunk_body
 => chunk_footer
```

That means:
- on each iteration, try the child rules in order,
- keep the first child parser that succeeds for that iteration,
- collect that child result,
- then repeat until no child parser succeeds or the rule hits its upper bound.

Worked bounded/shorthand examples:

```text
entry_stream:+
 => header_line
 => body_line
```

This means:
- run one-or-more repeated-choice iterations,
- each iteration picks the first child parser that succeeds,
- and the rule fails if even the first iteration cannot find a successful child.

```text
pair_or_triplet:OR{2,3}
 => digit_pair
 => hex_pair
```

This means:
- at least two successful child-choice iterations are required,
- at most three successful child-choice iterations are collected,
- and if only one child-choice iteration succeeds, the whole rule fails.

```text
optional_prefixes:OR{,2}
 => plus_prefix
 => minus_prefix
```

This means:
- zero, one, or two successful child-choice iterations are allowed,
- the standalone rule may legitimately return an empty collection,
- but a repeated parent rule will now stop cleanly instead of looping forever if such an optional child succeeds without advancing the input.

So repeated-choice blind-call is real supported surface now, even if `:AND` and `:|` are still often the clearest starting points for day-to-day authoring.

## What Is Still Deferred
There is no extra shorthand in this immediate rule-mode family still waiting to land.

The remaining deferred work is broader grouped-rule exploration that should only move when real authoring needs justify it, not because the DSL needs every possible combinator spelling up front.

## Historical “Super Split”: Inter-Match Gap Capture

The original split-like feature belongs to a repeated OR/default rule with action edges. The target
rule owns the regexes and retains its lifecycle/code; the enclosing rule refers to target slots and
receives the otherwise unmatched text before each selected match.

The ownership shape is:

```text
Document:
 /HEADER[^\n]*/
 /SECTION[^\n]*/
 /FOOTER[^\n]*/
 I {
   return(hash("text", entry_text()))
 }

Top::OR
 @move_pos
 -> Document[0] { ... }
 -> Document[1] { ... }
 -> Document[2] { ... }
```

`Document[0]`, `Document[1]`, and `Document[2]` identify the regex slots declared by `Document`.
`Document` without an index is the slot-zero compatibility form. A regex written immediately before
an action edge does not trigger or qualify that edge; inline same-rule forms that appear elsewhere in
this guide are compact paragraph layouts, not an adjacency relationship.

On the Perl reference, `@move_pos` enables this repeated sequence:

1. select the next action edge from its named target rule/slot;
2. expose the exact source text from the rolling boundary to that match's left edge through the
   historical `$CAPTURE` channel and current capture helpers;
3. run the selected edge action, which may call the target and receive its lifecycle result;
4. update the rolling boundary to the parser cursor after the action;
5. repeat.

The current reference exposes entry-to-first-match prefix text and interstitial gaps. It does not
automatically expose the final tail after the last match because no next match triggers another
action. Trimming, conditional storage, and result shape belong to action code; the mechanism does not
force one AST layout.

ADR `0045` adopts **inter-match gap capture** as the formal concept, **lossless segmentation** as the
broader model, and `@capture_gaps` as the accepted future backend-neutral directive. That spelling is
not implemented. Its executable contract must still decide exact prefix, tail, empty-span,
failure/backtracking, recursion, typed-span, diagnostic, and compatibility behavior after the active
rule-local cursor rollout completes.

The same future contract also has ratified terse named regex slots:

```text
Document:
 header=/HEADER[^\n]*/
 section = /SECTION[^\n]*/
 footer= /FOOTER[^\n]*/
 I {
   return(hash("kind", entry_slot(), "text", entry_text()))
 }

Top::OR
 @capture_gaps
 -> Document[header]  { ... }
 -> Document[section] { ... }
 -> Document[footer]  { ... }
```

Horizontal whitespace around `=` is insignificant. At rule-paragraph level this form declares a
stable rule-local regex slot; it is not mutable assignment. Named selectors avoid declaration-order
magic numbers, while existing unindexed/numeric selectors remain compatibility forms. Neither the
named declaration/selector nor the illustrative `entry_slot()` accessor is implemented; the accessor
name remains executable-contract work.

## `@capture_slice`: The Legacy Split Boundary Marker
On the Perl reference, `@capture_slice` is the preferred alias for the legacy split-boundary marker.

Older spellings `@capture_from_here` and `@move_pos` are still supported as compatibility aliases.

There is also a named checkpoint form:
- `@mark(name)`

On Perl, that named form is guarded by the preceding regex index and stores the current parser
position under `name` so later `capture_from(name)` and `capture_len_from(name)` calls can read the
current-edge span that starts at that checkpoint.

It is easy to misunderstand what it does, so here is the precise version:
- it does not collect text by itself,
- it does not return an AST node by itself,
- it advances the capture-start cursor used by later `$CAPTURE`-style span extraction.

For the historical repeated-action use, the directive lowers to rule-level local-end code and rolls
after each successful action; it is not attached to the nearest regex or edge by textual adjacency.
The later explicit helpers such as `start_capture_slice()` also let action/lifecycle code move the
same anonymous boundary manually. Those generalized helpers are useful, but they do not redefine the
original inter-match gap feature.

Do not assume marker-member parity across backends. Lua/LuaJIT later implemented all anonymous and
named marker members as preceding-regex-slot events. Rust drops parsed markers from native compiled
state; Dart and Julia preserve them as source body data but do not execute them natively. Explicit
helpers such as `start_capture_slice()` and `mark_here(name)` are separate contracts and are the clear
choice when timing must be portable. ADR `0045` leaves legacy reconciliation to the executable
`@capture_gaps` contract.

In compiler terms, it lowers to:

```text
$IPOS = pos $$STRING
```

That means:
- before `@capture_slice`, a later capture starts from the earlier rule-entry boundary,
- after `@capture_slice`, a later capture starts from the point where the parser had already advanced,
- so the next capture becomes “text since the last anchor” instead of “text since the beginning of the rule.”

That is why it is useful for split-like staged parsing.

There is now also a small explicit helper family for the same anonymous boundary:
- `capture_slice()` reads the current anonymous slice text up to the left edge of the current local match,
- `capture_slice_len()` reads the width of that same slice,
- `capture_slice_until_cursor()` reads from that same anonymous boundary through the live parser cursor,
- `capture_slice_until_cursor_len()` reads the width of that same anonymous through-cursor span,
- `capture_take_until_cursor()` reads that same anonymous through-cursor span and then advances the boundary to the live parser cursor,
- `capture_take_until_cursor_len()` reads the width of that same anonymous through-cursor span and then advances the boundary to the live parser cursor,
- `capture_take_len()` reads the width of that same anonymous current-edge span and then advances the boundary to the current parser position,
- `capture_take_rest()` reads that same anonymous boundary through end-of-input and then advances the boundary to end-of-input,
- `capture_take_rest_len()` reads the width of that same anonymous tail and then advances the boundary to end-of-input,
- `capture_slice_pos()` reads the numeric position where that same slice starts,
- `capture_slice_line()` reads the 1-based line number where that same anonymous slice starts,
- `capture_slice_col()` reads the 1-based column number where that same anonymous slice starts,
- `start_capture_slice()` moves that anonymous boundary explicitly from inside lifecycle or action code,
- `capture_take()` reads that same anonymous-boundary span and then advances the boundary to the current parser position,
- `capture_rest()` / `capture_rest_len()` read from that anonymous boundary through end-of-input,
- and `cursor_rest()` / `cursor_rest_len()` read from the live parser cursor through end-of-input.

That means the current Perl anonymous-boundary mental model is:
- `@capture_slice` enables rule-level post-action rolling at paragraph level,
- `start_capture_slice()` moves it inside code blocks,
- `capture_slice()` / `capture_slice_len()` / `capture_slice_until_cursor()` / `capture_slice_until_cursor_len()` / `capture_slice_pos()` / `capture_slice_line()` / `capture_slice_col()` read metadata or text about the current slice,
- `capture_take_until_cursor()` reads the current anonymous through-cursor span and also advances that anonymous boundary,
- `capture_take_until_cursor_len()` reads the width of that same current anonymous through-cursor span and also advances that anonymous boundary,
- `capture_take_len()` reads the width of that same current anonymous current-edge span and also advances that anonymous boundary,
- `capture_take_rest()` reads the current anonymous tail through end-of-input and also advances that anonymous boundary to end-of-input,
- `capture_take_rest_len()` reads the width of that same current anonymous tail and also advances that anonymous boundary to end-of-input,
- `capture_take()` reads the current slice and also advances that anonymous boundary,
- `capture_rest()` / `capture_rest_len()` read the remaining tail from that same boundary,
- and `cursor_rest()` / `cursor_rest_len()` answer the different question “what remains from the live parser cursor right now?” without consulting that anonymous boundary.

## Why `@capture_slice` Matters
This feature is especially useful when:
- the full structure is awkward to parse in one pass,
- but the file has reliable anchors,
- and you want to extract raw inner chunks first and parse them in a second pass.

That is a real LinkedSpec strength:
1. use stable outer anchors to capture coarse segments,
2. build a first-level AST that preserves those raw substrings,
3. parse those substrings with a second `.spec` or another follow-up parser.

This is exactly the kind of coarse-to-fine workflow LinkedSpec is good at.

## Worked Example: Advancing Anonymous Boundary
Sometimes a rule does not need a named checkpoint at all. It only needs one rolling anonymous boundary that should move forward after each captured segment.

That is what `capture_take()` is for.

```text
csv_triplet_anon::AND
 I { declare(scalar, first, second) }
 /foo\(/
 /alpha/
 /,\s*(?=beta)/
 /beta/
 /,\s*(?=gamma)/
 /gamma/
 /\)/
 -> csv_triplet_anon[0] { start_capture_slice() }
 -> csv_triplet_anon[2] { assign(scalar(first), capture_take()) }
 -> csv_triplet_anon[4] { assign(scalar(second), capture_take()) }
 -> csv_triplet_anon[6] { return(array("?csv_triplet_anon:", scalar(first), scalar(second), capture_slice())) }
```

On input:

```text
foo(alpha, beta, gamma)
```

the practical reading is:
- `start_capture_slice()` stores the anonymous boundary just after `(`,
- the first `capture_take()` returns `alpha` and advances that anonymous boundary to just after the first comma,
- the second `capture_take()` returns `beta` and advances that anonymous boundary to just after the second comma,
- the final `capture_slice()` returns `gamma` from the advanced anonymous boundary through the left edge of `)`,
- and no named checkpoint is needed because the whole rule only uses one rolling capture boundary.

This is the anonymous advancing-boundary pattern:
- `capture_slice()` is the stable anonymous read,
- `capture_take_until_cursor()` is the advancing anonymous read that includes everything through the live parser cursor,
- `capture_take()` is the advancing anonymous read,
- and `start_capture_slice()` is the explicit anonymous-boundary write when the rule wants to establish or reset that rolling boundary directly.

## Worked Example: Advancing Through-Cursor Reads
Sometimes the rule wants the right edge to be the live parser cursor, not the left edge of the current match, and it still wants that boundary to roll forward afterward.

That is what `capture_take_until_cursor()` and `capture_take_until_cursor_from(name)` are for.

```text
advancing_through_cursor::AND
 I { declare(scalar, anon_first, named_first) }
 /\(/
 @mark(named_start)
 -> advancing_through_cursor[0] { start_capture_slice() }
 /\w+/
 -> advancing_through_cursor[1] { assign(scalar(anon_first), capture_take_until_cursor()); assign(scalar(named_first), capture_take_until_cursor_from(named_start)) }
 /,\s*/
 /\w+/
 -> advancing_through_cursor[3] { return(array("?advancing_through_cursor:", scalar(anon_first), scalar(named_first), capture_take_until_cursor(), capture_take_until_cursor_from(named_start))) }
```

On input:

```text
(alpha, beta)
```

the practical reading is:
- `start_capture_slice()` establishes the anonymous left edge just after `(`,
- `@mark(named_start)` establishes the named left edge at that same position,
- the first `capture_take_until_cursor()` returns `alpha` and advances the anonymous boundary to just after `alpha`,
- the first `capture_take_until_cursor_from(named_start)` also returns `alpha` and advances `named_start` to just after `alpha`,
- the second calls then both return `, beta` because the right edge is the live parser cursor after `beta`,
- and both boundary models are now rolled forward to the current cursor rather than left at the earlier start point.

This is the through-cursor advancing pattern:
- `capture_slice_until_cursor()` is the stable anonymous through-cursor read,
- `capture_take_until_cursor()` is the advancing anonymous through-cursor read,
- `capture_until_cursor_from(name)` is the stable named through-cursor read,
- and `capture_take_until_cursor_from(name)` is the advancing named through-cursor read.

## Worked Example: Bridging Anonymous and Named Boundaries
Sometimes a rule starts with one anonymous rolling capture boundary, but later realizes that one of those anonymous positions should survive under a stable explicit name.

That is what `mark_capture_slice(name)` and `start_capture_slice_from(name)` are for.

```text
bridge_anon_and_named::AND
 I { declare(scalar, first, second) }
 /foo\(/
 /alpha/
 /,\s*(?=beta)/
 /beta/
 /,\s*(?=gamma)/
 /gamma/
 /\)/
 -> bridge_anon_and_named[0] { start_capture_slice() }
 -> bridge_anon_and_named[2] { mark_capture_slice(body_start); assign(scalar(first), capture_take()) }
 -> bridge_anon_and_named[4] { assign(scalar(second), capture_take()); start_capture_slice_from(body_start) }
 -> bridge_anon_and_named[6] { return(array("?bridge_anon_and_named:", scalar(first), scalar(second), capture_slice())) }
```

On input:

```text
foo(alpha, beta, gamma)
```

the practical reading is:
- `start_capture_slice()` stores the anonymous boundary just after `(`,
- `mark_capture_slice(body_start)` copies that anonymous boundary into the stable named mark `body_start`,
- the two `capture_take()` calls advance the anonymous boundary forward across `alpha` and `beta`,
- `start_capture_slice_from(body_start)` restores the anonymous boundary back to the remembered `body_start`,
- and the final `capture_slice()` returns `alpha, beta, gamma`.

This is the anonymous/named bridge pattern:
- `mark_capture_slice(name)` promotes the current anonymous boundary into a stable named checkpoint,
- `start_capture_slice_from(name)` restores that stored named checkpoint back into the anonymous rolling-boundary slot,
- and together they let one rule move between “one rolling anonymous boundary” and “one stable explicit checkpoint” without raw `$IPOS` plumbing.

## Real In-Tree Example
A real current example already exists in [`specs/ebnf.spec`](specs/ebnf.spec):

```text
logging_annotation: /@((?:log|debug|trace|benchmark|profile|timing)_\w+)\s*\(\s*/ /\s*\)/ I {declare(scalar, logging_name=entry_group(0)); start_capture_slice()}

-> quoted_string {
  push(quoted_string, 1);
  start_capture_slice()
}
-> comma {
  push_nonempty(array(logging_annotation), trim(capture_slice()));
  start_capture_slice()
}
-> logging_annotation[1] {
  push_nonempty(array(logging_annotation), trim(capture_slice()));
  return(array("logging_annotation", array(scalar(logging_name), array_copy(array(logging_annotation)))))
}
```

Why that shape matters:
- the outer anchors find the logging annotation and its closing `)`,
- `start_capture_slice()` moves the capture baseline forward after the opener and after each consumed argument/separator,
- later capture logic can treat only the unconsumed content between anchors as a meaningful span,
- and the rule builds a structured result without mutating `$IMATCH` or returning a bare host-language array literal.

If you are reading older specs or older notes, this may still appear as `@capture_from_here` or `@move_pos`. Those legacy spellings still work and lower to the same internal `MOVE_POS` event.

## `@mark(name)`: Named Checkpoints
`@mark(name)` is the first named checkpoint surface in the capture/mark API.

In compiler terms, it lowers to:

```text
if ($$minfo{index} == slot_idx) {
  $$info{marks}{'current_rule'}{'name'} = pos $$STRING
}
```

That means:
- it does not capture text by itself,
- it records the current parser position under a stable name,
- the name is scoped to the current rule label,
- and later `capture_from(name)`, `capture_len_from(name)`, or `capture_take(name)` in that same rule can recover information about the span that starts at that named point.

The most important semantic detail is this:
- `capture_from(name)` returns text from the saved mark up to the left edge of the current match,
- it does not include the current local match itself,
- `capture_from(name)` is a pure read and does not move the mark,
- `capture_len_from(name)` returns the numeric length of that same current-edge span without materializing the substring,
- `capture_until_cursor_from(name)` returns text from the saved mark through the live parser cursor instead of stopping at the current match edge,
- `capture_until_cursor_len_from(name)` returns the numeric width of that same named-mark through-cursor span,
- `capture_take_until_cursor_from(name)` returns that same named-mark through-cursor span and then advances the named mark to the current parser position,
- `capture_take_until_cursor_len_from(name)` returns the numeric width of that same named-mark through-cursor span and then advances the named mark to the current parser position,
- `capture_take(name)` returns that same span and then advances the named mark to the current parser position,
- `capture_rest_from(name)` returns text from the saved mark through end-of-input instead of stopping at the current match edge,
- `capture_rest_len_from(name)` returns the numeric width of that same remembered tail through end-of-input,
- `capture_between(start_mark, end_mark)` returns text between two explicit named checkpoints without using the current match edge as the right boundary,
- `capture_len_between(start_mark, end_mark)` returns the numeric length of that same explicit two-mark span without materializing the substring,
- `capture_take_between_len(start_mark, end_mark)` returns the numeric width of that same explicit two-mark span and then advances the start mark to the stored end mark,
- `capture_take_between(start_mark, end_mark)` returns that same explicit two-mark span and then advances `start_mark` to the stored `end_mark`,
- `mark_here(name)` updates the named mark to the current parser position without first reading a span from it,
- `mark_match_start(name)` updates the named mark to the left edge of the current match instead of to the current parser position,
- `mark_copy(target_mark, source_mark)` copies one explicit named checkpoint into another and clears the target if the source is absent,
- `clear_mark(name)` removes that named mark from the current rule-local mark bucket,
- `mark_exists(name)` reports whether that named mark is currently present in the current rule-local mark bucket,
- `mark_pos(name)` returns the stored numeric position of that named mark from the current rule-local mark bucket,
- `entry_text()` returns the current immediate match text directly without storing or reading a named mark first,
- `entry_group(index)` returns one capture group from the current immediate match directly without storing or reading a named mark first,
- `entry_groups()` snapshots the whole current immediate-match capture-group list directly without storing or reading a named mark first,
- `entry_named(name)` returns one named capture from the current immediate match directly without storing or reading a named mark first,
- `entry_len()` returns the width of the current immediate match directly without storing or reading a named mark first,
- `entry_start_pos()` returns the left edge of the current immediate match directly without storing or reading a named mark first,
- `entry_end_pos()` returns the right edge of the current immediate match directly without storing or reading a named mark first,
- `match_text()` returns the current local match text directly without storing or reading a named mark first,
- `match_group(index)` returns one capture group from the current local match directly without storing or reading a named mark first,
- `match_groups()` snapshots the whole current local-match capture-group list directly without storing or reading a named mark first,
- `match_named(name)` returns one named capture from the current local match directly without storing or reading a named mark first,
- `match_len()` returns the width of the current local match directly without storing or reading a named mark first,
- `match_start_pos()` returns the left edge of the current local match directly without storing or reading a named mark first,
- `match_end_pos()` returns the right edge of the current local match directly without storing or reading a named mark first,
- so a later regex slot in the same rule usually acts as the right delimiter of the captured span.

In high/debug trace mode, mark writes now also show where that checkpoint lands inside the input:
- `@mark(name)`, `mark_here(name)`, `mark_entry_start(name)`, `mark_entry_end(name)`, `mark_match_start(name)`, `mark_match_end(name)`, `mark_copy(target_mark, source_mark)`, `mark_capture_slice(name)`, and the advancing writes inside `capture_take(name)` and `capture_take_between(start_mark, end_mark)` emit a short visible excerpt of the input string,
- and the trace prints a caret on the next line under the stored checkpoint position,
- so you can see immediately whether the rule stored a post-match parser position or the left edge of the current match.

That means the usual authoring shape is:
- match an opening anchor,
- set `@mark(name)`,
- keep matching forward,
- then on a later closing delimiter or separator in that same rule call `capture_from(name)` if the mark should stay stable,
- or call `capture_len_from(name)` if the rule should read the numeric width of that same current-edge span instead of the substring itself,
- or call `capture_take(name)` if the mark should roll forward like a named split cursor,
- or call `capture_between(start_mark, end_mark)` if both edges should come from explicit named checkpoints,
- or call `capture_len_between(start_mark, end_mark)` if the rule should read the numeric width of that same explicit two-mark span instead of the substring itself,
- or call `capture_take_between(start_mark, end_mark)` if that explicit two-mark span should also advance the start mark to the remembered end mark,
- or call `mark_here(name)` if a later action block should move the named checkpoint explicitly without bundling the write into the read,
- or call `mark_match_start(name)` if a later action block should remember where the current match begins instead of where it ends,
- or call `mark_copy(target_mark, source_mark)` if a later action block should copy one remembered boundary into another named checkpoint explicitly,
- or call `clear_mark(name)` if the named checkpoint should stop being visible to later same-rule reads,
- or call `mark_exists(name)` if a later action block should branch on whether the named checkpoint is still present,
- or call `mark_pos(name)` if a later action block should expose the stored numeric checkpoint position itself,
- or call `entry_text()` if the rule should expose the entry/immediate match that led into the rule without first round-tripping through a named mark,
- or call `entry_group(index)` if the rule should expose one capture group from that same entry/immediate match without first round-tripping through a named mark,
- or call `entry_groups()` if the rule should expose the whole capture-group list from that same entry/immediate match without first round-tripping through a named mark,
- or call `entry_named(name)` if the rule should expose one named capture from that same entry/immediate match without first round-tripping through a named mark,
- or call `entry_len()` if the rule should expose the width of that same entry/immediate match without first round-tripping through a named mark,
- or call `entry_start_pos()` / `entry_end_pos()` if the rule should expose the entry/immediate match boundaries that led into the rule without first round-tripping through a named mark,
- or call `match_text()` if the current local match text itself should be returned as data without first round-tripping through a named mark,
- or call `match_group(index)` if one capture group from that same current local match should be returned as data without first round-tripping through a named mark,
- or call `match_groups()` if the whole capture-group list from that same current local match should be returned as data without first round-tripping through a named mark,
- or call `match_named(name)` if one named capture from that same current local match should be returned as data without first round-tripping through a named mark,
- or call `match_len()` if the width of that same current local match should be returned as data without first round-tripping through a named mark,
- or call `match_start_pos()` / `match_end_pos()` if the current local match boundaries themselves should be returned as data without first round-tripping through a named mark.

## Mark Timing: Later Slot, Not Same Slot
There is one timing rule that matters a lot in practice:

- `@mark(name)` becomes visible after the regex slot that carries it completes,
- so an action on that same slot should not expect the new mark yet,
- if you want to use the mark, do it from a later regex slot in the same rule,
- child rules do not inherit that named mark automatically.

That follows the current lowering shape:
- the mark lowers into `LECODE`,
- and `LECODE` is a later phase than the action attached to that same slot.

## Worked Example: Same-Rule Delimited Capture
This is the clearest safe checkpoint example today:

```text
semantic_chunk::AND
 I { declare(scalar, stage) }
 /foo\(/
 @mark(body_start)
 /\w+/
 /\)/
 -> semantic_chunk[0] { assign(scalar(stage), "open") }
 -> semantic_chunk[1] { assign(scalar(stage), "body") }
 -> semantic_chunk[2] { return(array("?semantic_chunk:", capture_from(body_start))) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- `/foo\(/` matches the stable opening anchor,
- `@mark(body_start)` remembers the start of the inner span,
- `/\w+/` consumes the inner content,
- `/\)/` is the right delimiter,
- `capture_from(body_start)` returns `bar`.

This is the easiest checkpoint pattern to teach:
- the rule owns the left boundary,
- the later slot in that same rule owns the right boundary,
- and the captured text is the span between them.

## Worked Example: Same-Rule Separator Capture
The current match does not have to be a closing delimiter. A separator works too.

```text
left_item::AND
 I { declare(scalar, stage) }
 /\(/
 @mark(left_start)
 /[^,]+/
 /,/
 -> left_item[0] { assign(scalar(stage), "open") }
 -> left_item[1] { assign(scalar(stage), "content") }
 -> left_item[2] { return(array("?left_item:", capture_from(left_start))) }
```

On input shaped like:

```text
(alpha,beta)
```

the current match at the final comma slot is the comma. That means `capture_from(left_start)` returns the text before the comma, not including the comma itself.

This is the key generalization:
- the current match acts as the right edge,
- not only closing delimiters,
- but any later separator or anchor slot in the same rule can play that role.

## Worked Example: Advancing Named Capture
Sometimes a stable named checkpoint is not enough. In repeated separator-style parsing, you often want to read the current span and then move the named checkpoint forward so the next capture starts after the current separator.

That is what `capture_take(name)` does.

```text
csv_triplet::AND
 I { declare(scalar, stage, first, second) }
 /foo\(/
 @mark(body_start)
 /alpha/
 /,\s*(?=beta)/
 /beta/
 /,\s*(?=gamma)/
 /gamma/
 /\)/
 -> csv_triplet[0] { assign(scalar(stage), "open") }
 -> csv_triplet[1] { assign(scalar(stage), "first_value") }
 -> csv_triplet[2] { assign(scalar(first), capture_take(body_start)) }
 -> csv_triplet[3] { assign(scalar(stage), "second_value") }
 -> csv_triplet[4] { assign(scalar(second), capture_take(body_start)) }
 -> csv_triplet[5] { assign(scalar(stage), "third_value") }
 -> csv_triplet[6] { return(array("?csv_triplet:", scalar(first), scalar(second), capture_from(body_start))) }
```

On input:

```text
foo(alpha, beta, gamma)
```

the practical reading is:
- the first `capture_take(body_start)` returns `alpha` and moves `body_start` to just after the first comma,
- the second `capture_take(body_start)` returns `beta` and moves `body_start` to just after the second comma,
- the final `capture_from(body_start)` returns `gamma` without moving the mark again.

This is the named split-cursor pattern:
- `capture_from(name)` is the stable read,
- `capture_take(name)` is the advancing read.

## Worked Example: Named Tail Through End Of Input
Sometimes the left edge should come from a remembered named checkpoint, but the right edge should be the real end of the input string rather than the current match boundary.

That is what `capture_rest_from(name)` and `capture_rest_len_from(name)` are for.

```text
tail_from_named_mark::AND
 I { declare(scalar, stage) }
 /\(/
 @mark(body_start)
 /\w+/
 /\)/
 -> tail_from_named_mark[0] { assign(scalar(stage), "open") }
 -> tail_from_named_mark[1] { assign(scalar(stage), "body") }
 -> tail_from_named_mark[2] { return(array("?tail_from_named_mark:", capture_rest_from(body_start), capture_rest_len_from(body_start))) }
```

On input:

```text
(bar)
```

the practical reading is:
- `@mark(body_start)` stores the position just after `(`,
- `capture_rest_from(body_start)` returns `bar)` because its right edge is end-of-input, not the left edge of the current `)` match,
- and `capture_rest_len_from(body_start)` returns `4` for that same remembered tail.

This is the named-tail pattern:
- `capture_from(name)` stops at the current match edge,
- `capture_rest_from(name)` goes through end-of-input,
- `capture_len_from(name)` reports the width of the current-edge span,
- `capture_rest_len_from(name)` reports the width of the end-of-input tail from the same named checkpoint.

## Worked Example: Live Cursor Tail Through End Of Input
Sometimes the left edge should not come from an anonymous capture boundary or a named mark at all. The rule may simply want to ask what remains from the live parser cursor right now.

That is what `cursor_rest()` and `cursor_rest_len()` are for.

```text
tail_from_cursor::AND
 I { declare(scalar, after_open_tail, after_body_tail) }
 /foo\(/
 /\w+/
 /\)/
 -> tail_from_cursor[0] { assign(scalar(after_open_tail), cursor_rest()) }
 -> tail_from_cursor[1] { assign(scalar(after_body_tail), cursor_rest()) }
 -> tail_from_cursor[2] { return(array("?tail_from_cursor:", scalar(after_open_tail), scalar(after_body_tail), cursor_rest(), cursor_rest_len())) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- after `/foo\(/`, the live parser cursor is just after `(`, so `cursor_rest()` returns `bar)`,
- after `/\w+/`, the live parser cursor is just after `bar`, so `cursor_rest()` returns `)`,
- after `/\)/`, the live parser cursor is at end-of-input, so `cursor_rest()` returns the empty string and `cursor_rest_len()` returns `0`,
- and none of those reads depend on `@capture_slice`, `start_capture_slice()`, or `@mark(name)` because the left edge is always the live parser cursor itself.

This is the live-cursor-tail pattern:
- `capture_rest()` goes from the anonymous capture boundary through end-of-input,
- `capture_rest_from(name)` goes from a named checkpoint through end-of-input,
- `cursor_rest()` goes from the live parser cursor through end-of-input,
- and `cursor_rest_len()` is the numeric width companion to that same live-cursor tail.

## Worked Example: Explicit Two-Mark Span
Sometimes the right edge should not come from the current match at all. Instead, the rule may want to remember a second explicit checkpoint and later capture the span between those two named positions.

That is what `capture_between(start_mark, end_mark)` is for.

```text
explicit_two_mark_span::AND
 I { declare(scalar, stage, first_segment) }
 /foo\(/
 @mark(body_start)
 /alpha/
 /,\s*(?=beta)/
 /beta/
 /\)/
 -> explicit_two_mark_span[0] { assign(scalar(stage), "open") }
 -> explicit_two_mark_span[1] { assign(scalar(stage), "first_value"); mark_here(first_end) }
 -> explicit_two_mark_span[2] { assign(scalar(stage), "separator"); assign(scalar(first_segment), capture_between(body_start, first_end)) }
 -> explicit_two_mark_span[3] { assign(scalar(stage), "second_value") }
 -> explicit_two_mark_span[4] { return(array("?explicit_two_mark_span:", scalar(first_segment), capture_from(body_start))) }
```

On input:

```text
foo(alpha,beta)
```

the practical reading is:
- `@mark(body_start)` stores the left edge just after `(`,
- `mark_here(first_end)` stores a second checkpoint just after `alpha`,
- `capture_between(body_start, first_end)` returns `alpha`,
- and the final `capture_from(body_start)` still returns `alpha,beta` because that helper still uses the current match edge.

This is the explicit-two-mark pattern:
- `capture_from(name)` uses one named checkpoint plus the current match edge,
- `capture_between(start_mark, end_mark)` uses two named checkpoints,
- and `mark_here(name)` is the usual way to establish the second explicit post-match right boundary.

## Worked Example: Explicit Two-Mark Span Length
Sometimes the rule wants explicit remembered boundaries, but only as width metadata rather than as a substring.

That is what `capture_len_between(start_mark, end_mark)` is for.

```text
explicit_two_mark_span_length::AND
 I { declare(scalar, stage, first_segment) }
 /foo\(/
 @mark(body_start)
 /alpha/
 /,\s*(?=beta)/
 /beta/
 /\)/
 -> explicit_two_mark_span_length[0] { assign(scalar(stage), "open") }
 -> explicit_two_mark_span_length[1] { assign(scalar(stage), "first_value"); mark_here(first_end) }
 -> explicit_two_mark_span_length[2] { assign(scalar(stage), "separator"); assign(scalar(first_segment), capture_between(body_start, first_end)) }
 -> explicit_two_mark_span_length[3] { assign(scalar(stage), "second_value") }
 -> explicit_two_mark_span_length[4] { return(array("?explicit_two_mark_span_length:", scalar(first_segment), capture_len_between(body_start, first_end), capture_len_between(body_start, missing_end))) }
```

On input:

```text
foo(alpha,beta)
```

the practical reading is:
- `capture_between(body_start, first_end)` returns `alpha`,
- `capture_len_between(body_start, first_end)` returns `5`,
- `capture_len_between(body_start, missing_end)` returns `undef` because the right boundary is absent.

This is the explicit-two-mark length pattern:
- `capture_between(start_mark, end_mark)` returns the substring,
- `capture_len_between(start_mark, end_mark)` returns the width of that same remembered-boundary span,
- and neither helper mutates the stored marks.

## Worked Example: Explicit Mark Copy After Length Read
Sometimes the rule wants a pure numeric two-mark read first, and only afterward wants to move one named checkpoint to the remembered boundary it just measured.

That is what `mark_copy(target_mark, source_mark)` is for.

```text
explicit_mark_copy::AND
 I { declare(scalar, stage, first_len) }
 /foo/
 @mark(body_start)
 /alpha/
 /beta/
 /END/
 -> explicit_mark_copy[0] { assign(scalar(stage), "open") }
 -> explicit_mark_copy[1] { assign(scalar(stage), "body") }
 -> explicit_mark_copy[2] { mark_match_start(first_end); assign(scalar(first_len), capture_len_between(body_start, first_end)); mark_copy(body_start, first_end) }
 -> explicit_mark_copy[3] { mark_match_start(final_end); return(array("?explicit_mark_copy:", scalar(first_len), capture_between(body_start, final_end), mark_copy(after_end, missing_end), mark_pos(after_end))) }
```

On input:

```text
fooalphabetaEND
```

the practical reading is:
- `capture_len_between(body_start, first_end)` returns `5`,
- `mark_copy(body_start, first_end)` advances `body_start` to the remembered `first_end` boundary without requiring a string-returning helper,
- `capture_between(body_start, final_end)` now returns `beta`,
- `mark_copy(after_end, missing_end)` clears `after_end` because the source mark is absent,
- and `mark_pos(after_end)` returns `undef`.

This is the explicit mark-copy pattern:
- pure length reads stay pure,
- `mark_copy(target_mark, source_mark)` owns explicit remembered-boundary moves,
- and missing-source copies clear the target instead of leaving stale checkpoint state behind.

## Worked Example: Explicit Two-Mark Span with Advancing Start
Sometimes the rule wants the clarity of an explicit remembered right boundary and also wants the start mark to roll forward to that remembered boundary after the read.

That is what `capture_take_between(start_mark, end_mark)` is for.

```text
explicit_two_mark_take::AND
 I { declare(scalar, stage, first_segment) }
 /foo/
 @mark(body_start)
 /alpha/
 /beta/
 /END/
 -> explicit_two_mark_take[0] { assign(scalar(stage), "open") }
 -> explicit_two_mark_take[1] { assign(scalar(stage), "body") }
 -> explicit_two_mark_take[2] { mark_match_start(first_end); assign(scalar(first_segment), capture_take_between(body_start, first_end)) }
 -> explicit_two_mark_take[3] { mark_match_start(final_end); return(array("?explicit_two_mark_take:", scalar(first_segment), capture_between(body_start, final_end))) }
```

On input:

```text
fooalphabetaEND
```

the practical reading is:
- the opening `-> explicit_two_mark_take[0]` action keeps the `/foo/` anchor inside the action-bearing sequence, so `@mark(body_start)` becomes visible at the right point for later same-rule reads,
- the next `-> explicit_two_mark_take[1]` action keeps the `/alpha/` body token inside that same explicit sequence, so the later `beta` and `END` boundaries are reached in order rather than skipping the body token entirely,
- `@mark(body_start)` stores the left edge before `alpha`,
- `mark_match_start(first_end)` stores the explicit boundary at the left edge of the `beta` match,
- `capture_take_between(body_start, first_end)` returns `alpha` and advances `body_start` to that stored `first_end` boundary,
- `mark_match_start(final_end)` stores the next explicit boundary at the left edge of the `END` match,
- `capture_between(body_start, final_end)` now returns `beta` because `body_start` already rolled forward to the stored first boundary.

This is the explicit-two-mark rolling pattern:
- `capture_between(start_mark, end_mark)` is the stable two-mark read,
- `capture_take_between(start_mark, end_mark)` is the advancing two-mark read,
- and `mark_match_start(name)` is a clean way to establish remembered left-edge boundaries for later two-mark reads.

## Worked Example: Left Edge of a Closing Match
Sometimes the right boundary should be the left edge of the current closing token, not the post-match parser position after that token.

That is what `mark_match_start(name)` is for.

```text
explicit_left_edge_end_mark::AND
 I { declare(scalar, stage) }
 /foo\(/
 @mark(body_start)
 /\w+/
 /\)/
 -> explicit_left_edge_end_mark[0] { assign(scalar(stage), "open") }
 -> explicit_left_edge_end_mark[1] { assign(scalar(stage), "body") }
 -> explicit_left_edge_end_mark[2] { mark_match_start(end_mark); mark_here(after_end); return(array("?explicit_left_edge_end_mark:", capture_between(body_start, end_mark), capture_between(body_start, after_end))) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- `mark_match_start(end_mark)` records the left edge of the current `)` match,
- `mark_here(after_end)` records the post-match parser position just after `)`,
- `capture_between(body_start, end_mark)` returns `bar`,
- `capture_between(body_start, after_end)` returns `bar)`.

This is the left-edge end-marker pattern:
- `mark_here(name)` stores post-match `pos $$STRING`,
- `mark_match_start(name)` stores `$LSPOS - length $LMATCH`,
- and `capture_between(...)` makes that distinction visible immediately.

## Worked Example: Stable Read, Explicit Advance
Sometimes the rule wants to read from a stable named checkpoint first and only then decide to move it.

That is what `mark_here(name)` is for.

```text
explicit_mark_move::AND
 I { declare(scalar, stage, first) }
 /foo\(/
 @mark(body_start)
 /alpha/
 /,\s*(?=beta)/
 /beta/
 /\)/
 -> explicit_mark_move[0] { assign(scalar(stage), "open") }
 -> explicit_mark_move[1] { assign(scalar(stage), "first_value") }
 -> explicit_mark_move[2] { assign(scalar(first), capture_from(body_start)); mark_here(body_start) }
 -> explicit_mark_move[3] { assign(scalar(stage), "second_value") }
 -> explicit_mark_move[4] { return(array("?explicit_mark_move:", scalar(first), capture_from(body_start))) }
```

On input:

```text
foo(alpha,beta)
```

the practical reading is:
- `capture_from(body_start)` reads `alpha` from the stable mark,
- `mark_here(body_start)` then moves that mark to the current parser position after the comma,
- the final `capture_from(body_start)` returns `beta`.

This is the explicit-control pattern:
- `capture_from(name)` reads without moving,
- `mark_here(name)` moves without reading,
- `capture_take(name)` combines those two operations when that is what the rule really wants.

## Worked Example: Stable Read, Explicit Clear
Sometimes the rule wants to consume one stable named span and then make that mark unavailable to later reads in the same rule.

That is what `clear_mark(name)` is for.

```text
explicit_mark_clear::AND
 I { declare(scalar, stage, first) }
 /foo\(/
 @mark(body_start)
 /alpha/
 /,\s*(?=beta)/
 /beta/
 /\)/
 -> explicit_mark_clear[0] { assign(scalar(stage), "open") }
 -> explicit_mark_clear[1] { assign(scalar(stage), "first_value") }
 -> explicit_mark_clear[2] { assign(scalar(first), capture_from(body_start)); clear_mark(body_start) }
 -> explicit_mark_clear[3] { assign(scalar(stage), "second_value") }
 -> explicit_mark_clear[4] { return(array("?explicit_mark_clear:", scalar(first), capture_from(body_start))) }
```

On input:

```text
foo(alpha,beta)
```

the practical reading is:
- `capture_from(body_start)` reads `alpha` from the stable mark,
- `clear_mark(body_start)` removes that named mark,
- the final `capture_from(body_start)` returns `undef` because the mark is no longer present.

This is the explicit-reset pattern:
- `capture_from(name)` reads without moving,
- `clear_mark(name)` drops the checkpoint,
- later same-rule reads see that the mark is gone.

## Worked Example: Explicit Current-Edge Length Read
Sometimes the rule wants metadata about the current span width rather than the substring itself.

That is what `capture_len_from(name)` is for.

```text
span_length::AND
 I { declare(scalar, stage) }
 /foo\(/
 @mark(body_start)
 /\w+/
 /\)/
 -> span_length[0] { assign(scalar(stage), "open") }
 -> span_length[1] { assign(scalar(stage), "body") }
 -> span_length[2] { return(array("?span_length:", capture_len_from(body_start), capture_len_from(missing_mark))) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- `capture_len_from(body_start)` returns `3` because the current-edge span is `bar`,
- `capture_len_from(missing_mark)` returns `undef` because that named checkpoint was never established,
- and neither read mutates the named mark.

This is the explicit current-edge length pattern:
- `capture_from(name)` returns the substring,
- `capture_len_from(name)` returns the width of that same current-edge span,
- and `capture_take(name)` is still the only one of those three helpers that advances the mark.

## Worked Example: Explicit Presence Check
Sometimes the rule wants to know whether a named checkpoint is still alive without reading or moving it.

That is what `mark_exists(name)` is for.

```text
explicit_mark_presence::AND
 I { declare(scalar, stage, before_clear) }
 /foo\(/
 @mark(body_start)
 /alpha/
 /,\s*(?=beta)/
 /beta/
 /\)/
 -> explicit_mark_presence[0] { assign(scalar(stage), "open") }
 -> explicit_mark_presence[1] { assign(scalar(stage), "first_value") }
 -> explicit_mark_presence[2] { assign(scalar(before_clear), mark_exists(body_start)); clear_mark(body_start) }
 -> explicit_mark_presence[3] { assign(scalar(stage), "second_value") }
 -> explicit_mark_presence[4] { return(array("?explicit_mark_presence:", scalar(before_clear), mark_exists(body_start))) }
```

On input:

```text
foo(alpha,beta)
```

the practical reading is:
- the first `mark_exists(body_start)` returns `1` because the named mark is present,
- `clear_mark(body_start)` removes that named mark,
- the final `mark_exists(body_start)` returns `0` because the mark is now absent.

This is the explicit-presence pattern:
- `mark_exists(name)` reports presence without reading a span,
- `clear_mark(name)` still owns deletion,
- and later same-rule logic can branch on mark presence directly instead of encoding that question through a read helper.

That branching use is part of the supported surface too. In other words, this is intentionally valid:

```text
if(mark_exists(body_start)); assign(scalar(state), "present"); else; assign(scalar(state), "missing"); endif
```

and so is:

```text
if(not(mark_exists(body_start))); return(array("?state:", "gone")); endif
```

## Worked Example: Explicit Position Read
Sometimes the rule wants the checkpoint itself as data rather than only as a later span boundary.

That is what `mark_pos(name)` is for.

```text
explicit_mark_position::AND
 I { declare(scalar, stage, begin_pos, end_pos) }
 /foo\(/
 @mark(body_start)
 /\w+/
 /\)/
 -> explicit_mark_position[0] { assign(scalar(stage), "open") }
 -> explicit_mark_position[1] { assign(scalar(stage), "body"); assign(scalar(begin_pos), mark_pos(body_start)) }
 -> explicit_mark_position[2] { mark_match_start(end_mark); assign(scalar(end_pos), mark_pos(end_mark)); return(array("?explicit_mark_position:", scalar(begin_pos), scalar(end_pos), capture_between(body_start, end_mark), mark_pos(missing_mark))) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- `mark_pos(body_start)` returns the stored left-boundary position of the inner span,
- `mark_match_start(end_mark)` stores the left edge of the closing `)` match,
- `mark_pos(end_mark)` returns that stored numeric position,
- `mark_pos(missing_mark)` returns `undef` because no such named checkpoint is currently present.

This is the explicit-position pattern:
- `mark_exists(name)` answers “is this mark present?”,
- `mark_pos(name)` answers “what numeric position is stored there right now?”,
- and neither helper mutates the mark bucket.

## Worked Example: Current Local Match Boundary Reads
Sometimes the rule does not want a stored checkpoint at all. It just wants the boundaries of the current local match as immediate data.

That is what `match_start_pos()` and `match_end_pos()` are for.

```text
explicit_match_boundaries::AND
 I { declare(scalar, stage, body_start_pos, body_end_pos) }
 /foo\(/
 /\w+/
 /\)/
 -> explicit_match_boundaries[0] { assign(scalar(stage), "open") }
 -> explicit_match_boundaries[1] { assign(scalar(stage), "body"); assign(scalar(body_start_pos), match_start_pos()); assign(scalar(body_end_pos), match_end_pos()) }
 -> explicit_match_boundaries[2] { return(array("?explicit_match_boundaries:", scalar(body_start_pos), scalar(body_end_pos), match_start_pos(), match_end_pos())) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- at `-> explicit_match_boundaries[1]`, the current local match is `bar`, so `match_start_pos()` returns `4` and `match_end_pos()` returns `7`,
- at `-> explicit_match_boundaries[2]`, the current local match is `)`, so `match_start_pos()` returns `7` and `match_end_pos()` returns `8`,
- and none of those reads touch the named-mark bucket at all.

This is the direct-current-boundary pattern:
- use `mark_pos(name)` when the rule wants a previously stored checkpoint,
- use `match_start_pos()` when the rule wants the current local match left edge immediately,
- and use `match_end_pos()` when the rule wants the current local match right edge immediately.

## Worked Example: Current Immediate Match Text Read
Sometimes a child rule wants to keep the entry match that led into the rule, even while later local matches inside that child rule keep changing.

That is what `entry_text()` is for.

```text
entry_vs_local_text::AND
 I { declare(scalar, stage) }
 /foo\(/
 -> entry_vs_local_text[0] { assign(scalar(stage), "open"); return(call(entry_vs_local_text_body)) }

entry_vs_local_text_body::AND
 I { declare(scalar, entry_token, body_token) }
 /\w+/
 /\)/
 -> entry_vs_local_text_body[0] { assign(scalar(entry_token), entry_text()); assign(scalar(body_token), match_text()) }
 -> entry_vs_local_text_body[1] { return(array("?entry_vs_local_text_body:", scalar(entry_token), scalar(body_token), match_text())) }
```

When building this exact inline example directly, select `top_rule => entry_vs_local_text` so the entry rule is explicit.

On input:

```text
foo(bar)
```

the practical reading is:
- when `entry_vs_local_text_body` starts, its immediate entry match is still `foo(` because that is the match from the parent edge that called it,
- at `-> entry_vs_local_text_body[0]`, the current local match is `bar`, so `entry_text()` returns `foo(` while `match_text()` returns `bar`,
- at `-> entry_vs_local_text_body[1]`, the current local match is `)`, so `match_text()` returns `)` while `entry_text()` would still keep the same entry match,
- and none of those direct match-text reads consult or mutate the named-mark bucket.

This is the direct-entry-text pattern:
- use `entry_text()` when the rule wants the immediate entry match that led into the current rule,
- use `entry_group(index)` when the rule wants one capture group from that same immediate entry match,
- use `match_text()` when the rule wants the current local match that is active right now inside the current rule,
- and use `capture_from(name)` when the rule wants a larger remembered span between rule-local boundaries instead.

## Worked Example: Current Immediate Match Group Read
Sometimes a child rule wants one capture group from the immediate entry match that led into the rule, even while later local matches inside that child rule have their own capture groups.

That is what `entry_group(index)` is for.

```text
entry_vs_local_groups::AND
 /(foo)\(/
 -> entry_vs_local_groups[0] { return(call(entry_vs_local_groups_body)) }

entry_vs_local_groups_body::AND
 I { declare(scalar, entry_group_0, body_group_0, body_group_1) }
 /(\w)(\w+)/
 /(\))/
 -> entry_vs_local_groups_body[0] { assign(scalar(entry_group_0), entry_group(0)); assign(scalar(body_group_0), match_group(0)); assign(scalar(body_group_1), match_group(1)) }
 -> entry_vs_local_groups_body[1] { return(array("?entry_vs_local_groups_body:", scalar(entry_group_0), scalar(body_group_0), scalar(body_group_1), match_group(0), entry_group(0), entry_group(1), match_group(1))) }
```

When building this exact inline example directly, select `top_rule => entry_vs_local_groups` so the entry rule is explicit.

On input:

```text
foo(bar)
```

the practical reading is:
- when `entry_vs_local_groups_body` starts, its immediate entry match is still `foo(` and its immediate capture-group list still contains `foo`, so `entry_group(0)` is `foo`,
- at `-> entry_vs_local_groups_body[0]`, the current local match is `bar`, so `match_group(0)` is `b` and `match_group(1)` is `ar`,
- at `-> entry_vs_local_groups_body[1]`, the current local match is `)`, so `match_group(0)` is `)` while `entry_group(0)` still keeps the same entry capture group,
- and missing group indexes stay `undef` instead of forcing the rule to branch first.

This is the direct-entry-group pattern:
- use `entry_group(index)` when the rule wants one capture group from the immediate entry match that led into the current rule,
- use `entry_groups()` when the rule wants that whole immediate-entry capture-group list as one snapshot value,
- use `match_group(index)` when the rule wants one capture group from the currently active local match instead,
- use `match_groups()` when the rule wants that whole current-local capture-group list as one snapshot value instead,
- and use `entry_text()` / `match_text()` when whole-match text is clearer than group-level reads.

## Worked Example: Current Immediate And Local Capture Group Lists
Sometimes a child rule wants the whole immediate entry capture-group list that led into the rule, while still watching the current local capture-group list change as later local matches happen inside that child rule.

That is what `entry_groups()` and `match_groups()` are for.

```text
entry_vs_local_group_lists::AND
 /(foo)\(/
 -> entry_vs_local_group_lists[0] { return(call(entry_vs_local_group_lists_body)) }

entry_vs_local_group_lists_body::AND
 I { declare(array, entry_groups_seen, body_groups_seen) }
 /(\w)(\w+)/
 /(\))/
 -> entry_vs_local_group_lists_body[0] { assign(array(entry_groups_seen), entry_groups()); assign(array(body_groups_seen), match_groups()) }
 -> entry_vs_local_group_lists_body[1] { return(array("?entry_vs_local_group_lists_body:", array_copy(array(entry_groups_seen)), array_copy(array(body_groups_seen)), match_groups())) }
```

When building this exact inline example directly, select `top_rule => entry_vs_local_group_lists` so the entry rule is explicit.

On input:

```text
foo(bar)
```

the practical reading is:
- when `entry_vs_local_group_lists_body` starts, its immediate entry capture-group list is still `["foo"]`, so `entry_groups()` snapshots that whole list,
- at `-> entry_vs_local_group_lists_body[0]`, the current local match is `bar`, so `match_groups()` snapshots `["b", "ar"]`,
- at `-> entry_vs_local_group_lists_body[1]`, the current local match is `)`, so `match_groups()` now snapshots `[")"]`,
- and the earlier saved snapshots stay stable because they were copied into ordinary rule arrays.

This is the direct-group-list pattern:
- use `entry_groups()` when the rule wants the whole immediate entry capture-group list that led into the current rule,
- use `match_groups()` when the rule wants the whole currently active local capture-group list instead,
- use `entry_group(index)` / `match_group(index)` when one positional capture is clearer than the whole list,
- use `entry_named(name)` / `match_named(name)` when one named capture is clearer than positional group snapshots,
- and use `entry_map()` / `match_map()` when the whole named-capture hash is the clearer boundary snapshot.

## Worked Example: Current Immediate And Local Named Capture Read
Sometimes a child rule wants named regex captures from both the immediate entry match that led into the rule and the currently active local match inside that child rule.

That is what `entry_named(name)` and `match_named(name)` are for.

```text
entry_vs_local_named_groups::AND
 /(?<prefix>foo)\(/
 -> entry_vs_local_named_groups[0] { return(call(entry_vs_local_named_groups_body)) }

entry_vs_local_named_groups_body::AND
 I { declare(scalar, entry_prefix, body_first, body_rest) }
 /(?<first>\w)(?<rest>\w+)/
 /(?<close>\))/
 -> entry_vs_local_named_groups_body[0] { assign(scalar(entry_prefix), entry_named(prefix)); assign(scalar(body_first), match_named(first)); assign(scalar(body_rest), match_named(rest)) }
 -> entry_vs_local_named_groups_body[1] { return(array("?entry_vs_local_named_groups_body:", scalar(entry_prefix), scalar(body_first), scalar(body_rest), match_named(close), entry_named(prefix), entry_named(missing_name), match_named(rest))) }
```

When building this exact inline example directly, select `top_rule => entry_vs_local_named_groups` so the entry rule is explicit.

On input:

```text
foo(bar)
```

the practical reading is:
- when `entry_vs_local_named_groups_body` starts, its immediate entry match is still `foo(` and its immediate named-capture hash still contains `prefix => foo`, so `entry_named(prefix)` is `foo`,
- at `-> entry_vs_local_named_groups_body[0]`, the current local match is `bar`, so `match_named(first)` is `b` and `match_named(rest)` is `ar`,
- at `-> entry_vs_local_named_groups_body[1]`, the current local match is `)`, so `match_named(close)` is `)` while `match_named(rest)` is now `undef`,
- and missing named captures stay `undef` instead of forcing the rule to branch first.

This is the direct-named-group pattern:
- use `entry_named(name)` when the rule wants one named capture from the immediate entry match that led into the current rule,
- use `match_named(name)` when the rule wants one named capture from the currently active local match instead,
- use `entry_group(index)` / `match_group(index)` when positional numbering is clearer than names,
- and use `entry_text()` / `match_text()` when whole-match text is clearer than either group form.

## Worked Example: Current Immediate And Local Named Capture Maps
Sometimes a child rule wants to snapshot the whole named-capture hash from both the immediate entry match and the currently active local match.

That is what `entry_map()` and `match_map()` are for.

```text
entry_vs_local_named_maps::AND
 /(?<prefix>foo)\(/
 -> entry_vs_local_named_maps[0] { return(call(entry_vs_local_named_maps_body)) }

entry_vs_local_named_maps_body::AND
 I { declare(hash, entry_named_seen, body_named_seen) }
 /(?<first>\w)(?<rest>\w+)/
 -> entry_vs_local_named_maps_body[0] { assign(hash(entry_named_seen), entry_map()); assign(hash(body_named_seen), match_map()) }
 /(?<close>\))/
 -> entry_vs_local_named_maps_body[1] { return(array("?entry_vs_local_named_maps_body:", scalar(hash(entry_named_seen), "prefix"), scalar(hash(body_named_seen), "first"), scalar(hash(body_named_seen), "rest"), scalar(match_map(), "close"), join_values(",", sorted_keys(entry_map())), join_values(",", sorted_keys(match_map())))) }
```

When building this exact inline example directly, select `top_rule => entry_vs_local_named_maps` so the entry rule is explicit.

On input:

```text
foo(bar)
```

the practical reading is:
- when `entry_vs_local_named_maps_body` starts, its immediate entry named-capture hash still contains `prefix => foo`, so `entry_map()` snapshots that entry-side named boundary directly,
- at `-> entry_vs_local_named_maps_body[0]`, the current local match is `bar`, so `match_map()` snapshots `first => b` and `rest => ar`,
- at `-> entry_vs_local_named_maps_body[1]`, the current local match is now `)`, so `match_map()` has moved on to `close => )`,
- and the earlier stored `body_named_seen` snapshot stays on the earlier `bar` match because it was copied into an ordinary rule-local hash.

This is the direct-named-map pattern:
- use `entry_map()` when the rule wants the whole immediate entry named-capture hash that led into the current rule,
- use `match_map()` when the rule wants the whole currently active local named-capture hash instead,
- use `entry_named(name)` / `match_named(name)` when one key is clearer than the full hash,
- and use `entry_groups()` / `match_groups()` when positional capture-group lists are the clearer representation.

## Worked Example: Current Immediate Match Width Read
Sometimes a child rule wants to keep the width of the immediate entry match that led into the rule, even while later local match widths inside that child rule keep changing.

That is what `entry_len()` is for.

```text
entry_vs_local_width::AND
 I { declare(scalar, stage) }
 /foo\(/
 -> entry_vs_local_width[0] { assign(scalar(stage), "open"); return(call(entry_vs_local_width_body)) }

entry_vs_local_width_body::AND
 I { declare(scalar, entry_width, body_width) }
 /\w+/
 /\)/
 -> entry_vs_local_width_body[0] { assign(scalar(entry_width), entry_len()); assign(scalar(body_width), length(match_text())) }
 -> entry_vs_local_width_body[1] { return(array("?entry_vs_local_width_body:", scalar(entry_width), scalar(body_width), entry_len(), length(match_text()))) }
```

When building this exact inline example directly, select `top_rule => entry_vs_local_width` so the entry rule is explicit.

On input:

```text
foo(bar)
```

the practical reading is:
- when `entry_vs_local_width_body` starts, its immediate entry match is still `foo(`, so `entry_len()` is `4`,
- at `-> entry_vs_local_width_body[0]`, the current local match is `bar`, so `length(match_text())` is `3`,
- at `-> entry_vs_local_width_body[1]`, the current local match is `)`, so `length(match_text())` is `1`,
- and the immediate entry width stays `4` throughout the child rule.

This is the direct-entry-width pattern:
- use `entry_len()` when the rule wants the width of the immediate entry match that led into the current rule,
- use `length(match_text())` when the rule wants the width of the currently active local match instead,
- and use `capture_len_from(name)` when the rule wants the width of a remembered span between rule-local boundaries instead.

## Worked Example: Current Immediate Match Boundary Reads
Sometimes a child rule wants to keep the boundaries of the immediate entry match that led into the rule, even while the current local match boundaries keep moving.

That is what `entry_start_pos()` and `entry_end_pos()` are for.

```text
entry_vs_local_boundaries::AND
 I { declare(scalar, stage) }
 /foo\(/
 -> entry_vs_local_boundaries[0] { assign(scalar(stage), "open"); return(call(entry_vs_local_boundaries_body)) }

entry_vs_local_boundaries_body::AND
 I { declare(scalar, entry_start, entry_end, body_start, body_end) }
 /\w+/
 /\)/
 -> entry_vs_local_boundaries_body[0] { assign(scalar(entry_start), entry_start_pos()); assign(scalar(entry_end), entry_end_pos()); assign(scalar(body_start), match_start_pos()); assign(scalar(body_end), match_end_pos()) }
 -> entry_vs_local_boundaries_body[1] { return(array("?entry_vs_local_boundaries_body:", scalar(entry_start), scalar(entry_end), scalar(body_start), scalar(body_end), entry_start_pos(), entry_end_pos(), match_start_pos(), match_end_pos())) }
```

When building this exact inline example directly, select `top_rule => entry_vs_local_boundaries` so the entry rule is explicit.

On input:

```text
foo(bar)
```

the practical reading is:
- when `entry_vs_local_boundaries_body` starts, its immediate entry match is still `foo(`, so `entry_start_pos()` is `0` and `entry_end_pos()` is `4`,
- at `-> entry_vs_local_boundaries_body[0]`, the current local match is `bar`, so `match_start_pos()` is `4` and `match_end_pos()` is `7`,
- at `-> entry_vs_local_boundaries_body[1]`, the current local match is `)`, so `match_start_pos()` is `7` and `match_end_pos()` is `8`,
- and the immediate entry boundaries remain `0` / `4` throughout the child rule.

This is the direct-entry-boundary pattern:
- use `entry_start_pos()` / `entry_end_pos()` when the rule wants the immediate entry match boundaries that led into the current rule,
- use `match_start_pos()` / `match_end_pos()` when the rule wants the currently active local match boundaries instead,
- and use `mark_pos(name)` when the rule wants a previously stored named checkpoint.

## Worked Example: Current Local Match Text Read
Sometimes the rule wants the current local match text itself, not a stored checkpoint, not the immediate entry match, and not a larger captured span.

That is what `match_text()` is for.

```text
explicit_match_text::AND
 I { declare(scalar, stage, body_token) }
 /foo\(/
 /\w+/
 /\)/
 -> explicit_match_text[0] { assign(scalar(stage), "open") }
 -> explicit_match_text[1] { assign(scalar(stage), "body"); assign(scalar(body_token), match_text()) }
 -> explicit_match_text[2] { return(array("?explicit_match_text:", scalar(body_token), match_text())) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- at `-> explicit_match_text[1]`, the current local match is `bar`, so `match_text()` returns `bar`,
- at `-> explicit_match_text[2]`, the current local match is `)`, so `match_text()` returns `)`,
- and those reads do not consult or mutate the named-mark bucket.

This is the direct-current-text pattern:
- use `entry_text()` when the rule wants the immediate entry match that led into the current rule,
- use `entry_start_pos()` / `entry_end_pos()` when the rule wants the immediate entry-match boundaries that led into the current rule,
- use `capture_from(name)` when the rule wants a span from a remembered left edge,
- use `match_text()` when the rule wants the current local match text only,
- and use `match_start_pos()` / `match_end_pos()` when the rule wants the current local match boundaries as numbers.

## Worked Example: Current Local Match Group Read
Sometimes the rule wants one capture group from the current local match itself, not a stored checkpoint span and not a capture group from the immediate entry match.

That is what `match_group(index)` is for.

```text
explicit_match_groups::AND
 I { declare(scalar, stage, first_piece, second_piece) }
 /foo\(/
 /(\w)(\w+)/
 /(\))/
 -> explicit_match_groups[0] { assign(scalar(stage), "open") }
 -> explicit_match_groups[1] { assign(scalar(stage), "body"); assign(scalar(first_piece), match_group(0)); assign(scalar(second_piece), match_group(1)) }
 -> explicit_match_groups[2] { return(array("?explicit_match_groups:", scalar(first_piece), scalar(second_piece), match_group(0), match_group(1))) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- at `-> explicit_match_groups[1]`, the current local match is `bar`, so `match_group(0)` is `b` and `match_group(1)` is `ar`,
- at `-> explicit_match_groups[2]`, the current local match is `)`, so `match_group(0)` is `)` and `match_group(1)` is `undef`,
- and those reads do not consult or mutate the named-mark bucket.

This is the direct-current-group pattern:
- use `entry_group(index)` when the rule wants one capture group from the immediate entry match that led into the current rule,
- use `match_group(index)` when the rule wants one capture group from the current local match only,
- use `capture_from(name)` when the rule wants a remembered span,
- and use `match_text()` / `match_len()` when whole-match text or width is clearer than group-level reads.

## Worked Example: Current Local Match Width Read
Sometimes the rule wants the width of the current local match itself, not a stored checkpoint span and not the immediate entry-match width.

That is what `match_len()` is for.

```text
explicit_match_width::AND
 I { declare(scalar, stage, body_width) }
 /foo\(/
 /\w+/
 /\)/
 -> explicit_match_width[0] { assign(scalar(stage), "open") }
 -> explicit_match_width[1] { assign(scalar(stage), "body"); assign(scalar(body_width), match_len()) }
 -> explicit_match_width[2] { return(array("?explicit_match_width:", scalar(body_width), match_len())) }
```

On input:

```text
foo(bar)
```

the practical reading is:
- at `-> explicit_match_width[1]`, the current local match is `bar`, so `match_len()` returns `3`,
- at `-> explicit_match_width[2]`, the current local match is `)`, so `match_len()` returns `1`,
- and those reads do not consult or mutate the named-mark bucket.

This is the direct-current-width pattern:
- use `entry_len()` when the rule wants the width of the immediate entry match that led into the current rule,
- use `capture_len_from(name)` when the rule wants the width of a remembered span from a stored checkpoint,
- use `match_len()` when the rule wants the width of the current local match only,
- and use `match_start_pos()` / `match_end_pos()` when the rule wants the current local match boundaries as numbers.

## Worked Example: Several Independent Checkpoints
Named checkpoints become more useful once one anonymous split cursor is no longer enough.

You can treat them as separate named left edges:
- `@mark(header_start)`
- `@mark(body_start)`
- `@mark(argument_start)`

Then later actions in that same rule can ask for exactly the span they want:

```text
capture_from(header_start)
capture_from(body_start)
capture_from(argument_start)
```

That is the main reason to choose `@mark(name)` over anonymous `@capture_slice`:
- anonymous split is good when one moving capture baseline is enough,
- named marks are better when multiple checkpoints may coexist,
- named marks are also better when the same rule needs several stable named left edges.

## Worked Example: Same Name in Different Rules
Named marks are rule-local, so different rules can reuse the same mark name safely.

```text
header::AND
 I { declare(scalar, stage) }
 /\[/
 @mark(body_start)
 /\w+/
 /\]/
 -> header[0] { assign(scalar(stage), "open") }
 -> header[1] { assign(scalar(stage), "body") }
 -> header[2] { return(array("?header:", capture_from(body_start))) }

payload::AND
 I { declare(scalar, stage) }
 /\(/
 @mark(body_start)
 /\w+/
 /\)/
 -> payload[0] { assign(scalar(stage), "open") }
 -> payload[1] { assign(scalar(stage), "body") }
 -> payload[2] { return(array("?payload:", capture_from(body_start))) }
```

Both rules use `body_start`, but they do not collide because each rule keeps its own named-mark bucket.

## Worked Example: Missing Marks Are Safe
`capture_from(name)` and `capture_take(name)` are intentionally safe if the mark does not exist yet.

If the named mark is absent:
- either helper returns `undef`,
- it does not throw by itself,
- and `capture_take(name)` also leaves the missing mark untouched,
- and `mark_here(name)` can still initialize the rule-local mark explicitly at the current parser position,
- and `clear_mark(name)` stays a harmless no-op,
- so action code can branch explicitly if the mark is optional in that rule family.

That means this is legal:

```text
-> rule[0] {
     return(array("?body:", capture_from(body_start)))
   }
```

If the mark is absent, the payload becomes:

```text
["?body:", undef]
```

## Choosing Between Anonymous and Named Checkpoints
Use `@capture_slice` when:
- one moving anonymous capture baseline is enough,
- you do not need to keep more than one checkpoint alive at once,
- and the capture flow is local enough that naming the checkpoint adds no clarity.

Use `@mark(name)` when:
- more than one checkpoint may be alive at once,
- the checkpoint meaning benefits from a real name,
- or the same rule needs more than one named left edge.

Use `capture_from(name)` when:
- the named checkpoint should stay stable for more than one later read,
- or you want to compare more than one later right boundary against the same named left edge.

Use `capture_len_from(name)` when:
- the rule wants the numeric width of the current-edge span instead of the substring itself,
- later logic should record or compare span length metadata without materializing that text,
- or the rule wants the same boundary semantics as `capture_from(name)` but in numeric form.

Use `capture_take(name)` when:
- you want the named checkpoint to roll forward after each read,
- the rule behaves like a named split cursor,
- or a repeated separator/delimiter pattern should keep consuming successive fields.

Use `capture_between(start_mark, end_mark)` when:
- both span boundaries should come from named checkpoints,
- the rule wants to compare an explicit two-mark span with a current-match-edge span,
- or the right edge should be remembered earlier than the final read site.

Use `capture_len_between(start_mark, end_mark)` when:
- the rule wants the numeric width of an explicit remembered-boundary span instead of the substring itself,
- later logic should compare or record two-mark span length metadata,
- or the rule wants the same two-mark boundary semantics as `capture_between(start_mark, end_mark)` but in numeric form.

Use `mark_here(name)` when:
- the rule should decide explicitly when a named checkpoint moves,
- you want stable read first and explicit advance second,
- or the mark should be updated even when no current capture string is being returned.

Use `mark_entry_start(name)` when:
- the rule should remember where the immediate entry match that led into this rule began,
- later same-rule logic should still be able to refer back to that entry boundary after local matches have advanced,
- or the rule wants a stable named writer-side companion to `entry_start_pos()`.

Use `mark_entry_end(name)` when:
- the rule should remember where the immediate entry match that led into this rule ended,
- later same-rule logic should still be able to refer back to that entry right edge after the live parser cursor has moved on,
- or the rule wants a stable named writer-side companion to `entry_end_pos()`.

Use `mark_match_start(name)` when:
- the mark should store the left edge of the current match,
- a closing token or delimiter should be excluded from a later `capture_between(...)` span,
- or the rule needs both the left edge and the post-match edge of the same current match.

Use `mark_match_end(name)` when:
- the mark should store the right edge of the current local match,
- later same-rule logic should still be able to refer back to that current-match right edge even if the live parser cursor advances further,
- or the rule wants a stable named writer-side companion to `match_end_pos()`.

Use `mark_copy(target_mark, source_mark)` when:
- the rule should copy one remembered boundary into another named checkpoint explicitly,
- a pure read helper like `capture_len_between(...)` should be followed by an explicit remembered-boundary move,
- or missing-source copies should clear the target instead of leaving stale state behind.

Use `mark_capture_slice(name)` when:
- the rule starts in the anonymous rolling-boundary model,
- one current anonymous boundary should be preserved under a stable explicit name before later anonymous reads move again,
- or a later action block will need to restore that current anonymous boundary explicitly through `start_capture_slice_from(name)`.

Use `start_capture_slice_from(name)` when:
- the rule already has a named checkpoint that should become the active anonymous rolling boundary again,
- later logic still wants the concise anonymous helper family after restoring that remembered left edge,
- or the rule wants an explicit named-to-anonymous bridge instead of raw `$IPOS = mark_pos(name)` plumbing.

Use `clear_mark(name)` when:
- the rule should decide explicitly when a named checkpoint disappears,
- one stable read should be followed by an explicit drop,
- or later same-rule reads should see that the mark is no longer present.

Use `mark_exists(name)` when:
- the rule should ask whether a named checkpoint is currently present,
- later logic should distinguish “mark still alive” from “mark already cleared,”
- or the rule wants explicit presence metadata without reading or mutating the capture span itself.

Use `mark_pos(name)` when:
- the rule should expose the numeric stored checkpoint position directly,
- later logic should compare or report mark positions rather than only captured spans,
- or the rule needs explicit position metadata without mutating the checkpoint.

Use `mark_line(name)` when:
- the rule should expose the stored checkpoint line directly,
- later diagnostics should report where a named checkpoint landed without first round-tripping through `mark_pos(name)`,
- or the rule needs explicit line metadata for one remembered boundary without mutating the checkpoint.

Use `mark_col(name)` when:
- the rule should expose the stored checkpoint column directly,
- later diagnostics should report where a named checkpoint landed on its line without first round-tripping through `mark_pos(name)`,
- or the rule needs explicit column metadata for one remembered boundary without mutating the checkpoint.

Use `mark_input_start(name)` when:
- the rule should remember the absolute start of the current input string under an explicit named checkpoint,
- later same-rule logic should reason about whole-input spans without inferring that left edge from rule entry or the anonymous capture boundary,
- the helper should remain safe as a standalone writer statement even when that stored boundary is `0`,
- or the rule wants a backend-neutral replacement for manually writing `0` into one named mark slot.

Use `mark_input_end(name)` when:
- the rule should remember the absolute end of the current input string under an explicit named checkpoint,
- later same-rule logic should reason about whole-input right edges without inferring that boundary from the current parser cursor,
- the helper should remain safe as a standalone writer statement even when that stored boundary happens to be `0`,
- or the rule wants a backend-neutral replacement for manually writing `length($$STRING)` into one named mark slot.

Use `cursor_col()` when:
- the rule should expose the live current parser column directly,
- later logic should compare or report same-line cursor movement without storing a checkpoint first,
- or the rule wants a backend-neutral replacement for raw `pos $$STRING` plus newline math in normal user-facing `.spec` code.

Use `capture_take()` when:
- one rolling anonymous capture boundary is enough for the whole rule,
- the rule should read the current anonymous slice and then continue later same-rule reads from the current parser position,
- the rule wants the anonymous-boundary counterpart to named `capture_take(name)`,
- or the rule wants a backend-neutral replacement for raw “capture current `$IPOS` span, then set `$IPOS = pos $$STRING`” flow in normal user-facing `.spec` code.

Use `capture_take_until_cursor()` when:
- one rolling anonymous capture boundary is enough for the whole rule,
- the returned span should extend through the live parser cursor instead of stopping at the current match edge,
- and the anonymous boundary should still roll forward after the read.

Use `capture_take_until_cursor_len()` when:
- one rolling anonymous capture boundary is enough for the whole rule,
- the rule only needs the width of that through-cursor span instead of the span text,
- and the anonymous boundary should still roll forward after the read.

Use `capture_take_len()` when:
- one rolling anonymous capture boundary is enough for the whole rule,
- the rule only needs the width of the current-edge span instead of the span text,
- and the anonymous boundary should still roll forward after the read.

Use `capture_take_rest()` when:
- one rolling anonymous capture boundary is enough for the whole rule,
- the returned span should extend all the way through end-of-input instead of stopping at the current match edge or current cursor,
- and the anonymous boundary should still roll forward afterward so later same-rule tail reads see end-of-input.

Use `capture_take_rest_len()` when:
- one rolling anonymous capture boundary is enough for the whole rule,
- the rule only needs the width of that end-of-input tail instead of the tail text,
- and the anonymous boundary should still roll forward afterward so later same-rule tail-width reads see zero.

Use `capture_take_until_cursor_from(name)` when:
- the rule wants a stable named checkpoint model rather than the anonymous boundary model,
- the returned span should extend through the live parser cursor instead of stopping at the current match edge,
- and the named checkpoint should still roll forward after the read.

Use `capture_take_until_cursor_len_from(name)` when:
- the rule wants a stable named checkpoint model rather than the anonymous boundary model,
- the rule only needs the width of that through-cursor span instead of the span text,
- and the named checkpoint should still roll forward after the read.

Use `capture_take_len_from(name)` when:
- the rule wants a stable named checkpoint model rather than the anonymous boundary model,
- the rule only needs the width of the current-edge span instead of the span text,
- and the named checkpoint should still roll forward after the read.

Use `capture_take_rest_from(name)` when:
- the rule wants a stable named checkpoint model rather than the anonymous boundary model,
- the returned span should extend all the way through end-of-input instead of stopping at the current match edge or current cursor,
- and the named checkpoint should still roll forward afterward so later same-rule tail reads start from end-of-input.

Use `capture_take_rest_len_from(name)` when:
- the rule wants a stable named checkpoint model rather than the anonymous boundary model,
- the rule only needs the width of that end-of-input tail instead of the tail text,
- and the named checkpoint should still roll forward afterward so later same-rule tail-width reads see zero.

Use `capture_take_between_len(start_mark, end_mark)` when:
- both boundaries should come from explicit named checkpoints rather than from the current match,
- the rule only needs the width of that explicit two-mark span instead of the span text,
- and the start mark should still roll forward to the stored end mark after the read.

Use `cursor_rest()` and `cursor_rest_len()` when:
- the rule should expose what remains from the live parser cursor through end-of-input,
- the left edge should be the live parser cursor rather than an anonymous or named checkpoint,
- later logic should compare or report “remaining input” directly instead of current match boundaries,
- or the rule wants backend-neutral replacements for raw `substr($$STRING, pos $$STRING, ...)` and `length($$STRING) - pos $$STRING` in normal user-facing `.spec` code.

Use `input_text()` when:
- the rule should expose the whole current input string directly instead of a narrower live-cursor, entry-match, or local-match view,
- child-rule logic should keep the full source visible even while `entry_text()` and `match_text()` answer different narrower questions,
- or the rule wants a backend-neutral replacement for raw `$$STRING` in normal user-facing `.spec` code.

Use `input_slice(start, width)` when:
- the rule already has explicit absolute source boundaries and needs that span as text,
- child-rule logic should read a whole-input span even though entry, local-match, and live-cursor views are narrower,
- or the rule wants a backend-neutral replacement for raw `substr($$STRING, start, width)` in normal user-facing `.spec` code.

Use `input_len()` when:
- the rule should expose the width of the whole current input directly instead of a narrower live-cursor, entry-match, or local-match width,
- child-rule logic should keep the full source width visible even while `entry_len()` and `match_len()` answer different narrower questions,
- or the rule wants a backend-neutral replacement for raw `length($$STRING)` in normal user-facing `.spec` code.

Use `input_end_pos()` when:
- the rule should expose the whole-input right edge as one explicit absolute position rather than as a width,
- later logic will compare that whole-input end boundary against marks, capture boundaries, cursor positions, or match boundaries,
- child-rule logic should keep that absolute whole-input right edge visible even while entry and local-match right-edge helpers expose narrower boundaries,
- or the rule wants a backend-neutral replacement for raw `length($$STRING)` when the surrounding code is reasoning in position terms rather than width terms.

Use `input_end_line()` and `input_end_col()` when:
- the rule should expose where the whole current input ends in human-readable line/column terms,
- the live parser cursor may still be earlier but diagnostics should still point at the final end-of-input location,
- or the rule wants backend-neutral replacements for manual newline/column math around `length($$STRING)` in normal user-facing `.spec` code.

Use `entry_text()` when:
- the rule wants the immediate entry match that led into the current rule,
- child-rule logic should keep that entry token visible while local matches continue to move forward,
- or the rule wants a backend-neutral replacement for raw `$IMATCH` in normal user-facing `.spec` code.

Use `entry_col()` when:
- the rule wants the column where the immediate entry match that led into the current rule began,
- child-rule logic should keep that entry column visible while local match columns continue to move forward,
- or the rule wants a backend-neutral replacement for raw `$IPOS - length($IMATCH)` plus newline math in normal user-facing `.spec` code.

Use `entry_start_line()` and `entry_start_col()` when:
- the rule wants those same immediate-match left-edge line/column values,
- the surrounding code already uses explicit `entry_start_pos()` / `entry_end_*()` wording and the helper family should read symmetrically,
- or the shorter `entry_line()` / `entry_col()` names would undersell that these are explicitly start-edge reads.

Use `entry_group(index)` when:
- the rule wants one capture group from the immediate entry match that led into the current rule,
- child-rule logic should keep that entry capture-group data visible while local match groups continue to move forward,
- or the rule wants a backend-neutral replacement for raw `scalar(IMATCH_LIST, index)` in normal user-facing `.spec` code.

Use `entry_has(name)` when:
- the rule wants to know whether one named capture exists on the immediate entry match that led into the current rule,
- child-rule logic should keep that entry named-capture presence visible while local named captures continue to move forward,
- or the rule wants a backend-neutral shortcut instead of spelling `has_key(entry_map(), "name")` just to ask a simple presence question.

Use `entry_len()` when:
- the rule wants the width of the immediate entry match that led into the current rule,
- child-rule logic should keep that entry width visible while local match widths continue to move forward,
- or the rule wants a backend-neutral replacement for raw `length($IMATCH)` in normal user-facing `.spec` code.

Use `entry_start_pos()` and `entry_end_pos()` when:
- the rule wants the immediate entry match boundaries that led into the current rule,
- child-rule logic should keep those entry boundaries visible while local match boundaries continue to move forward,
- or the rule wants backend-neutral replacements for raw `$IPOS - length($IMATCH)` and `$IPOS` in normal user-facing `.spec` code.

Use `entry_end_line()` and `entry_end_col()` when:
- the rule wants the human-readable line or column of the immediate entry-match right edge that led into the current rule,
- child-rule logic should keep that entry right-edge location visible while local right-edge location continues to move forward,
- or the rule wants backend-neutral replacements for manual line/column math around `entry_end_pos()` in normal user-facing `.spec` code.

Use `match_text()` when:
- the rule wants the current local match text itself as data,
- there is no need to store a named checkpoint for later reuse,
- or the rule wants a backend-neutral replacement for raw `$LMATCH` in normal user-facing `.spec` code.

Use `match_col()` when:
- the rule wants the column where the current local match began,
- there is no need to store a named checkpoint for later reuse,
- or the rule wants a backend-neutral replacement for raw `$LSPOS - length($LMATCH)` plus newline math in normal user-facing `.spec` code.

Use `match_start_line()` and `match_start_col()` when:
- the rule wants those same current local-match left-edge line/column values,
- the surrounding code already uses explicit `match_start_pos()` / `match_end_*()` wording and the helper family should read symmetrically,
- or the shorter `match_line()` / `match_col()` names would undersell that these are explicitly start-edge reads.

Use `match_group(index)` when:
- the rule wants one capture group from the current local match itself as data,
- there is no need to store a named checkpoint for later reuse,
- or the rule wants a backend-neutral replacement for raw `scalar(LMATCH_LIST, index)` in normal user-facing `.spec` code.

Use `match_has(name)` when:
- the rule wants to know whether one named capture exists on the current local match itself,
- there is no need to snapshot the whole named-capture hash just to ask that presence question,
- or the rule wants a backend-neutral shortcut instead of spelling `has_key(match_map(), "name")` just to test a current local named capture.

Use `match_len()` when:
- the rule wants the width of the current local match itself as data,
- there is no need to store a named checkpoint for later reuse,
- or the rule wants a backend-neutral replacement for raw `length($LMATCH)` in normal user-facing `.spec` code.

Use `match_start_pos()` and `match_end_pos()` when:
- the rule wants the current local match boundaries themselves as data,
- there is no need to store a named checkpoint for later reuse,
- or the rule wants to teach or debug the distinction between the current match and a separately remembered mark.

Use `match_end_line()` and `match_end_col()` when:
- the rule wants the human-readable line or column of the current local-match right edge,
- there is no need to store a named checkpoint for later reuse,
- or the rule wants backend-neutral replacements for manual line/column math around `match_end_pos()` in normal user-facing `.spec` code.

Documentation note:
- this guide prefers backend-neutral helper forms such as `return(payload)`, `assign(...)`, and `call(rule)` in code blocks,
- while [`USER_GUIDE_ActionIR_EmittedPerlReference.md`](USER_GUIDE_ActionIR_EmittedPerlReference.md) is the place that shows the Perl lowering explicitly.

## Split-Style Mental Model
If you like a more intuitive description, this is a good one:

- `@capture_slice` turns the current parser position into the new left edge of the next capture span.
- older specs may still say `@capture_from_here` or `@move_pos`, but the meaning is the same.

That makes it useful as a split-boundary marker.

It is still better to think “capture cursor move” than “magic split operator,” because the cursor explanation matches what the compiler actually emits.

## Practical Pattern: Coarse Outer Pass, Finer Inner Pass
A staged parsing workflow can look like this:

```text
outer_rule:
  1. match a stable opening anchor,
  2. move the capture boundary,
  3. keep scanning until a stable closing anchor,
  4. capture the raw middle region,
  5. store that region in the first-pass AST,
  6. parse that stored region with another rule family or another parser.
```

That pattern is especially valuable when:
- the inner region has its own mini-language,
- delimiter nesting is irregular,
- or the inner syntax is easier to parse once isolated from surrounding boilerplate.

## Current Contract
The current supported contract is:
- `:&`, `:|`, `:+`, `:*`, and `:?` are real current rule-mode sigils,
- explicit ordered-sequence label `AND` is now supported on top of the same ordered-sequence family,
- explicit repeated-sequence label `AND+` is now supported on top of the same repeated-sequence family as `AND{1,}`,
- explicit repeated-choice label `OR` is now supported on top of the same repeated-choice family,
- explicit repeated-choice shorthand `OR+` is now supported on top of the same repeated-choice family as `OR` and `OR{1,}`,
- bounded repeated-choice labels `OR{N,M}`, `OR{N}`, `OR{N,}`, and `OR{,M}` are supported on top of the current repeated-alternative model,
- bounded repeated-sequence labels `AND{N,M}`, `AND{N}`, `AND{N,}`, and `AND{,M}` are supported on top of the current ordered-sequence model,
- blind-call `=> child_rule` is a real current advanced rule-body surface and should not be mixed with `-> child_rule` inside one rule,
- the clearest documented blind-call shapes today are ordered-sequence wrappers (`:&`, `:AND`, `:AND+`, `:AND{...}`) and single-choice wrappers (`:|`),
- repeated-choice blind-call use on `rule:`, `:OR`, `:OR+`, `:+`, and `:OR{...}` is now supported current surface too, with label-driven repeated-choice semantics rather than implicit sequence semantics,
- the validation layer now recognizes that same current rule-label surface for earlier syntax diagnostics instead of only understanding the older `name::` subset,
- on the Perl reference, `@capture_slice` is the preferred alias for the legacy rule-level split-boundary marker,
- `capture_slice()`, `capture_slice_len()`, `capture_slice_until_cursor()`, `capture_slice_until_cursor_len()`, `capture_take_until_cursor()`, `capture_take_until_cursor_len()`, `capture_slice_pos()`, `capture_slice_line()`, and `capture_slice_col()` are the preferred anonymous split-boundary read helpers,
- `start_capture_slice()` is the preferred anonymous split-boundary move helper inside lifecycle/action code,
- `start_capture_slice_from(name)` is the preferred named-to-anonymous bridge helper when one stored named checkpoint should become the active anonymous split boundary again,
- `capture_take()` is the preferred anonymous split-boundary advancing-read helper,
- `capture_take_len()` is the preferred anonymous split-boundary advancing-width helper,
- `capture_take_until_cursor_from(name)` and `capture_take_until_cursor_len_from(name)` are the preferred advancing named-mark through-cursor helpers when the right edge should be the live parser cursor,
- `capture_take_len_from(name)` is the preferred advancing named-mark current-edge width helper when the right edge should still be the current match edge,
- `capture_take_between_len(start_mark, end_mark)` is the preferred advancing explicit two-mark width helper when both boundaries should stay fully explicit,
- `capture_rest()` and `capture_rest_len()` are the preferred anonymous split-boundary tail helpers,
- `cursor_rest()` and `cursor_rest_len()` are the preferred live-cursor tail helpers,
- `@mark(name)` remains an accepted marker-member spelling with backend-specific scope; use `mark_here(name)` in action code when portable timing matters,
- `mark_input_start(name)` and `mark_input_end(name)` are the preferred absolute whole-input boundary writers when the rule wants explicit named checkpoints for the input start or input end,
- on Perl, `@capture_from_here` and `@move_pos` remain supported compatibility aliases for the same rule-level lowering; Lua/LuaJIT give all three spellings preceding-slot scope, while Rust/Dart/Julia do not execute marker members natively,
- `capture_from(name)` currently means “text from the named checkpoint up to the left edge of the current match,”
- `capture_len_from(name)` means “the numeric length of that same current-edge span or `undef` when the mark is absent,”
- `capture_until_cursor_from(name)` means “text from the named checkpoint through the live parser cursor,”
- `capture_until_cursor_len_from(name)` means “the numeric length of that same named-mark through-cursor span or `undef` when the mark is absent,”
- `capture_take_until_cursor()` means “return the current anonymous through-cursor span and then advance that anonymous boundary to the live parser cursor,”
- `capture_take_until_cursor_len()` means “return the numeric width of the current anonymous through-cursor span and then advance that anonymous boundary to the live parser cursor,”
- `capture_take_len()` means “return the numeric width of the current anonymous current-edge span and then advance that anonymous boundary to the current parser position,”
- `capture_take_until_cursor_from(name)` means “return the current named-mark through-cursor span and then advance that named mark to the live parser cursor,”
- `capture_take_until_cursor_len_from(name)` means “return the numeric width of the current named-mark through-cursor span and then advance that named mark to the live parser cursor,”
- `capture_take_len_from(name)` means “return the numeric width of the current named-mark current-edge span and then advance that named mark to the current parser position,”
- `capture_take_between_len(start_mark, end_mark)` means “return the numeric width of the current explicit two-mark span and then advance the start mark to the stored end mark,”
- `capture_take()` means “return the current anonymous split-boundary span and then advance that anonymous boundary to the current parser position,”
- `start_capture_slice_from(name)` means “look up that stored named checkpoint and make it the active anonymous split-boundary start again,”
- `capture_take(name)` means “return that same span and then advance the named checkpoint to the current parser position,”
- `capture_between(start_mark, end_mark)` means “text between two explicit named checkpoints in the current rule-local mark bucket,”
- `capture_len_between(start_mark, end_mark)` means “the numeric length of that same explicit two-mark span or `undef` when either mark is absent or reversed,”
- `capture_take_between(start_mark, end_mark)` means “return that same explicit two-mark span and then advance the start checkpoint to the remembered end checkpoint,”
- `mark_input_start(name)` means “set or overwrite that named checkpoint at the absolute start of the current input string,”
- `mark_input_end(name)` means “set or overwrite that named checkpoint at the absolute end of the current input string,”
- `mark_input_start(name)` and `mark_input_end(name)` are meant to be followed by explicit readers like `mark_pos(name)` or `capture_between(...)`, and they now lower as safe standalone writer statements even when the stored boundary itself is `0`,
- `mark_here(name)` means “set or overwrite that named checkpoint at the current parser position without first reading from it,”
- `mark_match_start(name)` means “set or overwrite that named checkpoint at the left edge of the current match,”
- `mark_capture_slice(name)` means “set or overwrite that named checkpoint from the current anonymous split-boundary position,”
- `mark_copy(target_mark, source_mark)` means “set or overwrite the target checkpoint from the source checkpoint when the source exists, otherwise clear the target and return `undef`,”
- `clear_mark(name)` means “delete that named checkpoint from the current rule-local mark bucket,”
- `mark_exists(name)` means “return `1` if that named checkpoint is currently present in the current rule-local mark bucket, otherwise `0`,”
- `mark_pos(name)` means “return the numeric stored position of that named checkpoint or `undef` if it is absent,”
- `mark_line(name)` means “return the 1-based line number of that named checkpoint or `undef` if it is absent,”
- `mark_col(name)` means “return the 1-based column number of that named checkpoint or `undef` if it is absent,”
- `cursor_pos()` means “return the live current parser cursor position directly,”
- `cursor_line()` means “return the live current parser cursor line directly,”
- `cursor_col()` means “return the live current parser cursor column directly,”
- `cursor_rest()` means “return the remaining text from the live current parser cursor through end-of-input,”
- `cursor_rest_len()` means “return the width of that same live current parser-cursor tail or `undef` when the live cursor itself is unavailable,”
- `input_text()` means “return the whole current input string directly,”
- `input_slice(start, width)` means “return a substring from the whole current input using explicit absolute start and width expressions,”
- `input_len()` means “return the width of the whole current input string directly,”
- `input_end_pos()` means “return the absolute position of the whole-input right edge directly,”
- `input_end_line()` means “return the 1-based line number of the whole-input right edge directly,”
- `input_end_col()` means “return the 1-based column number of the whole-input right edge directly,”
- `entry_text()` means “return the current immediate match text directly,”
- `entry_line()` means “return the 1-based line number of the current immediate match directly,”
- `entry_start_line()` means “return the 1-based line number of the current immediate-match left edge directly,”
- `entry_col()` means “return the 1-based column number of the current immediate match directly,”
- `entry_start_col()` means “return the 1-based column number of the current immediate-match left edge directly,”
- `entry_group(index)` means “return one capture group from the current immediate match directly,”
- `entry_groups()` means “return the whole current immediate-match capture-group list directly,”
- `entry_named(name)` means “return one named capture from the current immediate match directly,”
- `entry_has(name)` means “return `1` when that named capture exists on the current immediate match, otherwise `0`,”
- `entry_map()` means “return the whole current immediate-match named-capture hash directly,”
- `entry_named_map()` is the compatibility alias for that same immediate named-capture-hash read,
- `entry_len()` means “return the width of the current immediate match directly,”
- `entry_start_pos()` means “return the left edge of the current immediate match directly,”
- `entry_end_pos()` means “return the right edge of the current immediate match directly,”
- `entry_end_line()` means “return the 1-based line number of the current immediate-match right edge directly,”
- `entry_end_col()` means “return the 1-based column number of the current immediate-match right edge directly,”
- `match_text()` means “return the current local match text directly,”
- `match_line()` means “return the 1-based line number of the current local match directly,”
- `match_start_line()` means “return the 1-based line number of the current local-match left edge directly,”
- `match_col()` means “return the 1-based column number of the current local match directly,”
- `match_start_col()` means “return the 1-based column number of the current local-match left edge directly,”
- `match_group(index)` means “return one capture group from the current local match directly,”
- `match_groups()` means “return the whole current local-match capture-group list directly,”
- `match_named(name)` means “return one named capture from the current local match directly,”
- `match_has(name)` means “return `1` when that named capture exists on the current local match, otherwise `0`,”
- `match_map()` means “return the whole current local named-capture hash directly,”
- `match_named_map()` is the compatibility alias for that same local named-capture-hash read,
- `match_len()` means “return the width of the current local match directly,”
- `match_start_pos()` means “return the left edge of the current local match directly,”
- `match_end_pos()` means “return the right edge of the current local match directly,”
- `match_end_line()` means “return the 1-based line number of the current local-match right edge directly,”
- `match_end_col()` means “return the 1-based column number of the current local-match right edge directly,”
- named marks are rule-local, so different rules can reuse the same mark name without colliding,
- and marks are a later-slot surface, so same-slot actions should not expect a freshly written mark yet,
- and any further grouped-rule strategy expansion is demand-driven future work rather than part of the current syntax contract.

That gives us a stable baseline before we expand the remaining rule-grouping surface further.
