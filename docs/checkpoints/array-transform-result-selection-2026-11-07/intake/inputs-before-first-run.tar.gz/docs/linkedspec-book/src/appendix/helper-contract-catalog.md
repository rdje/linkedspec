# Helper Contract Catalog

This appendix is the **canonical behavioral reference** for every ActionIR helper.
Each entry defines the helper's contract — signature, input/output types, semantics,
edge cases — at enough precision for a Rust, Dart, Julia, or Lua backend to implement
identically. No Perl implementation knowledge is required.

Helper calls use the `callee(args)` shape. Whitespace before the opening parenthesis
is accepted (`set (name, value)` is the same call as `set(name, value)`), but the
parentheses remain mandatory; no-parenthesis spellings such as `set name, value` or
`return scalar name` are not helper calls.

## 0. Primitive Value Literals

Primitive literals are value expressions, not helper calls or working-variable names.

- **Strings**: `"text"` and `'text'`.
- **Numbers**: integer and decimal forms such as `42`, `-1`, and `3.14`.
- **Booleans**: `true` and `false`, serialized as JSON booleans when returned or placed in containers.
- **Undefined**: `undef`, serialized as JSON `null`.

These literals are accepted in return payloads, constructor payloads, assignment RHS values,
append RHS values, hash keys/values, and flow predicates:

```text
return(array(true, false, "ready", 42, undef))
flag = true
items += false
meta["enabled"] = true
if(false); return("bad"); else(); return("good"); endif()
```

Literal recognition is exact. Prefix identifiers such as `trueword`, `false_alarm`, and
`undefine` are ordinary identifiers, not primitive literals.

## 0.1 Shape Value Literals

The Perl reference and Rust backend accept direct array and hash shape literals as value expressions:

```text
[]
[value, cat("a", "b"), true, []]
{ key : value, "fixed" : [value] }
```

Shape literals are accepted in value-consuming sites such as `return(payload)`, scalar assignment sources,
array append RHS values, typed-path assignment RHS values, `push(target, value)`, and nested constructor
payloads. Array elements, hash keys, and hash values lower through the scoped DSL value-expression rules:
primitive literals stay typed, recognized helper calls compose, direct nested access keeps its own bracket
semantics, nested shape literals recurse, and non-reserved bare names are scalar working-variable reads.
Perl and Rust both use `:` as the direct hash-literal key/value separator. Old `{ key => value }` ActionIR
value syntax is retired and reports `hash_literal_use_colon`; `=>` remains valid only for other owned surfaces
such as blind-call edges, source-language payloads, generated Perl host hashrefs, and historical records.

A bare hash-literal key is a dynamic scalar key, not a fixed string field name:

```text
set(key, "kind")
set(value, "token")
return({ key : value });       # {"kind": "token"}
return({ "kind" : value });    # fixed "kind" field
```

Direct shape literals are typed RHS values for bare assignment targets on the Perl reference and Rust backend:

```text
items = [value, cat("a", "b")];      # items holds an array value
meta = { key : value };             # meta holds a hash value
set(items, []);                      # items holds an empty array value
set(meta, {});                       # meta holds an empty hash value
set(items, []);               # explicit aggregate array reset
set(meta, {});                 # explicit aggregate hash reset
```

Bare working-variable reads and targets are the current scalar surface:
`set(payload, [value])` stores the whole array payload in `payload`. In value positions, `name` reads the
working variable named `name`.
Direct-access brackets (`payload["items"][i]`), typed-path assignment brackets (`meta[key] = value`),
control-flow/block braces, and all-bare child-call routing remain separate surfaces.

All current native backends accept expression-valued blocks in value-consuming sites. A non-empty
brace payload with no top-level hash-pair delimiter evaluates its statements and yields the final expression. A
`return(expr)` anywhere in the block exits only that expression-valued block, skips later block statements,
and yields `expr` as the block value. Hash literals keep precedence: `{}` and `{ key : value }`
remain hash shapes; old `{ key => value }` is retired and is not a block fallback.

Ordinary braces are eager even on an assignment RHS: `callback = { return("later") }` stores the scalar
`"later"`. Deferred first-class codeblocks use the distinct `{|params| ...}` form; a contextual trailing block
remains structural until the receiving callable executes it.

```text
return({ set(x, "a"); x });                    # "a"
set(out, { set(x, "a"); return(x) });          # $out = "a"
return({ return("a"); "b" });                  # "a"
set(out, { set(x, "a"); return(x); set(x, "b"); x });  # $out = "a"
return(array({ set(x, "a"); x }, { "k" : x }))
return({ [3, 1, 2] }.sorted().join_values(","));        # "1,2,3"
return({ " a-b " }.trim().split("-").count());          # 2
```

Expression-valued blocks are ordinary value expressions when used as receiver-dot receivers. The block
evaluates first, including any block-local `return(expr)`, and the yielded value is consumed by the same
compatible receiver family selected by the first method. Blocks do not create a separate block-only receiver
dispatch rule.

### Trailing block helper: `with(value) { ... }` / `.with() { ... }`

- **Signature**: `with(value?: expr) { block }`; receiver form `receiver.with() { block }`
- **Returns**: the immediate block result.
- **Backend status**: Perl, Rust, Dart, Julia, and Lua support attached and parenthesized contextual helper/receiver
  forms through declared final-codeblock metadata. They also accept an explicit `{|item| ...}` or bound codeblock
  value in that final slot. Bare `with { ... }` and explicit receiver `.with(value) { ... }` are not current
  surfaces.
- **Behavior**: Helper form evaluates the optional value argument, binds scoped working value `value` while the trailing
  block executes, restores any surrounding `value` binding afterward, and yields the block result. `with() { ... }`
  binds `value` to `undef`. Receiver form evaluates the receiver first, binds that receiver value as scoped
  `value`, and yields the block result as the terminal value or as the input to later compatible receiver-family
  links.
- **Execution context**: The block runs immediately in the caller's current action/runtime context. Captures,
  `retv`, cursor state, helper/function visibility, and ordinary working-variable side effects are shared with the
  call site. Only the working binding `value` is portable as the scoped block parameter in this MVP; mutations to
  other variable names persist after `with` returns.
- **Return semantics**: `return(expr)` inside the trailing block is block-local, exactly like expression-valued
  blocks: it yields `expr` from the block and skips later block statements; it does not return from the surrounding
  rule/action.
- **Examples**:
  - `return(with("x") { return(cat(value, "!")) })` yields `"x!"`.
  - `return(with("x", { return(cat(value, "!")) }))` is the same call on Perl, Rust, Dart, and Lua.
  - `return(with() { return(is_undefined(value)) })` yields true.
  - `return(" x ".with() { return(cat(value, "!")) }.trim())` yields `"x !"`.
  - `return(" a-b ".trim().with() { return(value.split("-")) }.count())` yields `2`.
  - `set(value, "outer"); return(array(with("inner") { return(value) }, value))` yields `["inner", "outer"]`.
  - On Lua, array/harray values are copied into `value`; the exact prior or absent uniform binding is restored even
    when the block or result copy fails.

> **Current portability boundary:** The language model has scalar, array, harray/hash, and codeblock values. A
> block-taking callable declares an exact final-only `name: codeblock` parameter, with no callback argument list;
> attached/contextual final-block forms normalize to the same call on helper, user-function, receiver, and tree
> surfaces. ADR 0031 defines explicit `{|args| body }` values, dynamic caller context without lexical capture, and
> retained `with`; ADR 0032 defines the metadata-owned final slot. Perl, Rust, Dart, Julia, and Lua construct and
> invoke explicit values and normalize governed contextual forms through their ordinary codeblock executors.
> Lua's native, reconstructed, generated-plan, and fresh emitted-module paths are implementation-current on PUC
> Lua and LuaJIT under `.11.8.1-.3`; `.11.8.4` admits both ABIs into the recurring five-backend/public proof.
> Five-backend callable recurring/public admission is complete.

## 1. Working Variables and Setup

> **Working variables auto-exist.** Referencing a bare variable in a read, assignment, or type-implying helper
> position creates a per-invocation binding. The target of `set(name, ...)` and the assignment
> operator `name = value`, which bind scalar, array, or hash RHS values as the variable's current
> typed value;
> the scalar source in `return(name)`, `set(out, name)`, and `out = name`; the array target of
> `push(name, ...)` and the array append operator `name += value`; and the harray target of
> `set_key(name, key, value)` auto-exist from a **bare** name too. On all five backends, typed-path assignment
> `name[key] = value` chooses the absent root from the evaluated selector kind instead of fixing it from syntax.
> `copy(name)` snapshots the current array or harray
> value. A backend MUST supply the same auto-existence: a position-referenced variable is a fresh working slot for
> the parse, not a value carried across parses. Recursive re-entry uses explicit fresh-container bindings:
> `set(name, [])` and `set(name, {})` establish rule-local aggregate bindings before
> mutation. New specs should use direct assignment initializers such as `name = value` or explicit
> aggregate resets such as `set(items, [])` and `set(meta, {})`.
> The DSL literals `undef`/`true`/`false` and the engine's own handler locals are never treated as
> working-variable names. Use `[undef]` to construct an array containing the `undef` literal.

### `name = value` assignment operator
- **Signature**: `name = value`
- **Returns**: In statement position, the stored value is ignored. In value position, it yields the typed value stored in the target.
- **Behavior**: Sets the working variable `name` to the evaluated RHS value. If the variable was not previously declared, the reference auto-creates it as a per-invocation working variable (see the note at the top of this section); otherwise it reassigns the existing variable. Later assignments may replace a scalar with an array/hash value, or replace an array/hash value with a scalar.
- **Edge cases**: `name = [value]`, `set(name, [value])`, and `=(name, [value])` bind an array value to `name`; `name = { key : value }` binds a hash value. In scalar assignment source slots, a bare source name reads the current typed working value: `out = value`.
- **Terse spelling**: `name = value` is the preferred operator spelling, and `set(name, value)` remains the helper spelling. In value positions, assignments store and yield the stored typed value. See [Terse Helper Renames](#terse-helper-renames-canonical-going-forward).

A completed `set` value can feed current reads, for example
`saved = set(items, ["head","tail"]); saved.coalesce(undef)[-1].uppercase()` yields
`"TAIL"`. Compatible direct methods also work on Perl, such as
`set(text, " tail ").trim().uppercase()`. Perl, Rust, Dart, Julia and installed Lua (PUC5.5.1/LuaJIT) support direct reads
and guard incompatible consumers before their operands run:

```text
set(items, ["head","tail"])[-1].uppercase()          # "TAIL"
set(meta, {"k":["head","tail"]})["k"][-1].uppercase() # "TAIL"
set(flag, false).not()                              # true
set(number, 0).add(1)                               # 1
set(absent, undef).coalesce(["head","tail"])[-1].uppercase() # "TAIL"
set(items, ["tail"]).set_key("k", 1)                 # null
```

Each call assigns once. Its result is captured before later selectors or consumer
operands rebind the target. Missing paths, empty values, local returns, function
bindings, `with` returned kinds and RHS errors keep their ordinary contracts.
First-class codeblocks remain values with existing invocation rules:
`saved = set(thunk, {|| return("tail")}); saved()` yields `"tail"`. Assignment
copy and alias rules stay unchanged. Regenerate affected emitted Perl parsers.
Rebuild Rust, Dart, Julia and Lua applications with the updated runtime.
Declared Lua5.4 and complete admission remain separate in the backend handoff.

- **Worked example**:
  ```text
  demo::
   -> value .push
   LX { return(copy(demo)) }

  value : /(\w+)/
   I {
     value = entry_group(0)
     set(items, [value, cat(value, "!")])
     set(meta, { "value" : value })
     return(array(value, items, meta, name = value, name))
   }
  ```
  Input `ok` returns `[["ok",["ok","ok!"],{"value":"ok"},"ok","ok"]]`.
  The scalar assignment `name = value` stores and yields `"ok"` in value position; the explicit
  aggregate resets establish `items` and `meta`.

## 2. Scalar Helpers

> **Worked examples.** Each example below is a complete, runnable `.spec` written in the
> recommended **two-rule idiom**: a **top (`::`) entry rule** — which carries **no regex**
> of its own (it is the dispatch loop) — plus a **normal (`:`) rule** that carries the
> regex and computes the value. (This is the clean idiom for these helper demos, not a
> hard minimum — `::` is just an entry marker, and a top rule may itself carry a regex or
> recurse; see [.spec Files and Rule Paragraphs](../user-model/spec-files-and-rule-paragraphs.md).)
> The shared shape is:
>
> ```text
> demo::  -> value  .push
> LX { return(copy(demo)) }
>
> value : /<regex>/  I.return( <helper-expression> )
> ```
>
> The top rule dispatches to `value`, pushes its returned value into the accumulator
> (named after the top rule), and a terminal `LX` returns a snapshot of it. The `value`
> rule matches the input and reads its captures with **`entry_group(N)`** (the entering
> match) — `entry_group(0)` is the **first capture group** of `<regex>` (0-based; see
> [Regex in `.spec`](../user-model/regex-in-spec.md#capture-groups)). Because the parser's
> output is the top rule's accumulator, it is a **one-element array** holding the helper's
> value (see [Runtime Semantics §5.5](runtime-semantics.md)). Each compact "over
> `/<regex>/`, `<expr>` on `<input>` → `<output>`" line plugs into this shape: `value`
> carries `/<regex>/`, its `I.return(<expr>)` computes the result, and `<output>` is the
> parser's array. String predicate results in these examples surface in the reference
> boolean shape (`1` for true, `0` for false); primitive literal `true`/`false` values
> are typed JSON booleans. An undefined result surfaces as a `null` element. The value-returning predicates
> (`matches`, `starts_with`, `ends_with`, `contains_substr`) may be returned directly. The definedness predicates
> (`is_defined`, `is_undefined`) are portable in `if (...)` conditions and in current Perl/Rust ActionIR AST value
> contexts such as `with() { return(is_undefined(value)) }`; current Perl definedness false remains empty text, as qualified in its entries below.

### `container[key]`
- **Signature**: `container: array|hash[key: int|string]`
- **Returns**: scalar or undef
- **Behavior**: Reads a single value from an array (by 0-based index) or hash (by string key).
- **Edge cases**: Returns `undef` if the key does not exist or container is not array/hash.
- **Example**: over `/(\w+),(\w+),(\w+)/`, `array(entry_group(0), entry_group(1), entry_group(2))[1]` on `a,b,c` → `["b"]`.

### Direct nested access and value-path assignment: `base["key"][index]`
- **Signature**: `base[path_segment...]`, where `base` is a working scalar containing an array/hash payload.
- **Returns**: read form returns the selected value or `undef`; assignment returns the updated root on success.
  Structural failures throw the typed v1 diagnostic on all five backends.
- **Behavior**: Reads any-depth mixed hash/array paths directly from a structured payload. The contract forbids
  creating state; see the executed [read-purity examples and Perl evaluation details](../dsl/value-container-flow-helper-reference.md#read-purity).
  Assignment uses the same spelling. On all five backends, each bracket expression is evaluated and its runtime kind selects
  harray (string) or array (nonnegative integer), so dynamic selectors are not classified from their authored
  spelling. A non-reserved bare path atom such as `[i]` reads the scalar working variable. The assignment target
  remains a bare binding, for example `payload["children"][0]["name"] = value`.
- **Edge cases**: Reads return `undef` when a segment does not exist or the current value has the wrong container
  kind. Writes create an absent root and missing intermediates only when evaluated selectors determine the
  shape; bound null and wrong kinds are conflicts. Arrays may replace or append exactly at length, never create a
  gap. Segments evaluate once left-to-right, then RHS once; typed selector/kind/gap failures commit no partial path.
  Primitive literals and engine locals such as `[true]` or
  `[CAPTURE]` are not claimed as scalar path variables.
- **Example**:
  ```text
  Top::
   -> Done {
     set(payload, hash("children", array(hash("name", "one"), hash("name", "two"))))
     set(i, 1)
     payload["children"][i]["name"] = "updated"
     return(payload["children"][i]["name"])
   }

  Done:
   /[a-z]+/
  ```
  Input `xhello` -> `"updated"`.

### `cat(args...)`
- **Signature**: `cat(a: scalar, b: scalar, ...)`
- **Returns**: scalar
- **Behavior**: Concatenates scalar text under `scalar-text-v1`. Strings are unchanged, booleans become `"1"`/`"0"`, and finite numbers use the established numeric text policy. An undef argument makes the whole result undef: `cat("a",undef,"b")` → undef, while `cat("a","","b")` → `"ab"`.
- **Edge cases**: Non-scalar arguments (arrays, hashes) return `undef` for the whole expression.
- **Argument boundary**: Every argument in an already-valid current value-helper call is an authored value. A bare
  first value is never consumed as a legacy scope label: `cat(key, "@", depth)` reads all three values. The same
  rule applies to variadic arithmetic/coalescing helpers and to the optional-width form
  `substr(value, start, width)`. Legacy optional-scope compatibility is considered only when the raw argument count
  would otherwise be invalid.
- **Retirement note**: the former `concat` spelling diagnoses on current runtimes. See [Terse Helper Renames](#terse-helper-renames-canonical-going-forward).
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /(\w+) (\w+)/  I.return( cat(entry_group(0), "-", entry_group(1)) )
  ```
  Input `hello world` → `["hello-world"]`.

### `coalesce(a, b, ...)`
- **Signature**: `coalesce(values: scalar...)`
- **Returns**: the selected value, preserving its kind; the published portable operand domain remains scalar.
- **Behavior**: Returns the first argument that is defined (not undef). Evaluates left-to-right, short-circuiting.
- **Edge cases**: Returns `undef` if all arguments are undef. Empty text, numeric zero and false are defined: `coalesce("", "fallback")` → `""`, `coalesce(0, 7)` → `0`, `coalesce(false, true)` → `false`.
- **Examples**: `coalesce([].first(), "fallback")` → `"fallback"`. With `audit="unset"`, `value=coalesce("first", { audit="late"; "fallback" })` leaves `audit` unchanged and returns `"first"`; later operand errors are also skipped. Nested selection keeps the same rule: `coalesce(undef, coalesce("", "late"))` → `""`. Ordinary Perl also preserves a selected direct Hash literal: `coalesce(undef,{"items":[7,{"n":7}],"flag":false})` returns the Hash with nested numeric/boolean kinds intact; this compatibility observation does not broaden the published portable operand domain. Ordinary Perl/Rust/Dart/Julia/Lua `value.coalesce(fallback, ...)` now requires one-or-more fallbacks and preserves defined-only lazy selection, actual scalar/Array/Hash kinds and compatible continuations. Examples include `"".coalesce("late").cat("!")` → `"!"` and `undef.coalesce(["a","b"]).last().uppercase()` → `"B"`; Perl native/fresh and Julia/Lua native/plan/fresh and Rust/Dart native/restored/in-process plan targeted checks cover copies, numeric indices, source-before-fallback/consumer snapshots, skipped unused runtime errors and zero-fallback rejection before effects. Lua checks use available PUC5.5.1/LuaJIT; declared5.4 and complete domain/context/portable admission remain separate.

### `coalesce_nonempty(a, b, ...)`
- **Signature**: `coalesce_nonempty(values: scalar...)`
- **Returns**: the selected value, preserving its kind. The published operand domain is scalar; current Array/named-Harray compatibility and bounded fluent targets are qualified below.
- **Behavior**: Returns the first argument that is defined and not the empty string `""`, evaluating operands once from left to right until selection. Preserves numeric `0` and boolean `false`; it does not test truthiness.
- **Edge cases**: Returns `undef` only if all arguments are undef or `""`. `coalesce_nonempty("", 0, "late")` → numeric `0`; `coalesce_nonempty(undef, false, "late")` → `false`. A selected numeric value retains its kind: `index=coalesce_nonempty(0,7)` remains numeric index zero for a later `values[index]` write.
- **Examples**: over `/(\w+)/`, `coalesce_nonempty("", entry_group(0))` on `value` → `["value"]`. With `audit="unset"`, `"first".coalesce_nonempty({ audit="late"; "fallback" })` returns `"first"` without changing `audit` or evaluating later failures. `"".coalesce_nonempty(" fallback ").trim().uppercase()` → `"FALLBACK"`; helper and documented receiver forms on Perl/Rust preserve this lazy rule, and `"".coalesce_nonempty(undef, "")` returns undef. Ordinary Perl/Rust/Dart/Julia/Lua selected Array/named-Harray continuations are targeted-checked (Lua: available PUC5.5.1/LuaJIT; declared5.4/full admission open): `[].join_values(",").coalesce_nonempty(["a","b"]).join_values("-").uppercase()` gives `"A-B"`; with `meta={"b":"y","a":"x"}`, `"".coalesce_nonempty(meta).sorted_values().join_values(":").uppercase()` gives `"X:Y"`. A retained String followed by Array-only methods stays null; selection and consumer effects remain lazy/once-only. Direct Hash literal defaults and nested typed values are also preserved on Perl: `coalesce_nonempty("",{"items":[7,{"n":7}],"flag":false})` selects those fields unchanged. Later operands stay skipped after selection. These are bounded native/fresh checks; no portable aggregate-domain claim follows.

On Rust, Dart, Julia and installed Lua (PUC5.5.1/LuaJIT), an ordinary receiver
default also keeps a selected container's actual
kind before subsequent consumers. For example, with `items=["tail"]`,
`items.coalesce(undef).set_key("k", 1)` returns null; with `meta={"k":"tail"}`,
`meta.coalesce_nonempty(undef).take(1)` returns null. Incompatible operands and
later `with` bodies stay skipped. Compatible Array and Hash methods still work,
and required fallback blocks run once before consumers. Empty containers are
values; `coalesce_nonempty` rejects empty Scalar text rather than testing container
emptiness or truthiness. Rebuild Rust, Dart, Julia and Lua applications with the updated runtime.
Direct free-helper selections preserve primitive kinds and compatible methods.
On Perl, Rust, Dart, Julia and installed Lua (PUC5.5.1/LuaJIT), canonical ordinary
calls with two-or-more positional operands guard
incompatible consumers before their arguments or later `with` bodies run:

```text
coalesce(undef,"tail").set_key("k",1)   # null
coalesce_nonempty("",0).take(1)         # null
coalesce(false,true).not()               # true
coalesce(undef,["head","tail"])[-1].uppercase() # TAIL (existing compatibility)
```

Rejection differs from a valid null selection: `coalesce(undef,undef).with(){
return("recovered")}` returns `"recovered"`. An empty Array produced by a compatible
consumer also remains a valid `with` input. Source and needed defaults run once;
unused runtime errors remain skipped. Regenerate affected emitted Perl parsers
and rebuild Rust, Dart, Julia and Lua applications with the updated runtime.
Declared Lua5.4 remains separate. A completed-value bridge
also works: `saved=coalesce(undef,"tail"); saved.coalesce(undef).set_key("k",1)`
returns null.
Published Scalar operand domains, qualified aggregate compatibility, legacy
arities and complete admission remain separate. See the backend handoff.

### `is_defined(expr)`
- **Signature**: `is_defined(value: expr)`
- **Returns**: predicate result; Perl retains native `1`/empty-text false, while Rust/Dart/Julia/Lua retain Boolean results.
- **Behavior**: Returns true if the value is not undef. Accepts any expression type.
- **Edge cases**: Empty string, `0`, and empty arrays are defined.
- **Usage**: Supports condition, returned and nested expression forms on current Perl; `cat(is_defined("abc"),"!")` returns `"1!"`.
  Perl false is empty text: `cat(is_defined(undef),"!")` returns `"!"`; a following `coalesce_nonempty("late")` selects `"late"`. Rust/Dart/Julia/Lua retain Boolean false (Lua: PUC5.5.1/LuaJIT; declared5.4 proof remains separate): `[].first().is_defined().cat("!")` returns `"0!"`, and `[].first().is_defined().coalesce_nonempty("late").cat("!")` retains `"0!"`. Ordinary Perl receivers now work: `"abc".is_defined().cat("!")` → `"1!"`, `[].first().is_defined().cat("!")` → `"!"`, and `1.add(1).is_defined().cat("!")` → `"1!"`. Zero operands are required before effects; compatible scalar/generic methods consume the actual result, and container-only methods return undef until an explicit bridge produces a container.
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /(\w+)/  I { if (is_defined(entry_group(0))) { return("present") } else { return("absent") } }
  ```
  Input `hi` → `["present"]`.

### `is_undefined(expr)`
- **Signature**: `is_undefined(value: expr)`
- **Returns**: predicate result; Perl retains native `1`/empty-text false, while Rust/Dart/Julia/Lua retain Boolean results.
- **Behavior**: Returns true if the value is undef. Logical inverse of `is_defined`.
- **Usage**: Condition, returned and nested expression forms work on current Perl: `cat(is_undefined(undef),"!")` returns `"1!"`. Ordinary Perl receivers now work: `[].first().is_undefined().cat("!")` → `"1!"` and `"abc".is_undefined().cat("!")` → `"!"`; named/literal/selected/default/function/copy sources retain existing kinds and once-only source/result snapshots. Rust/Dart/Julia/Lua support the same bounded family: `false.is_defined()` and `undef.is_undefined()` return true; `"abc".is_undefined().cat("!")` returns `"0!"`. Full domain/context/portable admission remains separate. Preserve actual truth/text kinds; other-backend/domain admission is assessed separately.
- **Example**: over `/(\w+)/`, `if (is_undefined(array(entry_group(0))[9])) { return("missing") } else { return("present") }` on `hi` → `["missing"]` (index 9 is out of range, so the read is undef).

On the checked Perl5.34.1 host, native definedness false also retains numeric
slots. Its empty-text rendering alone does not make it a literal String:

```text
is_defined(undef).cat("!")        # "!"
is_defined(undef).add(1)          # 1
num_add(is_undefined(0),1)        # 1
copy(is_defined(undef)).add(1)    # 1
"".add(1)                       # undef
false.add(1)                    # undef (actual DSL Boolean)
```

Numeric inspection preserves the original predicate snapshot and text rendering.
These are existing Perl compatibility controls; peer Boolean results keep their
existing arithmetic rules. This does not establish a portable scalar-kind or
host-cache rule.

Perl, Rust, Dart, Julia and Lua retain actual-kind and rejection guards through canonical one-value free
definedness calls and ordinary zero-operand predicate prefixes:

```text
is_defined(undef).take(1)                         # undef
undef.is_defined().take(1).with(){return("ran")}   # undef; body skipped
undef.is_defined().cat("x").split(",").set_key("k",1).with(){return("ran")} # undef
is_defined(undef).with(){return([value,value.copy()])} # Perl ["",""]; other backends [false,false]
is_defined(undef).add("bad").with(){return("null")}   # "null"; body runs
```

Incompatible consumer operands and later bodies stay skipped; source expressions
still run once in order. Valid false/null/empty results enter `with`, and an Array
returned by a valid body can continue with Array methods. Perl native/fresh paths
have ready ActionIR metadata; Rust/Dart/Julia/installed Lua pass native/restored
compiled-spec/SpecFile/generated-plan controls, with fresh emitted modules on
Julia/Lua and strict Bool/text/default/numeric profiles. Regenerate emitted Perl
parsers and rebuild Rust/Dart/Julia/Lua apps/runtime. Lua proof uses available
PUC5.5.1/LuaJIT; declared5.4 and full source/domain/context admission remain
separate. Predicate domains, Perl numeric compatibility and peer Bool kinds remain unchanged.

### `trim(s)`
- **Signature**: `trim(value: scalar)`
- **Returns**: scalar
- **Behavior**: Removes leading and trailing whitespace. Returns undef if input is undef.
- **Edge cases**: A string of only whitespace becomes `""`. Null propagation also applies in receiver form: `[].first().trim()` returns undef. The same source-null rule applies to `length`, `lowercase`, `uppercase`, `replace_substr`, `rm_prefix` and `rm_suffix`. Ordinary Perl/Rust/Dart/Julia/Lua scalar String-helper results now feed compatible scalar/generic/numeric methods; `" a,b ".trim().split(",").last().uppercase()` gives `"B"`. In the checked receiver forms, a scalar result followed by a container-only consumer returns undef without evaluating that consumer's operands. Malformed receiver shapes reject before source effects; source/prefix effects before a valid incompatible tail remain. Lua checks use available PUC5.5.1/LuaJIT; declared5.4 and complete domain/context/portable admission remain separate.
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /\[([^\]]*)\]/  I.return( trim(entry_group(0)) )
  ```
  Input `[  hello  ]` → `["hello"]` (capture group `0` is the bracketed, padded text).

Perl, Rust, Dart, Julia and the tested Lua hosts retain actual-kind guards through
canonical ordinary free calls,
compatible methods and explicit Array bridges:

```text
trim("tail").take(1)                         # null
uppercase("tail").set_key("k",1)              # null
trim(" a,b ").split(",").last().uppercase()  # B
trim(undef).with(){return("recovered")}        # recovered
```

Incompatible consumer arguments and later immediate `with` bodies stay skipped;
legitimate empty Arrays and null values still enter `with`. Scalar identities
remain Number/Boolean where the original producer preserves them. Regenerate
emitted Perl parsers and rebuild Rust/Dart/Julia/Lua applications/runtime to pick up
these guards. Lua coverage is PUC5.5.1 and LuaJIT2.1.1788460057.
Legacy named aggregate fallback, malformed/alias/regex mutation forms and broader
unsupported receiver contexts remain separate.

The same guard applies to canonical receiver String prefixes on all five backends
on the recorded hosts:

```text
" a,b ".trim().split(",").set_key("k",1)       # null
"tail".trim().take(1).with(){return("ran")}    # null; body skipped
"".trim().split(",").take(0).first().with(){return("recovered")} # recovered
```

These paths compile; Perl also has ready ActionIR metadata. Source effects run once,
rejected consumer arguments and later bodies stay skipped, and legitimate empty
or null values still enter `with`. Regenerate emitted Perl and rebuild Rust/Dart/Julia/Lua applications/runtime.


### `lowercase(s)`
- **Signature**: `lowercase(value: scalar)`
- **Returns**: scalar
- **Behavior**: Applies Unicode 17.0.0 full Default Lowercase (R2), locale-independent, including contextual
  `Final_Sigma`, with no implicit normalization. Returns undef if input is undef.
- **Example**: `lowercase("ΟΣ")` → `"ος"`; `lowercase("İ")` → `"i\u{0307}"`.

### `uppercase(s)`
- **Signature**: `uppercase(value: scalar)`
- **Returns**: scalar
- **Behavior**: Applies Unicode 17.0.0 full Default Uppercase (R1), locale-independent, with expansion and no
  implicit normalization. Returns undef if input is undef.
- **Example**: `uppercase("Straße ﬃ")` → `"STRASSE FFI"`.

### `length(s)`
- **Signature**: `length(value: scalar|array)`
- **Returns**: int
- **Behavior**: Returns the character length of a string or the element count of an array. Returns undef for undef input.
- **Examples**: over `/(\w+)/`, `length(entry_group(0))` on `hello` → `[5]`; `length(undef)` and `undef.length()` → undef, `length("")` → `0`, `length(0)` → `1`, `length([1,2])` → `2`, `length("🙂")` → `1`. On Perl/Rust/Dart/Julia/Lua, `"abcd".length().add(2)` → `6` and `["ab"].first().length().add(1)` → `3`; the actual numeric result feeds the next compatible method. Lua checks use available PUC5.5.1/LuaJIT; declared5.4 proof remains open.

### `matches(s, /pattern/)`
- **Signature**: `matches(value: scalar, pattern: regex)`
- **Returns**: predicate flag; Perl retains numeric `1`/`0`, while the checked native peers retain Boolean results.
- **Behavior**: Returns true if the value matches the regex pattern. The pattern is a literal `/regex/` — no variable interpolation. Perl/Rust/Dart/Julia/Lua now support `"abc".matches(/^a/).cat("!")` → `"1!"`, and `"abc".matches(/^z/).coalesce_nonempty("late").cat("!")` → `"0!"`. `"abc".matches(/^a/).cat(",x").split(",").last().uppercase()` → `"X"`; the split explicitly produces an Array. `.matches(/^a/).sorted()` returns undef. One pattern is required before effects; regex/producer policies stay unchanged. Lua checks use PUC5.5.1/LuaJIT; declared5.4/full regex admission remain separate. Dart retains literal i/m/s and processes suffix x before its existing bridge: `matches("ab",/^ a b $/x)` is true, while `/^ a b $/` misses; `matches("a b",/^ a [ ] b $/x)` is true because class spaces remain literal. Extended mode ignores ASCII whitespace and # line comments outside classes; escaped spaces/hash remain literal. `g/o` remain no-ops; unknown suffixes and invalid compiled patterns return false, so `"abc".matches(/a**/).cat("!")` is `"0!"`. Complete grouped dotted action regexes such as /(?s)^a.b$/ retain their literal boundaries; `matches("abc",/(/)` and its receiver form return false because the helper receives the invalid pattern. Symbolic `/(8,2)` remains numeric division and returns4. Inline x and broad scoped-mode semantics are not admitted. Broader grouped-brace action scanning/validation remains a tracked limitation. Rust now retains literal `i/m/s/x` modes in compiled action regex patterns; `g/o` remain no-ops and unknown flags fail closed. Regenerate older compiled/emitted Rust artifacts from source to pick up modes that the previous parser discarded; Rust retains its contextual pattern-string representation and existing serialized fields.
- **Regex flags**: `i`, `m`, `s`, and `x` affect compilation. Operation-only `g` and Perl compile-once `o` are
  accepted compile-time no-ops. Unknown flags or invalid patterns return false.
- **Edge cases**: Returns false for undef input.
- **Examples**: over `/(\w+)/`, `matches(entry_group(0), /^\d+$/)` returns `[1]` on `123` and `[0]` on `abc`; `matches(undef, /^$/)` is false, while `matches("", /^$/)` is true.

### `starts_with(s, prefix)`
- **Signature**: `starts_with(value: scalar, prefix: scalar)`
- **Returns**: numeric flag `1` or `0` on the checked backends.
- **Behavior**: Returns true if the value starts with the exact prefix string. Undefined value or prefix returns false; an empty prefix matches every defined value, including empty text. Perl/Rust/Dart/Julia/Lua support `"abc".starts_with("a").cat("!")` → `"1!"` and the equivalent nested form. These predicate results feed compatible scalar/text methods, retaining false and source/operand/result snapshots; one operand is required before effects. Complete domain/context/portable admission remains separate.
- **Example**: over `/(\S+)/`, `starts_with(entry_group(0), "foo")` on `foobar` → `[1]`.

### `ends_with(s, suffix)`
- **Signature**: `ends_with(value: scalar, suffix: scalar)`
- **Returns**: numeric flag `1` or `0` on the checked backends.
- **Behavior**: Returns true if the value ends with the exact suffix string. Undefined value or suffix returns false; an empty suffix matches every defined value, including empty text. On Perl/Rust/Dart/Julia/Lua, `"abc".ends_with("c").cat("!")` → `"1!"` and `"abc".ends_with("z").cat("!")` → `"0!"`; this predicate family also has targeted selected/pipeline/function/default String coverage.
- **Example**: over `/(\S+)/`, `ends_with(entry_group(0), "bar")` on `foobar` → `[1]`.

### `contains_substr(s, needle)`
- **Signature**: `contains_substr(value: scalar, needle: scalar)`
- **Returns**: numeric flag `1` or `0` on the checked backends.
- **Behavior**: Returns true if the value contains the needle as a substring. Undefined value or needle returns false; an empty needle matches every defined value, including empty text. On Perl/Rust/Dart/Julia/Lua, `"abc".contains_substr("b").cat("!")` → `"1!"` and `"abc".contains_substr("z").coalesce_nonempty("late").cat("!")` → `"0!"`: false remains present data. The source is captured before its operand, and the predicate before later consumer operands, so their mutations do not recompute the result.
- **Example**: over `/(\S+)/`, `contains_substr(entry_group(0), "oob")` on `foobar` → `[1]`.

The predicate kinds above matter for numeric continuations. A false text predicate
such as `starts_with("abc","z").copy().add(1)` yields `1`. A false regex result
such as `matches("abc",/^z/).copy().add(1)` yields `1` on Perl and null on the native
peers, whose Boolean result is outside the strict numeric domain. Compatible
`cat("!")` renders false flags as `"0!"` on all checked backends.

Perl, Rust, Dart, Julia and the checked Lua hosts retain actual-kind and rejection
guards through canonical two-operand free predicates and ordinary one-operand prefixes:

```text
starts_with("abc","z").take(1)                    # undef
"abc".ends_with("z").take(1).with(){return("ran")} # undef; body skipped
"abc".matches(/^z/).cat("x").split(",").set_key("k",1).with(){return("ran")} # undef
starts_with("abc","z").cat(",x").split(",").last().uppercase() # X
contains_substr("abc","z").with(){return([value,value.copy()])} # [0,0]
starts_with("abc","z").add("bad").with(){return("null")} # "null"; body runs
```

Incompatible consumer operands and later bodies stay skipped; completed source
and predicate-operand effects remain. The source is captured before the operand,
and the flag before subsequent consumer operands. Legitimate false, null and empty
results still enter `with`, and an Array returned by the body accepts Array methods.
Literal regex operands retain their existing representation and flags, including
numeric Perl versus Boolean native regex results. Focused guard checks cover
Perl native/fresh emission, Rust/Dart native/restored-spec/generated-plan,
and Julia/Lua native/restored-spec/generated-plan/fresh-module routes. Regenerate
emitted Perl parsers and rebuild applications with the current runtimes. Lua checks
use installed PUC5.5.1/LuaJIT2.1.1788460057; declared5.4 remains separately owned.
Complete text/regex domains, contextual use and portable admission remain separate.

### `replace_substr(s, old, new)`
- **Signature**: `replace_substr(value: scalar, old: scalar, new: scalar)`
- **Returns**: scalar
- **Behavior**: Replaces all literal occurrences of `old` with `new`. Returns undef if any operand is undef. This is a **literal** replacement, not a regex substitution.
- **Edge cases**: If `old` is empty, returns the original value and kind: `replace_substr("ab", "", "X")` → `"ab"`, `replace_substr(0, "", "X")` → numeric `0`. Operands still evaluate once from left to right.
- **Example**: over `/(\S+)/`, `replace_substr(entry_group(0), "-", "_")` on `a-b-c` → `["a_b_c"]`.

### `rm_prefix(s, prefix)`
- **Signature**: `rm_prefix(value: scalar, prefix: scalar)`
- **Returns**: scalar
- **Behavior**: Removes the prefix from the value if present. Returns the original value and kind if the prefix is empty or does not match (`rm_prefix(0, "")` and `rm_prefix(0, "x")` → numeric `0`). Returns undef if value or prefix is undef. Perl native/fresh and Rust/Dart native/restored/plan and Julia/Lua native/plan/fresh typed Array-index controls preserve numeric identity: `items=["zero"]; items[0.rm_prefix("x")]="updated"` updates entry zero. Matched removals produce text and a String `"0"` stays a String key.
- **Example**: over `/(\S+)/`, `rm_prefix(entry_group(0), "lib")` on `libparser` → `["parser"]`.

### `rm_suffix(s, suffix)`
- **Signature**: `rm_suffix(value: scalar, suffix: scalar)`
- **Returns**: scalar
- **Behavior**: Removes the suffix from the value if present. Returns the original value and kind if the suffix is empty or does not match (`rm_suffix(0, "")` and `rm_suffix(0, "x")` → numeric `0`). Returns undef if value or suffix is undef. Perl native/fresh and Rust/Dart native/restored/plan and Julia/Lua native/plan/fresh typed Array-index controls also preserve unmatched numeric suffix identities, while matched removals return text.
- **Example**: over `/(\S+)/`, `rm_suffix(entry_group(0), ".spec")` on `parser.spec` → `["parser"]`.

### `substr(s, start, length?)`
- **Signature**: `substr(value: scalar, start: int, length: int?)`
- **Returns**: scalar
- **Behavior**: Returns a substring of `value` starting at zero-based `start`. When `length` is supplied,
  returns at most that many characters; when omitted, returns from `start` through the end.
- **Edge cases**: Returns undef if `value` or `start` is undef. Perl/Rust also return undef for an explicitly supplied undef length; an omitted length still selects through the end. Negative or non-integer `start` is normalized
  to `0`; negative or non-integer `length` is normalized to `0`. Rust native/restored/plan controls retain eager operand order and these null/fractional boundaries; dedicated named-target regex mutation stays separate. Dart also normalizes fractional numeric offsets to zero, while preserving its current explicit-null-width-as-omitted and Boolean-offset-as-invalid-zero conventions. Julia also treats an explicit null width as omitted, but retains its current Boolean offset1. Lua on available PUC5.5.1/LuaJIT preserves the same null-width-as-omitted/Bool-invalid0 conventions as Dart. Lua now clips a large positive width before addition: `substr("abc",1,9223372036854775807)` gives `"bc"` on both hosts; Dart/Julia large-slice arithmetic has separate open owners. These input domains differ across backends and remain scheduled for reconciliation before portable admission; large-slice overflow remains separately tracked. Other backend domain/admission checks remain open.
- **Example**: over `/(\S+)/`, `substr(entry_group(0), 1, 3)` on `abcdef` → `["bcd"]`.

### `substr(target, pattern, replacement, flags)` / `regex_subst(...)`
- **Signature**: `substr(target, pattern: regex-or-scalar, replacement: scalar, flags: scalar)` or
  `regex_subst(target, pattern, replacement, flags)`
- **Returns**: no value; mutates the named scalar target.
- **Behavior**: Applies regex substitution to the current scalar target value. `g` performs global replacement;
  `i`, `m`, `s`, and `x` are regex flags; `o` is accepted as a compatibility no-op. Replacement strings can use
  `$0` for the whole match and numbered capture references such as `$1`.
- **Boundary**: This is the legacy statement-style mutation form used by shipped specs. It is intentionally
  separate from pure `substr(value, start, length?)` character slicing and from literal `replace_substr(...)`.
- **Example**: `substr(value, '"|\s', "", go)` removes quotes and whitespace from `value` in place. Single quotes
  keep the embedded double quote readable; the equivalent double-quoted pattern remains valid.

### `split(target, source, delimiter)`
- **Signature**: `split(target, source: scalar, delimiter: regex-or-scalar)`
- **Returns**: replaces the named explicit array target. Lua value-position calls also return an independent updated Array; other backend return forms remain under review.
- **Behavior**: Uses the same literal, regex, Unicode-empty-delimiter, and empty-field policy as pure
  `split(source, delimiter)`, then stores a copied typed array. The source scalar is not mutated. Lua preserves false as delimiter text "0", so `split(parts,"a0b",false)` stores `["a","b"]`.
- **Boundary**: Three arguments select target mutation; two arguments remain the pure split expression. An
  ordinary dropped split call is simply a discarded pure expression.

### String receiver-dot value chains
- **Signature**: `string_expr.method(args...).next(args...)`
- **Returns**: the documented return value of the final helper. After `split`, ordinary `first`/`last` select an entry whose actual kind can feed compatible scalar/container methods on all five backends; Lua host qualification is described in [Lua integration](../public-api/integration-lua.md#select-a-runtime-and-matching-native-products).
- **Behavior**: A compatible string receiver feeds into the first pure string helper, and each helper's return
  value feeds the next compatible helper. A bare receiver such as `raw.trim()` reads the working value `raw`.
  String literals may
  be receivers too: `"abcdef".substr(1, 3).uppercase()` is equivalent to
  `uppercase(substr("abcdef", 1, 3))`.
- **Allowed scalar-value links**: `trim`, `lowercase`, `uppercase`, `replace_substr`, `rm_prefix`,
  `rm_suffix`, `substr`, `cat`, and `coalesce_nonempty`. The old `concat` spelling is retired.
- **Allowed array bridge**: `split(delim)` returns an array and may continue through compatible array
  receiver helpers, for example `raw.trim().split("-").trim_each().lowercase_each().join_values("|")`.
- **Numeric result link**: `length` returns a number. Ordinary Perl/Rust/Dart/Julia/Lua chains can feed it to existing compatible scalar/number methods: `"abcd".length().add(2)` → `6`, equivalent to `num_add(length("abcd"),2)`. Array-producing links also support length, such as `[2,1].sorted().length().add(1)` → `3`.
- **Predicate result links**: `starts_with`, `ends_with`, `contains_substr` and `matches` retain their number/boolean results and continue through compatible scalar/text/generic methods and explicit Array bridges on Perl/Rust/Dart/Julia/Lua. Generic definedness/emptiness also continue with the actual result kinds qualified in their entries. Perl/Rust/Dart/Julia/Lua additionally support all six `str_*` receiver counterparts; other-backend/full admission stays separate.
- **Boundary**: `substr(value, start, length?)` here is the pure value substring helper. It is separate from
  any statement-style or host-language substitution idiom. Scalar results reject Array/Hash-only consumers
  until an explicit operation yields a container; the predicate families above reject wrong receiver arities before effects.
- **Block receivers**: An expression-valued block whose value is a string can be the receiver, for example
  `{ " a-b " }.trim().split("-").count()`.

## 3. Array Helpers

> **Worked examples.** Array examples use the same complete two-rule scaffold as the
> Scalar/Numeric examples:
>
> ```text
> demo::
>  -> value .push
>  LX { return(copy(demo)) }
>
> value : /<regex>/
>  I { return(<array-expression>) }
> ```
>
> The top `demo::` rule has no regex; it dispatches to the regex-owning `value:` rule,
> pushes the child value, and returns the accumulator snapshot. Outputs below are therefore
> one-element arrays holding the helper result. Multi-statement examples use the same
> scaffold but put the shown statements inside the `I { ... }` block.

**Verified value examples:**

| Surface | Example | Input | Output |
| --- | --- | --- | --- |
| Construct | `array(entry_group(0), entry_group(1), entry_group(2))` over `/(\w+),(\w+),(\w+)/` | `a,b,c` | `[["a","b","c"]]` |
| Copy | `copy(array(entry_group(0), entry_group(1), entry_group(2)))` over `/(\w+),(\w+),(\w+)/` | `a,b,c` | `[["a","b","c"]]` |
| Splice | `array("tag", flat_array(array(entry_group(0), entry_group(1))))` over `/(\w+),(\w+)/` | `a,b` | `[["tag","a","b"]]` |
| Concatenate | `concat_arrays(array(entry_group(0), entry_group(1)), array(entry_group(2)))` over `/(\w+),(\w+),(\w+)/` | `a,b,c` | `[["a","b","c"]]` |
| Count/select | `count(array(entry_group(0), entry_group(1), entry_group(2)))` / `first(...)` / `last(...)` | `a,b,c` | `[3]` / `["a"]` / `["c"]` |
| Edge slices | `take(..., 2)` / `take_last(..., 2)` / `drop_front(..., 1)` / `drop_back(..., 1)` / `slice(..., 1, 2)` | `a,b,c` | `[["a","b"]]` / `[["b","c"]]` / `[["b","c"]]` / `[["a","b"]]` / `[["b","c"]]` |
| Order | `sorted(array("b", "a", "c"))` / `reversed(array("a", "b", "c"))` | `x` | `[["a","b","c"]]` / `[["c","b","a"]]` |
| Membership | `contains(array("a", "b", "c"), "b")` / `index_of(array("a", "b", "c"), "b")` / missing `index_of(..., "z")` | `x` | `[1]` / `[1]` / `[null]` |
| Emptiness | `is_empty([])` / `is_nonempty(["a"])` | `x` | `[1]` / `[1]` |
| Join | `join_values(",", array("a", "b", "c"))` | `x` | `["a,b,c"]` |
| Split bridge | `entry_group(0).split(",")` over `/(.+)/` | `a,b,c` | `[["a","b","c"]]` |
| Receiver chain | `items.sorted().drop_front(1).first()` after `set(items, ["b", "a", "b", "c"])` | `x` | `["b"]` |
| Pipeline receiver | `items.trim_each().filter_nonempty().join_values("|")` after `set(items, [" a ", "", " b "])` | `x` | `["a|b"]` |

**Verified mutation/pipeline examples:**

| Body inside `value`'s `I { ... }` block | Input | Output |
| --- | --- | --- |
| `set(source, entry_group(0)); split(items, source, /,/); return(copy(items))` over `/(.+)/` | `a,b,c` | `[["a","b","c"]]` |
| `set(items, ["a:b", "c:d"]); split_each(items, ":"); return(copy(items))` | `x` | `[["a","b","c","d"]]` |
| `set(items, [" a ", " b"]); trim_each(items); return(copy(items))` | `x` | `[["a","b"]]` |
| `set(items, ["a", "", undef, "0", "b"]); filter_nonempty(items); return(copy(items))` | `x` | `[["a","0","b"]]` |
| `set(items, ["alpha", "beta", "atom"]); filter_match(items, /^a/); return(copy(items))` | `x` | `[["alpha","atom"]]` |
| `set(items, ["a", "b", "a", "c", "b"]); uniq(items); return(copy(items))` | `x` | `[["a","b","c"]]` |
| `set(items, ["A", "bC"]); lowercase_each(items); return(copy(items))` | `x` | `[["a","bc"]]` |
| `set(items, ["a", "bC"]); uppercase_each(items); return(copy(items))` | `x` | `[["A","BC"]]` |
| `set(value, entry_group(0)); push(items, value); items += "tail"; return(copy(items))` over `/(\w+)/` | `head` | `[["head","tail"]]` |
| `set(value, entry_group(0)); if(is_nonempty(value)) { push(items, value) }; set(value, ""); if(is_nonempty(value)) { push(items, value) }; return(copy(items))` over `/(\w+)/` | `keep` | `[["keep"]]` |

> **Current Perl caveats.** For `split(value, delim)`, prefer receiver form
> `value.split(delim)` or block form `I { return(split(value, delim)) }`. Compact
> lifecycle shorthand `I.return(split(...))` currently routes through an older tagged
> shorthand shape on the Perl reference. For array pipeline helpers (`split_each`,
> `trim_each`, `filter_nonempty`, `lowercase_each`, `uppercase_each`, `uniq`, and
> `filter_match`), return a receiver chain (`items.trim_each()`) or assign/copy the
> named target as shown above; a direct `return(split_each(items, ":"))` is
> shape-sensitive on current Perl and does not document the portable array value.

### `array(e1, e2, ...)`
- **Signature**: `array(elements: expr...)`
- **Returns**: array
- **Behavior**: Constructs a new array from the given elements. Elements are evaluated in order.

### `array_copy(arr)`
- **Signature**: `array_copy(arr: array)`
- **Returns**: array
- **Behavior**: Returns a shallow copy of the array. The new array contains the same elements but is a distinct container.
- **Compatibility**: `array_values(...)` and `array_copy(...)` are retired on current runtimes — use `copy(...)`.
- **Terse spelling**: `copy(arr)` is the canonical spelling — one unified `copy(...)` subsumes both legacy array
  and hash copy forms and dispatches from the current runtime value kind. See
  [Terse Helper Renames](#terse-helper-renames-canonical-going-forward).

### `flat_array(arr)`
- **Signature**: `flat_array(arr: array)`
- **Returns**: list (splices into parent context)
- **Behavior**: Flattens an array into list context for insertion into a parent container. Used with `hash(...)`, `array(...)`, and lifecycle accumulator returns.

### `concat_arrays(a1, a2)`
- **Signature**: `concat_arrays(a: array, b: array)`
- **Returns**: array
- **Behavior**: Returns a new array containing all elements of `a1` followed by all elements of `a2`. Neither input is mutated.

### `push(Child)` / `push(Child, target)`
- **Signature**: `push(child_rule: rule[, target: array])`
- **Returns**: explicit-target form returns an updated array snapshot; the implicit form has no portable expression result yet
- **Behavior**: Calls `Child` and appends the child result to an accumulator array. With one argument, the target is the current rule's implicit accumulator; with a second bare identifier, that identifier is the target accumulator. Use `push(Child)` as a statement: Perl currently leaks the host push count while Lua returns the updated implicit accumulator. `push(Child, target)` evaluates to an independent snapshot of the updated explicit target.
- **Convention**: The all-bare child-call forms keep precedence: `push(Child)`, `push(Child, target)`, `push(Child, index)`, and `push(Child, target, index)` are parser child-call helpers.
- **Action-edge fluent form**: after `-> Child`, `.push(target)` uses the edge's `Child` as the child rule and appends its return value to `target`; `.push(Child, target)` is the explicit child-and-target spelling used inside gated fluent chains.

### `push(Child, index)` / `push(Child, target, index)`
- **Signature**: `push(child_rule: rule, index: int)` or `push(child_rule: rule, target: array, index: int)`
- **Returns**: explicit-target form returns an updated array snapshot; the implicit form has no portable expression result yet
- **Behavior**: Calls `Child`, selects one element from the child result, and appends that element to the implicit or explicit accumulator. Use implicit indexed push as a statement; the explicit-target result is an independent snapshot of the updated accumulator.
- **Edge cases**: The disambiguation relies on integer matching before bare target-name matching. `push(Child, 0)` means index 0 into `Child`'s result; `push(Child, target, 0)` appends index 0 to `target`.

### `push(arr, value)`
- **Signature**: `push(target: array, value: expr)`
- **Returns**: updated array snapshot
- **Behavior**: Terse explicit-value append. Lowers identically to the array append operator for unambiguous value expressions, mutates the named target, and evaluates to an independent snapshot of the update.
- **Examples**: `push(items, "a")`, `push(items, value)`, `push(items, cat("a", "b"))`, and `push(items, call(Child))`.
- **Disambiguation**: For `push(A, B)` with two bare identifiers, a registered static rule `A` keeps child-call
  precedence. Otherwise `A` is the array binding and `B` is the appended working value. `items += value` is the
  unambiguous operator spelling when the author wants to emphasize mutation.

A completed append snapshot can be read on Perl with an explicit value binding:
`saved = push(items, "tail"); saved.coalesce(undef)[-1].uppercase()` yields `"TAIL"`.
Perl, Rust, Dart and Julia support direct result reads and fluent continuations from these append
snapshots. Installed PUC Lua5.5.1 and LuaJIT also support these direct reads and
fluent forms; declared Lua5.4 admission remains separate in the backend handoff.
Perl also accepts direct Hash and nested Array/Hash
payloads in value positions, for example `saved = push(items, {"name":"tail"})`.
Payload value blocks keep local returns scoped, and later updates preserve the
saved snapshot. Regenerate affected previously emitted Perl parsers with the
updated builder. Existing Array end-mutation methods and child-push forms retain
their contracts.

Perl, Rust, Dart and Julia direct reads use an unambiguous explicit value call:

```text
Value::
 I {
   items = [];
   out = push(items, " a ")[-1].trim().uppercase();
   return([out, items]);
 }
```

This returns `["A", [" a "]]`. The target updates once and the read consumes its
updated snapshot. Further selectors retain each selected value's actual kind:
`push(items, {"k":["head","tail"]})[-1]["k"][-1].uppercase()` returns `"TAIL"`.
`push(items, false)[-1].not()` returns true, and
`push(items, {0})[-1].add(1)` returns `1`.

For direct result composition, the target is a bare working name and the call has
exactly two arguments. Use an explicit value block for a variable or numeric
operand, for example `push(items, {payload})[-1]` or `push(items, {0})[-1]`.
The all-bare and numeric-literal spellings retain their child-push disambiguation.
Signed and nested reads, missing-path nulls and compatible continuations follow
the ordinary read rules. Empty strings skip defined-only defaults. A source
mutation error propagates before a default can replace a missing selection.

Perl, Rust, Dart and Julia can also continue directly through compatible value methods:

```text
push(items, "tail").last().uppercase()          # "TAIL"
push(items, "tail").copy().last().uppercase()   # "TAIL"
push(items, [3,1]).last().sorted().last().add(4) # 7
```

Each call appends once. The chain receives the resulting snapshot before later
consumer operands run. A selected Hash or Array uses its own method family;
`with` bodies can return another kind for further reads or methods. For example,
`push(items, "tail").with(){return(false)}.coalesce(true)` retains false.
Copy, logical operations, defaults, local returns and function-local bindings keep
their ordinary contracts. Source mutation failures propagate before consumers.

An incompatible container method returns null before its operands run:
`push(items, "tail").set_key("k", 1)` is null because the snapshot is an Array;
`push(items, false)[-1].take(1)` is null because the selected value is a Bool.
The append still happens once. Existing static rule names keep child-push
precedence. Rebuild Rust, Dart, Julia and Lua applications with the updated runtime.

### `items += value`
- **Signature**: `target += value: expr`
- **Returns**: updated array snapshot in value positions; side-effect-only behavior when used as a statement.
- **Behavior**: Array append operator. Lowers/runs identically to explicit append forms, mutates the named working array, and reads a bare RHS identifier as a scalar working variable. In value positions it evaluates to the updated array snapshot after the push.
- **Examples**: `items += "a"`, `items += cat("a", "b")`, and `items += value`.
- **Edge cases**: The target is an array working value and auto-exists when the mutation contract permits creation.
  A bare RHS such as `items += value` reads the current typed value of `value`; reserved literals such as `true`,
  `false`, and `undef` keep their literal meaning.

### `items.push_back(value)` / `items.push_front(value)` / `items.pop_back()` / `items.pop_front()`
- **Signature**: `target.push_back(value: expr)`, `target.push_front(value: expr)`, `target.pop_back()`, `target.pop_front()`
- **Returns**: an independent updated array snapshot.
- **Behavior**: Array end mutations on a named working array. `push_back` appends, `push_front` prepends,
  `pop_back` removes the last element, and `pop_front` removes the first element. Pop methods discard the removed
  value; their expression result is the updated array, not the removed item. An unused result is silently dropped.
- **Examples**: `items.push_back("tail")`, `items.push_front(value)`, `items.pop_back()`, `items.pop_front()`.
- **Edge cases**: The receiver is the bare array working value (`items`) and auto-exists as an array when the
  mutation contract permits creation. A bare push value reads a working variable, just like `items += value`.
  An existing non-array target raises `binding_kind_mismatch`. Saved results are independent snapshots, and a
  compatible continuation consumes the update; for example, `items.push_back(value).count()` yields the new count.
- **Worked example**:
  ```text
  Top::
   -> Done {
    set(value, "b")
    items.push_back("a")
    items.push_back(value)
    items.push_front("z")
    items.pop_back()
    items.pop_front()
    return(copy(items))
   }

  Done:
   /[a-z]+/
  ```
  On input `xhello`, the result is `["a"]`: the push methods build `["z", "a", "b"]`, then `pop_back()`
  removes `"b"` and `pop_front()` removes `"z"`.

### `count(arr)`
- **Signature**: `count(arr: array)`
- **Returns**: int
- **Behavior**: Returns the number of elements in the array. The reference returns `0` for non-array or undef input; Rust's current String exception is qualified below. Ordinary Perl/Rust/Dart/Julia/Lua chains preserve the numeric result for compatible scalar/number methods: `[1,2].count().add(3)` → `5`, `[].count().add(1)` → `1`, and `[1,2].count().cat(" items").uppercase()` → `"2 ITEMS"`. These count/length/key-count receiver methods take zero extra operands; Perl/Rust/Dart/Julia/Lua reject invalid shapes before source/operand effects.


Count source/prefix campaign73 covers canonical free-one and ordinary
zero-operand receiver chains. Baseline reference probes exposed incompatible
container consumers running Hash-key/value effects and later `with` bodies after
Count's numeric result. Perl source blocks now use their existing value owner on
free and direct receiver paths. Bounded Perl, Rust, Dart, Julia and installed Lua Count continuations guard each consumer
by its actual kind.
Numeric0, compatible scalar/default/Array bridges, source snapshots and valid
zero/null/Array-returning `with` controls already work in the selected examples.
The primary backend repairs have focused checks on their recorded routes/hosts; copy/source-domain/rejection combinations have
a mandatory follow-up under existing Count/copy authority. No source-domain,
copy-depth, signature/context or portable-admission expansion follows from this
frozen target.


Canonical Perl Count accepts mutation-yielding and computed source blocks:

```text
items=[]; count({push(items,"a")})       # 1; items is ["a"], pushed once
items=[]; {push(items,"a")}.count()     # same direct receiver result
count({items="text";push(items,"x")}).coalesce("masked")
# binding_kind_mismatch at execution; the default cannot mask the source error
```

The source runs once before later consumers. Needed source errors propagate on
native and freshly emitted Perl paths; numeric0, existing non-array Count zero
fallback, function/binding scope and snapshots stay. Regenerate emitted Perl.
Canonical Perl, Rust, Dart, Julia and installed Lua Count chains reject incompatible consumers before evaluating their
operands. Rejection also skips later immediate `with` bodies; a valid null result
still enters `with`.

```text
order="";
out=count({order=cat(order,"S");["a"]}).take({order=cat(order,"A");1}).with(){order=cat(order,"W");return("ran")}
# out is undef; order is "S": source runs, rejected operands/body do not

count([]).with(){return(value.add(1))}              # 1: zero is valid data
count([]).add("bad").with(){return("null")}       # "null": valid null enters
count([]).cat(",x").split(",").last().uppercase() # "X": explicit Array bridge
```

The bounded follow-up assessment has identified remaining defects. Perl currently
loses Count rejection across copy/default/with and its separate logical-producer
folding route, including a no-copy logical continuation. Rust currently counts
non-array Strings/Numbers/Booleans/nonempty Hashes instead of applying the source
zero fallback. Dart/Julia/installed Lua currently return null for initial Boolean
receiver Count where the reference returns Number0. These have concrete P1 repair
owners before unrelated selection; the primary guard checks do not close them.
Legitimate null must still enter with, and copied/produced Boolean values keep
their existing Array-only rejection. Full family/portable admission remains open.

An initial Count keeps its existing source policy. A value already produced by
Count keeps its actual Number kind: `count(["a"]).count()` and
`["a"].count().count()` reject the second Array-only consumer. Rejection skips
later `with` bodies; copying a legitimate null retains the existing null guard.
These distinctions are checked on native and emitted Perl/Rust/Dart routes and fresh Julia/Lua modules on the recorded installed hosts.

Rust currently returns `4` for both `count("text")` and `"text".count()`, while
the Perl reference returns zero. The guard repair preserves that observed source
behavior; mandatory Count/copy source-domain assessment73.6 owns the discrepancy.
Use Array inputs for portable Count behavior. Full family/context admission
remains separate from these focused backend checks.

The same guards apply to ordinary zero-operand `.count()` prefixes. Count's
existing non-array zero source policy and existing guarded copied-null behavior
remain separate; this repair does not normalize them. Copy/rejection combinations
and other backends have independent assessment owners. Regenerate affected Perl
parsers to obtain the repaired continuation lowering.

### `first(arr)`
- **Signature**: `first(arr: array)`
- **Returns**: scalar
- **Behavior**: Returns the first element. Returns undef for empty array or non-array input.

### `last(arr)`
- **Signature**: `last(arr: array)`
- **Returns**: scalar
- **Behavior**: Returns the last element. Returns undef for empty array or non-array input.

### `take(arr, n)`
- **Signature**: `take(arr: array, n: int = 1)`
- **Returns**: array
- **Behavior**: Returns the first `n` elements as a new array. When `n` is omitted, returns the first element as an array.
- **Edge cases**: If `n` > array length, returns the entire array. Returns an empty array for non-array input.

### `take_last(arr, n)`
- **Signature**: `take_last(arr: array, n: int = 1)`
- **Returns**: array
- **Behavior**: Returns the last `n` elements as a new array.
- **Edge cases**: If `n` > array length, returns the entire array.

### `drop_front(arr, n)`
- **Signature**: `drop_front(arr: array, n: int = 1)`
- **Returns**: array
- **Behavior**: Returns a new array with the first `n` elements removed. When `n` is omitted, drops 1 element.
- **Compatibility**: `tail(...)` is a retired alias.

### `drop_back(arr, n)`
- **Signature**: `drop_back(arr: array, n: int = 1)`
- **Returns**: array
- **Behavior**: Returns a new array with the last `n` elements removed.
- **Compatibility**: `drop_last(...)` is a retired alias.

### `slice(arr, start, n)`
- **Signature**: `slice(arr: array, start: int, n: int?)`
- **Returns**: array
- **Behavior**: Returns elements from index `start`. When `n` is provided, returns up to `n` elements. When `n` is omitted, returns from `start` to the end.
- **Edge cases**: If `start` exceeds array length, returns empty array.

### `sorted(arr)`
- **Signature**: `sorted(arr: array)`
- **Returns**: array
- **Behavior**: Returns a new array sorted in ascending (string/lexicographic) order. Does not mutate the input.
- **Perl scope and kinds**: Working variables and function parameters named `a` and `b` remain ordinary
  legal names. Sorting isolates its comparator inputs and preserves Number/String/Bool/null kinds;
  comparison does not convert stored numbers to strings. Regenerate older emitted Perl parsers.

```text
a="same"; b="same";
items=[3,1]; out=items.sorted();
return([out,items,a,b]);          # [[1,3],[3,1],"same","same"]
array(3,1).sorted().last().add(4)  # 7
sorted([2,"10",1])               # [1,"10",2] (lexicographic)
```


### `reversed(arr)`
- **Signature**: `reversed(arr: array)`
- **Returns**: array
- **Behavior**: Returns a new array in reverse order. Does not mutate the input.

### `array(e1, e2, ...)`
- **Signature**: `array(values: expr...)`
- **Returns**: array
- **Behavior**: Constructs an array from evaluated values. Quoted strings are literal payloads, so
  `array("items")` constructs `["items"]`; zero and multiple arguments are also valid constructors.
- **Boundary**: Exact `array(IDENTIFIER)` is a removed selector shape, not a one-element constructor. Use the bare
  identifier to read its typed value or `[identifier]` to construct one element. All five backends reject the
  removed shape before execution.
- **Function values**: Multi-argument `array(value, value)` reads parameter/local values just like `[value, value]`.
  See the [executed function example](../dsl/value-container-flow-helper-reference.md#array-constructors-inside-functions).

Retained ordinary constructor values support direct reads and guarded methods on
Perl, Rust, Dart, Julia and installed PUC Lua/LuaJIT. Incompatible container
consumers return null before their arguments or later `with` bodies run. Legitimate
empty/null results still enter `with`:

```text
array("head","tail")[-1].uppercase()       # "TAIL"
hash("k",["head","tail"])["k"][-1].uppercase() # "TAIL"
array("tail").set_key("k",1)                # null
hash("k","tail").take(1)                   # null
array("tail").take(0).with(){return(value.count())} # 0
array("tail").with(){return(undef)}.with(){return("recovered")} # "recovered"
```

Source and needed constructor arguments run once before consumers. Compatible
intermediate links retain actual-kind guards; rejection skips subsequent bodies.
Regenerate affected emitted Perl parsers and rebuild Rust/Dart/Julia/Lua applications/runtime.
Lua checks use PUC5.5.1/LuaJIT; declared5.4 and full admission remain open. Existing
element/pair/list-splice, bare-key and selector retirement rules remain in force.


### Array receiver-dot value chains
- **Signature**: `array_expr.method(args...).next(args...)`
- **Returns**: the documented return value of the final helper. `first`/`last` preserve the selected entry's kind; their ordinary compatible continuations are implemented on all five backends. Lua checks use available PUC5.5.1/LuaJIT; declared5.4 verification stays open.
- **Behavior**: A compatible array receiver feeds into verified array helper chains. Pure array links compose
  through later pure links and selection, for example `items.sorted().drop_front(2).first()` is equivalent to
  `first(drop_front(sorted(items), 2))`. Pipeline links compose through pipeline/terminal continuations that are
  locked by the runtime, for example `items.uniq().join_values(",")` and
  `phrases.split_each("-").filter_match(/^aa$/).count()`.
- **Allowed array-returning links**: `copy`, `sorted`, `reversed`, `take`, `take_last`,
  `drop_front`, `drop_back`, `slice`, `concat_arrays`, `split_each`, `trim_each`, `filter_nonempty`,
  `lowercase_each`, `uppercase_each`, `uniq`, and `filter_match`.
- **Numeric result links**: `count`/`length` feed compatible scalar/number methods; `[1,2].count().add(3)` returns `5`. Perl/Rust/Dart/Julia/Lua `index_of` also feeds compatible scalar/number methods on recorded hosts; declared5.4/full admission stays open. Generic emptiness/definedness results also continue through compatible consumers with their existing result kinds. Perl/Rust/Dart/Julia/Lua `contains` also feeds compatible scalar/text/generic methods, retaining numeric false through nonempty defaults.
  `join_values` returns a String; ordinary Perl/Rust/Dart/Julia/Lua continuations work on recorded hosts; declared5.4/full admission remain open. The six numeric reducers feed compatible scalar/number methods. Receiver-dot
  `items.join_values(delim)` keeps the helper's canonical delimiter-first contract: it maps to
  `join_values(delim, items)`. Receiver-dot numeric reducers such as `scores.sum()` and `scores.min()` are
  array-consuming links over the same numeric aggregate helpers. Ordinary Perl/Rust/Dart/Julia/Lua results continue into compatible scalar/number methods: `scores.sum().add(1)` equals `num_add(num_sum(scores),1)`. Lua checks use available PUC5.5.1/LuaJIT; declared5.4/full admission remains open.
- **Boundary**: `split(value, delim)` belongs to the scalar/string receiver family because its receiver is the
  string being split. Numeric reducer results on ordinary Perl/Rust/Dart/Julia/Lua feed scalar/number methods; array-only consumers stay invalid until an explicit String split
  produces an array. Full context/portable admission remains open; existing helper source domains stay unchanged. Named end mutations (`push_back`, `push_front`,
  `pop_back`, `pop_front`) update their binding and may feed a compatible continuation from the returned array.
  They are not pure links over arbitrary temporary array receivers. The portable contract does not
  promise every possible pipeline-to-pure continuation; use verified chains such as
  `items.uniq().join_values(",")`, `items.filter_match(/^a/).count()`, or pure chains such as
  `items.sorted().drop_front(1).first()`.
- **Block receivers**: An expression-valued block whose value is an array can be the receiver, for example
  `{ [3, 1, 2] }.sorted().join_values(",")`. A block-local `return(array_expr)` yields the receiver value and
  skips later block statements before the array chain runs.

### Array-tree receiver block traversal: `walk_leaves`, `map_leaves`, `reduce_leaves`
- **Signatures**:
  - `array_expr.walk_leaves() { block }`
  - `array_expr.map_leaves() { block }`
  - `array_expr.reduce_leaves(initial_acc: expr) { block }`
- **Returns**:
  - `walk_leaves` returns the original array tree after running callbacks.
  - `map_leaves` returns a new array tree with the same nested-array structure and each leaf replaced by the
    callback result.
  - `reduce_leaves` returns the final accumulator.
- **Backend status**: Perl reference support landed under `SPEC-FORMAT-TERSE.13.2`; Rust interpreter and
  generated-oracle parity landed under `SPEC-FORMAT-TERSE.13.3`. Dart, Julia, and Lua also support the contract;
  Lua's shared root-kind dispatcher and exact Perl oracle proof pass 114/114 on both Lua ABIs.
- **Tree shape**: The receiver must be an array. Nested arrays are interior nodes. Scalar values and hash values
  are leaves; hash values are not traversed recursively by this surface.
- **Traversal order**: Depth-first by zero-based array index. For `["a", ["b", "c"], { "h" : "H" }]`, callbacks
  run for paths `0`, `1/0`, `1/1`, then `2`.
- **Callback bindings**: Each callback runs immediately in the caller's current action/runtime context with scoped
  scalar bindings:
  - `value`: current leaf value.
  - `index`: zero-based index of the leaf in its parent array.
  - `path`: array value containing root-to-leaf indexes.
  - `depth`: number of path segments.
  - `acc`: current accumulator for `reduce_leaves` only.
- **Binding restoration**: The traversal restores those scoped names after each callback and after traversal
  completes, including callback errors. Inputs, paths, mapped results, and accumulator values are copied, so
  callback mutation cannot alias the source. Mutations to other working variables are ordinary side effects and
  persist.
- **Edge cases**: A non-array receiver yields `undef` and does not execute the callback or evaluate the reduce
  initial. Empty arrays run no callbacks; `reduce_leaves(initial)` returns the initial accumulator. `walk_leaves()` and
  `map_leaves()` take no parenthesized arguments. `reduce_leaves(initial)` requires exactly one parenthesized
  initial accumulator expression. `walk_leaves()` and `map_leaves()` can feed later compatible array receiver links
  such as `.count()`. Perl/Rust/Dart/Julia/Lua ordinary reduction results now continue by their actual kind: `[1,[2,3]].reduce_leaves(0) { return(acc.add(value)) }.add(1)` → `7`; `[1,[2,3]].reduce_leaves([]) { return(concat_arrays(acc,[value])) }.last().add(1)` → `4`; and `[].reduce_leaves(false) { return(true) }.cat("!")` → `"0!"`. Reduced containers also feed immediate traversals: `[1,[2]].reduce_leaves([]) { return(concat_arrays(acc,[value])) }.map_leaves() { return(value.add(1)) }.last()` → `3`. Source, initial and callbacks run before compatible consumer operands; callback bindings restore first. Wrong-family consumers retain that valid prefix and skip their operands. Perl native/fresh emitted, Rust/Dart native/restored/in-process plan and Julia/Lua native/plan/fresh emitted checks pass. Lua uses safe PUC5.5.1/LuaJIT; declared5.4 and full signature/context/portable admission remain separate. Nesting in an outer helper or saving a result is still available. Malformed initial-argument counts run no effects; current Perl returns null and Rust/Dart/Julia report compile-time `callable_contract_arity_mismatch`, and Lua raises its existing runtime arity error before source effects. Diagnostic-phase parity remains open.
- **Examples**:
  - After `set(items, ["a", ["b", "c"]])`,
    `return(items.map_leaves() { return(cat(join_values("/", path), "=", value)) })`
    yields `[["0=a",["1/0=b","1/1=c"]]]` through the standard `demo::` wrapper.
  - After `set(items, ["a", ["b", "c"]])`,
    `set(out, items.walk_leaves() { paths += join_values("/", path); return(value) }); return(copy(paths))`
    yields `[["0","1/0","1/1"]]`.
  - After `set(items, ["a", ["b", "c"]])`,
    `return(items.reduce_leaves(0) { return(acc.add(1)) })` yields `[3]`.
  - `return(items.map_leaves() { return(value) }.count())` yields `[2]`: the top-level mapped array has two
    elements, even though traversal visited three leaves.

### Five-backend receiver mutation: `map_leaves!`

- **Signature**: `binding_name.map_leaves!() { block }`
- **Returns**: a detached copy of the updated harray or array root; the named receiver is also rebound atomically.
- **Backend status**: current on Perl under `FUTURE-PARITY-BACKLOG.19.2.2`, Rust under `.19.3.2`, Dart under
  `.19.4.2`, Julia under `.19.5.2`, and shared Lua under `.19.6.2` on PUC Lua and LuaJIT. `.19.7` admits the exact
  portable capability row, `.19.8` completes exact six-runtime recurrence, and `.19.9` closes current public
  no-drift.
- **Addressability**: `binding_name` must be one existing, non-reserved, bare uniform binding that holds an harray
  or array. Literals, temporaries, helper results, bracket/property receivers, function-form `map_leaves!(tree)`,
  other bang methods, and arbitrary user-defined `name!` functions are not valid v1 forms.
- **Traversal and replacement**: the starting root kind determines recursion. An harray root recurses only through
  harrays in sorted-key depth-first order, treating arrays as leaves. An array root recurses only through arrays in
  index order, treating harrays as leaves. The runtime walks a detached snapshot of the original shape. Each block
  result replaces its leaf; a returned container of the root kind is not revisited during this call.
- **Callback bindings**: every callback receives detached `value`, complete copied `path` (also `@path` on Perl),
  `depth`, and `key` for harray roots or `index` for array roots. Changing `value` alone does not update the receiver; return the
  desired replacement. Ordinary effects on unrelated bindings remain visible.
- **Receiver protection**: callback code may not directly mutate the receiver binding. Direct assignment, bracket
  write, nested `map_leaves!`, `set`, `set_key`, `push`, `push_front`/`push_back`/`pop_front`/`pop_back`, and a
  binding-target array pipeline such as `trim_each(items)` fail with `receiver_mutation_reentrant` before writing.
  A distinct scoped binding with the same spelling is allowed because identity, not text, is guarded.
- **Atomicity and continuation**: callback or re-entrant failure leaves the receiver unchanged and releases the
  guard. Complete callback success publishes the rebuilt receiver once. Only then may the detached result enter a
  continuation such as `.count()` or `.count_keys()`. A later continuation failure cannot roll back the commit.
- **Examples**:
  - Harray root: `tree = { "a" : "A", "nested" : { "b" : "B" } }; tree.map_leaves!() {
    return(lowercase(value)) }` leaves `tree` as `{ "a" : "a", "nested" : { "b" : "b" } }`.
  - Array root: `items = ["A", ["B"]]; count = items.map_leaves!() { return(lowercase(value)) }.count()` leaves
    `items` as `["a", ["b"]]` and stores `2` in `count` because the continuation counts top-level elements.
  - Callback-local nested write: for `tree = { "leaf" : [] }`, `tree.map_leaves!() {
    value[0]["name"] = "normalized"; return(value) }` commits
    `{ "leaf" : [{ "name" : "normalized" }] }` without revisiting the new array/hash content.
  - Forbidden receiver write: `tree.map_leaves!() { tree["x"] = value; return(value) }` fails before modifying
    `tree`. Writing an unrelated `journal["seen"][0] = path` remains ordinary and independent.

### `contains(arr, needle)`
- **Signature**: `contains(arr: array, needle: scalar)`
- **Returns**: numeric flag `1` or `0` on the five current backends. Nested compatible consumers work: `cat(contains(["a"],"a"),"!")` gives `"1!"`, and `cat(coalesce_nonempty(contains(["a"],"z"),"late"),"!")` gives `"0!"`. Ordinary Perl/Rust/Dart/Julia/Lua result methods now work: `["a"].contains("a").cat("!")` gives `"1!"`, `["a"].contains("z").coalesce_nonempty("late").cat("!")` gives `"0!"`, and `["a"].contains("a").cat(",x").split(",").last().uppercase()` gives `"X"`. The actual scalar result feeds compatible scalar/text/generic methods; container-only consumers return undef until an explicit bridge yields a container. One needle is required before effects on Perl/Rust/Dart/Julia/Lua; missing/extra calls return undef, including bare `.contains` and nested Array elements. Rust/Dart/Julia/Lua capture the Array value before needle effects; rebinding it inside the needle does not change the searched values. The five current backends distinguish null from empty text in membership: `[undef].contains("")` and `[""].contains(undef)` return `0`, while `[undef].contains(undef)` returns `1`. `[undef].contains("").add(2)` returns `2`, using the actual numeric flag. Lua checks use available PUC5.5.1/LuaJIT; declared5.4/full admission remains separate.
- **Behavior**: Returns true if the array contains the needle value. Works on direct arrays and projected expressions (`sorted_keys(...)`, `sorted_values(...)`).
- **Edge cases**: Returns false for non-array or undef input.

Perl, Rust, Dart, Julia and Lua retain actual-kind and rejection guards through
canonical two-operand free membership calls and ordinary one-needle prefixes:

```text
contains(["a"],"z").take(1)                       # undef
["a"].contains("z").take(1).with(){return("ran")}  # undef; body skipped
["a"].contains("z").cat("x").split(",").set_key("k",1).with(){return("ran")} # undef
contains(["a"],"z").cat(",x").split(",").last().uppercase() # X
contains(["a"],"z").with(){return([value,value.copy()])} # [0,0]
contains(["a"],"z").add("bad").with(){return("null")} # "null"; valid null enters with
```

Completed source and needle effects remain; incompatible consumer operands and
later bodies are skipped. Legitimate false, null and empty results still enter
`with`, and an Array returned by its body accepts Array methods. Each native peer
is assessed independently.

Perl accepts computed value blocks as canonical `contains` operands, including a
block whose last operation is `push`:

```text
items=[]
contains({push(items,"a")},"a")  # 1; items is ["a"], pushed once
contains({push(items,"a");items},"a") # 1; explicit last-variable form also works
contains(["a"],{cat("","a")})    # 1; computed needle
contains({items="text";push(items,"x")},"a").coalesce("masked")
# binding_kind_mismatch at execution; the default cannot mask the source error
```

The source completes before the needle. A source error stops needle evaluation;
needle errors also propagate before later defaults or `with` bodies. Native and
freshly emitted Perl follow these rules; regenerate existing emitted parsers.

Perl, Rust, Dart, Julia and Lua selected, free, literal and block null sources
return numeric `0` and still evaluate the needle. For example, with `order=""`,
`{undef}.contains({order=cat(order,"O");"a"}).cat("!")` returns `"0!"` and leaves
`order` as `"O"`. Capturing a null source before a needle that creates an Array
still searches the captured null value. This membership rule grants no other
Array method a nullable receiver.

Ordinary Perl/Rust/Dart/Julia/installed Lua preserve nullable membership after copy.
`{undef}.copy().contains(needle)`, `copy({undef}).contains(needle)` and
`contains(copy({undef}),needle)` evaluate the needle once and return numeric0.
Repeated copies and copied legitimate null results from `with` or numeric methods
retain this behavior, including needed needle errors. These checked canonical
membership/copy chains retain rejection with and without `with`:

```text
order="";
out=contains(["a"],"z").take({order=cat(order,"A");1}).copy()
  .contains({order=cat(order,"N");"a"})
  .with(){order=cat(order,"W");return("ran")};
# out=undef, order=""; rejected take/needle/body effects stay skipped

order="";
out=contains(["a"],"z").add("bad").copy()
  .contains({order=cat(order,"N");"a"});
# out=0, order="N"; legitimate copied null still evaluates its needle
```

Regenerate emitted Perl parsers and rebuild Rust/Dart/Julia/Lua apps/runtime. Lua
checks use installed PUC5.5.1/LuaJIT; declared5.4 remains open. Equality, numeric
flags, null/empty distinction, copy depth and snapshots stay; full source/context/
portable admission remains open.

### `index_of(arr, needle)`
- **Signature**: `index_of(arr: array, needle: scalar)`
- **Returns**: int or undef. Ordinary Perl/Rust/Dart/Julia/Lua compatible scalar/number continuations are targeted-checked (Lua: available PUC5.5.1/LuaJIT; declared5.4/full admission open): `["a","b"].index_of("b").add(1)` returns `2`, while `.index_of("b").cat("!")` returns `"1!"`. The receiver requires one needle; missing/extra shapes return undef before source/operand effects. Declared5.4/full continuation admission remains separate.
- **Behavior**: Returns the 0-based index of the first match. Returns `0` when the match is at the first position. Returns `undef` for missing, non-array, or no-match cases. The five current backends keep null distinct from empty: `index_of([undef,""],"")` is `1`, and `index_of([""],undef)` is undef. Rust free `index_of(items, needle_expr)` also captures named `items` before needle effects: with `items=["a"]`, `index_of(items,{items=["z"];"a"})` returns `0` and leaves `items` as `["z"]`.


Ordinary canonical Perl, Rust, Dart, Julia and installed Lua `index_of` calls
and one-needle receiver prefixes now
retain actual result kinds and rejection through compatible continuations.
Incompatible container consumers return undef before their operands or later
`with` bodies run, keeping already completed source/needle effects:

```text
order="";
out=index_of({order=cat(order,"S");["a"]},{order=cat(order,"N");"a"})
  .take({order=cat(order,"A");1}).with(){order=cat(order,"W");return("ran")};
# out=undef, order="SN"

index_of(["a"],"z").with(){return("missing")} # "missing"; legitimate null
{undef}.index_of({order=cat(order,"O");"a"}).coalesce("fallback")
# "fallback"; nullable source still evaluates its needle once
```

Numeric0/null/no-match, equality, source snapshots, needed errors, compatible
defaults, String-to-Array and `with`-returned Array bridges remain. Lua checks use
installed PUC5.5.1/LuaJIT; declared5.4 remains separate.

Ordinary Perl/Rust/Dart/Julia/installed Lua preserve nullable index calls after copy.
These forms evaluate a needed needle once and return undef for legitimate null:

```text
{undef}.copy().index_of(needle)
copy({undef}).index_of(needle)
index_of(copy({undef}),needle)
{undef}.copy().copy().index_of(needle)
```

Copied legitimate null results from numeric methods or `with` retain this behavior,
including needed needle errors. Earlier rejected consumers stop the chain before
later copy, needle, default or `with` effects:

```text
order=""; out={undef}.copy().index_of({order=cat(order,"N");"a"})
# out=undef, order="N"
index_of(["a"],"a").add("bad").with(){return(undef)}.copy().index_of(needle)
# undef; needle runs once after the legitimate null result
index_of(["a"],"a").take(1).copy().index_of(needle)
# undef; needle skipped after rejected take
["a"].copy().index_of("a")           # numeric0
[undef,""].copy().index_of("")      # numeric1; null differs from empty
```

Regenerate emitted Perl parsers and rebuild Rust/Dart/Julia/Lua apps/runtime. Lua
checks use installed PUC5.5.1/LuaJIT; declared5.4 remains open. Equality, index0/null
identity, copy depth and snapshots stay; these bounded controls grant no general
nullable Array, domain/context or portable-admission policy.

Canonical Perl `index_of` accepts computed source and needle value blocks:

```text
items=[]
index_of({push(items,"a")},"a")       # 0; items is ["a"], pushed once
index_of(["a"],{cat("","a")})         # 0; computed needle
index_of({items="text";push(items,"x")},"a").coalesce("masked")
# binding_kind_mismatch at execution; the default cannot mask the source error
```

The source completes before the needle. Source errors stop needle evaluation;
needed needle errors propagate before later defaults or `with` bodies. Native
and freshly emitted Perl agree; regenerate existing emitted parsers. Numeric
indices, no-match/null results, equality, snapshots and copy depth are unchanged.

### `is_empty(arr)`
- **Signature**: `is_empty(value: array|hash|expr)`
- **Returns**: predicate result; Perl retains numeric `1`/`0`, while Rust/Dart/Julia/Lua retain Boolean results.
- **Behavior**: Returns true for an actual empty Array/Hash/String or undef; String `"0"`, numeric0 and false remain data. Perl/Rust/Dart/Julia/Lua ordinary values and receivers inspect that yielded kind once: `[].is_empty().cat("!")` → `"1!"`; `{"a":1}.is_empty().cat("!")` → `"0!"`; `cat(is_empty({[]}),"!")` → `"1!"`. Selected, function, default and copied dynamic Array/Hash sources also work. The predicate runs before consumer operands: `parts=[]; text=parts.is_empty().cat({parts+="x";"!"})` keeps `text="1!"` and leaves `parts=["x"]`. Receiver form takes no operands before effects; `.is_empty().sorted()` returns undef. Rust/Dart/Julia/Lua retain Boolean producer values; scalar-text chains render truth as0/1. Lua checks use available PUC5.5.1/LuaJIT; declared5.4/full admission and broader Perl FlowExpr conditional/literal-slot repairs remain tracked.
- **Edge cases**: Returns true for undef (treated as empty).

### `is_nonempty(arr)`
- **Signature**: `is_nonempty(value: array|hash|expr)`
- **Returns**: predicate result; Perl retains numeric `1`/`0`, while Rust/Dart/Julia/Lua retain Boolean results.
- **Behavior**: Logical inverse of `is_empty`. On Perl/Rust/Dart/Julia/Lua, `["a"].is_nonempty().cat("!")` → `"1!"`, and `{}.is_nonempty().coalesce_nonempty("late").cat("!")` → `"0!"` because false remains present data. `["a"].is_empty().cat(",x").split(",").last().uppercase()` → `"X"`; the explicit split produces an Array for later methods. Generic predicate results may themselves use `.is_nonempty()`. Ordinary free-helper `is_nonempty("0")` agrees with a binding holding `"0"` and returns1. The Lua declared-version/full-admission and broader Perl conditional qualifications above still apply.

Perl, Rust, Dart, Julia and installed Lua keep actual-kind and rejection guards through canonical one-value free
emptiness calls and ordinary zero-operand predicate prefixes:

```text
is_empty([1]).take(1)                            # undef
[1].is_empty().take(1).with(){return("ran")}       # undef; body skipped
[1].is_empty().cat("x").split(",").set_key("k",1).with(){return("ran")} # undef
is_empty([1]).with(){return([value,value.copy()])} # Perl [0,0]; Rust/Dart/Julia/Lua [false,false]
is_empty([1]).add("bad").with(){return("null")}     # "null"; body runs
is_empty([1]).is_nonempty().cat("!")              # "1!"
```

Incompatible consumer operands and later bodies stay skipped; source expressions
run once before compatible operands. Valid false/null/empty results still enter
`with`, and an Array returned by its body accepts Array methods. Focused Perl
native/fresh paths have ready ActionIR metadata; Rust/Dart/Julia/Lua pass native/restored
CompiledSpec/SpecFile/generated-plan checks with strict Bool/text/default/numeric profiles,
plus fresh Julia/Lua modules. Lua checks use installed PUC5.5.1/LuaJIT; declared5.4
and full admission remain separate. Regenerate emitted Perl parsers and rebuild
Rust/Dart/Julia/Lua apps/runtime. Empty/null versus zero/false/String0 domains
and broader Perl FlowExpr/host-slot qualifications remain unchanged.

### `join_values(delim, arr)`
- **Signature**: `join_values(delim: scalar, arr: array)`
- **Returns**: scalar
- **Behavior**: Joins array elements into a string with the delimiter between each element. Accepts composed array-valued expressions. Ordinary Perl/Rust/Dart/Julia/Lua joined Strings continue through compatible pure methods: `["a","b"].join_values(",").uppercase()` → `"A,B"`, `[].join_values(",").cat("!")` → `"!"`, and `["a","b"].join_values(":").length().add(1)` → `4`. A split bridges back to Array methods: `["a","b"].join_values(":").split(":").last().uppercase()` → `"B"`. Exactly one delimiter is required; other arities return null before effects. Snapshot the receiver before the delimiter and compute the joined String before later consumers; later source mutations do not recompute it. Lua checks use available PUC5.5.1/LuaJIT; declared5.4/full admission remains open. Lua receiver false delimiters now match the free helper: `["a","b"].join_values(false)` → `"a0b"`, with computed delimiters evaluated once.
- **Edge cases**: Returns empty string for an empty array and undef for a missing/undef array on the reference and
  Lua backends. Do not rely on a non-array source: Perl/Lua and Rust/Dart/Julia currently differ, with normalization
  owned by `FUTURE-PARITY-BACKLOG.5`.

### `split(s, delim)`
- **Signature**: `split(value: scalar, delim: scalar)`
- **Returns**: array
- **Behavior**: Splits a string on the delimiter, returning an array of substrings.
- **Regex flags**: Regex delimiters preserve `i`, `m`, `s`, and `x`; operation-only `g` and Perl compile-once `o`
  are accepted compile-time no-ops. Unknown flags or invalid patterns return an empty array. Dart examples: `split("aXb",/ x /ix)` returns `["a","b"]`, `["a b","ab"].filter_match(/^ a b $/x)` returns `["ab"]`, and `split("abc",/b/q)` returns `[]`; `split("abc",/(/)` also returns `[]` after its invalid pattern reaches regex compilation.
- **Examples**: over `/(.+)/`, `entry_group(0).split(",")` on `a,b,c` → `[["a","b","c"]]`.
  `count(entry_group(0).split(","))` on the same input → `[3]`.
- **Current Perl caveat**: use receiver form (`value.split(delim)`) or block form
  `I { return(split(value, delim)) }` in runnable examples. Compact `I.return(split(...))`
  currently surfaces an older tagged shorthand shape in the Perl reference.

### `split(target, source, delimiter)`
- **Signature**: `split(target, source, delimiter: regex-or-scalar)`
- **Returns**: replaces the named array target. Lua value-position calls also return an independent updated Array; other backend return forms remain under review.
- **Behavior**: Splits `source` on `delimiter` and replaces `target` with the resulting list. Regex delimiters
  split by regex match; scalar delimiters split literally. In Lua, false converts to "0": `parts=["old"]; updated=split(parts,"a0b",false); parts+="tail"` leaves `updated` as `["a","b"]` and `parts` as `["a","b","tail"]`. Source evaluates before the delimiter, once each.
- **Boundary**: This statement-style array pipeline helper is separate from pure `split(value, delim)`, which
  returns an array value for expression and receiver-chain use. Mutable split requires three arguments; a two-argument call remains pure and does not replace its first variable.

### `split_each(arr, delim)`
- **Signature**: `split_each(arr: array, delim: regex-or-scalar)`
- **Returns**: array
- **Behavior**: Splits each element and flattens the pieces. In ordinary Perl value/receiver forms, scalar delimiters may be variables or expressions: the array is snapshotted first, then the delimiter evaluates once, even for an empty array. Runtime scalar text splits literally; slash regex literals retain flags and existing trailing-field behavior.
- **Example**: `items=["a:b","c:d"]; delimiter=":"; return(items.split_each(delimiter))` returns `["a","b","c","d"]` and preserves `items`.
- **Statement form**: `split_each(items,delimiter)` writes the pieces back to `items`. On Perl the target is validated and snapshotted before the delimiter evaluates once, including for empty/absent arrays; an existing wrong kind fails before delimiter effects. Stored results and receiver chains preserve their inputs.

### `trim_each(arr)`
- **Signature**: `trim_each(arr: array)`
- **Returns**: array
- **Behavior**: Trims whitespace from each element of the array.
- **Example**: after `set(items, [" a ", " b"])`, `return(items.trim_each())`
  yields `[["a","b"]]`.

### `filter_nonempty(arr)`
- **Signature**: `filter_nonempty(arr: array)`
- **Returns**: array
- **Behavior**: Returns a new array with empty/undef elements removed. Kept entries retain their original kinds, including numeric entries used later as array indices; standalone writeback preserves the same kinds.
- **Example**: after `set(items, ["a", "", undef, "0", "b"])`,
  `return(items.filter_nonempty())` yields `[["a","0","b"]]`.

### `filter_match(arr, /pattern/)`
- **Signature**: `filter_match(arr: array, pattern: regex)`
- **Returns**: array
- **Behavior**: Returns elements matching the regex pattern. Retains the original entry kinds in value/receiver and standalone writeback forms.
- **Example**: after `set(items, ["alpha", "beta", "atom"])`,
  `return(items.filter_match(/^a/))` yields `[["alpha","atom"]]`.

### `uniq(arr)`
- **Signature**: `uniq(arr: array)`
- **Returns**: array
- **Behavior**: Returns a new array with duplicates removed. The first occurrence and its original value kind are preserved in value/receiver and standalone writeback forms. On the five current backends (Lua: available PUC5.5.1/LuaJIT), `items=[2,"2",undef,""]; uniq(items)` leaves `[2,undef,""]`; entry0 remains a numeric array index and null stays distinct from empty text.
- **Example**: after `set(items, ["a", "b", "a", "c", "b"])`,
  `return(items.uniq())` yields `[["a","b","c"]]`.

### `lowercase_each(arr)`
- **Signature**: `lowercase_each(arr: array)`
- **Returns**: array
- **Behavior**: Lowercases each element with the same Unicode 17 contract as `lowercase`.
- **Example**: after `set(items, ["A", "bC"])`, `return(items.lowercase_each())`
  yields `[["a","bc"]]`.

### `uppercase_each(arr)`
- **Signature**: `uppercase_each(arr: array)`
- **Returns**: array
- **Behavior**: Uppercases each element with the same Unicode 17 contract as `uppercase`.
- **Example**: after `set(items, ["a", "bC"])`, `return(items.uppercase_each())`
  yields `[["A","BC"]]`.

### `print_each(arr, prefix, suffix?)`
- **Signature**: `print_each(arr: array, prefix: scalar, suffix?: scalar)`
- **Returns**: void
- **Behavior**: Debug helper — eagerly emits `prefix + item + suffix` for each element in order. The omitted
  suffix is empty text under ADR `0042`. Arguments evaluate exactly once left-to-right before item delivery; an
  empty or wrong-kind target emits no events. No message enters the parser result. Each item is delivered as a
  caller-owned `RuntimeDiagnosticOutputEvent` with exact helper/rule/message fields; an absent sink is quiet and a
  sink failure propagates unchanged. Native and generated execution on all five backends consume this same
  contract; primary commands deliberately install no rich sink. See the [value/container helper
  reference](../dsl/value-container-flow-helper-reference.md#debug-output-helpers) for event rendering, typed exit,
  and host API examples.

## 4. Hash Helpers

> **Worked examples** use the same runnable two-rule scaffold as the Array section:
>
> ```text
> demo::
>  -> value .push
>  LX { return(copy(demo)) }
>
> value : /<regex>/
>  I { <statements>; return(<hash-or-derived-value>) }
> ```
>
> Outputs are the parser's accumulator array after `demo` pushes each `value` result.

**Verified value, mutation, and receiver examples:**

| Surface | Body inside `value`'s `I { ... }` block | Input | Output |
| --- | --- | --- | --- |
| Construct | `return(hash("b", 2, "a", 1))` | `x` | `[{"a":1,"b":2}]` |
| Explicit null value | `return(hash("a", 1, "missing", undef))` | `x` | `[{"a":1,"missing":null}]` |
| Splice count | `return(count(array(flat_hash(hash("a", 1, "b", 2)))))` | `x` | `[4]` |
| Copy snapshot | `set(meta, { "a" : 1 }); set(saved, copy(meta)); meta["b"] = 2; return(array(count_keys(meta), count_keys(saved)))` | `x` | `[[2,1]]` |
| Receiver copy | `set(meta, { "a" : 1, "b" : 2 }); return(meta.copy().flat_hash().count_keys())` | `x` | `[2]` |
| Flat-array hash splice | `return(hash(flat_array(["a", 1, "b", { "nested" : 2 }])))` | `x` | `[{"a":1,"b":{"nested":2}}]` |
| Receiver flat-array hash splice | `set(pairs, ["a", 1]); return(harray(pairs.flat_array()))` | `x` | `[{"a":1}]` |
| Merge override | `return(merge_hash(hash("a", 1, "b", 2), hash("b", 9, "c", 3)))` | `x` | `[{"a":1,"b":9,"c":3}]` |
| Pure `set_key` | `set(meta, { "a" : 1 }); return(array(meta.set_key("b", 2).count_keys(), count_keys(meta)))` | `x` | `[[2,1]]` |
| Statement `set_key` | `set_key(meta, "a", 1); set_key(meta, "b", 2); return(copy(meta))` | `x` | `[{"a":1,"b":2}]` |
| Typed-path assignment (string selector) | `key = "stage"; value = "ok"; meta[key] = value; return(copy(meta))` | `x` | `[{"stage":"ok"}]` |
| Rename/drop/pick | `return(rename_key(hash("old", 1, "keep", 2), "old", "new"))` / `return(drop_keys(hash("a", 1, "b", 2, "c", 3), "b", "c"))` / `return(pick_keys(hash("a", 1, "b", 2, "c", 3), "b", "missing"))` | `x` | `[{"keep":2,"new":1}]` / `[{"a":1}]` / `[{"b":2}]` |
| Membership/count | `return(array(has_key(hash("a", 1), "a"), has_key(hash("a", 1), "missing")))` / `return(count_keys(hash("a", 1, "b", 2)))` | `x` | `[[1,0]]` / `[2]` |
| Sorted views | `return(sorted_keys(hash("b", 2, "a", 1)))` / `return(sorted_values(hash("b", 2, "a", 1)))` | `x` | `[["a","b"]]` / `[[1,2]]` |
| Receiver chain | `set_key(meta, "b", 2); set_key(meta, "a", 1); return(meta.set_key("c", 3).sorted_keys().join_values(","))` | `x` | `["a,b,c"]` |
| Block receiver | `return({ { "b" : 2, "a" : 1 } }.sorted_keys().join_values(","))` | `x` | `["a,b"]` |
| Hash-tree map | `set(meta, { "b" : { "y" : "B" }, "a" : "A" }); return(meta.map_leaves() { return(cat(join_values("/", path), "=", value)) })` | `x` | `[{"a":"a=A","b":{"y":"b/y=B"}}]` |
| Hash-tree walk | `set(meta, { "b" : { "y" : "B" }, "a" : "A" }); return(array(meta.walk_leaves() { paths += cat(key, "@", depth); return(value) }.count_keys(), paths))` | `x` | `[[2,["a@1","y@2"]]]` |
| Hash-tree reduce | `set(meta, { "b" : { "y" : "B" }, "a" : "A" }); return(meta.reduce_leaves("") { return(cat(acc, key, "@", depth, ";")) })` | `x` | `["a@1;y@2;"]` |

> **Current Perl caveat.** Direct odd-arity constructor calls such as
> `hash("a", 1, "missing")` are not the portable "trailing undef" spelling on the
> current Perl reference; they lower to an unsupported-helper sentinel and return
> `undef` (`[null]` through this scaffold). Spell the missing value explicitly
> as `hash("a", 1, "missing", undef)`, or pass a list-valued splice such as
> `hash(flat_array(array("a", 1, "missing")))` when that list context is intended.

### `hash(k1, v1, k2, v2, ...)`
- **Signature**: `hash(keys_and_values: scalar...)`
- **Returns**: hash
- **Behavior**: Constructs a hash from flat key/value pairs. Quoted strings are literal constructor payloads, so
  `hash("key", value)` constructs a hash entry whose key is `"key"`. Zero and paired multi-argument calls are
  valid. Arguments are interpreted as alternating keys and values. Accepts
  `flat_array(...)` and `flat_hash(...)` for list-context insertion. Direct call or terminal receiver
  `flat_array(...)` results splice their copied array members as ordered alternating tokens; an unwrapped array
  argument remains one value, and an empty splice adds no tokens.
- **Boundary**: Exact `hash(IDENTIFIER)` is a removed selector shape. Use the bare identifier to read its harray
  value or `{ identifier : value }` / `{ "identifier" : value }` to construct a field. All five backends reject
  the removed selector before execution.
- **Edge cases**: Duplicate keys: last value wins. Direct multi-argument constructor calls should pass paired
  key/value arguments; use an explicit `undef` value for a null-valued trailing key.

On Perl, computed key expressions use the same typed evaluation as values,
including helper calls, indexed reads and action blocks with local returns:

```text
hash(cat("k","x"),false)        # {"kx":false}
hash({return("k")},[0,"tail"]) # {"k":[0,"tail"]}
```

Keys evaluate before their associated values and retain their evaluated snapshot
if a later value rebinds a working variable. Bare tag keys retain their existing
spelling; use a block or another computed expression for a dynamic binding value.
Needed key errors propagate before a consumer runs. Regenerate emitted Perl parsers.

### `flat_hash(h)`
- **Signature**: `flat_hash(h: hash)`
- **Returns**: list (splices into parent context)
- **Behavior**: Flattens a hash into alternating key/value list context for insertion into `hash(...)` or `array(...)`.
- **Ordering boundary**: Do not currently depend on the order of key/value pairs when a harray is flattened into an
  array. Lua sorts keys for deterministic output, while the admitted backends do not yet share one portable map-
  iteration sequence. `FUTURE-PARITY-BACKLOG.5` owns normalization.

### `hash_copy(h)`
- **Signature**: `hash_copy(h: hash)`
- **Returns**: hash
- **Behavior**: Shallow copy. The new hash has the same keys and values but is a distinct container.
- **Compatibility status**: Retired on current runtimes.
- **Terse spelling**: `copy(h)` / receiver `.copy()` is the unified canonical spelling (the same `copy(...)` that subsumes legacy array/hash copy helpers). See [Terse Helper Renames](#terse-helper-renames-canonical-going-forward).
- **Receiver boundary**: `value.copy()` evaluates `value` once and preserves array/harray kind for compatible links. Ordinary Perl lowering copies the outer container and shares nested references; Rust, Dart, Julia and Lua recursively copy their runtime containers.
  Ordinary function `copy(value)` preserves Bool, Number, String and null on Perl, Rust, Dart, Julia and the tested Lua hosts, evaluates its source once and guards continuations by the actual result kind. Number `0` and String `"0"` remain distinct, including as typed write selectors. Ordinary receiver `value.copy()` shares that producer across literals, bindings, selected/block/function/prior-result values and repeated/scoped chains; source errors and malformed-shape preflight remain. Perl interpreted free copy also passes primitive/null/source/origin controls; its deferred receiver copy remains unavailable and its existing recursive container depth is retained. Ordinary shallow depth must not be generalized to that executor. Rust/Dart native-restored-plan and Julia/safe-Lua native-plan-fresh-source checks cover the approved function/receiver/result flows, including guarded Array/Hash consumers. Lua checks use PUC5.5.1/LuaJIT; declared5.4 remains separate. ADR0138 approves scalar/null preservation across supported copy roles; full portable admission remains open.
  Receiver `copy()` takes zero extra operands; extra operands return null before receiver/operand effects on Perl, Rust, Dart, Julia and the available Lua hosts (PUC5.5.1/LuaJIT; declared5.4 proof remains open). For portable programs, give function copy one source value and receiver copy no extra operands; retain the documented container-depth differences. Complete copy-family source/context/portable admission remains open.

### `merge_hash(h1, h2)`
- **Signature**: `merge_hash(base: hash, overlay: hash)`
- **Returns**: hash
- **Behavior**: Merges `h2` into `h1`. Keys in `h2` override keys in `h1`. Neither input is mutated — returns a new hash. Rust captures earlier named Hash operands before later effects: with `base={"a":1}`, `merge_hash(base,{base={"z":2};{"b":3}})` returns `{"a":1,"b":3}` while `base` becomes `{"z":2}`.
- **Bare bindings**: Both positions accept bare typed harray bindings, so `merge_hash(base, overlay)` is canonical.
  `merge_hash(copy(base), overlay)` is equivalent when an explicit source snapshot makes the intent clearer; no
  aggregate-selector wrapper is required or accepted.

The ordinary Hash-valued results of `merge_hash`, pure `set_key`, `rename_key`,
`drop_keys` and `pick_keys` now retain actual-kind/rejection guards on bounded Perl,
Rust, Dart, Julia and installed Lua routes. Incompatible Array consumers return null before operands; later copy/
logical/with work is skipped, and needed producer errors remain errors. Current
source/arity/key/collision/mutation policies stay intact. Canonical selected free/
receiver arities are merge2/1, set/rename3/2, drop/pick with at least one key.
Full source/context/portable admission and declared Lua5.4 remain open; see
[the worked boundary examples](../dsl/value-container-flow-helper-reference.md#hash-valued-helper-continuations-selected-open-repair).

Perl's bounded source77.0 repair excludes Number ASTs from these five named-Hash
shortcuts and guards computed non-reference dereferencing. Observed Number3,
String `"3"` merge, Number3 overlay and pick/drop key-effect controls now stay
independent of unrelated `%main::3` data. Preserve the existing Array errors,
null/key branches and own arity policies; regenerate previously emitted Perl.
Bounded Perl composition77.1.1 is focused-checked; broad source/isolation admission
remains separate. Published
signatures still require actual Hash inputs; this defines no portable fallback.

### `set_key(h, key, value)`
- **Signature**: `set_key(h: hash, key: string, value: expr)`
- **Returns**: hash
- **Behavior**: Returns a new hash with the key set to the value. Does not mutate the input. Ordinary Perl value/receiver/statement forms accept eager String key blocks with local returns, for example `meta.set_key({return("kind")},{return("node")})`. Pure source, key and value evaluate once in that order; a later value cannot change the captured key. With `key="before"`, `set_key(meta,key,{key="after";2})` sets `"before"` in the copy. Statement and String-key operator writes also preserve the key selected before their value.
- **Statement form**: `set_key(name, key, value)` mutates the named working hash `name` directly. An absent target
  starts as an empty harray; an incompatible existing value fails with `binding_kind_mismatch`.
- **Operator form**: `name[key] = value` is a separate typed-path contract on all five backends. An evaluated string has the
  same field-update effect, while a nonnegative integer selects an array. It yields an independent updated root
  snapshot in value positions; bare key/RHS identifiers read scalar working variables. Receiver-dot
  `name.set_key(key, value)` remains pure.

### `name[key] = value`
- **Signature**: `target[key_expr] = value_expr`
- **Returns**: updated typed-root snapshot in value positions; side-effect-only behavior when used as a statement.
- **Behavior**: Typed path assignment on all five backends. It evaluates the selector and value once, chooses harray for a
  string or array for a nonnegative integer, mutates an isolated root copy, then commits and returns a detached
  updated root. It is not identical lowering to harray-only `set_key`.
- **Examples**: `meta["stage"] = "normalized"`, `meta[cat("source", "_kind")] = kind`,
  `meta[field_name] = field_value`, `items[position] = field_value`.
- **Edge cases**: The left side is a bare typed binding. Absence creates the root chosen by the selector;
  explicitly bound null or another wrong kind is a typed conflict. Array indexes replace or append at len, never
  create a gap. Bare key/RHS identifiers read scalar working variables in this mutation slot. Receiver-dot
  `meta.set_key(key, value)` remains pure copy-valued composition; use `meta[key] = value` when you want mutation.

### `rename_key(h, old, new)`
- **Signature**: `rename_key(h: hash, old_key: string, new_key: string)`
- **Returns**: hash
- **Behavior**: Returns a new hash with the key renamed. The value is preserved. If the old key does not exist, the hash is returned unchanged.
- **Portable collision boundary**: Keep `new_key` absent from the source. When it already exists, Perl/Julia keep
  the renamed old value while Dart/Rust keep the pre-existing destination; Lua currently follows Perl/Julia.
  `FUTURE-PARITY-BACKLOG.5` owns normalization.

### `drop_keys(h, k1, k2, ...)`
- **Signature**: `drop_keys(h: hash, keys: string...)`
- **Returns**: hash
- **Behavior**: Returns a new hash with the named keys removed. Does not mutate the input.

### `pick_keys(h, k1, k2, ...)`
- **Signature**: `pick_keys(h: hash, keys: string...)`
- **Returns**: hash
- **Behavior**: Returns a new hash containing only the named keys. Does not mutate the input. On Perl, expression-valued key blocks also run once after capturing the input Hash: `pick_keys(meta,{ audit="key"; "a" })` selects key `"a"`; a key block that reassigns `meta["a"]` does not change the previously captured value. The equivalent ordinary fluent key-block consumer follows the same rule.

### `has_key(h, key)`
- **Signature**: `has_key(h: hash, key: string)`
- **Returns**: presence flag; the checked Perl/Rust/Dart/Julia/Lua routes retain numeric `1`/`0`.
- **Behavior**: Returns true if the hash contains the named key, including a stored false/null value. Perl/Rust/Dart/Julia/Lua accept literal, variable, helper-produced and block String keys: `meta.has_key({calls=num_add(calls,1);"a"})` evaluates the key once, after capturing the source. Its result now continues through compatible scalar/text methods: `{"a":false}.has_key("a").cat("!")` → `"1!"`; `{}.has_key("a").cat("!")` → `"0!"`; `{}.has_key("a").coalesce_nonempty("late").cat("!")` → `"0!"`. `meta.copy().has_key("a").cat(",x").split(",").last().uppercase()` → `"X"` for a present key; `meta.has_key("a").sorted_values()` → undef. A key added during key evaluation stays absent from the captured source. Receiver form requires one key before effects. Rust free `has_key(meta,key_expr)` also uses its captured named source, even when the key operand rebinds `meta`. Perl also evaluates a key once when its source is null: with `meta=undef` and `calls=0`, `has_key(meta,{calls=num_add(calls,1);"a"})` returns `0` and leaves `calls` as `1`. The source is captured before key effects, so creating or replacing the working Hash inside the key does not change the current presence result. Focused Perl native/fresh, Rust/Dart native/restored/generated-plan and Julia/Lua native/plan/fresh-emitted checks cover selected, function and default sources too; Lua uses available PUC5.5.1/LuaJIT, with declared5.4/full admission separate.

Perl, Rust, Dart, Julia and installed Lua keep actual-kind and rejection guards through canonical two-value free
`has_key` calls and ordinary one-key prefixes:

```text
has_key({},"k").take(1)                           # undef
{}.has_key("k").take(1).with(){return("ran")}       # undef; body skipped
{}.has_key("k").cat("x").split(",").set_key("k",1).with(){return("ran")} # undef
has_key({},"k").with(){return([value,value.copy()])} # [0,0]
has_key({},"k").add("bad").with(){return("null")}   # "null"; body runs
```

Incompatible consumer operands and later bodies stay skipped. A valid null source
still evaluates its key exactly once before producing the numeric false flag:

```text
source=undef; order=""; calls=0;
out={order=cat(order,"S");source}.has_key({
  calls=num_add(calls,1);order=cat(order,"K");source={"k":1};"k"
}).cat({order=cat(order,"C");"!"});
# out="0!", order="SKC", calls=1, source={"k":1}
```

The key checks the captured null source even though its expression creates a new
working Hash. Legitimate false/null/empty results enter `with`; an Array returned
by the body accepts Array methods. Focused native/fresh Perl paths have ready
ActionIR metadata; Rust/Dart/Julia/Lua pass native/restored CompiledSpec/SpecFile/generated-plan
controls, plus fresh Julia/Lua modules, including the unchanged null-source/key
snapshot fixture. Lua uses installed PUC5.5.1/LuaJIT; declared5.4 remains separate.
Regenerate emitted Perl parsers and rebuild Rust/Dart/Julia/Lua apps/runtime. These
checks preserve presence flags, key domains and selected source/key/copy/default controls.

Ordinary Perl/Rust/Dart/Julia/installed Lua preserve nullable presence after copy.
`{undef}.copy().has_key(key)`, `copy({undef}).has_key(key)` and
`has_key(copy({undef}),key)` evaluate the key once and return numeric0. Repeated
copies and copied legitimate null results from `with` or numeric methods keep
the same behavior; needed key errors propagate. These checked chains distinguish
legitimate null from rejection, with and without a trailing `with`:

```text
order="";
out=has_key({},"k").take({order=cat(order,"A");1}).copy()
  .has_key({order=cat(order,"K");"k"})
  .with(){order=cat(order,"W");return("ran")};
# out=undef, order=""; incompatible take/key/body effects stay skipped

order="";
out=has_key({},"k").add("bad").copy()
  .has_key({order=cat(order,"K");"k"});
# out=0, order="K"; legitimate null still evaluates the key
```

Regenerate emitted Perl parsers and rebuild Rust/Dart/Julia/Lua apps/runtime. Lua
checks use installed PUC5.5.1/LuaJIT; declared5.4 and complete source/context/portable
admission remain open.

### `count_keys(h)`
- **Signature**: `count_keys(h: hash)`
- **Returns**: int
- **Behavior**: Returns the number of keys in the hash. Returns `0` for missing or non-hash input. On Perl/Rust/Dart/Julia/Lua, `{"a":1,"b":2}.count_keys().mul(2)` → `4` and `{}.count_keys().add(1)` → `1`; the result feeds existing compatible scalar/number methods just like `num_add(count_keys(meta),3)`. Source evaluation and the count precede later operands, so their mutations do not recompute that count.

- **Current Perl status (November6)**: Typed-source75.0.1, source-domain75.0.2 and bounded ordinary result guards75.1 are implemented with focused checks. In retained literal/computed initial-source controls, Boolean/Array/missing/Number/text inputs return `0`; valid named Hash counts remain intact. Numeric `4` stays data under localized host controls. Mutating value blocks keep typed errors during execution. Regenerate emitted Perl.

Canonical free counts and ordinary literal/binding/block receiver counts reject incompatible Array/Hash consumers with null before operands or later bodies. Rejection survives copy/eager logical/with; legitimate zero and explicit bridges remain valid. Perl callable75.6.1 now uses these guards too; independent Julia/installed Lua callable coverage75.6.4-.5 and full admission remain separate.

```text
count_keys(false)                     # 0
[1,2].count_keys()                    # 0
count_keys(4).add(1)                  # 1
meta={"a":1,"b":2};count_keys(meta)  # 2
```

The initial source is evaluated once before later operands. For example,
`count_keys({calls=num_add(calls,1);[1]}).add(1)` increments an existing numeric
`calls` once and yields `1`. A source binding error still propagates; returning
zero for an ordinary non-Hash value does not mask failed source evaluation.

```text
false.count_keys().coalesce(7)       # 0
[].count_keys().cat("!")             # "0!"
count_keys({}).count()               # null: a produced Number is not an Array
count_keys({}).with(){return([1,2])}.count() # 2: explicit Array bridge

order="";
out=count_keys({"k":1}).take({order=cat(order,"A");1})
  .copy().and({order=cat(order,"D");true})
  .with(){order=cat(order,"W");return("ran")};
# out=null, order=""; incompatible operands and later bodies stay skipped
```

Rust75.2 now applies the ordinary result guards in both direct and trailing-`with`
execution. Its independent22-case, four-route regression passes, preserving its
initial zero policy, source order and needed errors. Incompatible operands and
later bodies stay skipped. Rebuild Rust applications/runtime; the retained
emitted modules and serialized inputs are unchanged. Callable-receiver coverage
and full admission remain separate.

Dart75.3 now guards ordinary CountKeys results with its own source profile
preserved. Free `count_keys(false)` returns `0`, while receiver
`false.count_keys()` remains null under its scalar boundary. A one-step initial
KeyCount permission skips only the common guard; it adds no Boolean receiver
rights. Its independent22-case/four-route checks and direct Count/Length checks
pass. Rebuild Dart apps/runtime; broader domain/callable admission stays separate.

Julia75.4 now guards ordinary CountKeys results while preserving its independent
source profile: `count_keys(false)` returns `0`, and `false.count_keys()` remains
null. The first-step KeyCount permission skips only the common guard;
`scalar_result`, Count permission and loop-index Array-end mutation restrictions
stay intact. Free Count-produced Numbers are explicitly excluded from initial
KeyCount permission, so `count([1]).count_keys()` returns null and skips later
bodies. Its maintained25-case/four-route regression and selected Count/
Length checks pass346 assertions with strict depwarn. Rebuild Julia apps/runtime;
actual emitted modules/parsed inputs are unchanged. Callable receivers and full
admission remain separately owned.

Peer preservation75.7 independently confirms that Rust and Dart already exclude
Count-owned values from initial KeyCount permission. Their new three-program
checks pass on four routes; each maintained key-count normal now passes25 cases
on native/restored/plan routes. Both runtime implementations stay byte-identical.
Initial source zero stays distinct from a Count-produced Number:

```text
1.count_keys()                       # 0: initial non-Hash source
count([1]).count_keys()              # null: Count owns its Number result
count([1]).count_keys().with(){return("ran")} # null; body skipped
```

The retained peer emitted checks cover the new3 programs. Installed Lua75.5 also
includes these preservation controls; callable/context/full admission stays separate.

Installed Lua75.5 now guards ordinary CountKeys results on PUC5.5.1 and LuaJIT.
Its independent free Boolean zero/receiver Boolean null profile stays exact.
The common-only initial KeyCount exception excludes free Count ownership;
scalar state, Count permission and loop-index mutation restrictions remain intact,
with no new interpreter chunk locals. Its25-case/four-route regression and
selected Count/Length checks pass on each host. Rebuild Lua apps/runtime; actual
modules/parsed inputs are unchanged. All five ordinary backend implementations
have focused checks passing; Perl callable75.6.1 and independent Rust75.6.2/Dart75.6.3 are checked below, with Julia/installed Lua callable coverage and full admission open.

Perl registered-function results now compose through the same CountKeys guards;
independent Rust checks confirm its existing implementation already does so.
The existing function evaluator still owns argument order, parameter bindings,
local scope, and required argument errors. A Hash result produces its count once;
later operands see that Number, even if they mutate the original Hash:

```text
fn echo_hash(payload){return(payload)}
Value:: I {
  meta={"x":1};order="";
  out=echo_hash({order=cat(order,"S");meta}).count_keys()
    .add({order=cat(order,"A");meta["y"]=2;3});
  return([out,count_keys(meta),order])  # [4,2,"SA"]
}
```

These additional Perl/Rust examples show valid zero and rejected consumers:

```text
fn make_hash(){return({"k":1})}
fn make_empty(){return({})}
fn make_bool(){return(false)}
Value:: I {
  return([
    make_hash().count_keys().add(1),                  # 2
    make_hash().count_keys().cat(" keys").uppercase(), # "1 KEYS"
    make_empty().count_keys().coalesce(7).add(1),       # 1
    make_bool().count_keys().add(1),                  # 1: existing initial count is 0
    make_hash().count_keys().count(),                # null: Number is not an Array
    make_hash().count_keys().take(1).copy()
      .with(){return("ran")}                        # null: body skipped
  ])
}
```

On Perl, the earlier Boolean-function null/unready result was an incomplete continuation,
not an initial-source policy: its terminal count already returned0. The separate
terminal and composed controls now both pass. Malformed receiver arity still
rejects before source/operand/body effects. The 16-case focused native/emitted
regression passes. Independent Rust75.6.2 also passes all 16 source programs on
native, reconstructed, generated-plan and freshly compiled emitted routes, with
no runtime edit. Its regression covering 16 cases on native/restored/plan routes and 29 direct
CountKeys/function checks pass. Boolean-function terminal count 0 and composed result 1, malformed
arity and required native/generated error profiles are independently frozen.
Julia/installed Lua callable profiles still require their own assessment.

Dart independently supports the compatible Hash-function chains too, with no
runtime repair needed. Its Boolean-function receiver remains unsupported and
returns null; the free helper retains zero. The focused source programs give:

| Runtime | `make_hash().count_keys().add(1)` | `make_bool().count_keys()` | `make_bool().count_keys().add(1)` |
| --- | --- | --- | --- |
| Perl | `2` | `0` | `1` |
| Rust | `2` | `0` | `1` |
| Dart | `2` | `null` | `null` |

Here `make_hash` returns `{"k":1}` and `make_bool` returns `false`.
`count_keys(make_bool()).add(1)` returns `1` on all three. Dart's source/scalar
boundary is preserved rather than normalized to a peer. Its 12 compatible
targets and four independent source/error profiles pass on native, reconstructed,
generated-plan and fresh emitted routes; its maintained 16-case regression and
29 direct CountKeys/function checks pass. Julia and installed Lua still require
their independent callable assessments. Full source/context admission is open.

### `sorted_keys(hash)`
- **Signature**: `sorted_keys(h: hash)`
- **Returns**: array
- **Behavior**: Returns the hash's keys as an array, sorted alphabetically. Deterministic — does not depend on host-language hash iteration order.

### `sorted_values(hash)`
- **Signature**: `sorted_values(h: hash)`
- **Returns**: array
- **Behavior**: Returns the hash's values as an array, sorted by their corresponding keys alphabetically. Deterministic.

### Hash receiver-dot value chains
- **Signature**: `hash_expr.method(args...).next(args...)`
- **Returns**: the documented return value of the final helper in the chain.
- **Behavior**: A compatible hash receiver feeds into the first pure hash helper, and each helper's return
  value feeds the next compatible helper. For example,
  `meta.set_key("stage", "normalized").count_keys()` is equivalent to
  `count_keys(set_key(meta, "stage", "normalized"))`. `meta.sorted_keys().join_values(",")` first
  derives the sorted key array, then continues through the array receiver-chain family.
- **Allowed hash-returning links**: `copy`, `merge_hash`, `set_key`, `rename_key`, `drop_keys`,
  `pick_keys`, and `flat_hash`. `merge_hash` preserves the canonical helper contract: later arguments
  override earlier keys.
- **Allowed terminal/bridge links**: `sorted_keys` and `sorted_values` return arrays and may continue through
  compatible array receiver helpers. `count_keys` feeds scalar/number methods; Perl/Rust/Dart/Julia/Lua `has_key` feed compatible scalar/text methods.
  Field reads from a named working hash use `name.pick_keys(key).sorted_values().first()` after storing
  expression receivers in a named hash. Direct bracket reads such as `retv["key"]` are for scalar hashref
  payloads, not working-hash value reads.
- **Boundary**: `set_key(name, key, value)` mutates the named working harray. On all five backends,
  `name[key] = value` is typed-path assignment and may instead select array for an integer; it yields the updated
  root snapshot in value positions.
  Receiver-dot `meta.set_key(key, value)` is pure value composition; it mutates nothing unless assigned back.
- **Block receivers**: An expression-valued block whose value is a hash can be the receiver, for example
  `{ { "b" : 2, "a" : 1 } }.sorted_keys().join_values(",")`.

### Hash-tree receiver block traversal: `walk_leaves`, `map_leaves`, `reduce_leaves`
- **Signatures**:
  - `hash_expr.walk_leaves() { block }`
  - `hash_expr.map_leaves() { block }`
  - `hash_expr.reduce_leaves(initial_acc: expr) { block }`
- **Returns**:
  - `walk_leaves` returns the original hash tree after running callbacks.
  - `map_leaves` returns a new hash tree with each leaf replaced by the callback result.
  - `reduce_leaves` returns the final accumulator.
- **Backend status**: Perl, Rust, Dart, Julia, and Lua support this hash-root contract. Lua's harray proof passes
  113/113 and locks the exact Perl callback result; the shared root-kind dispatcher then closes array roots without
  changing hash semantics and passes 114/114 on both Lua ABIs.
- **Tree shape**: The receiver must be a hash. Nested hashes are interior nodes. Every non-hash value is a leaf,
  including arrays.
- **Traversal order**: Sorted-key depth-first traversal. For `{ "a" : "A", "arr" : ["u", "v"], "b" : { "y" : "B" } }`,
  callbacks run for paths `a`, `arr`, then `b/y`.
- **Callback bindings**: Each callback runs immediately in the caller's current action/runtime context with scoped
  scalar bindings:
  - `value`: current leaf value.
  - `key`: current leaf key.
  - `path`: array value containing root-to-leaf path segments.
  - `depth`: number of path segments (`count(path)`); a root leaf has depth 1.
  - `acc`: current accumulator for `reduce_leaves` only.
- **Binding restoration**: The traversal restores those scoped names after each callback and after traversal
  completes, including callback errors. Inputs, paths, mapped results, and accumulator values are copied, so
  callback mutation cannot alias the source. Mutations to other working variables are ordinary side effects and
  persist.
- **Return semantics**: `return(expr)` inside the callback is block-local and supplies that callback's result. In
  `map_leaves`, the result replaces the current leaf. In `reduce_leaves`, the result becomes the next accumulator.
  In `walk_leaves`, the result is ignored.
- **Edge cases**: A non-hash receiver yields `undef` and does not execute the callback. `walk_leaves()` and
  `map_leaves()` take no parenthesized arguments. `reduce_leaves(initial)` requires exactly one parenthesized
  initial accumulator expression. `walk_leaves()` and `map_leaves()` return hash values and can feed later hash
  receiver links such as `.count_keys()`. Perl/Rust/Dart/Julia/Lua ordinary reduction results now feed compatible methods: `{"b":2,"a":1}.reduce_leaves(0) { return(acc.add(value)) }.add(1)` → `4`; an Array-root reduction may also produce a Hash, as in `[1].reduce_leaves({}) { return({"key":"B"}) }.sorted_values().first().lowercase()` → `"b"`. Null/false and empty-tree initial kinds survive; scalar roots skip initial/callback, and malformed shapes skip all effects. Perl native/fresh emitted, Rust/Dart native/restored/in-process plan and Julia/Lua native/plan/fresh emitted checks pass. Lua uses safe PUC5.5.1/LuaJIT; declared5.4 and full signature/context/portable admission remain separate. These are immediate receiver block
  methods, not closures or delayed callbacks.
- **Examples**:
  - After `set(meta, { "b" : { "y" : "B" }, "a" : "A" })`,
    `return(meta.map_leaves() { return(cat(join_values("/", path), "=", value)) })`
    yields `[{"a":"a=A","b":{"y":"b/y=B"}}]` through the standard `demo::` wrapper.
  - After `set(meta, { "b" : { "y" : "B" }, "a" : "A" })`,
    `return(array(meta.walk_leaves() { paths += cat(key, "@", depth); return(value) }.count_keys(), paths))`
    yields `[[2,["a@1","y@2"]]]`.
  - After `set(meta, { "b" : { "y" : "B" }, "a" : "A" })`,
    `return(meta.reduce_leaves("") { return(cat(acc, key, "@", depth, ";")) })` yields `["a@1;y@2;"]`.

## 5. Numeric Helpers

All numeric helpers return `undef` if any input is missing, non-numeric, wrong-arity, non-finite, or (for
division/modulo) a zero divisor, unless wrapped in `coalesce(...)`. Numeric inputs are finite numbers or untrimmed
decimal strings matching `-?(?:digits(?:.digits)?|.digits)`. Booleans, null, arrays, harrays, plus/exponent/hex,
surrounding-whitespace, and trailing-dot strings are not numeric. Comparisons return numeric `1`/`0` when valid and
`undef` when invalid. Rounding sends exact halves away from zero; signed integer modulo uses floor/Euclidean
remainder, so a nonzero result has the divisor's sign. These rules are versioned by
`capability_conformance/scalar_numeric_contract.json` rather than delegated to host arithmetic APIs.

`num_add`, `num_mul`, and scalar `num_min`/`num_max` accept two or more operands. `num_sub`, `num_div`, `num_mod`,
and numeric comparisons require exactly two; unary helpers exactly one; clamp exactly three. Array-form min/max
and aggregate reducers keep their one-array signatures below.

Number receiver-dot value chains are pure value composition over this same family. Receiver methods use terse
names and map to `num_*`: `value.abs()` -> `num_abs(value)`, `value.add(2, 3)` -> `num_add(value, 2, 3)`,
`value.clamp(0, 10)` -> `num_clamp(value, 0, 10)`, and `value.gt(3)` -> `num_gt(value, 3)`. Bare receiver
identifiers read scalar working variables. Integer and float literal receivers are accepted (`5.mod(2)`,
`3.5.floor().add(1)`). Ordinary Perl/Rust/Dart/Julia/Lua arithmetic results now feed compatible scalar/text/generic consumers: `2.add(3).cat("!")` gives `"5!"`, `2.div(0).coalesce_nonempty(7).add(1)` gives `8`, and `2.add(1).cat(",x").split(",").last().uppercase()` gives `"X"`. Strict numeric domains and scalar/Array min/max overloads stay unchanged; Lua uses available PUC5.5.1/LuaJIT and declared5.4/full admission remain separate. Comparisons (`eq`, `ne`, `gt`, `ge`, `lt`, `le`) return numeric `1`/`0` or invalid-input `undef`; ordinary current-backend results feed compatible scalar and explicit-container continuations.
See the examples below; Lua checks use available PUC5.5.1/LuaJIT and declared5.4/full admission stays separate. Statement and lifecycle methods are not numeric receiver methods. An expression-valued block whose value is numeric can be the
receiver, for example `{ 3.5 }.floor().add(2)`.

The same numeric family also has function-form word aliases:
`add`, `sub`, `mul`, `div`, `mod`, `abs`, `floor`, `ceil`, `round`, `min`,
`max`, `clamp`, `sum`, `avg`, `median`, `range`, `eq`, `ne`, `gt`, `ge`, `lt`,
and `le`. These are exact aliases for the corresponding `num_*` helpers.
Arithmetic symbol callees are accepted as the same ordinary call form for the
arithmetic subset: `+(a, b)`, `-(a, b)`, `*(a, b)`, `/(a, b)`, and `%(a, b)`
map to `num_add`, `num_sub`, `num_mul`, `num_div`, and `num_mod`. These aliases
remain ordinary `callee(args)` calls, so there is no operator precedence; write
`+(*(a, b), c)` when you need explicit grouping. Comparison symbol callees are
accepted as numeric aliases too: `==(a, b)`, `!=(a, b)`, `>(a, b)`, `>=(a, b)`,
`<(a, b)`, and `<=(a, b)` map to the corresponding `num_*` comparison helpers. Ordinary Perl/Rust/Dart/Julia/Lua short comparison results feed compatible methods: `2.eq(2).cat("!")` → `"1!"`, `2.eq(3).coalesce_nonempty("late").cat("!")` → `"0!"`, and `2.eq(2).cat(",x").split(",").last().uppercase()` → `"X"`. Raw results remain numeric `1`/`0` or `undef` for invalid numeric inputs; one receiver RHS is required before effects. `"x".eq(2).coalesce_nonempty(7).add(1)` → `8`. Container-only consumers reject until an explicit bridge returns a container. Lua checks use available PUC5.5.1/LuaJIT; declared5.4, deferred/full admission remains separate.
The shipped explicit string bridge names are `str_eq`, `str_ne`, `str_gt`,
`str_ge`, `str_lt`, and `str_le`; use them for lexical string comparisons. Current Perl free/nested forms work: `cat(str_eq("a","a"),"!")` returns `"1!"`; false results are numeric0 and render `"0!"`. Rust/Dart/Julia/Lua preserve Boolean producers; false also renders `"0!"` and remains selected by `coalesce_nonempty`. Ordinary Perl/Rust/Dart/Julia/Lua counterparts now work for all six names: `"a".str_eq("a").cat("!")` returns `"1!"`, `"a".str_eq("b").coalesce_nonempty("late").cat("!")` returns `"0!"`, and `"a".str_eq("a").cat(",x").split(",").last().uppercase()` returns `"X"`. One operand is required before effects; results reject container-only consumers until an explicit bridge yields a container. Source/operand/result snapshots and numeric aliases stay unchanged; other-backend/full admission stays separate. Existing Perl lexical compatibility compares undef as empty text with legacy uninitialized warnings when enabled, so `str_eq(undef,"")` returns1; Rust also retains the measured undef-as-empty compatibility; Dart/Julia/Lua instead propagate null from either comparison operand; Dart’s known UTF-16 lexical-order limitation remains tracked. Lua comparison checks use available PUC5.5.1/LuaJIT; declared5.4/full admission remain open. No portable null-domain claim follows.


The [six-method reference](../dsl/value-container-flow-helper-reference.md#scalar-predicates-and-string-comparisons)
shows lexical true/false examples. Perl, Rust, Dart, Julia and Lua retain actual-kind and rejection guards
through canonical free comparisons and ordinary comparison prefixes:

```text
str_eq("a","b").take(1)                         # null
"a".str_eq("b").take(1).with(){return("ran")}     # null; body skipped
str_lt("a","b").split(",").set_key("k",1).with(){return("ran")} # null
str_eq("a","b").with(){return([value,value.copy()])}           # Perl [0,0], other backends [false,false]
str_eq("a","a").add("bad").with(){return("null")}              # "null"
```

Incompatible consumer operands and later bodies stay skipped; source operands
still run once in order. Legitimate zero/null/empty results enter `with`, and
an Array returned by a valid body may continue with Array methods. Perl reports
ready ActionIR metadata; Rust/Dart/Julia/installed Lua pass their native/restored
compiled-spec/SpecFile/generated-plan controls, with fresh emitted modules on
Julia/Lua. Regenerate emitted Perl parsers and rebuild Rust/Dart/Julia/Lua apps/runtime.
Lua proof uses available PUC5.5.1/LuaJIT; declared5.4 and full source/domain/context
admission remain separate. Existing result kinds stay distinct;
the producer/null/Unicode qualifications above remain unchanged.

> **Worked examples** use the same runnable two-rule shape as §2 (a top `::` entry rule
> — no regex — dispatching to a `value` rule that carries the regex and reads
> `entry_group(N)`; output = the parser's one-element accumulator array). The array-form
> reducers (`num_sum`, `num_avg`, `num_median`, `num_range`, and the array form of
> `num_min`/`num_max`) take an array of numeric values: use explicit `array(...)` in function form, or a
> compatible array receiver such as `scores.sum()` / `scores.min()`. Build literal arrays from
> capture groups (`array(entry_group(0), entry_group(1), …)`) or numeric literals. An
> `undef` result (e.g. divide-by-zero) surfaces as a `null` element.

Perl, Rust, Dart, Julia and the tested Lua hosts preserve actual result kinds
through canonical free arithmetic calls and
ordinary short Number prefixes, including later immediate `with`:

```text
num_add(1,2,3).cat("!")                   # "6!"
num_add(1,2).take(1)                      # null
1.add(2).take(1).with(){return("ran")}    # null; body skipped
num_add(1,2).split(",").first().cat("!")  # "3!"
num_div(1,0).with(){return("recovered")}  # "recovered"
```

Rejected container operations skip their operands and later bodies; a legitimate
null or empty value still enters `with`. Source and operands run once in order,
snapshots and zero-valued indices keep their kinds, and source errors remain visible.
The Perl paths have ready ActionIR metadata; Rust, Dart, Julia and tested Lua
pass their native, restored compiled-spec/SpecFile and generated-plan controls,
with Julia/Lua also checked through fresh emitted modules. Lua checks use installed
PUC5.5.1/LuaJIT; declared5.4/full admission remain separate. Regenerate emitted Perl
parsers and rebuild native applications/runtime. Scalar/Array min/max overloads
and numeric domains stay unchanged. Matching values alone do not establish
support in an unready context.

### Numeric comparisons: `num_eq`, `num_ne`, `num_gt`, `num_ge`, `num_lt`, `num_le`

Each function takes exactly two numeric operands. Its short receiver method takes
exactly one right-hand operand. Valid results are Number `1` or `0`; invalid
numeric inputs return null. Finite Numbers and the contracted untrimmed decimal
Strings are accepted; Bool, null, containers and malformed numeric Strings are
rejected. Use the separate `str_*` family for lexical comparisons.

| Function signature | Receiver form | True example → `1` | False example → `0` |
| --- | --- | --- | --- |
| `num_eq(a, b)` | `a.eq(b)` | `num_eq(2,2)` | `num_eq(2,3)` |
| `num_ne(a, b)` | `a.ne(b)` | `num_ne(2,3)` | `num_ne(2,2)` |
| `num_gt(a, b)` | `a.gt(b)` | `num_gt(3,2)` | `num_gt(2,3)` |
| `num_ge(a, b)` | `a.ge(b)` | `num_ge(2,2)` | `num_ge(2,3)` |
| `num_lt(a, b)` | `a.lt(b)` | `num_lt(2,3)` | `num_lt(3,2)` |
| `num_le(a, b)` | `a.le(b)` | `num_le(2,2)` | `num_le(3,2)` |

```text
num_eq("02",2)                              # 1; strict decimal conversion
num_lt("-.5",0)                             # 1
num_eq(false,0)                             # null; Bool is not numeric
num_eq(2,3).coalesce_nonempty(9).cat("!")      # "0!"; zero stays present
num_eq(2,3).split(",").first().cat("!")       # "0!"
num_eq(2,3).with(){return(value.add(2))}      # 2; valid zero enters the body
```

Source and operands evaluate once in order; later consumers use the computed
result. Perl, Rust, Dart, Julia and tested Lua also retain kind guards through
canonical free comparison calls
and ordinary short comparison prefixes, including intermediate Array bridges:

```text
num_eq(2,3).take(1)                         # null
2.eq(3).take(1).with(){return("ran")}       # null; body skipped
num_lt(2,3).split(",").set_key("k",1)        # null
num_eq("bad",2).coalesce([]).with(){return(value.count())} # 0
```

Incompatible consumer operands and later bodies stay skipped; legitimate
zero/one/null/empty values still enter `with`. These Perl paths execute with
ready ActionIR metadata; Rust, Dart, Julia and tested Lua pass their native,
restored compiled-spec/SpecFile and generated-plan controls, with Julia/Lua also
checked through fresh emitted modules. Lua checks use installed PUC5.5.1/LuaJIT;
declared5.4/full source-domain-context admission remain separate. Numeric kinds,
source effects, snapshots and needed errors are preserved. Regenerate emitted
Perl parsers and rebuild native apps/runtime; numeric domains/arity/aliases stay
unchanged.

### `num_add(a, b)`
- **Signature**: `num_add(a: numeric, b: numeric, ...: numeric)` (two or more scalar operands)
- **Returns**: numeric
- **Behavior**: Adds all operands. Every operand must be numeric; `num_add(1, 2, 3)` uses all three.
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /(\d+)\+(\d+)/  I.return( num_add(entry_group(0), entry_group(1)) )
  ```
  Input `2+3` → `[5]`.

### `num_sub(a, b)`
- **Signature**: `num_sub(a: numeric, b: numeric)`
- **Returns**: numeric
- **Behavior**: Subtracts `b` from `a`.
- **Example**: over `/(\d+)-(\d+)/`, `num_sub(entry_group(0), entry_group(1))` on `10-4` → `[6]`.

### `num_mul(a, b)`
- **Signature**: `num_mul(a: numeric, b: numeric, ...: numeric)` (two or more scalar operands)
- **Returns**: numeric
- **Behavior**: Multiplies all operands. Every operand must be numeric; `num_mul(1, 2, 3)` uses all three.
- **Example**: over `/(\d+)x(\d+)/`, `num_mul(entry_group(0), entry_group(1))` on `6x7` → `[42]`.

### `num_div(a, b)`
- **Signature**: `num_div(a: numeric, b: numeric)`
- **Returns**: numeric
- **Behavior**: Divides `a` by `b`. Returns `undef` on divide-by-zero.
- **Example**: over `/(\d+)\/(\d+)/`, `num_div(entry_group(0), entry_group(1))` gives `[5]` on `20/4`, `[3.5]` on `7/2`, and `[null]` on `5/0`.

### `num_mod(a, b)`
- **Signature**: `num_mod(a: numeric, b: numeric)`
- **Returns**: int
- **Behavior**: Modulo operation. Returns `undef` for divide-by-zero or non-integer operands.
- **Example**: over `/(\d+)%(\d+)/`, `num_mod(entry_group(0), entry_group(1))` on `17%5` → `[2]`.

### `num_abs(x)`
- **Signature**: `num_abs(x: numeric)`
- **Returns**: numeric
- **Behavior**: Absolute value.
- **Example**: over `/(-?\d+)/`, `num_abs(entry_group(0))` on `-7` → `[7]`.

### `num_floor(x)`
- **Signature**: `num_floor(x: numeric)`
- **Returns**: int
- **Behavior**: Floor — largest integer ≤ x.
- **Example**: over `/([\d.]+)/`, `num_floor(entry_group(0))` on `3.7` → `[3]`.

### `num_ceil(x)`
- **Signature**: `num_ceil(x: numeric)`
- **Returns**: int
- **Behavior**: Ceiling — smallest integer ≥ x.
- **Example**: over `/([\d.]+)/`, `num_ceil(entry_group(0))` on `3.2` → `[4]`.

### `num_round(x)`
- **Signature**: `num_round(x: numeric)`
- **Returns**: int
- **Behavior**: Rounds to nearest integer, with halves away from zero. For example, `num_round(-2.5)` returns `-3`.
- **Example**: over `/([\d.]+)/`, `num_round(entry_group(0))` on `3.5` → `[4]`.

### `num_min(a, b)` / `num_min(arr)`
- **Signature**: `num_min(a: numeric, b: numeric, ...: numeric)` (two or more scalar operands) or `num_min(arr: array)`
- **Returns**: numeric
- **Behavior**: Returns the smallest scalar operand. Every operand must be numeric; `num_min(1, 2, 3)` uses all three. Array form: returns the minimum element. Returns `undef` for empty array, non-array, or non-numeric elements.
- **Example**: 2-arg — over `/(\d+),(\d+)/`, `num_min(entry_group(0), entry_group(1))` on `8,3` → `[3]`. Array — over `/(\d+),(\d+),(\d+),(\d+)/`, `num_min(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3)))` on `8,3,5,1` → `[1]` on the current Perl/JSON route (internal selected-kind limitation below). Ordinary Perl/Rust/Dart/Julia/Lua result chaining: `[2,4,6].min().add(1)` → `3`; `[2,4].sum().min(3).add(1)` → `4` keeps the scalar overload.

### `num_max(a, b)` / `num_max(arr)`
- **Signature**: `num_max(a: numeric, b: numeric, ...: numeric)` (two or more scalar operands) or `num_max(arr: array)`
- **Returns**: numeric
- **Behavior**: Returns the largest scalar operand. Every operand must be numeric; `num_max(1, 2, 3)` uses all three. Array form: returns the maximum element.
- **Example**: 2-arg — over `/(\d+),(\d+)/`, `num_max(entry_group(0), entry_group(1))` on `8,3` → `[8]`. Array — over `/(\d+),(\d+),(\d+),(\d+)/`, `num_max(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3)))` on `8,3,5,1` → `[8]` on the current Perl/JSON route (internal selected-kind limitation below). Ordinary Perl/Rust/Dart/Julia/Lua result chaining: `[2,4,6].max().add(1)` → `7`.

### `num_clamp(x, lo, hi)`
- **Signature**: `num_clamp(x: numeric, lo: numeric, hi: numeric)`
- **Returns**: numeric
- **Behavior**: Clamps `x` to the `[lo, hi]` range. Returns `undef` if bounds are inverted (`lo > hi`).
- **Example**: over `/(\d+)/`, `num_clamp(entry_group(0), 0, 10)` gives `[10]` on `42` and `[7]` on `7`.

### `num_sum(arr)`
- **Array value sources (Perl)**: Literals, bindings, direct reads and function arguments/results are accepted.
  See the [complete six-reducer example](../dsl/value-container-flow-helper-reference.md#numeric-reducers-consume-array-values), including empty arrays and receiver form.
- **Signature**: `num_sum(arr: array)`
- **Returns**: numeric
- **Behavior**: Sum of array elements. Returns `0` for empty array. Returns `undef` for non-array or non-numeric element sources. Ordinary Perl/Rust/Dart/Julia/Lua `[2,4,6].sum().add(1)` → `13` and `[1,2].sum().cat(" total").uppercase()` → `"3 TOTAL"`. Lua checks use available PUC5.5.1/LuaJIT; declared5.4/full admission remains open. Source snapshots and the sum are computed before later consumer operands; subsequent source mutation does not recompute the result.
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /(\d+),(\d+),(\d+),(\d+)/  I.return( num_sum(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3))) )
  ```
  Input `1,2,3,4` → `[10]`.

### `num_avg(arr)`
- **Signature**: `num_avg(arr: array)`
- **Returns**: numeric
- **Behavior**: Arithmetic mean of array elements. Returns `undef` for empty array, non-array, or non-numeric elements.
- **Example**: over `/(\d+),(\d+),(\d+)/`, `num_avg(array(entry_group(0), entry_group(1), entry_group(2)))` on `2,4,6` → `[4]`. Ordinary Perl/Rust/Dart/Julia/Lua result chaining: `[2,4,6].avg().add(1)` → `5`.

### `num_median(arr)`
- **Signature**: `num_median(arr: array)`
- **Returns**: numeric
- **Behavior**: Median of array elements after numeric sort. For even-length arrays, returns the average of the two middle elements. Returns `undef` for empty array, non-array, or non-numeric elements.
- **Example**: over `/(\d+),(\d+),(\d+),(\d+),(\d+)/`, `num_median(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3), entry_group(4)))` on `5,1,3,2,4` → `[3]` on the current Perl/JSON route (sorted `1,2,3,4,5`; internal selected-kind limitation below). Ordinary Perl/Rust/Dart/Julia/Lua result chaining: `[2,4,6].median().add(1)` → `5`; `[4,1,3,2].median().mul(2)` → `5`.

Current Perl type limitation: array-form `num_min`/`num_max` and odd-length
`num_median` can retain a selected numeric string's internal kind. Current
Perl5.34.1/JSON::PP4.06 renders the examples above as numbers, including when
replaying the recorded sources with the older owned Perl library. The September
quoted-JSON observations remain historical; their original process/instrument
is not reconstructed. JSON alone is insufficient: these selected results still
fail as array-write indexes with `nested_write_kind_conflict`, while scalar
min/add controls work. `SESSION-STARTUP-READING.95` owns the internal-kind repair.
See the [worked numeric-index conversion](../dsl/values-containers-and-flow-helpers.md#aggregate-numeric-helpers-in-codeblocks)
for an arithmetic workaround. No result-kind fix is claimed by callback availability.

### `num_range(arr)`
- **Signature**: `num_range(arr: array)`
- **Returns**: numeric
- **Behavior**: `max - min` of array elements. Returns `undef` for empty array, non-array, or non-numeric elements.
- **Example**: over `/(\d+),(\d+),(\d+),(\d+)/`, `num_range(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3)))` on `3,9,1,7` → `[8]` (`9 - 1`). Ordinary Perl/Rust/Dart/Julia/Lua result chaining: `[2,4,6].range().add(1)` → `5`.

## 6. Control Flow Helpers

> **Worked examples** use the standard `demo:: -> value .push` scaffold unless stated otherwise.
> Examples that read `entry_group(0)` use a regex with an explicit capture group.

**Verified branch, loop, and return examples:**

| Surface | Body inside `value`'s `I { ... }` block | Input | Output |
| --- | --- | --- | --- |
| Inline `if(...)` value | `return(if(str_eq(entry_group(0), "hot"), "H", else("C")))` over `/([A-Za-z]+)/` | `hot` | `["H"]` |
| Marker `if`/`elseif`/`else` | `kind = entry_group(0); if(str_eq(kind, "a")); return("A"); elseif(str_eq(kind, "b")); return("B"); else(); return("Z"); endif()` over `/([A-Za-z]+)/` | `b` | `["B"]` |
| Attached `if` blocks | `kind = entry_group(0); if(str_eq(kind, "a")) { return("A") } elseif(str_eq(kind, "b")) { return("B") } else { return("Z") }` over `/([A-Za-z]+)/` | `b` | `["B"]` |
| `when` / `otherwise` | `kind = entry_group(0); when(str_eq(kind, "yes")) { return("Y") } otherwise { return("N") }` over `/([A-Za-z]+)/` | `yes` | `["Y"]` |
| Inline `switch(...)` value | `kind = entry_group(0); return(switch(kind, case("a", "A"), case("b", "B"), default("Z")))` over `/([A-Za-z]+)/` | `b` | `["B"]` |
| Attached `switch` blocks | `kind = entry_group(0); switch(kind) { case("a") { return("A") } case("b") { return("B") } default { return("Z") } }` over `/([A-Za-z]+)/` | `b` | `["B"]` |
| `while` loop | `count = 0; while(num_lt(count, 3)) { count = num_add(count, 1) }; return(count)` | `x` | `[3]` |
| `return(value)` | `return(entry_group(0))` over `/([A-Za-z]+)/` | `ok` | `["ok"]` |
| `return_undef()` | `if(str_eq(entry_group(0), "skip")) { return_undef() } else { return(entry_group(0)) }` over `/([A-Za-z]+)/` | `skip` | `[null]` |

**Verified repetition-control example:**

```text
demo::
 -> value .push
 LX { return(copy(demo)) }

value : /(keep|skip|take)\s*/
 I { if(str_eq(entry_group(0), "skip")) { next() } else { return(entry_group(0)) } }
```

Input `keep skip take ` yields `["keep","take"]`: `next()` consumes the `skip` repetition without appending a
value to `demo`'s accumulator.

**Compile-only fatal-exit example:** `exit_now(2)` is descriptor-verified as language-agnostic control metadata
(`ready=1`, `raw=0`, `fallback=0`, `unresolved=0`, canonical nodes `["EXIT"]`). It is not run in the example
table because its runtime behavior is to terminate the parser process.

### `and(value, ...)`, `or(value, ...)`, and `not(value)`
- **Target signatures**: `and` and `or` require at least one positional value; `not` requires exactly one.
- **Target returns**: a real boolean. One-argument `and`/`or` are boolean projections. Ordinary Perl direct results support `and(true).cat("!")` → `"1!"`, `and(false).coalesce_nonempty("late").cat("!")` → `"0!"`, and `or(false).add(1).coalesce_nonempty(["a","b"]).last().uppercase()` → `"B"`; numeric helpers still reject Boolean input. Perl/Rust/Dart/Julia/Lua also support `and(true).cat(",x").split(",").last().uppercase()` → `"X"` (and corresponding `or`/`not` results), clean null from container-only consumers such as `not(false).sorted()`, and typed source arity errors even with invalid operands. Existing source/counter snapshots and eager `LRC` ordering hold. Perl/Rust/Dart/Julia/Lua retain valid logical source and completed prefix effects before incompatible container consumers return null, while skipping the incompatible consumer operands. Malformed consumer shapes retain their existing preflight rules. Dart/Julia/Lua also keep actual Boolean selections scalar: `[and(true)].first().sorted()` → `undef`; their existing named container-context normalization is unchanged. All five bounded result implementations are targeted-checked; Lua uses available PUC5.5.1/LuaJIT and declared5.4/full result-family admission remain separately tracked under `TYPE-REFERENCE-BOOK.1.2.23.3.17`. This qualification concerns broader ordinary chains beyond the historical logical contract projection below.
- **Target evaluation**: after arity succeeds, every operand runs exactly once from left to right. Logical helpers
  do not short-circuit; `if`/`switch`/`while` remain the lazy mechanisms.
- **Target truthiness**: null, false, numeric zero, the empty string, and empty arrays/harrays are false. Other
  finite numbers, every nonempty string (including `"0"` and `"false"`), nonempty aggregates, and codeblocks are
  true. Testing a codeblock does not invoke it.
- **Target failures**: empty `and`/`or`, empty `not`, and multi-argument `not` report
  `helper_arity_mismatch` before evaluating any operand.
- **Scope boundary**: the codeblock value-kind row is model/backend-unit evidence; it does not activate the
  separately owned `{|...| ... }` literal syntax.
- **Current portability status**: ADR `0043` and `linkedspec-logical-helper-v1` are adopted. Perl native/live/
  standalone-emitted execution conforms under `FUTURE-PARITY-BACKLOG.5.2.2`; Rust native, serialized,
  generated-plan, direct-value, and compiled emitted execution conforms under `.5.2.3`; Dart native, normalized,
  generated-plan, standalone-emitted, and primary execution conforms under `.5.2.4`; Julia native, normalized,
  generated-plan, independently compiled emitted, and primary execution conforms under `.5.2.5`; Lua native,
  reconstructed, generated-plan, loaded emitted-module, and primary execution conforms on both ABIs under
  `.5.2.6`. Generated/primary `.5.2.7` proves every available direct/traced generated role, exact failure/source
  attribution, Rust's established direct-value versus compatibility-output split, and one common five-command
  default/POSIX primary case. Recurring `.5.2.8` now composes the neutral checker, exact native/generated roles
  for Perl/Rust/Dart/Julia/PUC-Lua/LuaJIT, selected 5x2x1 case, and support ledgers under one omission-checked
  driver. Public no-drift `.5.2.9` locks the authoritative guide/backend/status set and closes rollout at
  8 complete / 0 pending. Run `bash tools/check_logical_helper_five_backend.sh` for the recurring all-toolchain
  behavior proof; the offline checker also rejects public document, marker, stale-claim, and admission drift.

Boolean results also cross explicit type bridges: `and(false).split(",").first()`
is the String `"0"`, while `and(false).with(){return(value)}` keeps Bool false.
A numeric method still rejects Bool: `and(false).add(1)` yields null, which may
legitimately enter a subsequent `with` body. Perl, Rust, Dart, Julia and Lua preserve rejection state
through canonical logical free calls and ordinary `.and`/`.or`/`.not` prefixes:

```text
and(false).take(1).with(){return("ran")}      # null; body skipped
false.and(true).take(1).with(){return("ran")} # null; body skipped
not(false).split(",").set_key("k",1).with(){return("ran")} # null; body skipped
and(false).with(){return(["ok"])}.first().uppercase()     # "OK"
and(false).add(1).with(){return("null")}                  # "null"; body runs
```

Incompatible operands and later bodies stay skipped, while source operands
still run eagerly once in order. Perl reports ready ActionIR metadata; Rust, Dart,
Julia and installed Lua hosts pass their native, restored compiled-spec/SpecFile
and generated-plan controls, with fresh emitted modules on Julia/Lua. Valid
false/null/empty values remain distinct from rejected consumers. Regenerate emitted
Perl parsers and rebuild Rust/Dart/Julia/Lua apps/runtime. Lua proof uses available
PUC5.5.1/LuaJIT; declared5.4 and full source/domain/context admission remain separate;
typed truth, Boolean kinds and arity errors remain unchanged.

### `if(cond, then, elseif(cond2, then2), else(default))`
- **Signature**: Inline composite value form.
- **Returns**: value of the selected branch in supported value positions. Ordinary Perl/Rust/Dart/Julia/Lua (available PUC5.5.1/LuaJIT) inline results support direct reads and compatible methods: `if(true,["a","b"],[])[-1].uppercase()` returns `"B"`; missing/no-fallback selections yield undef. Conditions/payloads retain their lazy order and kinds.
- **Behavior**: Evaluates conditions left-to-right and evaluates only the selected branch payload. First true
  condition's branch is returned. If none match, the `else(...)` branch or plain third-argument fallback is
  returned. If no fallback matches, returns `undef`.
- **Portability status**: Implemented on Perl, Rust, Dart, Julia, and Lua in `return(...)`, assignment RHS, and
  fluent `.return(...)` value positions. Perl, Rust, Dart, Julia, and Lua consume ADR `0043` through one
  helper/condition truth seam per backend. `FUTURE-PARITY-BACKLOG.5.2.8` owns the recurring six-consumer
  native/generated/primary/support proof; `.5.2.9` closes public no-drift and parent `.5.2` at 8/0.

### `if(cond); ... elseif(cond2); ... else(); ... endif()`
- **Signature**: Statement-marker form.
- **Returns**: no value of its own; branch statements provide side effects or `return(...)` values.
- **Behavior**: Conditions are evaluated left-to-right. Only statements in the active branch execute. `else`
  runs when no prior branch matched, and `endif()` closes the chain.
- **Sugar**: `else` and `endif` bare-keyword forms are equivalent to `else()` and `endif()`.

### `if(cond) { ... } elseif(cond2) { ... } else { ... }`
- **Signature**: Attached-block statement form.
- **Returns**: no value of its own; branch statements provide side effects or `return(...)` values.
- **Behavior**: Conditions are evaluated left-to-right. Only statements in the active branch execute. The
  implicit close at the end of the attached chain is equivalent to `endif()`.
- **Sugar**: Compact continuations such as `} elseif(cond2) {` and `} else {` are accepted. A following
  same-line statement still needs the normal semicolon separator after the final `}`.

### `when(cond) { ... } otherwise { ... }`
- **Signature**: Attached-block alias form.
- **Returns**: no value of its own; branch statements provide side effects or `return(...)` values.
- **Behavior**: Equivalent to `if(cond) { ... } else { ... }`. The Perl reference and Rust backend
  normalize the aliases to canonical `if`/`else` control flow; they are not host-language `when` blocks.
- **Portability boundary**: Use `when/otherwise` only in this attached shape and `i/elif` only in marker chains.
  Perl, Dart, and Julia currently accept more combinations than Rust; backlog `.5` owns normalization.

### `switch(expr, case(val, body), default(body))`
- **Signature**: Inline composite form.
- **Returns**: value of the first matching `case` body, or the `default` body when no case matches. Ordinary Perl/Rust/Dart/Julia/Lua (available PUC5.5.1/LuaJIT) inline results support direct reads: `switch("k",case("k",{"items":["a","b"]}))["items"][-1].uppercase()` returns `"B"`. The subject and selected source evaluate once; later selectors and methods retain their normal order and kind guards.
- **Behavior**: Evaluates `expr` once, compares it to each `case(val)` in order, and evaluates only the
  selected branch payload. A bare switch subject such as `switch(kind, ...)` reads scalar `kind`; a bare case
  value such as `case(foo, body)` is a literal tag named `foo`, matching attached-switch case labels.
- **Portability status**: Implemented on Perl, Rust, Dart, Julia, and Lua in `return(...)`, assignment RHS, and
  fluent `.return(...)` value positions.
- **Comparison boundary**: Null matches empty text on all current backends. Boolean/number and aggregate
  comparison are not yet portable: Perl/Rust/Lua make `false` match numeric `0`; Dart/Julia do not. Perl/Lua do
  not scalar-compare arrays/harrays, Rust currently collapses them to empty text, and Dart/Julia stringify host
  containers. Use text/number predicates to normalize a subject before switching when these kinds are possible;
  `FUTURE-PARITY-BACKLOG.5` owns the final typed-equality policy.

### `switch(expr) { case(val) { ... } default { ... } }`
- **Signature**: Attached-block statement form.
- **Returns**: no value of its own; branch statements provide side effects or `return(...)` values.
- **Behavior**: Evaluates `expr` once. `case(...)` branches are tested in order, only the first matching branch
  executes, and `default` executes only when no case matched. A bare switch subject reads the working scalar; a
  bare case label is a literal tag, so `switch(kind) { case(foo) { ... } }` compares scalar `kind` to `"foo"`.
- **Sugar**: `default() { ... }` is equivalent to `default { ... }`. A following same-line statement still
  needs the normal semicolon separator after the final `}`.
- **Portability status**: Implemented on Perl, Rust, Dart, Julia, and Lua. It shares the inline form's pending
  boolean/number and aggregate comparison boundary above.

### `switch(expr); case(val); ...; endcase(); default(); ...; endswitch()`
- **Signature**: Marker-delimited statement form.
- **Returns**: no value of its own; selected branch statements provide side effects or `return(...)` values.
- **Behavior**: Evaluates `expr` once, selects the first matching `case` or one `default`, and skips every later
  candidate and body. `endcase()` is an optional explicit branch boundary; the next same-depth `case`, `default`,
  or `endswitch()` also closes the current branch. Nested marker switches own their inner markers.
- **Portability status**: Implemented on Perl, Rust, Dart, Julia, and Lua. Bare labels and the comparison boundary
  are identical to inline and attached switch. Keep every executable statement inside a case/default range:
  Perl currently executes statements outside all ranges, while Rust/Dart/Julia/Lua skip them. Backlog `.5` owns
  normalization.

### `while(cond) { ... }`
- **Signature**: Attached-block statement form.
- **Returns**: no value of its own; body statements provide side effects or `return(...)` values.
- **Behavior**: Perl, Rust, Dart, Julia, and Lua evaluate `cond` before every iteration and expose body mutation to
  the next condition. A `return(expr)` exits the surrounding action, or stays local when the loop is inside an
  expression-valued block.
- **Safety**: The default deterministic guard is 10000 body executions. Perl/Rust/Lua recheck the condition after
  the final allowed body and fail only if it remains true; Dart/Julia currently fail immediately. Lua's typed
  failure includes code, keyword, ActionIR kind, configured limit, and rule.
- **Portability boundary**: Do not rely on `next()` inside the body yet. Perl/Lua treat it as inner-loop continue,
  Rust treats it as a no-op, and Dart/Julia propagate it to rule repetition. Backlog `.5` owns guard/flow
  normalization.

### `case(val, body)`
- **Signature**: Inline switch branch.
- **Returns**: branch body value.
- **Behavior**: Embedded in inline-composite `switch(expr, case(...), ...)`. A bare first argument is a literal
  tag. Use a value expression such as `case(cat(foo, ""), body)` when the case value should be read dynamically
  from a working variable.

### `default(body)`
- **Signature**: Default switch branch.
- **Returns**: branch body value.

### `exit_now(status)`
- **Signature**: `exit_now(status: int)`
- **Returns**: never returns — terminates parser immediately.
- **Behavior**: Exits the parser with the given exit status. Used for fatal diagnostic paths.
- **Compatibility**: Bare `exit` is legacy; `exit_now(...)` contributes canonical `EXIT` metadata.

### `next()`
- **Signature**: `next()`
- **Returns**: control flow — skips to next repetition.
- **Behavior**: Skip the current repetition and advance to the next in repeated-rule loops. Consumes/recognizes input without appending a value.
- **Syntax**: Perl, Rust, Dart, Julia, and Lua accept standalone bare `next`; it is the same zero-argument operation as `next()`.

### `return(value)`
- **Signature**: `return(value: expr)`
- **Returns**: the supplied value through the active return channel.
- **Behavior**: As a top-level action or lifecycle statement, writes the surrounding rule/action return channel. Inside an expression-valued block, it is block-local: it yields that block's value and skips later statements in the block.
- **Edge cases**: `return(array(...))` returns an array value. A bare scalar source such as `return(count)` reads the working scalar `count`; primitive literals stay exact, so `return(true)` is the boolean literal and `return(undef)` is `undef`. A final non-`return(...)` statement in a lifecycle block is evaluated as a statement and is not an implicit rule return.

For the retired tagged-return family, see [Migrating the retired tagged returns](../dsl/values-containers-and-flow-helpers.md#migrating-the-retired-tagged-returns). Its examples distinguish flat capture groups, nested arrays, and snapshot limits.

### `return_undef()`
- **Signature**: `return_undef()`
- **Returns**: undef.
- **Behavior**: Explicitly returns undef. Used for flow-stop edges.

## 7. Capture and Mark Helpers

LinkedSpec tracks two kinds of capture origin: a single **anonymous capture
cursor** (set by `start_capture_slice()`) and any number of **named marks** (set
by `mark_here(name)`, `mark_input_start(name)`, and the other `mark_*` helpers).
The capture readers below extract text — or its character length — between such
an origin and one of three endpoints:

- the **start of the current match** — the non-cursor readers (`capture_slice`,
  `capture_slice_len`, `capture_take`, `capture_take_len`, `capture_from`,
  `capture_len_from`, `capture_take_len_from`);
- the **current scan position** (the cursor) — the `*_until_cursor*` readers;
- the **end of input** — the `*_rest*` readers.

The `capture_until_boundary(rule[, ...])` helper is the structural-lookahead
member of this family. It does not read from the anonymous capture cursor or a
named mark. It starts at the live cursor, seeks for named rule boundaries, and
captures the text before the earliest boundary match without consuming that
boundary.

Text readers return the captured substring; `*_len*` readers return its length in
**characters** (not bytes). A reader whose mark or required match endpoint is absent, or whose span is
reversed (end before start), returns `undef`. The `capture_take*` variants are
destructive: after reading they advance the capture origin — the anonymous cursor
or the named mark — to the **current scan position** (or to **end of input** for
the `_rest` readers), so the next capture continues from there. Note that the
match-start readers (`capture_take`, `capture_take_len`, `capture_take_len_from`)
read up to the match start but still advance the origin to the scan position.

> **Worked examples.** Boundary-oriented capture examples are often naturally
> default/OR-family snippets: an opener match records a boundary, the rule seeks to a
> later delimiter match, and the capture helper reads the text between them.

Anonymous capture cursor:

```text
demo::
 -> body .push
 LX { return(copy(demo)) }

body: /BEGIN/ /END/
 -> body[1] {
   return(hash("body", trim(capture_slice()), "width", capture_slice_len()))
 }
```

With `body:` deriving intrinsic `seek`, input `BEGIN alpha END` returns
`[{"body":"alpha","width":7}]`: `capture_slice()` spans the text between the
`BEGIN` match and the later `END` match, while `trim(...)` removes the surrounding
spaces for the displayed body.

Named marks and explicit span endpoints:

```text
demo::AND
 => pair

pair:AND
 /\[/
 /\w+/
 /:/
 /\w+/
 /\]/
 -> pair[0] { mark_here(body_start) }
 -> pair[2] {
   mark_match_start(colon_start)
   left = capture_between(body_start, colon_start)
   mark_here(right_start)
 }
 -> pair[4] {
   mark_match_start(close_start)
   return(hash(
     "left", left,
     "left_len", capture_len_between(body_start, colon_start),
     "right", capture_between(right_start, close_start)
   ))
 }
```

With `pair:AND` deriving intrinsic contiguous `consume`, input `[left:right]` returns
`[{"left":"left","left_len":4,"right":"right"}]`. The first action records the
left boundary, the colon action records an exact right boundary for `left` and a
new start for `right`, and the closing-bracket action records the final right edge.

### `start_capture_slice()`
- **Signature**: `start_capture_slice()`
- **Returns**: void
- **Behavior**: Moves the anonymous capture cursor to the current scan position.
- **Compatibility**: `capture_slice_here()` is a supported compatibility alias.

### `capture_slice()`
- **Signature**: `capture_slice()`
- **Returns**: scalar or undef
- **Behavior**: Returns the text from the anonymous capture cursor to the start of the current match.
- **Compatibility**: `capture_from_rule_start()` is a supported compatibility alias.

### `capture_slice_len()`
- **Signature**: `capture_slice_len()`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_slice()`. Preferred over raw position arithmetic.
- **Compatibility**: `capture_slice_length()` and `capture_len_from_rule_start()` are supported compatibility aliases.

### `capture_slice_until_cursor()`
- **Signature**: `capture_slice_until_cursor()`
- **Returns**: scalar or undef
- **Behavior**: Returns the text from the anonymous capture cursor to the **current scan position** (cursor).

### `capture_slice_until_cursor_len()`
- **Signature**: `capture_slice_until_cursor_len()`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_slice_until_cursor()`.

### `capture_until_boundary(...)`
- **Signature**: `capture_until_boundary(rule[, rule...])`
- **Returns**: scalar or undef
- **Behavior**: Treats each argument as a named boundary rule, quoted or bare. From the current live cursor, seeks for the earliest match of any valid boundary rule, returns the text from the original cursor to that boundary start, and moves the live cursor to that boundary start. The boundary match itself is not consumed. If at least one valid boundary rule exists but no boundary is found, captures through end-of-input and moves the cursor to end-of-input. If no requested boundary rule can be resolved to a pattern, returns `undef` and leaves the cursor unchanged.
- **Use it when**: an open-ended body should stop at the next structural token and that token must remain available to the normal rule path. This is different from `save_cursor()` / `restore_cursor()` and from `rewind_match_start()` / `rewind_entry_start()`: those helpers move an already-consumed cursor, while `capture_until_boundary(...)` avoids consuming the structural boundary in the first place.
- **Backend status**: Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT implement the named-rule boundary behavior. Lua
  uses a boundary-specific compiled-alternation cache and unconditional seek, so consume mode does not anchor the
  lookahead. The signature requires at least one rule; zero-argument behavior is not portable and is owned by
  `FUTURE-PARITY-BACKLOG.5`.

- **Perl quoted labels**: `capture_until_boundary("a,b,c", end)` requests two labels,
  `a,b,c` and `end`; it never expands the first into `a`, `b`, and `c`. Empty
  quoted labels are omitted. Escaped quotes and backslashes are decoded; spaces
  inside quotes remain significant. A quoted unresolved label follows the same
  no-usable-rule behavior as a bare unresolved label. See the
  [boundary reference](../dsl/source-boundary-helper-reference.md)
  for executable examples, including nested Perl unknown escapes. The boundary
  serializer preserves only recognized lexical calls whose complete decoded
  atoms agree with the typed arguments; this adds no grammar or source sidecars.
  These escape examples do not establish new rule-definition syntax or
  cross-backend escape parity.

### `capture_take()`
- **Signature**: `capture_take()`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_slice()` (anonymous cursor to the start of the current match), then advances the anonymous cursor to the **current scan position**.

### `capture_take_len()`
- **Signature**: `capture_take_len()`
- **Returns**: int or undef
- **Behavior**: Character length from the anonymous cursor to the start of the current match, then advances the anonymous cursor to the **current scan position**.

### `capture_take_until_cursor()`
- **Signature**: `capture_take_until_cursor()`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_slice_until_cursor()`, then advances the anonymous cursor to the cursor.

### `capture_take_until_cursor_len()`
- **Signature**: `capture_take_until_cursor_len()`
- **Returns**: int or undef
- **Behavior**: Like `capture_slice_until_cursor_len()`, then advances the anonymous cursor to the cursor.

### `capture_rest()`
- **Signature**: `capture_rest()`
- **Returns**: scalar or undef
- **Behavior**: Returns the text from the anonymous capture cursor to the **end of input**.

### `capture_rest_len()`
- **Signature**: `capture_rest_len()`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_rest()`.
- **Compatibility**: `capture_rest_length()` is a supported compatibility alias.

### `capture_take_rest()`
- **Signature**: `capture_take_rest()`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_rest()`, then advances the anonymous cursor to end of input.

### `capture_take_rest_len()`
- **Signature**: `capture_take_rest_len()`
- **Returns**: int or undef
- **Behavior**: Like `capture_rest_len()`, then advances the anonymous cursor to end of input.

### `mark_input_start(name)`
- **Signature**: `mark_input_start(mark_name: string)`
- **Returns**: void
- **Behavior**: Stores the absolute start-of-input position (0) under the named mark. Used for whole-input capture.

### `mark_input_end(name)`
- **Signature**: `mark_input_end(mark_name: string)`
- **Returns**: void
- **Behavior**: Stores the absolute end-of-input position under the named mark.

### `mark_copy(target, source)`
- **Signature**: `mark_copy(target_mark: string, source_mark: string)`
- **Returns**: void
- **Behavior**: Copies the `source` mark's position onto the `target` mark. If `source` is unset, the `target` mark is removed instead.

### `capture_from(name)`
- **Signature**: `capture_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Returns text from the named mark to the **start of the current match**.

### `capture_len_from(name)`
- **Signature**: `capture_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_from(name)`.

### `capture_until_cursor_from(name)`
- **Signature**: `capture_until_cursor_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Returns text from the named mark to the **current scan position** (cursor).

### `capture_until_cursor_len_from(name)`
- **Signature**: `capture_until_cursor_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_until_cursor_from(name)`.

### `capture_take_until_cursor_from(name)`
- **Signature**: `capture_take_until_cursor_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_until_cursor_from(name)`, then advances the mark to the cursor.

### `capture_take_until_cursor_len_from(name)`
- **Signature**: `capture_take_until_cursor_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Like `capture_until_cursor_len_from(name)`, then advances the mark to the cursor.

### `capture_take_len_from(name)`
- **Signature**: `capture_take_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Character length from the mark to the start of the current match, then advances the mark to the cursor.

### `capture_rest_from(name)`
- **Signature**: `capture_rest_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Returns text from the named mark to the **end of input**.

### `capture_rest_len_from(name)`
- **Signature**: `capture_rest_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_rest_from(name)`.

### `capture_take_rest_from(name)`
- **Signature**: `capture_take_rest_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_rest_from(name)`, then advances the mark to end of input.

### `capture_take_rest_len_from(name)`
- **Signature**: `capture_take_rest_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Like `capture_rest_len_from(name)`, then advances the mark to end of input.

### `capture_between(start, end)`
- **Signature**: `capture_between(start_mark: string, end_mark: string)`
- **Returns**: scalar or undef
- **Behavior**: Returns text between two named marks (requires `start` ≤ `end`).

### `capture_len_between(start, end)`
- **Signature**: `capture_len_between(start_mark: string, end_mark: string)`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_between(start, end)`.

## 8. Entry and Match Helpers

These helpers read from the **current match** — the regex capture that triggered the current code block.

> **Worked example: entry versus local match.** A no-regex top dispatcher enters a
> seeking child rule through the first slot (`name`) and the child returns from a
> later local slot (`Alpha`):
>
> ```text
> demo::
>  -> value .push
>  LX { return(copy(demo)) }
>
> value:
>  /(?<head>name)/
>  /\s*=\s*/
>  /(?<value>[A-Za-z_]+)/
>  -> value[1] {
>    eq = match_text()
>  }
>  -> value[2] {
>    return(hash(
>      "entry_text", entry_text(),
>      "entry_named", entry_named(head),
>      "entry_groups", entry_groups(),
>      "entry_map", entry_map(),
>      "entry_start", entry_start_pos(),
>      "entry_end", entry_end_pos(),
>      "local_text", match_text(),
>      "local_named", match_named(value),
>      "local_groups", match_groups(),
>      "local_map", match_map(),
>      "local_start", match_start_pos(),
>      "local_end", match_end_pos(),
>      "separator", trim(eq)
>    ))
>  }
> ```
>
> Input `name=Alpha` returns
> `[{"entry_end":4,"entry_groups":["name"],"entry_map":{"head":"name"},"entry_named":"name","entry_start":0,"entry_text":"name","local_end":10,"local_groups":["Alpha"],"local_map":{"value":"Alpha"},"local_named":"Alpha","local_start":5,"local_text":"Alpha","separator":"="}]`.
> The `entry_*` helpers read the match that entered `value` (the first slot, `name`);
> the `match_*` helpers in the final action read the current local slot (`Alpha`).

### `entry_text()`
- **Signature**: `entry_text()`
- **Returns**: scalar
- **Behavior**: Full text matched by the current match entry.

### `entry_group(index)`
- **Signature**: `entry_group(index: int)`
- **Returns**: scalar or undef
- **Behavior**: Numbered capture group by 0-based index over the **captured groups**.
  Index `0` is the **first** capture group (not the whole match — read the whole match
  with `entry_text()`). The list is **compacted**: capture groups that did not participate
  in the match are omitted, which shifts the indices of the groups that follow. Returns
  `undef` for an out-of-range index. See [Regex in `.spec`](../user-model/regex-in-spec.md#capture-groups).

### `entry_groups()`
- **Signature**: `entry_groups()`
- **Returns**: array (flat list of all captured groups, compacted — see `entry_group(index)`). Ordinary Perl/Rust/Dart/Julia/Lua actions can select directly: `entry_groups()[-1].uppercase()` returns the final capture as uppercase text. Lua checks use available PUC5.5.1/LuaJIT; declared5.4 proof remains open. A binding such as `groups=entry_groups(); groups[-1].uppercase()` and `copy(entry_groups())[-1].uppercase()` remain equivalent read forms; Perl's explicit/registered deferred callbacks keep their supported named-reader vocabulary.

### `entry_named(name)`
- **Signature**: `entry_named(name: string)`
- **Returns**: scalar or undef
- **Behavior**: Named capture group. Returns undef if the group does not exist. In ordinary Perl, `entry_named(head)` and `entry_named("head")` identify the same static capture; a working binding named `head` does not change that name. Single/double quoted names and discarded calls are supported. Unknown names return undef; participating empty/`"0"` captures remain Strings. Computed-name expressions and wrong arities remain unsupported/unready. Pure functions receive capture values as explicit arguments, for example `fn upper(text){return(text.uppercase())}` with `upper(entry_named("head"))`; they cannot invoke these parser-state readers in their bodies.

### `entry_has(name)`
- **Signature**: `entry_has(name: string)`
- **Returns**: integer `1` or `0`
- **Behavior**: Returns `1` if the named capture group exists in the entry match, else `0`. Ordinary Perl accepts static bare or quoted names, including `entry_has("head")`; a participating empty capture exists. `match_named`/`match_has` use the same name syntax for the current local match. Invalid name shapes are distinct from a valid unknown name: they remain unsupported/unready rather than reporting an ordinary missing capture.

### `entry_map()`
- **Signature**: `entry_map()`
- **Returns**: hash
- **Behavior**: All named capture groups as a hash (name → value). Ordinary Perl/Rust/Dart/Julia/Lua actions can use `entry_map()["head"].uppercase()` directly, or bind/copy the collection first. Quoted missing keys yield undef; compatible defaults and Array/Hash/String continuations use the selected value's actual kind. Accepted aliases follow the same source rule.
- **Compatibility**: `entry_named_map()` remains an accepted source-boundary compatibility alias; prefer `entry_map()`.

### `entry_len()`
- **Signature**: `entry_len()`
- **Returns**: int
- **Behavior**: Length of the matched text.

### `entry_start_pos()`, `entry_end_pos()`
- **Signature**: `entry_start_pos()`, `entry_end_pos()`
- **Returns**: int
- **Behavior**: Absolute start/end positions in the input.

### `entry_end_line()`, `entry_end_col()`
- **Signature**: `entry_end_line()`, `entry_end_col()`
- **Returns**: int
- **Behavior**: Line number and column of the match end position.

### `match_text()`, `match_group(index)`, `match_groups()`, `match_named(name)`, `match_has(name)`, `match_map()`, `match_len()`, `match_start_pos()`, `match_end_pos()`
- Same semantics as their `entry_*` counterparts but for the **local match** (the immediate regex match inside a code block, which may differ from the rule's entry match in nested contexts).
- If no local match exists, text/group/named/length/start/end values are `undef`, `match_groups()` is `[]`,
  `match_map()` is `{}`, and `match_has(name)` is `0`. Line and column readers retain their 1-based default of `1`.
  A real zero-width local match is different: its text/capture may be empty, but its length is `0`, its positions
  are the actual (possibly zero) offsets, and a present named empty capture makes `match_has(name)` return `1`.

## 9. Input Helpers

> **Worked example.** Input helpers read the whole input, not the current cursor,
> entry match, or local match:
>
> ```text
> demo::
>  -> value .push
>  LX { return(copy(demo)) }
>
> value : /.+/
>  I {
>    return(hash(
>      "text", input_text(),
>      "len", input_len(),
>      "slice", input_slice(1, 2),
>      "line", input_end_line(),
>      "col", input_end_col()
>    ))
>  }
> ```
>
> Input `abcd` returns `[{"col":5,"len":4,"line":1,"slice":"bc","text":"abcd"}]`.

### `input_text()`
- **Signature**: `input_text()`
- **Returns**: scalar
- **Behavior**: Returns the entire current input as a string. Ordinary Perl/Rust/Dart/Julia/Lua (available PUC5.5.1/LuaJIT) support direct scalar/default/inter-type flow: `input_text().coalesce("fallback").split("=")[-1].uppercase()`. The source is captured before later operands; defined empty text skips a defined-only fallback. Input/cursor scalar results reject Array/Hash-only consumers before their operands; declared Lua5.4/full admission remain separate.

### `input_slice(start, len)`
- **Signature**: `input_slice(start: int, length: int)`
- **Returns**: scalar
- **Behavior**: Returns a substring of the current input from `start` for `length` characters.

### `input_len()`
- **Signature**: `input_len()`
- **Returns**: int
- **Behavior**: Total length of the current input. Ordinary Perl/Rust/Dart/Julia/Lua (available PUC5.5.1/LuaJIT) preserve its Number kind through `input_len().coalesce(0).add(1)`, including zero-valued indices; a container-only consumer yields undef and skips its operands.

### `input_end_line()`, `input_end_col()`
- **Signature**: `input_end_line()`, `input_end_col()`
- **Returns**: int
- **Behavior**: Line/column at the end-of-input boundary, one character position past the final character. Computed without storing explicit marks.

## 10. Call Expression

### `call(child_rule)`
- **Signature**: `call(rule_name: bare rule-label token)`
- **Returns**: the child rule's return value
- **Behavior**: Invokes a child rule directly from action code and returns its result. Used for nested parsing delegation. This is parser-state work. On ordinary Perl, `fn bad(){return(call(Child))}` remains unsupported/unready under the pure-function contract. Rust, Dart, Julia and Lua (available PUC5.5.1/LuaJIT) reject the same parser-state function call at runtime before helper operands. Read the child result in the ordinary caller and pass that value explicitly, such as `upper(call(Child))` for `fn upper(text){return(text.uppercase())}`.
- **Edge cases**: The child rule must exist and be a valid body rule in the same `.spec` file. Use the bare
  rule label (`call(child)`), not a quoted string: current runtimes resolve the target from the raw action
  argument token. Inside an action edge, calling that edge's current target reads the one cached selected-child
  result; it does not launch a second child search or permit a later fallback dispatch. A body-less passive
  terminal has already been consumed by the parent dependency match, so its cached result is undefined/null and
  the child is not re-searched. Calling a different rule name remains an ordinary independent call.
- **Worked example**:
  ```text
  demo::
   -> child {
     retv = call(child)
     return(hash("child", retv, "len", length(retv)))
   }

  child: /(\w+)/
   I { return(uppercase(entry_text())) }
  ```
  Input `abc` returns `{"child":"ABC","len":3}`. The top action calls `child`, stores the child return in
  `retv`, and returns a hash directly; this example does not use the top accumulator wrapper. The `-> child`
  edge selects `child`, and `call(child)` consumes that selected result exactly once.

## Cross-Cutting Contracts

### Composition Guarantee
Pure value helpers support **unlimited nested composition**. Example:
```
count(drop_front(sorted_keys(merge_hash(copy(base), overlay))))
```
Any portable pure helper that accepts an array can receive the output of an array-returning helper. Any
portable pure helper that accepts a scalar can receive the output of a scalar-returning helper. Hash-consuming
helper argument slots accept bare harray working variables as snapshots, including both arguments of
`merge_hash(base, overlay)`. `copy(base)` is optional explicit-copy composition; removed single-name aggregate-
selector syntax is not a required type marker. Array-consuming helper argument slots likewise accept bare
array working variables as snapshots, so `count(drop_front(sorted(items)))` is portable. Array receiver-dot
value chains are the same composition written from the receiver side, so
`items.sorted().drop_front(2).first()` and `items.filter_match(/^a$/).count()` are portable. Hash receiver-dot
value chains apply the same rule to hash helpers, so
`meta.set_key("stage", "normalized").sorted_keys().join_values(",")` is portable and pure. String receiver-dot
chains apply the same rule to scalar string helpers, so `raw.trim().lowercase().substr(0, 12)` is portable,
and `raw.trim().split("-").lowercase_each().join_values("_")` bridges explicitly into the array family. Bare typed
bindings are accepted anywhere the helper contract admits the runtime value kind; quoted strings are literal
constructor payloads, not aliases or indirect lookup. Mutation statement forms remain available, and assignment/mutation operators also have
expression values where documented: `name = value` yields the stored value, `items += value` yields the updated
array snapshot, and `name[key] = value` yields the updated typed-root snapshot. Array end mutations likewise yield an
independent updated array and can continue through compatible receivers. Inline value `if`/`switch` is portable in the supported
value-consuming slots (`return(...)`,
assignment RHS, and fluent `.return(...)`), and its contract is the selected payload value rather than any
specific compatibility tag string.

### Receiver-Dot Method Families
Receiver-dot methods are available for the value families that have a typed receiver table:

- **String/scalar** receivers support pure string links such as `trim`, `lowercase`, `uppercase`,
  `replace_substr`, `rm_prefix`, `rm_suffix`, `substr`, `cat`, and `coalesce_nonempty`; `split(delim)`
  bridges to array chains; `length` feeds scalar/number methods. Perl/Rust/Dart/Julia/Lua `starts_with`, `ends_with`, `contains_substr`, and `matches` feed compatible scalar/text methods on recorded hosts; full admission remains open.
- **Array/list** receivers support pure array links such as `copy`, `sorted`, `reversed`, `take`, `drop_front`,
  `slice`, `concat_arrays`, `split_each`, `trim_each`, `filter_nonempty`, `uniq`, and `filter_match`. Count/Length results feed compatible scalar/number methods.
  Perl/Rust/Dart/Julia/Lua `contains` results feed compatible scalar/text/generic methods; Perl/Rust/Dart/Julia/Lua `is_empty`/`is_nonempty` results feed compatible scalar/text methods on recorded hosts; full admission remains open. Perl/Rust/Dart/Julia/Lua `index_of` feeds compatible scalar/number methods on recorded hosts; full admission stays open;
  `join_values` returns a String with ordinary Perl/Rust/Dart/Julia/Lua continuations on recorded hosts; full admission remains open. Ordinary Perl/Rust/Dart/Julia/Lua reducers (`sum`, `avg`, `median`, `range`, `min`, `max`) feed compatible scalar/number methods. `first` and `last` select an entry. Ordinary selected strings/numbers on Perl, Rust, Dart, Julia and Lua can continue through existing scalar methods: `" a :b ".split(/:/).first().trim().uppercase()` returns `"A"`, and `[2,3].last().mul(4)` returns `12`. Empty selections follow the next helper’s null behavior. Selected arrays/harrays also continue on all five ordinary backends: `[[3,1],[2]].first().sorted().last().add(4)` returns `7`, and `[{"b":2,"a":1}].first().sorted_keys().last().uppercase()` returns `"B"`. A selected value’s `copy()` preserves its actual array/harray kind. Lua checks use matching available PUC5.5.1/LuaJIT products; declared PUC5.4 proof remains LUA-STARTUP-READING.2.2. Rust scalar-null/operand repairs61.1/.61.2 are implemented with targeted checks; full scalar/fluent admission remains open.
- **Hash** receivers support pure hash links such as `copy`, `merge_hash`, `set_key`, `rename_key`,
  `drop_keys`, `pick_keys`, and `flat_hash`; `sorted_keys` and `sorted_values` bridge to array chains; `count_keys`
  feeds compatible scalar/number methods; Perl/Rust/Dart/Julia/Lua `has_key` feed compatible scalar/text methods. Hash-tree traversal receiver methods `walk_leaves`, `map_leaves`, and
  `reduce_leaves` are immediate block-bearing links with their own scoped callback bindings.
- **Array-tree traversal** uses the same block-bearing receiver method names on array-valued receivers, with
  Perl reference support from `SPEC-FORMAT-TERSE.13.2`, Rust/oracle parity from `SPEC-FORMAT-TERSE.13.3`, and
  Dart/Julia/Lua parity. Lua's shared root-kind proof passes 114/114 on both ABIs.
- **Number** receivers support terse numeric links such as `abs`, `floor`, `ceil`, `round`, `add`, `sub`, `mul`,
  `div`, `mod`, `clamp`, `min`, and `max`; `eq`, `ne`, `gt`, `ge`, `lt`, and `le` are terminal numeric
  comparisons.

Perl/Rust/Dart/Julia/Lua ordinary is_empty/is_nonempty results also support compatible scalar/text continuation. Other predicate and flow-result continuations remain separately tracked; Perl/Rust/Dart/Julia/Lua has_key support the scalar/text handoff above. Expression-valued blocks and pure user-function returns do not
have separate method tables: the yielded runtime value selects the compatible family above. Mutation forms,
lifecycle/control helpers, parser-state readers (`entry_*`, `match_*`, capture/input/mark helpers), declaration
helpers, and child-dispatch calls remain function, statement, or lifecycle surfaces unless a future task explicitly
adds type-correct receiver semantics.

### Fluent / Block Equivalence
For the locked ordinary helper families, structured-block form (`I { name = value }`) and compact
lifecycle-marker fluent-chain form (`I.set(name, value)`) produce the same behavior. Receiver-fluent
`when/otherwise` block chains are portable on action-edge and lifecycle-marker surfaces, and no-arg
action-edge `.push` / `.return(expr)` continuations are portable too. Explicit/flow action-edge chains beyond
that subset remain a separately locked surface.

### Undef Propagation
Most helpers propagate `undef` from their inputs to their outputs. Explicit `coalesce(...)` is the canonical way to provide a default. No helper silently converts `undef` to `0` or `""` unless documented otherwise.

### No Mutation Guarantee
Value and receiver forms that return arrays or hashes (`copy`, `merge_hash`, value-form `set_key(hash_expr, key, value)`, `rename_key`, `drop_keys`, `pick_keys`, `sorted_keys`, `sorted_values`, `map_leaves`, `drop_front`, `drop_back`, `take`, `take_last`, `slice`, `sorted`, `reversed`, `concat_arrays`, `filter_nonempty`, `filter_match`, `uniq`, `split`, `split_each`, `trim_each`, `lowercase_each`, `uppercase_each`) do **not** mutate their inputs. They return new containers. A standalone `split_each(name, delimiter)`, `trim_each(name)`, `filter_nonempty(name)`, `filter_match(name, regex)`, `lowercase_each(name)`, `uppercase_each(name)`, or `uniq(name)` call is a statement form and writes its result back to that explicit working array on Perl, Rust, Dart, Julia and Lua. For example, `items=["a:b","a:a"]; split_each(items,":"); filter_match(items,/^a$/); uniq(items); return(items)` returns `["a"]`. Operands evaluate once; an absent target initializes an empty array and an existing wrong kind fails. Stored helper results and receiver forms remain pure: `out=uniq(items)` leaves `items` unchanged. The three missing implementations are now present; `FUTURE-PARITY-BACKLOG.5.3.4` retains broader validation after feature coverage. `walk_leaves` is the explicit tree side-effect traversal: it returns the original hash or array tree and preserves ordinary callback side effects. On all five backends, `binding.map_leaves!() { block }` is the distinct atomic receiver-rebinding traversal. Other explicit mutation forms include `name = value`, `items += value`, `items.push_back(value)`, `items.push_front(value)`, `items.pop_back()`, `items.pop_front()`, `set_key(name, key, value)`, and `name[key] = value`.

### Canonical Terse Forms
The `.spec` format has migrated these helper families to terser spellings. The **terse spelling is canonical**:

| Canonical form | Related form | Notes |
|---|---|---|
| `set(target, value)` | `target = value` | typed value assignment. Both spellings bind scalar, array, harray, or codeblock RHS values and yield the stored value in value positions. A bare source `set(out, name)` reads `name`. |
| `name = value` / `=(name, value)` | `set(name, value)` / `name = value` | assignment expression/operator spelling. It stores the target and yields the stored typed value in value positions. |
| `items += value` | `push(items, value)` | array append operator. A bare RHS reads a scalar working variable; all-bare `push(A,B)` remains child-call syntax; in value positions it yields the updated array snapshot. |
| `items.push_back(value)` / `items.push_front(value)` / `items.pop_back()` / `items.pop_front()` | `items += value` for back append only | named array end mutations. They mutate a bare array binding and evaluate to an independent updated snapshot; pop methods discard the removed value. |
| `meta[key] = value` | `set_key(meta, key, value)` for explicit harray intent | typed-path assignment operator on all five backends (string→harray, nonnegative integer→array). Bare key/RHS identifiers read scalar working variables; value positions yield the updated root snapshot. |
| `payload["items"][0]["name"] = value` | direct nested access assignment | mutates a scalar-held array/harray path. All five backends create absent/unambiguous missing containers from evaluated string/integer selectors. Wrong kinds are never coerced and array gaps remain invalid. |
| `cat(args...)` | string value expression | String concatenation through the portable scalar-to-text contract: strings unchanged, booleans `1`/`0`, stable finite decimal text (`-0.0` → `0`, `1.0` → `1`), and null for any null/array/harray/codeblock argument. Retired `concat` remains unsupported. |
| `copy(container)` | array/harray snapshot | one unified `copy(...)` dispatches from the current runtime value kind. |

Direct nested access, for example `payload["children"][0]["name"]` or `payload["children"][i]["name"]`, is
also part of the terse surface. It is not a helper rename; it is the replacement surface for the older nested
path helper spelling. For reads, quoted segments are hash keys and bare path atoms such as `[i]` read scalar
working variables. As a lvalue on any backend, every segment is instead classified from its evaluated value kind.
A direct nested path mutates a scalar-held array/harray value tree with the vivifying rules described above.

The current helper aliases above lower within their supported statement/helper families. Assignment forms
(`set(...)`, `name = value`, and `=(name, value)`) now compose as value expressions when the
target receives a scalar, array, or hash RHS value. Mutation assignment operators also compose as value
expressions: `items += value` yields the updated array snapshot and `meta[key] = value` yields the updated typed-root
snapshot. Typed path failures throw exact diagnostics on every backend.
Array end mutations yield updated arrays too; pop methods still discard the removed element.
Value-producing helper aliases such as `cat(...)` and `copy(...)` compose in the value positions documented by
their contracts. New `.spec` authoring should prefer the terse names.

### Removed Helper Spellings

This catalog intentionally lists the current helper surface only. Deleted helper spellings are not contract
entries, not canonical ActionIR events, and not compatibility lowering paths. Update old specs to the current
forms documented above.
