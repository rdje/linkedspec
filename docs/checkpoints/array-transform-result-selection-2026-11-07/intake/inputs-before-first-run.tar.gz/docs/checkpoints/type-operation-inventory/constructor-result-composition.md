# Retained constructor result composition

Owner: TYPE-REFERENCE-BOOK.1.2.23.1.22; family23.3.61.
Status: Recorded bounded61 implementations and comparator61.0 targeted-checked on named routes/hosts; full domain/context/portable admission remains23.4.

Uniform binding retains array(), array("literal"), multi-expression Array calls,
hash() and paired ordinary key/value Hash calls. Exact one-bare-identifier
array(name)/hash(name) selectors remain compile-rejected. Original constructors
own element/pair/key/list-splice/odd/malformed/signature/domain/copy/alias policy;
no new flat-root boxing/selector/context/deferred/callback/schema authority.
Canonical retained ordinary values feed existing direct reads/compatible methods
and actual-kind guards. Evaluate source/arguments once before ordered selectors/
consumer arguments, retain nested kinds/local returns/function scope/snapshots/
empty values/needed errors. Incompatible consumers skip operands/later with;
valid empty constructor with remains an input and executes its body.

```text
array("head","tail")[-1].uppercase()              # TAIL
hash("k",["head","tail"])["k"][-1].uppercase() # TAIL
array("tail").set_key("k",1)                     # null target
hash("k","tail").take(1)                        # null target
```

## Public finite intake

Twenty-one programs retain native/fresh/descriptor/substitution/full emitted
source. Initial12 nine healthy/three outliers. Full21 has thirteen healthy value
programs/seven actual outliers/one qualified needed-runtime-error control. All
descriptors ready/raw0 despite Array-to-Hash handler-eval/fresh runtime failure
and Hash-to-Array argument-block handler/fresh source compilation failure with
warnings. Guard-before-with similarly runtime-fails. Existing primitive values/
reads/selected-bound guards/order/function/valid with/needed error already work.
Constructor source is absent from emitted_result_chain; reuse original typed
producer/current guard and scoped with rejection flow. Source producers stay.

Four outlier programs separately reveal P1 lexical sort comparator capture,
owned61.0 first: perl-sort-comparator-scope.md/shared perl_sort_scope_cases.json.
Without a/b variables, numeric/string layers sort correctly. Exact renaming or
function a/b parameters proves the capture; expected7 stays unchanged. This is
not constructor-payload corruption or permission to reserve valid names.

Shared constructor_result_cases.json has original12 plus three with/error controls.
Sort-scope shared7 retains all discriminating programs. Own production/activation
inputs unchanged before book update; actual producers/inputs/modules/results in
constructor-result-selection-intake.json.gz. P1 sort61.0 then constructor61.1 and
independent peers61.2-.5, no peer/domain/portable/full23.4 admission inferred.

## Bounded Perl61.1 outcome

Retained ordinary constructor results reuse current actual-kind guards through
intermediate links and scoped immediate-with rejection state. Invalid consumers
skip arguments/later bodies; legitimate empty/null with inputs still run. Original
typed payload/pair/splice/odd/malformed/selector/signature policies remain. Public
tools separately prove computed Hash keys passed raw DSL to tag normalization;
they now reuse typed value lowering, preserving bare/literal key policy, local
returns, ordered key/value snapshots, function scope and original needed errors.

Same19 baseline14healthy5RED to guard candidate18PASS1RED. Expanded23 baseline
18PASS5RED plus selected4 baseline2PASS2RED precede key edit; final unchanged25
PASS native/fresh/metadata. No full25 RED baseline claimed.23 values/original13/
candidate17/expanded17 healthy observations/inherited argument error exact;
eight excluded AST/lowerings unchanged. Nearest free-default/uniform-binding and
syntax pass. Actual source/producers/all inputs/epochs/setup corrections retained
in constructor-perl-intake.json.gz. Only explicitly preloaded/source-verified
overlay establishes original behavior; earlier overridden -I/diagnostic-prefix
reader errors are disqualified setup observations. Known SESSION7 wrapper EPERM
recurrence supplies no lifecycle claim. Regenerate emitted Perl. New25/shared15/
excluded8 canonical registration remains23.4.1-owned; Rust61.2 next, full admission
separate. Comparator61.0 preserves original expected7.

## Bounded Rust61.2 guards

Same24 tests19healthy5RED to24PASS native/restored CompiledSpec/in-process plan.
21 values/16 healthy observations/two needed errors/eight syntax shapes exact.
Canonical retained Array/paired Hash source admission reuses current direct/
trailing guards; invalid operands/later with skip, source once and valid null/
empty with stay. Computed keys/order/snapshots/functions already healthy; original
producers/readers/signatures/arity/with/copy/alias/function/parser/schema remain.
Final nearest free-default18/uniform-binding16/owned fmt pass. A memory-only writer
assertion failed before source writes; premature nominal accepted/nearest/fmt ran
unchanged baseline, retained/disqualified. Corrected writer and distinct final
phases establish acceptance; no setup RED credit. Actual inputs/producers/epochs:
constructor-rust-intake.json.gz. Rebuild apps/runtime. Dart61.3 next, no isolated
emitted package/exhaustive excluded-runtime/domain/full admission inference.

## Bounded Dart61.3 guards

Same24 tests19healthy5RED to24PASS native/restoredSpec/in-process plan;21 values/
16 healthy observations/two needed errors/eight public syntax shapes exact.
Canonical retained Array/paired Hash source admission feeds current common
guard; invalid operands/later with skip, source once/intermediate kinds/valid
null-empty with stay. Computed keys/order/snapshots/functions already healthy,
original producer/read/default retention/with/signature/arity/copy/alias/function/
parser/schema stay. Final nearest35/fatal owner-normal analysis/new-normal format0.
New helper formatting is isolated: indentation/one optional trailing argument
comma, remaining token text/surrounding source exact. Initial strict token
assertion caught comma before write; retained/corrected/no test RED credit.
Final-source runtime/nearest/analysis pass; whole-SDK format debt stays2.25-owned.
Actual producers/inputs/epochs: constructor-dart-intake.json.gz. Rebuild apps/
runtime; Julia61.4 next, no fresh isolated/exhaustive excluded-runtime/domain/full
admission inference.

## Bounded Julia61.4 guards

Same116 assertions96PASS20RED to116PASS native/restoredSpec/plan/fresh Module;
96 includes five passing route-key scaffolds in failed groups.21 values/16 healthy
observations/two needed errors/eight syntax shapes exact. Canonical ordinary
Array/paired Hash source predicate/current common guard and one runner include;
existing splice classifier reused. Invalid operands/later with skip; source
once/intermediate kinds/null-empty with stay. Computed keys/order/snapshots/
functions already healthy, original producer/read/default retention/with/arity/
signatures/copy/alias/function/parser/schema remain. Nearest free-default91/
uniform-binding61/strict depwarn pass; standalone Main imports/derived REPO_ROOT
supplied, standard precompile retained. Actual inputs/producers/epochs:
constructor-julia-intake.json.gz. Rebuild apps/runtime. Safe Lua61.5 next;
no isolated package/exhaustive excluded-runtime/domain/full admission inference.

## Safe installed Lua61.5 guards

Same116 checks96PASS20RED to116PASS per PUC5.5.1/LuaJIT2.1.1788460057;96 includes
five passing compile scaffolds in failed groups.21 values/16 healthy observations/
two errors/eight syntax shapes canonically exact on native/restoredSpec/plan/fresh
module, accepted hosts match. Canonical Array/paired Hash namespace predicate/
current common guard/three-line runner entry; no new interpreter chunk locals.
Rejected operands/later with skip, source once/intermediate kinds/empty-null with
stay. Computed keys/order/snapshots/functions already healthy; original producer/
read/default retention/with/signature/arity/copy/alias/function/parser/schema stay.
Per-host nearest free-default91/six default programs/loadfile/version pass, focused
stderr empty. Actual inputs/producers/results: constructor-lua-intake.json.gz.
Rebuild apps/runtime. Bounded61 outcomes recorded, next owned selection23.1.23.
No declared5.4/unsafe runner/formatter/isolated package/exhaustive excluded-runtime/
domain/full admission inference.
