#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
REPO_ROOT=$(cd -- "$SCRIPT_DIR/.." && pwd)
source "$REPO_ROOT/tools/project_data_env.sh"
linkedspec_project_data_enter_run "$REPO_ROOT/tools/run_lua_local.sh" "$@"
LUA_CMD=${LINKEDSPEC_LUA_CMD:-lua}
LUAJIT_CMD=${LINKEDSPEC_LUAJIT_CMD:-luajit}
export LUA_PATH="$REPO_ROOT/lua/src/?.lua;$REPO_ROOT/lua/src/?/init.lua;;"

log() {
 printf '[lua-ci] %s\n' "$*"
}

fail() {
 printf '[lua-ci] ERROR: %s\n' "$*" >&2
 exit 1
}

command -v "$LUA_CMD" >/dev/null 2>&1 || fail "required primary runtime not found: $LUA_CMD"
command -v perl >/dev/null 2>&1 || fail "required command not found: perl"

native_root=$(mktemp -d "${TMPDIR:?project-data initializer did not set TMPDIR}/linkedspec-lua-native.XXXXXX")
trap 'rm -rf "$native_root"' EXIT
primary_native="$native_root/puc"
secondary_native="$native_root/luajit"
export LINKEDSPEC_LUA_NATIVE_PUC_DIR="$primary_native"

log "building disposable PUC Lua native modules"
bash "$REPO_ROOT/tools/build_lua_native.sh" puc "$primary_native"
export LUA_CPATH="$primary_native/?.so;;"

cd "$REPO_ROOT"
log "checking the generated filesystem-free Lua MCP contract binding"
bash tools/run_python_project_data.sh tools/generate_lua_mcp_contract.py

log "syntax-checking Lua source"
find lua -type f \( -name '*.lua' -o -name 'linkedspec-lua' \) -print0 |
 while IFS= read -r -d '' file; do
  LINKEDSPEC_LUA_CHECK_FILE="$file" \
   "$LUA_CMD" -e 'assert(loadfile(os.getenv("LINKEDSPEC_LUA_CHECK_FILE")))'
 done

log "running primary PUC Lua tests"
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/mcp_contract_lua_binding_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/mcp_server_lua_dispatch_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/mcp_server_lua_stdio_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/mcp_server_lua_admission_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_source_foundation_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_compilation_foundation_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_static_graph_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_static_remaining_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_call_core_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_call_staged_generated_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_query_kernel_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_runtime_observation_native_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_runtime_projection_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_index_runtime_observation_generated_routes_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/semantic_introspection_lua_admission_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/unicode_rule_label_classifier_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/unicode_rule_label_routes_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/unicode_rule_label_identity_routes_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/body_fluent_whole_token_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/unicode_rule_label_negative_isolation_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/diagnostic_output_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/sexpr_document_v1_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/logical_helper_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/callable_codeblock_literal_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/root_rule_selection_core_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/root_rule_selection_routes_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/root_rule_selection_admission_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/rule_local_cursor_normalization_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/rule_local_cursor_execution_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/rule_local_cursor_descriptor_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/rule_local_cursor_generated_source_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/rule_local_cursor_option_removal_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/rule_local_cursor_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/source_boundary_compatibility_aliases_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/typed_source_location_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/recursive_observation_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/recognition_transaction_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/staged_ast_enrichment_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/progressive_span_dispatch_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/duplicate_regex_slot_identity_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/repeated_action_result_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/write_vivification_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/map_leaves_mutation_contract_test.lua
LINKEDSPEC_LUA_TEST_RUNTIME="$LUA_CMD" "$LUA_CMD" lua/test/run.lua

log "running shared primary CLI contract (default environment)"
env -u POSIXLY_CORRECT PERL5LIB= perl tools/run_cli_conformance.pl \
 --display-command 'lua/bin/linkedspec-lua' -- \
 "$LUA_CMD" '{{REPO_ROOT}}/lua/bin/linkedspec-lua'

log "running shared primary CLI contract (POSIX environment)"
env POSIXLY_CORRECT=1 PERL5LIB= perl tools/run_cli_conformance.pl \
 --display-command 'lua/bin/linkedspec-lua' -- \
 "$LUA_CMD" '{{REPO_ROOT}}/lua/bin/linkedspec-lua'

log "validating the exact checked-in corpus through the developer command"
corpus_output=$("$LUA_CMD" lua/bin/corpus_runner.lua --corpus rust/linkedspec-runtime/tests/corpus)
printf '%s\n' "$corpus_output" | grep -F 'fixtures: 105' >/dev/null ||
 fail "corpus runner fixture count drifted"
printf '%s\n' "$corpus_output" | grep -F 'status: manifest validated; execution not requested' >/dev/null ||
 fail "corpus runner validation boundary drifted"

log "executing the complete checked-in corpus through the developer command"
corpus_output=$("$LUA_CMD" lua/bin/corpus_runner.lua \
 --corpus rust/linkedspec-runtime/tests/corpus --execute)
printf '%s\n' "$corpus_output" | grep -F 'PASS proof_edge_array_literal' >/dev/null ||
 fail "corpus runner first result drifted"
printf '%s\n' "$corpus_output" | grep -F 'PASS capability_capture_named_surface' >/dev/null ||
 fail "corpus runner last result drifted"
printf '%s\n' "$corpus_output" | grep -F 'summary: 105 passed, 0 failed' >/dev/null ||
 fail "corpus runner complete execution drifted"

if command -v "$LUAJIT_CMD" >/dev/null 2>&1; then
 log "building disposable LuaJIT native modules"
 bash "$REPO_ROOT/tools/build_lua_native.sh" luajit "$secondary_native"
 log "running secondary LuaJIT compatibility tests"
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/mcp_contract_lua_binding_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/mcp_server_lua_dispatch_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/mcp_server_lua_stdio_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/mcp_server_lua_admission_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_source_foundation_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_compilation_foundation_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_static_graph_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_static_remaining_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_call_core_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_call_staged_generated_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_query_kernel_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_runtime_observation_native_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_runtime_projection_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_index_runtime_observation_generated_routes_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/semantic_introspection_lua_admission_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/unicode_rule_label_classifier_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/unicode_rule_label_routes_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/unicode_rule_label_identity_routes_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/body_fluent_whole_token_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/unicode_rule_label_negative_isolation_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
 "$LUAJIT_CMD" lua/test/diagnostic_output_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/sexpr_document_v1_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/logical_helper_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/callable_codeblock_literal_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/root_rule_selection_core_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/root_rule_selection_routes_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/root_rule_selection_admission_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/rule_local_cursor_normalization_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/rule_local_cursor_execution_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/rule_local_cursor_descriptor_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/rule_local_cursor_generated_source_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/rule_local_cursor_option_removal_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/rule_local_cursor_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/source_boundary_compatibility_aliases_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/typed_source_location_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/recursive_observation_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/recognition_transaction_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/staged_ast_enrichment_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/progressive_span_dispatch_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/duplicate_regex_slot_identity_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/repeated_action_result_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/write_vivification_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/map_leaves_mutation_contract_test.lua
 LUA_CPATH="$secondary_native/?.so;;" LINKEDSPEC_LUA_TEST_RUNTIME="$LUAJIT_CMD" \
  "$LUAJIT_CMD" lua/test/run.lua
 export LINKEDSPEC_LUA_NATIVE_LUAJIT_DIR="$secondary_native"
else
 log "LuaJIT compatibility runtime not installed; secondary leg skipped"
fi

log "proving Lua project data stays in repository storage"
bash tools/test_lua_project_data_storage.sh --reuse-complete-lua-gate

log "Lua local gate passed"
