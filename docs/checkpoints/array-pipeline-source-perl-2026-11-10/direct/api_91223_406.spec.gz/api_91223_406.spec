Value:: I {source={"k":"tail"};return(take_last(source,1))}
