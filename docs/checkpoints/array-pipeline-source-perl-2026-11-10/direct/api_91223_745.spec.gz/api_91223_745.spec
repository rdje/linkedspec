Value:: I {return(slice({return(num_clamp(1,2))},1).with(){return("masked")})}
