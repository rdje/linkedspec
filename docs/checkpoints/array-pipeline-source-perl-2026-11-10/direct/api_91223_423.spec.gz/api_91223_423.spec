Value:: I {order="";source=["head","tail"];out=take_last(source,1,{order=cat(order,"E");2});return([out,order])}
