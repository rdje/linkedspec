Value:: I {order="";source=["head","tail"];out=source.take_last(1,{order=cat(order,"E");2});return([out,order])}
