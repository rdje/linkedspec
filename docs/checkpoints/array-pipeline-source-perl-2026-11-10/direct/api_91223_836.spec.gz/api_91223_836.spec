Value:: I {source={"k":"tail"};return(source.drop_back(1).with(){return(value)})}
