Value:: I {return([sorted(["tail","head"]),["tail","head"].sorted()])}
