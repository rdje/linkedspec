fn clean(values) { return(uniq(trim_each(values))) }
fn divide(values,delimiter) { return(split_each(values,delimiter)) }
fn divide_inplace(values,delimiter) { split_each(values,delimiter); return(values) }
Top:: I {  source=[" a:A ",""," B:B "," a:A "]; saved=copy(source);
 trimmed=trim_each(source); nonempty=filter_nonempty(source);
 lower=lowercase_each(source); upper=uppercase_each(source); unique=uniq(source);
 parts_source=["a:b","c:d"]; parts=split_each(parts_source,":");
 delimiter=":"; dynamic=split_each(parts_source,delimiter);
 dynamic_receiver=parts_source.split_each(delimiter); dynamic_nested=count(split_each(parts_source,delimiter));
 dynamic_function=divide(parts_source,delimiter); delimiter_effects=0; order="";
 dynamic_computed=split_each({order=cat(order,"S"); ["x.y","z."]},
   {order=cat(order,"D"); delimiter_effects=num_add(delimiter_effects,1); "."});
 dynamic_empty=split_each([], {delimiter_effects=num_add(delimiter_effects,1); ":"});
 regex_parts=split_each(["aXb","cxd"],/x/i);
 statement_dynamic=copy(parts_source); split_each(statement_dynamic,delimiter);
 statement_effects=0; statement_computed=["a.b","c."]; statement_saved=copy(statement_computed);
 split_each(statement_computed,{statement_effects=num_add(statement_effects,1); "."});
 statement_empty=[]; split_each(statement_empty,{statement_effects=num_add(statement_effects,1); ":"});
 split_each(statement_absent,{statement_effects=num_add(statement_effects,1); ":"});
 statement_function=divide_inplace(parts_source,delimiter);
 letters=["a","b","a"];
 nested=uniq(uppercase_each(letters));
 filtered=filter_match(uniq(uppercase_each(letters)),/^A/);
 receiver=letters.uppercase_each().uniq();
 function=clean(source); effects=0;
 computed=uniq({ effects=num_add(effects,1); ["z","z","y"] });
 typed=[2,"2","x"]; typed_result=uniq(typed); typed_index=first(typed_result);
 typed_filtered=filter_match(typed,/^2$/); filtered_index=first(typed_filtered);
 typed_nonempty=filter_nonempty([2,"",undef]); nonempty_index=first(typed_nonempty);
 statement_unique=[2,"2",undef,""]; statement_unique_saved=copy(statement_unique); uniq(statement_unique);
 statement_filter=[2,"2","x"]; filter_match(statement_filter,/^2$/);
 statement_nonempty=[2,"",undef,"0"]; filter_nonempty(statement_nonempty);
 statement_indexed=["zero","one","two"];
 statement_indexed[first(statement_unique)]="unique";
 statement_indexed[first(statement_filter)]="filtered";
 statement_indexed[first(statement_nonempty)]="selected";
 indexed=["zero","one","two"]; indexed[typed_index]="unique";
 indexed[filtered_index]="filtered"; indexed[nonempty_index]="selected"; typed_result[0]=9;
 trimmed[0]="changed";
 mut=[" a:A ",""," b:B "," a:A "];
 trim_each(mut); filter_nonempty(mut); split_each(mut,":");
 lowercase_each(mut); uppercase_each(mut); uniq(mut);
 return([trimmed,nonempty,lower,upper,unique,parts,source,saved,parts_source,
   dynamic,dynamic_receiver,dynamic_nested,dynamic_function,dynamic_computed,dynamic_empty,delimiter_effects,order,regex_parts,
   statement_dynamic,statement_computed,statement_saved,statement_empty,statement_absent,statement_effects,statement_function,
   letters,nested,filtered,receiver,function,computed,effects,typed,typed_result,typed_index,
   typed_filtered,filtered_index,typed_nonempty,nonempty_index,indexed,mut,
   statement_unique,statement_unique_saved,statement_filter,statement_nonempty,statement_indexed]);
 }