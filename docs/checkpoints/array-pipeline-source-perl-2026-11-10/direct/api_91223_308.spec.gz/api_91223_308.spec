Value:: I {order="";out=take(["tail"],0).with(){order=cat(order,"W");return(value.count())};return([out,order])}
