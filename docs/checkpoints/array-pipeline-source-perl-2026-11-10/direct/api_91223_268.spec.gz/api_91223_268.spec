Value:: I {return([slice(["head","tail"],1,1),["head","tail"].slice(1,1)])}
