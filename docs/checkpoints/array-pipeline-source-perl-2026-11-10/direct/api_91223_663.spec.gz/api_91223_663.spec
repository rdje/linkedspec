Value:: I {order="";source=["head","tail"];out=source.reversed({order=cat(order,"E");2});return([out,order])}
