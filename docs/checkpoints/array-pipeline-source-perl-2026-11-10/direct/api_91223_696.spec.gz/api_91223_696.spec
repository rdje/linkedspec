Value:: I {order="";source=["head","tail"];out=concat_arrays(source,["extra"],{order=cat(order,"E");2});return([out,order])}
