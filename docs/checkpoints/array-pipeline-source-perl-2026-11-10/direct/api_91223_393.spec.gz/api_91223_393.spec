Value:: I {source=3;return(source.take_last(1))}
