Value:: I {source=undef;return(take_last(source,1))}
