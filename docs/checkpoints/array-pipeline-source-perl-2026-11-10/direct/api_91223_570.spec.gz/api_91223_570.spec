Value:: I {order="";source=["head","tail"];out=slice(source,1,1,{order=cat(order,"E");2});return([out,order])}
