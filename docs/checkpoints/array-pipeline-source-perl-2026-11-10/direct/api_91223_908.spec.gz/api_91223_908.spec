Value:: I {source=undef;return(source.reversed().with(){return(value)})}
