Value:: I {source=3;return(source.take(1))}
