Value:: I {order="";source=["head","tail"];out=source.concat_arrays(["extra"],{order=cat(order,"E");2});return([out,order])}
