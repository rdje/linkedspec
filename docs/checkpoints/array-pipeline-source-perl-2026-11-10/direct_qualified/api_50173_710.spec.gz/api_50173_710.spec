Value:: I {order="";out=sorted_values({"k":"tail"}).set_key({order=cat(order,"K");"k"},1);return([out,order])}
