Value:: I {source=["head","tail","end"];return(source.drop_back())}
