Value:: I {source={"k":"tail"};return(source.take(1))}
