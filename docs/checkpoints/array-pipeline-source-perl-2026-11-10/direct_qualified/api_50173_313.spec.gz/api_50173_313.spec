Value:: I {return(take({items="bad";items+=1;["tail"]},1))}
