Value:: I {source=["head","tail","end"];return(source.take_last())}
