Value:: I {source={"k":"tail"};return(source.slice(1,1).with(){return(value)})}
