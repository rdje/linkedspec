Value:: I {return(take_last({return(num_clamp(1,2))}).with(){return("masked")})}
