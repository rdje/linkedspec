Value:: I {source=undef;return(drop_front(source,1))}
