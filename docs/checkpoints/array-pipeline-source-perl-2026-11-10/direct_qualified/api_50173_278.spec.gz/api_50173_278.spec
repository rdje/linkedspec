Value:: I {return([reversed(["head","tail"]),["head","tail"].reversed()])}
