Value:: I {source={"k":"tail"};return(slice(source,1,1))}
