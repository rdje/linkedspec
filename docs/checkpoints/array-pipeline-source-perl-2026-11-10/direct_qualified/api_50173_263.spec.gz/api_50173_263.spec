Value:: I {return([drop_back(["head","tail"],1),["head","tail"].drop_back(1)])}
