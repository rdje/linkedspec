Value:: I {order="";source=["head","tail"];out=sorted(source,{order=cat(order,"E");2});return([out,order])}
