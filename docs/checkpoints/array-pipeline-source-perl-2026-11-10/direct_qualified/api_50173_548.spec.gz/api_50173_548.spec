Value:: I {source=undef;return(slice(source,1,1))}
