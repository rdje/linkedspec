Value:: I {source=undef;return(source.take(1).with(){return(value)})}
