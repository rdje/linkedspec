Value:: I {source=3;return(source.take(1).with(){return(value)})}
