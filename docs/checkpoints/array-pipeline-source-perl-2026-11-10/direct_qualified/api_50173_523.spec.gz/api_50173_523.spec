Value:: I {order="";source=["head","tail"];out=drop_back(source,1,{order=cat(order,"E");2});return([out,order])}
