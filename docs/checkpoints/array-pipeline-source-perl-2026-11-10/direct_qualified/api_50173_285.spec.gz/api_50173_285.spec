Value:: I {return([take(["head","tail"],1).last().uppercase(),reversed([{"k":"tail"}]).last().pick_keys("k").count_keys(),sorted(["b","a"]).join_values(",")])}
