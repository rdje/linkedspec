Value:: I {source=undef;return(source.drop_front(1))}
