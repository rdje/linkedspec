
### Perl pure-pipeline source acquisition

Perl79.1.0 acquires the unchanged36 plus98 own source questions/42 extra localized
host distinctions, then eight separate delimiter/pattern controls. Original17
composition failures remain. Fourteen literal Number3 free/receiver forms read
unrelated main::3 data through [@3]; empty-host/outer-package and computed {3}
controls remain empty. Every host snapshot stays unchanged. P1 source79.0 repairs
that source shortcut before result79.1.1, without changing global extractors,
producer fallback/coercion/Unicode/regex/copy/mutation or earlier owners.

The63 initial empty-host forms produce [] or count0/W; this alone never proves
Number isolation. Fourteen excluded arities retain free KW/unresolved helper or
receiver null/no effects/unresolved with. Six earlier owners keep their guards.
Bool/null/Number/text kinds stay exact, including the observed numeric Array trim
result. Terminal needed-delimiter errors and valid computed/variable/count
receivers work; composing the needed error with an incompatible consumer retains
DSL and fails compilation. That extra forwarding target belongs to79.1.1.

Four /(/ inputs are DSL syntax exclusions, not regex-producer observations. Four
balanced invalid-range controls reach actual regex compilation and fail before
consumers. Unloaded modules have load_error and no invented fresh invocation.
The184 programs retain180 actual module/parser-source pairs; four syntax
rejections have none.148 acquired profiles explicitly separate defects,
exclusions and preservation. First readonly0/empty stderr/ten corruptions passes,
including omitted error provenance and hidden host reads. Actual own input bytes/
modes precede SDK use and generated inputs precede execution; all channels survive.
No production or peer change is claimed. Source79.0 follows clean preflight landing.

This observer retains every observed public error-Hash field. The original
selection39 observer retained an explicit whitelist projection; omitted older
field values stay unknown, without retrospective credit. Original archives,
producers and observations stay unchanged. Full native/cache/transitive/toolchain
custody4.2/SESSION5, general source/context/isolation/registration/declared5.4/
full23.4 remain separate. Evidence:
`docs/checkpoints/array-pipeline-result-perl-2026-11-10/REVIEW.md`.
