---
id: github-size-safe-publication
title: Monitor outgoing packs and publish around the director 1.5 GB budget
answers:
  - "how can LinkedSpec publish a backlog above the GitHub push size limit"
  - "is the uncompressed Git object total the actual upload size"
  - "why use a temporary upload branch before updating main"
  - "where are the original backlog planner and actual publication records retained"
  - "are successive Git range object lists disjoint"
  - "when must LinkedSpec push before batch cadence completes"
  - "what is the conservative GitHub outgoing push budget"
  - "why can packed object count exceed the outgoing revision list"
  - "how does sparse Git pack walking add already remote objects"
date: 2026-11-12
status: early-push policy adopted; November4 backlog historical; new operational custody gaps owned by23.4.30
tags: [git, publication, pack, github, continuity]
evidence: "Primary Git/GitHub contracts; original records, raw/normalized plans, actual publication logs/receipt and complete logical Git-object manifest in docs/checkpoints/publication-custody-2026-11-04/; scoped claim TYPE-REFERENCE-BOOK.1.2.23.4.7."
reverify: "bash tools/run_python_project_data.sh docs/checkpoints/publication-custody-2026-11-04/review.py; optional --verify-objects repeats full opaque body hashes. Historical close_claim.py requires accepted eda3c81 Git inputs. The original mode-only preserve_publication_claim.py recipe is historical at accepted2286c6606 inputs. Later advisory-boundary preservation: bash tools/run_python_project_data.sh docs/checkpoints/task-headroom-lua-2026-11-07/preserve_advisory_claim.py. Archived planners/publisher remain retired."
---


Current director override, November12: monitor the estimated serialized outgoing
pack after every leaf and before large growth. Publish around1,500,000,000 bytes
(decimal1.5GB), even before a PNT/batch cadence boundary. Prepare with enough margin
for canonical proof/receipts; every push still requires clean exact-HEAD canonical
CI, normal hooks and observed remote acceptance. Commit count and repository disk
usage do not substitute for outgoing pack size. Formal monitor/discovery/publication
owner TYPE-REFERENCE-BOOK.1.2.23.4.30 follows clean Dart80.3. The old one-off uploader
below remains retired; this directive does not authorize replaying it or rewriting
history. Future estimates must bind actual refs and disclose remote freshness.

The first operational HEAD1753884257bed7ce0b842bc406c665671403a828 versus cached
origin4683555ec51f04b8977812ce4e984c5cc6e6f42c estimate is1,233,210,937 bytes/101
commits. It excludes the uncommitted Dart slice and is not actual negotiated wire
size. Source/commands/metadata live at docs/checkpoints/array-concat-open-arity-dart-2026-11-12/push-monitor-current/.
The actual pack header45148 and outgoing revision-list45143 are different
populations: all five additional blobs already occur at the base. A first
added-delta-base hypothesis fails because none has delta children. Disabling only
sparse walking removes exactly these five and yields the full45143 logical set.
Git documents that sparse walking can include extra objects:
https://git-scm.com/docs/git-pack-objects#Documentation/git-pack-objects.txt---sparse.
Keep the larger conservative estimate. Raw packs/indexes stay ignored on this
volume. The scoped operational claim at docs/claims/TYPE-REFERENCE-BOOK.1.2.23.3.80.3.json
has checked re-derivation and explicitly missing independent historical size
falsification/complete physical artifact/toolchain durability, owned by23.4.30.
Logical metadata equality does not close these gaps or promise a future upload.

The November4 workflow below is dated historical evidence.

GitHub documents a maximum 2 GiB single push and successive smaller pushes as the
workaround: https://docs.github.com/en/get-started/using-git/troubleshooting-the-2-gb-push-limit.
Git transfers compressed objects and deltas; a raw object total is a different
measurement. Thin packs omit common objects already held by the receiver:
https://git-scm.com/docs/git-pack-objects and https://git-scm.com/docs/git-push.

For the initial 2ac834913..cd3b6adc backlog, retained diagnostic observations show
about 17.7 GiB of uncompressed objects and 9.30 GB in a thin-pack estimate against
the advertised remote main. The actual original call/output records and planner
are recovered in the custody capsule; wrong-budget/chain and original equality
controls close the two disclosed legs. These dated estimates are neither an
actual rejected upload nor a wire-size promise.

The prepared publisher uploads successive existing commit tips to its own
temporary branch. Each data batch gets a fresh conservative non-thin size check
below 1.5 GiB. Main stays at its initial tip until the upload reaches the verified
runtime HEAD, then advances once. Git's shared object store should make that last
update small; actual server acceptance and identities must be observed. All Git
IDs survive. Tags and submodule recursion are disabled for these root-repository
pushes. Cleanup deletes only the session's temporary ref with an expected-tip
lease. Existing-ref collisions and unexpected main changes reject.

Synthetic healthy/resume/oversize/wrong-main/collision controls exercise operator
logic without a real push or receipt. The real operation requires a clean tree,
the exact canonical receipt and normal hooks. The actual operation completed23
batches, advanced main to d3a26a94f5c2 and removed its temporary branch. A fresh
remote check matched local/origin main and found no temporary ref. Byte-exact
publisher messages survive in the November4 artifact-review capsule. The separate
publication-custody capsule retains every actual command/log, historical receipt,
raw input stream and109230 reachable logical Git-object identities. Every body
was retrieved and its Git address/SHA256 recomputed; Git history retains bodies
without a duplicate payload archive. Physical pack layout, transitive toolchain
closure, exact wire bytes and future remote state remain unassessed.

Actual successive range lists need not be disjoint: one blob appears in batches12
and20, is reachable through the later negative base history and absent from its
tip tree. The original35008 input rows cover35007 unique outgoing objects with
no missing required new object. Preserve raw lists and check set coverage rather
than summing counts as newly transmitted bodies. The first failed disjointness
review and independent diagnosis remain retained. This is an observed input-list
property, not an inference about Git implementation or wire duplication.

The raw final plan retains its initial head anchor and original last group33.
The normalized report independently derives actual runtime head d3a26a94f5c2,
834 first-parent commits and last range34. All published IDs remain intact.
The one-off publisher is retired as historical evidence for new publication use.

GitHub emitted an accepted50.86MB artifact warning in batch10. Follow-up23.4.8
now closes the bounded growth assessment; its actual observation and prevention
choices live in docs/checkpoints/artifact-growth-2026-11-05/PLAN.md.
Prospective producer/reader adoption23.4.12 remains separately scheduled.
Pack size is not server on-disk storage; historical deletion/rewrite stays excluded.
The later outgoing-range correction in that PLAN distinguishes the whole local
store from unpublished commits and confirms the warned blob already exists at
the locally recorded origin base. It establishes no current oversized push.
The later book edit preserves the dated custody claim at `eda3c81`; all original
fields and20 original input rows remain exact, with only mode/revision changed.
The original closeout/preservation recipes remain historical at their accepted Git inputs.
Later4.16 preserves the advisory metadata claim at2286c6606 without refreshing any publication
observation; its reader uses captured edited-book bytes, not future live prose.
