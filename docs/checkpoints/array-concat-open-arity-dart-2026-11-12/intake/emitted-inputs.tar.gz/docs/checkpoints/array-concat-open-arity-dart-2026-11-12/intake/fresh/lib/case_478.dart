// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-concat-open-arity-result-guard/own80_signature_fixed_missing_receiver_terminal.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1jb25jYXQtb3Blbi1hcml0eS1yZXN1bHQtZ3VhcmQvb3duODBfc2lnbmF0dXJlX2ZpeGVkX21pc3NpbmdfcmVjZWl2ZXJfdGVybWluYWwuc3BlYyIsImZ1bmN0aW9ucyI6W3sibmFtZSI6InBhaXIiLCJwYXJhbXMiOlsibGVmdCIsInJpZ2h0Il0sImFyaXR5IjoyLCJib2R5X3NvdXJjZSI6InJldHVybihsZWZ0KSIsImJvZHlfcGF5bG9hZCI6eyJraW5kIjoic3RhZ2VkX3BheWxvYWQiLCJ2ZXJzaW9uIjoxLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwiZnVuY3Rpb25fbmFtZSI6InBhaXIiLCJwYXJhbXMiOlsibGVmdCIsInJpZ2h0Il0sImFyaXR5IjoyLCJ0ZXh0IjoicmV0dXJuKGxlZnQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjIxLCJlbmQiOjMzLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInByb3ZlbmFuY2UiOlt7ImtpbmQiOiJzb3VyY2Vfc2xpY2UiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjEsImVuZCI6MzMsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dfSwiYm9keV9wYXJzZV9qb2IiOnsia2luZCI6InBhcnNlX2pvYiIsInZlcnNpb24iOjEsImpvYl9pZCI6InBhcnNlX2pvYjpmdW5jdGlvbl9ib2R5OmZ1bmN0aW9ucy4wLmJvZHlfc291cmNlOmFjdGlvbmlyLWJvZHkuc3BlYzphY3Rpb25fYmxvY2s6MjEtMzMiLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwiZnVuY3Rpb25fbmFtZSI6InBhaXIiLCJwYXJhbXMiOlsibGVmdCIsInJpZ2h0Il0sImFyaXR5IjoyLCJ0ZXh0IjoicmV0dXJuKGxlZnQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjIxLCJlbmQiOjMzLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInBhcnNlcl9zcGVjX2lkIjoiYWN0aW9uaXItYm9keS5zcGVjIiwidG9wX3J1bGUiOiJhY3Rpb25fYmxvY2siLCJyZXN1bHRfcG9saWN5IjoicmVwbGFjZV9maWVsZCIsInJlc3VsdF9maWVsZCI6ImJvZHlfYXN0IiwiZmFpbHVyZV9wb2xpY3kiOiJmYWlsIiwiZGlhZ25vc3RpY19vd25lciI6ImZ1bmN0aW9uX2JvZHkifSwiYm9keV9hc3QiOnsia2luZCI6ImFjdGlvbl9ibG9jayIsInNvdXJjZSI6InJldHVybihsZWZ0KSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjEyfSwic3RhdGVtZW50cyI6W3sia2luZCI6ImFjdGlvbl9zdG10Iiwic291cmNlIjoicmV0dXJuKGxlZnQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTJ9LCJleHByIjp7ImtpbmQiOiJjYWxsIiwic291cmNlIjoicmV0dXJuKGxlZnQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTJ9LCJuYW1lIjoicmV0dXJuIiwic291cmNlX21ldGhvZCI6InJldHVybiIsImFyZ3MiOlt7ImtpbmQiOiJ2YXJpYWJsZSIsInNvdXJjZSI6ImxlZnQiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6NywiZW5kIjoxMX0sIm5hbWUiOiJsZWZ0In1dfSwiZHJvcHNfdmFsdWUiOnRydWV9XX0sInNvdXJjZSI6ImZuIHBhaXIobGVmdCxyaWdodCkge3JldHVybihsZWZ0KX0iLCJzb3VyY2Vfc3BhbiI6eyJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sImJvZHlfc3BhbiI6eyJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XSwicnVsZXMiOlt7ImhlYWRlciI6eyJsYWJlbCI6IlZhbHVlIiwiaXNfdG9wIjp0cnVlLCJtb2RlIjoiRGVmYXVsdCIsInJlc3QiOiJJIHtvcmRlcj1cIlwiO291dD1wYWlyKHtvcmRlcj1jYXQob3JkZXIsXCJTXCIpO1tcImhlYWRcIl19KS5jb25jYXRfYXJyYXlzKHtvcmRlcj1jYXQob3JkZXIsXCJUXCIpO1tcInRhaWxcIl19LHtvcmRlcj1jYXQob3JkZXIsXCJVXCIpO1tcImVuZFwiXX0pO3JldHVybihbb3V0LG9yZGVyXSl9IiwibGluZSI6M30sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6Im9yZGVyPVwiXCI7b3V0PXBhaXIoe29yZGVyPWNhdChvcmRlcixcIlNcIik7W1wiaGVhZFwiXX0pLmNvbmNhdF9hcnJheXMoe29yZGVyPWNhdChvcmRlcixcIlRcIik7W1widGFpbFwiXX0se29yZGVyPWNhdChvcmRlcixcIlVcIik7W1wiZW5kXCJdfSk7cmV0dXJuKFtvdXQsb3JkZXJdKSJ9LCJzb3VyY2UiOiJJIHtvcmRlcj1cIlwiO291dD1wYWlyKHtvcmRlcj1jYXQob3JkZXIsXCJTXCIpO1tcImhlYWRcIl19KS5jb25jYXRfYXJyYXlzKHtvcmRlcj1jYXQob3JkZXIsXCJUXCIpO1tcInRhaWxcIl19LHtvcmRlcj1jYXQob3JkZXIsXCJVXCIpO1tcImVuZFwiXX0pO3JldHVybihbb3V0LG9yZGVyXSl9IiwibGluZSI6M31dfV19';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
