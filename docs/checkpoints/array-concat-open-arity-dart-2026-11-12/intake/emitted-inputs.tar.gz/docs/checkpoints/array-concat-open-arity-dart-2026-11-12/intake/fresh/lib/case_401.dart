// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-concat-open-arity-result-guard/own80_initial_number_ordinary_3_free_with.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1jb25jYXQtb3Blbi1hcml0eS1yZXN1bHQtZ3VhcmQvb3duODBfaW5pdGlhbF9udW1iZXJfb3JkaW5hcnlfM19mcmVlX3dpdGguc3BlYyIsImZ1bmN0aW9ucyI6W10sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7c291cmNlPTM7b3JkZXI9XCJcIjtvdXQ9Y29uY2F0X2FycmF5cyhzb3VyY2Use29yZGVyPWNhdChvcmRlcixcIlRcIik7W1widGFpbFwiXX0se29yZGVyPWNhdChvcmRlcixcIlVcIik7W1wiZW5kXCJdfSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKHZhbHVlLmNvdW50KCkpfTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjF9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJzb3VyY2U9MztvcmRlcj1cIlwiO291dD1jb25jYXRfYXJyYXlzKHNvdXJjZSx7b3JkZXI9Y2F0KG9yZGVyLFwiVFwiKTtbXCJ0YWlsXCJdfSx7b3JkZXI9Y2F0KG9yZGVyLFwiVVwiKTtbXCJlbmRcIl19KS53aXRoKCl7b3JkZXI9Y2F0KG9yZGVyLFwiV1wiKTtyZXR1cm4odmFsdWUuY291bnQoKSl9O3JldHVybihbb3V0LG9yZGVyXSkifSwic291cmNlIjoiSSB7c291cmNlPTM7b3JkZXI9XCJcIjtvdXQ9Y29uY2F0X2FycmF5cyhzb3VyY2Use29yZGVyPWNhdChvcmRlcixcIlRcIik7W1widGFpbFwiXX0se29yZGVyPWNhdChvcmRlcixcIlVcIik7W1wiZW5kXCJdfSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKHZhbHVlLmNvdW50KCkpfTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjF9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
