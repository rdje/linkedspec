// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-concat-open-arity-result-guard/own80_signature_rest_missing_free_terminal.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1jb25jYXQtb3Blbi1hcml0eS1yZXN1bHQtZ3VhcmQvb3duODBfc2lnbmF0dXJlX3Jlc3RfbWlzc2luZ19mcmVlX3Rlcm1pbmFsLnNwZWMiLCJmdW5jdGlvbnMiOlt7Im5hbWUiOiJrZWVwIiwic2lnbmF0dXJlIjp7ImtpbmQiOiJjYWxsYWJsZV9zaWduYXR1cmUiLCJ2ZXJzaW9uIjoxLCJwb3NpdGlvbmFsX3BhcmFtcyI6WyJzZWVkIl0sInJlc3RfcGFyYW0iOiJleHRyYXMiLCJtaW5fYXJpdHkiOjEsIm1heF9hcml0eSI6bnVsbH0sImJvZHlfc291cmNlIjoicmV0dXJuKHNlZWQpIiwiYm9keV9wYXlsb2FkIjp7ImtpbmQiOiJzdGFnZWRfcGF5bG9hZCIsInZlcnNpb24iOjEsIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJmdW5jdGlvbl9uYW1lIjoia2VlcCIsInNpZ25hdHVyZSI6eyJraW5kIjoiY2FsbGFibGVfc2lnbmF0dXJlIiwidmVyc2lvbiI6MSwicG9zaXRpb25hbF9wYXJhbXMiOlsic2VlZCJdLCJyZXN0X3BhcmFtIjoiZXh0cmFzIiwibWluX2FyaXR5IjoxLCJtYXhfYXJpdHkiOm51bGx9LCJ0ZXh0IjoicmV0dXJuKHNlZWQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjI1LCJlbmQiOjM3LCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInByb3ZlbmFuY2UiOlt7ImtpbmQiOiJzb3VyY2Vfc2xpY2UiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjUsImVuZCI6MzcsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dfSwiYm9keV9wYXJzZV9qb2IiOnsia2luZCI6InBhcnNlX2pvYiIsInZlcnNpb24iOjEsImpvYl9pZCI6InBhcnNlX2pvYjpmdW5jdGlvbl9ib2R5OmZ1bmN0aW9ucy4wLmJvZHlfc291cmNlOmFjdGlvbmlyLWJvZHkuc3BlYzphY3Rpb25fYmxvY2s6MjUtMzciLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwiZnVuY3Rpb25fbmFtZSI6ImtlZXAiLCJzaWduYXR1cmUiOnsia2luZCI6ImNhbGxhYmxlX3NpZ25hdHVyZSIsInZlcnNpb24iOjEsInBvc2l0aW9uYWxfcGFyYW1zIjpbInNlZWQiXSwicmVzdF9wYXJhbSI6ImV4dHJhcyIsIm1pbl9hcml0eSI6MSwibWF4X2FyaXR5IjpudWxsfSwidGV4dCI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyNSwiZW5kIjozNywibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwYXJzZXJfc3BlY19pZCI6ImFjdGlvbmlyLWJvZHkuc3BlYyIsInRvcF9ydWxlIjoiYWN0aW9uX2Jsb2NrIiwicmVzdWx0X3BvbGljeSI6InJlcGxhY2VfZmllbGQiLCJyZXN1bHRfZmllbGQiOiJib2R5X2FzdCIsImZhaWx1cmVfcG9saWN5IjoiZmFpbCIsImRpYWdub3N0aWNfb3duZXIiOiJmdW5jdGlvbl9ib2R5In0sImJvZHlfYXN0Ijp7ImtpbmQiOiJhY3Rpb25fYmxvY2siLCJzb3VyY2UiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxMn0sInN0YXRlbWVudHMiOlt7ImtpbmQiOiJhY3Rpb25fc3RtdCIsInNvdXJjZSI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjEyfSwiZXhwciI6eyJraW5kIjoiY2FsbCIsInNvdXJjZSI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjEyfSwibmFtZSI6InJldHVybiIsInNvdXJjZV9tZXRob2QiOiJyZXR1cm4iLCJhcmdzIjpbeyJraW5kIjoidmFyaWFibGUiLCJzb3VyY2UiOiJzZWVkIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MTF9LCJuYW1lIjoic2VlZCJ9XX0sImRyb3BzX3ZhbHVlIjp0cnVlfV19LCJzb3VyY2UiOiJmbiBrZWVwKHNlZWQsLi4uZXh0cmFzKSB7cmV0dXJuKHNlZWQpfSIsInNvdXJjZV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwiYm9keV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge29yZGVyPVwiXCI7b3V0PWNvbmNhdF9hcnJheXMoa2VlcCgpLHtvcmRlcj1jYXQob3JkZXIsXCJUXCIpO1tcInRhaWxcIl19LHtvcmRlcj1jYXQob3JkZXIsXCJVXCIpO1tcImVuZFwiXX0pO3JldHVybihbb3V0LG9yZGVyXSl9IiwibGluZSI6M30sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6Im9yZGVyPVwiXCI7b3V0PWNvbmNhdF9hcnJheXMoa2VlcCgpLHtvcmRlcj1jYXQob3JkZXIsXCJUXCIpO1tcInRhaWxcIl19LHtvcmRlcj1jYXQob3JkZXIsXCJVXCIpO1tcImVuZFwiXX0pO3JldHVybihbb3V0LG9yZGVyXSkifSwic291cmNlIjoiSSB7b3JkZXI9XCJcIjtvdXQ9Y29uY2F0X2FycmF5cyhrZWVwKCkse29yZGVyPWNhdChvcmRlcixcIlRcIik7W1widGFpbFwiXX0se29yZGVyPWNhdChvcmRlcixcIlVcIik7W1wiZW5kXCJdfSk7cmV0dXJuKFtvdXQsb3JkZXJdKX0iLCJsaW5lIjozfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
