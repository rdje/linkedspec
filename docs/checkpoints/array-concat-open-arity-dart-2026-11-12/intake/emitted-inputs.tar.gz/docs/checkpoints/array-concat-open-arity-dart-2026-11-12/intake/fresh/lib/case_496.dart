// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-concat-open-arity-result-guard/own80_snapshot_ordinary_receiver_hash.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1jb25jYXQtb3Blbi1hcml0eS1yZXN1bHQtZ3VhcmQvb3duODBfc25hcHNob3Rfb3JkaW5hcnlfcmVjZWl2ZXJfaGFzaC5zcGVjIiwiZnVuY3Rpb25zIjpbXSwicnVsZXMiOlt7ImhlYWRlciI6eyJsYWJlbCI6IlZhbHVlIiwiaXNfdG9wIjp0cnVlLCJtb2RlIjoiRGVmYXVsdCIsInJlc3QiOiJJIHtpdGVtcz1bXCJoZWFkXCJdO291dD1pdGVtcy5jb25jYXRfYXJyYXlzKHtpdGVtcys9XCJjaGFuZ2VkXCI7W1widGFpbFwiXX0sW1wiZW5kXCJdKS5zZXRfa2V5KFwia1wiLDEpO3JldHVybihbb3V0LGl0ZW1zXSl9IiwibGluZSI6MX0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6Iml0ZW1zPVtcImhlYWRcIl07b3V0PWl0ZW1zLmNvbmNhdF9hcnJheXMoe2l0ZW1zKz1cImNoYW5nZWRcIjtbXCJ0YWlsXCJdfSxbXCJlbmRcIl0pLnNldF9rZXkoXCJrXCIsMSk7cmV0dXJuKFtvdXQsaXRlbXNdKSJ9LCJzb3VyY2UiOiJJIHtpdGVtcz1bXCJoZWFkXCJdO291dD1pdGVtcy5jb25jYXRfYXJyYXlzKHtpdGVtcys9XCJjaGFuZ2VkXCI7W1widGFpbFwiXX0sW1wiZW5kXCJdKS5zZXRfa2V5KFwia1wiLDEpO3JldHVybihbb3V0LGl0ZW1zXSl9IiwibGluZSI6MX1dfV19';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
