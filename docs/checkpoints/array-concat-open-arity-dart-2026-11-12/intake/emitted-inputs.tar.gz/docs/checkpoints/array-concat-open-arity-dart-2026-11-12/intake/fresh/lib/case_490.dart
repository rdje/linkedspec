// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-concat-open-arity-result-guard/own80_signature_rest_multi_receiver_terminal.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1jb25jYXQtb3Blbi1hcml0eS1yZXN1bHQtZ3VhcmQvb3duODBfc2lnbmF0dXJlX3Jlc3RfbXVsdGlfcmVjZWl2ZXJfdGVybWluYWwuc3BlYyIsImZ1bmN0aW9ucyI6W3sibmFtZSI6ImtlZXAiLCJzaWduYXR1cmUiOnsia2luZCI6ImNhbGxhYmxlX3NpZ25hdHVyZSIsInZlcnNpb24iOjEsInBvc2l0aW9uYWxfcGFyYW1zIjpbInNlZWQiXSwicmVzdF9wYXJhbSI6ImV4dHJhcyIsIm1pbl9hcml0eSI6MSwibWF4X2FyaXR5IjpudWxsfSwiYm9keV9zb3VyY2UiOiJyZXR1cm4oc2VlZCkiLCJib2R5X3BheWxvYWQiOnsia2luZCI6InN0YWdlZF9wYXlsb2FkIiwidmVyc2lvbiI6MSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sImZ1bmN0aW9uX25hbWUiOiJrZWVwIiwic2lnbmF0dXJlIjp7ImtpbmQiOiJjYWxsYWJsZV9zaWduYXR1cmUiLCJ2ZXJzaW9uIjoxLCJwb3NpdGlvbmFsX3BhcmFtcyI6WyJzZWVkIl0sInJlc3RfcGFyYW0iOiJleHRyYXMiLCJtaW5fYXJpdHkiOjEsIm1heF9hcml0eSI6bnVsbH0sInRleHQiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjUsImVuZCI6MzcsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicHJvdmVuYW5jZSI6W3sia2luZCI6InNvdXJjZV9zbGljZSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyNSwiZW5kIjozNywibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV19LCJib2R5X3BhcnNlX2pvYiI6eyJraW5kIjoicGFyc2Vfam9iIiwidmVyc2lvbiI6MSwiam9iX2lkIjoicGFyc2Vfam9iOmZ1bmN0aW9uX2JvZHk6ZnVuY3Rpb25zLjAuYm9keV9zb3VyY2U6YWN0aW9uaXItYm9keS5zcGVjOmFjdGlvbl9ibG9jazoyNS0zNyIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJmdW5jdGlvbl9uYW1lIjoia2VlcCIsInNpZ25hdHVyZSI6eyJraW5kIjoiY2FsbGFibGVfc2lnbmF0dXJlIiwidmVyc2lvbiI6MSwicG9zaXRpb25hbF9wYXJhbXMiOlsic2VlZCJdLCJyZXN0X3BhcmFtIjoiZXh0cmFzIiwibWluX2FyaXR5IjoxLCJtYXhfYXJpdHkiOm51bGx9LCJ0ZXh0IjoicmV0dXJuKHNlZWQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjI1LCJlbmQiOjM3LCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInBhcnNlcl9zcGVjX2lkIjoiYWN0aW9uaXItYm9keS5zcGVjIiwidG9wX3J1bGUiOiJhY3Rpb25fYmxvY2siLCJyZXN1bHRfcG9saWN5IjoicmVwbGFjZV9maWVsZCIsInJlc3VsdF9maWVsZCI6ImJvZHlfYXN0IiwiZmFpbHVyZV9wb2xpY3kiOiJmYWlsIiwiZGlhZ25vc3RpY19vd25lciI6ImZ1bmN0aW9uX2JvZHkifSwiYm9keV9hc3QiOnsia2luZCI6ImFjdGlvbl9ibG9jayIsInNvdXJjZSI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjEyfSwic3RhdGVtZW50cyI6W3sia2luZCI6ImFjdGlvbl9zdG10Iiwic291cmNlIjoicmV0dXJuKHNlZWQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTJ9LCJleHByIjp7ImtpbmQiOiJjYWxsIiwic291cmNlIjoicmV0dXJuKHNlZWQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTJ9LCJuYW1lIjoicmV0dXJuIiwic291cmNlX21ldGhvZCI6InJldHVybiIsImFyZ3MiOlt7ImtpbmQiOiJ2YXJpYWJsZSIsInNvdXJjZSI6InNlZWQiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6NywiZW5kIjoxMX0sIm5hbWUiOiJzZWVkIn1dfSwiZHJvcHNfdmFsdWUiOnRydWV9XX0sInNvdXJjZSI6ImZuIGtlZXAoc2VlZCwuLi5leHRyYXMpIHtyZXR1cm4oc2VlZCl9Iiwic291cmNlX3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJib2R5X3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV0sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7b3JkZXI9XCJcIjtvdXQ9a2VlcCh7b3JkZXI9Y2F0KG9yZGVyLFwiU1wiKTtbXCJoZWFkXCJdfSx7b3JkZXI9Y2F0KG9yZGVyLFwiWFwiKTs5fSkuY29uY2F0X2FycmF5cyh7b3JkZXI9Y2F0KG9yZGVyLFwiVFwiKTtbXCJ0YWlsXCJdfSx7b3JkZXI9Y2F0KG9yZGVyLFwiVVwiKTtbXCJlbmRcIl19KTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJvcmRlcj1cIlwiO291dD1rZWVwKHtvcmRlcj1jYXQob3JkZXIsXCJTXCIpO1tcImhlYWRcIl19LHtvcmRlcj1jYXQob3JkZXIsXCJYXCIpOzl9KS5jb25jYXRfYXJyYXlzKHtvcmRlcj1jYXQob3JkZXIsXCJUXCIpO1tcInRhaWxcIl19LHtvcmRlcj1jYXQob3JkZXIsXCJVXCIpO1tcImVuZFwiXX0pO3JldHVybihbb3V0LG9yZGVyXSkifSwic291cmNlIjoiSSB7b3JkZXI9XCJcIjtvdXQ9a2VlcCh7b3JkZXI9Y2F0KG9yZGVyLFwiU1wiKTtbXCJoZWFkXCJdfSx7b3JkZXI9Y2F0KG9yZGVyLFwiWFwiKTs5fSkuY29uY2F0X2FycmF5cyh7b3JkZXI9Y2F0KG9yZGVyLFwiVFwiKTtbXCJ0YWlsXCJdfSx7b3JkZXI9Y2F0KG9yZGVyLFwiVVwiKTtbXCJlbmRcIl19KTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
