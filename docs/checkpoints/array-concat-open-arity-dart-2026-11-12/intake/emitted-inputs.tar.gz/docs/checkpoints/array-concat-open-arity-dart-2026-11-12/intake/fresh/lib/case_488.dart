// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-concat-open-arity-result-guard/own80_signature_rest_multi_free_terminal.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1jb25jYXQtb3Blbi1hcml0eS1yZXN1bHQtZ3VhcmQvb3duODBfc2lnbmF0dXJlX3Jlc3RfbXVsdGlfZnJlZV90ZXJtaW5hbC5zcGVjIiwiZnVuY3Rpb25zIjpbeyJuYW1lIjoia2VlcCIsInNpZ25hdHVyZSI6eyJraW5kIjoiY2FsbGFibGVfc2lnbmF0dXJlIiwidmVyc2lvbiI6MSwicG9zaXRpb25hbF9wYXJhbXMiOlsic2VlZCJdLCJyZXN0X3BhcmFtIjoiZXh0cmFzIiwibWluX2FyaXR5IjoxLCJtYXhfYXJpdHkiOm51bGx9LCJib2R5X3NvdXJjZSI6InJldHVybihzZWVkKSIsImJvZHlfcGF5bG9hZCI6eyJraW5kIjoic3RhZ2VkX3BheWxvYWQiLCJ2ZXJzaW9uIjoxLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwiZnVuY3Rpb25fbmFtZSI6ImtlZXAiLCJzaWduYXR1cmUiOnsia2luZCI6ImNhbGxhYmxlX3NpZ25hdHVyZSIsInZlcnNpb24iOjEsInBvc2l0aW9uYWxfcGFyYW1zIjpbInNlZWQiXSwicmVzdF9wYXJhbSI6ImV4dHJhcyIsIm1pbl9hcml0eSI6MSwibWF4X2FyaXR5IjpudWxsfSwidGV4dCI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyNSwiZW5kIjozNywibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwcm92ZW5hbmNlIjpbeyJraW5kIjoic291cmNlX3NsaWNlIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjI1LCJlbmQiOjM3LCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XX0sImJvZHlfcGFyc2Vfam9iIjp7ImtpbmQiOiJwYXJzZV9qb2IiLCJ2ZXJzaW9uIjoxLCJqb2JfaWQiOiJwYXJzZV9qb2I6ZnVuY3Rpb25fYm9keTpmdW5jdGlvbnMuMC5ib2R5X3NvdXJjZTphY3Rpb25pci1ib2R5LnNwZWM6YWN0aW9uX2Jsb2NrOjI1LTM3IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsImZ1bmN0aW9uX25hbWUiOiJrZWVwIiwic2lnbmF0dXJlIjp7ImtpbmQiOiJjYWxsYWJsZV9zaWduYXR1cmUiLCJ2ZXJzaW9uIjoxLCJwb3NpdGlvbmFsX3BhcmFtcyI6WyJzZWVkIl0sInJlc3RfcGFyYW0iOiJleHRyYXMiLCJtaW5fYXJpdHkiOjEsIm1heF9hcml0eSI6bnVsbH0sInRleHQiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjUsImVuZCI6MzcsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicGFyc2VyX3NwZWNfaWQiOiJhY3Rpb25pci1ib2R5LnNwZWMiLCJ0b3BfcnVsZSI6ImFjdGlvbl9ibG9jayIsInJlc3VsdF9wb2xpY3kiOiJyZXBsYWNlX2ZpZWxkIiwicmVzdWx0X2ZpZWxkIjoiYm9keV9hc3QiLCJmYWlsdXJlX3BvbGljeSI6ImZhaWwiLCJkaWFnbm9zdGljX293bmVyIjoiZnVuY3Rpb25fYm9keSJ9LCJib2R5X2FzdCI6eyJraW5kIjoiYWN0aW9uX2Jsb2NrIiwic291cmNlIjoicmV0dXJuKHNlZWQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTJ9LCJzdGF0ZW1lbnRzIjpbeyJraW5kIjoiYWN0aW9uX3N0bXQiLCJzb3VyY2UiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxMn0sImV4cHIiOnsia2luZCI6ImNhbGwiLCJzb3VyY2UiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxMn0sIm5hbWUiOiJyZXR1cm4iLCJzb3VyY2VfbWV0aG9kIjoicmV0dXJuIiwiYXJncyI6W3sia2luZCI6InZhcmlhYmxlIiwic291cmNlIjoic2VlZCIsInNvdXJjZV9zcGFuIjp7InN0YXJ0Ijo3LCJlbmQiOjExfSwibmFtZSI6InNlZWQifV19LCJkcm9wc192YWx1ZSI6dHJ1ZX1dfSwic291cmNlIjoiZm4ga2VlcChzZWVkLC4uLmV4dHJhcykge3JldHVybihzZWVkKX0iLCJzb3VyY2Vfc3BhbiI6eyJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sImJvZHlfc3BhbiI6eyJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XSwicnVsZXMiOlt7ImhlYWRlciI6eyJsYWJlbCI6IlZhbHVlIiwiaXNfdG9wIjp0cnVlLCJtb2RlIjoiRGVmYXVsdCIsInJlc3QiOiJJIHtvcmRlcj1cIlwiO291dD1jb25jYXRfYXJyYXlzKGtlZXAoe29yZGVyPWNhdChvcmRlcixcIlNcIik7W1wiaGVhZFwiXX0se29yZGVyPWNhdChvcmRlcixcIlhcIik7OX0pLHtvcmRlcj1jYXQob3JkZXIsXCJUXCIpO1tcInRhaWxcIl19LHtvcmRlcj1jYXQob3JkZXIsXCJVXCIpO1tcImVuZFwiXX0pO3JldHVybihbb3V0LG9yZGVyXSl9IiwibGluZSI6M30sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6Im9yZGVyPVwiXCI7b3V0PWNvbmNhdF9hcnJheXMoa2VlcCh7b3JkZXI9Y2F0KG9yZGVyLFwiU1wiKTtbXCJoZWFkXCJdfSx7b3JkZXI9Y2F0KG9yZGVyLFwiWFwiKTs5fSkse29yZGVyPWNhdChvcmRlcixcIlRcIik7W1widGFpbFwiXX0se29yZGVyPWNhdChvcmRlcixcIlVcIik7W1wiZW5kXCJdfSk7cmV0dXJuKFtvdXQsb3JkZXJdKSJ9LCJzb3VyY2UiOiJJIHtvcmRlcj1cIlwiO291dD1jb25jYXRfYXJyYXlzKGtlZXAoe29yZGVyPWNhdChvcmRlcixcIlNcIik7W1wiaGVhZFwiXX0se29yZGVyPWNhdChvcmRlcixcIlhcIik7OX0pLHtvcmRlcj1jYXQob3JkZXIsXCJUXCIpO1tcInRhaWxcIl19LHtvcmRlcj1jYXQob3JkZXIsXCJVXCIpO1tcImVuZFwiXX0pO3JldHVybihbb3V0LG9yZGVyXSl9IiwibGluZSI6M31dfV19';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
