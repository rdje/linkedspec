"""Reconcile historical objective evidence without claiming fresh runtime execution.

Run with tools/run_python_project_data.sh. Runtime/test inputs must match the
latest audited milestone or an exact owner-bound source evolution. Historical
hashes and executions stay fixed; current runtime proof is separately owned.
"""

import base64
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parents[2]
PREFIX = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.1.3."
MILESTONES = ("1.2.3", "2.7", "3.5")
RUNTIMES = ("perl", "rust", "dart", "julia", "puc", "luajit")
GOVERNANCE_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.2.2"
COMPOSED_GOVERNANCE_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.2"
PUSH_REPAIR_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.1"
NORMALIZATION_CORRECTION_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.1"
SIGNATURE_REPAIR_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.2.1.3.1"
SIGNATURE_BEFORE = "67af62f7aa6dff39b6c3fd64b15fb5139f691a0a"
SIGNATURE_AFTER = "446fb65fadca2e1bd31fec93bb9de779eb2134d1"
OCCURRENCE_REPAIR_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.6.1"
BOUNDARY_REPAIR_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.2.2.0.1.4.0.1"
BOUNDARY_BEFORE = "da5c8d1f66732f0989cecca745557005fe44e7c1"
BOUNDARY_AFTER = "b2156813fffed53622e640583a46a4ca94186a08"
BOUNDARY_RECURRENCE_OWNER = BOUNDARY_REPAIR_OWNER + ".1"
BOUNDARY_RECURRENCE_AFTER = "d52add3e5e070b243eb3a2a532d061b51994a36a"
COMPILER_MEMBERSHIP_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.2.2.0.2.1"
COMPILER_MEMBERSHIP_RECONCILIATION_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.2.2.0.2.2.0"
COMPILER_MEMBERSHIP_BEFORE = "31395e440a38acec7a6712d470a90a90a6567863"
COMPILER_MEMBERSHIP_AFTER = "af5d19971a1682f6895901fb769ff41b69842672"
CONTRACT_CAPTURE_BEFORE = "2d878478028fc417ac5b7790c016543c18c1f48b"
CONTRACT_CAPTURE_DEPENDENCIES = "be7d70719856e76b7cb5a427ad6061a7109028ea"
CONTRACT_CAPTURE_AFTER = "33e57deee73e27b97e9c21116bc70942f3f33772"
CONTRACT_CAPTURE_OWNERS = ("PERL-PRIVATE-FACTORY-CAPTURE.2.1.0", "PERL-PRIVATE-FACTORY-CAPTURE.2.1.1")
EVALUATED_VALUES_OWNER = 'TYPE-REFERENCE-BOOK.1.2.3'
EVALUATED_VALUES_TABLE = 'tests/language-readiness/evaluated-value-regression-evolution.json'
EVALUATED_VALUES_TABLE_SHA256 = 'ad3bcdbd4615d2c0ecc5c30c692e19c6881a0f2c51cf2367330fe08ad7310030'
EVALUATED_VALUES_BEFORE = 'c053c9dcf24a78cc8b551187f47cdb7aefb03eb3'
SCALAR_NUMERIC_OWNER = 'TYPE-REFERENCE-BOOK.1.2.5'
SCALAR_NUMERIC_TABLE = 'tests/language-readiness/scalar-numeric-regression-evolution.json.gz'
SCALAR_NUMERIC_TABLE_SHA256 = '99e3bd544e304d48b1ae1da780fb749bbf2a02de34875610a881fa1b7d8890f9'
SCALAR_NUMERIC_BEFORE = '203cde3159105cd9d96117015ff2dbbc24796a56'
SCALAR_NUMERIC_MARKER = b'    my $numeric_setup = q{'
DROP_GENERATED_OWNER = 'TYPE-REFERENCE-BOOK.1.2.6'
DROP_GENERATED_TABLE = 'tests/language-readiness/drop-generated-regression-evolution.json.gz'
DROP_GENERATED_TABLE_SHA256 = '939ec5469217ec76501ccc123e15feca956985e8d659ffb08a70f81cac1c299e'
DROP_GENERATED_BEFORE = '9fc95b0bd1167db110e91bf50a8939129485c960'
DROP_GENERATED_MARKER = b'my @__ls_drop_keys = ('
COUNT_FIRST_OWNER = 'TYPE-REFERENCE-BOOK.1.2.10'
COUNT_FIRST_TABLE = 'tests/language-readiness/count-first-regression-evolution.json'
COUNT_FIRST_TABLE_SHA256 = '5169035f3fbab2b0f5a853b902a9c5ec2fba87ae10ab1cc834c3f8dfa9d6e814'
COUNT_FIRST_BEFORE = 'a8bd8620a4e545b3e472561bfea90c656ab69923'
COUNT_FIRST_MARKER = b'ref($__ls_count)'
RUST_SIGNED_OWNER = 'TYPE-REFERENCE-BOOK.1.2.17.3'
RUST_SIGNED_SOURCE = 'rust/linkedspec-runtime/src/engine.rs'
RUST_SIGNED_BEFORE = '5d1c572c2c310f5dd0aa4f62bb07020cf5c416a8483799cd1c85f13ffeb68009'
RUST_SIGNED_AFTER = '0a5a6e7091e2daef5f84942db839829ce98e5a60f62c3d83ce204538c95a5772'
DART_SIGNED_OWNER = 'TYPE-REFERENCE-BOOK.1.2.17.4'
DART_SIGNED_SOURCE = 'dart/lib/src/runtime/interpreter.dart'
DART_SIGNED_ACTIVATION = '4e6ece603bbdf7c77b83a2e8c1f79946e7da0490'
DART_SIGNED_BEFORE = '0af1a72725fb2b3691ce57f97278439c63fbe23a153a490f0d51a3397f4a1e24'
DART_SIGNED_AFTER = '9f0ee7637d28e63592bfcf0968431e17d0465e4f45ef7d6390d896e678971823'
RUST_NUMERIC_OWNER = 'SESSION-STARTUP-READING.55.1'
RUST_NUMERIC_ACTIVATION = 'f0d974aa1b337bbf2ee16e51c0297182e1e94f82'
RUST_NUMERIC_IMAGES = {
    'rust/Cargo.toml': (
        '4f85f31df8b2228a18e44f22e9a9e276f6ca91943becea7f7025b70d564cbe81',
        '4f85f31df8b2228a18e44f22e9a9e276f6ca91943becea7f7025b70d564cbe81',
        '412b4ca6561744edee837a4096961a305de9be391cfbc3e06184ee106d9df7f8'),
    RUST_SIGNED_SOURCE: (
        RUST_SIGNED_BEFORE, RUST_SIGNED_AFTER,
        'b1c327a23ba03a6d345fe13002a2bacc9c5c67580551fd9d135e6c581247b3cf'),
}
RUST_NUMERIC_SUPPORT = {
    'rust/linkedspec-core/src/numeric.rs': '65ad021924defd8dd6a623edf5adc7dcdd43d32fc4dad65460b01944035f8072',
    'rust/linkedspec-core/src/types.rs': '836a7fd0de6fdf1d351283476074a63cb16d1cb7a6c9ca1d3d7428735dac0ced',
    'rust/linkedspec-core/src/lib.rs': 'c2cca39ba3ec0e03606737486361b24d0255566167020f4ebeb0df1469e986a3',
    'rust/linkedspec-runtime/src/spec_parser.rs': 'd25de1bfd0a36de1979049072431e14c3319cf9297899b9f0be56c321a165560',
    'rust/linkedspec-runtime/src/staged_parser_registry.rs': '8fdd3a75fbb411a1783d19201678b4c5df66f9f7198b8b469c475366770b1a89',
}
CURRENT_IMAGE_OWNER = 'TYPE-REFERENCE-BOOK.1.2.20.1.11'
CURRENT_IMAGE_TABLE = 'tests/language-readiness/current-source-images.json.gz'
CURRENT_IMAGE_TABLE_SHA256 = '1b36eab6308b311933775c31da8bcb522f6dd18acb2be0a467790f3112a3f310'
CURRENT_IMAGE_HELPER = 'tools/historical_objective_images.py'
CURRENT_SUCCESSOR_OWNER = 'TYPE-REFERENCE-BOOK.1.2.23.4.18.1'
CURRENT_SUCCESSOR_TABLE = 'tests/language-readiness/current-source-successors.json.gz'
CURRENT_SUCCESSOR_SHA256 = 'f9ebc109d910119055847c19dc42e4efa1e6b83b0bf4195132b530f7ea6915af'
ADDITIONAL_IMAGE_TABLE = 'tests/language-readiness/additional-source-images.json.gz'
ADDITIONAL_IMAGE_SHA256 = '33e71bf5506e09a50940f2a196ad0388f552448e77f3ed5156f37c816340c18e'
IMAGE_EVOLUTION_INPUTS = (CURRENT_IMAGE_TABLE, CURRENT_IMAGE_HELPER, CURRENT_SUCCESSOR_TABLE, ADDITIONAL_IMAGE_TABLE)
STORAGE_INVENTORY_OWNER = 'TYPE-REFERENCE-BOOK.1.2.20.1.19'
STORAGE_INVENTORY_TABLE = 'tests/language-readiness/perl-storage-inventory-evolution.json.gz'
STORAGE_INVENTORY_TABLE_SHA256 = '99e0726f0a51a06d4e2d86e030ee9385ba83bac85f03c0656396f266f4dbe164'
PHASE0_FIXTURE_OWNER = 'TYPE-REFERENCE-BOOK.1.2.20.1.21'
PHASE0_FIXTURE = 't/phase0_regression.t'
PHASE0_FIXTURE_TABLE = 'tests/language-readiness/phase0-fixture-calibration.json.gz'
PHASE0_FIXTURE_SHA256 = '4d16bd8b938d30f5f5fa7885931242ea195ed8316be60e36d54d282b452ef45e'
PHASE0_VALUE_OWNER = 'TYPE-REFERENCE-BOOK.1.2.23.4.18.1'
PHASE0_VALUE_TABLE = 'tests/language-readiness/phase0-value-calibration.json.gz'
PHASE0_VALUE_SHA256 = '83a26ab17b802e800a44650b59e07d794a804bdf3d752936870c15f8e00b199c'
PHASE0_VALUE_ACTIVATION = '7289836f28e4873463ad1c50d354d8e66c77af8d'
PHASE0_VALUE_BEFORE = 'c2d8dca7786c285e99b81802755aeb9d4563b0e62a55e0801e203d1e637d1d80'
_IMAGE_MODULE = None


def current_image_admissions(read):
    global _IMAGE_MODULE
    if _IMAGE_MODULE is None:
        spec = importlib.util.spec_from_file_location('historical_objective_images', ROOT / CURRENT_IMAGE_HELPER)
        _IMAGE_MODULE = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(_IMAGE_MODULE)
    images = _IMAGE_MODULE.ImageAdmissions(read(CURRENT_IMAGE_TABLE), CURRENT_IMAGE_TABLE_SHA256, git)
    require(images.data['owner'] == CURRENT_IMAGE_OWNER, 'current image admission owner mismatch')
    successors = _IMAGE_MODULE.ImageAdmissions(read(CURRENT_SUCCESSOR_TABLE), CURRENT_SUCCESSOR_SHA256, git)
    require(successors.data['owner'] == CURRENT_SUCCESSOR_OWNER, 'successor image admission owner mismatch')
    layered = _IMAGE_MODULE.SuccessorImageAdmissions(images, successors, protected=(PHASE0_FIXTURE,))
    additional = _IMAGE_MODULE.ImageAdmissions(read(ADDITIONAL_IMAGE_TABLE), ADDITIONAL_IMAGE_SHA256, git)
    require(additional.data['owner'] == CURRENT_SUCCESSOR_OWNER, 'additional image admission owner mismatch')
    return _IMAGE_MODULE.AdditionalImageAdmissions(layered, additional)


COMPILER_SCAN_BEFORE = b"    local *LinkedSpec::ActionIR::Scanner::scan_contract_ir_events = sub {\n"
COMPILER_SCAN_AFTER = b"    local *LinkedSpec::ActionIR::Scanner::_scan_executable_contract_ir_events = sub {\n"
BOUNDARY_IMPORT = b"use LinkedSpec::ActionIR::BoundaryLabels ();\n"
BOUNDARY_LOOP_BEFORE = br'''     for my $boundary (split(/\s*,\s*/, $+{boundaries})) {
      if ($boundary =~ /\A(["'])(.*)\1\z/s) {
       $boundary = $2;
       $boundary =~ s/\\(["'\\])/$1/g;
      }
'''
BOUNDARY_LOOP_AFTER = b"     for my $boundary (@{LinkedSpec::ActionIR::BoundaryLabels::_decode_recognized_labels($+{boundaries})}) {\n"
OCCURRENCE_ANCHOR = b"subtest 'actionir_canonical_events_require_avoids_core_load_until_build' => sub {\n"
OCCURRENCE_INSERTION = (
    b"subtest 'actionir_residual_occurrence_order_regression' => sub {\n"
    b"    plan tests => 2;\n"
    b"    my ($exit_code, $out, $err) = run_perl_snippet_in_subprocess(<<'PERL');\n"
    b"my $result = do './t/canonical_event_occurrence_order.t';\n"
    b"die $@ if $@;\n"
    b'die "queue regression did not load: $!" unless defined $result;\n'
    b"PERL\n"
    b"    is($exit_code, 0, 'permanent queue occurrence/ownership regression passes') or diag($err || $out);\n"
    b"    like($out, qr/^1\\.\\.[1-9][0-9]*$/m, 'the complete standalone assertion plan actually ran');\n"
    b"};\n"
)
# Only these reviewed CI insertions and Perl inventory replacements may evolve
# historical executable inputs. Normalization must recover every original byte.
TASK_EVIDENCE_CI_OWNER = 'TYPE-REFERENCE-BOOK.1.2.23.4.3'
TASK_EVIDENCE_CI_PATHS = (
    'tools/test_diagnosis_evidence.py',
    'docs/checkpoints/task-acceptance-backend-scope/test_restoration_boundary.py',
    'docs/checkpoints/task-acceptance-backend-scope/test_publish.py',
)
TASK_EVIDENCE_CI_INSERTIONS = (
    (b'bash "$REPO_ROOT/scripts/check_doctrines.sh"\n\n',
     b'log "checking task-evidence path coverage through isolated indexes"\n'
     b'require_tracked_file tools/test_diagnosis_evidence.py\n'
     b'bash "$REPO_ROOT/tools/run_python_project_data.sh" tools/test_diagnosis_evidence.py\n'
     b'require_tracked_file docs/checkpoints/task-acceptance-backend-scope/test_restoration_boundary.py\n'
     b'bash "$REPO_ROOT/tools/run_python_project_data.sh" docs/checkpoints/task-acceptance-backend-scope/test_restoration_boundary.py\n'
     b'require_tracked_file docs/checkpoints/task-acceptance-backend-scope/test_publish.py\n'
     b'bash "$REPO_ROOT/tools/run_python_project_data.sh" docs/checkpoints/task-acceptance-backend-scope/test_publish.py\n\n'),
)
RESTORATION_CI_INSERTIONS = (
    (b'require_command julia\n\n',
     b'if [[ "$(uname -s)" == Darwin ]]; then\n'
     b' log "checking macOS sandbox initialization required by process locality"\n'
     b" /usr/bin/sandbox-exec -p '(version 1) (allow default)' /usr/bin/true ||\n"
     b'  fail "macOS sandbox initialization denied; rerun this complete staged candidate in approved host execution (docs/knowledge/project-data-process-locality-proof.md)"\n'
     b'fi\n\n'),
    (b'bash "$REPO_ROOT/scripts/check_doctrines.sh"\n\n',
     b'log "checking bounded NUL-delimited path transport in the path/storage doctrines"\n'
     b'require_tracked_file tools/test_doctrine_path_streaming.py\n'
     b'bash "$REPO_ROOT/tools/run_python_project_data.sh" tools/test_doctrine_path_streaming.py\n'
     b'\n'
    ),
    (b'PERL5LIB= prove t/knowledge_map_header_lists.t\n',
     b'\n'
     b'log "checking atomic Knowledge Map publication and failure preservation"\n'
     b'require_tracked_file tools/test_knowledge_map_atomic_output.py\n'
     b'bash "$REPO_ROOT/tools/run_python_project_data.sh" tools/test_knowledge_map_atomic_output.py\n'
     b'\n'
     b'log "checking compact Knowledge metadata, immutable claim reuse and maintained scope controls"\n'
     b'for fixture in tools/test_knowledge_map_projection.py tools/test_claim_verification_cache.py tools/test_reference_scope.py tools/test_task_narrative.py tools/test_historical_objective_images.py \\\n'
     b'    docs/checkpoints/document-pressure-restoration/review.py \\\n'
     b'    docs/checkpoints/document-pressure-restoration/book_review.py; do\n'
     b'  require_tracked_file "$fixture"\n'
     b'  bash "$REPO_ROOT/tools/run_python_project_data.sh" "$fixture"\n'
     b'done\n'
     b'require_tracked_file tools/historical_objective_images.py\n'
     b'require_tracked_file tests/language-readiness/current-source-images.json.gz\n'
     b'log "checking paged exact document-history catalogs"\n'
     b'require_tracked_file t/document_history_catalog.t\n'
     b'PERL5LIB= prove t/document_history_catalog.t\n'
    ),
)

CI_INSERTIONS = (
    (b"require_tracked_file tools/check_typed_source_location_contract.py\n",
     b"require_tracked_file tools/check_language_closure_contract.py\n"
     b"require_tracked_file capability_conformance/language_closure_contract.json\n"),
    (b"perl tools/check_capability_conformance.pl\n\n",
     b'log "checking language closure operation/scope/reference structure"\n'
     b"bash tools/run_python_project_data.sh tools/check_language_closure_contract.py\n\n"),
)
COMPOSED_CI_INSERTIONS = (
    (b"require_tracked_file capability_conformance/language_closure_contract.json\n",
     b"require_tracked_file tools/check_composed_objective_contract.py\n"
     b"require_tracked_file capability_conformance/composed_objective_contract.json\n"
     b"require_tracked_file tests/language-readiness/composed/diagnostic.spec\n"
     b"require_tracked_file tests/language-readiness/composed/normalization.spec\n"
     b"require_tracked_file tests/language-readiness/composed/diagnostic-invalid-arity.spec\n"),
    (b"bash tools/run_python_project_data.sh tools/check_language_closure_contract.py\n\n",
     b'log "checking neutral composed objective fixtures and independent observations"\n'
     b"bash tools/run_python_project_data.sh tools/check_composed_objective_contract.py\n\n"),
)
PUSH_CI_INSERTIONS = (
    (b"require_tracked_file t/phase0_regression.t\n",
     b"require_tracked_file t/codeblock_push_composition_perl.t\n"),
    (b"PERL5LIB= prove -Iperl t/callable_codeblock_literal_contract.t\n",
     b'\nlog "running Perl deferred push composition and caller-identity fixture"\n'
     b"PERL5LIB= prove -Iperl t/codeblock_push_composition_perl.t\n"),
)
SIGNED_ARRAY_SELECTOR_OWNER = "TYPE-REFERENCE-BOOK.1.2.17.2"
SIGNED_ARRAY_SELECTOR_CI_INSERTIONS = (
    (b"require_tracked_file t/callable_codeblock_literal_contract.t\n",
     b"require_tracked_file t/signed_array_selector_perl_contract.t\n"
     b"require_tracked_file tests/numeric-codeblocks/signed-array-selectors.json\n"),
    (b"perl -c -Iperl t/callable_codeblock_literal_contract.t\n",
     b"perl -c -Iperl t/signed_array_selector_perl_contract.t\n"),
    (b"PERL5LIB= prove -Iperl t/callable_codeblock_literal_contract.t\n",
     b'\nlog "running Perl signed-array selector contract and public route fixture"\n'
     b"PERL5LIB= prove -Iperl t/signed_array_selector_perl_contract.t\n"),
)
NORMALIZATION_CI_INSERTIONS = (
    (b"require_tracked_file tests/language-readiness/composed/normalization.spec\n",
     b"require_tracked_file tests/language-readiness/composed/normalization-calls.spec\n"
     b"require_tracked_file t/composed_normalization_perl.t\n"
     b"require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.1-fresh.pl\n"),
    (b"PERL5LIB= prove -Iperl t/codeblock_push_composition_perl.t\n",
     b'\nlog "running Perl call-form normalization source and native/fresh object controls"\n'
     b"PERL5LIB= prove -Iperl t/composed_normalization_perl.t\n"),
)
ARTIFACT_RECOVERY_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.1"
ARTIFACT_CI_INSERTIONS = (
    (b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.1-fresh.pl\n',
     b'require_tracked_file tests/language-readiness/recover_objective_audit_inputs.py\n'
     b'require_tracked_file tests/language-readiness/artifacts/objective-audit-inputs.zip\n'
     b'require_tracked_file tests/language-readiness/artifacts/objective-audit-inputs.json\n'
     b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.1-proof.py\n'
     b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.1-archive.py\n'
     b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.0-census.py\n'
     b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.0-verification.json\n'
     b'require_tracked_file tests/language-readiness/verify_objectives.py\n'
     b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.1-verification.json\n'
     b'require_tracked_file docs/language-readiness/objective-reconciliation.md\n'
     b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.1.3.1.2.3-verification.json\n'
     b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.1.3.2.7-verification.json\n'
     b'require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.1.3.3.5-verification.json\n'
    ),
    (b'bash tools/run_python_project_data.sh tools/check_composed_objective_contract.py\n\n',
     b'log "checking isolated historical artifact recovery and read-denied audit"\n'
     b'bash tools/run_python_project_data.sh docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.1-proof.py\n'
     b'\n'
    ),
)

RAW_READINESS_OWNER = "SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.1"
RAW_READINESS_CI_INSERTIONS = (
    (b"require_tracked_file t/phase0_regression.t\n",
     b"require_tracked_file perl/LinkedSpec/ActionIR/RawDependencies.pm\n"
     b"require_tracked_file t/actionir_raw_dependency_metadata.t\n"
     b"require_tracked_file t/actionir_raw_dependency_provenance.t\n"
     b"require_tracked_file t/actionir_nested_block_source_spans.t\n"
     b"require_tracked_file t/actionir_raw_dependency_compatibility.t\n"),
    (b"perl -c -Iperl t/actionir_ast_parser.t\n",
     b"perl -c -Iperl perl/LinkedSpec/ActionIR/RawDependencies.pm\n"
     b"perl -c -Iperl t/actionir_raw_dependency_metadata.t\n"
     b"perl -c -Iperl t/actionir_raw_dependency_provenance.t\n"
     b"perl -c -Iperl t/actionir_nested_block_source_spans.t\n"
     b"perl -c -Iperl t/actionir_raw_dependency_compatibility.t\n"),
    (b"prove -Iperl t/actionir_ast_parser.t\n",
     b'\nlog "running source-bound raw dependency readiness and provenance suites"\n'
     b"PERL5LIB= prove -Iperl t/actionir_raw_dependency_metadata.t t/actionir_raw_dependency_provenance.t t/actionir_nested_block_source_spans.t t/actionir_raw_dependency_compatibility.t\n"),
)

SCALAR_RECEIVER_COPY_OWNER = "PERL-PRIVATE-FACTORY-CAPTURE.3.1.6.0.0"
SCALAR_RECEIVER_COPY_CI_INSERTIONS = (
    (b"require_tracked_file t/uniform_binding_contract.t\n",
     b"require_tracked_file t/actionir_receiver_scalar_copy.t\n"
     b"require_tracked_file t/actionir_receiver_scalar_copy_probe.pl\n"),
    (b"perl -c -Iperl t/actionir_ast_parser.t\n",
     b"perl -c -Iperl t/actionir_receiver_scalar_copy.t\n"
     b"perl -c -Iperl t/actionir_receiver_scalar_copy_probe.pl\n"),
    (b"prove -Iperl t/actionir_ast_parser.t\n",
     b'\nlog "running scalar receiver-copy regression suite"\n'
     b"prove -Iperl t/actionir_receiver_scalar_copy.t\n"),
)

KNOWLEDGE_HEADER_GATE_OWNER = "PERL-PRIVATE-FACTORY-CAPTURE.3.2.1.11"
KNOWLEDGE_HEADER_GATE_CI_INSERTIONS = (
    (b'bash "$REPO_ROOT/scripts/check_doctrines.sh"\n\n',
     b'log "checking Knowledge header list association through the public generator/checker"\n'
     b'require_tracked_file t/knowledge_map_header_lists.t\n'
     b'PERL5LIB= prove t/knowledge_map_header_lists.t\n\n'),
)

PRIVATE_FACTORY_FIXTURE_OWNER = "PERL-PRIVATE-FACTORY-CAPTURE.7"
PRIVATE_FACTORY_FIXTURE_PATHS = (
    't/actionir_method_input_captures.t',
    't/actionir_method_argument_source_frames.t',
    't/actionir_empty_expression_spans.t',
    't/actionir_ast_input_frames.t',
    't/actionir_ast_constructions.t',
    't/actionir_ast_parser.t',
    't/actionir_source_emissions.t',
    't/canonical_event_occurrence_order.t',
    't/actionir_nested_block_source_spans.t',
    't/actionir_compiler_source_membership.t',
    't/actionir_executable_source_membership.t',
    't/trace_actionir_method_lowering.t',
    't/trace_emit_context_bridge.t',
    'docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.2.2.0.3.1.0-origin-fixture.t',
    't/actionir_event_input_grants.t',
    't/actionir_input_composition_acceptance.t',
    't/actionir_factory_capture.t',
    't/actionir_emit_context_capture.t',
    't/actionir_emit_context_capture_cold.t',
    't/actionir_contract_dependency_capture.t',
    't/actionir_contract_dependency_capture_cold.t',
    't/actionir_contract_factory_capture.t',
    't/actionir_contract_factory_capture_cold.t',
    't/actionir_method_default_capture.t',
    't/actionir_method_default_capture_cold.t',
    't/actionir_method_trim_capture.t',
    't/actionir_method_trim_capture_cold.t',
    't/actionir_method_inference_capture.t',
    't/actionir_method_inference_capture_cold.t',
    't/actionir_method_inline_capture.t',
    't/actionir_method_inline_capture_cold.t',
    't/actionir_method_block_component_capture.t',
    't/actionir_method_block_component_capture_cold.t',
    't/actionir_method_local_return_capture.t',
    't/actionir_method_local_return_capture_cold.t',
    't/actionir_method_block_value_capture.t',
    't/actionir_method_block_value_capture_cold.t',
    't/actionir_method_ast_hash_key_capture.t',
    't/actionir_method_ast_hash_key_capture_cold.t',
    't/actionir_method_ast_call_capture.t',
    't/actionir_method_ast_call_capture_cold.t',
    't/actionir_method_ast_array_end_capture.t',
    't/actionir_method_ast_array_end_capture_cold.t',
    't/uniform_binding_contract.t',
    't/actionir_method_ast_assignment_capture.t',
    't/actionir_method_ast_assignment_capture_cold.t',
    't/actionir_method_value_capture.t',
    't/actionir_method_value_capture_cold.t',
    't/actionir_method_slot_capture.t',
    't/actionir_method_slot_capture_cold.t',
    't/actionir_method_general_return_capture.t',
    't/actionir_method_general_return_capture_cold.t',
    't/actionir_method_assignment_required_capture.t',
    't/actionir_method_assignment_required_capture_cold.t',
    't/actionir_method_set_key_required_capture.t',
    't/actionir_method_set_key_required_capture_cold.t',
    't/actionir_method_push_required_capture.t',
    't/actionir_method_push_required_capture_cold.t',
    't/actionir_method_regex_undef_required_capture.t',
    't/actionir_method_regex_undef_required_capture_cold.t',
    't/actionir_receiver_scalar_copy.t',
    't/actionir_array_receiver_required_capture.t',
    't/actionir_scalar_receiver_required_capture.t',
    't/actionir_hash_receiver_required_capture.t',
    't/actionir_array_end_required_capture.t',
    't/actionir_hash_index_required_capture.t',
    't/actionir_package_flow_capture.t',
    't/actionir_dropped_trim_capture.t',
    't/actionir_small_kind_capture.t',
    't/actionir_uniform_target.t',
    't/actionir_method_kind_capture.t',
    't/actionir_source_assignment_kind_capture.t',
    't/actionir_ast_optional_capture.t',
    't/actionir_tracking_predicate_capture.t',
    't/actionir_formal_trim_capture.t',
    't/actionir_named_dispatch_capture.t',
    't/actionir_flow_required_capture.t',
    't/actionir_flow_kind_capture.t',
    't/actionir_flow_default_capture.t',
    't/actionir_control_foundation_capture.t',
    't/actionir_control_expansion_capture.t',
    't/actionir_control_attached_capture.t',
    't/actionir_control_single_capture.t',
    't/actionir_control_ifwhile_capture.t',
    't/actionir_control_switch_capture.t',
    't/diagnostic_output_perl_contract.t',
    't/actionir_control_output_capture.t',
    't/actionir_control_kind_capture.t',
    't/actionir_control_calls_capture.t',
    't/actionir_control_default_capture.t',
    't/actionir_default_object_capture.t',
    't/actionir_array_end_required_cold_probe.pl',
    't/actionir_array_end_required_probe.pl',
    't/actionir_array_receiver_required_cold_probe.pl',
    't/actionir_array_receiver_required_probe.pl',
    't/actionir_ast_optional_probe.pl',
    't/actionir_ast_optional_stable_probe.pl',
    't/actionir_control_attached_native_fixed.pl',
    't/actionir_control_calls_native_complete.pl',
    't/actionir_control_default_native.pl',
    't/actionir_control_expansion_native.pl',
    't/actionir_control_foundation_native.pl',
    't/actionir_control_ifwhile_native.pl',
    't/actionir_control_ifwhile_native_complete.pl',
    't/actionir_control_kind_native_complete.pl',
    't/actionir_control_output_native.pl',
    't/actionir_control_output_native_complete.pl',
    't/actionir_control_single_native.pl',
    't/actionir_control_switch_native.pl',
    't/actionir_default_object_native.pl',
    't/actionir_dropped_trim_cold_probe.pl',
    't/actionir_dropped_trim_probe.pl',
    't/actionir_flow_default_native.pl',
    't/actionir_flow_kind_native.pl',
    't/actionir_flow_required_native.pl',
    't/actionir_formal_trim_probe.pl',
    't/actionir_hash_index_required_cold_probe.pl',
    't/actionir_hash_index_required_probe.pl',
    't/actionir_hash_receiver_required_cold_probe.pl',
    't/actionir_hash_receiver_required_probe.pl',
    't/actionir_legacy_hash_kind_cold_probe.pl',
    't/actionir_legacy_hash_kind_probe.pl',
    't/actionir_method_kind_authority_probe.pl',
    't/actionir_method_kind_probe.pl',
    't/actionir_method_regex_undef_required_probe.pl',
    't/actionir_named_dispatch_probe.pl',
    't/actionir_package_flow_cold_probe.pl',
    't/actionir_package_flow_probe.pl',
    't/actionir_receiver_scalar_copy_probe.pl',
    't/actionir_scalar_receiver_required_cold_probe.pl',
    't/actionir_scalar_receiver_required_probe.pl',
    't/actionir_small_kind_probe.pl',
    't/actionir_small_kind_reference_probe.pl',
    't/actionir_small_kind_symbolic_probe.pl',
    't/actionir_source_assignment_kind_probe.pl',
    't/actionir_tracking_predicate_probe.pl',
    't/actionir_uniform_target_probe.pl',
)
PRIVATE_FACTORY_FIXTURE_CI_INSERTIONS = ((
    b'PERL5LIB= prove -Iperl t/actionir_raw_dependency_metadata.t t/actionir_raw_dependency_provenance.t t/actionir_nested_block_source_spans.t t/actionir_raw_dependency_compatibility.t\n',
    (
        b'\n'
        b'# PERL-PRIVATE-FACTORY-CAPTURE.7: exact supplied fixture admission.\n'
        b'private_factory_suites=(\n'
        b' t/actionir_method_input_captures.t\n'
        b' t/actionir_method_argument_source_frames.t\n'
        b' t/actionir_empty_expression_spans.t\n'
        b' t/actionir_ast_input_frames.t\n'
        b' t/actionir_ast_constructions.t\n'
        b' t/actionir_ast_parser.t\n'
        b' t/actionir_source_emissions.t\n'
        b' t/canonical_event_occurrence_order.t\n'
        b' t/actionir_nested_block_source_spans.t\n'
        b' t/actionir_compiler_source_membership.t\n'
        b' t/actionir_executable_source_membership.t\n'
        b' t/trace_actionir_method_lowering.t\n'
        b' t/trace_emit_context_bridge.t\n'
        b' docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.2.2.0.3.1.0-origin-fixture.t\n'
        b' t/actionir_event_input_grants.t\n'
        b' t/actionir_input_composition_acceptance.t\n'
        b' t/actionir_factory_capture.t\n'
        b' t/actionir_emit_context_capture.t\n'
        b' t/actionir_emit_context_capture_cold.t\n'
        b' t/actionir_contract_dependency_capture.t\n'
        b' t/actionir_contract_dependency_capture_cold.t\n'
        b' t/actionir_contract_factory_capture.t\n'
        b' t/actionir_contract_factory_capture_cold.t\n'
        b' t/actionir_method_default_capture.t\n'
        b' t/actionir_method_default_capture_cold.t\n'
        b' t/actionir_method_trim_capture.t\n'
        b' t/actionir_method_trim_capture_cold.t\n'
        b' t/actionir_method_inference_capture.t\n'
        b' t/actionir_method_inference_capture_cold.t\n'
        b' t/actionir_method_inline_capture.t\n'
        b' t/actionir_method_inline_capture_cold.t\n'
        b' t/actionir_method_block_component_capture.t\n'
        b' t/actionir_method_block_component_capture_cold.t\n'
        b' t/actionir_method_local_return_capture.t\n'
        b' t/actionir_method_local_return_capture_cold.t\n'
        b' t/actionir_method_block_value_capture.t\n'
        b' t/actionir_method_block_value_capture_cold.t\n'
        b' t/actionir_method_ast_hash_key_capture.t\n'
        b' t/actionir_method_ast_hash_key_capture_cold.t\n'
        b' t/actionir_method_ast_call_capture.t\n'
        b' t/actionir_method_ast_call_capture_cold.t\n'
        b' t/actionir_method_ast_array_end_capture.t\n'
        b' t/actionir_method_ast_array_end_capture_cold.t\n'
        b' t/uniform_binding_contract.t\n'
        b' t/actionir_method_ast_assignment_capture.t\n'
        b' t/actionir_method_ast_assignment_capture_cold.t\n'
        b' t/actionir_method_value_capture.t\n'
        b' t/actionir_method_value_capture_cold.t\n'
        b' t/actionir_method_slot_capture.t\n'
        b' t/actionir_method_slot_capture_cold.t\n'
        b' t/actionir_method_general_return_capture.t\n'
        b' t/actionir_method_general_return_capture_cold.t\n'
        b' t/actionir_method_assignment_required_capture.t\n'
        b' t/actionir_method_assignment_required_capture_cold.t\n'
        b' t/actionir_method_set_key_required_capture.t\n'
        b' t/actionir_method_set_key_required_capture_cold.t\n'
        b' t/actionir_method_push_required_capture.t\n'
        b' t/actionir_method_push_required_capture_cold.t\n'
        b' t/actionir_method_regex_undef_required_capture.t\n'
        b' t/actionir_method_regex_undef_required_capture_cold.t\n'
        b' t/actionir_receiver_scalar_copy.t\n'
        b' t/actionir_array_receiver_required_capture.t\n'
        b' t/actionir_scalar_receiver_required_capture.t\n'
        b' t/actionir_hash_receiver_required_capture.t\n'
        b' t/actionir_array_end_required_capture.t\n'
        b' t/actionir_hash_index_required_capture.t\n'
        b' t/actionir_package_flow_capture.t\n'
        b' t/actionir_dropped_trim_capture.t\n'
        b' t/actionir_small_kind_capture.t\n'
        b' t/actionir_uniform_target.t\n'
        b' t/actionir_method_kind_capture.t\n'
        b' t/actionir_source_assignment_kind_capture.t\n'
        b' t/actionir_ast_optional_capture.t\n'
        b' t/actionir_tracking_predicate_capture.t\n'
        b' t/actionir_formal_trim_capture.t\n'
        b' t/actionir_named_dispatch_capture.t\n'
        b' t/actionir_flow_required_capture.t\n'
        b' t/actionir_flow_kind_capture.t\n'
        b' t/actionir_flow_default_capture.t\n'
        b' t/actionir_control_foundation_capture.t\n'
        b' t/actionir_control_expansion_capture.t\n'
        b' t/actionir_control_attached_capture.t\n'
        b' t/actionir_control_single_capture.t\n'
        b' t/actionir_control_ifwhile_capture.t\n'
        b' t/actionir_control_switch_capture.t\n'
        b' t/diagnostic_output_perl_contract.t\n'
        b' t/actionir_control_output_capture.t\n'
        b' t/actionir_control_kind_capture.t\n'
        b' t/actionir_control_calls_capture.t\n'
        b' t/actionir_control_default_capture.t\n'
        b' t/actionir_default_object_capture.t\n'
        b')\n'
        b'private_factory_helpers=(\n'
        b' t/actionir_array_end_required_cold_probe.pl\n'
        b' t/actionir_array_end_required_probe.pl\n'
        b' t/actionir_array_receiver_required_cold_probe.pl\n'
        b' t/actionir_array_receiver_required_probe.pl\n'
        b' t/actionir_ast_optional_probe.pl\n'
        b' t/actionir_ast_optional_stable_probe.pl\n'
        b' t/actionir_control_attached_native_fixed.pl\n'
        b' t/actionir_control_calls_native_complete.pl\n'
        b' t/actionir_control_default_native.pl\n'
        b' t/actionir_control_expansion_native.pl\n'
        b' t/actionir_control_foundation_native.pl\n'
        b' t/actionir_control_ifwhile_native.pl\n'
        b' t/actionir_control_ifwhile_native_complete.pl\n'
        b' t/actionir_control_kind_native_complete.pl\n'
        b' t/actionir_control_output_native.pl\n'
        b' t/actionir_control_output_native_complete.pl\n'
        b' t/actionir_control_single_native.pl\n'
        b' t/actionir_control_switch_native.pl\n'
        b' t/actionir_default_object_native.pl\n'
        b' t/actionir_dropped_trim_cold_probe.pl\n'
        b' t/actionir_dropped_trim_probe.pl\n'
        b' t/actionir_flow_default_native.pl\n'
        b' t/actionir_flow_kind_native.pl\n'
        b' t/actionir_flow_required_native.pl\n'
        b' t/actionir_formal_trim_probe.pl\n'
        b' t/actionir_hash_index_required_cold_probe.pl\n'
        b' t/actionir_hash_index_required_probe.pl\n'
        b' t/actionir_hash_receiver_required_cold_probe.pl\n'
        b' t/actionir_hash_receiver_required_probe.pl\n'
        b' t/actionir_legacy_hash_kind_cold_probe.pl\n'
        b' t/actionir_legacy_hash_kind_probe.pl\n'
        b' t/actionir_method_kind_authority_probe.pl\n'
        b' t/actionir_method_kind_probe.pl\n'
        b' t/actionir_method_regex_undef_required_probe.pl\n'
        b' t/actionir_named_dispatch_probe.pl\n'
        b' t/actionir_package_flow_cold_probe.pl\n'
        b' t/actionir_package_flow_probe.pl\n'
        b' t/actionir_receiver_scalar_copy_probe.pl\n'
        b' t/actionir_scalar_receiver_required_cold_probe.pl\n'
        b' t/actionir_scalar_receiver_required_probe.pl\n'
        b' t/actionir_small_kind_probe.pl\n'
        b' t/actionir_small_kind_reference_probe.pl\n'
        b' t/actionir_small_kind_symbolic_probe.pl\n'
        b' t/actionir_source_assignment_kind_probe.pl\n'
        b' t/actionir_tracking_predicate_probe.pl\n'
        b' t/actionir_uniform_target_probe.pl\n'
        b')\n'
        b'log "checking complete private factory fixture inputs and syntax"\n'
        b'for private_factory_input in "${private_factory_suites[@]}" "${private_factory_helpers[@]}"; do\n'
        b' require_tracked_file "$private_factory_input"\n'
        b' perl -c -Iperl "$private_factory_input"\n'
        b'done\n'
        b'log "running complete supplied private factory regression population"\n'
        b'LINKEDSPEC_EVENT_ORDER_BASELINE=0 LINKEDSPEC_MEMBERSHIP_BASELINE=0 PERL5LIB= PERL5OPT= prove -Iperl "${private_factory_suites[@]}"\n'
    ),
),)

PERL_STORAGE_REPLACEMENTS = (
    (b"(( ${#perl_temp_owners[@]} == 27 )) ||\n",
     b"(( ${#perl_temp_owners[@]} == 29 )) ||\n"),
    (b' fail "tracked Perl temporary-allocation inventory drifted from 27 to ${#perl_temp_owners[@]}"\n',
     b' fail "tracked Perl temporary-allocation inventory drifted from 29 to ${#perl_temp_owners[@]}"\n'),
    (b"for owner in t/legacy_pathsearch_fallback.t t/nested_tree_readiness.t t/lua_legacy_temp_residue.t; do\n",
     b"for owner in t/legacy_pathsearch_fallback.t t/nested_tree_readiness.t t/lua_legacy_temp_residue.t t/codeblock_push_composition_perl.t t/knowledge_map_header_lists.t; do\n"),
    (b" '[perl-project-data-test] PASS: 27 Perl allocators, traces, and CLI workspaces stay on repository storage'\n",
     b" '[perl-project-data-test] PASS: 29 Perl allocators, traces, and CLI workspaces stay on repository storage'\n"),
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=ROOT)


def read_relative(path):
    candidate = Path(path)
    require(not candidate.is_absolute() and ".." not in candidate.parts,
            f"non-repository evidence path: {path}")
    resolved = (ROOT / candidate).resolve()
    resolved.relative_to(ROOT)
    return resolved.read_bytes()


def producing_commit(path):
    commit = git("log", "--diff-filter=A", "-1", "--format=%H", "--", path).decode().strip()
    require(len(commit) == 40, f"missing producing commit: {path}")
    return commit


def verify_governance_evolution(source, contents, historical_hash):
    require(source == "tools/run_ci_local.sh", f"unapproved governance source: {source}")
    normalized = contents
    # Strip the later insertions first: their anchors are earlier owned additions.
    insertions = (
        TASK_EVIDENCE_CI_INSERTIONS
        + RESTORATION_CI_INSERTIONS
        + SIGNED_ARRAY_SELECTOR_CI_INSERTIONS
        + PRIVATE_FACTORY_FIXTURE_CI_INSERTIONS
        + KNOWLEDGE_HEADER_GATE_CI_INSERTIONS
        + SCALAR_RECEIVER_COPY_CI_INSERTIONS
        + RAW_READINESS_CI_INSERTIONS
        + ARTIFACT_CI_INSERTIONS
        + NORMALIZATION_CI_INSERTIONS
        + PUSH_CI_INSERTIONS
        + COMPOSED_CI_INSERTIONS
        + CI_INSERTIONS
    )
    for anchor, insertion in insertions:
        require(normalized.count(anchor + insertion) == 1,
                f"governance registration mismatch: {source}")
        normalized = normalized.replace(anchor + insertion, anchor, 1)
    require(digest(normalized) == historical_hash,
            f"unreviewed governance drift: {source}")
    return {"path": source, "historical": historical_hash,
            "current": digest(contents), "owner": GOVERNANCE_OWNER,
            "additional_owner": COMPOSED_GOVERNANCE_OWNER,
            "runtime_repair_owner": PUSH_REPAIR_OWNER,
            "source_correction_owner": NORMALIZATION_CORRECTION_OWNER,
            "artifact_recovery_owner": ARTIFACT_RECOVERY_OWNER,
            "raw_readiness_owner": RAW_READINESS_OWNER,
            "scalar_receiver_copy_owner": SCALAR_RECEIVER_COPY_OWNER,
            "knowledge_header_gate_owner": KNOWLEDGE_HEADER_GATE_OWNER,
            "private_factory_fixture_owner": PRIVATE_FACTORY_FIXTURE_OWNER,
            "signed_array_selector_owner": SIGNED_ARRAY_SELECTOR_OWNER,
            "restoration_owner": "TYPE-REFERENCE-BOOK.1.2.20.1.10",
            "execution_preflight_owner": "TYPE-REFERENCE-BOOK.1.2.20.1.20",
            "task_evidence_owner": TASK_EVIDENCE_CI_OWNER,
            "scope": "exact anchored checker/input registration; original CI bytes preserved"}


SELECTOR_LITERAL_PATTERN_UPDATES = (
    (b'r"(?<![A-Za-z0-9_])(?:array|hash)\\([ \\t]*[A-Za-z_][A-Za-z0-9_]*[ \\t]*\\)"',
     b'r"(?<![A-Za-z0-9_])(?:array|hash)\\([ \\t]*(?!(?:true|false|undef)[ \\t]*\\))[A-Za-z_][A-Za-z0-9_]*[ \\t]*\\)"'),
    (b'r"(?<![A-Za-z0-9_])(?:array|hash)[ \\t]*\\([ \\t]*[A-Za-z_][A-Za-z0-9_]*[ \\t]*\\)"',
     b'r"(?<![A-Za-z0-9_])(?:array|hash)[ \\t]*\\([ \\t]*(?!(?:true|false|undef)[ \\t]*\\))[A-Za-z_][A-Za-z0-9_]*[ \\t]*\\)"'),
)


def verify_selector_governance_evolution(source, contents, historical_hash):
    require(source == "tools/check_public_aggregate_selector_surface.py",
            f"unapproved selector governance source: {source}")
    current_image = digest(contents)
    for original_pattern, literal_pattern in SELECTOR_LITERAL_PATTERN_UPDATES:
        require(contents.count(literal_pattern) == 1,
                f"selector governance registration mismatch: {source}")
        contents = contents.replace(literal_pattern, original_pattern, 1)
    before = b"EXPECTED_CLASSIFIED_REFERENCE_COUNT = 36\n"
    after = b"EXPECTED_CLASSIFIED_REFERENCE_COUNT = 40\n"
    require(contents.count(after) == 1,
            f"selector governance registration mismatch: {source}")
    normalized = contents.replace(after, before, 1)
    require(digest(normalized) == historical_hash,
            f"unreviewed selector governance drift: {source}")
    return {"path": source, "historical": historical_hash,
            "current": current_image, "owner": SCALAR_RECEIVER_COPY_OWNER,
            "literal_owner": "TYPE-REFERENCE-BOOK.1.2.20.1.13.2",
            "scope": "exact public census and literal-token inverses; every original checker byte preserved"}


def signature_subtest(contents):
    start = b"subtest 'actionir_statement_split_core_requires_newline_or_semicolon_boundaries' => sub {\n"
    following = b"subtest 'actionir_canonical_events_require_avoids_core_load_until_build' => sub {\n"
    require(contents.count(start) == contents.count(following) == 1,
            "signature regression marker mismatch: t/phase0_regression.t")
    first = contents.index(start)
    end = contents.index(following, first)
    return contents[first:end]


def restore_raw_readiness_oracles(contents):
    path = "docs/checkpoints/" + RAW_READINESS_OWNER + "-compatibility-oracles.json"
    table = json.loads(read_relative(path))
    expected = ("emit_context_meta_exposes_language_agnostic_readiness",
                "emit_context_meta_exposes_language_agnostic_blocker_statements",
                "return_descriptor_exposes_action_rewriter_migration_summary",
                "return_descriptor_exposes_action_rewriter_migration_blocker_type_breakdown",
                "method_empty_action_return_with_leading_space_args_stays_balanced")
    require(tuple(row["subtest"] for row in table["subtests"]) == expected
            and sum(len(row["assertions"]) for row in table["subtests"]) == 14,
            "raw-readiness oracle table mismatch: t/phase0_regression.t")
    for row in table["subtests"]:
        marker = ("subtest '" + row["subtest"] + "' => sub {\n").encode()
        require(contents.count(marker) == 1,
                "raw-readiness oracle marker mismatch: t/phase0_regression.t")
        start = contents.index(marker)
        end = contents.find(b"\nsubtest ", start + len(marker))
        require(end >= 0, "raw-readiness oracle boundary mismatch: t/phase0_regression.t")
        block = contents[start:end]
        for pair in row["assertions"]:
            old, new = pair["before"].encode(), pair["after"].encode()
            require(old != new and block.count(new) == 1,
                    "raw-readiness oracle assertion mismatch: t/phase0_regression.t")
            block = block.replace(new, old, 1)
        contents = contents[:start] + block + contents[end:]
    return contents


def boundary_recurrence(contents):
    marker = b"subtest 'quoted_boundary_atoms_survive_nested_value_serialization' => sub {\n"
    anchor = b"subtest 'anonymous_capture_take_until_cursor_helper_reads_and_advances_through_current_parser_position' => sub {\n"
    require(contents.count(marker) == contents.count(anchor) == 1,
            "boundary recurrence marker mismatch: t/phase0_regression.t")
    start = contents.index(marker)
    end = contents.index(anchor, start)
    return contents[start:end]


def restore_boundary_recurrence(source, contents):
    before = git("show", f"{BOUNDARY_AFTER}:{source}")
    after = git("show", f"{BOUNDARY_RECURRENCE_AFTER}:{source}")
    insertion = boundary_recurrence(after)
    require(after.replace(insertion, b"", 1) == before,
            f"unreviewed boundary recurrence history: {source}")
    require(contents.count(insertion) == 1,
            f"boundary recurrence registration mismatch: {source}")
    return contents.replace(insertion, b"", 1)


def restore_compiler_scanner_mock(source, contents):
    before = git("show", f"{COMPILER_MEMBERSHIP_BEFORE}:{source}")
    after = git("show", f"{COMPILER_MEMBERSHIP_AFTER}:{source}")
    require(after.count(COMPILER_SCAN_AFTER) == 1 and
            after.replace(COMPILER_SCAN_AFTER, COMPILER_SCAN_BEFORE, 1) == before,
            f"unreviewed compiler scanner mock history: {source}")
    require(contents.count(COMPILER_SCAN_AFTER) == 1,
            f"compiler scanner mock registration mismatch: {source}")
    return contents.replace(COMPILER_SCAN_AFTER, COMPILER_SCAN_BEFORE, 1)



def drop_generated_table(source):
    raw = read_relative(DROP_GENERATED_TABLE)
    require(digest(raw) == DROP_GENERATED_TABLE_SHA256,
            "drop inverse table identity mismatch: " + source)
    table = json.loads(gzip.decompress(raw))
    require(table["version"] == 1 and table["owner"] == DROP_GENERATED_OWNER and
            table["source"] == source == "t/phase0_regression.t" and
            table["before_revision"] == DROP_GENERATED_BEFORE and
            len(table["hunks"]) == len({item["id"] for item in table["hunks"]}) == 2,
            "drop inverse owner/population mismatch: " + source)
    rebuilt = git("show", f"{DROP_GENERATED_BEFORE}:{source}")
    require(digest(rebuilt) == table["before_sha256"], "drop inverse base mismatch: " + source)
    for item in table["hunks"]:
        old, new = item["before"].encode(), item["after"].encode()
        require(old and new and old != new and rebuilt.count(old) == 1,
                "drop inverse reconstruction mismatch: " + source)
        rebuilt = rebuilt.replace(old, new, 1)
    require(digest(rebuilt) == table["after_sha256"], "drop inverse reconstruction mismatch: " + source)
    return table


def count_first_table(source):
    raw = read_relative(COUNT_FIRST_TABLE)
    require(digest(raw) == COUNT_FIRST_TABLE_SHA256,
            "count/first inverse table identity mismatch: " + source)
    table = json.loads(raw)
    require(table["version"] == 1 and table["owner"] == COUNT_FIRST_OWNER and
            table["source"] == source == "t/phase0_regression.t" and
            table["before_revision"] == COUNT_FIRST_BEFORE and
            len(table["hunks"]) == len({item["id"] for item in table["hunks"]}) == 10,
            "count/first inverse owner/population mismatch: " + source)
    rebuilt = git("show", f"{COUNT_FIRST_BEFORE}:{source}")
    require(digest(rebuilt) == table["before_sha256"],
            "count/first inverse base mismatch: " + source)
    for item in table["hunks"]:
        old, new = item["before"].encode(), item["after"].encode()
        require(old and new and old != new and rebuilt.count(old) == 1,
                "count/first inverse reconstruction mismatch: " + source)
        rebuilt = rebuilt.replace(old, new, 1)
    require(digest(rebuilt) == table["after_sha256"],
            "count/first inverse reconstruction mismatch: " + source)
    return table


def restore_count_first_regressions(source, contents):
    # Older falsifiers intentionally supply their original pre-selection stage.
    # The final historical comparison still rejects every unregistered edit.
    if COUNT_FIRST_MARKER not in contents:
        return contents
    for item in reversed(count_first_table(source)["hunks"]):
        old, new = item["before"].encode(), item["after"].encode()
        require(contents.count(new) == 1,
                "count/first regression registration mismatch: " + source)
        contents = contents.replace(new, old, 1)
    return contents


def restore_drop_generated_regressions(source, contents):
    # Earlier-stage falsifiers deliberately supply pre-drop source. The final
    # historical byte/hash comparison still rejects every unregistered edit.
    if DROP_GENERATED_MARKER not in contents:
        return contents
    table = drop_generated_table(source)
    for item in reversed(table["hunks"]):
        old, new = item["before"].encode(), item["after"].encode()
        require(contents.count(new) == 1, "drop regression registration mismatch: " + source)
        contents = contents.replace(new, old, 1)
    return contents


def scalar_numeric_table(source):
    raw = read_relative(SCALAR_NUMERIC_TABLE)
    require(digest(raw) == SCALAR_NUMERIC_TABLE_SHA256,
            "numeric inverse table identity mismatch: " + source)
    table = json.loads(gzip.decompress(raw))
    require(table["version"] == 1 and table["owner"] == SCALAR_NUMERIC_OWNER and
            table["source"] == source == "t/phase0_regression.t" and
            table["before_revision"] == SCALAR_NUMERIC_BEFORE and
            len(table["hunks"]) == len({row["id"] for row in table["hunks"]}) == 22,
            "numeric inverse owner/population mismatch: " + source)
    rebuilt = git("show", f"{SCALAR_NUMERIC_BEFORE}:{source}")
    require(digest(rebuilt) == table["before_sha256"],
            "numeric inverse base mismatch: " + source)
    for row in table["hunks"]:
        old, new = row["before"].encode(), row["after"].encode()
        require(old and new and old != new and rebuilt.count(old) == 1,
                "numeric inverse reconstruction mismatch: " + source)
        rebuilt = rebuilt.replace(old, new, 1)
    require(digest(rebuilt) == table["after_sha256"],
            "numeric inverse reconstruction mismatch: " + source)
    return table


def restore_scalar_numeric_regressions(source, contents):
    # Older-stage falsifiers deliberately supply pre-numeric source. The complete
    # historical comparison still rejects every unregistered older-stage edit.
    if SCALAR_NUMERIC_MARKER not in contents:
        return contents
    table = scalar_numeric_table(source)
    for row in reversed(table["hunks"]):
        old, new = row["before"].encode(), row["after"].encode()
        require(contents.count(new) == 1,
                "numeric regression registration mismatch: " + source)
        contents = contents.replace(new, old, 1)
    return contents


def restore_evaluated_value_regressions(source, contents):
    raw = read_relative(EVALUATED_VALUES_TABLE)
    require(digest(raw) == EVALUATED_VALUES_TABLE_SHA256,
            "evaluated-value inverse table identity mismatch: " + source)
    table = json.loads(raw)
    require(table["version"] == 1 and table["owner"] == EVALUATED_VALUES_OWNER and
            table["source"] == source == "t/phase0_regression.t" and
            table["before_revision"] == EVALUATED_VALUES_BEFORE,
            "evaluated-value inverse owner mismatch: " + source)
    before = git("show", f"{EVALUATED_VALUES_BEFORE}:{source}")
    require(digest(before) == table["before_sha256"],
            "evaluated-value inverse base mismatch: " + source)
    rebuilt = before
    for row in table["hunks"]:
        old, new = row["before"].encode(), row["after"].encode()
        require(old and new and old != new and rebuilt.count(old) == 1,
                "evaluated-value inverse reconstruction mismatch: " + source)
        rebuilt = rebuilt.replace(old, new, 1)
    require(digest(rebuilt) == table["after_sha256"],
            "evaluated-value inverse reconstruction mismatch: " + source)
    for row in table["hunks"]:
        old, new = row["before"].encode(), row["after"].encode()
        require(contents.count(new) == 1,
                "evaluated-value regression registration mismatch: " + source)
        contents = contents.replace(new, old, 1)
    return contents


def verify_signature_regression_evolution(source, contents, historical_hash):
    require(source == "t/phase0_regression.t", f"unapproved signature regression source: {source}")
    before = git("show", f"{SIGNATURE_BEFORE}:{source}")
    after = git("show", f"{SIGNATURE_AFTER}:{source}")
    current_hash = digest(contents)
    contents = restore_count_first_regressions(source, contents)
    contents = restore_drop_generated_regressions(source, contents)
    contents = restore_scalar_numeric_regressions(source, contents)
    contents = restore_evaluated_value_regressions(source, contents)
    contents = restore_compiler_scanner_mock(source, contents)
    contents = restore_boundary_recurrence(source, contents)
    require(contents.count(OCCURRENCE_INSERTION + OCCURRENCE_ANCHOR) == 1,
            f"occurrence regression registration mismatch: {source}")
    prior = restore_raw_readiness_oracles(contents).replace(OCCURRENCE_INSERTION + OCCURRENCE_ANCHOR,
                             OCCURRENCE_ANCHOR, 1)
    require(prior == after, f"unreviewed signature-regression drift: {source}")
    # Replace only the exact owned subtest, including its fixed/dynamic plan change.
    normalized = prior.replace(signature_subtest(after), signature_subtest(before), 1)
    require(normalized == before and digest(normalized) == historical_hash,
            f"unreviewed signature-regression history: {source}")
    return {"path": source, "historical": historical_hash, "current": current_hash,
            "owner": SIGNATURE_REPAIR_OWNER, "reconciliation_owner": NORMALIZATION_CORRECTION_OWNER,
            "occurrence_repair_owner": OCCURRENCE_REPAIR_OWNER,
            "raw_readiness_owner": RAW_READINESS_OWNER,
            "boundary_recurrence_owner": BOUNDARY_RECURRENCE_OWNER,
            "boundary_recurrence_before_revision": BOUNDARY_AFTER,
            "boundary_recurrence_after_revision": BOUNDARY_RECURRENCE_AFTER,
            "count_first_owner": COUNT_FIRST_OWNER,
            "count_first_input": COUNT_FIRST_TABLE,
            "count_first_table_sha256": COUNT_FIRST_TABLE_SHA256,
            "count_first_before_revision": COUNT_FIRST_BEFORE,
            "drop_generated_owner": DROP_GENERATED_OWNER,
            "drop_generated_input": DROP_GENERATED_TABLE,
            "drop_generated_table_sha256": DROP_GENERATED_TABLE_SHA256,
            "drop_generated_before_revision": DROP_GENERATED_BEFORE,
            "scalar_numeric_owner": SCALAR_NUMERIC_OWNER,
            "scalar_numeric_input": SCALAR_NUMERIC_TABLE,
            "scalar_numeric_table_sha256": SCALAR_NUMERIC_TABLE_SHA256,
            "scalar_numeric_before_revision": SCALAR_NUMERIC_BEFORE,
            "evaluated_values_owner": EVALUATED_VALUES_OWNER,
            "evaluated_values_input": EVALUATED_VALUES_TABLE,
            "evaluated_values_table_sha256": EVALUATED_VALUES_TABLE_SHA256,
            "evaluated_values_before_revision": EVALUATED_VALUES_BEFORE,
            "compiler_membership_owner": COMPILER_MEMBERSHIP_OWNER,
            "compiler_membership_reconciliation_owner": COMPILER_MEMBERSHIP_RECONCILIATION_OWNER,
            "compiler_membership_before_revision": COMPILER_MEMBERSHIP_BEFORE,
            "compiler_membership_after_revision": COMPILER_MEMBERSHIP_AFTER,
            "before_revision": SIGNATURE_BEFORE, "after_revision": SIGNATURE_AFTER,
            "scope": "exact count/first guard-golden inverse followed by owner-bound evaluated-value test inverse, committed compiler-scanner mock-entry replacement, nested-boundary insertion, fourteen metadata assertion replacements, occurrence regression insertion and committed signature subtest/plan replacement; original Phase0 bytes recovered"}


def restore_perl_storage_inventory(source, contents, read=None):
    read = read_relative if read is None else read
    raw = read(STORAGE_INVENTORY_TABLE)
    require(digest(raw) == STORAGE_INVENTORY_TABLE_SHA256,
            'unreviewed Perl storage inventory table')
    table = json.loads(gzip.decompress(raw))
    require(table['schema_version'] == 1 and table['owner'] == STORAGE_INVENTORY_OWNER
            and source == table['path'] == 'tools/test_perl_project_data_storage.sh',
            'unreviewed Perl storage inventory owner')

    def decode(row):
        raw = base64.b64decode(row['base64'], validate=True)
        require(digest(raw) == row['sha256'], 'unreviewed Perl storage inventory packet')
        return raw

    require(contents == decode(table['after']), 'unreviewed Perl storage inventory source')
    require(set(table['support']) == {'tools/check_project_storage_inventory.pl',
                                    'doctrine/project_data_storage/perl_temporary_owners.json'},
            'unreviewed Perl storage inventory support population')
    for name, row in table['support'].items():
        require(read(name) == decode(row), 'unreviewed Perl storage inventory support: ' + name)
    return decode(table['before'])


def verify_perl_storage_evolution(source, contents, historical_hash, read=None):
    prior = restore_perl_storage_inventory(source, contents, read)
    result = verify_perl_storage_census_evolution(source, prior, historical_hash)
    result.update(current=digest(contents), inventory_owner=STORAGE_INVENTORY_OWNER,
                  inventory_table_sha256=STORAGE_INVENTORY_TABLE_SHA256,
                  scope='exact reviewed manifest/source stage, then original 27-to-29 census inverse; runtime proof separate')
    return result


def verify_perl_storage_census_evolution(source, contents, historical_hash):
    require(source == "tools/test_perl_project_data_storage.sh",
            f"unapproved Perl storage source: {source}")
    normalized = contents
    for historical, current in PERL_STORAGE_REPLACEMENTS:
        require(normalized.count(current) == 1,
                f"Perl storage registration mismatch: {source}")
        normalized = normalized.replace(current, historical, 1)
    require(digest(normalized) == historical_hash,
            f"unreviewed Perl storage drift: {source}")
    return {"path": source, "historical": historical_hash,
            "current": digest(contents), "owner": PUSH_REPAIR_OWNER,
            "knowledge_header_gate_owner": KNOWLEDGE_HEADER_GATE_OWNER,
            "scope": "exact 27-to-29 census and two allocator memberships; original bytes preserved"}


def restore_contract_factory_capture(source, contents):
    """Admit only the two named committed whole-file factory changes.

    This is historical byte reconciliation, never a fresh runtime assertion.
    Any later or foreign source edit requires its own reviewed inverse.
    """
    before = git("show", f"{CONTRACT_CAPTURE_BEFORE}:{source}")
    dependencies = git("show", f"{CONTRACT_CAPTURE_DEPENDENCIES}:{source}")
    after = git("show", f"{CONTRACT_CAPTURE_AFTER}:{source}")
    require(before == git("show", f"{BOUNDARY_AFTER}:{source}") and
            before == git("show", f"{CONTRACT_CAPTURE_DEPENDENCIES}^1:{source}") and
            dependencies == git("show", f"{CONTRACT_CAPTURE_AFTER}^1:{source}") and
            before != dependencies and dependencies != after,
            f"unreviewed Contracts factory capture history: {source}")
    require(contents == after,
            f"unreviewed Contracts factory capture drift: {source}")
    return before


def verify_boundary_contract_evolution(source, contents, historical_hash):
    require(source == "perl/LinkedSpec/ActionIR/Contracts.pm",
            f"unapproved boundary contract source: {source}")
    current_hash = digest(contents)
    contents = restore_contract_factory_capture(source, contents)
    before = git("show", f"{BOUNDARY_BEFORE}:{source}")
    after = git("show", f"{BOUNDARY_AFTER}:{source}")
    require(digest(before) == historical_hash,
            f"unreviewed boundary contract history: {source}")
    require(contents.count(BOUNDARY_IMPORT) == 1 and
            contents.count(BOUNDARY_LOOP_AFTER) == 1,
            f"boundary contract registration mismatch: {source}")
    normalized = contents.replace(BOUNDARY_IMPORT, b"", 1).replace(
        BOUNDARY_LOOP_AFTER, BOUNDARY_LOOP_BEFORE, 1)
    require(normalized == before and contents == after,
            f"unreviewed boundary contract drift: {source}")
    return {"path": source, "historical": historical_hash, "current": current_hash,
            "owner": BOUNDARY_REPAIR_OWNER,
            "before_revision": BOUNDARY_BEFORE, "after_revision": BOUNDARY_AFTER,
            "factory_capture_owners": list(CONTRACT_CAPTURE_OWNERS),
            "factory_capture_before_revision": CONTRACT_CAPTURE_BEFORE,
            "factory_capture_dependencies_revision": CONTRACT_CAPTURE_DEPENDENCIES,
            "factory_capture_after_revision": CONTRACT_CAPTURE_AFTER,
            "scope": "exact two committed whole-file factory/dependency changes, then decoder import and quoted-boundary loop inverse; original historical bytes recovered; no fresh objective execution"}


def verify_rust_signed_evolution(source, contents, historical_hash):
    require(source == RUST_SIGNED_SOURCE, f"unapproved Rust runtime source: {source}")
    require(historical_hash == RUST_SIGNED_BEFORE,
            f"Rust runtime historical boundary mismatch: {source}")
    # This is a whole-source admission, not a wildcard or blind replacement.
    # Both images are retained by the owner's actual native/generated proof;
    # any further executable or test-byte change needs its own reviewed owner.
    require(digest(contents) == RUST_SIGNED_AFTER,
            f"unreviewed Rust runtime drift: {source}")
    return {"path": source, "historical": historical_hash,
            "current": digest(contents), "owner": RUST_SIGNED_OWNER,
            "scope": "exact signed-selector source image; historical runtime results unchanged; fresh Rust readiness compatibility is separately retained"}


def verify_dart_signed_evolution(source, contents, historical_hash):
    require(source == DART_SIGNED_SOURCE, f"unapproved Dart runtime source: {source}")
    require(historical_hash == DART_SIGNED_BEFORE,
            f"Dart runtime historical boundary mismatch: {source}")
    activation = git("show", f"{DART_SIGNED_ACTIVATION}:{source}")
    require(digest(activation) == DART_SIGNED_BEFORE,
            f"Dart runtime activation boundary mismatch: {source}")
    require(digest(contents) == DART_SIGNED_AFTER,
            f"unreviewed Dart runtime drift: {source}")
    return {"path": source, "historical": historical_hash,
            "activation_commit": DART_SIGNED_ACTIVATION,
            "current": digest(contents), "owner": DART_SIGNED_OWNER,
            "scope": "exact whole Dart signed-selector source image; historical runtime results unchanged; fresh Dart compatibility is separately retained"}


def verify_rust_numeric_evolution(source, contents, historical_hash, read=None):
    require(source in RUST_NUMERIC_IMAGES, f"unapproved Rust numeric source: {source}")
    historical, activation, accepted = RUST_NUMERIC_IMAGES[source]
    require(historical_hash == historical,
            f"Rust numeric historical boundary mismatch: {source}")
    before = git("show", f"{RUST_NUMERIC_ACTIVATION}:{source}")
    require(digest(before) == activation,
            f"Rust numeric activation boundary mismatch: {source}")
    predecessors = []
    if source == RUST_SIGNED_SOURCE:
        predecessors.append(verify_rust_signed_evolution(source, before, historical_hash))
    require(digest(contents) == accepted,
            f"unreviewed Rust numeric drift: {source}")
    read = read or read_relative
    for support, expected in RUST_NUMERIC_SUPPORT.items():
        require(digest(read(support)) == expected,
                f"unreviewed Rust numeric support drift: {support}")
    return {"path": source, "historical": historical_hash,
            "activation_commit": RUST_NUMERIC_ACTIVATION, "activation": activation,
            "current": digest(contents), "owner": RUST_NUMERIC_OWNER,
            "predecessors": predecessors,
            "support_sources": dict(RUST_NUMERIC_SUPPORT),
            "scope": "exact numeric source image; original historical and signed-selector results unchanged; fresh runtime/readiness compatibility is separately retained"}


def phase0_value_fixture_reader(read, images, expected_table=PHASE0_VALUE_SHA256):
    """Invert exactly twenty value-oracle assertions before all prior stages."""
    raw = read(PHASE0_VALUE_TABLE)
    require(digest(raw) == expected_table, 'unreviewed Phase0 value table')
    require(len(raw) <= 32768, 'Phase0 value table bound')
    data = _IMAGE_MODULE.strict_json(gzip.decompress(raw))
    require(isinstance(data, dict) and set(data) == {
        'schema_version', 'owner', 'path', 'activation_commit',
        'before_sha256', 'after_sha256', 'hunks'}, 'Phase0 value table schema')
    require(type(data['schema_version']) is int and data['schema_version'] == 1,
            'Phase0 value table version')
    require(data['owner'] == PHASE0_VALUE_OWNER and data['path'] == PHASE0_FIXTURE,
            'Phase0 value owner or path')
    require(data['activation_commit'] == PHASE0_VALUE_ACTIVATION and
            data['before_sha256'] == PHASE0_VALUE_BEFORE, 'Phase0 value committed boundary')
    committed = images.image(data['activation_commit'], PHASE0_FIXTURE, data['before_sha256'])
    actual = read(PHASE0_FIXTURE)
    require(digest(actual) == data['after_sha256'], 'unreviewed current Phase0 value fixture')
    hunks = data['hunks']
    require(isinstance(hunks, list) and len(hunks) == 20, 'Phase0 value hunk population')
    restored = actual
    for hunk in hunks:
        require(isinstance(hunk, dict) and set(hunk) == {'before', 'after'} and
                all(isinstance(hunk[k], str) and hunk[k] for k in hunk) and
                hunk['before'] != hunk['after'], 'Phase0 value hunk schema')
        old, new = hunk['before'].encode(), hunk['after'].encode()
        require(restored.count(new) == 1 and committed.count(old) == 1,
                'Phase0 value hunk anchor')
        restored = restored.replace(new, old, 1)
    require(restored == committed, 'Phase0 value inverse mismatch')
    def prior_stage(name):
        return restored if name == PHASE0_FIXTURE else read(name)
    return prior_stage, dict(owner=PHASE0_VALUE_OWNER, path=PHASE0_FIXTURE,
        activation_commit=data['activation_commit'], preserved_committed_sha256=digest(committed),
        actual_current_sha256=digest(actual), table_sha256=digest(raw), exact_assertion_edits=20,
        scope='Finite value/effect oracle calibration; every prior fixture/image stage remains; no historical runtime result change')


def phase0_fixture_reader(read, images, expected_table=PHASE0_FIXTURE_SHA256):
    prior, value_evolution = phase0_value_fixture_reader(read, images)
    effective, previous = _prior_phase0_fixture_reader(prior, images, expected_table)
    return effective, dict(previous, value_calibration=value_evolution,
        prior_fixture_sha256=previous['actual_current_sha256'],
        actual_current_sha256=value_evolution['actual_current_sha256'],
        source_stage='actual current value fixture; twenty-assertion inverse, then prior six-assertion inverse and committed image admission')


def _prior_phase0_fixture_reader(read, images, expected_table=PHASE0_FIXTURE_SHA256):
    """Restore only the owned six-assertion fixture edit, before image admission.

    The returned view is an explicit committed activation stage. Actual current
    bytes and table are observed first and have separate reported provenance.
    """
    raw = read(PHASE0_FIXTURE_TABLE)
    require(digest(raw) == expected_table, 'unreviewed Phase0 fixture table')
    require(len(raw) <= 32768, 'Phase0 fixture table bound')
    data = _IMAGE_MODULE.strict_json(gzip.decompress(raw))
    require(isinstance(data, dict) and set(data) == {
        'schema_version', 'owner', 'path', 'activation_commit',
        'before_sha256', 'after_sha256', 'hunks'}, 'Phase0 fixture table schema')
    require(type(data['schema_version']) is int and data['schema_version'] == 1,
            'Phase0 fixture table version')
    require(data['owner'] == PHASE0_FIXTURE_OWNER and data['path'] == PHASE0_FIXTURE,
            'Phase0 fixture owner or path')
    row = images.rows[PHASE0_FIXTURE]
    require(data['activation_commit'] == images.data['activation_commit'] and
            data['before_sha256'] == row['current_sha256'], 'Phase0 fixture committed boundary')
    committed = images.image(data['activation_commit'], PHASE0_FIXTURE, data['before_sha256'])
    actual = read(PHASE0_FIXTURE)
    require(digest(actual) == data['after_sha256'], 'unreviewed current Phase0 fixture')
    hunks = data['hunks']
    require(isinstance(hunks, list) and len(hunks) == 6, 'Phase0 fixture hunk population')
    restored = actual
    for hunk in hunks:
        require(isinstance(hunk, dict) and set(hunk) == {'before', 'after'} and
                all(isinstance(hunk[k], str) and hunk[k] for k in hunk) and
                hunk['before'] != hunk['after'], 'Phase0 fixture hunk schema')
        old, new = hunk['before'].encode(), hunk['after'].encode()
        require(restored.count(new) == 1 and committed.count(old) == 1,
                'Phase0 fixture hunk anchor')
        restored = restored.replace(new, old, 1)
    require(restored == committed, 'Phase0 fixture inverse mismatch')
    def committed_stage(name):
        return restored if name == PHASE0_FIXTURE else read(name)
    return committed_stage, dict(owner=PHASE0_FIXTURE_OWNER, path=PHASE0_FIXTURE,
        activation_commit=data['activation_commit'], preserved_committed_sha256=digest(committed),
        actual_current_sha256=digest(actual), table_sha256=digest(raw), exact_assertion_edits=6,
        source_stage='actual current fixture; exact inverse precedes preserved committed image admission',
        scope='Fixture calibration only; historical runtime results unchanged; no fresh objective admission')


def falsify_phase0_fixture(images):
    read, _ = phase0_value_fixture_reader(read_relative, images)
    raw = read(PHASE0_FIXTURE_TABLE)
    data = _IMAGE_MODULE.strict_json(gzip.decompress(raw))
    rejected = []
    def reject(label, reader, expected, table_sha=PHASE0_FIXTURE_SHA256):
        try:
            _prior_phase0_fixture_reader(reader, images, table_sha)
        except ValueError as error:
            require(str(error) == expected, 'unrelated Phase0 fixture rejection: ' + label)
            rejected.append(label)
        else:
            raise ValueError('Phase0 fixture corruption admitted: ' + label)
    for label, value in (('source-appended', read(PHASE0_FIXTURE) + b'# unreviewed\n'),
                         ('source-missing', b''),
                         ('prior-committed-stage', images.image(data['activation_commit'],
                            PHASE0_FIXTURE, data['before_sha256']))):
        reject(label, lambda name: value if name == PHASE0_FIXTURE else read(name),
               'unreviewed current Phase0 fixture')
    reject('table-bytes', lambda name: raw + b' ' if name == PHASE0_FIXTURE_TABLE else read(name),
           'unreviewed Phase0 fixture table')
    for label, field, value, expected in (
            ('owner', 'owner', 'TYPE-REFERENCE-BOOK.1.2.20.1.11', 'Phase0 fixture owner or path'),
            ('path', 'path', '../outside', 'Phase0 fixture owner or path'),
            ('revision', 'activation_commit', '0' * 40, 'Phase0 fixture committed boundary'),
            ('before-hash', 'before_sha256', '0' * 64, 'Phase0 fixture committed boundary'),
            ('after-hash', 'after_sha256', '0' * 64, 'unreviewed current Phase0 fixture'),
            ('hunk-omission', 'hunks', data['hunks'][:-1], 'Phase0 fixture hunk population')):
        changed = dict(data)
        changed[field] = value
        candidate = gzip.compress(json.dumps(changed, sort_keys=True).encode(), mtime=0)
        reject(label, lambda name: candidate if name == PHASE0_FIXTURE_TABLE else read(name),
               expected, digest(candidate))
    changed = json.loads(json.dumps(data))
    changed['hunks'][0]['before'] += '# unreviewed'
    candidate = gzip.compress(json.dumps(changed, sort_keys=True).encode(), mtime=0)
    reject('hunk-rebinding', lambda name: candidate if name == PHASE0_FIXTURE_TABLE else read(name),
           'Phase0 fixture hunk anchor', digest(candidate))
    return rejected


def falsify_phase0_value_fixture(images):
    raw = read_relative(PHASE0_VALUE_TABLE)
    data = _IMAGE_MODULE.strict_json(gzip.decompress(raw))
    rejected = []
    def reject(label, reader, expected, table_sha=PHASE0_VALUE_SHA256):
        try:
            phase0_value_fixture_reader(reader, images, table_sha)
        except ValueError as error:
            require(str(error) == expected, 'unrelated Phase0 value rejection: ' + label)
            rejected.append(label)
        else:
            raise ValueError('Phase0 value corruption admitted: ' + label)
    for label, value in (('source-appended', read_relative(PHASE0_FIXTURE) + b'# unreviewed\n'),
                         ('source-missing', b''),
                         ('prior-committed-stage', images.image(PHASE0_VALUE_ACTIVATION,
                            PHASE0_FIXTURE, PHASE0_VALUE_BEFORE))):
        reject(label, lambda name: value if name == PHASE0_FIXTURE else read_relative(name),
               'unreviewed current Phase0 value fixture')
    reject('table-bytes', lambda name: raw + b' ' if name == PHASE0_VALUE_TABLE else read_relative(name),
           'unreviewed Phase0 value table')
    for label, field, value, expected in (
            ('owner', 'owner', PHASE0_FIXTURE_OWNER, 'Phase0 value owner or path'),
            ('path', 'path', '../outside', 'Phase0 value owner or path'),
            ('revision', 'activation_commit', '0' * 40, 'Phase0 value committed boundary'),
            ('before-hash', 'before_sha256', '0' * 64, 'Phase0 value committed boundary'),
            ('after-hash', 'after_sha256', '0' * 64, 'unreviewed current Phase0 value fixture'),
            ('hunk-omission', 'hunks', data['hunks'][:-1], 'Phase0 value hunk population')):
        changed = dict(data); changed[field] = value
        candidate = gzip.compress(json.dumps(changed, sort_keys=True).encode(), mtime=0)
        reject(label, lambda name: candidate if name == PHASE0_VALUE_TABLE else read_relative(name),
               expected, digest(candidate))
    for label, change in (('hunk-rebinding', lambda rows: rows[0].update(before=rows[0]['before'] + '# unreviewed')),
                          ('hunk-duplicate', lambda rows: rows.__setitem__(1, dict(rows[0])))):
        changed = json.loads(json.dumps(data)); change(changed['hunks'])
        candidate = gzip.compress(json.dumps(changed, sort_keys=True).encode(), mtime=0)
        reject(label, lambda name: candidate if name == PHASE0_VALUE_TABLE else read_relative(name),
               'Phase0 value hunk anchor', digest(candidate))
    return rejected


def audit_evidence(read=read_relative):
    checkpoints, sources, logs, milestones = {}, {}, {}, {}
    references = 0

    def checkpoint(path, expected=None):
        contents = read(path)
        if expected is not None:
            require(digest(contents) == expected, f"checkpoint digest mismatch: {path}")
        commit = producing_commit(path)
        require(git("show", f"{commit}:{path}") == contents,
                f"checkpoint changed since production: {path}")
        record = json.loads(contents)
        require(record["owner"] + "-verification.json" == Path(path).name,
                f"checkpoint owner mismatch: {path}")
        checkpoints[path] = {"sha256": digest(contents), "producing_commit": commit}
        return record, commit

    for suffix in MILESTONES:
        path = f"docs/checkpoints/{PREFIX}{suffix}-verification.json"
        record, milestone_commit = checkpoint(path)
        milestones[suffix] = record
        if "audit" in record:
            audit = record["audit"]
            children = [(p, row["sha256"]) for p, row in audit["checkpoints"].items()]
            comparisons = []
            for child_path, expected in children:
                child, child_commit = checkpoint(child_path, expected)
                for source, source_hash in child["source_hashes"].items():
                    comparisons.append((source, source_hash, child_commit))
            current_hashes = audit["current_source_hashes"]
            log_hashes = audit["log_hashes"]
        else:
            for row in record["checkpoint_hashes"]:
                checkpoint(row["path"], row["sha256"])
            comparisons = [(row["path"], row["recorded"],
                            checkpoints[row["checkpoint"]]["producing_commit"])
                           for row in record["source_hash_comparisons"]]
            current_hashes = {row["path"]: row["current"]
                              for row in record["source_hash_comparisons"]}
            log_hashes = {row["path"]: row.get("sha256", row.get("recorded"))
                          for row in record["log_hashes"]}
        for source, expected, commit in comparisons:
            require(digest(git("show", f"{commit}:{source}")) == expected,
                    f"historical source mismatch: {source} at {commit}")
            references += 1
        for source, expected in current_hashes.items():
            require(digest(git("show", f"{milestone_commit}:{source}")) == expected,
                    f"milestone source mismatch: {source}")
            sources[source] = {"sha256": expected, "milestone": suffix}
        for log, expected in log_hashes.items():
            require(digest(read(log)) == expected, f"retained log mismatch: {log}")
            if log in logs:
                require(logs[log] == expected, f"conflicting log digest: {log}")
            logs[log] = expected

    images = current_image_admissions(read)
    fixture_read, fixture_evolution = phase0_fixture_reader(read, images)
    source_image_evolutions = images.verify(sources, fixture_read)
    for evolution in source_image_evolutions:
        if evolution['path'] == PHASE0_FIXTURE:
            evolution['source_stage'] = 'preserved committed activation image before owner21 fixture calibration'
    documentation_updates, governance_updates, runtime_source_updates = [], [], []
    for source, row in sources.items():
        observed = fixture_read(source)
        admitted = images.predecessor(source, observed)
        current = digest(admitted)
        if current != row["sha256"]:
            if source == DART_SIGNED_SOURCE:
                runtime_source_updates.append(verify_dart_signed_evolution(
                    source, admitted, row["sha256"]))
                continue
            if source in RUST_NUMERIC_IMAGES:
                runtime_source_updates.append(verify_rust_numeric_evolution(
                    source, admitted, row["sha256"], read=read))
                continue
            if source == RUST_SIGNED_SOURCE:
                runtime_source_updates.append(verify_rust_signed_evolution(
                    source, admitted, row["sha256"]))
                continue
            if source == "tools/run_ci_local.sh":
                governance_updates.append(verify_governance_evolution(
                    source, admitted, row["sha256"]))
                continue
            if source == "tools/test_perl_project_data_storage.sh":
                governance_updates.append(verify_perl_storage_evolution(
                    source, admitted, row["sha256"], read=read))
                continue
            if source == "t/phase0_regression.t":
                governance_updates.append(verify_signature_regression_evolution(
                    source, admitted, row["sha256"]))
                continue
            if source == "perl/LinkedSpec/ActionIR/Contracts.pm":
                governance_updates.append(verify_boundary_contract_evolution(
                    source, admitted, row["sha256"]))
                continue
            if source == "tools/check_public_aggregate_selector_surface.py":
                governance_updates.append(verify_selector_governance_evolution(
                    source, admitted, row["sha256"]))
                continue
            require(source.startswith("docs/") and source.endswith(".md"),
                    f"current executable evidence drift: {source}")
            documentation_updates.append({"path": source, "historical": row["sha256"],
                                          "current": current, "milestone": row["milestone"]})

    for update in governance_updates + runtime_source_updates:
        if update['path'] in images.rows:
            update['source_stage'] = 'preserved admitted predecessor; current image reported separately'

    # Read the original independent oracle, rather than deriving expected case
    # counts or coordinates from a runtime checker or this summary's prose.
    corpora = {}
    for stem in ("nested-tree", "context-names", "lossless-segments", "lossless-child"):
        path = f"tests/language-readiness/{stem}/cases.json"
        cases = json.loads(read(path))
        accepts, rejects = cases["accept"], cases.get("reject", [])
        names = [row if isinstance(row, str) else row.get("id", row["input"])
                 for row in accepts + rejects]
        require(len(names) == len(set(names)), f"duplicate authored case: {stem}")
        spans = 0

        def walk(value, text):
            nonlocal spans
            if isinstance(value, list):
                for child in value:
                    walk(child, text)
            elif isinstance(value, dict):
                if "span" in value:
                    span = value["span"]
                    first, last = span if isinstance(span, list) else (span["start"], span["end"])
                    require(type(first) is int and type(last) is int and
                            0 <= first <= last <= len(text), f"invalid scalar span: {stem}")
                    if "text" in value:
                        require(text[first:last] == value["text"], f"wrong scalar slice: {stem}")
                    spans += 1
                for key, child in value.items():
                    if key != "span":
                        walk(child, text)

        for case in accepts:
            walk(case["expected"], case["input"])
            if stem == "lossless-segments":
                cursor = 0
                for segment in case["expected"]:
                    span = segment["span"]
                    first, last = span if isinstance(span, list) else (span["start"], span["end"])
                    require(first == cursor, "lossless segments are not adjacent")
                    cursor = last
                require(cursor == len(case["input"]), "lossless segments omit input")
        corpora[stem] = {"accept": len(accepts), "reject": len(rejects),
                         "authored_spans": spans, "case_names": names,
                         "sha256": digest(read(path))}

    matrices = {}
    for suffix, key in (("1.2.3", "routes"), ("2.7", "typed_routes"), ("3.5", "carrier_pairs")):
        rows = {("puc" if name == "puc_lua" else name): row
                for name, row in milestones[suffix][key].items()}
        require(set(rows) == set(RUNTIMES), f"runtime membership mismatch: {suffix}")
        for row in rows.values():
            routes = row.get("routes", row.get("matched"))
            require(0 < row["retained"] <= routes, f"invalid retained routes: {suffix}")
            if suffix != "3.5":
                rejected = corpora["nested-tree" if suffix == "1.2.3" else "context-names"]["reject"]
                require(row["recoveries"] == row["retained"] * 2 * rejected,
                        f"recovery inflation: {suffix}")
            else:
                require(row["per_call"] == routes - row["retained"], "per-call pair mismatch")
        matrices[suffix] = rows

    return {"checkpoints": checkpoints, "historical_source_references": references,
            "latest_source_inputs": sources, "retained_log_hashes": logs,
            "documentation_updates": documentation_updates,
            "governance_updates": governance_updates, "corpora": corpora,
            "runtime_source_updates": runtime_source_updates,
            "source_image_evolutions": source_image_evolutions,
            "fixture_source_evolutions": [fixture_evolution],
            "matrices": matrices,
            "limits": "Evidence integrity and independent scalar slicing; runtime execution is historical per-leaf proof. No new capability or objective promotion."}


def falsify(report):
    targets = (next(iter(report["checkpoints"])), next(iter(report["latest_source_inputs"])),
               next(iter(report["retained_log_hashes"])),
               "tests/language-readiness/context-names/cases.json")
    for target in targets:
        def corrupt(path):
            data = read_relative(path)
            return data + b" " if path == target else data
        try:
            audit_evidence(corrupt)
        except ValueError:
            continue
        raise ValueError(f"corruption control did not reject: {target}")
    for target in ("../outside", "/outside"):
        try:
            read_relative(target)
        except ValueError:
            continue
        raise ValueError(f"outside-path control did not reject: {target}")
    images = current_image_admissions(read_relative)
    fixture_read, _ = phase0_fixture_reader(read_relative, images)
    images.verify(report['latest_source_inputs'], fixture_read)
    def evolution_source(path):
        return images.read_predecessor(path, fixture_read)
    governance_controls = 0
    controls_by_source = {}
    storage_controls = []
    storage_row = next(row for row in report['governance_updates']
                       if row['path'] == 'tools/test_perl_project_data_storage.sh')
    storage_source = storage_row['path']
    storage_current = evolution_source(storage_source)
    for label, candidate in (
            ('source-appended', storage_current + b'# unreviewed\n'),
            ('source-missing', b''), ('source-duplicated', storage_current * 2),
            ('prior-stage', restore_perl_storage_inventory(storage_source, storage_current))):
        try:
            verify_perl_storage_evolution(storage_source, candidate, storage_row['historical'])
        except ValueError as error:
            require(str(error) == 'unreviewed Perl storage inventory source',
                    'unrelated storage source rejection')
            storage_controls.append(label)
        else:
            raise ValueError('storage source corruption control did not reject')
    for name in (STORAGE_INVENTORY_TABLE, 'tools/check_project_storage_inventory.pl',
                 'doctrine/project_data_storage/perl_temporary_owners.json'):
        def corrupt_storage(path):
            raw = read_relative(path)
            return raw + b' ' if path == name else raw
        try:
            verify_perl_storage_evolution(storage_source, storage_current, storage_row['historical'],
                                          read=corrupt_storage)
        except ValueError as error:
            expected = ('unreviewed Perl storage inventory table' if name == STORAGE_INVENTORY_TABLE
                        else 'unreviewed Perl storage inventory support: ' + name)
            require(str(error) == expected, 'unrelated storage input rejection')
            storage_controls.append(name)
        else:
            raise ValueError('storage input corruption control did not reject')
    for row in report["governance_updates"]:
        source = row["path"]
        current = evolution_source(source)
        if source == "tools/run_ci_local.sh":
            altered = (
                current + b"# unreviewed edit\n",
                current.replace(CI_INSERTIONS[0][1], b"", 1),
                current.replace(b"bash tools/run_python_project_data.sh tools/check_scalar_numeric_contract.py\n", b"", 1),
                current.replace(b"require_tracked_file capability_conformance/composed_objective_contract.json\n",
                                b"", 1),
                current.replace(COMPOSED_CI_INSERTIONS[1][1], b"", 1),
                current.replace(COMPOSED_CI_INSERTIONS[1][1],
                                COMPOSED_CI_INSERTIONS[1][1] * 2, 1),
                current.replace(PUSH_CI_INSERTIONS[0][1], b"", 1),
                current.replace(PUSH_CI_INSERTIONS[1][1], b"", 1),
                current.replace(PUSH_CI_INSERTIONS[1][1], PUSH_CI_INSERTIONS[1][1] * 2, 1),
                current.replace(NORMALIZATION_CI_INSERTIONS[0][1], b"", 1),
                current.replace(NORMALIZATION_CI_INSERTIONS[1][1], b"", 1),
                current.replace(NORMALIZATION_CI_INSERTIONS[1][1],
                                NORMALIZATION_CI_INSERTIONS[1][1] * 2, 1),
                current.replace(ARTIFACT_CI_INSERTIONS[0][1], b"", 1),
                current.replace(ARTIFACT_CI_INSERTIONS[1][1], b"", 1),
                current.replace(ARTIFACT_CI_INSERTIONS[1][1],
                                ARTIFACT_CI_INSERTIONS[1][1] * 2, 1),
                current.replace(RAW_READINESS_CI_INSERTIONS[0][1], b"", 1),
                current.replace(RAW_READINESS_CI_INSERTIONS[1][1], b"", 1),
                current.replace(RAW_READINESS_CI_INSERTIONS[2][1], b"", 1),
                current.replace(RAW_READINESS_CI_INSERTIONS[2][1],
                                RAW_READINESS_CI_INSERTIONS[2][1] * 2, 1),
                current.replace(RAW_READINESS_CI_INSERTIONS[2][1],
                                RAW_READINESS_CI_INSERTIONS[2][1].replace(b"PERL5LIB= prove", b"PERL5LIB= true"), 1),
                current.replace(RAW_READINESS_CI_INSERTIONS[0][1],
                                RAW_READINESS_CI_INSERTIONS[0][1].replace(b"metadata.t", b"missing.t"), 1),
                current.replace(b"require_tracked_file t/actionir_nested_block_source_spans.t\n", b"", 1),
                current.replace(b"perl -c -Iperl t/actionir_nested_block_source_spans.t\n", b"", 1),
                current.replace(b" t/actionir_nested_block_source_spans.t t/actionir_raw_dependency_compatibility.t\n",
                                b" t/actionir_raw_dependency_compatibility.t\n", 1),
                current.replace(b"require_tracked_file t/actionir_raw_dependency_compatibility.t\n", b"", 1),
                current.replace(b"perl -c -Iperl t/actionir_raw_dependency_compatibility.t\n", b"", 1),
                current.replace(b" t/actionir_raw_dependency_compatibility.t\n", b"\n", 1),
            )
            altered += tuple(current.replace(insertion, b"", 1)
                             for _, insertion in SCALAR_RECEIVER_COPY_CI_INSERTIONS)
            altered += tuple(current.replace(insertion, insertion * 2, 1)
                             for _, insertion in SCALAR_RECEIVER_COPY_CI_INSERTIONS)
            altered += (
                current.replace(b"prove -Iperl t/actionir_receiver_scalar_copy.t\n",
                                b"true t/actionir_receiver_scalar_copy.t\n", 1),
                current.replace(b"perl -c -Iperl t/actionir_receiver_scalar_copy.t\n",
                                b"perl -c -Iperl t/other_copy.t\n", 1),
                current.replace(b"require_tracked_file t/actionir_receiver_scalar_copy_probe.pl\n", b"", 1),
                current.replace(b"perl -c -Iperl t/actionir_receiver_scalar_copy_probe.pl\n", b"", 1),
            )
            altered += tuple(current.replace(insertion, b"", 1)
                             for _, insertion in KNOWLEDGE_HEADER_GATE_CI_INSERTIONS)
            altered += tuple(current.replace(insertion, insertion * 2, 1)
                             for _, insertion in KNOWLEDGE_HEADER_GATE_CI_INSERTIONS)
            altered += (
                current.replace(b"PERL5LIB= prove t/knowledge_map_header_lists.t\n",
                                b"PERL5LIB= true t/knowledge_map_header_lists.t\n", 1),
                current.replace(b"require_tracked_file t/knowledge_map_header_lists.t\n",
                                b"require_tracked_file t/other_header_lists.t\n", 1),
                current.replace(b"require_tracked_file t/knowledge_map_header_lists.t\n", b"", 1),
            )
            altered += tuple(current.replace(insertion, b"", 1)
                             for _, insertion in PRIVATE_FACTORY_FIXTURE_CI_INSERTIONS)
            altered += tuple(current.replace(insertion, insertion * 2, 1)
                             for _, insertion in PRIVATE_FACTORY_FIXTURE_CI_INSERTIONS)
            block = PRIVATE_FACTORY_FIXTURE_CI_INSERTIONS[0][1]
            for path in PRIVATE_FACTORY_FIXTURE_PATHS:
                line = b" " + path.encode() + b"\n"
                require(block.count(line) == 1, "private fixture path is not unique in its block")
                altered += (current.replace(block, block.replace(line, b"", 1), 1),
                            current.replace(block, block.replace(line, line * 2, 1), 1))
            altered += (
                current.replace(b'PERL5OPT= prove -Iperl "${private_factory_suites[@]}"',
                                b'PERL5OPT= true "${private_factory_suites[@]}"', 1),
                current.replace(b' perl -c -Iperl "$private_factory_input"',
                                b' true "$private_factory_input"', 1),
                current.replace(b' require_tracked_file "$private_factory_input"',
                                b' true "$private_factory_input"', 1),
                current.replace(b" t/actionir_default_object_capture.t\n",
                                b" t/other_private_fixture.t\n", 1),
            )
            altered += tuple(current.replace(insertion, b"", 1)
                             for _, insertion in SIGNED_ARRAY_SELECTOR_CI_INSERTIONS)
            altered += tuple(current.replace(insertion, insertion * 2, 1)
                             for _, insertion in SIGNED_ARRAY_SELECTOR_CI_INSERTIONS)
            altered += (
                current.replace(b"PERL5LIB= prove -Iperl t/signed_array_selector_perl_contract.t\n",
                                b"PERL5LIB= true t/signed_array_selector_perl_contract.t\n", 1),
                current.replace(b"perl -c -Iperl t/signed_array_selector_perl_contract.t\n",
                                b"true t/signed_array_selector_perl_contract.t\n", 1),
                current.replace(b"require_tracked_file t/signed_array_selector_perl_contract.t\n",
                                b"true t/signed_array_selector_perl_contract.t\n", 1),
                current.replace(b"require_tracked_file tests/numeric-codeblocks/signed-array-selectors.json\n",
                                b"require_tracked_file tests/numeric-codeblocks/missing-signed-array-selectors.json\n", 1),
            )
            altered += tuple(current.replace(insertion, b"", 1) for _, insertion in RESTORATION_CI_INSERTIONS)
            altered += tuple(current.replace(insertion, insertion * 2, 1) for _, insertion in RESTORATION_CI_INSERTIONS)
            altered += (current.replace(RESTORATION_CI_INSERTIONS[0][1],
                                        RESTORATION_CI_INSERTIONS[0][1].replace(b'== Darwin', b'== Linux'), 1),)
            altered += tuple(current.replace(insertion, b"", 1) for _, insertion in TASK_EVIDENCE_CI_INSERTIONS)
            altered += tuple(current.replace(insertion, insertion * 2, 1) for _, insertion in TASK_EVIDENCE_CI_INSERTIONS)
            for path in TASK_EVIDENCE_CI_PATHS:
                presence = b'require_tracked_file ' + path.encode() + b'\n'
                execution = b'bash "$REPO_ROOT/tools/run_python_project_data.sh" ' + path.encode() + b'\n'
                require(current.count(presence) == current.count(execution) == 1,
                        'task-evidence selector is not unique')
                altered += (current.replace(presence, b'', 1),
                            current.replace(execution, b'true\n', 1),
                            current.replace(execution, execution.replace(path.encode(), b'tools/unreviewed.py'), 1))
            verify = verify_governance_evolution
            reasons = ("governance registration mismatch:", "unreviewed governance drift:")
        elif source == "tools/test_perl_project_data_storage.sh":
            # Keep every original reason-sensitive falsifier on its actual old
            # 29-owner stage. New source/data denials are independent above.
            current = restore_perl_storage_inventory(source, current)
            altered = (current + b"# unreviewed edit\n",) + tuple(
                current.replace(replacement, historical, 1)
                for historical, replacement in PERL_STORAGE_REPLACEMENTS
            ) + (current.replace(PERL_STORAGE_REPLACEMENTS[2][1],
                                 PERL_STORAGE_REPLACEMENTS[2][1] * 2, 1),
                 current.replace(b" t/knowledge_map_header_lists.t; do\n", b"; do\n", 1),
                 current.replace(b" t/knowledge_map_header_lists.t; do\n",
                                 b" t/other_header_lists.t; do\n", 1),
                 current.replace(b"== 29 ))", b"== 28 ))", 1))
            verify = verify_perl_storage_census_evolution
            reasons = ("Perl storage registration mismatch:", "unreviewed Perl storage drift:")
        elif source == "t/phase0_regression.t":
            count_first_current = current
            current = restore_count_first_regressions(source, current)
            drop_current = current
            current = restore_drop_generated_regressions(source, current)
            numeric_current = current
            current = restore_scalar_numeric_regressions(source, current)
            before = git("show", f"{SIGNATURE_BEFORE}:{source}")
            # Isolate the original signature controls from the new recurrence.
            owned = signature_subtest(current.replace(OCCURRENCE_INSERTION + OCCURRENCE_ANCHOR,
                                                       OCCURRENCE_ANCHOR, 1))
            altered = (
                current.replace(owned, signature_subtest(before), 1),
                current.replace(owned, owned.replace(b"    done_testing();\n",
                                                    b"    plan tests => 8;\n", 1), 1),
                current + b"# unreviewed edit outside the owned subtest\n",
                current.replace(OCCURRENCE_INSERTION, b"", 1),
                current.replace(OCCURRENCE_INSERTION, OCCURRENCE_INSERTION * 2, 1),
                current.replace(OCCURRENCE_INSERTION,
                                OCCURRENCE_INSERTION.replace(b"    plan tests => 2;\n",
                                                             b"    plan tests => 1;\n"), 1),
            )
            table = json.loads(read_relative("docs/checkpoints/" + RAW_READINESS_OWNER + "-compatibility-oracles.json"))
            altered += tuple(current.replace(row["assertions"][0]["after"].encode(),
                                             row["assertions"][0]["before"].encode(), 1)
                             for row in table["subtests"])
            insertion = boundary_recurrence(current)
            altered += (
                current.replace(insertion, b"", 1),
                current.replace(insertion, insertion * 2, 1),
                current.replace(insertion, insertion.replace(b"my @cases", b"my @other_cases", 1), 1),
                current.replace(insertion, insertion.replace(b"is_deeply", b"ok", 1), 1),
                current.replace(insertion, insertion.replace(b'"a,b,c"', b'"a"', 1), 1),
                current.replace(insertion, insertion.replace(b"runtime_ctx_ref =>", b"other_ctx_ref =>", 1), 1),
                current.replace(COMPILER_SCAN_AFTER, COMPILER_SCAN_BEFORE, 1),
                current.replace(COMPILER_SCAN_AFTER, COMPILER_SCAN_AFTER * 2, 1),
                current.replace(COMPILER_SCAN_AFTER, COMPILER_SCAN_AFTER.replace(b"sub {", b"sub { return;"), 1),
                current.replace(COMPILER_SCAN_AFTER, COMPILER_SCAN_AFTER.replace(b"_scan_executable_contract_ir_events", b"_other_scan"), 1),
            )
            inverse_table = json.loads(read_relative(EVALUATED_VALUES_TABLE))
            for fragment_record in inverse_table["hunks"]:
                fragment = fragment_record["after"].encode()
                require(current.count(fragment) == 1,
                        "evaluated-value control registration mismatch: " + source)
                changed = bytes([fragment[0] ^ 1]) + fragment[1:]
                altered += (current.replace(fragment, b"", 1),
                            current.replace(fragment, fragment * 2, 1),
                            current.replace(fragment, changed, 1))
            # Keep every older reason-sensitive control on its original source
            # stage, then exercise each new numeric registration on current bytes.
            for numeric_hunk in scalar_numeric_table(source)["hunks"]:
                fragment = numeric_hunk["after"].encode()
                require(numeric_current.count(fragment) == 1,
                        "numeric control registration mismatch: " + source)
                changed = bytes([fragment[0] ^ 1]) + fragment[1:]
                altered += (numeric_current.replace(fragment, b"", 1),
                            numeric_current.replace(fragment, fragment * 2, 1),
                            numeric_current.replace(fragment, changed, 1))
            # All644 previous controls retain their exact pre-drop source stage.
            # The two complete new subtests get omission/duplication/corruption.
            for drop_hunk in drop_generated_table(source)["hunks"]:
                fragment = drop_hunk["after"].encode()
                require(drop_current.count(fragment) == 1,
                        "drop control registration mismatch: " + source)
                changed = bytes([fragment[0] ^ 1]) + fragment[1:]
                altered += (drop_current.replace(fragment, b"", 1),
                            drop_current.replace(fragment, fragment * 2, 1),
                            drop_current.replace(fragment, changed, 1))
            # Preserve all650 previous falsifiers at their original source stages.
            # Each new complete guard line has independent absence/duplication/change.
            for count_first_hunk in count_first_table(source)["hunks"]:
                fragment = count_first_hunk["after"].encode()
                require(count_first_current.count(fragment) == 1,
                        "count/first control registration mismatch: " + source)
                changed = bytes([fragment[0] ^ 1]) + fragment[1:]
                altered += (count_first_current.replace(fragment, b"", 1),
                            count_first_current.replace(fragment, fragment * 2, 1),
                            count_first_current.replace(fragment, changed, 1))
            verify = verify_signature_regression_evolution
            reasons = ("raw-readiness oracle assertion mismatch:", "occurrence regression registration mismatch:", "unreviewed signature-regression drift:",
                       "unreviewed signature-regression history:", "signature regression marker mismatch:",
                       "boundary recurrence registration mismatch:", "compiler scanner mock registration mismatch:",
                       "evaluated-value regression registration mismatch:",
                       "numeric regression registration mismatch:",
                       "drop regression registration mismatch:",
                       "count/first regression registration mismatch:")
        elif source == "perl/LinkedSpec/ActionIR/Contracts.pm":
            altered = (
                current + b"# unreviewed boundary contract edit\n",
                current.replace(BOUNDARY_IMPORT, b"", 1),
                current.replace(BOUNDARY_IMPORT, BOUNDARY_IMPORT * 2, 1),
                current.replace(BOUNDARY_LOOP_AFTER, BOUNDARY_LOOP_BEFORE, 1),
                current.replace(BOUNDARY_LOOP_AFTER, BOUNDARY_LOOP_AFTER * 2, 1),
                current.replace(BOUNDARY_LOOP_AFTER,
                                BOUNDARY_LOOP_AFTER.replace(b"_decode_recognized_labels", b"_other_decoder"), 1),
            )
            altered += (
                current.replace(b"return _bind_emission_dependency($cb)", b"return $cb", 1),
                current.replace(b"return _register_native_contracts([", b"return [", 1),
                current.replace(b"sub _register_native_contracts {", b"sub _other_native_contracts {", 1),
                current.replace(b"SourceEmissions::_invoke_emission_dependency($callback", b"SourceEmissions::_invoke_other_dependency($callback", 1),
            )
            verify = verify_boundary_contract_evolution
            reasons = ("boundary contract registration mismatch:", "unreviewed boundary contract drift:",
                       "unreviewed Contracts factory capture drift:")
        elif source == "tools/check_public_aggregate_selector_surface.py":
            line = b"EXPECTED_CLASSIFIED_REFERENCE_COUNT = 40\n"
            altered = (
                current + b"# unreviewed edit\n",
                current.replace(line, b"", 1),
                current.replace(line, line * 2, 1),
                current.replace(line, b"EXPECTED_CLASSIFIED_REFERENCE_COUNT = 39\n", 1),
                current.replace(b"reference_count = check_exact_references(paths)", b"reference_count = 0", 1),
                current.replace(b"EXPECTED_PUBLIC_FILE_COUNT = 70", b"EXPECTED_PUBLIC_FILE_COUNT = 69", 1),
            )
            altered += tuple(current.replace(fragment, b"", 1)
                             for _, fragment in SELECTOR_LITERAL_PATTERN_UPDATES)
            altered += tuple(current.replace(fragment, fragment * 2, 1)
                             for _, fragment in SELECTOR_LITERAL_PATTERN_UPDATES)
            altered += tuple(current.replace(fragment, fragment.replace(b"false", b"False", 1), 1)
                             for _, fragment in SELECTOR_LITERAL_PATTERN_UPDATES)
            verify = verify_selector_governance_evolution
            reasons = ("selector governance registration mismatch:", "unreviewed selector governance drift:")
        else:
            raise ValueError(f"unapproved governance control source: {source}")
        require(all(candidate != current for candidate in altered),
                f"governance controls must change actual bytes: {source}")
        controls_by_source[source] = 0
        for contents in altered:
            try:
                verify(source, contents, row["historical"])
            except ValueError as error:
                require(str(error).startswith(reasons),
                        "unrelated error substituted for governance rejection")
                governance_controls += 1
                controls_by_source[source] += 1
            else:
                raise ValueError("governance corruption control did not reject")
    runtime_controls = {}
    for row in report.get("runtime_source_updates", []):
        source = row["path"]
        current = evolution_source(source)
        verifier = {RUST_NUMERIC_OWNER: verify_rust_numeric_evolution,
                    RUST_SIGNED_OWNER: verify_rust_signed_evolution,
                    DART_SIGNED_OWNER: verify_dart_signed_evolution}[row["owner"]]
        if row["owner"] == DART_SIGNED_OWNER:
            altered = (
                current + b"\n// unreviewed Dart runtime edit\n",
                current.replace(b"collection.length + index", b"collection.length - index", 1),
                current.replace(b"Object get pathValue => key ?? index!;",
                                b"Object get pathValue => key ?? 0;", 1),
            )
        elif source == 'rust/Cargo.toml':
            altered = (
                current + b"\n# unreviewed numeric edit\n",
                current.replace(b'"float_roundtrip"', b'"arbitrary_precision"', 1),
                current.replace(b'{ version = "1", features = ["float_roundtrip"] }', b'"1"', 1),
            )
        else:
            altered = (
                current + b"\n// unreviewed runtime edit\n",
                current.replace(b"fn negative_array_index(", b"fn unreviewed_negative_array_index(", 1),
                current.replace(b"linkedspec_core::numeric::nonnegative_integer_to_usize(*number)",
                                b"Some(*number as usize)", 1) if row["owner"] == RUST_NUMERIC_OWNER
                    else current.replace(b"resolved_index: items.len() as i128 + index,",
                                         b"resolved_index: (items.len() as f64 + *index as f64) as i128,", 1),
            )
        require(all(candidate != current for candidate in altered),
                "runtime controls must change actual bytes")
        for candidate in altered:
            try:
                verifier(source, candidate, row["historical"])
            except ValueError as error:
                language = 'Dart' if row["owner"] == DART_SIGNED_OWNER else 'Rust'
                expected = 'numeric' if row["owner"] == RUST_NUMERIC_OWNER else 'runtime'
                require(str(error) == f"unreviewed {language} {expected} drift: {source}",
                        "unrelated error substituted for runtime rejection")
            else:
                raise ValueError("runtime corruption control did not reject")
        runtime_controls[source] = len(altered)
    support_controls = []
    numeric = next((row for row in report.get("runtime_source_updates", [])
                    if row["owner"] == RUST_NUMERIC_OWNER), None)
    if numeric:
        for support in RUST_NUMERIC_SUPPORT:
            contents = evolution_source(support)
            changed = contents + b"\n// unreviewed numeric support edit\n"
            def support_reader(path):
                return changed if path == support else evolution_source(path)
            try:
                verify_rust_numeric_evolution(numeric["path"], evolution_source(numeric["path"]),
                                              numeric["historical"], read=support_reader)
            except ValueError as error:
                require(str(error) == f"unreviewed Rust numeric support drift: {support}",
                        "unrelated error substituted for support rejection")
            else:
                raise ValueError("numeric support corruption control did not reject")
            support_controls.append(support)
    return {"corrupted_inputs_rejected": list(targets), "outside_paths_rejected": 2,
            "governance_mutations_rejected": governance_controls,
            "governance_mutations_by_source": controls_by_source,
            "runtime_source_mutations_rejected": sum(runtime_controls.values()),
            "runtime_source_mutations_by_source": runtime_controls,
            "numeric_support_mutations_rejected": support_controls,
            "storage_inventory_mutations_rejected": storage_controls,
            "current_image_mutations_rejected": images.falsify(report["latest_source_inputs"], fixture_read),
            "phase0_fixture_mutations_rejected": falsify_phase0_fixture(images),
            "phase0_value_fixture_mutations_rejected": falsify_phase0_value_fixture(images)}


def verify_summary(report, text):
    labels = dict(zip(RUNTIMES, ("Perl", "Rust", "Dart", "Julia", "PUC Lua", "LuaJIT")))
    for runtime in RUNTIMES:
        nesting = report["matrices"]["1.2.3"][runtime]
        context = report["matrices"]["2.7"][runtime]
        child = report["matrices"]["3.5"][runtime]
        require(nesting["routes"] == context["routes"] and
                nesting["retained"] == context["retained"], "combined route table loses a distinction")
        row = (f"| {labels[runtime]} | {nesting['routes']} | {nesting['retained']} | "
               f"{nesting['recoveries']} / {context['recoveries']} | {child['matched']} | "
               f"{child['retained']} | {child['per_call']} |")
        require(text.splitlines().count(row) == 1, f"summary route mismatch: {runtime}")


if __name__ == "__main__":
    result = audit_evidence()
    result["controls"] = falsify(result)
    summary = read_relative("docs/language-readiness/objective-reconciliation.md").decode()
    verify_summary(result, summary)
    try:
        verify_summary(result, summary.replace("| 28 / 68 |", "| 29 / 68 |", 1))
    except ValueError:
        result["controls"]["summary_recovery_inflation_rejected"] = True
    else:
        raise ValueError("summary recovery inflation control did not reject")
    print(json.dumps(result, indent=2, sort_keys=True))
