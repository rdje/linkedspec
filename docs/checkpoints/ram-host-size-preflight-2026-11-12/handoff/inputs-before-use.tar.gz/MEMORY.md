# MEMORY

- activation_commit: `b370de8d31e3f38da6abf8ed4702a523aa3d6d97` — clean resource14 activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.32` — rooting narrative headroom; all10/post-pointer/brief0/clean verified.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.14`; task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: full PNT, no fixed batch count; no pause requested.
- session_health: Long context; preserve qualified producers/results and use targeted recovery before larger CI changes.
- next_action: Retain original RAM producers/OS channels and distinguishing denial RED, then repair both preflights with one validated snapshot, focused controls and exact staged canonical admission. Current discovery4.1/raw-error4.28 remain required before push.
- in_flight_uncommitted: resource14 activation; implementation/proof/docs and canonical receipt remain to finish. Headroom32 and its failed terse attempt are committed; never replay their writers.
- evidence: docs/checkpoints/ram-host-size-preflight-2026-11-12/PLAN.md; original RAM observations remain dated in the two prerequisite cards. Headroom32 historical recovery remains under its original checkpoint.
- publication: Director1,500,000,000-byte trigger overrides cadence; advisory preparation1,400,000,000. Fresh b370 measurement is retained under .linkedspec-data/push-monitor/20261112T194221.101324Z; preserve metadata/source/channels here before publishing measured values. Raw pack stays ignored/protected. No remote freshness/wire/future-size guarantee. Exact clean-HEAD canonical/current discovery4.1/raw-error4.28/normal hooks/fresh remote precede push.
- continuity: All five bounded concat80 backends have focused outcomes; full23.4/native4.2/SESSION5/source/context/historical4.24/launcher4.22/SESSION7/literal/excluded/shadowing32/declared5.4/formatter remain owned. Lua80.5 historical default is review_qualified.py; original standalone reader expects retired plain oracle.
- verification_policy: This infrastructure leaf is canonical. Same-volume/serial intensive jobs/shared24GiB/current90-percent trend policy; only this repository writable, submodules black boxes. Latest cleanup2026-11-12T15:32:21.895461+00:00 remains current. No native PID/PGID inference from denied pgrep.
