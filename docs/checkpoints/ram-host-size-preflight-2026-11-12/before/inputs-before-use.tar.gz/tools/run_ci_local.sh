#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
REPO_ROOT=$(cd -- "$SCRIPT_DIR/.." && pwd)
source "$REPO_ROOT/tools/project_data_env.sh"
linkedspec_project_data_enter_run "$REPO_ROOT/tools/run_ci_local.sh" "$@"

cd "$REPO_ROOT"

log() {
 printf '[ci] %s\n' "$*"
}

fail() {
 printf '[ci] ERROR: %s\n' "$*" >&2
 exit 1
}

CANONICAL_GATE_FINGERPRINT=$("$REPO_ROOT/tools/verification_receipt.sh" fingerprint) ||
 fail "canonical candidate must be fully staged with no unstaged or untracked inputs"
export LINKEDSPEC_CANONICAL_GATE_IN_PROGRESS=1

require_command() {
 command -v "$1" >/dev/null 2>&1 || fail "required command not found: $1"
}

require_tracked_file() {
 local path="$1"
 [[ -f "$path" ]] || fail "required file missing: $path"
 git ls-files --error-unmatch -- "$path" >/dev/null 2>&1 || fail "required file is not git-tracked: $path"
}

require_tracked_tree() {
 local path="$1"
 [[ -d "$path" ]] || fail "required directory missing: $path"
 if ! git ls-files -- "$path" | grep -q .; then
  fail "required directory has no git-tracked files: $path"
 fi
}

check_no_untracked_ci_inputs() {
 local status_line
 local found=0

 status_line=$(git status --short --untracked-files=all -- tools/check_mutation_public_surface.py)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 while IFS= read -r status_line; do
  [[ "$status_line" == '?? '* ]] || continue
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 done < <(git status --short --untracked-files=all -- .github/workflows bin/linkedspec capability_conformance cli_conformance unicode_case lua/src/linkedspec/semantic_index.lua lua/src/linkedspec/semantic_compilation_outcome.lua lua/src/linkedspec/semantic_static_projection.lua lua/src/linkedspec/semantic_query.lua lua/test/project_data_storage_test.lua lua/test/semantic_index_source_foundation_test.lua lua/test/semantic_index_compilation_foundation_test.lua lua/test/semantic_index_static_graph_test.lua lua/test/semantic_index_static_remaining_test.lua lua/test/semantic_index_call_core_test.lua lua/test/semantic_index_call_staged_generated_test.lua lua/test/semantic_index_query_kernel_test.lua tools/build_lua_native.sh tools/check_callable_codeblock_contract.py tools/check_callable_codeblock_five_backend.sh tools/check_callable_signature_contract.py tools/check_complete_named_mark_contract.py tools/check_diagnostic_output_contract.py tools/check_diagnostic_output_five_backend.sh tools/check_duplicate_regex_slot_identity_contract.py tools/check_duplicate_regex_slot_identity_five_backend.sh tools/check_logical_helper_contract.py tools/check_logical_helper_five_backend.sh tools/check_mcp_implementation_admission.py tools/check_mcp_semantic_transport_contract.py tools/check_mutation_six_runtime.sh tools/check_progressive_span_dispatch_contract.py tools/check_recognition_transaction_contract.py tools/check_staged_ast_enrichment_contract.py tools/materialize_mcp_semantic_transport_contract.py tools/mcp_contract_binding.py tools/generate_perl_mcp_contract.py tools/generate_rust_mcp_contract.py tools/generate_julia_mcp_contract.py tools/check_punctuation_light_zero_arg_contract.py tools/check_punctuation_light_five_backend.sh tools/check_repeated_action_result_contract.py tools/check_repeated_action_result_five_backend.sh tools/check_root_rule_selection_contract.py tools/check_root_rule_selection_five_backend.sh tools/check_semantic_introspection_contract.py tools/check_uniform_binding_contract.py tools/check_uniform_binding_mutation_result_surface.py tools/check_capability_conformance.pl tools/check_generated_source_contract.pl tools/check_language_capability_coverage.pl tools/check_native_spec_resolution_contract.pl tools/check_scalar_numeric_contract.py tools/check_unicode_case_contract.py tools/check_unicode_rule_label_contract.py tools/run_ci_local.sh tools/run_rust_local.sh tools/run_dart_local.sh tools/run_dart_project_data.sh tools/run_julia_local.sh tools/run_lua_project_data.sh tools/run_primary_cli_matrix.sh tools/run_python_project_data.sh tools/run_cli_conformance.pl tools/test_lua_project_data_storage.sh tools/test_perl_project_data_storage.sh tools/test_project_data_process_locality.sh tools/test_repo_root_process_portability.sh tools/test_tool_project_data_storage.sh rust/linkedspec-runtime/src/mcp_contract.rs rust/linkedspec-runtime/src/mcp_contract_runtime.rs rust/linkedspec-runtime/src/mcp_server.rs rust/linkedspec-runtime/src/mcp_wire.rs rust/linkedspec-runtime/tests/mcp_server_rust_dispatch.rs rust/linkedspec-runtime/tests/mcp_server_rust_stdio.rs rust/linkedspec-runtime/tests/mcp_server_rust_admission.rs rust/linkedspec-runtime/tests/repository_root_relocation.rs dart/lib/src/mcp/mcp_wire.dart dart/test/mcp_server_dart_stdio_test.dart dart/test/mcp_server_dart_admission_test.dart specs conf tablescript ebnf perl t)

 while IFS= read -r status_line; do
  [[ "$status_line" == '?? '* ]] || continue
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 done < <(git status --short --untracked-files=all -- \
  tools/generate_dart_mcp_contract.py \
  dart/lib/src/mcp/mcp_contract.dart \
  dart/lib/src/mcp/mcp_contract_runtime.dart \
  dart/lib/src/mcp/mcp_server.dart \
  dart/lib/src/mcp/mcp_wire.dart \
  dart/test/mcp_contract_dart_binding_test.dart \
  dart/test/mcp_server_dart_dispatch_test.dart \
  dart/test/mcp_server_dart_stdio_test.dart \
  dart/test/mcp_server_dart_admission_test.dart \
  julia/src/mcp/McpContract.jl \
  julia/src/mcp/McpContractRuntime.jl \
  julia/src/mcp/McpServer.jl \
  julia/src/mcp/McpWire.jl \
  julia/test/mcp_contract_julia_binding_test.jl \
  julia/test/mcp_server_julia_dispatch_test.jl \
  julia/test/mcp_server_julia_stdio_test.jl \
  julia/test/mcp_server_julia_admission_test.jl \
  tools/generate_lua_mcp_contract.py \
  lua/native/mcp_system.c \
  lua/src/linkedspec/mcp_contract.lua \
  lua/src/linkedspec/mcp_contract_runtime.lua \
  lua/src/linkedspec/mcp_server.lua \
  lua/src/linkedspec/mcp_wire.lua \
  lua/test/mcp_contract_lua_binding_test.lua \
  lua/test/mcp_server_lua_dispatch_test.lua \
  lua/test/mcp_server_lua_stdio_test.lua \
  lua/test/mcp_server_lua_admission_test.lua)

 status_line=$(git status --short --untracked-files=all -- lua/test/semantic_introspection_lua_admission_test.lua)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_semantic_introspection_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_mcp_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_typed_source_location_contract.py)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_typed_source_location_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_recursive_observation_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_progressive_span_dispatch_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_staged_ast_enrichment_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_typed_authoring_model_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_inter_match_gap_capture_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_typed_gap_composition_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 status_line=$(git status --short --untracked-files=all -- tools/check_recognition_transaction_six_runtime.sh)
 if [[ "$status_line" == '?? '* ]]; then
  printf '[ci] ERROR: untracked CI input: %s\n' "${status_line#?? }" >&2
  found=1
 fi

 (( found == 0 )) || exit 1
}

audit_no_machine_specific_absolute_paths() {
 local path
 local matches
 local found=0

 matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\' tools/check_mutation_public_surface.py || true)
 if [[ -n "$matches" ]]; then
  printf '[ci] ERROR: machine-specific absolute path(s) in tools/check_mutation_public_surface.py:\n%s\n' "$matches" >&2
  found=1
 fi

 while IFS= read -r path; do
  [[ -f "$path" ]] || continue
  matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' "$path" || true)
  if [[ -n "$matches" ]]; then
   printf '[ci] ERROR: machine-specific absolute path(s) in %s:\n%s\n' "$path" "$matches" >&2
   found=1
  fi
 done < <(git ls-files -- .github/workflows/ci.yml bin/linkedspec capability_conformance cli_conformance unicode_case lua/src/linkedspec/semantic_index.lua lua/src/linkedspec/semantic_compilation_outcome.lua lua/src/linkedspec/semantic_static_projection.lua lua/src/linkedspec/semantic_query.lua lua/test/project_data_storage_test.lua lua/test/semantic_index_source_foundation_test.lua lua/test/semantic_index_compilation_foundation_test.lua lua/test/semantic_index_static_graph_test.lua lua/test/semantic_index_static_remaining_test.lua lua/test/semantic_index_call_core_test.lua lua/test/semantic_index_call_staged_generated_test.lua lua/test/semantic_index_query_kernel_test.lua tools/build_lua_native.sh tools/check_callable_codeblock_contract.py tools/check_callable_codeblock_five_backend.sh tools/check_callable_signature_contract.py tools/check_complete_named_mark_contract.py tools/check_diagnostic_output_contract.py tools/check_diagnostic_output_five_backend.sh tools/check_duplicate_regex_slot_identity_contract.py tools/check_duplicate_regex_slot_identity_five_backend.sh tools/check_logical_helper_contract.py tools/check_logical_helper_five_backend.sh tools/check_mcp_implementation_admission.py tools/check_mcp_semantic_transport_contract.py tools/check_mutation_six_runtime.sh tools/check_progressive_span_dispatch_contract.py tools/check_recognition_transaction_contract.py tools/check_staged_ast_enrichment_contract.py tools/materialize_mcp_semantic_transport_contract.py tools/mcp_contract_binding.py tools/generate_perl_mcp_contract.py tools/generate_rust_mcp_contract.py tools/check_punctuation_light_zero_arg_contract.py tools/check_punctuation_light_five_backend.sh tools/check_repeated_action_result_contract.py tools/check_repeated_action_result_five_backend.sh tools/check_root_rule_selection_contract.py tools/check_root_rule_selection_five_backend.sh tools/check_rule_local_cursor_contract.py tools/check_rule_local_cursor_five_backend.sh tools/check_semantic_introspection_contract.py tools/check_uniform_binding_contract.py tools/check_uniform_binding_mutation_result_surface.py tools/check_capability_conformance.pl tools/check_generated_source_contract.pl tools/check_language_capability_coverage.pl tools/check_native_spec_resolution_contract.pl tools/check_scalar_numeric_contract.py tools/check_unicode_case_contract.py tools/check_unicode_rule_label_contract.py tools/run_ci_local.sh tools/run_rust_local.sh tools/run_dart_local.sh tools/run_dart_project_data.sh tools/run_julia_local.sh tools/run_lua_project_data.sh tools/run_primary_cli_matrix.sh tools/run_python_project_data.sh tools/run_cli_conformance.pl tools/test_lua_project_data_storage.sh tools/test_project_data_process_locality.sh tools/test_repo_root_process_portability.sh tools/test_tool_project_data_storage.sh rust/linkedspec-runtime/src/mcp_contract.rs rust/linkedspec-runtime/src/mcp_contract_runtime.rs rust/linkedspec-runtime/src/mcp_server.rs rust/linkedspec-runtime/src/mcp_wire.rs rust/linkedspec-runtime/tests/mcp_server_rust_dispatch.rs rust/linkedspec-runtime/tests/mcp_server_rust_stdio.rs rust/linkedspec-runtime/tests/mcp_server_rust_admission.rs rust/linkedspec-runtime/tests/repository_root_relocation.rs dart/test/mcp_server_dart_admission_test.dart t/phase0_regression.t t/trace_cli.t t/cli_conformance_runner.t t/repeated_action_result_perl_contract.t t/mcp_contract_perl_binding.t t/mcp_server_perl_dispatch.t t/mcp_server_perl_stdio.t t/mcp_server_perl_admission.t lua/test/repeated_action_result_contract_test.lua perl/LinkedSpec.pm perl/LinkedSpec)

 while IFS= read -r path; do
  [[ -f "$path" ]] || continue
  matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' "$path" || true)
  if [[ -n "$matches" ]]; then
   printf '[ci] ERROR: machine-specific absolute path(s) in %s:\n%s\n' "$path" "$matches" >&2
   found=1
  fi
 done < <(git ls-files -- \
  tools/generate_dart_mcp_contract.py \
  tools/generate_julia_mcp_contract.py \
  dart/lib/src/mcp/mcp_contract.dart \
  dart/lib/src/mcp/mcp_contract_runtime.dart \
  dart/lib/src/mcp/mcp_server.dart \
  dart/lib/src/mcp/mcp_wire.dart \
  dart/test/mcp_contract_dart_binding_test.dart \
  dart/test/mcp_server_dart_dispatch_test.dart \
  dart/test/mcp_server_dart_stdio_test.dart \
  dart/test/mcp_server_dart_admission_test.dart \
  julia/src/mcp/McpContract.jl \
  julia/src/mcp/McpContractRuntime.jl \
  julia/src/mcp/McpServer.jl \
  julia/src/mcp/McpWire.jl \
  julia/test/mcp_contract_julia_binding_test.jl \
  julia/test/mcp_server_julia_dispatch_test.jl \
  julia/test/mcp_server_julia_stdio_test.jl \
  julia/test/mcp_server_julia_admission_test.jl \
  tools/generate_lua_mcp_contract.py \
  lua/native/mcp_system.c \
  lua/src/linkedspec/mcp_contract.lua \
  lua/src/linkedspec/mcp_contract_runtime.lua \
  lua/src/linkedspec/mcp_server.lua \
  lua/src/linkedspec/mcp_wire.lua \
  lua/test/mcp_contract_lua_binding_test.lua \
  lua/test/mcp_server_lua_dispatch_test.lua \
  lua/test/mcp_server_lua_stdio_test.lua \
  lua/test/mcp_server_lua_admission_test.lua)

 (( found == 0 )) || exit 1
}

log "repo root: $REPO_ROOT"
log "checking required commands"
require_command git
require_command perl
require_command prove
require_command python3
require_command dart
require_command julia

if [[ "$(uname -s)" == Darwin ]]; then
 log "checking macOS sandbox initialization required by process locality"
 /usr/bin/sandbox-exec -p '(version 1) (allow default)' /usr/bin/true ||
  fail "macOS sandbox initialization denied; rerun this complete staged candidate in approved host execution (docs/knowledge/project-data-process-locality-proof.md)"
fi

log "running the general doctrine enforcer (DOCTRINE_ENFORCEMENT.md §5/§7 — E4 backstop): the registry driver runs every registered check (memory-architecture, Knowledge Map, ...)"
bash "$REPO_ROOT/scripts/check_doctrines.sh"

log "checking task-evidence path coverage through isolated indexes"
require_tracked_file tools/test_diagnosis_evidence.py
bash "$REPO_ROOT/tools/run_python_project_data.sh" tools/test_diagnosis_evidence.py
require_tracked_file docs/checkpoints/task-acceptance-backend-scope/test_restoration_boundary.py
bash "$REPO_ROOT/tools/run_python_project_data.sh" docs/checkpoints/task-acceptance-backend-scope/test_restoration_boundary.py
require_tracked_file docs/checkpoints/task-acceptance-backend-scope/test_publish.py
bash "$REPO_ROOT/tools/run_python_project_data.sh" docs/checkpoints/task-acceptance-backend-scope/test_publish.py

log "checking bounded NUL-delimited path transport in the path/storage doctrines"
require_tracked_file tools/test_doctrine_path_streaming.py
bash "$REPO_ROOT/tools/run_python_project_data.sh" tools/test_doctrine_path_streaming.py

log "checking Knowledge header list association through the public generator/checker"
require_tracked_file t/knowledge_map_header_lists.t
PERL5LIB= prove t/knowledge_map_header_lists.t

log "checking atomic Knowledge Map publication and failure preservation"
require_tracked_file tools/test_knowledge_map_atomic_output.py
bash "$REPO_ROOT/tools/run_python_project_data.sh" tools/test_knowledge_map_atomic_output.py

log "checking compact Knowledge metadata, immutable claim reuse and maintained scope controls"
for fixture in tools/test_knowledge_map_projection.py tools/test_claim_verification_cache.py tools/test_reference_scope.py tools/test_task_narrative.py tools/test_historical_objective_images.py \
    docs/checkpoints/document-pressure-restoration/review.py \
    docs/checkpoints/document-pressure-restoration/book_review.py; do
  require_tracked_file "$fixture"
  bash "$REPO_ROOT/tools/run_python_project_data.sh" "$fixture"
done
require_tracked_file tools/historical_objective_images.py
require_tracked_file tests/language-readiness/current-source-images.json.gz
log "checking paged exact document-history catalogs"
require_tracked_file t/document_history_catalog.t
PERL5LIB= prove t/document_history_catalog.t

log "auditing git-tracked CI inputs"
require_tracked_file .github/workflows/ci.yml
require_tracked_file tools/run_ci_local.sh
require_tracked_file tools/verification_receipt.sh
require_tracked_file tools/run_rust_local.sh
require_tracked_file tools/run_dart_local.sh
require_tracked_file tools/run_dart_project_data.sh
require_tracked_file tools/run_julia_local.sh
require_tracked_file tools/run_julia_project_data.sh
require_tracked_file tools/run_lua_local.sh
require_tracked_file tools/run_lua_project_data.sh
require_tracked_file tools/run_python_project_data.sh
require_tracked_file tools/run_primary_cli_matrix.sh
require_tracked_file tools/run_cargo_local.sh
require_tracked_file tools/build_lua_native.sh
require_tracked_file tools/test_perl_project_data_storage.sh
require_tracked_file tools/test_rust_project_data_storage.sh
require_tracked_file tools/test_dart_project_data_storage.sh
require_tracked_file tools/test_julia_project_data_storage.sh
require_tracked_file tools/test_lua_project_data_storage.sh
require_tracked_file tools/test_tool_project_data_storage.sh
require_tracked_file tools/test_project_data_process_locality.sh
require_tracked_file tools/test_repo_root_process_portability.sh
require_tracked_file rust/linkedspec-runtime/tests/repository_root_relocation.rs
require_tracked_file lua/test/project_data_storage_test.lua
require_tracked_file tools/check_julia_primary_cli.sh
require_tracked_file tools/run_cli_conformance.pl
require_tracked_file tools/check_callable_codeblock_contract.py
require_tracked_file tools/check_callable_codeblock_five_backend.sh
require_tracked_file tools/check_callable_signature_contract.py
require_tracked_file tools/check_complete_named_mark_contract.py
require_tracked_file tools/check_diagnostic_output_contract.py
require_tracked_file tools/check_diagnostic_output_five_backend.sh
require_tracked_file tools/check_duplicate_regex_slot_identity_contract.py
require_tracked_file tools/check_duplicate_regex_slot_identity_five_backend.sh
require_tracked_file tools/check_logical_helper_contract.py
require_tracked_file tools/check_logical_helper_five_backend.sh
require_tracked_file tools/materialize_mcp_semantic_transport_contract.py
require_tracked_file tools/check_mcp_semantic_transport_contract.py
require_tracked_file tools/check_progressive_span_dispatch_contract.py
require_tracked_file tools/check_recognition_transaction_contract.py
require_tracked_file tools/check_staged_ast_enrichment_contract.py
require_tracked_file tools/mcp_contract_binding.py
require_tracked_file tools/generate_perl_mcp_contract.py
require_tracked_file tools/generate_rust_mcp_contract.py
require_tracked_file tools/generate_dart_mcp_contract.py
require_tracked_file tools/generate_julia_mcp_contract.py
require_tracked_file tools/generate_lua_mcp_contract.py
require_tracked_file tools/check_mcp_implementation_admission.py
require_tracked_file tools/check_punctuation_light_zero_arg_contract.py
require_tracked_file tools/check_punctuation_light_five_backend.sh
require_tracked_file tools/check_repeated_action_result_contract.py
require_tracked_file tools/check_repeated_action_result_five_backend.sh
require_tracked_file tools/check_standalone_lifecycle_block_contract.py
require_tracked_file tools/check_standalone_lifecycle_block_five_backend.sh
require_tracked_file tools/check_sexpr_document_v1.sh
require_tracked_file specs/SExprDocumentV1.spec
require_tracked_file tests/sexpr-document-v1/contract.json
require_tracked_file t/sexpr_document_v1.t
require_tracked_file rust/linkedspec-runtime/tests/sexpr_document_v1.rs
require_tracked_file dart/test/sexpr_document_v1_test.dart
require_tracked_file julia/test/sexpr_document_v1_test.jl
require_tracked_file lua/test/sexpr_document_v1_test.lua
require_tracked_file tools/check_root_rule_selection_contract.py
require_tracked_file tools/check_root_rule_selection_five_backend.sh
require_tracked_file tools/check_rule_local_cursor_contract.py
require_tracked_file tools/check_rule_local_cursor_five_backend.sh
require_tracked_file tools/check_typed_source_location_contract.py
require_tracked_file tools/check_language_closure_contract.py
require_tracked_file capability_conformance/language_closure_contract.json
require_tracked_file tools/check_composed_objective_contract.py
require_tracked_file capability_conformance/composed_objective_contract.json
require_tracked_file tests/language-readiness/composed/diagnostic.spec
require_tracked_file tests/language-readiness/composed/normalization.spec
require_tracked_file tests/language-readiness/composed/normalization-calls.spec
require_tracked_file t/composed_normalization_perl.t
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.1-fresh.pl
require_tracked_file tests/language-readiness/recover_objective_audit_inputs.py
require_tracked_file tests/language-readiness/artifacts/objective-audit-inputs.zip
require_tracked_file tests/language-readiness/artifacts/objective-audit-inputs.json
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.1-proof.py
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.1-archive.py
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.0-census.py
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.0-verification.json
require_tracked_file tests/language-readiness/verify_objectives.py
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.1-verification.json
require_tracked_file docs/language-readiness/objective-reconciliation.md
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.1.3.1.2.3-verification.json
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.1.3.2.7-verification.json
require_tracked_file docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.1.3.3.5-verification.json
require_tracked_file tests/language-readiness/composed/diagnostic-invalid-arity.spec
require_tracked_file tools/check_typed_source_location_six_runtime.sh
require_tracked_file tools/check_recursive_observation_six_runtime.sh
require_tracked_file tools/check_progressive_span_dispatch_six_runtime.sh
require_tracked_file tools/check_staged_ast_enrichment_six_runtime.sh
require_tracked_file tools/check_typed_authoring_model_six_runtime.sh
require_tracked_file tools/check_inter_match_gap_capture_contract.py
require_tracked_file tools/check_inter_match_gap_capture_six_runtime.sh
require_tracked_file tools/check_typed_gap_composition_six_runtime.sh
require_tracked_file lua/test/inter_match_gap_capture_contract_test.lua
require_tracked_file tools/check_recognition_transaction_six_runtime.sh
require_tracked_file tools/check_semantic_introspection_contract.py
require_tracked_file tools/check_semantic_introspection_six_runtime.sh
require_tracked_file tools/check_mcp_six_runtime.sh
require_tracked_file tools/check_mutation_public_surface.py
require_tracked_file tools/check_mutation_six_runtime.sh
require_tracked_file tools/check_uniform_binding_contract.py
require_tracked_file tools/check_uniform_binding_mutation_result_surface.py
require_tracked_file tools/check_capability_conformance.pl
require_tracked_file tools/check_generated_source_contract.pl
require_tracked_file tools/check_language_capability_coverage.pl
require_tracked_file tools/check_native_spec_resolution_contract.pl
require_tracked_file tools/check_scalar_numeric_contract.py
require_tracked_file tools/check_unicode_case_contract.py
require_tracked_file tools/check_unicode_rule_label_contract.py
require_tracked_file capability_conformance/mcp_semantic_transport_contract.json
require_tracked_file capability_conformance/progressive_span_dispatch_contract.json
require_tracked_file capability_conformance/recognition_transaction_contract.json
require_tracked_file capability_conformance/mcp_semantic_transport/schema.json
require_tracked_file capability_conformance/mcp_semantic_transport/semantic_payloads.json
require_tracked_file capability_conformance/mcp_semantic_transport/corpus.json
require_tracked_file capability_conformance/mcp_semantic_transport/canonical_frames.jsonl
require_tracked_file capability_conformance/mcp_semantic_transport/validator_cases.json
require_tracked_file capability_conformance/mcp_implementation_admission.json
require_tracked_file unicode_case/self_hosted_cli/manifest.json
require_tracked_file t/semantic_introspection_perl_admission.t
require_tracked_file rust/linkedspec-runtime/tests/semantic_introspection_rust_admission.rs
require_tracked_file rust/linkedspec-runtime/src/mcp_contract.rs
require_tracked_file rust/linkedspec-runtime/src/mcp_contract_runtime.rs
require_tracked_file rust/linkedspec-runtime/src/mcp_server.rs
require_tracked_file rust/linkedspec-runtime/src/mcp_wire.rs
require_tracked_file rust/linkedspec-runtime/tests/mcp_server_rust_dispatch.rs
require_tracked_file rust/linkedspec-runtime/tests/mcp_server_rust_stdio.rs
require_tracked_file rust/linkedspec-runtime/tests/mcp_server_rust_admission.rs
require_tracked_file dart/lib/src/mcp/mcp_contract.dart
require_tracked_file dart/lib/src/mcp/mcp_contract_runtime.dart
require_tracked_file dart/lib/src/mcp/mcp_server.dart
require_tracked_file dart/lib/src/mcp/mcp_wire.dart
require_tracked_file dart/test/mcp_contract_dart_binding_test.dart
require_tracked_file dart/test/mcp_server_dart_dispatch_test.dart
require_tracked_file dart/test/mcp_server_dart_stdio_test.dart
require_tracked_file dart/test/mcp_server_dart_admission_test.dart
require_tracked_file julia/src/mcp/McpContract.jl
require_tracked_file julia/src/mcp/McpContractRuntime.jl
require_tracked_file julia/src/mcp/McpServer.jl
require_tracked_file julia/src/mcp/McpWire.jl
require_tracked_file julia/test/mcp_contract_julia_binding_test.jl
require_tracked_file julia/test/mcp_server_julia_dispatch_test.jl
require_tracked_file julia/test/mcp_server_julia_stdio_test.jl
require_tracked_file julia/test/mcp_server_julia_admission_test.jl
require_tracked_file lua/native/mcp_system.c
require_tracked_file lua/src/linkedspec/mcp_contract.lua
require_tracked_file lua/src/linkedspec/mcp_contract_runtime.lua
require_tracked_file lua/src/linkedspec/mcp_server.lua
require_tracked_file lua/src/linkedspec/mcp_wire.lua
require_tracked_file lua/test/mcp_contract_lua_binding_test.lua
require_tracked_file lua/test/mcp_server_lua_dispatch_test.lua
require_tracked_file lua/test/mcp_server_lua_stdio_test.lua
require_tracked_file lua/test/mcp_server_lua_admission_test.lua
require_tracked_file dart/test/semantic_introspection_dart_admission_test.dart
require_tracked_file julia/test/semantic_introspection_julia_admission_test.jl
require_tracked_file lua/test/semantic_introspection_lua_admission_test.lua
require_tracked_file t/rule_local_cursor_perl_contract.t
require_tracked_file t/duplicate_regex_slot_identity_perl_contract.t
require_tracked_file t/sparse_and_action_slots_perl_regression.t
require_tracked_file t/repeated_action_result_perl_contract.t
require_tracked_file t/standalone_lifecycle_block_perl_contract.t
require_tracked_file t/standalone_lifecycle_block_self_hosted_contract.t
require_tracked_file rust/linkedspec-runtime/tests/duplicate_regex_slot_identity_contract.rs
require_tracked_file rust/linkedspec-runtime/tests/repeated_action_result_contract.rs
require_tracked_file rust/linkedspec-runtime/tests/standalone_lifecycle_block_contract.rs
require_tracked_file rust/linkedspec-core/tests/unicode_rule_label_contract.rs
require_tracked_file rust/linkedspec-runtime/tests/unicode_rule_label_routes.rs
require_tracked_file dart/test/repeated_action_result_contract_test.dart
require_tracked_file dart/test/standalone_lifecycle_block_contract_test.dart
require_tracked_file dart/test/self_hosted_unicode_rule_label_test.dart
require_tracked_file dart/lib/src/parser/unicode_rule_label.dart
require_tracked_file dart/test/unicode_rule_label_classifier_test.dart
require_tracked_file dart/test/unicode_rule_label_routes_test.dart
require_tracked_file dart/test/unicode_rule_label_identity_routes_test.dart
require_tracked_file dart/test/unicode_rule_label_negative_isolation_test.dart
require_tracked_file julia/src/spec/UnicodeRuleLabel.jl
require_tracked_file julia/test/unicode_rule_label_classifier_test.jl
require_tracked_file julia/test/unicode_rule_label_routes_test.jl
require_tracked_file julia/test/unicode_rule_label_identity_routes_test.jl
require_tracked_file julia/test/unicode_rule_label_negative_isolation_test.jl
require_tracked_file julia/test/repeated_action_result_contract_test.jl
require_tracked_file julia/test/standalone_lifecycle_block_contract_test.jl
require_tracked_file lua/src/linkedspec/unicode_rule_label.lua
require_tracked_file lua/src/linkedspec/semantic_index.lua
require_tracked_file lua/src/linkedspec/semantic_compilation_outcome.lua
require_tracked_file lua/src/linkedspec/semantic_static_projection.lua
require_tracked_file lua/src/linkedspec/semantic_query.lua
require_tracked_file lua/test/semantic_index_source_foundation_test.lua
require_tracked_file lua/test/semantic_index_compilation_foundation_test.lua
require_tracked_file lua/test/semantic_index_static_graph_test.lua
require_tracked_file lua/test/semantic_index_static_remaining_test.lua
require_tracked_file lua/test/semantic_index_call_core_test.lua
require_tracked_file lua/test/semantic_index_call_staged_generated_test.lua
require_tracked_file lua/test/semantic_index_query_kernel_test.lua
require_tracked_file lua/test/unicode_rule_label_classifier_test.lua
require_tracked_file lua/test/unicode_rule_label_routes_test.lua
require_tracked_file lua/test/unicode_rule_label_identity_routes_test.lua
require_tracked_file lua/test/body_fluent_whole_token_test.lua
require_tracked_file lua/test/unicode_rule_label_negative_isolation_test.lua
require_tracked_file lua/test/repeated_action_result_contract_test.lua
require_tracked_file lua/test/standalone_lifecycle_block_contract_test.lua
require_tracked_file dart/test/duplicate_regex_slot_identity_contract_test.dart
require_tracked_file julia/test/duplicate_regex_slot_identity_contract_test.jl
require_tracked_file lua/test/duplicate_regex_slot_identity_contract_test.lua
require_tracked_file t/root_rule_selection_perl_core.t
require_tracked_file t/root_rule_selection_perl_routes.t
require_tracked_file rust/linkedspec-runtime/tests/rule_local_cursor_contract.rs
require_tracked_file dart/test/rule_local_cursor_contract_test.dart
require_tracked_file julia/test/rule_local_cursor_contract_test.jl
require_tracked_file lua/test/rule_local_cursor_contract_test.lua
require_tracked_file rust/linkedspec-runtime/tests/root_rule_selection_admission.rs
require_tracked_file dart/test/root_rule_selection_admission_test.dart
require_tracked_file julia/test/root_rule_selection_admission_test.jl
require_tracked_file lua/test/root_rule_selection_admission_test.lua
require_tracked_file bin/linkedspec
require_tracked_file capability_conformance/manifest.json
require_tracked_file capability_conformance/callable_codeblock_contract.json
require_tracked_file capability_conformance/callable_signature_contract.json
require_tracked_file capability_conformance/complete_named_mark_contract.json
require_tracked_file capability_conformance/diagnostic_output_contract.json
require_tracked_file capability_conformance/duplicate_regex_slot_identity_contract.json
require_tracked_file capability_conformance/logical_helper_contract.json
require_tracked_file capability_conformance/punctuation_light_zero_arg_contract.json
require_tracked_file capability_conformance/repeated_action_result_contract.json
require_tracked_file capability_conformance/standalone_lifecycle_block_contract.json
require_tracked_file capability_conformance/repeated_action_result/explicit_or_distinct.spec
require_tracked_file capability_conformance/repeated_action_result/explicit_or_distinct.input
require_tracked_file capability_conformance/repeated_action_result/explicit_or_distinct.expected.json
require_tracked_file capability_conformance/root_rule_selection_contract.json
require_tracked_file capability_conformance/rule_local_cursor_contract.json
require_tracked_file capability_conformance/typed_source_location_contract.json
require_tracked_file capability_conformance/inter_match_gap_capture_contract.json
require_tracked_file capability_conformance/semantic_introspection_contract.json
require_tracked_file capability_conformance/semantic_introspection_model.json
require_tracked_file capability_conformance/uniform_binding_contract.json
require_tracked_file capability_conformance/generated_source_contract.json
require_tracked_file capability_conformance/native_spec_resolution_contract.json
require_tracked_file capability_conformance/unicode_case_contract.json
require_tracked_file capability_conformance/unicode_rule_label_contract.json
require_tracked_file capability_conformance/scalar_text_contract.json
require_tracked_file capability_conformance/scalar_numeric_contract.json
require_tracked_file unicode_case/README.md
require_tracked_file unicode_case/generate_unicode_case_contract.py
require_tracked_file unicode_case/generate_unicode_rule_label_contract.py
require_tracked_file unicode_case/unicode_rule_label_regex_class.txt
require_tracked_file unicode_case/upstream/17.0.0/UnicodeData.txt.gz
require_tracked_file unicode_case/upstream/17.0.0/SpecialCasing.txt.gz
require_tracked_file unicode_case/upstream/17.0.0/DerivedCoreProperties.txt.gz
require_tracked_file unicode_case/upstream/17.0.0/LICENSE.txt.gz
require_tracked_file perl/LinkedSpec/UnicodeCaseMapping.pm
require_tracked_file perl/LinkedSpec/UnicodeXIDContinue.pm
require_tracked_file rust/linkedspec-runtime/src/unicode_case_mapping.rs
require_tracked_file rust/linkedspec-core/src/unicode_rule_label.rs
require_tracked_file rust/linkedspec-runtime/src/semantic_index.rs
require_tracked_file rust/linkedspec-runtime/tests/unicode_case_mapping.rs
require_tracked_file rust/linkedspec-runtime/tests/semantic_index_foundation.rs
require_tracked_file dart/lib/src/runtime/unicode_case_mapping.dart
require_tracked_file dart/test/unicode_case_mapping_test.dart
require_tracked_file julia/src/runtime/UnicodeCaseMapping.jl
require_tracked_file lua/src/linkedspec/unicode_case_mapping.lua
require_tracked_file cli_conformance/manifest.json
require_tracked_file t/cli_conformance_runner.t
require_tracked_file t/trace_cli.t
require_tracked_file t/native_spec_resolution.t
require_tracked_file t/generated_source_contract.t
require_tracked_file t/diagnostic_output_perl_contract.t
require_tracked_file t/scalar_numeric_contract.t
require_tracked_file t/punctuation_light_zero_arg_contract.t
require_tracked_file t/complete_named_mark_contract.t
require_tracked_file t/typed_source_location_values.t
require_tracked_file t/typed_source_location_perl_contract.t
require_tracked_file t/recursive_observation_perl_contract.t
require_tracked_file t/recognition_transaction_perl_authority.t
require_tracked_file t/recognition_transaction_perl_contract.t
require_tracked_file t/progressive_span_dispatch_perl_contract.t
require_tracked_file t/staged_ast_enrichment_perl_contract.t
require_tracked_file rust/linkedspec-runtime/tests/staged_ast_enrichment_contract.rs
require_tracked_file dart/test/staged_ast_enrichment_contract_test.dart
require_tracked_file julia/test/staged_ast_enrichment_contract_test.jl
require_tracked_file lua/test/staged_ast_enrichment_contract_test.lua
require_tracked_file rust/linkedspec-runtime/tests/progressive_span_dispatch_contract.rs
require_tracked_file dart/test/progressive_span_dispatch_contract_test.dart
require_tracked_file julia/test/progressive_span_dispatch_contract_test.jl
require_tracked_file lua/test/progressive_span_dispatch_contract_test.lua
require_tracked_file rust/linkedspec-runtime/tests/recognition_transaction_contract.rs
require_tracked_file dart/test/recognition_transaction_contract_test.dart
require_tracked_file julia/test/recognition_transaction_contract_test.jl
require_tracked_file lua/test/recognition_transaction_contract_test.lua
require_tracked_file rust/linkedspec-runtime/tests/typed_source_location_contract.rs
require_tracked_file rust/linkedspec-runtime/tests/recursive_observation_contract.rs
require_tracked_file dart/test/typed_source_location_contract_test.dart
require_tracked_file dart/test/recursive_observation_contract_test.dart
require_tracked_file julia/test/typed_source_location_contract_test.jl
require_tracked_file julia/test/recursive_observation_contract_test.jl
require_tracked_file lua/test/typed_source_location_contract_test.lua
require_tracked_file lua/test/recursive_observation_contract_test.lua
require_tracked_file lua/test/source_boundary_compatibility_aliases_test.lua
require_tracked_file t/variadic_user_function_contract.t
require_tracked_file t/callable_codeblock_literal_contract.t
require_tracked_file t/signed_array_selector_perl_contract.t
require_tracked_file tests/numeric-codeblocks/signed-array-selectors.json
require_tracked_file t/uniform_binding_contract.t
require_tracked_file t/actionir_receiver_scalar_copy.t
require_tracked_file t/actionir_receiver_scalar_copy_probe.pl
require_tracked_file t/semantic_index_perl_foundation.t
require_tracked_file t/semantic_index_perl_static_projection.t
require_tracked_file t/semantic_index_perl_calls_projection.t
require_tracked_file t/semantic_index_perl_query.t
require_tracked_file t/semantic_index_perl_runtime_observation.t
require_tracked_file t/mcp_contract_perl_binding.t
require_tracked_file t/mcp_server_perl_dispatch.t
require_tracked_file t/mcp_server_perl_stdio.t
require_tracked_file t/mcp_server_perl_admission.t
require_tracked_file perl/LinkedSpec/SemanticCallProjection.pm
require_tracked_file perl/LinkedSpec/SemanticQuery.pm
require_tracked_file perl/LinkedSpec/SemanticRuntimeProjection.pm
require_tracked_file perl/LinkedSpec/SemanticStaticProjection.pm
require_tracked_file perl/LinkedSpec/RuntimeSemanticObservation.pm
require_tracked_file tools/check_aggregate_selector_retirement.py
require_tracked_file tools/check_public_aggregate_selector_surface.py
require_tracked_file tools/check_executable_aggregate_selector_sources.py
require_tracked_file perl/LinkedSpec.pm
require_tracked_file perl/LinkedSpec/BindingRuntime.pm
require_tracked_file perl/LinkedSpec/SpecLoader.pm
require_tracked_file perl/LinkedSpec/GeneratedSource.pm
require_tracked_file perl/LinkedSpec/RecognitionTransaction.pm
require_tracked_file perl/LinkedSpec/RecognitionTransactionPolicy.pm
require_tracked_file perl/LinkedSpec/RecognitionTransactionRuntime.pm
require_tracked_file perl/LinkedSpec/RecursiveObservationPolicy.pm
require_tracked_file perl/LinkedSpec/ActionIR/Scanner/RecognitionTransactionRules.pm
require_tracked_file perl/LinkedSpec/SemanticIndex.pm
require_tracked_file perl/LinkedSpec/SemanticSourceMap.pm
require_tracked_file perl/LinkedSpec/MCPContract.pm
require_tracked_file perl/LinkedSpec/MCPContractRuntime.pm
require_tracked_file perl/LinkedSpec/MCPServer.pm
require_tracked_file perl/LinkedSpec/MCPWire.pm
require_tracked_file perl/LinkedSpec/Numeric.pm
require_tracked_file t/phase0_regression.t
require_tracked_file perl/LinkedSpec/ActionIR/RawDependencies.pm
require_tracked_file t/actionir_raw_dependency_metadata.t
require_tracked_file t/actionir_raw_dependency_provenance.t
require_tracked_file t/actionir_nested_block_source_spans.t
require_tracked_file t/actionir_raw_dependency_compatibility.t
require_tracked_file t/codeblock_push_composition_perl.t
require_tracked_file scripts/check_memory_architecture.sh
require_tracked_file scripts/check_memory_commit_pointer.sh
require_tracked_file tools/test_memory_commit_pointer.sh
require_tracked_file tools/check_memory_handoff_state.py
require_tracked_file scripts/check_doctrines.sh
require_tracked_file scripts/check_diagnosis_evidence.sh
require_tracked_file scripts/check_readme_stability.sh
require_tracked_file scripts/check_readme_routing_pressure.pl
require_tracked_file doctrine/readme_stability/routes.jsonl
require_tracked_file README_POLICY.md
require_tracked_file DOCTRINE_ENFORCEMENT.md
require_tracked_file TOOLBOX.md
require_tracked_file MEMORY_ARCHITECTURE.md
require_tracked_file KNOWLEDGE_MAP.md
require_tracked_file knowledge-map/scripts/gen_knowledge_map.sh
require_tracked_file knowledge-map/scripts/check_knowledge_map.sh
# NOTE: 'plugin' is intentionally NOT required here — NONCORE-QUARANTINE.3 git mv'd the 13 .plg to
# noncore/plugin/ and removed the top-level plugin/ dir. The core gate stays core-only and does not reach
# into noncore/ (same core-only precedent as PHASE0-BACKHALF-TRIAGE.5.1/.5.4). (PHASE0-BACKHALF-TRIAGE.5.3.1)
for path in capability_conformance cli_conformance unicode_case specs conf tablescript ebnf perl t; do
 require_tracked_tree "$path"
done
check_no_untracked_ci_inputs

log "auditing CI-local path usage"
audit_no_machine_specific_absolute_paths
semantic_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_semantic_introspection_six_runtime.sh || true)
[[ -z "$semantic_driver_matches" ]] || fail "machine-specific absolute path(s) in semantic recurring driver:
$semantic_driver_matches"
mcp_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_mcp_six_runtime.sh || true)
[[ -z "$mcp_driver_matches" ]] || fail "machine-specific absolute path(s) in MCP recurring driver:
$mcp_driver_matches"
typed_source_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_typed_source_location_six_runtime.sh || true)
[[ -z "$typed_source_driver_matches" ]] || fail "machine-specific absolute path(s) in typed source-location recurring driver:
$typed_source_driver_matches"
recursive_observation_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_recursive_observation_six_runtime.sh || true)
[[ -z "$recursive_observation_driver_matches" ]] || fail "machine-specific absolute path(s) in recursive-observation recurring driver:
$recursive_observation_driver_matches"
progressive_span_dispatch_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_progressive_span_dispatch_six_runtime.sh || true)
[[ -z "$progressive_span_dispatch_driver_matches" ]] || fail "machine-specific absolute path(s) in progressive span-dispatch recurring driver:
$progressive_span_dispatch_driver_matches"
staged_ast_enrichment_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_staged_ast_enrichment_six_runtime.sh || true)
[[ -z "$staged_ast_enrichment_driver_matches" ]] || fail "machine-specific absolute path(s) in staged-AST enrichment recurring driver:
$staged_ast_enrichment_driver_matches"
typed_authoring_model_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_typed_authoring_model_six_runtime.sh || true)
[[ -z "$typed_authoring_model_driver_matches" ]] || fail "machine-specific absolute path(s) in typed authoring-model recurring driver:
$typed_authoring_model_driver_matches"
inter_match_gap_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_inter_match_gap_capture_six_runtime.sh || true)
[[ -z "$inter_match_gap_driver_matches" ]] || fail "machine-specific absolute path(s) in inter-match gap-capture recurring driver:
$inter_match_gap_driver_matches"
typed_gap_composition_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_typed_gap_composition_six_runtime.sh || true)
[[ -z "$typed_gap_composition_driver_matches" ]] || fail "machine-specific absolute path(s) in typed gap-composition driver:
$typed_gap_composition_driver_matches"
recognition_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_recognition_transaction_six_runtime.sh || true)
[[ -z "$recognition_driver_matches" ]] || fail "machine-specific absolute path(s) in recognition-transaction recurring driver:
$recognition_driver_matches"
standalone_lifecycle_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_standalone_lifecycle_block_five_backend.sh || true)
[[ -z "$standalone_lifecycle_driver_matches" ]] || fail "machine-specific absolute path(s) in standalone lifecycle-block recurring driver:
$standalone_lifecycle_driver_matches"
mutation_driver_matches=$(grep -nE '/(Users|home)/[^[:space:]]*|[[:alpha:]]:\\\\' tools/check_mutation_six_runtime.sh || true)
[[ -z "$mutation_driver_matches" ]] || fail "machine-specific absolute path(s) in mutation recurring driver:
$mutation_driver_matches"

log "running syntax checks"
bash -n tools/run_ci_local.sh tools/run_rust_local.sh tools/run_dart_local.sh \
 tools/run_julia_local.sh tools/run_julia_project_data.sh tools/run_lua_local.sh tools/run_lua_project_data.sh \
 tools/run_python_project_data.sh tools/run_dart_project_data.sh \
 tools/run_primary_cli_matrix.sh \
 tools/build_lua_native.sh tools/check_julia_primary_cli.sh \
 tools/run_cargo_local.sh tools/test_perl_project_data_storage.sh tools/test_rust_project_data_storage.sh \
 tools/test_dart_project_data_storage.sh tools/test_julia_project_data_storage.sh \
 tools/test_lua_project_data_storage.sh tools/test_tool_project_data_storage.sh \
 tools/test_project_data_process_locality.sh tools/test_repo_root_process_portability.sh \
 tools/check_callable_codeblock_five_backend.sh \
 tools/check_diagnostic_output_five_backend.sh tools/check_logical_helper_five_backend.sh \
 tools/check_duplicate_regex_slot_identity_five_backend.sh tools/check_repeated_action_result_five_backend.sh \
 tools/check_standalone_lifecycle_block_five_backend.sh \
 tools/check_sexpr_document_v1.sh \
 tools/check_root_rule_selection_five_backend.sh \
 tools/check_rule_local_cursor_five_backend.sh \
 tools/check_semantic_introspection_six_runtime.sh \
 tools/check_mcp_six_runtime.sh \
 tools/check_typed_source_location_six_runtime.sh \
 tools/check_recursive_observation_six_runtime.sh \
 tools/check_progressive_span_dispatch_six_runtime.sh \
 tools/check_staged_ast_enrichment_six_runtime.sh \
 tools/check_typed_authoring_model_six_runtime.sh \
 tools/check_inter_match_gap_capture_six_runtime.sh \
 tools/check_typed_gap_composition_six_runtime.sh \
 tools/check_recognition_transaction_six_runtime.sh \
 scripts/check_memory_commit_pointer.sh scripts/check_readme_stability.sh \
 tools/test_memory_commit_pointer.sh \
 tools/check_punctuation_light_five_backend.sh tools/check_scalar_numeric_six_runtime.sh
bash -n tools/check_mutation_six_runtime.sh
perl -c perl/LinkedSpec.pm
perl -c bin/linkedspec
perl -c scripts/check_readme_routing_pressure.pl
perl -c tools/run_cli_conformance.pl
perl -c tools/check_capability_conformance.pl
perl -c tools/check_generated_source_contract.pl
perl -c tools/check_language_capability_coverage.pl
perl -c tools/check_native_spec_resolution_contract.pl
perl -c -Iperl t/actionir_ast_parser.t
perl -c -Iperl t/actionir_receiver_scalar_copy.t
perl -c -Iperl t/actionir_receiver_scalar_copy_probe.pl
perl -c -Iperl perl/LinkedSpec/ActionIR/RawDependencies.pm
perl -c -Iperl t/actionir_raw_dependency_metadata.t
perl -c -Iperl t/actionir_raw_dependency_provenance.t
perl -c -Iperl t/actionir_nested_block_source_spans.t
perl -c -Iperl t/actionir_raw_dependency_compatibility.t
perl -c -Iperl t/cli_conformance_runner.t
perl -c -Iperl t/trace_cli.t
perl -c -Iperl t/native_spec_resolution.t
perl -c -Iperl t/generated_source_contract.t
perl -c -Iperl t/diagnostic_output_perl_contract.t
perl -c -Iperl t/scalar_text_contract.t
perl -c -Iperl t/scalar_numeric_contract.t
perl -c -Iperl t/punctuation_light_zero_arg_contract.t
perl -c -Iperl t/complete_named_mark_contract.t
perl -c -Iperl t/typed_source_location_values.t
perl -c -Iperl t/typed_source_location_perl_contract.t
perl -c -Iperl t/recursive_observation_perl_contract.t
perl -c -Iperl t/recognition_transaction_perl_authority.t
perl -c -Iperl t/recognition_transaction_perl_contract.t
perl -c -Iperl t/progressive_span_dispatch_perl_contract.t
perl -c -Iperl t/staged_ast_enrichment_perl_contract.t
perl -c -Iperl t/rule_local_cursor_perl_contract.t
perl -c -Iperl t/duplicate_regex_slot_identity_perl_contract.t
perl -c -Iperl t/sparse_and_action_slots_perl_regression.t
perl -c -Iperl t/repeated_action_result_perl_contract.t
perl -c -Iperl t/root_rule_selection_perl_core.t
perl -c -Iperl t/root_rule_selection_perl_routes.t
perl -c -Iperl t/variadic_user_function_contract.t
perl -c -Iperl t/callable_codeblock_literal_contract.t
perl -c -Iperl t/signed_array_selector_perl_contract.t
perl -c -Iperl t/uniform_binding_contract.t
perl -c -Iperl t/semantic_index_perl_foundation.t
perl -c -Iperl t/semantic_index_perl_static_projection.t
perl -c -Iperl t/semantic_index_perl_calls_projection.t
perl -c -Iperl t/semantic_index_perl_query.t
perl -c -Iperl t/semantic_index_perl_runtime_observation.t
perl -c -Iperl t/semantic_introspection_perl_admission.t
perl -c -Iperl t/mcp_contract_perl_binding.t
perl -c -Iperl t/mcp_server_perl_dispatch.t
perl -c -Iperl t/mcp_server_perl_stdio.t
perl -c -Iperl t/mcp_server_perl_admission.t
perl -c -Iperl perl/LinkedSpec/BindingRuntime.pm
perl -c -Iperl perl/LinkedSpec/UnicodeXIDContinue.pm
perl -c -Iperl perl/LinkedSpec/RecognitionTransaction.pm
perl -c -Iperl perl/LinkedSpec/RecognitionTransactionPolicy.pm
perl -c -Iperl perl/LinkedSpec/RecognitionTransactionRuntime.pm
perl -c -Iperl perl/LinkedSpec/RecursiveObservationPolicy.pm
perl -c -Iperl perl/LinkedSpec/ActionIR/Scanner/RecognitionTransactionRules.pm
perl -c -Iperl perl/LinkedSpec/SemanticIndex.pm
perl -c -Iperl perl/LinkedSpec/SemanticSourceMap.pm
perl -c -Iperl perl/LinkedSpec/SemanticCallProjection.pm
perl -c -Iperl perl/LinkedSpec/SemanticQuery.pm
perl -c -Iperl perl/LinkedSpec/SemanticRuntimeProjection.pm
perl -c -Iperl perl/LinkedSpec/SemanticStaticProjection.pm
perl -c -Iperl perl/LinkedSpec/RuntimeSemanticObservation.pm
perl -c -Iperl perl/LinkedSpec/MCPContract.pm
perl -c -Iperl perl/LinkedSpec/MCPContractRuntime.pm
perl -c -Iperl perl/LinkedSpec/MCPServer.pm
perl -c -Iperl perl/LinkedSpec/MCPWire.pm
perl -c -Iperl t/phase0_regression.t

log "checking the phase-aware MEMORY activation-commit pointer"
bash tools/test_memory_commit_pointer.sh

log "checking machine-readable backend capability census"
perl tools/check_capability_conformance.pl

log "checking language closure operation/scope/reference structure"
bash tools/run_python_project_data.sh tools/check_language_closure_contract.py

log "checking neutral composed objective fixtures and independent observations"
bash tools/run_python_project_data.sh tools/check_composed_objective_contract.py

log "checking isolated historical artifact recovery and read-denied audit"
bash tools/run_python_project_data.sh docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.4.2.1-proof.py

log "checking pinned Unicode casing contract"
bash tools/run_python_project_data.sh tools/check_unicode_case_contract.py

log "checking pinned Unicode rule-label contract"
bash tools/run_python_project_data.sh tools/check_unicode_rule_label_contract.py

log "checking portable scalar numeric helper contract"
bash tools/run_python_project_data.sh tools/check_scalar_numeric_contract.py

log "checking backend-neutral logical-helper and typed-truthiness contract"
bash tools/run_python_project_data.sh tools/check_logical_helper_contract.py

log "checking backend-neutral rule-local cursor and bare-edge contract"
bash tools/run_python_project_data.sh tools/check_rule_local_cursor_contract.py

log "checking backend-neutral typed source-location algebra contract"
bash tools/run_python_project_data.sh tools/check_typed_source_location_contract.py

log "checking backend-neutral progressive span-dispatch contract"
bash tools/run_python_project_data.sh tools/check_progressive_span_dispatch_contract.py

log "checking backend-neutral staged-AST enrichment contract"
bash tools/run_python_project_data.sh tools/check_staged_ast_enrichment_contract.py

log "running exact Perl staged-AST enrichment admission consumer"
PERL5LIB= prove -Iperl t/staged_ast_enrichment_perl_contract.t

log "running exact Rust staged-AST enrichment admission consumer"
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test staged_ast_enrichment_contract

log "running exact Dart staged-AST enrichment admission consumer"
(cd dart && bash ../tools/run_dart_project_data.sh test --reporter failures-only test/staged_ast_enrichment_contract_test.dart)

log "running exact Julia staged-AST enrichment admission consumer"
bash tools/run_julia_project_data.sh --project=julia --startup-file=no --history-file=no julia/test/staged_ast_enrichment_contract_test.jl

log "running exact Lua staged-AST enrichment admission consumer on PUC Lua"
bash tools/run_lua_project_data.sh puc lua/test/staged_ast_enrichment_contract_test.lua

log "running exact Lua staged-AST enrichment admission consumer on LuaJIT"
bash tools/run_lua_project_data.sh luajit lua/test/staged_ast_enrichment_contract_test.lua

log "running exact Perl progressive span-dispatch admission consumer"
PERL5LIB= prove -Iperl t/progressive_span_dispatch_perl_contract.t

log "running exact Rust progressive span-dispatch admission consumer"
RUSTFLAGS='--cfg linkedspec_progressive_span_dispatch_red' cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test progressive_span_dispatch_contract

log "running exact Dart progressive span-dispatch admission consumer"
(cd dart && bash ../tools/run_dart_project_data.sh test --reporter failures-only test/progressive_span_dispatch_contract_test.dart)

log "running exact Julia progressive span-dispatch admission consumer"
bash tools/run_julia_project_data.sh --project=julia --startup-file=no --history-file=no -e 'using LinkedSpecJulia, JSON3, Test; include("julia/test/progressive_span_dispatch_contract_test.jl")'

log "running exact Lua progressive span-dispatch admission consumer on PUC Lua"
bash tools/run_lua_project_data.sh puc lua/test/progressive_span_dispatch_contract_test.lua

log "running exact Lua progressive span-dispatch admission consumer on LuaJIT"
bash tools/run_lua_project_data.sh luajit lua/test/progressive_span_dispatch_contract_test.lua

log "checking backend-neutral inter-match gap-capture contract and current no-overclaim boundary"
bash tools/run_python_project_data.sh tools/check_inter_match_gap_capture_contract.py

log "running exact Perl inter-match gap-capture admission consumer"
PERL5LIB= prove -Iperl t/inter_match_gap_capture_perl_contract.t

log "running exact Rust inter-match gap-capture admission consumer"
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test inter_match_gap_capture_contract

log "running exact Dart inter-match gap-capture admission consumer"
(cd dart && bash ../tools/run_dart_project_data.sh test --reporter failures-only test/inter_match_gap_capture_contract_test.dart)

log "running exact Julia inter-match gap-capture admission consumer"
bash tools/run_julia_project_data.sh --project=julia --startup-file=no --history-file=no -e 'using LinkedSpecJulia, JSON3, Test; include("julia/test/inter_match_gap_capture_contract_test.jl")'

log "running exact Lua inter-match gap-capture admission consumer on PUC Lua"
bash tools/run_lua_project_data.sh puc lua/test/inter_match_gap_capture_contract_test.lua

log "running exact Lua inter-match gap-capture admission consumer on LuaJIT"
bash tools/run_lua_project_data.sh luajit lua/test/inter_match_gap_capture_contract_test.lua

log "checking backend-neutral recognition transaction and progress contract"
bash tools/run_python_project_data.sh tools/check_recognition_transaction_contract.py

log "running private Perl recognition transaction authority contract"
PERL5LIB= prove -Iperl t/recognition_transaction_perl_authority.t

log "running exact Perl recognition transaction admission consumer"
PERL5LIB= prove -Iperl t/recognition_transaction_perl_contract.t

log "running exact Rust recognition transaction admission consumer"
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test recognition_transaction_contract

log "running exact Dart recognition transaction admission consumer"
(cd dart && bash ../tools/run_dart_project_data.sh test --reporter failures-only test/recognition_transaction_contract_test.dart)

log "running exact Julia recognition transaction admission consumer"
bash tools/run_julia_project_data.sh --project=julia --startup-file=no --history-file=no -e 'using LinkedSpecJulia, JSON3, Test; include("julia/test/recognition_transaction_contract_test.jl")'

log "running exact Lua recognition transaction admission consumer on PUC Lua"
bash tools/run_lua_project_data.sh puc lua/test/recognition_transaction_contract_test.lua

log "running exact Lua recognition transaction admission consumer on LuaJIT"
bash tools/run_lua_project_data.sh luajit lua/test/recognition_transaction_contract_test.lua

log "running exact Perl typed source-location value, projection, and recursive-observation admission consumers"
PERL5LIB= prove -Iperl t/typed_source_location_values.t t/typed_source_location_perl_contract.t t/recursive_observation_perl_contract.t

log "running exact Rust typed source-location value and projection admission consumer"
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test typed_source_location_contract --test recursive_observation_contract

log "running exact Dart typed source-location value, projection, and recursive-observation admission consumers"
(cd dart && bash ../tools/run_dart_project_data.sh test --reporter failures-only test/typed_source_location_contract_test.dart test/recursive_observation_contract_test.dart)

log "running exact Julia typed source-location value and projection admission consumer"
bash tools/run_julia_project_data.sh --project=julia --startup-file=no --history-file=no -e 'using LinkedSpecJulia, JSON3, Test; include("julia/test/typed_source_location_contract_test.jl"); include("julia/test/recursive_observation_contract_test.jl")'

log "running exact Lua typed source-location value, projection, and recursive-observation admission consumers on PUC Lua"
bash tools/run_lua_project_data.sh puc lua/test/typed_source_location_contract_test.lua
bash tools/run_lua_project_data.sh puc lua/test/recursive_observation_contract_test.lua

log "running exact Lua typed source-location value, projection, and recursive-observation admission consumers on LuaJIT"
bash tools/run_lua_project_data.sh luajit lua/test/typed_source_location_contract_test.lua
bash tools/run_lua_project_data.sh luajit lua/test/recursive_observation_contract_test.lua

log "checking backend-neutral root-rule selection contract"
bash tools/run_python_project_data.sh tools/check_root_rule_selection_contract.py

log "checking backend-neutral semantic introspection model/query contract"
bash tools/run_python_project_data.sh tools/check_semantic_introspection_contract.py

log "checking exact MCP transport materialization"
bash tools/run_python_project_data.sh tools/materialize_mcp_semantic_transport_contract.py

log "independently validating the MCP transport contract"
bash tools/run_python_project_data.sh tools/check_mcp_semantic_transport_contract.py

log "checking the generated filesystem-free Perl MCP contract binding"
bash tools/run_python_project_data.sh tools/generate_perl_mcp_contract.py

log "checking the generated filesystem-free Rust MCP contract binding"
bash tools/run_python_project_data.sh tools/generate_rust_mcp_contract.py

log "checking the generated filesystem-free Dart MCP contract binding"
bash tools/run_python_project_data.sh tools/generate_dart_mcp_contract.py

log "checking the generated filesystem-free Julia MCP contract binding"
bash tools/run_python_project_data.sh tools/generate_julia_mcp_contract.py

log "checking the generated filesystem-free Lua MCP contract binding"
bash tools/run_python_project_data.sh tools/generate_lua_mcp_contract.py

log "running Perl MCP contract-binding, decoded-dispatch, and strict-stdio proof"
PERL5LIB= prove -Iperl t/mcp_contract_perl_binding.t t/mcp_server_perl_dispatch.t t/mcp_server_perl_stdio.t

log "running Rust MCP frozen-runtime, secure-registry, decoded-dispatch, strict-stdio, and exact-admission proof"
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --lib mcp_
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test mcp_server_rust_dispatch
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test mcp_server_rust_stdio
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test mcp_server_rust_admission

log "running Dart MCP generated-binding, frozen-runtime, secure-registry, decoded-dispatch, and strict-stdio proof"
(
 cd "$REPO_ROOT/dart"
 bash ../tools/run_dart_project_data.sh test test/mcp_contract_dart_binding_test.dart test/mcp_server_dart_dispatch_test.dart test/mcp_server_dart_stdio_test.dart
)

log "running exact Dart MCP admission consumer"
(
 cd "$REPO_ROOT/dart"
 bash ../tools/run_dart_project_data.sh test test/mcp_server_dart_admission_test.dart
)

log "running Julia MCP generated-binding, frozen-runtime, secure-registry, decoded-dispatch, and strict-stdio proof"
bash tools/run_julia_project_data.sh --project=julia -e 'using LinkedSpecJulia, Test; const REPO_ROOT=pwd(); include("julia/test/mcp_contract_julia_binding_test.jl"); include("julia/test/mcp_server_julia_dispatch_test.jl"); include("julia/test/mcp_server_julia_stdio_test.jl")'

log "running exact Julia MCP admission consumer"
bash tools/run_julia_project_data.sh --project=julia -e 'using LinkedSpecJulia, Test; const REPO_ROOT=pwd(); include("julia/test/mcp_server_julia_admission_test.jl")'

log "running exact shared Lua MCP admission consumer on PUC Lua"
bash tools/run_lua_project_data.sh puc lua/test/mcp_server_lua_admission_test.lua

log "running exact shared Lua MCP admission consumer on LuaJIT"
bash tools/run_lua_project_data.sh luajit lua/test/mcp_server_lua_admission_test.lua

log "checking MCP implementation/runtime admission ledger"
bash tools/run_python_project_data.sh tools/check_mcp_implementation_admission.py

log "running exact Perl MCP admission consumer"
PERL5LIB= prove -Iperl t/mcp_server_perl_admission.t

log "running Perl semantic-index source/map/outcome foundation"
PERL5LIB= prove -Iperl t/semantic_index_perl_foundation.t

log "running Perl semantic-index static graph/diagnostic projection"
PERL5LIB= prove -Iperl t/semantic_index_perl_static_projection.t

log "running Perl semantic-index call/staged/generated projection"
PERL5LIB= prove -Iperl t/semantic_index_perl_calls_projection.t

log "running Perl immutable semantic capabilities/query evaluator"
PERL5LIB= prove -Iperl t/semantic_index_perl_query.t

log "running Perl typed runtime semantic observation and route projection"
PERL5LIB= prove -Iperl t/semantic_index_perl_runtime_observation.t

log "running composed Perl semantic-introspection admission consumer"
PERL5LIB= prove -Iperl t/semantic_introspection_perl_admission.t

log "running composed Rust semantic-introspection admission consumer"
cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test semantic_introspection_rust_admission

log "running composed Dart semantic-introspection admission consumer"
(
 cd "$REPO_ROOT/dart"
 bash ../tools/run_dart_project_data.sh test test/semantic_introspection_dart_admission_test.dart
)

log "running composed Julia semantic-introspection admission consumer"
julia --project=julia --startup-file=no --history-file=no --compiled-modules=no julia/test/semantic_introspection_julia_admission_test.jl

log "checking backend-neutral duplicate regex-slot identity contract"
bash tools/run_python_project_data.sh tools/check_duplicate_regex_slot_identity_contract.py

log "running composed Perl duplicate regex-slot identity consumer"
PERL5LIB= prove -Iperl t/duplicate_regex_slot_identity_perl_contract.t

log "running Perl sparse-AND action-slot regression consumer"
PERL5LIB= prove -Iperl t/sparse_and_action_slots_perl_regression.t

log "checking backend-neutral explicit-repetition action-result contract"
bash tools/run_python_project_data.sh tools/check_repeated_action_result_contract.py

log "running composed Perl explicit-repetition action-result consumer"
PERL5LIB= prove -Iperl t/repeated_action_result_perl_contract.t

log "checking backend-neutral standalone lifecycle-block contract"
bash tools/run_python_project_data.sh tools/check_standalone_lifecycle_block_contract.py

log "running permanent self-hosted standalone lifecycle-block consumer"
PERL5LIB= prove -Iperl t/standalone_lifecycle_block_self_hosted_contract.t

log "checking the SExprDocumentV1 authored contract across all six runtimes"
bash tools/check_sexpr_document_v1.sh

log "running focused Perl root-rule selection core consumer"
PERL5LIB= prove -Iperl t/root_rule_selection_perl_core.t

log "running focused Perl root-rule loaded/generated/trace consumer"
PERL5LIB= prove -Iperl t/root_rule_selection_perl_routes.t

log "running composed Perl rule-local cursor admission consumer"
PERL5LIB= prove -Iperl t/rule_local_cursor_perl_contract.t

log "checking portable callable-signature contract"
bash tools/run_python_project_data.sh tools/check_callable_signature_contract.py

log "checking portable callable-codeblock contract"
bash tools/run_python_project_data.sh tools/check_callable_codeblock_contract.py

log "checking complete named-mark helper contract"
bash tools/run_python_project_data.sh tools/check_complete_named_mark_contract.py

log "checking backend-neutral diagnostic-output event contract"
bash tools/run_python_project_data.sh tools/check_diagnostic_output_contract.py

printf '%s\n' '[ci-local] Perl diagnostic-output event contract'
PERL5LIB= prove -Iperl t/diagnostic_output_perl_contract.t

log "running Perl complete named-mark behavior contract fixture"
PERL5LIB= prove -Iperl t/complete_named_mark_contract.t

log "checking punctuation-light zero-argument syntax contract"
bash tools/run_python_project_data.sh tools/check_punctuation_light_zero_arg_contract.py

log "running Perl punctuation-light zero-argument behavior contract fixture"
PERL5LIB= prove -Iperl t/punctuation_light_zero_arg_contract.t

log "checking portable uniform-binding and aggregate-selector retirement contract"
bash tools/run_python_project_data.sh tools/check_uniform_binding_contract.py

log "checking uniform-binding mutation-result public surface"
bash tools/run_python_project_data.sh tools/check_uniform_binding_mutation_result_surface.py

log "checking mutation public-current teaching and no-drift"
bash tools/run_python_project_data.sh tools/check_mutation_public_surface.py

log "checking final public aggregate-selector retirement admission"
bash tools/run_python_project_data.sh tools/check_public_aggregate_selector_surface.py

log "running Perl uniform-binding behavior contract fixture"
PERL5LIB= prove -Iperl t/uniform_binding_contract.t

log "running Perl callable-codeblock literal contract fixture"
PERL5LIB= prove -Iperl t/callable_codeblock_literal_contract.t

log "running Perl signed-array selector contract and public route fixture"
PERL5LIB= prove -Iperl t/signed_array_selector_perl_contract.t

log "running Perl deferred push composition and caller-identity fixture"
PERL5LIB= prove -Iperl t/codeblock_push_composition_perl.t

log "running Perl call-form normalization source and native/fresh object controls"
PERL5LIB= prove -Iperl t/composed_normalization_perl.t

log "running Perl variadic user-function contract fixture"
PERL5LIB= prove -Iperl t/variadic_user_function_contract.t

log "checking generated-source capability contract"
perl tools/check_generated_source_contract.pl

log "running Perl generated-source contract fixture"
PERL5LIB= prove -Iperl t/generated_source_contract.t

log "running neutral scalar-to-text contract fixture"
PERL5LIB= prove -Iperl t/scalar_text_contract.t

log "running Perl scalar numeric contract fixture"
PERL5LIB= prove -Iperl t/scalar_numeric_contract.t

log "checking native named/file resolution contract"
perl tools/check_native_spec_resolution_contract.pl

log "running Perl native named/file resolution fixture"
PERL5LIB= prove -Iperl t/native_spec_resolution.t

log "checking exhaustive current ActionIR documentation and neutral corpus coverage"
perl tools/check_language_capability_coverage.pl

log "running ActionIR AST parser focused suite"
prove -Iperl t/actionir_ast_parser.t

log "running scalar receiver-copy regression suite"
prove -Iperl t/actionir_receiver_scalar_copy.t

log "running source-bound raw dependency readiness and provenance suites"
PERL5LIB= prove -Iperl t/actionir_raw_dependency_metadata.t t/actionir_raw_dependency_provenance.t t/actionir_nested_block_source_spans.t t/actionir_raw_dependency_compatibility.t

# PERL-PRIVATE-FACTORY-CAPTURE.7: exact supplied fixture admission.
private_factory_suites=(
 t/actionir_method_input_captures.t
 t/actionir_method_argument_source_frames.t
 t/actionir_empty_expression_spans.t
 t/actionir_ast_input_frames.t
 t/actionir_ast_constructions.t
 t/actionir_ast_parser.t
 t/actionir_source_emissions.t
 t/canonical_event_occurrence_order.t
 t/actionir_nested_block_source_spans.t
 t/actionir_compiler_source_membership.t
 t/actionir_executable_source_membership.t
 t/trace_actionir_method_lowering.t
 t/trace_emit_context_bridge.t
 docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.7.2.2.0.3.1.0-origin-fixture.t
 t/actionir_event_input_grants.t
 t/actionir_input_composition_acceptance.t
 t/actionir_factory_capture.t
 t/actionir_emit_context_capture.t
 t/actionir_emit_context_capture_cold.t
 t/actionir_contract_dependency_capture.t
 t/actionir_contract_dependency_capture_cold.t
 t/actionir_contract_factory_capture.t
 t/actionir_contract_factory_capture_cold.t
 t/actionir_method_default_capture.t
 t/actionir_method_default_capture_cold.t
 t/actionir_method_trim_capture.t
 t/actionir_method_trim_capture_cold.t
 t/actionir_method_inference_capture.t
 t/actionir_method_inference_capture_cold.t
 t/actionir_method_inline_capture.t
 t/actionir_method_inline_capture_cold.t
 t/actionir_method_block_component_capture.t
 t/actionir_method_block_component_capture_cold.t
 t/actionir_method_local_return_capture.t
 t/actionir_method_local_return_capture_cold.t
 t/actionir_method_block_value_capture.t
 t/actionir_method_block_value_capture_cold.t
 t/actionir_method_ast_hash_key_capture.t
 t/actionir_method_ast_hash_key_capture_cold.t
 t/actionir_method_ast_call_capture.t
 t/actionir_method_ast_call_capture_cold.t
 t/actionir_method_ast_array_end_capture.t
 t/actionir_method_ast_array_end_capture_cold.t
 t/uniform_binding_contract.t
 t/actionir_method_ast_assignment_capture.t
 t/actionir_method_ast_assignment_capture_cold.t
 t/actionir_method_value_capture.t
 t/actionir_method_value_capture_cold.t
 t/actionir_method_slot_capture.t
 t/actionir_method_slot_capture_cold.t
 t/actionir_method_general_return_capture.t
 t/actionir_method_general_return_capture_cold.t
 t/actionir_method_assignment_required_capture.t
 t/actionir_method_assignment_required_capture_cold.t
 t/actionir_method_set_key_required_capture.t
 t/actionir_method_set_key_required_capture_cold.t
 t/actionir_method_push_required_capture.t
 t/actionir_method_push_required_capture_cold.t
 t/actionir_method_regex_undef_required_capture.t
 t/actionir_method_regex_undef_required_capture_cold.t
 t/actionir_receiver_scalar_copy.t
 t/actionir_array_receiver_required_capture.t
 t/actionir_scalar_receiver_required_capture.t
 t/actionir_hash_receiver_required_capture.t
 t/actionir_array_end_required_capture.t
 t/actionir_hash_index_required_capture.t
 t/actionir_package_flow_capture.t
 t/actionir_dropped_trim_capture.t
 t/actionir_small_kind_capture.t
 t/actionir_uniform_target.t
 t/actionir_method_kind_capture.t
 t/actionir_source_assignment_kind_capture.t
 t/actionir_ast_optional_capture.t
 t/actionir_tracking_predicate_capture.t
 t/actionir_formal_trim_capture.t
 t/actionir_named_dispatch_capture.t
 t/actionir_flow_required_capture.t
 t/actionir_flow_kind_capture.t
 t/actionir_flow_default_capture.t
 t/actionir_control_foundation_capture.t
 t/actionir_control_expansion_capture.t
 t/actionir_control_attached_capture.t
 t/actionir_control_single_capture.t
 t/actionir_control_ifwhile_capture.t
 t/actionir_control_switch_capture.t
 t/diagnostic_output_perl_contract.t
 t/actionir_control_output_capture.t
 t/actionir_control_kind_capture.t
 t/actionir_control_calls_capture.t
 t/actionir_control_default_capture.t
 t/actionir_default_object_capture.t
)
private_factory_helpers=(
 t/actionir_array_end_required_cold_probe.pl
 t/actionir_array_end_required_probe.pl
 t/actionir_array_receiver_required_cold_probe.pl
 t/actionir_array_receiver_required_probe.pl
 t/actionir_ast_optional_probe.pl
 t/actionir_ast_optional_stable_probe.pl
 t/actionir_control_attached_native_fixed.pl
 t/actionir_control_calls_native_complete.pl
 t/actionir_control_default_native.pl
 t/actionir_control_expansion_native.pl
 t/actionir_control_foundation_native.pl
 t/actionir_control_ifwhile_native.pl
 t/actionir_control_ifwhile_native_complete.pl
 t/actionir_control_kind_native_complete.pl
 t/actionir_control_output_native.pl
 t/actionir_control_output_native_complete.pl
 t/actionir_control_single_native.pl
 t/actionir_control_switch_native.pl
 t/actionir_default_object_native.pl
 t/actionir_dropped_trim_cold_probe.pl
 t/actionir_dropped_trim_probe.pl
 t/actionir_flow_default_native.pl
 t/actionir_flow_kind_native.pl
 t/actionir_flow_required_native.pl
 t/actionir_formal_trim_probe.pl
 t/actionir_hash_index_required_cold_probe.pl
 t/actionir_hash_index_required_probe.pl
 t/actionir_hash_receiver_required_cold_probe.pl
 t/actionir_hash_receiver_required_probe.pl
 t/actionir_legacy_hash_kind_cold_probe.pl
 t/actionir_legacy_hash_kind_probe.pl
 t/actionir_method_kind_authority_probe.pl
 t/actionir_method_kind_probe.pl
 t/actionir_method_regex_undef_required_probe.pl
 t/actionir_named_dispatch_probe.pl
 t/actionir_package_flow_cold_probe.pl
 t/actionir_package_flow_probe.pl
 t/actionir_receiver_scalar_copy_probe.pl
 t/actionir_scalar_receiver_required_cold_probe.pl
 t/actionir_scalar_receiver_required_probe.pl
 t/actionir_small_kind_probe.pl
 t/actionir_small_kind_reference_probe.pl
 t/actionir_small_kind_symbolic_probe.pl
 t/actionir_source_assignment_kind_probe.pl
 t/actionir_tracking_predicate_probe.pl
 t/actionir_uniform_target_probe.pl
)
log "checking complete private factory fixture inputs and syntax"
for private_factory_input in "${private_factory_suites[@]}" "${private_factory_helpers[@]}"; do
 require_tracked_file "$private_factory_input"
 perl -c -Iperl "$private_factory_input"
done
log "running complete supplied private factory regression population"
LINKEDSPEC_EVENT_ORDER_BASELINE=0 LINKEDSPEC_MEMBERSHIP_BASELINE=0 PERL5LIB= PERL5OPT= prove -Iperl "${private_factory_suites[@]}"

log "running codegen-inspector explicit-owner smoke suite"
PERL5LIB= prove -Iperl t/inspect_spec_codegen.t

log "running primary CLI runner and focused trace suites"
PERL5LIB= prove -Iperl t/cli_conformance_runner.t t/trace_cli.t

log "proving Perl project data stays in managed repository storage"
bash "$REPO_ROOT/tools/test_perl_project_data_storage.sh"

log "proving Python and tool output stays in managed repository storage"
bash "$REPO_ROOT/tools/test_tool_project_data_storage.sh"

log "proving representative process IO stays within repository storage and necessary reads"
bash "$REPO_ROOT/tools/test_project_data_process_locality.sh"

log "proving relocated named-spec execution across all five primary runtime anchors"
bash "$REPO_ROOT/tools/test_repo_root_process_portability.sh"

log "running primary CLI conformance (default option environment)"
PERL5LIB= perl tools/run_cli_conformance.pl \
 --display-command 'perl bin/linkedspec' \
 -- perl -I{{REPO_ROOT}}/perl {{REPO_ROOT}}/bin/linkedspec

log "running primary CLI conformance (POSIX option environment)"
POSIXLY_CORRECT=1 PERL5LIB= perl tools/run_cli_conformance.pl \
 --display-command 'perl bin/linkedspec' \
 -- perl -I{{REPO_ROOT}}/perl {{REPO_ROOT}}/bin/linkedspec

# Memory guard — bail if system RAM is critically low before running the heavy suite
_ram_used_pct() {
  if [[ "$(uname -s)" == "Darwin" ]]; then
    local page_size free_pages inactive_pages speculative_pages total_ram avail_pages
    page_size=$(pagesize 2>/dev/null || echo 16384)
    free_pages=$(vm_stat 2>/dev/null | awk '/Pages free/               {print $NF}' | tr -d '.')
    inactive_pages=$(vm_stat 2>/dev/null | awk '/Pages inactive/         {print $NF}' | tr -d '.')
    speculative_pages=$(vm_stat 2>/dev/null | awk '/Pages speculative/    {print $NF}' | tr -d '.')
    avail_pages=$(( ${free_pages:-0} + ${inactive_pages:-0} + ${speculative_pages:-0} ))
    total_ram=$(sysctl -n hw.memsize 2>/dev/null || echo 17179869184)
    echo $(( 100 - (avail_pages * page_size * 100 / total_ram) ))
  else
    awk '/MemTotal/{t=$2} /MemAvailable/{a=$2} END{printf "%d", 100-(a*100/t)}' /proc/meminfo 2>/dev/null || echo 0
  fi
}
GUARD_PCT=$(_ram_used_pct)
DANGER_PCT="${LINKEDSPEC_TEST_DANGER_PCT:-88}"
if [[ "${GUARD_PCT}" -ge "${DANGER_PCT}" ]]; then
  fail "RAM ${GUARD_PCT}% used (danger threshold ${DANGER_PCT}%) — refusing to run heavy suite. Free RAM and retry, or set LINKEDSPEC_TEST_DANGER_PCT higher."
fi
log "RAM ${GUARD_PCT}% used — within threshold (${DANGER_PCT}%)"

log "running phase0 regression suite"
prove -v -Iperl t/phase0_regression.t

if [[ "${LINKEDSPEC_RUN_RUST:-0}" == "1" ]]; then
 log "running optional Rust local gate (LINKEDSPEC_RUN_RUST=1)"
 require_tracked_file tools/run_rust_local.sh
 bash "$REPO_ROOT/tools/run_rust_local.sh"
else
 log "skipping optional Rust local gate (set LINKEDSPEC_RUN_RUST=1 to include it when a Rust toolchain is available)"
fi

if [[ "${LINKEDSPEC_RUN_DART:-0}" == "1" ]]; then
 log "running optional Dart local gate (LINKEDSPEC_RUN_DART=1)"
 require_tracked_file tools/run_dart_local.sh
 bash "$REPO_ROOT/tools/run_dart_local.sh"
else
 log "skipping optional Dart local gate (set LINKEDSPEC_RUN_DART=1 to include it when a Dart SDK is available)"
fi

if [[ "${LINKEDSPEC_RUN_JULIA:-0}" == "1" ]]; then
 log "running optional Julia local gate (LINKEDSPEC_RUN_JULIA=1)"
 require_tracked_file tools/run_julia_local.sh
 bash "$REPO_ROOT/tools/run_julia_local.sh"
else
 log "skipping optional Julia local gate (set LINKEDSPEC_RUN_JULIA=1 to include it when a Julia SDK is available)"
fi

if [[ "${LINKEDSPEC_RUN_LUA:-0}" == "1" ]]; then
 log "running optional dual-ABI Lua local gate (LINKEDSPEC_RUN_LUA=1)"
 require_tracked_file tools/run_lua_local.sh
 bash "$REPO_ROOT/tools/run_lua_local.sh"
else
 log "skipping optional dual-ABI Lua local gate (set LINKEDSPEC_RUN_LUA=1 when PUC Lua and LuaJIT are available)"
fi

if [[ "${LINKEDSPEC_RUN_CLI_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend primary CLI matrix (LINKEDSPEC_RUN_CLI_MATRIX=1)"
 require_tracked_file tools/run_primary_cli_matrix.sh
 bash "$REPO_ROOT/tools/run_primary_cli_matrix.sh"
 bash "$REPO_ROOT/tools/run_primary_cli_matrix.sh" --manifest unicode_case/self_hosted_cli/manifest.json
else
 log "skipping optional five-backend primary CLI matrix (set LINKEDSPEC_RUN_CLI_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_SEMANTIC_MATRIX:-0}" == "1" ]]; then
 log "running optional six-runtime semantic-introspection matrix (LINKEDSPEC_RUN_SEMANTIC_MATRIX=1)"
 require_tracked_file tools/check_semantic_introspection_six_runtime.sh
 bash "$REPO_ROOT/tools/check_semantic_introspection_six_runtime.sh"
else
 log "skipping optional six-runtime semantic-introspection matrix (set LINKEDSPEC_RUN_SEMANTIC_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_MCP_MATRIX:-0}" == "1" ]]; then
 log "running optional six-runtime MCP composition matrix (LINKEDSPEC_RUN_MCP_MATRIX=1)"
 require_tracked_file tools/check_mcp_six_runtime.sh
 bash "$REPO_ROOT/tools/check_mcp_six_runtime.sh"
else
 log "skipping optional six-runtime MCP composition matrix (set LINKEDSPEC_RUN_MCP_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_TYPED_SOURCE_MATRIX:-0}" == "1" ]]; then
 log "running optional six-runtime typed source-location matrix (LINKEDSPEC_RUN_TYPED_SOURCE_MATRIX=1)"
 require_tracked_file tools/check_typed_source_location_six_runtime.sh
 bash "$REPO_ROOT/tools/check_typed_source_location_six_runtime.sh"
else
 log "skipping optional six-runtime typed source-location matrix (set LINKEDSPEC_RUN_TYPED_SOURCE_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_RECURSIVE_OBSERVATION_MATRIX:-0}" == "1" ]]; then
 log "running optional six-runtime recursive-observation matrix (LINKEDSPEC_RUN_RECURSIVE_OBSERVATION_MATRIX=1)"
 require_tracked_file tools/check_recursive_observation_six_runtime.sh
 bash "$REPO_ROOT/tools/check_recursive_observation_six_runtime.sh"
else
 log "skipping optional six-runtime recursive-observation matrix (set LINKEDSPEC_RUN_RECURSIVE_OBSERVATION_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_PROGRESSIVE_SPAN_MATRIX:-0}" == "1" ]]; then
 log "running optional six-runtime progressive span-dispatch matrix (LINKEDSPEC_RUN_PROGRESSIVE_SPAN_MATRIX=1)"
 require_tracked_file tools/check_progressive_span_dispatch_six_runtime.sh
 bash "$REPO_ROOT/tools/check_progressive_span_dispatch_six_runtime.sh"
else
 log "skipping optional six-runtime progressive span-dispatch matrix (set LINKEDSPEC_RUN_PROGRESSIVE_SPAN_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_STAGED_AST_ENRICHMENT_MATRIX:-0}" == "1" ]]; then
 log "running optional six-runtime staged-AST enrichment matrix (LINKEDSPEC_RUN_STAGED_AST_ENRICHMENT_MATRIX=1)"
 require_tracked_file tools/check_staged_ast_enrichment_six_runtime.sh
 bash "$REPO_ROOT/tools/check_staged_ast_enrichment_six_runtime.sh"
else
 log "skipping optional six-runtime staged-AST enrichment matrix (set LINKEDSPEC_RUN_STAGED_AST_ENRICHMENT_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_TYPED_AUTHORING_MODEL_MATRIX:-0}" == "1" ]]; then
 log "running optional composed typed authoring-model matrix (LINKEDSPEC_RUN_TYPED_AUTHORING_MODEL_MATRIX=1)"
 require_tracked_file tools/check_typed_authoring_model_six_runtime.sh
 bash "$REPO_ROOT/tools/check_typed_authoring_model_six_runtime.sh"
else
 log "skipping optional composed typed authoring-model matrix (set LINKEDSPEC_RUN_TYPED_AUTHORING_MODEL_MATRIX=1 to run all six existing recurring authorities)"
fi

if [[ "${LINKEDSPEC_RUN_INTER_MATCH_GAP_MATRIX:-0}" == "1" ]]; then
 log "running optional inter-match gap-capture six-runtime route (LINKEDSPEC_RUN_INTER_MATCH_GAP_MATRIX=1)"
 require_tracked_file tools/check_inter_match_gap_capture_six_runtime.sh
 bash "$REPO_ROOT/tools/check_inter_match_gap_capture_six_runtime.sh"
else
 log "skipping optional inter-match gap-capture six-runtime route (set LINKEDSPEC_RUN_INTER_MATCH_GAP_MATRIX=1 to re-run the current neutral plus six-runtime proof)"
fi

if [[ "${LINKEDSPEC_RUN_TYPED_GAP_COMPOSITION_MATRIX:-0}" == "1" ]]; then
 log "running optional typed lossless-gap composition route (LINKEDSPEC_RUN_TYPED_GAP_COMPOSITION_MATRIX=1)"
 require_tracked_file tools/check_typed_gap_composition_six_runtime.sh
 bash "$REPO_ROOT/tools/check_typed_gap_composition_six_runtime.sh"
else
 log "skipping optional typed lossless-gap composition route (set LINKEDSPEC_RUN_TYPED_GAP_COMPOSITION_MATRIX=1 to recompose the current typed contract, six gap runtimes, and support ledgers)"
fi

if [[ "${LINKEDSPEC_RUN_RECOGNITION_TRANSACTION_MATRIX:-0}" == "1" ]]; then
 log "running optional six-runtime recognition-transaction matrix (LINKEDSPEC_RUN_RECOGNITION_TRANSACTION_MATRIX=1)"
 require_tracked_file tools/check_recognition_transaction_six_runtime.sh
 bash "$REPO_ROOT/tools/check_recognition_transaction_six_runtime.sh"
else
 log "skipping optional six-runtime recognition-transaction matrix (set LINKEDSPEC_RUN_RECOGNITION_TRANSACTION_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_MUTATION_MATRIX:-0}" == "1" ]]; then
 log "running optional six-runtime mutation matrix (LINKEDSPEC_RUN_MUTATION_MATRIX=1)"
 require_tracked_file tools/check_mutation_six_runtime.sh
 bash "$REPO_ROOT/tools/check_mutation_six_runtime.sh"
else
 log "skipping optional six-runtime mutation matrix (set LINKEDSPEC_RUN_MUTATION_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_CALLABLE_CODEBLOCK_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend callable-codeblock matrix (LINKEDSPEC_RUN_CALLABLE_CODEBLOCK_MATRIX=1)"
 require_tracked_file tools/check_callable_codeblock_five_backend.sh
 bash "$REPO_ROOT/tools/check_callable_codeblock_five_backend.sh"
else
 log "skipping optional five-backend callable-codeblock matrix (set LINKEDSPEC_RUN_CALLABLE_CODEBLOCK_MATRIX=1 when all five backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_DIAGNOSTIC_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend diagnostic-output matrix (LINKEDSPEC_RUN_DIAGNOSTIC_MATRIX=1)"
 require_tracked_file tools/check_diagnostic_output_five_backend.sh
 bash "$REPO_ROOT/tools/check_diagnostic_output_five_backend.sh"
else
 log "skipping optional five-backend diagnostic-output matrix (set LINKEDSPEC_RUN_DIAGNOSTIC_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_LOGICAL_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend logical-helper matrix (LINKEDSPEC_RUN_LOGICAL_MATRIX=1)"
 require_tracked_file tools/check_logical_helper_five_backend.sh
 bash "$REPO_ROOT/tools/check_logical_helper_five_backend.sh"
else
 log "skipping optional five-backend logical-helper matrix (set LINKEDSPEC_RUN_LOGICAL_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_ROOT_RULE_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend root-rule selection matrix (LINKEDSPEC_RUN_ROOT_RULE_MATRIX=1)"
 require_tracked_file tools/check_root_rule_selection_five_backend.sh
 bash "$REPO_ROOT/tools/check_root_rule_selection_five_backend.sh"
else
 log "skipping optional five-backend root-rule selection matrix (set LINKEDSPEC_RUN_ROOT_RULE_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_CURSOR_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend rule-local cursor matrix (LINKEDSPEC_RUN_CURSOR_MATRIX=1)"
 require_tracked_file tools/check_rule_local_cursor_five_backend.sh
 bash "$REPO_ROOT/tools/check_rule_local_cursor_five_backend.sh"
else
 log "skipping optional five-backend rule-local cursor matrix (set LINKEDSPEC_RUN_CURSOR_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_DUPLICATE_SLOT_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend duplicate regex-slot matrix (LINKEDSPEC_RUN_DUPLICATE_SLOT_MATRIX=1)"
 require_tracked_file tools/check_duplicate_regex_slot_identity_five_backend.sh
 bash "$REPO_ROOT/tools/check_duplicate_regex_slot_identity_five_backend.sh"
else
 log "skipping optional five-backend duplicate regex-slot matrix (set LINKEDSPEC_RUN_DUPLICATE_SLOT_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_REPEATED_ACTION_RESULT_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend repeated action-result matrix (LINKEDSPEC_RUN_REPEATED_ACTION_RESULT_MATRIX=1)"
 require_tracked_file tools/check_repeated_action_result_five_backend.sh
 bash "$REPO_ROOT/tools/check_repeated_action_result_five_backend.sh"
else
 log "skipping optional five-backend repeated action-result matrix (set LINKEDSPEC_RUN_REPEATED_ACTION_RESULT_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_STANDALONE_LIFECYCLE_BLOCK_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend standalone lifecycle-block matrix (LINKEDSPEC_RUN_STANDALONE_LIFECYCLE_BLOCK_MATRIX=1)"
 require_tracked_file tools/check_standalone_lifecycle_block_five_backend.sh
 bash "$REPO_ROOT/tools/check_standalone_lifecycle_block_five_backend.sh"
else
 log "skipping optional five-backend standalone lifecycle-block matrix (set LINKEDSPEC_RUN_STANDALONE_LIFECYCLE_BLOCK_MATRIX=1 when all backend toolchains are available)"
fi

if [[ "${LINKEDSPEC_RUN_PUNCTUATION_MATRIX:-0}" == "1" ]]; then
 log "running optional five-backend punctuation-light matrix (LINKEDSPEC_RUN_PUNCTUATION_MATRIX=1)"
 require_tracked_file tools/check_punctuation_light_five_backend.sh
 bash "$REPO_ROOT/tools/check_punctuation_light_five_backend.sh"
else
 log "skipping optional five-backend punctuation-light matrix (set LINKEDSPEC_RUN_PUNCTUATION_MATRIX=1 when all backend toolchains are available)"
fi

"$REPO_ROOT/tools/verification_receipt.sh" write-staged "$CANONICAL_GATE_FINGERPRINT"
log "local CI gate passed"
