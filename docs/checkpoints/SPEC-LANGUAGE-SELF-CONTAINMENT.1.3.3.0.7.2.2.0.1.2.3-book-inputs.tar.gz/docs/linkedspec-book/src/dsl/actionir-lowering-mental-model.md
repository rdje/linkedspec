# ActionIR Lowering Mental Model

ActionIR is the bridge between LinkedSpec action syntax and emitted runtime code.

It exists because the project does not want `.spec` files to remain tied forever to raw Perl fragments. The target is a cleaner semantic layer:

```text
.spec helper DSL -> canonical ActionIR -> emitted backend code
```

Today the emitted backend is Perl. The direction is backend-neutrality.

## Why not just keep raw Perl?

Raw Perl is powerful, but it has a cost:

- it is hard to validate structurally
- it is hard to translate to non-Perl backends
- it hides parser intent inside host-language details
- it makes examples harder for new users to generalize

Helper DSL makes common parser actions explicit.

Instead of asking readers to understand a substring expression, a mutable array push, and a return shape all at once, a rule can say:

```text
name = entry_group(0);
push(items, name);
return(hash("kind", "names", "items", copy(items)));
```

That is still compact, but it is more self-describing.

## A simple lowering example

Source-level helper DSL:

```text
name = entry_group(0);
return(hash("kind", "token", "name", name));
```

Semantic reading:

- write the first entry capture group to local scalar `name`
- return a structured payload with a fixed `kind` and the captured `name`

The exact emitted Perl is an implementation detail for most users. What matters is that these helper forms describe operations LinkedSpec can reason about.

## Current Helper Forms

Public `.spec` actions should use the current helper surface:

```text
retv = call(Child);
push(items, retv);
```

Deleted helper names are not part of the contract resolver. A backend may still report
an unknown-helper diagnostic for an unrecognized helper-looking call, but that is not a
compatibility path and it does not lower through a name-specific replacement table.

## What counts as a good helper form?

A good helper form should make these questions easy to answer:

- What value is being read?
- What value is being written?
- Which parser boundary or mark is being used?
- Does the helper mutate a boundary or only read it?
- Is the result a scalar, array, hash, boolean, or rule call?

That is why recent naming work strongly favors explicit names such as:

- `capture_rest_from(name)`
- `capture_take_until_cursor_len_from(name)`
- `dependency_regex_map`
- `dependency_refs`

Names should reduce guessing.

## How to learn the surface

Start with the core families:

- `set(...)` for writing values
- `return(...)` for returning payloads
- bare scalar reads plus `array(...)` / `hash(...)` for value construction
- `entry_*` and `match_*` readers for match data
- `capture_*` and `mark_*` helpers for parser boundary work
- `if(...)` and `switch` helpers for structured control flow

Then move into the more specialized helper families as needed.

## The lowering pipeline

The lowering *pipeline* — discover which helper contracts are present, split statements, canonicalize helpers into ActionIR events, then dispatch each to a lowering owner before emitting backend code — is a **backend-neutral** sequence. The specific owner modules named in this section (`ActionIR::Scanner`, `ScannerCore`, `StatementSplit`, `CanonicalEvents`, `RewritePipeline`, the per-family lowering owners, and `ActionIR::Contracts`) are the **Perl reference backend's** realization of those stages; another backend organizes the same scan → split → canonicalize → lower → emit flow in its own modules.

ActionIR lowering is not one monolithic pass. It flows through a pipeline of owners, each responsible for one stage:

```text
source rule paragraph text
  -> Scanner (contract discovery)
  -> StatementSplit (safe statement splitting)
  -> CanonicalEvents (normalize helpers into canonical ActionIR)
  -> RewritePipeline (glue scan/classify/lower phases)
  -> FlowExpr / ValueExpr / ControlFlow / MethodLowering / DeclareMethod / ArrayPipeline
  -> Emit (final backend code generation — Perl in the reference backend)
```

### Scanner

`ActionIR::Scanner` discovers which helper contracts are present in a rule's action text. It uses a registry of scanner rule families (`PrimitiveBasicRules`, `PrimitivePipelineRules`, `FlowRules`, `LegacyRules`) to match helper syntax patterns and classify them into contract families. `ScannerCore` is the single source of truth for the scanner dependency contract — the mapping between recognized helper patterns and their lowering handlers.

The pipeline family has a separately retained nineteen-contract diagnosis. Eleven contracts
scan the original full input, while eight select original statements; nested hash assignment
and value-only expressions each have two event-construction branches. The diagnostic source
repeats literal receivers and structured plans around Unicode, CRLF, quoted helper text and
ignored comments. Its public and private scans keep the same arguments and dependency
callback inputs/results. All eleven full-input regex pipeline contracts now retain private
source origins; ten new hooks preserve the existing `set_value` channel. Match coordinates
and raw expressions are captured before parser/planner callbacks, and recording keeps the
original event and argument objects. All eight statement contracts now carry original
occurrence frames through their ten existing event constructors. The supplied splitter runs
once and returns its original array. Ignored statements still advance the frame index;
copied, changed, opaque or foreign-source arrays supply no occurrence authority.
Quoted matches are syntactic observations, not executable membership.

For repeated calls, the private channel identifies each original occurrence:

```perl
my $result = LinkedSpec::ActionIR::ScannerCore::_scan_contract_ir_events_with_provenance(
    {id => 'push'}, "push(items, '雪'); push(items, '雪');", $scanner_deps
);
# source_origins spans: [0, 16), [18, 34)
```

The same original-owner regression first fails for the ten missing hooks, then passes for
all eleven regex contracts; empty and rejected calls add no origins. Public events still
contain only `raw` and `args`. Independent before/after probes preserve full generated
source, substitution and descriptor channels, including original pipeline plan inputs.

Statement occurrences use the same private channel. Repeated equal text keeps distinct
scalar intervals, and nested scans restore the outer collector:

```perl
my $result = LinkedSpec::ActionIR::ScannerCore::_scan_contract_ir_events_with_provenance(
    {id => 'scalar_assignment_operator'}, 'value = 7; value = 7;', $scanner_deps
);
# source_origins spans: [0, 9), [11, 20)
```

Direct and nested hash assignments each keep their original constructor branch:

```perl
my $result = LinkedSpec::ActionIR::ScannerCore::_scan_contract_ir_events_with_provenance(
    {id => 'hash_index_assignment_operator'}, "tree['key'] = '雪'; tree['key'][0] = '雪';", $scanner_deps
);
# source_origins spans: [0, 17), [19, 39)
```

The eight covered statement contracts are print-foreach, split/trim/filter assignment,
scalar assignment, array append, array end mutation, hash-index assignment, key assignment
and value discard. Both value-discard branches and all four array end methods retain their
existing arguments. Later callback transformations preserve events but decline origins when
the resulting raw text no longer matches the original frame. Exceptions and caller error
state retain their existing behavior. This is private compiler provenance; public events
remain `raw`/`args`, and family signoff still requires its canonical closeout.

A fresh immutable Git recurrence now repeats all nineteen pipeline contracts from the
committed implementation, with no candidate overlays. Three controlled seeds preserve
the literal source/argument/interval oracle, actual returned-event and constructor/argument
references, all five callback effects, and the exact earlier complete compiler channels.
The normalized split and equal-valued copied-return controls also recur unchanged.
Fourteen direct suites check the composed pipeline and existing source-frame consumers.
Canonical acceptance additionally requires the exact staged local CI receipt before family
closure. This closes private pipeline provenance; Flow, legacy and staged producers,
executable membership, comments and replacement remain separate work.

The split scanner now reports the normalized source expression from its successful planner:

```perl
split(items, input, ',')
# planner split op: source_expr => '$input'
# current scanner event: source => '$input'
# lowering still reads $input
```

A bare input binding appears as `$input`; literal inputs keep their quoted text, and
compound inputs keep their trimmed call expression. The descriptor's helper and canonical
events report the same source expression. These examples show the event field:

```perl
split(items, ' 雪,β ', ',')
# args.source => "' 雪,β '"
split(items, cat('雪', ',β'), ',')
# args.source => "cat('雪', ',β')"
```

Supplied planner callbacks that publish only the older `source_symbol` retain that value.
A defined `source_expr` takes priority when both fields exist, including the expression
`"0"`; an undefined canonical field falls back to the older field. Generated lowering,
raw expressions, target/delimiter fields and private occurrence origins stay unchanged.
The original null metadata remains retained as the before observation, with complete
compiler channels and an independent source/argument/plan oracle. This correction adds
no DSL form or native-execution guarantee.

### StatementSplit

`ActionIR::StatementSplit` splits action text into individual statements safe for independent lowering. This is important because a single action block can contain multiple helper calls (`set(...)`, `push(...)`, `return(...)`) that must be lowered separately.

The separator contract is deliberately narrow: top-level newlines split helper statements,
and a semicolon separates adjacent statements on one physical line. It is a separator, not
a line terminator, so the last statement on that line needs no trailing semicolon. Plain
spaces do not create a boundary. Nested semicolons inside expression payloads stay inside
the payload. Executable examples without inline comments therefore omit line-ending semicolons
when a newline already separates the statements.

The Perl reference supports newline separation after assignments, captures, cursor
changes, and marker-control statements as well as helper calls. These sequences
lower like their equivalents separated by semicolons on one line. Newlines inside parentheses, brackets, blocks, quoted strings, regex payloads,
and comments use the scanner state appropriate to that construct.

Perl still has comment limitations (`SESSION-STARTUP-READING.34`). An inline
comment can hide a generated separator; an explicit semicolon before it avoids
that LF/CRLF lowering failure. However, closing-delimiter text inside an inline
comment, such as `# pattern/)`, can still affect structural validation even with
that semicolon. Put such comments on their own line. CR-only comments can absorb
the following statement; use LF or CRLF for comment-bearing source until that
repair lands.

The lowering pipeline retains the canonical contract ID while deciding whether a newline
boundary needs host syntax. This matters for marker-style `switch`: its Perl representation is
an expression-shaped `do { ... }`, so `endswitch()` needs a generated host terminator before a
following newline-separated statement. Ordinary `if` block closure remains statement-shaped
and receives no such terminator. Neither detail changes the source-level separator rule.

### CanonicalEvents

`ActionIR::CanonicalEvents` records recognized current helper calls as ActionIR event records. Each event carries a contract ID, resolved arguments, and metadata needed by the later lowering stages. Deleted helper names are not canonicalized into replacement events. Raw-Perl compatibility passthroughs may still be classified for migration reporting, but their descriptor-facing diagnostic labels stay neutral instead of reusing retired helper names.

### RewritePipeline

`ActionIR::RewritePipeline` glues the scan, classify, and lower phases together. It orchestrates the flow: scan for contracts, split statements, produce canonical events, and dispatch to the appropriate lowering owner for each event.

At `debug` trace level, the Perl reference pipeline reports these stages with
`actionir:<owner>:<phase>:<label>:<decision>` decisions. That trace can show scanner helper-event discovery,
canonical queue matches or RAW_PERL fallbacks, unresolved helper diagnostics, rewrite-rule construction, compact
flow/value/array/declaration/control-flow lowering choices, source-span or contract skips, normal statement
rewrites, unmatched helper events, implicit attached-if closure insertion, and `MethodLowering` helper-family,
assignment/mutation, receiver-chain, AST-vs-string fallback, and unsupported-helper decisions.

The planned Perl reference compile/ActionIR owner trace coverage is closed through MethodLowering; the remaining
trace work is cross-variant parity rather than another known opaque ActionIR owner.

### Lowering owners

Each contract family has a dedicated lowering owner:

- `FlowExpr` — flow-expression helpers (method chains, fluent continuations)
- `ValueExpr` — value construction (bare scalar reads, `array(...)`, `hash(...)`)
- `ControlFlow` — structured control flow (`if/elseif/else/endif`, `switch/case/default/endswitch`)
- `MethodLowering` — method-like helper lowering to Perl code
- `DeclareMethod` — current `set(...)` assignment lowering and backend declaration initializer helpers
- `ArrayPipeline` — array pipeline operations (filter, map, sort, etc.)

### Contracts catalog

`ActionIR::Contracts` is the contract catalog. It defines supported helper surfaces: their names, ActionIR node types, diagnostic identities, and unresolved patterns (the templates matched before lowering resolves them). The main contract families are:

| Family | Purpose |
| --- | --- |
| capture_and_cursor | Boundary capture, mark, cursor-reader, and explicit cursor-control helpers |
| call_and_dispatch | Rule dispatch and call helpers |
| return | Return value construction |
| passthrough_ir | Backend-owned pass-through surfaces |
| emit_and_declare | Declaration and emit helpers |
| array_pipeline | Array pipeline operations |
| flow_control | Structured control flow |
| assignment_and_regex | Assignment and regex-slot helpers |

Understanding the pipeline matters because it explains why a helper call in a `.spec` rule is not just a string substitution — it passes through discovery, normalization, classification, and lowering before becoming emitted backend code.

## Deeper reference

The repo-root ActionIR guides are the exhaustive working references while this book grows toward absorbing that surface:

- `USER_GUIDE_ActionIR_Contracts.md` — full contract catalog (158 contracts across 8 families)
- `USER_GUIDE_ActionIR_MethodLowering.md` — method lowering pipeline
- `USER_GUIDE_ActionIR_EmittedPerlReference.md` — emitted Perl for every supported helper
- `USER_GUIDE_RuleModesAndSplit.md` — rule modes and split-boundary details

These guides go deeper than the book chapters and include exact emitted-Perl shapes for compatibility and migration work.

## Canonical event order and execution

A descriptor event list is compiler telemetry, not a trace of actions executed at runtime.
Top-level statements keep their authored order and existing exclusive ownership. Remaining
helper occurrences now follow the helper scan input, including equal-text occurrences
interleaved across raw keys. Consumed occurrences and alternatives removed by an exclusive
statement are not replayed. The internal queue bookkeeping adds no public event fields.

Helper scans are grouped by contract precedence, with occurrences retained within each
contract. This is stable scan provenance, not global lexical source order. For example,
`return("a")`, `return("b")`, then `return("a")` are three occurrences. Sorting distinct raw
keys or grouping all equal text together would lose that interleaving.

Equal spelling also cannot establish which source occurrence produced an event.
The following current Perl probe has two genuine return calls. The inner text is
a string value and is consumed as part of the outer scanner match:

```spec
Top:: I { return('return("x")'); return("x") }
```

Pairing each event with its earliest equal source text would attach the second
real return to the inner string and incorrectly discard it. Simply skipping
quoted positions has a different failure:

```spec
Top:: I { text="set(counter,1)"; set(counter,2); set(counter,1); return(counter) }
```

The current set scanner reports the quoted `set(counter,1)` and both real calls.
A raw-key mapper that skips the string can assign the first false event to the
later real twin, keeping `set(counter,1)` before `set(counter,2)` and losing the
last event. The independent source oracle requires the real calls in `2`, then
`1` order. Both candidate mappings were executed against captured public helper
arrays and failed their occurrence oracles; they are not compiler repairs.

The pending quote repair therefore needs source occurrence provenance from
the scanner, followed by executable-source selection and exact replacement.
Original argument and literal bytes must remain available to typed parsing and
lowering. The preserved diagnostic fixture currently fails eleven of thirteen
groups; the genuine unsupported/raw and opaque-return guards pass. This is a
complete failing baseline, not acceptance of the repaired compiler.

The first provenance step now records original scalar source positions privately
for the Perl `return_general`, `set_value`, and `if_flow` scanners. It keeps the
original event object and arguments; the position records remain separate from
public descriptor events. For the standalone action strings inside the two examples
above, without their surrounding framing spaces, return matches start at `0, 23`
and set matches at `6, 23, 39`. The quoted set at `6` is deliberately still recorded
as a syntactic match at this stage. Provenance identifies where a scanner matched;
the subsequent membership repair decides whether that source is executable.

The private collector follows the selected event array by object identity, retains
empty and opaque dispatcher returns, isolates nested invocations, and checks that
each recorded scalar span retrieves its exact original raw source. Ordinary public
scans retain their existing fields and order. Remaining producer families and recursive
frames, quoted-source selection, exact replacement, and final recurring acceptance
are separate steps. This private channel does not repair the quoted-value or readiness
defects described below.

Nine basic regex contracts also retain their full-input scalar match positions in
that private channel: the two call assignments, indexed and unindexed built-in
child pushes, `return call(...)`, and `entry_slot()`, `gap_span()`, `gap_text()`,
`gap_kind()`. This includes the existing syntactic matches inside strings; none
of those matches has yet been classified as executable. Public raw text, arguments,
lowering and event order remain unchanged. The eleven basic statement scans now use their own original splitter frames.

The statement splitter preserves comments and quoted punctuation in its returned
text. Its default trim callback removes whitespace at the edges. For example,
this action string produces a quoted assignment and two separate declarations;
the equal declaration text inside the string is not a declaration statement:

```perl
text="my $x"; my $x; my $x;
```

A top-level line break can end a statement after a comment. This input produces
`my #inside` and `$x`, neither recognized by the bare declaration contract:

```perl
my #inside
 $x;
```

Inside parentheses the same line break remains part of one statement:

```perl
return (7 #inside
);
```

These are splitter/compiler inspection examples, not execution recommendations.
Twenty-two authored inputs, including repeated examples for all eleven basic
statement contracts, were inspected under three hash seeds. Each returned
statement matches an independently authored contiguous scalar interval in the
original input, including Unicode whitespace and CRLF. That bounded observation
supports producer-side statement spans; it does not establish every possible
host-language input or transformation by a custom dependency callback. These
statement producers had zero private origins at the diagnostic boundary. Their implemented
hooks retain the existing five callbacks and capture occurrence identity at the splitter,
without searching the source for equal raw strings. Comment classification, executable
membership and residual replacement remain subsequent work.

The private splitter now publishes an aligned `source_frames` sidecar for its
exact returned array. It captures original boundaries during splitting and checks
each trimmed value against that original scalar interval. The callback still runs
once with its original arguments, and the returned array stays the same object.
A copied or opaque callback return receives no borrowed frames. A changed array
entry or custom interior transformation keeps its result and receives no invented
frame; a source supplied as a reference also receives no scalar frame. Nested
private calls restore the enclosing collector, and callback errors propagate.

For compiler diagnostics, with `$default_split` obtained from the ordinary
Scanner dependency bundle:

```perl
my $result = LinkedSpec::ActionIR::StatementSplit::Core::_split_with_source_frames(
    $default_split, 'my $x; my $x;'
);
# source_frames spans: [0, 5), [7, 12)
```

The preserved 28-group fixture fails 25 groups before this private capture and
passes all 28 afterward. Sixty-six source/seed before-and-after compiler records
remain identical, while 177 statement frames match the independent original
scalar intervals. Initial runs and their actual fixture/source boundaries remain
recoverable. This is a private compiler probe.

All eleven basic statement event producers now connect those aligned frames to the
original event objects when private provenance recording is active. Each producer
captures the occurrence index before filtering a statement, so ignored comments and
quoted assignments do not shift later positions. It retains the original raw text,
argument objects, recognition expressions, event order and callback effects. Ordinary
scans call the existing splitter directly; they add no public source fields.

The covered contracts are:

| Contract | Existing statement family |
| --- | --- |
| `return_bare` | Bare return and payload |
| `exit_bare` | Bare exit and payload |
| `linecount_prefix_newline_matches` | Newline matches in a prefix substring |
| `print_capture_substr` | Print the current captured substring |
| `my_declare_bare` | Bare scalar, array or hash declaration |
| `assign_match_my` | Assign a capture/match scalar |
| `destructure_imatch_list_my` | Destructure the match list |
| `regex_subst_assignment` | Regex substitution assignment |
| `next_bare` | Named loop continuation |
| `ref_field_assign` | Assignment from a referenced field path |
| `position_tracking` | Existing cursor/position bookkeeping forms |

For the same declaration string, with `$scanner_deps` obtained from the ordinary
Scanner dependency bundle:

```perl
my $result = LinkedSpec::ActionIR::ScannerCore::_scan_contract_ir_events_with_provenance(
    {id => 'my_declare_bare'}, 'my $x; my $x;', $scanner_deps
);
# source_origins spans: [0, 5), [7, 12)
```

Each origin contains the complete original source, scalar interval and the exact event
object in the returned event array. Copied/opaque split arrays and changed entries gain
no borrowed origins. If a later trim callback changes the raw text, the existing event
is preserved and its origin is omitted. Nested scans isolate their collectors and restore
the outer frames. A custom callback that splits a different source also keeps its event,
but that other string cannot authorize coordinates in the requested action. The private
bridge snapshots the requested source before the callback and declines foreign frames.
The original foreign-source probe reproduces one incorrect origin before this guard and
none afterward; those actual channels and source identities remain separate from the
initial 28-group captures. The permanent producer fixture preserves 21 failing groups before the
hooks and passes all 29 afterward, including callback count/argument/error guards.
Across the 22 authored inputs and three seeds, all 111 emitted origins match independent
original occurrence intervals; all 177 statement frames and 66 full public compiler
records remain unchanged. This bounded proof does not classify executable membership,
repair comment semantics or admit arbitrary host syntax. The statement-family acceptance repeats all eleven contracts from one immutable
source boundary. It independently checks original frame/event occurrences, exact event
identity, unchanged complete compiler records, foreign-source rejection and all four
source-provenance fixtures. Complete TAP plans and both output channels are retained;
missing inputs, incomplete plans and nested failures are distinguishing rejection
controls. Canonical CI gates this family closeout on the exact staged candidate. The
mixed twenty-contract proof now uses one shared action input. Its literal construction
includes a quoted row of all nine regex forms, every regex and statement form in
forward order, an ignored comment, then all twenty forms in reverse order. Unicode,
CRLF and Unicode whitespace remain in the original source. For each of three hash
seeds, the nine regex scans retain three syntactic matches each; the eleven statement
scans retain two original statements each. That is 49 event origins and 43 splitter
frames per input, with no origin inferred by searching equal raw text.

The independent oracle checks exact original arguments as well as spans. It distinguishes
an indexed child push from an unindexed push, call-return from bare return, declaration
from assignment, and each zero-argument gap helper. Public and private scans retain the
same values and dependency callback sequence. Every private origin refers to its original
event object and original argument object; the sidecar adds no public event fields.
Eight unchanged source/scanner/AST/order consumers pass 144 complete test groups,
including the existing callback, nested collector, opaque result, foreign-source and
caller-error guards. Actual full output channels and immutable source inputs are retained;
twenty distinguishing controls reject missing or altered occurrences, arguments, references,
callbacks, inputs and incomplete or failed results. The initial missing-test-path harness
failure stays recorded as incomplete evidence. A fresh immutable Git recurrence repeats all twenty contracts from the committed
mixed-proof boundary with no overlays. It independently validates the complete source
population and preserves the exact prior Toolbox channels under all three seeds, alongside
all eight original test plans, occurrence/argument/reference checks and foreign-source
guards. The exact staged canonical CI receipt gates BasicRules family closeout before
landing. Other scanner families still require their own producer frames and independent
composition before executable membership and source replacement can be repaired. This composition does not classify executable text,
repair comment semantics or activate source replacement.


These are compiler inspection examples, not recommended parsing actions. Each
contains one quoted syntactic occurrence followed by two equal real occurrences:

```spec
Top:: I { note="雪;my $x = call(Done)";
  my $x = call(Done);	my $x = call(Done) }
Done: /x/ I.return("child")
```

```spec
Top:: I { note="雪;gap_text( )";
  gap_text( );	gap_text( ) }
Done: /x/ I.return("child")
```

The captured action inputs use CRLF after the quoted assignment; the book displays
LF. That display normalization does not alter the retained compiler input or its
Unicode scalar position oracle. Private provenance also keeps the original event
object, rather than reconstructing it by matching equal raw text.

The earlier hash-key residual drain and its raw permutations remain historical evidence.
These exact sources return `ok` and `a` respectively, both natively and from independently
loaded emitted source in the measured before/after source-and-seed comparisons:

```spec
Top:: I { cb={|x,y| nested={|s,q| return(s) }; return(nested(x,y)) }; return(cb("ok","unused")) }
```

```spec
Top:: I { cb={|| if(false) { return("a") }; if(false) { return("b") }; return("a") }; return(cb()) }
```

For the second source, the top-level assignment and outer return precede the residual
`RETURN a`, `RETURN b`, `RETURN a`, then the two attached `IF` events. This ordering records
scanner precedence; it does not say those returns or branches were executed.

The current nine-source matrix preserves full ordered records across three controlled
seeds. Exact substitutions, parser dumps, emitted source, ASTs, metadata populations/counts
and native/fresh values match the before-owner observations. Fifteen current lowering traces
retain the measured source-cursor misses, ambiguous raw skips and single unmatched rewrites.
Those bounded controls do not establish arbitrary-overlap equivalence. Raw compatibility
results and process-specific host warning locations do not establish portable semantics.

Readiness still has separate known defects. This source returns its exact quoted value,
yet reports an extra `IF` event and three unresolved helpers:

```spec
Top:: I { return("return(inner); if(true)") }
```

Its typed argument is a string. The helper-looking contents must remain data; quoted-payload
repair is independently owned. The nested raw-expression reporting repair is explained below.
Stable event order alone does not repair those classifications. A working value cannot establish
portable readiness, and a false blocker must not be removed by hiding genuine raw source.

Literal contents must retain their data meaning during helper discovery, canonical-event
construction, lowering and unresolved-helper reporting. Recognizing the outer `return` does
not make the text inside its quoted argument executable. Diagnosis, a bounded repair and
independent closeout are tracked separately, including the earlier quoted primitive-rewrite
observations. Accepted quote syntax and genuine unsupported operands elsewhere in the action
retain their existing contracts while that work proceeds.

The current quote diagnosis also exposes a value defect:

```spec
Top:: I { return("set(counter, 2)") }
```

The intended result is the literal `set(counter, 2)`. The current primitive scan
creates a false `ASSIGN`, and residual lowering changes the literal contents to
`$counter = 2` before generated Perl evaluates the string. This case remains a
known defect. A mixed action must retain genuine executable assignments while
leaving an identical spelling inside data untouched.

For the quoted `if(true)` example above, the current lowering trace reaches the
phantom replacement, then detects an unbalanced flow stack and returns the original
action text. That fallback explains the healthy literal value; it does not validate
the false compiler events or readiness classification.
For the measured nested `cat` and `matches` controls, this fallback also leaves
unlowered host calls and causes execution errors in both native and fresh emitted
Perl. Those failures are owned by the same source-occurrence repair.

Unsupported-helper diagnostics also need source ownership:

```spec
Top:: I { return("LINKEDSPEC_UNSUPPORTED_ACTIONIR_HELPER:substr") }
```

```spec
Top:: I { return(substr("abc")) }
```

The first action returns ordinary authored string data. The second uses an
unsupported helper arity and must remain blocked; its current lowering returns
`undef` through a compiler-owned diagnostic marker. Both currently contribute one
unresolved `substr` because diagnostics search marker text without origin information.
Ignoring every quoted string would erase the second action's genuine blocker.
These examples describe the measured Perl reference behavior and pending repair;
they do not admit unsupported syntax or establish another backend's behavior.

The historical diagnosis keeps unmodified arrays and streams under the `.0.6.0` checkpoint
prefix. The `.0.6.1` successor retains an exact before-owner module, source-identical
before/after public captures, independent occurrence-order oracles, complete TAP and current
traces. Its read-only reviewer rejects corrupted source/order/population/consumer evidence;
it never overwrites captures. The permanent regression is also invoked by Phase 0. Compiler
landing requires canonical acceptance of the exact staged candidate. Three fixed seeds are
named observations, not a probability estimate or another backend's admission.

## Reading portability diagnostics

Perl readiness reporting includes unsupported expressions nested inside recognized
helper statements. Arithmetic and comparison use call form.
These two exact measured sources illustrate the difference:

```spec
Top:: I { i=2; i=i+1; return(i) }
```

```spec
Top:: I { i=2; i=num_add(i,1); return(i) }
```

The first contains an unsupported raw `i+1` AST child. It retains host Perl
behavior and returns1 on both measured routes; the fresh emitted route also
reports bareword/numeric warnings. It now reports ready0/raw1/fallback0 and
exposes `i+1` as a raw dependency and portability blocker. The earlier
ready1/raw0/fallback0 observation remains historical diagnostic evidence.
The second uses the admitted helper and returns3 with no raw child.
Use canonical calls; infix source is not portable authoring.

The same reporting defect reaches deferred bodies:

```spec
Top:: I { cb={|i| i=i+1; return(i) }; return(cb(2)) }
```

Metadata now reports ready0/raw1/fallback0; actual invocation still fails with
`unsupported_codeblock_actionir` for `raw_perl`. Native context and fresh
generated-source errors expose that failure through their own public channels;
native handler evaluation also emits its normal failure trace. A ready flag
does not erase an observed unsupported body.

Data must also be distinguished from executable source. This measured ordinary
action returns ok, but the current AST classifies the comment as raw and reports
a false portability blocker:

```spec
Top:: I { # i=i+1; i < 1
 return("ok") }
```

Source-comment classification has a separate repair owner. This ordinary LF
case establishes no deferred/function comment support. The earlier quoted
string example likewise remains data despite phantom helper telemetry.

The historical diagnosis retains16 full sources/48 native-and-fresh pairs under
three named seeds and16 lowering traces. Its seven hidden raw dependencies are
now visible in rule-action diagnostics. Conditions may appear twice in serialized
ASTs because condition and argument fields share a node; that is one source
occurrence. Equal text at different spans or in different action units remains
separate. For example, this source has two raw expression occurrences, while
the displayed raw text contains `i+1` once:

```spec
Top:: I { i=2; i=i+1; i=i+1; return(i) }
```

`canonical_action_ir_fallback_count` keeps its top-level event meaning.
`raw_perl_dependency_count` adds uncovered nonempty `unsupported_expression`
occurrences to that existing fallback count. A raw-containing statement already
represented by a `RAW_PERL` event covers its child raw nodes; they are not counted
again. Raw display and blocker lists contain unique text rather than occurrence
counts. Existing canonical events and helper diagnostics keep their meanings.

`raw_perl_expression_dependencies` exposes each added occurrence as `source`,
`reason`, `source_span` with `start`/`end`, and `source_unit`.
`raw_perl_expression_source_units` records `kind`, `index`, and the diagnostic
unit's exact `source`; blind actions also record `target`. The span indexes that
recorded action-unit text, not the absolute `.spec` file. Normalized fluent units
may be derived text. Unit kinds distinguish lifecycle slots, action edges,
blind edges and AND-local actions; repeated units retain separate indices.
Both arrays are empty when there are no added expression dependencies.

Nested eager braces, attached calls and attached controls propagate their body
start into child ASTs. Success nodes and typed parse errors use Unicode-scalar
coordinates in the containing action unit, including leading spaces and CRLF.
Correcting those coordinates can change serialized AST payloads in substitutions,
parser dumps and emitted Perl; the executable source around those payloads,
node structure, values and runtime behavior retain their existing contracts.

Semantic rule markers also create compiler-owned lifecycle code:

```spec
Top::
 -> MoveTop

MoveTop: /foo/ /bar/ @mark(body_start)
```

This measured named mark keeps ready1/raw0. RuleIR records the exact generated
LE slot and source; only that matching chunk is excluded from added expression
scanning. An authored identical chunk in a later slot, or changed source in the
recorded slot, remains visible. Position markers `@move_pos`, `@capture_slice`
and `@capture_from_here` keep their existing raw1/fallback1/ready0 diagnostic;
generated ownership does not remove prior canonical fallback events. Their
canonical portability classification has a separate reconciliation task before
readiness closeout; runtime equivalence alone does not establish that contract.


Readiness reports unsupported source present in an action; it is not an execution
trace. These measured keyword calls remain unsupported:

```spec
fn id(value) { return(value) }
Top:: I { cb={|| return(id(value:"x")) }; return(cb()) }

```

```spec
fn pair(first,second) { return([first,second]) }
Top:: I { effects=[]; cb={|| return(pair({ push(effects,"bad"); return("x") },second:"y")) }; return(cb()) }

```

Their raw expression dependencies are `value:"x"` and `second:"y"`, respectively.
Both report ready0/raw1/fallback0. Native and fresh emitted execution retain the
typed `user_function_keyword_arguments_unsupported` error, with
`arguments_evaluated`0. The second control leaves `effects` empty: rejection
occurs before either operand executes. No keyword syntax is admitted by this
reporting change. Its source spans are18–27 and69–79 in the recorded I-action
units; those units include their original leading/trailing spaces.

A blind action's rewrite input includes a compiler-generated call assignment.
Only that caller separates its exact bridge from the diagnostic body. For this
measured source, the added dependency is `i+1`, indexed in ` return(i+1) `:

```spec
Top:: I { i=2 } => Done { return(i+1) }

Done:: I { return("child") }
```

Canonical blind calls remain raw-free. Authored text with the same spelling as the generated bridge
is retained in its diagnostic unit; the existing `assign_call` contract owns that supported wrapper.
A genuine adjacent `i+1` still blocks readiness and retains its authored offset. A mismatched blind
target retains the complete source unit rather than applying the generated-prefix separation.

Supported legacy contracts also matter: a raw whole-expression AST can describe
a statement already owned by an exact canonical helper contract. This measured
wrapper source retains ready1/raw0/fallback0:

```spec
Top::&
 /a/ -> Top { my $retv = call(Leaf); $retv = call(Leaf); push @Top, call(Leaf) }

Leaf:
 /a/ -> Leaf { return(1) }
```

Canonical ownership requires the exact statement and a sanctioned legacy contract;
it never blankets arbitrary descendants of an outer `return(...)`. Bare `return`
and `exit` payloads are inspected independently. This measured method return keeps
its canonical RETURN/CALL events, but its host map/reference operands report
ready0/raw2/fallback0:

```spec
Top::&
 /a/ -> Top .return ((map {lc} @IMATCH_LIST), \@Top, call(Leaf))

Leaf:
 /a/ -> Leaf { return(1) }
```

Existing ordinary assignment-expression lowering also supports grouped mutation
receivers. This measured source retains ready1/raw0 and its existing values:

```spec
Top::
 /x/ -> Done { set(value, "ok"); set(key, "stage"); return(array(items += value, copy(items), meta[key] = value, copy(meta), (items += "x").count(), (meta["last"] = value).count_keys())) }

Done::
 /[a-z]+/
```

The collector inspects the typed inner assignment and still exposes unsupported
inner values. It leaves grouped assignments inside deferred codeblocks raw: that
executor consumes the original AST and has no corresponding admission. This
reporting classification adds no syntax or runtime behavior.

The repair covers original rule-action and deferred-body ASTs. It does not scan
the function registry or claim a transitive function dependency count. Measured
referenced raw function bodies retain unresolved-helper guards; an unused raw
function does not newly block the rule. Comments and quoted helper-looking data
retain their separate repair owners. Shipped-spec descriptor census is source
compilation evidence, not full execution or syntax admission. Source-reference
compilation must use the exact decoded file text; passing a filename to `Get`
does not establish that file's readiness.

The diagnostic and repair checkpoints preserve original sources, full streams,
before-owner modules and independent fresh observations. The reporting change
leaves ASTs, lowering, emitted source and runtime behavior unchanged. Fixed seeds
are named observations, not a probability estimate. Canonical signoff is required
for landing; dispatcher/full composition and other-backend admission remain open.
