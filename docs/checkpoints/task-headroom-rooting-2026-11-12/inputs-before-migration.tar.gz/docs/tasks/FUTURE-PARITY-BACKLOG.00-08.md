- ID: `FUTURE-PARITY-BACKLOG.0`
  Status: `done`
  Goal: Create and register the future parity backlog tree.
  Acceptance: The task tree exists, the central index points at it, ADR `0021` records the
    backend rollout order, and roadmap/book/KM/live docs agree. No implementation code changes.
  Verification: **PASS 2026-07-09.** `git diff --check`, memory architecture, Knowledge Map,
    doctrine, task-tree metadata, mdBook build, and local CI pass; local CI includes phase0
    `1..1028`. No implementation code changed.
  Commit: `FUTURE-PARITY-BACKLOG.0 - create future parity backlog`

- ID: `FUTURE-PARITY-BACKLOG.1`
  Status: `done`
  Goal: Add future backend implementations in full parity with Perl5 and Rust.
  Children: `.1.1`, `.1.2`, `.1.3`, `.1.4`, `.1.5`, `.1.6`
  Acceptance: Dart, Julia, and Lua each reach the same `.spec` language, helper/action AST,
    runtime semantics, staged parsing, diagnostics, and corpus parity contract as Perl5 and Rust; each exposes an
    idiomatic native in-memory library API, with its primary CLI exactly conforming to ADR `0023` and its corpus
    runner remaining a separate secondary adapter.
  Verification: **PASS 2026-07-16.** Dart, Julia, and Lua are complete alongside Perl and Rust. The executable
    census requires all five backends across 16 capabilities at 80/0/0; exact primary CLI proof is 5x2x61, and
    native/generated/corpus evidence remains separately recurring. Lua `.8.4` performs the final admission.
  Commit: `LUA-BACKEND-PARITY.8.4 - admit Lua capability parity`

- ID: `FUTURE-PARITY-BACKLOG.1.1`
  Status: `done`
  Goal: Dart backend parity track - split/scaffold the Dart implementation path.
  Acceptance: Create or expand a dedicated Dart backend implementation plan before code, covering
    parser, helper/action AST, compiler/HandlerIR or interpreter strategy, runtime, regex engine,
    staged parser registry, corpus runner, docs, and parity gates against Perl5/Rust.
  Verification: **PASS 2026-07-09.** Created `docs/tasks/DART-BACKEND-PARITY.md` as the dedicated
    Dart backend plan. The plan covers parser/frontend, typed helper/action AST, interpreter-first
    compiled-state strategy, runtime, regex engine, staged parser registry, corpus runner, docs,
    trace/diagnostics, parity gates, and generated Dart source as a later proof lane. No backend code
    changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.1 - scope Dart backend parity plan`

- ID: `FUTURE-PARITY-BACKLOG.1.2`
  Status: `done`
  Goal: Julia backend parity track - split/scaffold now that Dart has reached its scoped parity milestone.
  Acceptance: Create or expand a dedicated Julia backend implementation plan with the same full-parity
    obligations as Dart, reusing lessons from Dart without changing `.spec` semantics.
  Verification: **PASS 2026-07-09.** Created `docs/tasks/JULIA-BACKEND-PARITY.md` as the dedicated Julia backend
    plan. The plan schedules interpreter-first parity, Julia-specific CLI ownership, typed `.spec` frontend,
    typed helper/action AST, compiled state, runtime interpreter, regex/match state, staged parser registry,
    user-function runtime, diagnostics/trace, corpus runner, local verification, mdBook alignment, and generated
    Julia source as a later proof decision. No Julia package or implementation code changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.2 - scope Julia backend parity plan`

- ID: `FUTURE-PARITY-BACKLOG.1.3`
  Status: `done`
  Goal: Lua backend parity track - split/scaffold after Julia reaches its scoped parity milestone.
  Acceptance: Create or expand a dedicated Lua backend implementation plan with the same universal
    `.spec`, helper/action AST, runtime, staged parsing, diagnostics, and corpus parity obligations; define an
    idiomatic native Lua module that parses/compiles/executes in memory, direct library-level embedding tests,
    and a distinct Lua-specific executable token that implements ADR `0023`'s exact primary CLI interface.
  Verification: **PASS 2026-07-11.** Created `docs/tasks/LUA-BACKEND-PARITY.md` as the dedicated full-parity Lua
    plan. It fixes PUC Lua 5.4 primary/LuaJIT secondary roles, records installed Lua/LPeg and absent LuaRocks/test/
    lint/format tools, and splits module/harness, frontend, ActionIR/compiler, matching/runtime, staged/loading/
    capabilities, 105-case corpus, exact CLI, generated source, docs/gates, and final admission. Native in-memory
    APIs, exact 61x2 CLI, four value kinds, generic final-codeblock syntax, newline/semicolon and quote semantics,
    strict UTF-8 boundaries, 15-capability expansion, and generated-source v1 are explicit. No Lua code changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.3 - scope Lua backend parity plan`

- ID: `FUTURE-PARITY-BACKLOG.1.4`
  Status: `done`
  Goal: Ratify native in-memory embedding as the primary multi-backend product contract.
  Acceptance: Audit the current Perl, Rust, Dart, and Julia public library surfaces; record a durable decision that
    each backend must compile/parse/execute in the host process without requiring a CLI, subprocess, or serialized
    file handoff; require Lua and future backend plans to expose equivalent native library APIs; define CLIs and
    corpus runners as thin adapters with no exclusive semantics; align roadmap, mdBook public API/handoff,
    Knowledge Map, live docs, and backend task acceptance; make no parser/runtime behavior change.
  Verification: **PASS 2026-07-10.** Audited the native Perl `Get`/`get_parser`, Rust core parser/compiler plus
    runtime `Engine`, Dart package parse/compile/runtime exports and CLI adapter, and Julia module
    parse/compile/runtime exports and CLI adapter. ADR `0022`, roadmaps, mdBook public API/handoff, backend task
    acceptance, Knowledge Map, live docs, and Lua/future acceptance now agree. Direct Perl coderef construction,
    50 focused Dart runtime tests, direct Julia parse/compile/execute, mdBook build, Knowledge Map, memory,
    task-tree, doctrine, and whitespace gates pass. No parser/compiler/runtime source changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.4 - ratify native in-memory backend contract`

- ID: `FUTURE-PARITY-BACKLOG.1.5`
  Status: `done`
  Goal: Make every implemented backend's primary CLI conform to one byte-testable user interface.
  Children: `.1.5.0`, `.1.5.1`, `.1.5.2`, `.1.5.3`, `.1.5.4`
  Verification: **PASS 2026-07-10.** Perl, Rust, Dart, and Julia expose the same strict 61-case primary CLI under
    default and POSIX option environments. One recurring driver owns all eight legs, backend-focused gates pass,
    and the broader core gate passes through Phase 0 `1..1028`.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.4.3 - close exact primary CLI parity`

- ID: `FUTURE-PARITY-BACKLOG.1.5.0`
  Status: `done`
  Goal: Ratify and route the exact cross-backend CLI contract before implementation.
  Acceptance: ADR `0023` defines the canonical option/argument/output/error/exit contract, current gaps are
    source-backed, and every implemented backend repair plus the language-neutral conformance gate has an owner.
  Verification: `PASS` - delegated `JULIA-BACKEND-PARITY.7.3.1` records ADR `0023`, the Perl reference command
    schema, zero positional arguments/subcommands, normalized output/error/exit rules, current gaps, and the
    `.1.5.1` through `.1.5.4` repair sequence. No implementation behavior changed.
  Commit: `JULIA-BACKEND-PARITY.7.3.1 - ratify exact backend interface parity`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1`
  Status: `done`
  Goal: Lock the language-neutral CLI fixtures and normalize the Perl reference command to ADR `0023`.
  Children: `.1.5.1.0`, `.1.5.1.1`, `.1.5.1.2`, `.1.5.1.3`, `.1.5.1.4`, `.1.5.1.5`, `.1.5.1.6`
  Acceptance: Checked-in fixture cases define help, success, usage, compile/input/runtime failure, trace routing,
    stdout/stderr, and exit behavior; Perl passes exactly and rejects undocumented primary-CLI surface.
  Verification: **PASS 2026-07-10.** Seven completed implementation/no-drift leaves establish strict help/usage,
    source/input/parser controls, operational failures, canonical trace, preserved strict UTF-8, recursive JSON,
    and stable invalid-byte phases. Perl passes all 61 shared cases under default/POSIX environments; focused
    runner/trace tests and full local CI through Phase 0 pass. The neutral manifest is now the reusable reference.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.6.3 - close Perl CLI reference`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.0`
  Status: `done`
  Goal: Audit and split the neutral fixture plus Perl-normalization work by observable mechanism before code.
  Acceptance: Inspect ADR `0023`, the Perl primary source/tests, relevant Knowledge Map/toolbox facts, and direct
    process behavior; record every observed contract gap; split a recoverable sequence before implementation.
  Verification: `PASS` - `bin/linkedspec`, `t/trace_cli.t`, ADR `0023`, the trace owner, and direct process probes
    show that the current trace smoke passes but the full contract does not. Perl accepts an ignored positional,
    uppercase long options, unique abbreviations, and undocumented `--no-trace-*` forms. `POSIXLY_CORRECT` changes
    abbreviation and argument-order behavior because `Getopt::Long` policy is implicit. Unknown options prepend an
    uncontrolled library warning. Compile and invocation failure correctly exit `1` but emit timestamped/source-
    located `DUMP_NONE` records to stdout before the normalized stderr. The work is split into harness/help,
    arguments, success/IO, operational failures, and trace/gate leaves; no implementation source changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.0 - split neutral CLI fixture work`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.1`
  Status: `done`
  Goal: Establish the language-neutral fixture schema/runner and exact help baseline.
  Acceptance: A checked-in manifest and backend-independent process runner validate schema, command arrays,
    executable-display substitution, isolated fixture workspaces, exact stdout/stderr bytes, and exit status; the
    first help fixture passes on Perl without weakening later four-backend reuse.
  Verification: `PASS` - `cli_conformance/manifest.json` and `tools/run_cli_conformance.pl` define a strict schema,
    arbitrary launch command after `--`, explicit placeholders, per-case canonicalized temp workspaces, exact raw
    stdout/stderr/exit and generated-file comparisons, safe relative paths, focused selection, and useful first-
    mismatch diagnostics. The exact help fixture passes Perl and uses backend-neutral wording plus the complete
    trace alias/help surface. Four runner subtests (13 assertions), the existing two trace CLI subtests, direct
    conformance execution, syntax, docs, Knowledge Map, governance, mdBook, and whitespace checks pass.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.1 - add neutral CLI fixture runner`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.2`
  Status: `done`
  Goal: Normalize and fixture-lock Perl's exact argument and usage-error surface.
  Acceptance: Only ADR `0023` options/spellings are accepted; case aliases, abbreviations, negated aliases,
    subcommands, positionals, missing values, invalid modes/levels, and selector conflicts produce deterministic
    fixture-owned stderr and exit `2`, independent of environment defaults.
  Verification: `PASS` - Perl now uses an explicit case-sensitive, non-abbreviating parser equivalent to the
    shared Julia model, with no `Getopt::Long`/environment policy. Twenty-two neutral cases pass with
    `POSIXLY_CORRECT` both unset and set: long/short help, selector requirements/conflicts, status/corpus/trailing
    positionals, `--`, unknown/case/abbreviation/negated aliases, missing values, flag values, invalid parse/trace
    modes/levels, and ordered multiple errors. Every usage failure has empty stdout, exact templated stderr, and
    exit `2`; four runner subtests and two trace CLI subtests remain green.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.2 - normalize Perl CLI arguments`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.3`
  Status: `done`
  Goal: Lock Perl source/input/parser controls and canonical successful output through neutral fixtures.
  Acceptance: Named/file/inline source, literal/file input, top-rule, seek/consume, nested canonical JSON, and one
    trailing newline are exact; source/input bytes and documented resolution have no backend-local side channel.
  Verification: `PASS` - seven backend-neutral success cases lock repository named resolution from an isolated
    workspace, exact file/inline source and literal/file input, explicit top rule, distinct seek/consume controls,
    recursively sorted nested JSON, preserved input-file newline bytes, empty stderr, exit `0`, and exactly one
    JSON-record newline. `LinkedSpec::Get`, `get_parser`, generated-source, and trace probes confirmed the portable
    action-edge return shape and ADR `0020`'s already-owned direct-default-rule `E` caveat before fixture authoring.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.3 - lock Perl CLI success behavior`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.4`
  Status: `done`
  Goal: Normalize and fixture-lock Perl compilation, input-load, and invocation failures.
  Acceptance: Phase order is compilation then input then invocation; each failure has backend-neutral stable stderr,
    empty stdout unless trace is explicitly selected, and exit `1`; paths and host exception text do not make the
    shared contract platform- or backend-specific.
  Verification: `PASS` - four exact neutral cases lock invalid/missing source compilation, compilation-before-input
    precedence, missing input, and missing-top-rule invocation. Untraced failures have empty stdout, one stable
    backend-neutral heading on stderr, exit `1`, and no files. The adapter suppresses backend trace environment
    state unless a CLI trace option is present; an ambient debug/file/reset regression proves no output or file.
    All 33 cases pass in default/POSIX environments; runner and three trace CLI subtests remain green.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.4 - normalize Perl CLI failures`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.5`
  Status: `done`
  Goal: Lock Perl canonical trace routing and integrate the reusable fixture runner into the local gate.
  Acceptance: Stdout/route/mirror, file/reset, quiet/none, and emoji behavior are represented deterministically in
    the neutral suite; Perl passes every help/success/usage/failure/trace fixture; focused/local gates and public
    docs invoke the reusable runner; later Rust/Dart/Julia leaves consume the same manifest without forked cases.
  Verification: `PASS` - ADR `0024` replaces the nondeterministic multi-megabyte Perl CLI projection with one
    concise canonical phase protocol while preserving native embedding trace. Twenty exact cases lock stdout,
    route, mirror, file reset/persistence/append, all levels/aliases, numeric thresholds, UTF-8 emoji, success,
    and every failure phase. All 53 cases pass twice;
    four runner plus three trace subtests and `tools/run_ci_local.sh` pass. The local gate now invokes the same
    manifest/runner in default and POSIX environments.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.5 - close canonical CLI trace`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.6`
  Status: `done`
  Goal: Define and fixture-lock the primary CLI UTF-8 process boundary before declaring Perl the reusable reference.
  Children: `.1.5.1.6.0`, `.1.5.1.6.1`, `.1.5.1.6.2`, `.1.5.1.6.3`
  Acceptance: Audit argv and file decoding for inline/file/named source and literal/file input, canonical JSON
    encoding, invalid UTF-8 handling, error phase/status, and trace byte counts; ratify one backend-neutral policy;
    split implementation if needed; add exact neutral fixtures that prevent mojibake or host-specific decoding.
  Verification: **PASS 2026-07-10.** `.6.0` ratifies ADR `0025`, `.6.1` makes invalid bytes fixtureable, `.6.2`
    fixes strict Perl decoding/recursive UTF-8 JSON and adds eight exact behavior cases, and `.6.3` closes no-drift.
    The initiating mojibake is resolved; Perl passes 61/61 twice and the full local gate reaches Phase 0 `1..1028`.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.6.3 - close Perl CLI reference`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.6.0`
  Status: `done`
  Goal: Audit, ratify, and split the exact primary CLI UTF-8 text boundary before implementation.
  Acceptance: Use Knowledge Map/toolbox facts and direct native/process probes; inspect Perl, Julia, Rust, runner,
    and public docs; decide argv/file/JSON/trace encoding, normalization/BOM/newline behavior, invalid-byte phase,
    and contract exclusions; split runner, adapter/fixtures, and no-drift work before code.
  Verification: `PASS` - ADR `0025` defines strict UTF-8 text with no normalization, BOM stripping, newline
    conversion, or trimming; valid argv is the interface precondition; invalid source/input file bytes project to
    compilation/input-load failures. Perl `Get` probes prove decoded `xé` and `/é/` execute and serialize as exact
    `c3 a9`, isolating mojibake to adapter decoding. Julia uses `String` argv/files, Rust APIs use `&str` and
    `read_to_string`, and the neutral runner lacks invalid-byte materialization. Three implementation leaves own
    runner hex bytes, Perl boundary/fixtures, and final closeout; no behavior code changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.6.0 - split primary CLI UTF-8 boundary`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.6.1`
  Status: `done`
  Goal: Let the neutral runner materialize exact invalid/non-text fixture bytes without checked-in binary blobs.
  Acceptance: Extend schema version 1 input-file records with one validated mutually exclusive lowercase-even
    hex byte source beside checked-in `source`; preserve safe paths/workspaces/raw comparison; add focused schema,
    materialization, and malformed-hex tests; document the portable mechanism without backend-specific cases.
  Verification: `PASS` - schema-v1 input-file records accept exactly one of checked-in `source` or non-empty
    lowercase even-length `bytes_hex`; materialization uses raw `pack` bytes and preserves safe-path/workspace
    handling. Six runner subtests cover exact `00 c3 28 ff 0a` bytes plus both/neither/empty/uppercase/odd/non-hex
    rejection before backend launch. Syntax, checked-in help, full local gate, docs/KM/governance/book pass.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.6.1 - add neutral hex byte fixtures`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.6.2`
  Status: `done`
  Goal: Implement Perl strict UTF-8 process/file decoding and add exact valid/invalid neutral fixtures.
  Acceptance: Decode valid option values at the correct phase, decode source/input files strictly, preserve code
    points/BOM/newlines without normalization/trimming, emit canonical UTF-8 JSON, keep trace byte counts exact,
    map invalid source/input bytes to stable compilation/input-load failures, and cover literal/file Unicode plus
    invalid files in the shared manifest under default/POSIX environments.
  Verification: **PASS 2026-07-10.** `bin/linkedspec` strictly decodes valid UTF-8 argv and raw source/input files,
    preserves code points/BOM/newlines, emits recursive canonical JSON as UTF-8 once, and retains stable invalid
    source/input phase failures. Eight exact neutral cases cover inline/file Unicode, composed/decomposed text,
    input BOM/CRLF/LF, source BOM preservation, invalid files, and trace input/result byte counts. Focused suites,
    61/61 default and POSIX runs, full local CI/Phase 0, docs/KM/governance/mdBook/whitespace/cleanup pass.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.6.2 - enforce Perl CLI UTF-8 text`

- ID: `FUTURE-PARITY-BACKLOG.1.5.1.6.3`
  Status: `done`
  Goal: Close Perl UTF-8/reference conformance and advance to the Rust primary command no-drift.
  Acceptance: Re-audit all task/roadmap/KM/book/help/fixture/gate surfaces; run focused suites, both full neutral
    environments, mdBook/governance, and full local CI; mark `.1.5.1` done only if no stale byte-oriented or
    mojibake claim remains; activate `.1.5.2` without changing the shared contract.
  Verification: **PASS 2026-07-10.** Current-state searches find no unresolved Perl mojibake/active-repair claim;
    historical 53-case and initiating-gap evidence remains clearly dated. Help, task/roadmap/live docs, mdBook,
    Knowledge Map, and fixture counts agree on strict UTF-8 and the 61-case Perl reference. Focused suites, 61/61
    default/POSIX, full local CI/Phase 0, mdBook/governance/whitespace, and generated-artifact cleanup pass.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.1.6.3 - close Perl CLI reference`

- ID: `FUTURE-PARITY-BACKLOG.1.5.2`
  Status: `done`
  Goal: Add the Rust primary CLI against the shared fixture contract.
  Children: `.1.5.2.0`, `.1.5.2.1`, `.1.5.2.2`, `.1.5.2.3`, `.1.5.2.4`
  Acceptance: A Rust binary delegates to native core/runtime APIs and passes the same CLI fixtures as Perl. The
    binary may project portable argument/loading/diagnostic/trace policy, but it may not duplicate `.spec` parsing,
    compilation, matching, lifecycle, helper, or result semantics owned by the Rust libraries.
  Verification: **PASS 2026-07-10.** Children `.0`-`.4` add the exact Rust process boundary, reusable native
    entry/mode/direct-value execution, strict preserved UTF-8 loading, canonical JSON/failures, ADR `0024` trace,
    and recurring local verification. The built command passes all 61 unchanged fixtures in default and POSIX
    environments without duplicating runtime language semantics.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.2.4 - close Rust primary CLI`

- ID: `FUTURE-PARITY-BACKLOG.1.5.2.0`
  Status: `done`
  Goal: Audit and split the Rust primary-command work by observable mechanism before implementation.
  Acceptance: Inspect the Rust workspace, parser/compiler/validation/runtime/trace APIs, named-spec and fixture
    resolution, ADRs `0023`-`0025`, and the unchanged 61-case manifest; record exact reusable seams and gaps; split
    recoverable implementation leaves before adding a binary or changing runtime behavior.
  Verification: **PASS 2026-07-10.** Source audit confirms a two-library workspace with no binary target; native
    full-spec parsing, validation, compilation, execution, structured JSON values, and rich trace already exist.
    The runtime currently enters only the compiled `Top` rule and consumes each compiled rule's own parse mode, so
    reusable entry-rule/global-mode controls need a native execution seam rather than CLI-only semantics. Rust
    strict UTF-8 file reads, named resolution, exact option/help handling, canonical JSON bytes, stable phase
    failures, and canonical CLI trace projection remain adapter work. Governance, book, and Knowledge Map checks
    pass; no Rust source or fixture behavior changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.2.0 - split Rust primary CLI work`

- ID: `FUTURE-PARITY-BACKLOG.1.5.2.1`
  Status: `done`
  Goal: Add the Rust binary boundary with exact arguments, help, strict UTF-8 loading, and deterministic resolution.
  Acceptance: A `linkedspec-rust` binary exposes only ADR `0023`'s case-sensitive, non-abbreviating options; exact
    help/usage and exit `2` match shared bytes; named/file/inline source plus literal/file input preparation obeys
    compile-before-input ordering, repository fallback rules, and ADR `0025` strict preserved UTF-8 without owning
    parser/runtime semantics.
  Verification: **PASS 2026-07-10.** `linkedspec-runtime::primary_cli` and the `linkedspec-rust` binary now share
    one exact manual parser, fixture-derived help, deterministic current-directory/repository named resolution,
    deferred input loading, strict `String::from_utf8` file decoding, stable phase headings, and raw process-channel
    bytes. Four focused unit tests pass. The built binary passes all 22 shared help/usage cases byte-for-byte and
    the full manifest baseline passes 29/61: the other seven passes are all three invalid-UTF-8 phase cases and all
    four operational failures. The full runtime package passes 133 unit, 99 oracle, 190 integration, three source-
    emitter, and 10 trace-control tests. The 32 expected residuals are exactly 11 direct top-value result cases (the
    existing documented Rust accumulator wrapper) plus 21 canonical-trace cases owned by `.2`/`.3`. Formatting,
    build, runtime tests, default/POSIX argument fixtures, governance, mdBook, and cleanup pass. Strict Clippy on
    the touched crate remains obstructed only by pre-existing core/runtime lints; the new module's large-enum lint
    was fixed; formatting and `cargo build` are green.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.2.1 - add Rust CLI boundary`

- ID: `FUTURE-PARITY-BACKLOG.1.5.2.2`
  Status: `done`
  Goal: Expose native Rust entry-rule/parse-mode controls and complete primary execution/result/failure projection.
  Acceptance: The native runtime provides idiomatic reusable controls for optional entry rule and global parse
    mode; the CLI composes full-spec parse, validation, compile, and `Engine` execution through public APIs; nested
    values emit recursively canonical compact UTF-8 JSON plus one newline; compile/input/invoke failures and exits
    match the shared phase contract without backend exception leakage.
  Verification: **PASS 2026-07-10.** `ExecutionOptions` plus `Engine::execute_value` and traced variants expose
    per-invocation entry-rule/global-mode selection and the direct rule value without mutating compiled state;
    legacy `Engine::execute` retains its accumulator wrapper. Runtime matching consumes the effective override in
    interpreted and generated-plan paths. The CLI now uses this API instead of compiled-field mutation. A nested
    shared object exposed Rust `hash(...)` implicitly splicing every hash argument; Rust now matches the existing
    cross-backend/book contract by preserving ordinary hash values and splicing only explicit `flat`/`flat_hash`.
    Three focused native/hash tests and all 11 direct result cases pass; the unchanged suite advances 29 -> 41/61,
    leaving only 20 non-quiet trace cases under `.3`. Full runtime package, formatting/build, governance, mdBook,
    Knowledge Map, whitespace, and regenerated-cache cleanup pass. Strict Clippy remains blocked only by the same
    pre-existing runtime/core lint backlog; no new touched-code diagnostic remains.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.2.2 - add Rust direct execution API`

- ID: `FUTURE-PARITY-BACKLOG.1.5.2.3`
  Status: `done`
  Goal: Implement the canonical primary CLI trace projection and exact sink behavior in Rust.
  Acceptance: Rust emits ADR `0024`'s deterministic phase records, thresholds/aliases, percent escaping, UTF-8
    byte counts, emoji, stdout/route/mirror defaults, reset/append/persistence, and failure events while keeping the
    rich native trace API independent and suppressing ambient backend-specific trace configuration.
  Verification: **PASS 2026-07-10.** `linkedspec_runtime::primary_cli` now owns a backend-neutral canonical
    trace adapter separate from `linkedspec_core::trace`: exact 100/200/300/400/500 thresholds and aliases,
    portable compile/input/invoke phase records, UTF-8 byte counts, uppercase percent escaping, optional emoji,
    stdout/route/mirror sinks, default routing, reset/truncate, append/persistence, and stable failure records.
    Trace-file setup/write failures remain stable compilation failures, and quiet/none reset without emitting.
    Six focused adapter tests pass; the full runtime package passes 137 unit, 99 oracle, 190 integration, three
    source-emitter, and 10 native trace-control tests. Strict Clippy reports no touched-file diagnostic beyond the
    pre-existing runtime/core backlog, formatting passes, and all 61 unchanged neutral cases pass exactly for the
    built Rust command. Governance, mdBook, Knowledge Map, whitespace, and regenerated-cache cleanup pass.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.2.3 - add canonical Rust CLI trace`

- ID: `FUTURE-PARITY-BACKLOG.1.5.2.4`
  Status: `done`
  Goal: Close Rust primary-command conformance and recurring focused verification.
  Acceptance: The built Rust command passes all 61 unchanged neutral cases in default and POSIX environments;
    focused Rust tests and the broader local gate pass; the Rust primary command is wired into relevant local
    checks; task/roadmap/live docs, mdBook, Knowledge Map, help, and artifact cleanup agree before Dart `.1.5.3`.
  Verification: **PASS 2026-07-10.** Added `tools/run_rust_local.sh`: it checks formatting, runs the full Rust
    runtime package (137 unit, 99-fixture oracle, 190 integration, three source-emitter, and 10 native trace-
    control tests), builds `linkedspec-rust`, then runs all 61 unchanged primary-command cases with
    `POSIXLY_CORRECT` unset and set. `tools/run_ci_local.sh` exposes this gate through explicit
    `LINKEDSPEC_RUN_RUST=1`, preserving a toolchain-independent default like Dart/Julia. The focused Rust gate
    passes end to end. The broader default local gate passes all doctrines/syntax, 22 ActionIR checks, nine
    runner/trace checks, both Perl 61-case environments, and Phase 0 `1..1028`. Help/fixtures are unchanged;
    task/roadmap/live docs, mdBook, Knowledge Map, whitespace, and safe generated-cache cleanup pass.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.2.4 - close Rust primary CLI`

- ID: `FUTURE-PARITY-BACKLOG.1.5.3`
  Status: `done`
  Goal: Replace Dart's primary corpus command with the shared parser CLI contract.
  Children: `.1.5.3.0`, `.1.5.3.1`, `.1.5.3.2`, `.1.5.3.3`, `.1.5.3.4`
  Acceptance: Dart's primary executable passes the same fixtures; corpus execution remains a separate developer
    runner and owns no primary-CLI-only semantics.
  Verification: **PASS 2026-07-10.** Children `.0`-`.4` replace only the primary process boundary, correct the
    reusable no-function staged seam, compose native direct execution/canonical JSON, add independent canonical
    trace, and wire recurring verification. Dart passes all 61 unchanged cases default/POSIX while the separate
    corpus runner remains 99/99 green.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.3.4 - close Dart primary CLI`

- ID: `FUTURE-PARITY-BACKLOG.1.5.3.0`
  Status: `done`
  Goal: Audit and split the Dart primary-command work by observable mechanism before implementation.
  Acceptance: Inspect the primary/corpus entrypoints, parser/compiler/validation/runtime/trace APIs, source and
    input loading, canonical JSON support, ADRs `0023`-`0025`, and the unchanged 61-case manifest; record exact
    reusable seams and gaps; split recoverable implementation leaves before changing Dart behavior.
  Verification: **PASS 2026-07-10.** The current corpus-oriented primary command is measured at 0/61 unchanged
    cases. Source/API inspection confirms reusable staged parsing, validation/compilation, constructor-level global
    mode, call-level top rule, direct result value, rich trace, and canonical-JSON logic. Boundary/loading,
    execution/results/failures, trace, and closeout are separate leaves; corpus-runner behavior is preserved.
    Memory, Knowledge Map, task metadata, doctrine, whitespace, and mdBook checks pass; no Dart behavior changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.3.0 - split Dart primary CLI work`

- ID: `FUTURE-PARITY-BACKLOG.1.5.3.1`
  Status: `done`
  Goal: Replace the Dart primary process boundary with exact arguments, help, strict UTF-8 loading, and resolution.
  Acceptance: `dart/bin/linkedspec_dart.dart` exposes only ADR `0023`'s case-sensitive, non-abbreviating options;
    exact help/usage and exits match shared bytes; named/file/inline source plus literal/file input preparation
    obeys compile-before-input ordering, repository fallback, and ADR `0025` strict preserved UTF-8. The separate
    `dart/bin/corpus_runner.dart` retains corpus-only options and behavior.
  Verification: **PASS 2026-07-10.** The primary binary now uses an exact manual option parser and shared help,
    rejects old corpus/positional/alias surfaces, resolves named/current/repository source deterministically,
    loads raw source before deferred input with strict preserved UTF-8, keeps leading source BOM visible to phase
    policy, and emits raw stable usage/phase bytes. The reusable staged function parser now treats no definitions
    as an empty list, allowing ordinary specs through the same API. Six focused boundary tests, the staged-parser
    regression, analyzer, all 147 Dart tests, 99/99 corpus, and the exact 29-case boundary/failure subset in default
    and POSIX environments pass. The remaining 32 cases are exactly 11 results plus 21 trace cases under `.2`/`.3`.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.3.1 - add Dart CLI boundary`

- ID: `FUTURE-PARITY-BACKLOG.1.5.3.2`
  Status: `done`
  Goal: Complete Dart primary execution, direct canonical JSON results, and stable operational failures.
  Acceptance: The adapter composes exported staged full-spec parsing, validation/compilation, and
    `LinkedSpecRuntimeEngine` execution; entry rule and global parse mode remain reusable native controls; direct
    values emit recursively key-sorted compact UTF-8 JSON plus one newline; compile/input/invoke failures and exits
    match the shared phase contract without leaking backend exceptions.
  Verification: **PASS 2026-07-10.** The adapter retains compiled state, loads input only after compilation,
    constructs `LinkedSpecRuntimeEngine` with native global mode, passes optional top rule, and serializes direct
    `RuntimeParseResult.value` through recursive map-key sorting, compact UTF-8 JSON, and one newline. Backend/JSON
    errors retain stable invocation failure. A focused nested/top/mode test and all 11 unchanged result cases pass
    in default/POSIX environments; quiet trace also passes, advancing the full baseline 29 -> 41/61. Analyzer,
    all Dart tests, 99/99 corpus, docs/KM/governance/mdBook/cleanup pass. Only 20 trace cases remain under `.3`.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.3.2 - add Dart primary execution`

- ID: `FUTURE-PARITY-BACKLOG.1.5.3.3`
  Status: `done`
  Goal: Implement the canonical primary CLI trace projection and exact sink behavior in Dart.
  Acceptance: Dart emits ADR `0024`'s deterministic phase records, thresholds/aliases, percent escaping, UTF-8
    byte counts, emoji, stdout/route/mirror defaults, reset/append/persistence, and failure events while keeping
    its rich native trace API independent and suppressing ambient backend-specific trace configuration.
  Verification: **PASS 2026-07-10.** `primary_cli.dart` now owns an ADR `0024` adapter trace independent of
    `LinkedSpecTraceEmitter`: exact aliases/thresholds, UTF-8 byte counts, percent escaping, emoji, phase events,
    stdout/route/mirror defaults, reset/append/persistence, and traced failures. Trace setup/write errors remain
    stable compilation failures. Three focused trace tests, analyzer, full Dart suite, 99/99 corpus, and all 61
    unchanged shared cases pass in default and POSIX environments. Docs/KM/governance/mdBook/cleanup pass.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.3.3 - add canonical Dart CLI trace`

- ID: `FUTURE-PARITY-BACKLOG.1.5.3.4`
  Status: `done`
  Goal: Close Dart primary-command conformance and recurring focused verification.
  Acceptance: Dart passes all 61 unchanged cases in default and POSIX environments; the Dart local gate preserves
    the separate full 99-fixture corpus runner; focused/full checks pass; task/roadmap/live docs, mdBook, Knowledge
    Map, help, and artifact cleanup agree before global CLI identity `.1.5.4`.
  Verification: **PASS 2026-07-10.** `tools/run_dart_local.sh` now runs format, analyzer, all 151 Dart tests,
    primary help, bounded corpus smoke, all 61 unchanged cases in default and POSIX environments, and the full
    99/99 corpus. The focused gate passes end to end. The broader core gate passes doctrines/syntax, 22 ActionIR,
    nine runner/trace checks, both Perl 61-case legs, and Phase 0 `1..1028` in 527 seconds. Task/roadmap/live docs,
    README, mdBook, Knowledge Map, help, whitespace, and generated-artifact cleanup agree.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.3.4 - close Dart primary CLI`

- ID: `FUTURE-PARITY-BACKLOG.1.5.4`
  Status: `done`
  Goal: Close current Perl/Rust/Dart/Julia CLI parity and make the conformance matrix a recurring gate.
  Children: `.1.5.4.0`, `.1.5.4.1`, `.1.5.4.2`, `.1.5.4.3`
  Acceptance: One driver runs identical fixtures against all four implemented primary commands and proves
    normalized stdout, stderr, and exit-code identity after substituting only the executable token.
  Verification: **PASS 2026-07-10.** Julia progresses 13 -> 42 -> 61/61 through exact boundary and independent
    trace leaves. `tools/run_primary_cli_matrix.sh` then proves all four commands under both option environments
    with unchanged fixtures and explicit Julia warmup; the recurring opt-in CI hook is installed.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.4.3 - close exact primary CLI parity`

- ID: `FUTURE-PARITY-BACKLOG.1.5.4.0`
  Status: `done`
  Goal: Audit Julia against the unchanged 61-case global contract and split exact repair/driver mechanisms.
  Acceptance: Run the shared process suite after a Julia warmup; classify every residual against help/usage,
    strict UTF-8/loading/failure projection, canonical trace, or driver policy; inspect native/public seams and the
    existing nine-family checker; split recoverable leaves before Julia or global-driver code changes.
  Verification: **PASS 2026-07-10.** After Julia project/depot warmup, the unchanged suite baseline is 13/61:
    all 11 ordinary success/result cases plus `none`/`quiet` trace pass. The 48 failures partition into exact shared
    help/usage bytes; malformed-UTF-8 acceptance and backend-detail error suffixes; and rich native trace bytes in
    place of canonical trace. Existing native parse/compile/execute/canonical JSON controls remain reusable. Cold
    first-process precompile progress is Julia toolchain ambient output; the existing local checker already warms
    the project, and the final global driver must do likewise. No Julia behavior changed in this audit/split.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.4.0 - split Julia global CLI repair`

- ID: `FUTURE-PARITY-BACKLOG.1.5.4.1`
  Status: `done`
  Goal: Align Julia shared help, strict UTF-8 file loading, and stable phase-only failures.
  Acceptance: Julia renders the exact shared help/usage template for its executable token, rejects malformed UTF-8
    source/input while preserving valid text/BOM/newlines, and emits only the stable compile/input/invoke heading
    on primary stderr; rich diagnostics remain available through native APIs and native trace. Ordinary success
    behavior stays native and unchanged.
  Verification: **PASS 2026-07-10.** `_primary_cli_usage()` is byte-identical to the shared template for
    `linkedspec_julia`; `_read_primary_cli_file(...)` validates raw file bytes as UTF-8 without normalization,
    BOM, or newline conversion; primary operational stderr contains exactly one phase heading. The package passes
    1,019 assertions, the updated nine-family process checker, and 99/99 corpus fixtures. The unchanged suite
    advances 13 -> 42/61 in both default and `POSIXLY_CORRECT=1` environments; all 19 residuals are canonical-trace
    cases owned by `.2`.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.4.1 - align Julia CLI boundary`

- ID: `FUTURE-PARITY-BACKLOG.1.5.4.2`
  Status: `done`
  Goal: Replace Julia primary rich trace output with the independent canonical CLI trace projection.
  Acceptance: Julia emits ADR `0024`'s exact levels/events, UTF-8 byte counts, escaping, emoji, stdout/route/mirror,
    reset/append/persistence, and traced failures while keeping its rich native trace emitter independent; all 61
    unchanged cases pass in default and POSIX environments.
  Verification: **PASS 2026-07-10.** Julia's primary command owns an independent canonical phase recorder with
    exact named/numeric thresholds, UTF-8 byte counts, percent escaping, emoji, stdout/route/mirror defaults,
    reset/append/persistence, result framing, and compile/input/invoke failure records. The rich native emitter
    remains unchanged and directly tested. The package passes 1,019 assertions, nine real-process families and
    99/99 corpus; all 61 unchanged cases pass in default and POSIX environments.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.4.2 - add canonical Julia CLI trace`

- ID: `FUTURE-PARITY-BACKLOG.1.5.4.3`
  Status: `done`
  Goal: Add one recurring four-backend identity driver and close the exact CLI parity lane.
  Acceptance: One repo-owned command warms toolchains where required and runs the same unchanged manifest against
    Perl, built Rust, Dart, and Julia in default/POSIX environments; each focused backend gate and the broader core
    gate pass; task/roadmap/live docs, mdBook, Knowledge Map, help, fixtures, and cleanup agree before `.1.6`.
  Verification: **PASS 2026-07-10.** `tools/run_primary_cli_matrix.sh` builds Rust, prepares/warmups Dart, warms
    Julia, and passes 4 backends x 2 environments x 61 unchanged cases. It is available to the core gate through
    `LINKEDSPEC_RUN_CLI_MATRIX=1`; all backend scripts are tracked/syntax-checked CI inputs. Rust focused proof
    passes 137 unit/99 oracle/190 integration/3 emitter/10 trace plus 61x2; Dart passes format/analyzer/151 tests/
    61x2/99 corpus; Julia passes 1,019 assertions/nine process families/99 corpus. The broader gate passes
    doctrines, syntax, 22 ActionIR, nine runner/trace, Perl 61x2, and Phase 0 `1..1028` in 499 seconds. Safe cleanup
    removes 1.6 GB Rust target, 143 MB Julia depot, and 30 MB Dart cache after their results are consumed.
  Commit: `FUTURE-PARITY-BACKLOG.1.5.4.3 - close exact primary CLI parity`

- ID: `FUTURE-PARITY-BACKLOG.1.6`
  Status: `done`
  Goal: Prove complete user-observable feature/behavior parity beyond the 99-fixture interpreter corpus.
  Children: `.1.6.0`, `.1.6.1`, `.1.6.2`, `.1.6.3`, `.1.6.4`, `.1.6.5`, `.1.6.6`
  Acceptance: Build a machine-readable capability matrix from the mdBook, exported public APIs, Phase 0, and the
    language-neutral corpus; classify Perl/Rust/Dart/Julia gaps before implementation; split every gap into an
    owned parity leaf; do not call a backend full-parity while any user-visible capability differs.
  Verification: `.0`–`.6` establish a validated 15x4 census, exhaustive 239-name/105-fixture current-language proof,
    exact outward descriptors, four-backend structured diagnostics, exact native named/file resolution, complete
    Dart full-pipeline trace, and final owner/no-drift closeout. The final matrix is 57 pass, one partial, two gaps;
    its only non-pass capability is generated parser source (Rust partial; Dart/Julia gaps), all owned by `.3`.
    Canonical core CI immediately prior passes 61x2 CLI and Phase 0 `1..1030`; recent complete backend gates remain
    adjacent and green. Non-codegen capability parity is closed without claiming complete generated-source parity.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.6 - close non-codegen capability parity`

- ID: `FUTURE-PARITY-BACKLOG.1.6.0`
  Status: `done`
  Goal: Audit and classify the complete user-observable capability surface before parity implementation.
  Acceptance: Define a machine-readable capability schema; inventory canonical mdBook behavior, exported native
    APIs, Phase 0, the 99-case interpreter corpus, exact primary CLI, trace, and generated-source boundaries;
    record evidence and current Perl/Rust/Dart/Julia status without re-deriving logged facts; validate the inventory;
    split every concrete residual mechanism into ordered owned leaves before changing backend behavior.
  Verification: **PASS 2026-07-10.** A strict checker validates 15 capability rows x four exact backends, 47 pass/
    five partial/eight gap states, every evidence path, and every residual/exclusion owner. The core gate runs the
    checker and passes 22 ActionIR, nine runner/trace, Perl 61x2, and Phase 0 `1..1028` in 496 seconds. mdBook,
    Knowledge Map, governance, whitespace, and cleanup pass; no parser/compiler/runtime behavior changed.
  Commit: `FUTURE-PARITY-BACKLOG.1.6.0 - audit backend capability parity`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1`
  Status: `done`
  Goal: Turn the complete current mdBook language/helper surface into neutral executable capability proof.
  Children: `.1.6.1.0`, `.1.6.1.1`, `.1.6.1.2`
  Acceptance: Map every current non-legacy language, rule, lifecycle, ActionIR, helper, method, value-kind, cursor,
    capture, function, and staged-body contract to an existing neutral fixture or add a backend-neutral fixture;
    run unchanged on Perl/Rust/Dart/Julia; split any behavioral mismatch by mechanism before repair.
  Verification: The corrected Dart/Julia inventories contain 239 current call names and match exactly. The strict
    checker proves every name appears in the mdBook and 105-case neutral corpus, and reverse-checks every current
    Perl contract call used by that corpus against both inventories. Perl generates all 105 exact values; Rust,
    Dart, and Julia execute the unchanged manifest 105/105. `language.current_mdbook_surface` is pass on all four
    backends, and the strict checker is part of the recurring local CI gate.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.1.2.2.5 - admit exhaustive capability corpus`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.0`
  Status: `done`
  Goal: Audit exhaustive current-call documentation/corpus coverage and split every observed mismatch before code.
  Acceptance: Derive the shared Dart/Julia current ActionIR call-name inventory, require exact set identity, audit
    every name against the mdBook and neutral corpus source (including canonical parser-produced markers), seed
    bounded Perl-oracle fixtures by semantic family, capture toolbox source/runtime evidence for each blocker, and
    split rather than repair every mismatch found; do not require the incomplete fixtures to join the manifest yet.
  Acceptance Checklist:
    - REPRODUCE: run the inventory auditor in report mode and execute the bounded fixture families against Perl.
    - ROOT CAUSE: use `TOOLBOX.md` probes to identify whether failures are inventory, documentation, parser,
      statement-splitting, lowering, or runtime seams rather than classifying them from fixture output alone.
    - FIX: install the reusable strict/report auditor, canonical neutral fixture sources, and exact repair/closeout
      child leaves; do not change runtime behavior in this audit slice.
    - ADDRESSED: record every discovered mismatch in a durable fact card and an owning child acceptance contract.
    - NO REGRESSION: syntax-check the auditor and run the existing focused separator locks plus governance gates.
    - LOCKSTEP: update the roadmap/task frontier, live docs, MEMORY resume pointer, mdBook limitation note, and
      generated Knowledge Map in the same commit.
  Verification: `perl -c tools/check_language_capability_coverage.pl` passes; report mode derives 237 identical
    Dart/Julia current call names, zero missing mdBook names, and 98 names absent from the 99-fixture corpus.
    Direct Perl execution passes pure-helper, position-helper, and one-line separator-explicit control fixtures;
    toolbox probes reproduce missing generated boundaries/raw targets for capture, cursor, and newline marker
    families. `PERL5LIB= prove -v -Iperl t/phase0_regression.t` passes `1..1028` in 501 seconds.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.0 - audit neutral language coverage`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.1`
  Status: `done`
  Goal: Make physical newlines universally separate ActionIR statements without requiring trailing semicolons.
  Acceptance: Root-cause and repair Perl reference splitting/lowering so consecutive ordinary helpers, assignments,
    cursor/capture calls, and `if/i`/`elseif/elif`/`else`/`endif` plus switch markers separated by physical newlines
    lower equivalently to same-line semicolon-separated statements; preserve nested strings/regexes/blocks; add
    focused source/runtime locks and unchanged Rust/Dart/Julia neutral proof before resuming coverage closeout.
  Acceptance Checklist:
    - REPRODUCE: use `call_spec_handler_subst` to lock the capture/cursor raw-target and marker-chain failures.
    - ROOT CAUSE: prove the depth-zero splitter recognizes only complete call statements, so assignment lines absorb
      their successors even though nesting/quote state already protects payload newlines.
    - FIX: consume every unquoted depth-zero LF/CRLF/CR as a boundary, including a completed line comment, without
      weakening same-line adjacency or attached-continuation rules.
    - ADDRESSED: lock assignment/cursor/marker splits and exact lowering plus cursor/control runtime execution.
    - NO REGRESSION: protect multiline parentheses, blocks, quotes, regex substitutions, comments, CRLF, and the
      unchanged 99-fixture Perl/Rust/Dart/Julia corpus.
    - LOCKSTEP: remove the mdBook limitation, resolve the Knowledge Map gap, update live docs/frontier, and clean
      every generated backend cache after verification.
  Verification: toolbox lowering now emits independent `$` targets and generated Perl terminators for capture and
    cursor sequences, and fully lowers newline if/switch marker chains. The new 17-assertion Phase 0 subtest covers universal
    LF/CRLF/CR boundaries, nesting/quote/regex/comment protection, exact lowering, and cursor/control runtime;
    `PERL5LIB= prove -v -Iperl t/phase0_regression.t` passes `1..1029` in 490 wall-clock seconds. Perl regeneration produces
    the unchanged 99 fixtures; Rust, Dart, and Julia each pass 99/99. Four stale empty corpus artifact directories
    were removed after their manifest-guard failure; 1.4 GB Rust, 86 MB Julia, and 20 KB Dart caches were removed
    after all results were consumed.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.1 - enforce universal newline separators`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2`
  Status: `done`
  Goal: Complete and run exhaustive current-call neutral coverage after newline separator repair.
  Children: `.1.6.1.2.0`, `.1.6.1.2.1`, `.1.6.1.2.2`
  Acceptance: Finish bounded pure/position/capture/mark/cursor/control fixtures, make the coverage checker require
    every current Dart/Julia ActionIR name in the mdBook and generated neutral corpus, regenerate Perl oracle bytes,
    run the unchanged corpus on Perl/Rust/Dart/Julia, split any residual behavioral mismatch, and close parent
    `.1.6.1` only when `language.current_mdbook_surface` can move from partial to pass.
  Verification: Universal newline separation, contract-aware switch closure, all exact-value repair children,
    reconciled call inventories, and final 105-case admission are complete on all four implemented backends.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.1.2.2.5 - admit exhaustive capability corpus`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.0`
  Status: `done`
  Goal: Correct capture fixture timing and split the residual newline control-close terminator mismatch before code.
  Acceptance Checklist:
    - REPRODUCE: execute all six seeded fixtures after the splitter repair and inspect any failure with toolbox APIs.
    - ROOT CAUSE: distinguish fixture action timing from canonical lowering and isolate invalid generated Perl after
      a newline-separated `endswitch()` followed by another statement.
    - FIX: define separate repair and final-coverage leaves; make no compiler/runtime change in this audit slice.
    - ADDRESSED: route control-close termination to `.2.1` and corrected fixture/oracle admission to `.2.2`.
    - NO REGRESSION: preserve the committed 99-case corpus and green `.1.6.1.1` Phase 0 boundary.
    - LOCKSTEP: record the temporary mdBook qualification, fact card, task frontier, and live resume pointer.
  Verification: corrected in-memory capture probes using `Top::AND => Value`, three regex slots, and action indexes
    `0`/`2` return exact anonymous/named hashes. The multiline combined control fixture compiles to invalid Perl:
    `call_spec_handler_subst` emits the closing switch `} }` followed directly by `return [...]`; the earlier
    `if/endif` block followed by assignment is valid. Source inspection maps this to the generic leading-`}`
    terminator suppression in `RewritePipeline::_lowered_statement_needs_terminator`.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.0 - split control-close terminator residual`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.1`
  Status: `done`
  Goal: Insert the implicit newline terminator after switch-control closure without weakening block continuations.
  Acceptance: Make newline-separated `endswitch()` followed by any ordinary statement lower equivalently to the
    semicolon-separated same-line form; key the terminator decision to the actual control contract/lowered shape so
    `if`/`elseif`/`else`, `while`, attached continuations, and nested block payloads remain valid; add focused source
    and runtime locks plus Phase 0 before returning to coverage.
  Verification: `RewritePipeline` now records `contract_id` with each pending lowered statement and requires a
    generated terminator specifically for newline-separated `endswitch_flow` before generic leading-`}` block
    suppression. Five focused assertions lock exact `};\nreturn`, absence of the invalid adjacency, unchanged
    `endif` closure output, successful multiline compilation, and runtime `["elif","case-b"]`.
    `perl -c perl/LinkedSpec.pm` and `perl -c -Iperl t/phase0_regression.t` pass;
    `PERL5LIB= prove -v -Iperl t/phase0_regression.t` passes `1..1030` in 491 wall-clock seconds.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.1 - terminate newline switch closure`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2`
  Status: `done`
  Goal: Correct fixture timing, admit exhaustive current-call families, and close strict four-backend proof.
  Children: `.1.6.1.2.2.0`, `.1.6.1.2.2.1`, `.1.6.1.2.2.2`, `.1.6.1.2.2.3`,
    `.1.6.1.2.2.4`, `.1.6.1.2.2.5`
  Acceptance: Apply the proven three-slot capture/mark timing, use newline-only control source, register all six
    source fixtures in oracle generation, regenerate exact Perl values, reconcile the provisional 237-name inventory
    against the current Perl registry and make strict corrected-name coverage pass, run the
    expanded corpus unchanged on Perl/Rust/Dart/Julia, update `language.current_mdbook_surface`, and close `.1.6.1`.
  Verification: Corrected pure, position, marker-control, and capture/mark fixtures match exactly on every
    backend. Final admission reconciles the two omitted bridge helpers, generates all 105 reference values, passes
    strict 239-name coverage, and runs 105/105 on Perl, Rust, Dart, and Julia.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.1.2.2.5 - admit exhaustive capability corpus`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.0`
  Status: `done`
  Goal: Execute the corrected exhaustive fixtures, root-cause the advertised-call/runtime gap, and split repair.
  Acceptance Checklist:
    - REPRODUCE: run all six corrected fixture families directly on Perl and diagnostically in a generated 105-case
      corpus on Rust, Dart, and Julia.
    - ROOT CAUSE: distinguish call-name inventory coverage from executable semantics and classify every mismatch
      by value, position, control, or capture/mark mechanism.
    - FIX: define backend-specific children for each mechanism before changing backend code.
    - ADDRESSED: retain corrected governed sources and reusable repo-relative `source_file` generator support while
      keeping the mandatory manifest at the last green 99-case boundary.
    - NO REGRESSION: prove the original 99 cases still pass on every backend during the diagnostic 105-case run.
    - LOCKSTEP: update task/live/book/Knowledge Map surfaces with exact counts and owners.
  Verification: Perl produces exact values for all six fixtures and regenerates 105/105. Strict source-name
    coverage reaches 237/237. Rust, Dart, and Julia each pass the original 99 plus cursor control and fail the same
    five new families (100/105), with backend-specific details: common pure-value mismatch; empty local-match
    projection mismatch; Rust missing `i`/`elif` while Dart/Julia select marker default after a matching case; and
    incomplete capture/mark helper execution on all three. The diagnostic six directories and manifest entries
    were removed after evidence capture so the mandatory corpus stays green at 99 until repair closes.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.0 - split executable capability residuals`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.1`
  Status: `done`
  Goal: Align exhaustive pure/aggregate helper values with the Perl reference.
  Children: `.1.6.1.2.2.1.1`, `.1.6.1.2.2.1.2`, `.1.6.1.2.2.1.3`
  Acceptance: Close exact predicate/comparison `1`/`0`, direct-literal `flat` splicing, and statement-form
    `uppercase_each` mutation without weakening typed literal booleans or value-form array transformations.
  Verification: Perl, Rust, Dart, and Julia now return the same governed exact hash. Each non-reference backend
    preserves typed booleans and pure value/receiver transforms while projecting the historical predicate family
    as numeric `1`/`0`, splicing explicit direct-literal `flat`, and mutating explicit working-array transforms
    only in statement context. Recorded backend-focused suites and unchanged 99-case corpora pass.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.1.2.2.1.3 - align Julia pure helper values`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.1.1`
  Status: `done`
  Goal: Align Rust pure/aggregate helper value semantics.
  Acceptance: The pure fixture returns the exact Perl hash; focused Rust locks distinguish numeric predicate results,
    direct-literal flat splicing, and mutation-vs-value `uppercase_each`; existing 99-case corpus remains green.
  Verification: Rust now returns numeric `1`/`0` for the fixture's string/array/hash/numeric predicates while
    preserving typed literal booleans; direct array literals splice explicit `flat` calls; standalone
    `trim_each`/`lowercase_each`/`uppercase_each(array(name))` mutate the named working array while value/receiver
    forms remain pure. The governed exact-value integration lock passes. Stale internal helper-result expectations
    were aligned without changing string-comparison or literal-boolean expectations. `cargo fmt --all -- --check`,
    focused fixture, full 191-test integration, and unchanged 99-case oracle (three harness tests) pass.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.1.1 - align Rust pure helper values`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.1.2`
  Status: `done`
  Goal: Align Dart pure/aggregate helper value semantics under the same exact fixture.
  Acceptance: Match the repaired Rust/Perl value without backend-specific source or CLI behavior.
  Verification: Dart now returns numeric `1`/`0` for the fixture's string/array/hash/numeric predicates while
    preserving typed literal booleans; direct array literals splice explicit `flat` calls; standalone
    `trim_each`/`lowercase_each`/`uppercase_each(array(name))` mutate the named working array while value/receiver
    forms remain pure. The governed exact-value runtime lock passes. Twelve stale serialized fields across four
    existing helper tests were aligned without changing regex-match, string-comparison, definedness, or
    literal-boolean results.
    `dart format`, fatal analyzer, all 152 package tests, both 61-case CLI environments, and the unchanged 99-case
    corpus pass through `tools/run_dart_local.sh`.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.1.2 - align Dart pure helper values`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.1.3`
  Status: `done`
  Goal: Align Julia pure/aggregate helper value semantics under the same exact fixture.
  Acceptance: Match the repaired Rust/Perl/Dart value without backend-specific source or CLI behavior and close `.1`.
  Verification: Julia now returns numeric `1`/`0` for the fixture's string/array/hash/numeric predicates while
    preserving typed literal booleans; direct array literals reuse explicit array-splice classification; standalone
    `trim_each`/`lowercase_each`/`uppercase_each(array(name))` mutate the named working array while value/receiver
    forms remain pure. The governed exact source lock passes. Twelve stale serialized fields across four existing
    helper tests were aligned without changing regex-match, string-comparison, definedness, logical, or literal
    boolean results. The offline package entrypoint passes 1,020 assertions, both shared 61-case CLI environments
    pass, and the unchanged corpus passes 99/99.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.1.3 - align Julia pure helper values`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.2`
  Status: `done`
  Goal: Align empty local-match position projection on Rust, Dart, and Julia.
  Children: `.1.6.1.2.2.2.1`, `.1.6.1.2.2.2.2`, `.1.6.1.2.2.2.3`
  Acceptance: Match Perl's exact null capture/length/position plus empty-map/list/has and 1-based line/column defaults
    after entry match without inventing a local match; close one backend per committed child.
  Verification: Rust, Dart, and Julia now return the exact Perl position fixture value and independently preserve
    a real zero-width match at offset zero. Each backend projects absent local capture/length/position as null,
    containers as empty, named presence as numeric `0`, and diagnostic line/column defaults as 1. The unchanged
    99-case corpus remains green on every backend.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.1.2.2.2.3 - align Julia empty-match positions`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.2.1`
  Status: `done`
  Goal: Align Rust empty local-match position projection.
  Acceptance: Exact position fixture value and existing corpus pass.
  Verification: Explicit entry/local presence bits now travel with every saved rule match frame, so initialized
    zero offsets no longer invent a local match and a real zero-width match at offset zero remains present. With no
    local match, text/group/length/start/end positions are `undef`; group/map containers are empty; `match_has` is
    numeric `0`; line/column defaults remain 1. Entry/local named-presence helpers return numeric `1`/`0`. The
    exact governed fixture and an independent zero-width regression pass. `cargo fmt --all -- --check`, 137
    library tests, 193 integration tests, and the unchanged 99-case oracle (three harness tests) pass. Strict
    no-dependency clippy was attempted but remains red on 12 pre-existing unrelated lints; none names changed lines.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.2.1 - align Rust empty-match positions`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.2.2`
  Status: `done`
  Goal: Align Dart empty local-match position projection.
  Acceptance: Exact position fixture value and existing corpus pass.
  Verification: Dart's nullable `RuntimeRegexMatch` already distinguishes absence from a real zero-width match,
    so helper projection now preserves that state: absent capture/length/start/end values are `null`, group/map
    containers are empty, `match_has` is numeric `0`, and line/column diagnostics default to 1. Entry/local
    named-presence helpers return numeric `1`/`0`. The exact governed fixture and an independent zero-width-at-zero
    regression pass. `tools/run_dart_local.sh` passes formatting, fatal analysis, all 154 package tests, both
    61-case CLI environments, and the unchanged 99-case corpus.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.2.2 - align Dart empty-match positions`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.2.3`
  Status: `done`
  Goal: Align Julia empty local-match position projection and close `.2`.
  Acceptance: Exact position fixture value and existing corpus pass.
  Verification: Julia's nullable `RuntimeMatchRegisters.local_match` already distinguishes absence from a real
    zero-width match, so helper projection now returns numeric named presence and 1-based line/column defaults
    without changing null capture/length/start/end or empty group/map values. The governed exact fixture and an
    independent zero-width-at-zero regression pass. The offline package suite passes 1,022 assertions, both shared
    61-case CLI environments pass, and the unchanged corpus passes 99/99. The disposable 122 MB verification depot
    was removed after its result was consumed.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.2.3 - align Julia empty-match positions`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.3`
  Status: `done`
  Goal: Align marker aliases and matched-case/default control semantics.
  Children: `.1.6.1.2.2.3.1`, `.1.6.1.2.2.3.2`, `.1.6.1.2.2.3.3`
  Acceptance: Newline `i`/`elif` executes like `if`/`elseif`; a matching case excludes default; end markers preserve
    exact control boundaries; close one backend per committed child.
  Verification: Rust, Dart, and Julia return exact `["elif","case-b"]`: short aliases execute as canonical
    if/elseif controls and a matched switch case excludes default. The unchanged 99-case corpus remains green on
    every backend.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.1.2.2.3.3 - align Julia marker control`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.3.1`
  Status: `done`
  Goal: Align Rust marker aliases/control fixture.
  Acceptance: Remove unknown `i`/`elif` diagnostics and return `["elif","case-b"]` without regressing switch.
  Verification: Rust's known-call registry and statement-if gate now recognize `i` as `if` and `elif` as
    `elseif`; existing switch frames already suppress `default` after a matched case. The exact governed fixture
    returns `["elif","case-b"]`. `tools/run_rust_local.sh` passes formatting, 137 library tests, the unchanged
    99-case oracle, 194 integration tests, three source-emitter tests, ten trace tests, and both 61-case CLI
    environments. The 1.6 GB reproducible target directory was removed after verification.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.3.1 - align Rust marker control`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.3.2`
  Status: `done`
  Goal: Align Dart marker switch selection.
  Acceptance: Preserve alias behavior and exclude default after matching case; exact control fixture passes.
  Verification: Dart now groups marker-form `switch`/`case`/`default`/`endcase`/`endswitch` statements into one
    selectable chain in both action and value blocks. It evaluates the subject once, executes only the first
    matching case or otherwise default, and handles nested marker switches. Existing typed `i`/`elif` alias
    normalization is unchanged. The governed fixture returns `["elif","case-b"]`; formatting, fatal analysis,
    all 155 package tests, both 61-case CLI environments, and the unchanged 99-case corpus pass.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.3.2 - align Dart marker control`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.3.3`
  Status: `done`
  Goal: Align Julia marker switch selection and close `.3`.
  Acceptance: Preserve alias behavior and exclude default after matching case; exact control fixture passes.
  Verification: Julia groups marker-form switch siblings into one nesting-aware selectable chain in action and
    value blocks, evaluates the subject once, and executes only the first matching case or otherwise default.
    Existing typed `i`/`elif` normalization remains unchanged. The governed fixture returns `["elif","case-b"]`;
    the offline package suite passes 1,023 assertions, both shared 61-case CLI environments pass, and the unchanged
    corpus passes 99/99. The disposable 122 MB depot was removed after verification.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.3.3 - align Julia marker control`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.4`
  Status: `done`
  Goal: Complete anonymous/named capture-mark executable semantics.
  Children: `.1.6.1.2.2.4.1`, `.1.6.1.2.2.4.2`, `.1.6.1.2.2.4.3`
  Acceptance: Exact anonymous and named hashes pass, including stable/advancing reads, bridge/reset, mark metadata,
    input boundary marks, copied marks, and two-mark advancing reads; close one backend per committed child.
  Verification: Rust, Dart, and Julia now return both exact governed capture hashes. Each preserves symbolic bare
    mark names, rule-local named anchors, character-based public positions/lengths over host-safe internal
    offsets, stable and advancing anonymous/named reads, bridge/reset helpers, input-boundary/copy marks, and
    two-mark reads. Non-repeated `AND` blind-call wrappers retain ordered child values unless explicitly
    overridden. Each backend's recurring package, CLI, and unchanged 99-case corpus gate passes.
  Commit: completed by children `.4.1` through `.4.3`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.4.1`
  Status: `done`
  Goal: Complete Rust capture/mark fixture semantics.
  Acceptance: Both exact fixture hashes pass with no unknown-helper warning and existing corpus remains green.
  Verification: Rust now preserves bare mark identifiers symbolically, implements the missing anonymous/named
    bridge, column, copied-slice, and two-mark advancing helpers, and projects `mark_exists` as numeric `1`/`0`.
    The governed anonymous and named hashes match Perl exactly. The capture sources also exposed and closed Rust's
    non-repeated `AND` blind-call default-result gap in both interpreted and generated-plan execution: absent an
    explicit parent return, the parent surfaces the ordered child-return array. `tools/run_rust_local.sh` passes
    formatting, 137 library tests, the unchanged 99-case oracle, 196 integration tests, three source-emitter
    tests, ten trace tests, and both 61-case CLI environments.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.4.1 - complete Rust capture marks`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.4.2`
  Status: `done`
  Goal: Complete Dart capture/mark fixture semantics.
  Acceptance: Both exact fixture hashes pass with no unsupported-helper failure and existing corpus remains green.
  Verification: Dart now owns a rule-local code-unit named-mark store with character-based public positions and lengths,
    executes all stable/advancing anonymous and named reads, preserves bare symbolic mark names, bridges the
    anonymous start to/from named marks, and implements input-boundary/copy/two-mark operations. Non-repeated
    `AND` blind-call parents surface ordered child returns unless explicitly overridden. Both governed hashes plus
    independent implicit-result and rule-local-mark locks pass. `tools/run_dart_local.sh` passes formatting, fatal
    analysis, all 160
    package tests, both 61-case CLI environments, and the unchanged 99-case corpus. The reproducible 30 MB Dart
    cache was removed after verification.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.4.2 - complete Dart capture marks`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.4.3`
  Status: `done`
  Goal: Complete Julia capture/mark fixture semantics and close `.4`.
  Acceptance: Both exact fixture hashes pass with no unsupported-helper failure and existing corpus remains green.
  Verification: Julia now stores named marks as rule-local input code-unit offsets and exposes character-based
    positions and captured lengths. It executes the full governed stable/advancing anonymous and named families,
    anonymous/named bridge operations, current/input-boundary/copied marks, and two-mark reads while preserving
    bare symbolic mark names. Non-repeated `AND` blind-call parents surface ordered child returns unless an
    explicit return overrides them. Both exact governed hashes plus independent implicit-result, rule-local-mark,
    and multibyte locks pass. `tools/run_julia_local.sh` passes 1,028 package assertions, primary CLI conformance,
    and the unchanged 99/99 corpus. The disposable 70 MB depot was removed after verification; `.4` closes.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.4.3 - complete Julia capture marks`

- ID: `FUTURE-PARITY-BACKLOG.1.6.1.2.2.5`
  Status: `done`
  Goal: Admit all six fixtures and close strict current-call proof.
  Acceptance: Register governed `source_file` cases, regenerate 105 exact values, pass strict reconciled-name
    coverage (the earlier 237-name count is provisional),
    run 105/105 unchanged on Perl/Rust/Dart/Julia, promote all four `language.current_mdbook_surface` states to
    pass, close `.1.6.1.2`/`.1.6.1`, and advance to `.1.6.2`. Before claiming the strict count, reconcile the
    governed capture sources against the shared current-call inventories: `start_capture_slice_from` and
    `mark_capture_slice` are current Perl contracts used by those sources but are absent from the aligned
    Dart/Julia 237-name sets, so the final count is provisional until that omission is corrected atomically.
  Verification: `mark_capture_slice` and `start_capture_slice_from` now belong to both Dart and Julia known-call
    and capture-family tables, raising the exact shared inventory from provisional 237 to corrected 239. The
    coverage checker now also derives current non-compatibility Perl contract names and rejects any such neutral
    corpus call absent from both backend inventories. All six governed `source_file` cases are byte-identical in
    the generated corpus; Perl regenerates 105 exact values and strict coverage reports 239 names/105 fixtures,
    zero book gaps, zero corpus gaps, and zero missing Perl contract calls. Recurring gates pass: Rust 137 library,
    105 oracle, 196 integration, three emitter, ten trace, and 61x2 CLI; Dart formatting/analyzer, 160 tests,
    61x2 CLI, and 105 corpus; Julia 1,036 assertions, primary CLI, and 105 corpus. The strengthened core gate passes
    22 ActionIR tests, nine CLI/trace tests, Perl 61x2, and Phase 0 `1..1030` in 490 seconds. The local gate now
    runs strict language coverage permanently. Generated 1.6 GB Rust, 30 MB Dart, and 122 MB Julia caches were
    removed after verification.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.1.2.2.5 - admit exhaustive capability corpus`

- ID: `FUTURE-PARITY-BACKLOG.1.6.2`
  Status: `done`
  Goal: Add Rust's backend-neutral outward compiled-descriptor projection.
  Children: `.1.6.2.0`, `.1.6.2.1`, `.1.6.2.2`, `.1.6.2.3`
  Acceptance: Rust exposes the documented `spec`, `functions`, `dependency_regex_map`, and `meta` projection with
    stable field meanings/order and staged function metadata equivalent to Perl/Dart/Julia; focused neutral shape
    fixtures prove idiomatic Rust types/JSON without coupling callers to engine internals.
  Verification: The canonical descriptor contract is consumed by focused tests in all four variants. Exact outer
    function fields, metadata identities/order, rule/dependency semantics, and staged function values pass; the
    complete relevant backend gates pass and the capability state is promoted to pass.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.2.3 - admit exact descriptor parity`

- ID: `FUTURE-PARITY-BACKLOG.1.6.2.0`
  Status: `done`
  Goal: Audit the outward descriptor contract and split implementation without copying an existing drift.
  Acceptance: Use the Perl `return_descriptor` toolbox probe plus Rust/Dart/Julia source and focused tests to
    identify the canonical public shape, record any cross-variant mismatch durably, and split bounded repair,
    Rust-projection, and final-admission leaves before production changes.
  Verification: The reference probe returns exactly `spec`, `functions`, `dependency_regex_map`, and `meta`, but
    exposes `meta.descriptor_model = compiled_spec_state_v1`; `CompilerState.pm` proves the actual composing owner
    is `kind = compiled_descriptor_state`. The mdBook plus Dart and Julia instead expose the semantically correct
    wrapper identity `compiled_descriptor_state`; Phase 0 contains two explicit locks for the stale Perl tag. Rust
    has no descriptor projection, explicit dependency-ref state, or descriptor-focused tests. The implementation
    is split into public metadata reconciliation `.1`, Rust projection `.2`, and four-backend admission `.3`.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.2.0 - split outward descriptor parity`

- ID: `FUTURE-PARITY-BACKLOG.1.6.2.1`
  Status: `done`
  Goal: Reconcile the canonical outward descriptor-model identity before adding Rust.
  Acceptance: Perl reports the documented composing descriptor-state identity and explicit nested model identities
    without changing rule/function/dependency payloads, parser behavior, or Dart/Julia values; focused descriptor
    locks, Phase 0, mdBook, census, and Knowledge Map agree.
  Verification: `compiled_spec_state_meta(...)` now reports `descriptor_model = compiled_descriptor_state` and
    explicit `compiled_spec_model = compiled_spec_state` / `compiled_dependency_regex_model =
    compiled_dependency_regex_state`. The focused `return_descriptor` probe preserves exactly the four top-level
    keys and verifies all three identities. Both former Phase 0 stale-tag locks now assert the composing identity
    plus nested models; the complete Phase 0 suite passes `1..1030` in 509 seconds. Dart/Julia already expose the
    same three values and were not changed.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.2.1 - reconcile descriptor model identity`

- ID: `FUTURE-PARITY-BACKLOG.1.6.2.2`
  Status: `done`
  Goal: Add an idiomatic Rust outward descriptor projection over existing compiled state.
  Acceptance: Public Rust APIs project deterministic `spec`, `functions`, `dependency_regex_map`, and `meta`
    values, including rule dependency refs and preserved staged function metadata, without coupling callers to the
    runtime engine or changing execution/serialization compatibility; focused shape/round-trip tests pass.
  Verification: `linkedspec-core::descriptor` exports typed serializable descriptor, rule, dependency-regex,
    function, mode, handler, and metadata records. `CompiledSpec::descriptor_state()` and
    `to_descriptor_json()` project the four public keys without a runtime-engine dependency. Compilation now
    preserves ordered `DependencyRef` values on `CompiledRule`; old serialized state remains readable through the
    default plus dispatch-derived fallback. Three focused tests prove exact shape/staged metadata, compiled-state
    JSON round-trip identity, and deterministic last-definition projection. The full core package passes. The full
    Rust gate passes formatting, 137 runtime, 105 oracle, 196 integration, three generated-source, ten trace, and
    61x2 CLI cases. Strict clippy reports only 14 pre-existing errors in untouched files and none in this leaf.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.2.2 - expose Rust compiled descriptors`

- ID: `FUTURE-PARITY-BACKLOG.1.6.2.3`
  Status: `done`
  Goal: Admit and close four-backend outward descriptor parity.
  Acceptance: Focused neutral shape evidence proves the documented top-level keys, metadata identities/order,
    rule/dependency semantics, and staged function fields across Perl/Rust/Dart/Julia; update the census from
    partial/gap to pass, synchronize public/live docs, run recurring gates, and advance to `.1.6.3`.
    The final comparison must also resolve the outer function-record convention exposed by `.2`: Perl uses
    `kind`/`version`/`source_text` without `index`, Dart/Julia use `index`/`source` without `kind`/`version`, and
    Rust currently publishes the neutral-definition identity plus `index`. Nested `body_payload`,
    `body_parse_job`, and `body_ast` semantics are already aligned.
  Verification: `capability_conformance/outward_descriptor_contract.json` defines the exact four top-level keys,
    required model/order metadata, and canonical outer function record: `index`, `kind`, `version`, `name`,
    `params`, `arity`, `source_text`, source/body spans and source, plus `body_payload`, `body_parse_job`, and
    `body_ast`. Perl adds the source-order index; Dart and Julia use descriptor-specific projections that add the
    neutral identity/source fields without changing their internal AST serialization; Rust already matches the
    convention. Focused contract tests pass on all four variants. Complete Dart passes formatting, analysis, 160
    tests, 61x2 CLI, and 105 corpus cases; Julia passes 1,040 assertions, its primary CLI process suite, and 105
    corpus cases; Rust's focused three tests pass after the prior full Rust gate; complete Perl Phase 0 passes
    `1..1030` in 775 wallclock seconds. The capability census is 52 pass / one partial / seven gap.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.2.3 - admit exact descriptor parity`

- ID: `FUTURE-PARITY-BACKLOG.1.6.3`
  Status: `done`
  Goal: Add structured Rust runtime diagnostic context equivalent to the other native backends.
  Children: `.1.6.3.0`, `.1.6.3.1`, `.1.6.3.2`
  Acceptance: Native Rust runtime failures expose stable type/stage/summary/detail plus available spec/top/rule/
    handler attribution as structured data rather than requiring string scraping; ordinary `Result` ergonomics,
    CLI phase projection, trace behavior, and successful results remain compatible.
  Verification: Typed/JSON diagnostic implementation, exact focused evidence, complete runtime package, complete
    recurring Rust gate, and both CLI environments pass. Existing success/string/trace/CLI behavior stays exact;
    the capability row is pass for all four variants.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.3.2 - admit Rust runtime diagnostics`

- ID: `FUTURE-PARITY-BACKLOG.1.6.3.0`
  Status: `done`
  Goal: Audit the real Rust runtime failure boundary and split implementation before behavior code.
  Acceptance: Knowledge Map and source/toolbox evidence identify the public execution result types, error
    propagation/unwind seam, source-identity availability, CLI adapter boundary, and every compatibility surface;
    record any mismatch in prior durable wording and create bounded implementation/admission owners.
  Verification: `rust/linkedspec-runtime::Engine` public execution methods and all internal runtime frames return
    `Result<_, String>`. The similarly named core `LinkedSpecError::Runtime(String)` is unused by the runtime crate,
    so the mdBook/census wording pointed at the wrong type. `execute_rule(...)` is the singular interpreted rule
    wrapper and observes a child error before its own frame unwinds, but `RuntimeContext` stores neither top/rule
    identity nor a last diagnostic. `Engine` stores only `CompiledSpec`; the primary CLI deliberately collapses
    any execution failure to its canonical `invoke:error` / `parser invocation failed` projection. `.1` owns typed
    records, source identity, diagnostic-aware native execution, and compatibility adapters; `.2` owns full
    no-drift proof, public docs, census promotion, and parent closeout.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.3.0 - split Rust runtime diagnostics`

- ID: `FUTURE-PARITY-BACKLOG.1.6.3.1`
  Status: `done`
  Goal: Add typed structured diagnostics to Rust native interpreted execution.
  Acceptance: Export serializable neutral diagnostic/error records; let callers optionally attach spec identity;
    expose diagnostic-aware accumulator/direct-value methods; preserve a failing child rule before unwind; keep
    existing string-returning methods, successful values, trace methods, and primary CLI behavior compatible.
  Verification: `linkedspec-runtime::diagnostic` exports serializable `RuntimeDiagnostic` and compact
    `RuntimeExecutionError`. `Engine` accepts optional spec name/path and exposes `execute_with_diagnostics(...)`
    plus `execute_value_with_diagnostics(...)`; existing string methods delegate through the typed path and recover
    the original message. `RuntimeContext` retains first/deepest failure context, and interpreted `execute_rule`
    captures it before variable/recursion unwind. Five focused tests prove exact JSON/source identity, deepest
    child rule, missing-entry `rule_lookup`, unavailable-field omission/top selection, success equality, and string
    compatibility. The complete runtime package passes 137 unit, 105 oracle, 196 integration, five diagnostic,
    three generated-source, and ten trace tests. Strict Clippy initially found two new large-error findings; boxing
    the nested diagnostic removes both, leaving exactly 14 pre-existing errors in untouched runtime/core files.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.3.1 - add Rust runtime diagnostics`

- ID: `FUTURE-PARITY-BACKLOG.1.6.3.2`
  Status: `done`
  Goal: Admit and close structured Rust runtime diagnostic parity.
  Acceptance: Focused error-shape/source/top/child-rule/success/string-compatibility tests and complete Rust/CLI
    gates pass; mdBook/live docs/capability census agree; promote the Rust state to pass and advance to `.1.6.4`.
  Verification: `tools/run_rust_local.sh` passes formatting, 137 unit, 105 oracle, 196 integration, five focused
    diagnostic, three generated-source, and ten trace tests, then exact 61/61 primary CLI conformance under both
    default and POSIX option environments. The capability checker promotes structured runtime diagnostics to pass
    and reports 53 pass / one partial / six gap. Generated Rust artifacts (2.0 GB) are removed after verification.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.3.2 - admit Rust runtime diagnostics`

- ID: `FUTURE-PARITY-BACKLOG.1.6.4`
  Status: `done`
  Goal: Add and exactly admit idiomatic native named/file spec resolution across all four current backends.
  Children: `.1.6.4.0`, `.1.6.4.1`, `.1.6.4.2`, `.1.6.4.3`, `.1.6.4.4`, `.1.6.4.5`
  Acceptance: Each library exposes the book's portable file-oriented role with deterministic explicit-path and
    named-spec resolution/search precedence, strict text loading, parse/compile composition, and structured errors;
    shared path fixtures prove equivalent behavior without requiring the primary CLI or a subprocess. Perl's
    legacy `get_parser` compatibility discovery remains separately available.
  Verification: ADR `0026` and its 14/9/4 fixture are consumed directly by Perl, Rust, Dart, and Julia native
    libraries. Each exposes separate portable name/exact-path intent, ordered direct roots, first-regular-file
    resolution, strict preserved UTF-8, retained source identity, progressive composition, structured stages/codes,
    and a backend-native compiled value. The final Perl facade leaves legacy `get_parser`/`PathSearch` untouched.
    Prior committed Rust/Dart/Julia complete recurring and 61x2 CLI gates remain green; final admission adds Perl
    direct proof to the canonical gate, which passes 239-name coverage, focused suites, 61x2 Perl CLI, and Phase 0
    `1..1030` in 556 seconds. Capability state remains 56/1/3 because this row was already promoted backend by
    backend; the parent is now exactly admitted.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.4.5 - admit native spec resolution parity`

- ID: `FUTURE-PARITY-BACKLOG.1.6.4.0`
  Status: `done`
  Goal: Audit the real four-backend resolution mechanisms and split implementation before behavior code.
  Acceptance: Source/tests establish validation, candidate precedence, fallback discovery, file-kind checks,
    strict-decoding ownership, parse/compile composition, and error seams; any process/native or cross-variant
    drift is durable; bounded neutral-contract, backend, and admission owners exist before implementation.
  Verification: Perl `LinkedSpec::Resolver` checks exact cwd, cwd `<name>.spec`, and module-root `specs/` before
    delegating a bare miss to `PathSearch`; that legacy fallback recursively caches cwd plus the repository tree,
    deduplicates through a hash, and selects the first hash-key match, so duplicate-name precedence is not
    deterministic or portable. Rust and Dart primary adapters stop after the first three candidates; Julia alone
    adds a sorted/pruned recursive repository fallback. All three non-Perl mechanisms are process-adapter-only.
    Rust/Julia require regular files and all three adapters decode strictly as UTF-8; Dart resolution currently
    tests existence before its later file read. `.1` owns one explicit ordered-root contract and fixture; `.2`,
    `.3`, and `.4` own Rust, Dart, and Julia native APIs; `.5` owns exact four-backend admission and CLI no-drift.
    No parser/compiler/runtime behavior changed.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.4.0 - split native spec resolution`

- ID: `FUTURE-PARITY-BACKLOG.1.6.4.1`
  Status: `done`
  Goal: Define the executable backend-neutral named/file resolution contract.
  Acceptance: A checked-in schema/fixture defines name validation, explicit-path handling, deterministic candidate
    order over explicit ordered search roots, regular-file requirements, strict preserved UTF-8, source identity,
    parse/compile phase order, and structured failure stages; Perl's implicit recursive `PathSearch` remains a
    compatibility extension outside this portable API rather than silently defining duplicate-name precedence.
  Verification: ADR `0026` fixes separate named/path requests, portable traversal-safe names, cwd/suffix/declared-
    root candidate order, direct non-recursive roots, first-regular-file selection, strict preserved UTF-8, exact
    source identity, pipeline order, and neutral typed error stages/codes. The original JSON contained 13 name,
    nine resolution/file-kind, and four text cases. Its independent Perl checker validates schema, task ownership,
    declared semantics, every expected outcome, Unicode/BOM/normalization preservation, malformed UTF-8, and no
    UTF-16 autodetection. The checker is wired into the canonical local gate. The complete gate passes the checker,
    239-name coverage, focused suites, exact Perl CLI 61/61 under default and POSIX environments, and Phase 0
    `1..1030` in 502 wallclock seconds. No backend behavior changed.
    Rust implementation `.2` subsequently adds the missing Windows-drive absolute-name rejection case, bringing
    the same versioned fixture to 14 name cases without changing the ratified policy.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.4.1 - define native spec resolution contract`

- ID: `FUTURE-PARITY-BACKLOG.1.6.4.2`
  Status: `done`
  Goal: Add Rust native named/file resolution and compilation.
  Acceptance: Public typed Rust APIs consume the neutral fixture without CLI/subprocess ownership, compose strict
    loading through parse/validate/compile, retain requested/resolved source identity, return structured errors,
    and let the primary CLI delegate without changing its exact contract.
  Verification: Public `spec_loader` exports typed name/path requests, cwd plus ordered direct roots, deterministic
    resolution origins, regular-file selection, strict byte read/UTF-8 decode, loaded/compiled source identity,
    serializable stage/code errors, and `LoadedCompiledSpec::into_engine()` attribution. It composes the full staged
    user-function parser, core validation, and compiler. Rust consumes all 14 name, nine resolution/file-kind, and
    four text cases directly; five focused tests also prove full function execution, parse/validation failures, and
    exact error JSON. The primary CLI delegates named/file requests to the native API while inline behavior stays
    unchanged. Full Rust gate passes 137 unit, 105 oracle, 196 integration, five runtime diagnostic, three generated-
    source, five loader, ten trace, and 61x2 CLI cases. Strict Clippy finds no new loader/CLI issue and stops on the
    same 14 pre-existing untouched runtime findings. The Rust capability state is pass; census is 54/1/5.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.4.2 - add Rust native spec resolution`

- ID: `FUTURE-PARITY-BACKLOG.1.6.4.3`
  Status: `done`
  Goal: Add Dart native named/file resolution and compilation.
  Acceptance: Public typed Dart APIs consume the neutral fixture without CLI/subprocess ownership, require regular
    files, compose strict loading through parse/compile, retain source identity, return structured exceptions, and
    let the primary CLI delegate without changing its exact contract.
  Verification: Public `src/io/spec_loader.dart`, re-exported from `linkedspec_dart.dart`, provides typed name/path
    requests, cwd plus ordered direct roots, deterministic candidate origins, regular-file selection, strict
    preserved UTF-8 loading, exact source identity, progressive resolve/load/compile results, neutral structured
    exceptions, and `LoadedCompiledSpec.createEngine()` attribution. The full composition uses the staged user-
    function parser, explicit validation, and compiler. Five direct-library tests consume all 14 name, nine
    resolution/file-kind, and four text cases, then prove staged-function execution, parse/validation separation,
    engine identity, and exact missing-name JSON. The primary CLI delegates named/file sources while inline source
    stays on its existing in-memory path. Format and strict analysis pass; the complete Dart gate passes 165 tests,
    exact 61/61 CLI cases under default and POSIX environments, and all 105 corpus fixtures. Dart promotes to pass;
    census is 55/1/4.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.4.3 - add Dart native spec resolution`

- ID: `FUTURE-PARITY-BACKLOG.1.6.4.4`
  Status: `done`
  Goal: Add Julia native named/file resolution and compilation.
  Acceptance: Public Julia APIs consume the neutral fixture without CLI/subprocess ownership, replace the CLI-only
    recursive fallback with the portable ordered-root policy, compose strict loading through staged parse/compile,
    retain source identity, return structured exceptions, and preserve exact primary CLI behavior.
  Verification: Public `src/io/SpecLoader.jl`, included and exported by `LinkedSpecJulia`, provides typed name/path
    requests, cwd plus ordered direct roots, deterministic candidate origins, regular-file selection, strict
    preserved UTF-8 loading, exact source identity, progressive resolve/load/compile results, typed stages/codes,
    structured JSON exceptions, and `create_engine(...)` attribution. The full composition uses the staged user-
    function parser, explicit validation, and compiler. Five direct-library testsets consume all 14 name, nine
    resolution/file-kind, and four text cases with 82 assertions, then prove staged-function execution, parse/
    validation separation, engine identity, and exact missing-name JSON. The primary CLI delegates named/file
    sources, removes its non-portable recursive repository fallback, retains deferred input loading, and keeps
    exact process behavior. The complete package passes 1,110 assertions; focused process checks, exact 61/61 CLI
    cases under default and POSIX environments, and all 105 corpus fixtures pass. Julia promotes to pass; census is
    56/1/3.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.4.4 - add Julia native spec resolution`

- ID: `FUTURE-PARITY-BACKLOG.1.6.4.5`
  Status: `done`
  Goal: Admit and close exact native named/file resolution parity.
  Acceptance: All four variants pass the shared direct-library fixture and their complete recurring/CLI gates;
    public docs and the capability census promote the role only after adapter no-drift; `.1.6.4` closes and the
    frontier advances to Dart full-pipeline trace `.1.6.5`.
  Verification: Added public `LinkedSpec::SpecLoader` with blessed name/path request, options, resolved/loaded/
    compiled result, and structured error types. It accepts cwd plus ordered direct roots, distinguishes exact
    paths, chooses regular files, decodes raw bytes with strict UTF-8, retains source/request/path identity, composes
    through `LinkedSpec::Get`, and projects the reference compiler's raw validation-before-bootstrap seam into the
    neutral parse/validate/compile error stages. `t/native_spec_resolution.t` directly consumes every 14/9/4 case
    and proves staged user-function execution plus exact errors. The test is a required canonical CI input. Focused
    proof and the complete core gate pass, including 61x2 CLI and Phase 0 `1..1030` in 556 seconds. Prior adjacent
    Rust, Dart, and Julia direct-library/full-gate commits supply the other three exact admission legs. Generated
    LinkedSpec artifacts are absent; active external mutation-test temp trees were identified and left untouched.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.4.5 - admit native spec resolution parity`

## `FUTURE-PARITY-BACKLOG.1.6.4.5` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Knowledge Map/source audit plus `rg -n 'get_parser|PathSearch|SpecLoader' perl t`
  proved Rust/Dart/Julia consumed the 14/9/4 fixture directly while Perl exposed only legacy `get_parser` resolution;
  the first `prove -v -Iperl t/native_spec_resolution.t` run reproduced the missing portable facade and exposed the
  correct top-rule action-edge execution shape before passing.
- [x] **ROOT CAUSE (WHY + WHERE)** — `perl/LinkedSpec/Resolver.pm:63` owns legacy local plus `PathSearch` discovery,
  while `perl/LinkedSpec/ParserFactory.pm:89` owns compatibility compilation. Neither accepts separate name/path
  request types or caller-ordered roots; raw `LinkedSpec::Get` validation also reports “must start with a rule” at
  `last_error.stage=validate_spec_content`, requiring neutral parse-stage projection in the portable facade.
- [x] **FIX** — Added `LinkedSpec::SpecLoader` as a separate typed portable request/options/result/error facade over
  ordered direct resolution, strict raw-byte UTF-8 decoding, retained identity, and `LinkedSpec::Get` composition;
  legacy `get_parser` and `PathSearch` remain untouched. Added direct fixture/pipeline proof and canonical-gate wiring.
- [x] **ADDRESSED (verified)** — `PERL5LIB= prove -v -Iperl t/native_spec_resolution.t` passes all five subtests:
  every 14/9/4 contract family, staged user-function compilation/execution, name/path identity, parse/validation
  separation, and exact missing-name error hash.
- [x] **NO REGRESSION** — `bash tools/run_ci_local.sh` passes the required Perl loader test, 239-name coverage,
  focused suites, 61x2 CLI, and Phase 0 `1..1030` in 556 seconds; prior committed Rust, Dart, and Julia loader plus
  complete recurring/61x2 CLI gates remain green.
- [x] **LOCKSTEP** — The same JSON contract remains the single fixture; this leaf synchronizes capability evidence,
  `tools/run_ci_local.sh`, mdBook/API examples, task/live/roadmap docs, and Knowledge Map before parent admission.

- ID: `FUTURE-PARITY-BACKLOG.1.6.5`
  Status: `done`
  Goal: Complete Dart native trace coverage across frontend, compiler, function-shell, and staged dispatch.
  Children: `.1.6.5.0`, `.1.6.5.1`, `.1.6.5.2`, `.1.6.5.3`
  Acceptance: One caller-owned Dart emitter propagates through parse, validation, compile, function-definition,
    staged-job, and runtime entrypoints with balanced scopes, decisions, failures, sinks, default quietness, and
    traced/untraced identity equivalent to Perl/Rust/Julia; focused and 99-corpus gates pass.
  Verification: Closed by `.0`–`.3`: exact audit/split, core frontend/compiler propagation, function/staged
    propagation, and public native composition/admission. One caller-owned emitter now spans file loading,
    parser-spec construction/runtime, AST projection, staged jobs, validation, compilation, registry construction,
    and final runtime execution with balanced scopes/failures, complete sinks, default quietness, and exact result/
    diagnostic identity. Full Dart gate passes 175 tests, 61x2 CLI, and 105 corpus; capability promotes to pass at
    census 57/1/2.
  Commit: closed by `FUTURE-PARITY-BACKLOG.1.6.5.3 - admit Dart full-pipeline trace`

- ID: `FUTURE-PARITY-BACKLOG.1.6.5.0`
  Status: `done`
  Goal: Audit and split Dart full-pipeline native trace before behavior changes.
  Acceptance: Establish the exact current emitter boundary, compare the established Julia/Rust portable proof,
    name every Dart propagation seam, and split implementation from final admission without overclaiming runtime-
    only trace as full-pipeline trace.
  Verification: Source and Knowledge Map audit confirms `LinkedSpecTraceEmitter` is public and complete for levels,
    events, sinks, and runtime interpreter entrypoints, but is imported only by `runtime/interpreter.dart` among the
    native pipeline owners. `parseSpec`, `validateSpec`, `compileSpec`, `UserFunctionRegistry`, function-definition
    parsing/projection, staged registry dispatch, and `loadAndCompileSpec` have no optional emitter. Julia's admitted
    implementation establishes the applicable optional caller-owned propagation pattern and balanced failure exits.
    No Dart behavior changed. `.1` owns frontend/compiler, `.2` owns function-shell/staged dispatch, and `.3` owns
    public loader composition, full proof, census promotion, and parent closeout.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.5.0 - split Dart full-pipeline trace`

## `FUTURE-PARITY-BACKLOG.1.6.5.0` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — `rg` across Dart native owners proves trace injection begins at
  `LinkedSpecRuntimeEngine.parse/execute`; the capability manifest therefore correctly keeps Dart at `gap` for the
  separate frontend/compiler/function/staged row.
- [x] **ROOT CAUSE (WHY + WHERE)** — Public operations in `parser/spec_parser.dart`, `validation/spec_validator.dart`,
  `compiler/compiled_spec.dart`, `action/function_registry.dart`, the two function-definition owners,
  `parser/staged_parser_registry.dart`, and `io/spec_loader.dart` have no emitter parameter or propagation path.
- [x] **FIX** — Split the active parent into bounded frontend/compiler `.1`, function-shell/staged `.2`, and composed
  native admission `.3` leaves; recorded the exact boundary in a Knowledge Map fact card and public/live docs.
- [x] **ADDRESSED (verified)** — Task-tree metadata, Knowledge Map generation/check, memory architecture, doctrines,
  whitespace, and mdBook build pass for the audit-only slice.
- [x] **NO REGRESSION** — No Dart parser/compiler/runtime/API behavior or capability state changed; the already-green
  165-test, 105-corpus, and 61x2 CLI baseline remains the implementation starting point.
- [x] **LOCKSTEP** — The split follows the admitted portable contract and Julia/Rust evidence while leaving Dart at
  `gap` until `.3` proves the complete caller-owned path and promotes all synchronized docs/metadata.

- ID: `FUTURE-PARITY-BACKLOG.1.6.5.1`
  Status: `done`
  Goal: Propagate one optional Dart trace emitter through source parsing, validation, and compilation.
  Acceptance: Existing public entrypoints remain source-compatible while emitting balanced `dart_frontend:*` and
    `dart_compiler:*` scopes, stable decisions, and failure exits through the caller's emitter; disabled/omitted
    tracing is quiet and parsed/compiled JSON is identical.
  Verification: `parseSpec`, `validateSpec`, `compileSpec`, and both `UserFunctionRegistry` factories now accept
    the same optional `LinkedSpecTraceEmitter` without changing existing calls. High-level balanced scopes cover
    parse, validation, compilation, and registry construction; medium decisions cover parsed rule counts,
    validation completion/skips, function definitions, compiled rules, and dependency-regex construction. All
    failure paths exit emitted scopes and rethrow the original object. Three focused tests prove exact event order,
    disabled quietness, parsed/compiled JSON identity, parse failure, and nested validation/compile failure. The six
    affected suites pass 38 tests; sequential strict analysis is clean. The complete Dart gate passes formatting,
    analysis, 168 tests, exact 61/61 CLI in default/POSIX environments, and all 105 corpus fixtures. Census remains
    56/1/3 until full function/staged/native admission.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.5.1 - trace Dart frontend and compiler`

## `FUTURE-PARITY-BACKLOG.1.6.5.1` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Audit `.0` proved core public frontend/compiler entrypoints could not receive the
  already-public emitter; focused tests now directly exercise those previously missing injection seams.
- [x] **ROOT CAUSE (WHY + WHERE)** — Parser, validator, compiler, and function-registry APIs had no optional trace
  dependency, so compilation could not preserve one caller-owned event order/sink/indent state.
- [x] **FIX** — Added source-compatible optional named emitter parameters, nested balanced scopes, medium decisions,
  validation propagation, and unchanged exception rethrows to the four owning modules.
- [x] **ADDRESSED (verified)** — Three focused tests compare traced/untraced `SpecFile` and `CompiledSpec` JSON,
  assert exact structured event order, prove disabled quietness, and lock parse plus validation failure exits.
- [x] **NO REGRESSION** — Format and strict analysis pass; six affected suites pass 38 tests; complete Dart gate
  passes 168 tests, 61x2 CLI, and 105/105 corpus.
- [x] **LOCKSTEP** — Public trace docs and durable facts describe the new partial boundary while the capability row
  remains `gap`; `.2` is active for function/staged propagation and `.3` alone owns promotion.

- ID: `FUTURE-PARITY-BACKLOG.1.6.5.2`
  Status: `done`
  Goal: Propagate the caller-owned Dart emitter through function-definition shell and staged parse dispatch.
  Acceptance: Parser-spec construction/execution, AST projection, job normalization/order, resolve/load/compile/
    execute, body stitching, and failures emit balanced function/staged events without changing ASTs or job results.
  Verification: Optional `trace:` now propagates through parser-spec construction/cache selection, definition-shell
    execution, AST projection, stripped-source parsing, staged function-body composition, single/batch queue
    execution, function-body dispatch, and stitching. One emitter retains nested ordering and sinks. Balanced high-
    level scopes cover function parsing/projection and staged queues/jobs; medium decisions cover definition counts,
    parser cache, projected definitions, normalized/sorted queues, each resolve/load/compile/execute phase, and body
    stitching. Four focused tests prove full topic coverage, scope balance, exact AST identity, disabled quietness,
    unchanged resolve failures, and preserved function-projection diagnostics. Strict analysis and the complete Dart
    gate pass formatting, 172 tests, exact 61/61 CLI in default/POSIX environments, and all 105 corpus fixtures.
    Census remains 56/1/3 until native composition/admission `.3`.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.5.2 - trace Dart function staging`

## `FUTURE-PARITY-BACKLOG.1.6.5.2` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Completed `.1` left function parser/shell and staged registry APIs without emitter
  parameters, so caller-owned ordering stopped before user-function extraction and resumed only at runtime.
- [x] **ROOT CAUSE (WHY + WHERE)** — `user_function_definition_parser.dart`,
  `user_function_definition_shell.dart`, and `staged_parser_registry.dart` independently called parser/compiler/
  runtime/staged phases without forwarding a trace dependency.
- [x] **FIX** — Added optional source-compatible propagation, balanced function/staged scopes, cache/definition/
  queue/phase/stitch decisions, runtime forwarding, and unchanged failure rethrows through all owning entrypoints.
- [x] **ADDRESSED (verified)** — Four focused tests prove end-to-end topics and balance, traced/untraced AST identity,
  disabled quietness, unchanged staged resolve failure, and original projection diagnostic classification.
- [x] **NO REGRESSION** — Format and strict analysis pass; complete Dart gate passes 172 tests, 61x2 CLI, and
  105/105 corpus.
- [x] **LOCKSTEP** — Public trace docs and Knowledge Map now describe frontend/compiler/function/staged/runtime
  coverage while leaving capability `gap`; `.3` alone owns loader composition, sink/failure admission, and promotion.

- ID: `FUTURE-PARITY-BACKLOG.1.6.5.3`
  Status: `done`
  Goal: Admit and close Dart full-pipeline native trace parity.
  Acceptance: `loadAndCompileSpec` accepts one caller-owned emitter and composes it through every frontend/function/
    staged/compiler phase into an engine using the same emitter at execution; focused failure/sink/identity proof,
    complete Dart/105-corpus/61x2 CLI gates, docs, and census all pass before parent closeout.
  Verification: `loadAndCompileSpec(..., trace:)` adds a balanced `dart_io:load_and_compile_spec` scope and loaded-
    source decision, then forwards the caller's emitter through staged function parsing, explicit validation, and
    compilation. The ordinary result does not retain mutable trace state; the caller passes the same emitter to
    `createEngine().execute(...)`. Three direct native tests prove one routed file contains IO/frontend/function/
    staged/compiler/runtime topics in balanced order with exact compiled/result identity, disabled tracing is empty,
    and validation failure JSON is unchanged with balanced failure exits. The initial focused compile caught and
    corrected `SpecCandidateOrigin.name` to its portable `contractName`. Format, strict analysis, 22 affected tests,
    and the full Dart gate pass 175 tests, 61x2 CLI, and 105 corpus. Canonical core CI passes 61x2 Perl CLI and
    Phase 0 `1..1030` in 514 seconds. The capability row promotes to pass, census is 57/1/2, `.1.6.5` closes, and
    `.1.6.6` becomes active.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.5.3 - admit Dart full-pipeline trace`

## `FUTURE-PARITY-BACKLOG.1.6.5.3` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — `.1`/`.2` proved every inner phase but `loadAndCompileSpec` still created the staged
  parser/validator/compiler path without accepting the caller's emitter, preventing one native composition proof.
- [x] **ROOT CAUSE (WHY + WHERE)** — `dart/lib/src/io/spec_loader.dart` called `_parseLoadedSpec`, `validateSpec`,
  and `compileSpec` without trace forwarding; final runtime already accepted the emitter separately.
- [x] **FIX** — Added source-compatible optional loader injection, balanced IO scope/loaded decision, forwarding
  through every compiled phase, and caller-explicit reuse at runtime without retaining mutable emitter state.
- [x] **ADDRESSED (verified)** — Three direct tests prove routed all-phase events and balance, compiled/result/source
  identity, disabled quietness, and exact structured validation failures.
- [x] **NO REGRESSION** — Format, strict analysis, 22 affected tests, complete 175-test Dart suite, exact 61x2 CLI,
  105/105 corpus, and the canonical core gate pass.
- [x] **LOCKSTEP** — Capability manifest, public trace API/book, roadmaps, task/live docs, and Knowledge Map promote
  together to 57/1/2; `.1.6.5` closes and non-codegen closeout `.1.6.6` is active.

- ID: `FUTURE-PARITY-BACKLOG.1.6.6`
  Status: `done`
  Goal: Close the non-codegen capability census and hand generated-source residuals to `.3` without overclaiming.
  Acceptance: The validated matrix contains no unowned gap/partial state; all `.1.6` implementation/proof leaves
    pass recurring checks; task/roadmap/live docs, mdBook, Knowledge Map, public APIs, and exact CLI agree; parent
    `.1.6` closes while complete backend parity remains blocked only by generated-source `.3` and later Lua.
  Verification: A direct manifest projection enumerates exactly three non-pass states: Rust `partial`, Dart `gap`,
    and Julia `gap`, all under `codegen.generated_parser_source` and all owned by `FUTURE-PARITY-BACKLOG.3`. The
    strict checker passes 57/1/2, proving no missing evidence path, invalid state, or unowned residual. Immediately
    prior `.1.6.5.3` passes 175 Dart tests, 61x2 Dart CLI, 105 corpus, canonical 61x2 Perl CLI, and Phase 0 `1..1030`
    in 514 seconds; adjacent Rust/Julia/full-matrix proofs remain the durable other legs. Public/task/live/roadmap/
    Knowledge Map surfaces now state that all non-codegen rows pass and complete parity is blocked only by `.3` plus
    the later Lua implementation. No parser/compiler/runtime behavior or manifest status changed in this closeout.
  Commit: prepared in `FUTURE-PARITY-BACKLOG.1.6.6 - close non-codegen capability parity`

## `FUTURE-PARITY-BACKLOG.1.6.6` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Direct machine-readable enumeration proves the 57/1/2 census contains exactly three
  non-pass states rather than treating a green interpreter/CLI subset as complete backend parity.
- [x] **ROOT CAUSE (WHY + WHERE)** — Every residual is confined to `codegen.generated_parser_source`: Rust proof is
  curated (`partial`), while Dart and Julia emit no parser source (`gap`); top-level `.3` owns all three.
- [x] **FIX** — Closed the non-codegen `.1.6` parent, activated `.3`, and synchronized task/roadmap/live/public/KM
  wording without changing capability data or backend behavior.
- [x] **ADDRESSED (verified)** — `perl tools/check_capability_conformance.pl` passes at 57/1/2; direct projection
  prints only the three generated-source states with the same `.3` owner.
- [x] **NO REGRESSION** — Immediately prior complete Dart and canonical core gates pass, including 175 tests,
  61x2 Dart, 105 corpus, 61x2 Perl, and Phase 0 `1..1030`; docs/KM/governance/whitespace/mdBook pass here.
- [x] **LOCKSTEP** — All codebase/book/continuity status surfaces distinguish closed non-codegen capability parity
  from still-open generated-source parity and later Lua; no complete-parity claim is made early.

- ID: `FUTURE-PARITY-BACKLOG.2`
  Status: `superseded`
  Goal: Generalize staged linked parsing beyond the current function-body prototype.
  Acceptance: Public `parse_job(...)` authoring, import/provider search roots, multiple payload
    parser families, recursive staged queues, cycle diagnostics, docs, and corpus fixtures are
    split before implementation and kept implementation-language neutral.
  Superseded by: `FUTURE-PARITY-BACKLOG.14`, with progressive in-parse composition under `.14.6` and staged AST
    enrichment under `.14.7`.
  Verification: **SUPERSEDED 2026-08-01.** No implementation or activation landed under `.2`. Git history proves
    commits `e96d389e` and `7dd70a2d` misplaced unrelated `.9.1.7.4`/`.9.1.7.6` commit and verification text here;
    `.24.0.1` removes those insertions and records the later `.14`/`.14.6-.7` ownership transfer truthfully.
  Commit: `none — superseded without implementation`

- ID: `FUTURE-PARITY-BACKLOG.3`
  Status: `done`
  Goal: Close generated-source capability parity beyond the current interpreter-first correctness gates.
  Children: `.3.0`, `.3.1`, `.3.2`, `.3.3`, `.3.4`, `.3.5`
  Acceptance: Split Rust full-manifest breadth and separate Dart/Julia source-emitter proofs before code. Each
    non-Rust emitter lane must own a minimal emitter scaffold plus compile/run harness, typed generated-family plan,
    direct structural-family execution, and curated manifest-backed corpus subset. Rust exports source emission as
    a public runtime-crate capability, so ADR `0023` makes equivalent capability mandatory before Dart/Julia/Lua can
    claim complete user-visible parity; interpreter parity remains the primary correctness gate.
  Verification: **PASS 2026-07-11.** Contract-first Perl repair/admission, strict Rust 105/105 breadth, and
    deterministic Dart/Julia scaffold, exact ten-family direct execution, and accepted 8/105 admission all pass.
    Contract/capability census is 60/0/0 and final `.3.5` reverified every focused backend proof plus adjacent
    complete backend gates, governance, public docs, and cleanup. Lua `.1.3` activates only after this closeout.
  Commit: `FUTURE-PARITY-BACKLOG.3.5 - close generated-source parity`

- ID: `FUTURE-PARITY-BACKLOG.3.0`
  Status: `done`
  Goal: Audit and split generated-source parity before implementation.
  Acceptance: Read the canonical Knowledge Map facts first; inspect Perl reference generation, the public Rust
    emitter/export, its isolated compile/run harness and exact manifest subset, and Dart/Julia source trees; record
    the current 105-fixture boundary; create separate neutral-contract, Rust-breadth, Dart-emitter, Julia-emitter,
    and final-admission owners without changing parser/compiler/runtime behavior or capability status.
  Verification: **PASS 2026-07-11.** The then-current census classified Perl pass; Rust publicly emits a standalone module,
    validates a typed family plan, directly runs all current structural families, and compile/runs only eight named
    manifest fixtures; Dart and Julia expose no source emitter. `.3.1.0` later added the missing standalone Perl
    execution probe and corrected that classification. Knowledge Map, task/live/roadmap/book, governance,
    whitespace, and mdBook checks passed; generated artifacts were removed.
  Commit: `FUTURE-PARITY-BACKLOG.3.0 - split generated-source parity`

- ID: `FUTURE-PARITY-BACKLOG.3.1`
  Status: `done`
  Goal: Define the executable backend-neutral generated-source contract and correct the Perl reference boundary.
  Children: `.3.1.0`, `.3.1.1`, `.3.1.2`, `.3.1.3`
  Acceptance: Ratify a versioned contract and neutral fixtures for source emission from a compiled `.spec`,
    host-language compile/load, direct generated execution, exact canonical result and diagnostic/source identity,
    trace entry, structural-family metadata, malformed-plan rejection, and manifest-backed proof. Host APIs and
    emitted bytes may remain idiomatic/backend-native under ADR `0023`; observable capability and behavior may not
    differ. Keep the 105-case interpreter corpus as the primary oracle; correct and repair Perl's independently
    compiled-source boundary before treating the reference as a pass baseline.
  Verification: **PASS 2026-07-11.** Contract v1, corrected independently loadable Perl generation, Rust typed
    identity/metadata/errors, exact neutral plan/rejections/direct result/trace roles, and explicit admission are
    complete. Focused Perl proof passes 69 assertions; focused Rust source-emitter passes 5/5. Complete canonical
    Perl CI passes 61x2 CLI and Phase 0 `1..1030` in 652 seconds; complete Rust passes
    137/105/196/5/5/5/10 plus 61x2 CLI. Census promotes to 57/1/2: Perl pass, Rust partial solely for 8/105 breadth,
    Dart/Julia gap. Docs/KM/governance/mdBook/cleanup pass; `.3.2` is active.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.3.3 - admit Perl Rust generated baseline`

- ID: `FUTURE-PARITY-BACKLOG.3.1.0`
  Status: `done`
  Goal: Root-cause the Perl standalone generated-source failure and split correction before code.
  Acceptance: Use `LinkedSpec::Get` plus `generate_only`/`dump_parser_source`/`parser_source_ref` to compare the
    normal parser with independently compiled captured source; reduce any mismatch to the exact source mechanism;
    correct the capability census and every public/continuity claim; create separate contract, Perl repair, and
    admission leaves before behavior changes.
  Verification: **PASS 2026-07-11.** A minimal action-edge parser returns `"ok"` normally; captured source compiles
    under an isolated package but returns `undef`. Debug trace proves regex match succeeds while the expected action
    index is skipped. The dump stringifies `LinkedRE::oredRE` into `qr/...(?{$pos=N}).../`; recompilation detaches
    that marker from `LinkedRE::or`'s lexical index, yielding wrong/undefined `match_index`. Capability checker,
    docs/KM/governance/whitespace/mdBook/cleanup pass at corrected census 56/2/2; no behavior code changed.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.0 - correct Perl generated-source status`

- ID: `FUTURE-PARITY-BACKLOG.3.1.1`
  Status: `done`
  Goal: Define the versioned executable neutral generated-source contract and fixtures.
  Acceptance: Add a strictly checked schema/fixture set for host-source emission, independent compile/load, direct
    result, trace, diagnostic/source identity, exact family-plan validation/rejection, and the accepted manifest
    subset. Define semantic entrypoint roles rather than identical host-language names or source bytes. Wire the
    checker into canonical local CI before changing Perl generation.
  Verification: **PASS 2026-07-11.** Strict checker validates v1 schema, ownership, semantic/API boundary,
    deterministic markers, pipeline, ten families, plan rejection, errors, direct fixture, exact eight-case subset,
    live 105-case manifest, and current 56/2/2 states. Checker syntax/focused execution, capability, Knowledge Map,
    canonical local CI through Phase 0 `1..1030`, docs/governance/whitespace/mdBook, and cleanup pass.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.1 - define generated-source contract`

- ID: `FUTURE-PARITY-BACKLOG.3.1.2`
  Status: `done`
  Goal: Make Perl's public captured/generated source independently compile and execute equivalently.
  Acceptance: Preserve normal parser behavior while emitting dependency-regex reconstruction that retains exact
    alternative indexes after independent compilation; add direct result/trace/source-identity and malformed-plan
    locks over the neutral fixtures; keep diagnostic capture compatibility explicit and avoid host-package binding.
  Verification: **PASS 2026-07-11.** Public emitter and legacy capture are byte-identical/deterministic; isolated
    arbitrary-package execution returns the exact neutral result; reconstructed `LinkedRE::oredRE` alternatives
    retain indexes zero/one including slash-bearing regex; metadata/identity, ordinary/traced execution, all four
    plan rejections, and structured emission/execution errors pass 69 focused assertions. Existing generated branch
    suites pass. Phase 0 first reached its true stop with exactly two stale direct-Get source locks, then passes
    `1..1030` in 546 seconds after they require validated `Get -> Execute`; canonical CI, docs/KM/governance/mdBook,
    and cleanup pass. Capability remains partial until admission `.3.1.3`.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.2 - repair Perl generated source`

## `FUTURE-PARITY-BACKLOG.3.1.2` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — `LinkedSpec::Get` normal execution returned `"ok"`, while independently evaluated
  `generate_only`/`dump_parser_source` text consumed the regex with the wrong index and returned `undef`.
- [x] **ROOT CAUSE (WHY + WHERE)** — debug `generated_handler_branch` trace and reduced `LinkedRE::oredRE` probes
  located `Compiler.pm` stringification of `qr/...(?{$pos=N}).../`, which detached markers from `LinkedRE::or`'s
  lexical index on recompilation.
- [x] **FIX** — `Compiler.pm` reconstructs dependency alternatives from compiled rule refs, emits v1 metadata/plan/
  wrappers, and `LinkedSpec::GeneratedSource` owns public emission, validation, trace roles, and structured errors.
- [x] **ADDRESSED (verified)** — `t/generated_source_contract.t` passes direct/trace/identity/error/plan/index/slash
  locks; public and legacy source are identical; arbitrary packages return exact results.
- [x] **NO REGRESSION** — four focused generated trace suites pass; full Phase 0 reaches `1..1030` after exactly two
  measured stale wrapper-shape locks are migrated; canonical local CI passes.
- [x] **LOCKSTEP** — API/book/USER_GUIDE/TOOLBOX, task/roadmap/live docs, Knowledge Map, capability note, checks, and
  generated artifact cleanup agree; census remains 56/2/2 pending `.3.1.3` admission.

- ID: `FUTURE-PARITY-BACKLOG.3.1.3`
  Status: `done`
  Goal: Admit the neutral contract baseline and corrected Perl generated-source pass.
  Children: `.3.1.3.0`, `.3.1.3.1`, `.3.1.3.2`, `.3.1.3.3`
  Acceptance: Perl and existing Rust source emission consume the same contract roles; focused and full Perl/Rust
    gates pass; capability checker returns Perl to pass with only Rust breadth partial plus Dart/Julia gaps; docs,
    book, Knowledge Map, roadmap, artifact cleanup, and parent `.3.1` closeout agree before `.3.2` starts.
  Verification: **PASS 2026-07-11.** Rust's audited v1 gaps are closed through typed identity/metadata/errors,
    exact ten-family plan and four rejections, direct result, portable trace roles, and compatibility adapters.
    Focused and full Perl/Rust gates pass under `.3.1.3.3`; capability checker reports 57 pass / one partial / two
    gap states. Perl is admitted pass; Rust's only partial boundary is generated breadth 8/105. `.3.1` closes.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.3.3 - admit Perl Rust generated baseline`

- ID: `FUTURE-PARITY-BACKLOG.3.1.3.0`
  Status: `done`
  Goal: Audit Rust against every generated-source v1 role and split admission before behavior code.
  Acceptance: Inspect the public emitter, emitted markers/entrypoints, plan representation and rejection surface,
    trace events, error types, isolated compile/run harness, and neutral fixture; record every exact v1 mismatch;
    create bounded metadata/error, plan/trace, and final-admission leaves without changing runtime behavior or
    capability status.
  Verification: **PASS 2026-07-11.** Knowledge Map and source audit proves the compatibility emitter accepts only
    `CompiledSpec`, emits only a format marker, returns raw strings, validates a private typed-enum plan without an
    unknown-family value, and exposes rich native `rust_runtime:generated_plan:*` trace topics rather than the
    three neutral roles. Its existing isolated proof remains green: all ten families, legacy repetition, and the
    eight-case subset pass three focused tests in 35.69 seconds. Metadata/error `.1`, plan/trace `.2`, and admission
    `.3` are split before behavior code; census remains 56/2/2. Docs/KM/governance/mdBook/cleanup pass.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.3.0 - split Rust generated-source v1 alignment`

## `FUTURE-PARITY-BACKLOG.3.1.3.0` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — direct source/API scans show no contract-id/source-identity marker, no typed
  `generated_source_error`, no unknown-family rejection code, and no neutral generated trace-role names.
- [x] **ROOT CAUSE (WHY + WHERE)** — `source_emitter.rs` predates contract v1: its compatibility API was designed
  around `CompiledSpec`, a Rust enum family table, native `String` errors, and native generated-plan trace topics.
- [x] **FIX** — no behavior fix belongs in this audit leaf; `.1` owns typed identity/metadata/errors, `.2` owns the
  exact neutral plan/trace roles, and `.3` owns gates/status admission.
- [x] **ADDRESSED (verified)** — the exact gaps and still-green all-family/legacy/eight-case baseline are durable in
  the task tree, capability evidence, public book/status, and Knowledge Map.
- [x] **NO REGRESSION** — existing `source_emitter` integration test passes 3/3, including independently compiled
  temporary crates; no parser/compiler/runtime behavior source changed.
- [x] **LOCKSTEP** — task/roadmap/live/book/capability/KM state remains at 56/2/2 and activates `.3.1.3.1`.

- ID: `FUTURE-PARITY-BACKLOG.3.1.3.1`
  Status: `done`
  Goal: Align Rust emission metadata, source identity, and generated-source errors with contract v1.
  Acceptance: Add an idiomatic typed public request/error surface while preserving the compatibility emitter;
    emit deterministic contract/version/source-identity metadata; map emission, generated load/compile harness,
    plan validation, and execution failures to the stable contract fields/stages/codes with exact focused tests.
  Verification: **PASS 2026-07-11.** Rust now exposes `emit_rust_source_v1(compiled, source_identity)` with
    deterministic contract/version/identity metadata and typed `GeneratedSourceError` stages/codes while the
    original `emit_rust_source(compiled) -> Result<String, String>` and emitted `parse` adapters retain their exact
    compatibility behavior. Focused source-emitter proof passes 4/4, including exact metadata JSON, empty-identity
    emission failure, caller projection of compile/load failure, malformed embedded-spec validation, row-count
    plan validation, attributed execution failure, deterministic identity behavior, and independently compiled
    generated modules. The complete Rust gate passes 137 unit, 105 corpus, 196 integration, 5 diagnostics,
    4 source-emitter, 5 spec-loader, 10 trace tests, doc/build checks, and 61/61 CLI cases in default and POSIX
    environments. Strict Clippy reports only 14 pre-existing findings in untouched owners. Docs/KM/governance/
    mdBook/cleanup pass; census remains 56/2/2 pending exact plan/trace `.2` and admission `.3`.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.3.1 - add Rust generated-source v1 metadata`

## `FUTURE-PARITY-BACKLOG.3.1.3.1` Acceptance Checklist

- [x] **PUBLIC TYPED SURFACE** — callers can supply source identity and receive structured emission errors through
  `emit_rust_source_v1`; `GeneratedSourceError::compile_failed` projects the host compile/load boundary.
- [x] **DETERMINISTIC METADATA** — emitted modules expose exact contract id, format version, source identity, and
  `metadata()`; identical compiled input/identity emits identical source and changing identity changes source.
- [x] **STABLE ERRORS** — emission, compile/load, plan-validation, and execution failure paths carry the contract
  type, stage, code, summary, source identity, and available rule/family/detail attribution.
- [x] **COMPATIBILITY** — the original string-returning emitter delegates with `<inline>` identity, while generated
  `parse` and `parse_with_trace` continue to return the original raw string diagnostics and exact results.
- [x] **NO REGRESSION** — focused 4/4 plus the complete 137/105/196/5/4/5/10 and 61x2 Rust gate pass.
- [x] **LOCKSTEP** — Rust API/docs/book/task/live/capability/KM state records metadata/error completion without
  claiming exact neutral plan/trace roles or capability admission; `.3.1.3.2` becomes active.

- ID: `FUTURE-PARITY-BACKLOG.3.1.3.2`
  Status: `done`
  Goal: Align Rust generated-plan rejection and neutral trace roles with contract v1.
  Acceptance: Validate exact ordered label/family rows using the ten neutral family names; reject row count, label,
    family mismatch, and unknown family before execution with exact codes; expose generated-rule enter, family
    decision, and exit roles while retaining richer native trace; pass the neutral result/trace/identity fixture and
    existing all-family isolated compile/run matrix.
  Verification: **PASS 2026-07-11.** Emitted Rust modules now expose an exact neutral `GeneratedPlanRow` table,
    `plan()`, and `validate_plan(...)`; typed execution rejects row count, label, known-family mismatch, and arbitrary
    unknown-family values before runtime with the four stable codes. The exact neutral fixture initially exposed
    Rust's historical generated accumulator envelope (`["ok"]`) versus v1 direct result (`"ok"`): root cause was
    that generated execution had not mirrored the already-adopted `Engine::execute_value`/legacy `execute` split.
    Typed v1 `execute` now uses a generated-plan-aware direct-value seam; compatibility `parse` keeps the envelope.
    Traced v1 execution emits `generated_rule_enter`, `generated_family_decision`, and `generated_rule_exit` with
    identity/rule/family beside rich native topics. A first full gate correctly caught and repaired accidental
    legacy traced projection drift; focused trace 10/10 and source-emitter 5/5 then pass. The clean rerun passes
    137 unit, 105 corpus, 196 integration, 5 diagnostics, 5 source-emitter, 5 loader, 10 trace, docs/build, and
    61/61 CLI in default and POSIX environments. Strict Clippy retains exactly 14 pre-existing untouched findings.
    Docs/KM/governance/mdBook/cleanup pass; census remains 56/2/2 for explicit admission `.3`.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.3.2 - align Rust generated plans and trace`

## `FUTURE-PARITY-BACKLOG.3.1.3.2` Acceptance Checklist

- [x] **EXACT PLAN** — emitted `GeneratedPlanRow` values use exactly the ten neutral family names in source rule
  order; `Repetition` remains only a legacy enum marker and has no contract name.
- [x] **FOUR REJECTIONS** — count, label, known-family mismatch, and arbitrary unknown-family mutations fail before
  execution with exact v1 stages/codes/source identity and available label/family attribution.
- [x] **DIRECT RESULT** — typed v1 generated `execute` returns the portable top-rule value while legacy `parse`
  retains its historical accumulator envelope; interpreter-first direct and compatibility projections are proven.
- [x] **PORTABLE TRACE** — traced v1 execution carries the three neutral role names plus identity/rule/family while
  retaining all richer `rust_runtime:generated_plan:*` events and exact legacy traced results.
- [x] **NO REGRESSION** — focused 5/5 source-emitter and 10/10 trace-control proof plus the complete
  137/105/196/5/5/5/10 and 61x2 Rust gate pass after the compatibility correction.
- [x] **LOCKSTEP** — API/book/task/live/capability/KM state records a green Perl/Rust v1 baseline without promotion;
  explicit admission `.3.1.3.3` becomes active.

- ID: `FUTURE-PARITY-BACKLOG.3.1.3.3`
  Status: `done`
  Goal: Admit the corrected Perl/Rust generated-source v1 baseline.
  Acceptance: Run focused and complete Perl/Rust gates, promote Perl generated source to pass while Rust remains
    partial only for 8/105 breadth, close `.3.1`, synchronize all public/continuity/capability records, clean safe
    generated artifacts, and activate `.3.2`.
  Verification: **PASS 2026-07-11.** Contract checker and focused Perl generated-source proof pass 69 assertions;
    focused Rust passes 5/5. `PERL5LIB= bash tools/run_ci_local.sh` passes contract/native/239-name/AST/trace gates,
    61/61 CLI in default and POSIX environments, and Phase 0 `1..1030` in 652 seconds. A fresh
    `bash tools/run_rust_local.sh` passes formatting, 137 unit, 105 corpus, 196 integration, 5 diagnostics,
    5 source-emitter, 5 loader, 10 trace, docs/build, and 61/61 CLI default/POSIX. Capability and contract state
    advance from 56/2/2 to 57/1/2: Perl pass, Rust partial only for 8/105 breadth, Dart/Julia gap. Docs/KM/
    governance/mdBook/cleanup pass; `.3.1` closes and `.3.2.0` becomes active.
  Commit: `FUTURE-PARITY-BACKLOG.3.1.3.3 - admit Perl Rust generated baseline`

## `FUTURE-PARITY-BACKLOG.3.1.3.3` Acceptance Checklist

- [x] **FOCUSED PROOF** — Perl contract checker + 69 assertions and Rust source-emitter 5/5 pass independently.
- [x] **COMPLETE PERL** — canonical CI passes 61x2 CLI and Phase 0 `1..1030` in 652 seconds.
- [x] **COMPLETE RUST** — fresh 137/105/196/5/5/5/10, docs/build, and 61x2 CLI gate passes.
- [x] **EXACT ADMISSION** — Perl promotes partial→pass; Rust stays partial only for named 8/105 breadth; Dart and
  Julia remain gap, yielding exactly 57 pass / one partial / two gap states.
- [x] **CLOSEOUT** — `.3.1.3` and `.3.1` close; task/roadmap/live/book/capability/KM/checkers agree; `.3.2.0` active.

- ID: `FUTURE-PARITY-BACKLOG.3.2`
  Status: `done`
  Goal: Expand Rust generated-source proof from eight curated fixtures to the complete 105-case manifest.
  Children: `.3.2.0`, `.3.2.1`, `.3.2.2`
  Acceptance: Reuse the neutral contract and existing public emitter/family-plan path; do not weaken or replace the
    interpreter oracle. Classify the full manifest first, recursively split every discovered failure by mechanism
    before repair code, then compile/run generated Rust source for all 105 fixtures with exact expected values.
  Verification: **PASS 2026-07-11.** `.3.2.0` adds exact staged all-105 classification, `.3.2.1` proves all
    requested repair inventories empty, and `.3.2.2` makes the classifier unconditional/recurring and admits it.
    Independent strict classification passes 105/105 in 186.42 seconds. The canonical complete Rust gate runs the
    same test automatically and passes 137 unit, 105 interpreter corpus, 105 generated-source breadth in 189.42s,
    196 integration, 5 diagnostics, 5 source-emitter, 5 loader, 10 trace, docs/build, and 61x2 CLI. Strict Clippy
    still names the 14 pre-existing runtime findings; exempting only their six classes passes the changed test.
    Contract and
    capability checkers report 58 pass / zero partial / two gaps. Rust promotes to pass; `.3.3.1` is active for Dart.
  Commit: `FUTURE-PARITY-BACKLOG.3.2.2 - admit Rust generated-source breadth`

- ID: `FUTURE-PARITY-BACKLOG.3.2.0`
  Status: `done`
  Goal: Add a scalable full-manifest Rust generated-source classifier.
  Acceptance: Drive all 105 checked-in fixtures through parse/validate/compile/interpreter-oracle/emit/isolated
    compile/run; report deterministic per-case stages without silently skipping failures; retain the existing
    synthetic all-family matrix and eight-case proof while classification is active.
  Verification: **PASS 2026-07-11.** Added an explicitly invoked full-manifest classifier that validates exact
    105-case manifest accounting, prepares every fixture through strict-UTF-8 read, parse, validate, compile,
    legacy/direct interpreter oracle, and v1 emission, then writes separate generated modules into one isolated
    temporary Cargo crate for one host compile and 105 named host tests. The first per-case prototype proved exact
    staging but measured roughly ten seconds per fixture; it was stopped after eight green cases and replaced by
    the shared-crate design. The scalable run classifies all 105 fixtures PASS across all eight stages in 184.46
    seconds with zero skips/failures and removes its temporary crate on drop. Existing all-family and eight-case
    tests pass 5/5 in 36.66 seconds. Strict Clippy reports the same 14 pre-existing runtime findings; rerunning with
    only their six known lint classes exempted passes the new test cleanly under `-D warnings`. No emitter/runtime
    behavior changed. `.3.2.1` is active to close the zero-failure classification before strict recurring admission.
  Commit: `FUTURE-PARITY-BACKLOG.3.2.0 - classify all Rust generated fixtures`

## `FUTURE-PARITY-BACKLOG.3.2.0` Acceptance Checklist

- [x] **COMPLETE INPUT** — manifest format/count/uniqueness are checked and exactly 105 ordered fixture names are
  processed; terminal pass/failure accounting must total 105.
- [x] **EXACT STAGES** — every case reaches or is attributed to read, parse, validate, compile, interpreter oracle,
  emit source, isolated host compile, or host run; failures do not silently disappear.
- [x] **SCALABLE HOST** — one temporary crate contains separate per-case modules/tests, one host compile, and one
  serial host run; all dependency/build output is caller-owned and removed on drop.
- [x] **CLASSIFICATION** — explicit run passes 105/105 in 184.46 seconds with zero failure mechanisms to split.
- [x] **NO REGRESSION** — the existing synthetic ten-family matrix and admitted eight-case test remain untouched;
  the classifier is explicit/ignored until `.3.2.2` recurring-gate admission.
- [x] **LOCKSTEP** — task/public/live/KM state records green classification without prematurely promoting Rust;
  zero-failure closeout `.3.2.1` becomes active.

- ID: `FUTURE-PARITY-BACKLOG.3.2.1`
  Status: `done`
  Goal: Own classification and recursive repair splitting, not unsplit fixes.
  Acceptance: Classify every `.3.2.0` failure by exact source-emitter, generated-plan, generated-executor,
    dependency/build, or fixture-contract mechanism. Add bounded child leaves before changing behavior; if no
    failures exist, record that result and close without behavior code.
  Verification: **PASS 2026-07-11.** Reviewed the complete `.3.2.0` terminal report: all 105 fixtures pass all
    eight stages, so the source-emitter, generated-plan, generated-executor, dependency/build, and fixture-contract
    failure inventories are each empty. No recursive repair child and no behavior change are justified. The exact
    zero-failure result is durable in the classifier test, `.3.2.0` verification, capability note, public book, and
    Knowledge Map fact. `.3.2.1` closes as required and activates only strict recurring admission `.3.2.2`.
  Commit: `FUTURE-PARITY-BACKLOG.3.2.1 - close zero-failure Rust classification`

## `FUTURE-PARITY-BACKLOG.3.2.1` Acceptance Checklist

- [x] **COMPLETE REPORT** — the classifier accounts for exactly 105 pass + failure terminal records.
- [x] **MECHANISM INVENTORY** — emitter, plan, executor, dependency/build, and fixture-contract failure sets are
  all empty; no failure is left unsplit.
- [x] **NO INVENTED REPAIR** — no child leaf or behavior change is created for a mechanism the evidence did not
  find.
- [x] **DURABLE RESULT** — source test, task verification, capability note, mdBook, and Knowledge Map all preserve
  the 105/105 zero-failure conclusion.
- [x] **NEXT BOUNDARY** — Rust remains partial; strict recurring admission `.3.2.2` alone becomes active.

- ID: `FUTURE-PARITY-BACKLOG.3.2.2`
  Status: `done`
  Goal: Admit complete Rust generated-source manifest breadth.
  Acceptance: Every recursively split repair is closed; all 105 fixtures compile and run generated Rust source with
    exact oracle values; the synthetic family matrix, full interpreter gate, trace/source identity, complete Rust
    local gate, docs, Knowledge Map, and artifact cleanup pass before Rust promotes from partial to pass.
  Verification: **PASS 2026-07-11.** Removed the classifier ignore marker and conditional strictness escape hatch;
    any classified failure now fails ordinary `cargo test -p linkedspec-runtime`. Contract v1 names the exact test
    and its checker rejects a missing/non-file path, case count other than 105, any ignore attribute, or absence of
    unconditional `failures.is_empty()` enforcement. Independent strict 105/105 passes in 186.42 seconds. The full
    Rust gate repeats it in 189.42 seconds and passes all adjacent counts: 137/105/105-generated/196/5/5/5/10 plus
    61x2 CLI. Strict Clippy retains only 14 pre-existing runtime findings and the changed test passes when their six
    known classes are exempted. Rust generated source promotes partial→pass; census is 58/0/2; parent `.3.2` closes and Dart `.3.3.1`
    becomes active after docs/KM/governance/mdBook/cleanup agree.
  Commit: `FUTURE-PARITY-BACKLOG.3.2.2 - admit Rust generated-source breadth`

## `FUTURE-PARITY-BACKLOG.3.2.2` Acceptance Checklist

- [x] **STRICT RECURRING TEST** — no ignore/conditional bypass remains; ordinary runtime-package tests execute the
  all-105 classifier and any failure fails the test.
- [x] **CONTRACT ENFORCEMENT** — generated-source contract/checker locks the exact test path, 105 count, no ignore,
  unconditional failure rejection, and Rust pass state.
- [x] **INDEPENDENT PROOF** — strict classifier passes 105/105 in 186.42 seconds with exact staged accounting.
- [x] **COMPLETE RUST** — canonical gate passes 137 unit, 105 interpreter, 105 generated, 196 integration,
  5 diagnostics, 5 emitter, 5 loader, 10 trace, docs/build, and 61x2 CLI.
- [x] **EXACT PROMOTION** — Rust promotes partial→pass; census becomes exactly 58 pass / zero partial / two gaps.
- [x] **CLOSEOUT** — `.3.2` closes; task/roadmap/live/book/capability/KM/cleanup agree; Dart `.3.3.1` becomes active.

- ID: `FUTURE-PARITY-BACKLOG.3.3`
  Status: `done`
  Goal: Add public generated Dart source with direct structural execution and proof.
  Children: `.3.3.1`, `.3.3.2`, `.3.3.3`
  Acceptance: Implement only after `.3.1`; preserve native interpreter behavior and exact CLI parity while exposing
    an idiomatic Dart API equivalent to the neutral generated-source contract.
  Verification: `.3.3.1-.3` complete; deterministic emitter, ten-family direct matrix, exact accepted subset,
    complete 181-test/61x2/105 Dart gate, contract/capability 59/0/1, docs/KM/no-drift/cleanup.
  Commit: closed by `FUTURE-PARITY-BACKLOG.3.3.3 - admit generated Dart source`

- ID: `FUTURE-PARITY-BACKLOG.3.3.1`
  Status: `done`
  Goal: Add the public Dart emitter scaffold and isolated compile/run harness.
  Acceptance: Emit deterministic Dart source from compiled state, load/compile it in a caller-owned temporary
    package without repository build leakage, execute a minimal parser entrypoint, prove stable format/version and
    failures, and clean generated packages/caches.
  Verification: focused format/analyze/source-emitter 3/3; isolated offline pub/analyze/run; complete Dart gate
    178 tests, 61/61 default, 61/61 POSIX, and 105/105 corpus.
  Commit: `FUTURE-PARITY-BACKLOG.3.3.1 - add Dart generated-source scaffold`

### `FUTURE-PARITY-BACKLOG.3.3.1` outcome

- [x] **PUBLIC SCAFFOLD** — Dart exports deterministic compatibility and contract-v1 emitters plus typed metadata
  and portable stage/code/source-attribution failures.
- [x] **COMPILED INPUT** — emission consumes effective ordered `CompiledSpec` functions/rules and reconstructs a
  normalized specification inside the generated library without retaining repository build state.
- [x] **TEXT BOUNDARY** — generated Dart is Unicode source; its embedded normalized payload is strict UTF-8 encoded
  as deterministic Base64, keeping Unicode distinct from the selected persisted encoding and avoiding interpolation.
- [x] **ISOLATED HOST PROOF** — a caller-owned temporary package and private `PUB_CACHE` resolve offline, analyze,
  execute the direct value, project attributed runtime failure, and are deleted recursively in `finally`.
- [x] **EXACT SCAFFOLD CONTRACT** — contract id, format 1, source identity, deterministic bytes, emit/compile-load/
  execution failures, and ordinary/traced entrypoint roles are locked; family-plan semantics remain `.3.3.2`.
- [x] **COMPLETE DART** — canonical gate passes 178 package tests, 61x2 CLI, and 105/105 interpreter corpus.
- [x] **HONEST STATUS** — capability census stays 58/0/2; Dart remains gap until `.3.3.2` and `.3.3.3` admission.

- ID: `FUTURE-PARITY-BACKLOG.3.3.2`
  Status: `done`
  Goal: Add Dart typed family-plan metadata and direct generated structural execution.
  Acceptance: Cover every current default/OR/AND/repetition acode/bcode family, validate label/family plans before
    execution, retain trace and diagnostic/source identity, and compile/run a synthetic all-family matrix.
  Verification: focused format/analyze/source-emitter 5/5; isolated ten-family package analyze/run; four exact
    rejections; portable trace roles; complete Dart gate 180 tests, 61x2 CLI, and 105/105 corpus.
  Commit: `FUTURE-PARITY-BACKLOG.3.3.2 - add Dart generated family execution`

### `FUTURE-PARITY-BACKLOG.3.3.2` outcome

- [x] **EXACT PLAN** — emitted libraries expose ordered `GeneratedPlanRow { label, family }` rows using all ten
  neutral default/OR/AND/repetition acode/bcode family strings.
- [x] **FOUR REJECTIONS** — count, label, known-family mismatch, and arbitrary unknown-family inputs fail before
  execution with distinct contract-v1 stage/code/source/rule/family/detail records.
- [x] **DIRECT STRUCTURAL ROUTING** — validated typed families are passed into the native engine and select regex/
  acode versus blind/bcode dispatch on every generated rule entry instead of serving as decorative metadata.
- [x] **TRACE/DIAGNOSTIC IDENTITY** — traced generated execution emits `generated_rule_enter`,
  `generated_family_decision`, and `generated_rule_exit`; failures preserve source and available rule/family.
- [x] **ALL-FAMILY HOST PROOF** — one caller-owned offline temporary Dart package analyzes and runs generated
  libraries for every ten-family case against direct interpreter values, then recursively deletes package/cache.
- [x] **COMPLETE DART** — canonical gate passes 180 package tests, 61x2 CLI, and 105/105 interpreter corpus.
- [x] **HONEST STATUS** — census stays 58/0/2; curated interpreter-first generated admission remains `.3.3.3`.

- ID: `FUTURE-PARITY-BACKLOG.3.3.3`
  Status: `done`
  Goal: Admit generated Dart source against manifest-backed oracle fixtures.
  Acceptance: Run the neutral curated subset through interpreter-first exact comparison, emitted-source
    compile/run, complete Dart gates, docs/KM/no-drift, and cleanup; promote Dart's generated-source gap only after
    all contract families pass.
  Verification: exact contract-sourced 8/105 interpreter-first subset; one isolated offline host analyze/run;
    direct result/metadata/plan/trace identity; complete Dart 181 tests, 61x2 CLI, 105 corpus; checkers 59/0/1.
  Commit: `FUTURE-PARITY-BACKLOG.3.3.3 - admit generated Dart source`

### `FUTURE-PARITY-BACKLOG.3.3.3` outcome

- [x] **EXECUTABLE SOURCE LIST** — the test reads `corpus_proof.accepted_subset` directly from contract v1 and
  locks its exact eight-case count and membership in the 105-case interpreter manifest.
- [x] **INTERPRETER FIRST** — every fixture parses through ordinary or staged-function frontend, compiles, and
  equals checked-in `expected.json` through native direct execution before source emission.
- [x] **INDEPENDENT GENERATED PROOF** — eight emitted libraries analyze and run in one caller-owned offline package;
  values, contract/version/identity metadata, ordered plans, and portable trace identity are exact.
- [x] **RECURRING ENFORCEMENT** — contract names the Dart test path; checker locks count, contract consumption,
  interpreter-first order, v1 emission, host analyze/run, trace roles/identity, cleanup, and no skip.
- [x] **COMPLETE DART** — canonical gate passes 181 tests, 61x2 CLI, and 105/105 interpreter corpus.
- [x] **PROMOTION** — Dart generated source moves gap→pass; census is exactly 59/0/1 with Julia the sole gap.
- [x] **CLOSEOUT** — `.3.3` closes; Julia scaffold `.3.4.1` becomes active after clean commit.

- ID: `FUTURE-PARITY-BACKLOG.3.4`
  Status: `done`
  Goal: Add public generated Julia source with direct structural execution and proof.
  Children: `.3.4.1`, `.3.4.2`, `.3.4.3`
  Acceptance: Implement only after `.3.1`; preserve native interpreter behavior and exact CLI parity while exposing
    an idiomatic Julia API equivalent to the neutral generated-source contract.
  Verification: **PASS 2026-07-11.** Deterministic scaffold, exact family/direct execution, and contract-sourced
    interpreter-first manifest admission are all complete through `.3.4.1`-`.3.4.3`. Julia generated source passes.
  Commit: `FUTURE-PARITY-BACKLOG.3.4.3 - admit generated Julia source`

- ID: `FUTURE-PARITY-BACKLOG.3.4.1`
  Status: `done`
  Goal: Add the public Julia emitter scaffold and isolated include/compile-run harness.
  Acceptance: Emit deterministic Julia source from compiled state, include/load it in caller-owned isolation,
    execute a minimal parser entrypoint, prove stable format/version and failures, respect depot/artifact boundaries,
    and clean only generated task-owned files.
  Verification: **PASS 2026-07-11.** Public compatibility/v1 Julia emitters reconstruct deterministic effective
    AST state, serialize canonical JSON, and embed strict-UTF-8 payload/identity bytes as ASCII hex. Generated
    modules expose exact contract/version/identity metadata plus direct/traced execution and typed emission,
    compile/load, and execution failures. An 18-assertion proof runs valid and corrupt modules in fresh offline
    Julia processes from a caller-owned temporary project with compiled modules disabled and a private writable
    depot layer; Unicode/`$` result and cleanup are exact. Focused 18/18 and package 1,128 assertions pass without
    native interpreter or CLI changes. Complete Julia gate result is recorded in the verification log below.
  Commit: `FUTURE-PARITY-BACKLOG.3.4.1 - add Julia generated-source scaffold`

- ID: `FUTURE-PARITY-BACKLOG.3.4.2`
  Status: `done`
  Goal: Add Julia typed family-plan metadata and direct generated structural execution.
  Acceptance: Cover every current default/OR/AND/repetition acode/bcode family, validate label/family plans before
    execution, retain trace and diagnostic/source identity, and run a synthetic all-family matrix directly.
  Verification: **PASS 2026-07-11.** Julia exposes the exact ten typed contract families, ordered plan rows,
    compiled-state classification, and four distinct pre-execution rejection codes. A validated family map is
    authoritative on every generated root/nested rule entry and selects regex/acode versus blind/bcode dispatch;
    native calls retain structure-derived behavior. Generated trace adds portable enter/decision/exit roles with
    source/rule/family identity beside native trace. One emitted all-family module runs in a fresh caller-owned
    offline project and equals ten native interpreter values. Focused family 27/27 plus scaffold 18/18 and package
    1,155 assertions pass; complete Julia gate result is recorded below. Census remains 59/0/1 until `.3.4.3`.
  Commit: `FUTURE-PARITY-BACKLOG.3.4.2 - add Julia generated family execution`

- ID: `FUTURE-PARITY-BACKLOG.3.4.3`
  Status: `done`
  Goal: Admit generated Julia source against manifest-backed oracle fixtures.
  Acceptance: Run the neutral curated subset through interpreter-first exact comparison, emitted-source
    include/compile-run, complete Julia gates, docs/KM/no-drift, and cleanup; promote Julia's generated-source gap
    only after all contract families pass.
  Verification: **PASS 2026-07-11.** The test reads the exact eight names from contract v1 and verifies membership
    in the 105-case manifest. Each ordinary/staged spec compiles and equals checked-in expected JSON through the
    native interpreter before emission. One fresh caller-owned offline host loads eight emitted modules in separate
    namespaces and verifies exact values, metadata, ordered plans, portable trace roles, and source identity, then
    recursively deletes project/depot state. The checker locks count, contract consumption, interpreter-first
    ordering, v1 emission, independent include, trace/identity, cleanup, and no skip. Focused 13+27+18 and package
    1,168 assertions pass; complete Julia gate is 61x2 CLI and 105/105 corpus. Julia promotes gap to pass; capability
    and generated-source census is 60/0/0, `.3.4` closes, and exact final admission `.3.5` activates.
  Commit: `FUTURE-PARITY-BACKLOG.3.4.3 - admit generated Julia source`

- ID: `FUTURE-PARITY-BACKLOG.3.5`
  Status: `done`
  Goal: Admit exact generated-source parity across all four implemented backends.
  Acceptance: Perl, Rust, Dart, and Julia satisfy the same versioned neutral contract; Rust proves all 105 manifest
    fixtures and Dart/Julia prove the accepted manifest subset plus all structural families; full backend gates,
    capability checker, docs/book/KM/roadmap, and artifact cleanup pass; promote the census to 60/0/0, close `.3`,
    and only then activate Lua `.1.3`.
  Verification: **PASS 2026-07-11.** Executable contract/capability checkers report 60/0/0. Focused generated-
    source proof passes Perl 69 assertions, Rust 5/5, Dart 6/6, and Julia 58/58. The immediately adjacent complete
    gates pass Perl Phase 0 `1..1030` plus 61x2 CLI, strict recurring Rust 105/105 generated breadth plus complete
    runtime/CLI suites, Dart 181/61x2/105, and Julia 1,168/61x2/105. Roadmaps, mdBook, KM, task/live docs, memory,
    doctrines, whitespace, and artifact cleanup pass. Removed 1.17 GB Rust debug deps/incremental plus Dart/Julia
    caches. No behavior code changed. `.3` closes and Lua parity plan `.1.3` becomes active after this commit.
  Commit: `FUTURE-PARITY-BACKLOG.3.5 - close generated-source parity`

- ID: `FUTURE-PARITY-BACKLOG.4`
  Status: `done`
  Goal: Decide and implement user-function and callable-signature extension topics beyond the MVP.
  Children: `.4.0`, `.4.1`, `.4.2`, `.4.3`, `.4.4`
  Acceptance: Fixed versus semantically variadic helper/method/function signatures are explicit; user-defined
    functions have one unambiguous definition-time variadic parameter form and deterministic runtime binding.
    Recursive functions, closures/lambdas/currying, namespaces, alternate spellings, optional zero-arg parens,
    brace-less bodies, and caller-mutating forms are each accepted, rejected, or split with explicit `.spec`
    contract and parity obligations before code.
  Verification: **PASS 2026-07-12.** ADR 0030 and one recurring neutral contract define the final `...rest`
    syntax, exact-v1/variadic-v2 records, positional eager evaluation, fresh typed rest arrays, and purpose-specific
    callable bounds. Perl, Rust, Dart, and Julia pass the unchanged native/generated fixture. `.4.4` reconciles
    capability/roadmap/book/KM/live state and routes Lua native execution to `.5.1`, descriptor admission to `.5.3`,
    and generated preservation/execution/admission to `.8` without claiming Lua behavior early.
  Commit: closed by `.4.1`, backend child commits, and `.4.4`

- ID: `FUTURE-PARITY-BACKLOG.4.0`
  Status: `done`
  Goal: Audit callable arity ownership and split variadic user-function design before behavior code.
  Acceptance: Inspect the `.spec` function-definition grammar, neutral descriptor/body-job shape, callable
    contract registries, call validation, and runtime binding in Perl/Rust/Dart/Julia plus the Lua parity plan;
    distinguish purposefully unbounded helpers/methods from exact-arity operations; record the director's
    2026-07-12 directive durably; split neutral syntax/semantics, admitted-backend rollout, and Lua parity without
    choosing syntax from one host language by accident.
  Verification: **PASS 2026-07-12.** Knowledge Map retrieval, ADRs `0017`/`0023`, direct
    `LinkedSpec::Get(..., return_descriptor => 1)` plus `runtime_ctx_ref` probes, and source inspection across the
    grammar, staged shell/payload/job, exact outward descriptor contract, registries, validators, compiled records,
    native/generated runtimes, and Lua invocation-frame seam located every arity owner. Purposefully unbounded
    built-ins already use minimum/open-maximum contracts; receiver methods inject the receiver into the same
    helper contract. User functions alone hard-code exact `arity` at every layer and reject duplicate names, so
    this is one signature evolution rather than overload resolution. Unrecognized rest syntax returns `undef` with
    structured `compiler_pipeline:function_registry` detail, not a swallowed error. Neutral contract `.4.1`,
    Perl/Rust `.4.2.1-.2`, Dart/Julia `.4.3.1-.2`, and final Lua/no-drift routing `.4.4` are mechanism-sized.
  Commit: `FUTURE-PARITY-BACKLOG.4.0 - split variadic callable signatures`

- ID: `FUTURE-PARITY-BACKLOG.4.1`
  Status: `done`
  Goal: Adopt a backend-neutral variadic callable and user-function definition contract.
  Dependencies: `.4.0`
  Acceptance: One grammar-owned definition syntax marks at most one final variadic parameter; descriptors preserve
    fixed parameters plus the rest binding; call validation defines minimum arity, eager ordered evaluation, empty
    rest values, recursion/diagnostics, method receiver interaction, and collision behavior through executable
    neutral fixtures before runtime changes.
  Verification: **PASS 2026-07-12.** ADR `0030` adopts `fn name(fixed, ...rest) { ... }` with one final marker/name
    token, positional eager calls, a fresh typed rest array, exact version-1 fixed functions, and version-2
    variadic `callable_signature` records. The neutral JSON contract covers three definitions, nine valid/invalid
    calls, seven malformed signatures, purpose-specific helper/method bounds, descriptor/staged evolution, mixed
    value preservation, empty rest, and result receiver chaining. Its independent Python checker validates and
    deterministically renders the future `.spec` fixture and is required by canonical local CI. Capability census
    keeps current exact functions at pass and owns variadic behavior as future until backend rollout.
    Canonical local CI passes the new recurring checker, both Perl CLI environments at 61/61, and Phase 0
    `1..1030` in 668 wallclock seconds.
  Commit: `FUTURE-PARITY-BACKLOG.4.1 - adopt variadic callable contract`

- ID: `FUTURE-PARITY-BACKLOG.4.2`
  Status: `done`
  Goal: Implement variadic user-function signatures on Perl and Rust.
  Children: `.4.2.1`, `.4.2.2`
  Dependencies: `.4.1`
  Acceptance: Both frontends, registries, staged descriptors, runtimes, generated-source paths, and diagnostics
    consume the unchanged neutral contract while preserving exact-arity fixed functions and purpose-specific
    helper/method arities; focused and complete gates pass.
  Verification: **PASS 2026-07-12.** Perl `.4.2.1` and Rust `.4.2.2` consume the unchanged neutral contract from
    their spec-owned frontend through staged/public descriptors and native/generated execution. Fixed v1 exact
    arity and v2 fixed-prefix/rest semantics, fresh arrays, ordered evaluation, mixed values, receiver chaining,
    invalid definitions, and diagnostics are recurring-gate covered on both reference variants.
  Commit: closed by child commits `.4.2.1` and `.4.2.2`

- ID: `FUTURE-PARITY-BACKLOG.4.2.1`
  Status: `done`
  Goal: Implement the neutral variadic signature in the Perl reference frontend, descriptor, and generated calls.
  Dependencies: `.4.1`
  Acceptance: The spec-owned shell, registry normalization, staged records, ActionIR resolution, eager call
    lowering, fresh local binding, exact fixed-function diagnostics, public descriptor, and generated source pass
    every neutral case without broad host-Perl fallback or caller capture.
  Verification: **PASS 2026-07-12.** The spec-owned shell emits version-2 function/signature records while fixed
    version-1 records remain exact. Registry validation preserves the same signature through staged payload/job
    and outward descriptor fields. Generated Perl evaluates every argument once left-to-right, binds fixed values,
    and allocates one fresh rest array per invocation. The 66-assertion contract-consuming test passes both grammar
    owners and all valid
    neutral results, descriptor/source roles, seven malformed definitions, fixed-extra/variadic-minimum diagnostics,
    empty/mixed rest values, fresh identity, and receiver chaining. The fixture exposed and this leaf corrected a
    pre-existing Perl drift: documented array `.length()` used scalar address-string length; the shared lowerer now
    returns array cardinality while preserving scalar length. The first complete Phase 0 run measured only 13
    stale exact-source assertions in one outer subtest; after migrating those locks, canonical local CI passes the
    recurring 66 assertions, both 61-case CLI environments, and Phase 0 `1..1030` in 710 seconds.
  Commit: `FUTURE-PARITY-BACKLOG.4.2.1 - implement Perl variadic functions`

- ID: `FUTURE-PARITY-BACKLOG.4.2.2`
  Status: `done`
  Goal: Implement the unchanged neutral variadic signature in Rust native and generated execution.
  Dependencies: `.4.2.1`
  Acceptance: Parsed/compiled/described signature fields, registry-first call resolution, eager evaluation, typed
    rest-array binding, exact fixed-function diagnostics, recursion fences, receiver continuation, source emission,
    and oracle/full gates match the Perl reference and neutral fixture.
  Verification: **PASS 2026-07-12.** Rust carries one typed `CallableSignature` through parsed and compiled
    function records, exact v2 staged sidecars, public descriptor projection, serialized compiled state, emitted
    source, and generated-plan execution. Registered variadic calls enforce the fixed-prefix minimum, eagerly
    evaluate authored arguments once left-to-right, bind fixed values in fresh local stores, and bind every extra
    value into a new typed rest array. The contract-consuming seven-test suite passes exact v1/v2 shapes, all
    neutral results, mixed/empty/fresh rest values, receiver continuation, seven invalid definitions, fixed/minimum
    arity diagnostics, compiled round-trip, emitted signature text, and generated execution. The fixture exposed a
    pre-existing Rust drift: generic `length` stringified array values to empty text and returned zero; the shared
    helper now returns array cardinality while retaining Unicode character count for scalar text. Core tests pass
    185 + 3 descriptor + 8 type assertions. The authoritative Rust gate passes 137 runtime units, the 105-fixture
    interpreter oracle, the isolated all-105 generated-source proof, 197 integration tests, all focused runtime
    suites including 7/7 variadic cases, a fresh primary build, and both CLI environments at 61/61.
  Commit: `FUTURE-PARITY-BACKLOG.4.2.2 - implement Rust variadic functions`

- ID: `FUTURE-PARITY-BACKLOG.4.3`
  Status: `done`
  Goal: Implement variadic user-function signatures on Dart and Julia.
  Children: `.4.3.1`, `.4.3.2`
  Dependencies: `.4.1`, `.4.2`
  Acceptance: Both native and generated paths consume the unchanged neutral contract, preserve fixed-function
    diagnostics, and pass package/CLI/corpus/source-emitter gates without host-language rest-argument drift.
  Verification: **PASS 2026-07-12.** Dart `.4.3.1` and Julia `.4.3.2` preserve the unchanged exact-v1/variadic-v2
    union through typed spec/staged records, registry/action resolution, public descriptors, native runtimes,
    normalized generated state, and generated-plan execution. Both reject keyword arguments for registered
    functions, bind fresh rest arrays after ordered evaluation, and pass complete package/CLI/corpus gates.
  Commit: closed by child commits `.4.3.1` and `.4.3.2`

- ID: `FUTURE-PARITY-BACKLOG.4.3.1`
  Status: `done`
  Goal: Implement the unchanged neutral variadic signature in Dart native and generated execution.
  Dependencies: `.4.2`
  Acceptance: Spec projection, registry/action contracts, runtime rest binding, descriptors, generated source,
    exact fixed-function diagnostics, and complete Dart gates consume the shared contract without Dart-specific
    optional/named/rest behavior.
  Verification: **PASS 2026-07-12.** Dart carries a typed `CallableSignature` through spec-owned shell projection,
    `FunctionDefinition`, `StagedParseJob`, registry/action resolution, public descriptor projection, normalized
    emitted state, generated-plan execution, and generated JSON reconstruction. Registered calls reject keyword
    arguments, preserve exact v1 diagnostics, enforce v2 minimum arity, eagerly evaluate values once left-to-right,
    and bind a fresh copied list of extras in the existing function-local store swap. Six contract tests cover
    exact v1/v2 records and staged copies, every neutral result, receiver continuation, mixed/empty/fresh arrays,
    seven invalid definitions, keyword rejection, fixed/minimum arity diagnostics, emitted Base64 state, direct
    generated execution, and round-trip reconstruction. The authoritative Dart gate passes strict format/analyze,
    190 package tests, both CLI environments at 61/61, and all 105 corpus fixtures.
  Commit: `FUTURE-PARITY-BACKLOG.4.3.1 - implement Dart variadic functions`

- ID: `FUTURE-PARITY-BACKLOG.4.3.2`
  Status: `done`
  Goal: Implement the unchanged neutral variadic signature in Julia native and generated execution.
  Dependencies: `.4.3.1`
  Acceptance: Spec projection, registry/action contracts, runtime rest binding, descriptors, generated source,
    exact fixed-function diagnostics, and complete Julia gates consume the shared contract without Julia splat or
    dispatch behavior leaking into `.spec` semantics.
  Verification: **PASS 2026-07-12.** Julia carries a typed `CallableSignature` through `FunctionDefinition`,
    `StagedParseJob`, exact shell and staged validation, registry/action resolution, public descriptor projection,
    normalized emitted JSON, generated-plan execution, and generated-state reconstruction. Registered calls reject
    keyword arguments, retain exact v1 arity, enforce the v2 fixed-prefix minimum, evaluate positional arguments
    once left-to-right, and bind a fresh typed vector of extras into fresh function-local scalar/array stores.
    The 55-assertion neutral suite covers exact v1/v2 records, every result, mixed/empty/fresh rest arrays, receiver
    continuation, seven invalid definitions, keyword rejection, fixed/minimum diagnostics, emitted hex state,
    direct generated execution, and round-trip reconstruction. The authoritative Julia gate passes all package
    tests, the exact 61x2 primary CLI matrix, and all 105 corpus fixtures.
  Commit: `FUTURE-PARITY-BACKLOG.4.3.2 - implement Julia variadic functions`

- ID: `FUTURE-PARITY-BACKLOG.4.4`
  Status: `done`
  Goal: Close callable-arity no-drift and route Lua variadic parity to its dependency-complete owner.
  Dependencies: `.4.2`, `.4.3`
  Acceptance: Public docs, mdBook, Knowledge Map, neutral capability data, and four admitted backends agree on
    exact versus unbounded signatures; Lua's frontend/runtime/generated-source obligations are added to the
    existing Lua task tree at the first dependency-complete function leaf rather than claimed prematurely.
  Verification: **PASS 2026-07-12.** Current source/tests/descriptors and the callable checker prove exact v1 and
    variadic v2 behavior across Perl, Rust, Dart, and Julia native/generated paths. Stale capability README/manifest,
    roadmap, mdBook, Knowledge Map, live status, and task/index rollout text now name those four implementations.
    Lua already owns the spec shell, exact registry, isolated invocation frame, and compiled descriptor but does not
    dispatch function bodies; therefore `.5.1` is the first dependency-complete native variadic owner. `.5.3`
    explicitly owns descriptor admission, `.8.1` normalized generated-state preservation, `.8.2` independent
    generated execution of the neutral fixture, `.8.3` recurring proof, and `.8.4` capability retirement. The
    capability checker now discovers owners from both the future and Lua task trees, so the future manifest points
    directly at `.5.1`. The callable/capability/KM/memory/doctrine/task/whitespace/mdBook checks and unchanged
    dual-ABI Lua gate pass.
  Commit: `FUTURE-PARITY-BACKLOG.4.4 - close variadic callable routing`

### `FUTURE-PARITY-BACKLOG.4.4` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The four admitted implementations were green, but capability and roadmap surfaces
  still described Rust/Dart/Julia as rollout work and Lua had no explicit variadic obligations in its later leaves.
- [x] **ROOT CAUSE (WHY + WHERE)** — Lua's existing `.2.4` shell and `.3.3` registry deliberately stop before body
  dispatch; routing variadic behavior there retroactively would bypass its helper/value/control dependencies.
- [x] **FIX** — Keep Lua capability future and route native callable execution to `.5.1`, exact descriptors to
  `.5.3`, generated preservation/execution to `.8.1-.3`, and final capability retirement to `.8.4`; let the
  capability checker validate owner IDs from both task trees.
- [x] **ADDRESSED (verified)** — Four backend contract tests/gates remain authoritative; the neutral checker and
  no-drift scans agree, and every remaining Lua signature/native/generated/admission obligation has one owner.
- [x] **NO REGRESSION** — Planning/no-drift only: no parser, registry, runtime, descriptor, fixture, or generated-
  source behavior changed; Lua's current scalar numeric frontier and dual-ABI proof remain unchanged.
- [x] **LOCKSTEP** — Capability data, roadmap, task trees/index, README/book, Knowledge Map, changes/notes/live,
  and bounded memory close `.4` and return PNT to Lua `.4.3.3.1.4`.

### `FUTURE-PARITY-BACKLOG.4.0` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Direct descriptor and malformed-signature probes show fixed functions expose exact
  `arity`, while unrecognized rest spellings fail in the spec-owned definition shell.
- [x] **ROOT CAUSE (WHY + WHERE)** — Exact arity is copied through the grammar AST, staged payload/job, outward
  descriptor schema, every backend AST/compiled registry, call resolver, runtime frame, and generated-source state;
  loosening one runtime length check would create descriptor/compiler/runtime drift.
- [x] **FIX** — No behavior fix belongs in this audit. Split one neutral versioned signature/fixture owner, then
  Perl, Rust, Dart, and Julia implementation leaves, followed by Lua dependency routing and final no-drift.
- [x] **ADDRESSED (verified)** — Existing built-in `min,max` arity tables prove purpose-specific open maxima already
  exist; receiver methods use effective helper arguments. User functions are unique-name, non-overloaded calls and
  therefore need one optional final rest binding rather than host overload/splat semantics.
- [x] **NO REGRESSION** — Read-only LinkedSpec probes and source/contract inspection only; no grammar, descriptor,
  parser, runtime, generated-source, fixture, capability, or backend-status behavior changed.
- [x] **LOCKSTEP** — Task/index, roadmaps, architecture/live docs, mdBook status, Knowledge Map, changes/notes, and
  memory identify neutral contract `.4.1` as the sole active variadic frontier.

### `FUTURE-PARITY-BACKLOG.4.1` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — `.4.0` proves no neutral representation can express a fixed prefix plus unbounded
  rest without reinterpreting exact version-1 `arity`.
- [x] **ROOT CAUSE (WHY + WHERE)** — The staged/public/backend contract modeled only `params`/`arity`; helper open
  maxima existed separately and could not safely define user-function syntax or binding.
- [x] **FIX** — ADR 0030 plus `linkedspec-callable-signature-v1` select final `...IDENTIFIER`, version-2 signature
  records, eager positional calls, typed rest arrays, exact fixed functions, and stable diagnostics.
- [x] **ADDRESSED (verified)** — Independent checker validates three definitions, nine calls, seven invalid
  definitions, v1/v2 descriptor roles, representative helper/method purpose, exact expected bindings, and rendered
  `.spec` source; the checker and contract are recurring canonical-CI inputs.
- [x] **NO REGRESSION** — No backend parser/compiler/runtime behavior changed; current exact-function capability
  remains pass at census 60/0/0, canonical CI passes 61x2 CLI plus Phase 0 `1..1030` in 668 seconds, and variadic
  behavior is explicitly future/owned during rollout.
- [x] **LOCKSTEP** — ADR/index, task/index/roadmaps, README/TOOLBOX, capability data, mdBook, Knowledge Map,
  architecture/live docs, changes/notes, memory, checker, and CI agree; Perl reference `.4.2.1` is active.

### `FUTURE-PARITY-BACKLOG.4.2.1` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The unchanged neutral fixture initially produced correct rest arrays but
  `all_values(1, 2, 3).length()` returned Perl's array-reference address-string length (`18`) instead of `3`.
- [x] **ROOT CAUSE (WHY + WHERE)** — The function shell/registry/lowerer knew only v1 `params`/`arity`; additionally,
  the shared Perl `length` lowerer ignored the documented array value case and always invoked scalar `length`.
- [x] **FIX** — Parse final `...rest` into v2 signatures, validate/preserve them through staged/outward records,
  enforce min/exact arity, lower arguments to ordered temporaries, bind a fresh array from extras, and make the
  common length helper dispatch arrays to cardinality.
- [x] **ADDRESSED (verified)** — `t/variadic_user_function_contract.t` consumes the adopted JSON contract and passes
  66 assertions covering both grammar owners, exact v1/v2 keys, staged signatures, generated source, valid results, fresh identity,
  left-to-right single evaluation, seven invalid signatures, and fixed/variadic wrong-arity diagnostics.
- [x] **NO REGRESSION** — Fixed function records retain the exact outward v1 keys and diagnostics; scalar length is
  unchanged; canonical CI passes 66 focused assertions, 61x2 CLI, and Phase 0 `1..1030` in 710 seconds; no
  Rust/Dart/Julia/Lua behavior or capability census status changes in this backend-local leaf.
- [x] **LOCKSTEP** — Grammar/runtime/test/CI, task/index/roadmaps, README/TOOLBOX, mdBook, Knowledge Map, live docs,
  changes/notes, and memory agree that Perl is implemented and Rust `.4.2.2` is active.

- ID: `FUTURE-PARITY-BACKLOG.5`
  Status: `active`
  Goal: Normalize or permanently document helper caveats.
  Children: `.5.1`, `.5.2`, `.5.3`, `.5.4`, `.5.5`, `.5.6`, `.5.7`
  Acceptance: Own the array split/pipeline return-shape caveats (`SPEC-LANG-REFERENCE.5.3.1`) and
    odd-arity `hash(...)` behavior (`SPEC-LANG-REFERENCE.5.4.1`) as explicit keep-or-normalize decisions; also
    reconcile direct/constructor-context and arity drift for `flat`, `flat_array`, and `concat_arrays`: Perl
    accepts the catalog-sized one/two-argument forms but rejects zero/variadic direct forms, while Rust, Dart,
    Julia, and Lua currently return copied list values for those forms; normalize negative `take`/`drop`/`slice`
    counts too, because Dart clamps them to zero, Julia defaults invalid negatives, and Rust's signed-to-unsigned
    path can produce oversized counts. Reconcile dropped bare transform rebinding too: the Perl reference assigns
    and returns updated arrays for `split_each`, `filter_match`, and `uniq`, whereas Rust, Dart, and Julia currently
    rebind only `trim_each`, `filter_nonempty`, `lowercase_each`, and `uppercase_each` and silently discard the
    other three pure results. Normalize `join_values` invalid-source behavior as well: Perl returns an empty string
    for a non-array scalar and null for a missing/null source, while Rust, Dart, and Julia stringify a scalar and
    return an empty string for a missing source. Normalize implicit child-push expression results too: a direct
    Perl `push(Child)` leaks the host push count while Lua returns the updated implicit accumulator; explicit-target
    child push already returns the governed updated target. Include harray flatten context: Perl direct harray
    `flat`/`flat_hash` exposes host list/scalar context, shipped `hash(flat_array(defs))` is not recognized uniformly
    by newer typed runtimes, and harray-to-array key/value order differs across unordered/insertion-ordered hosts;
    Lua sorts keys locally for deterministic output, but that is not yet a portable sequence guarantee. Normalize
    `rename_key(source, old, new)` when `new` already exists too: direct CLI probes return the renamed old value on
    Perl/Julia but the pre-existing destination value on Dart/Rust, and the current catalog does not select either.
    Normalize condition/logical truthiness too: Perl and Rust treat scalar `"0"` as false while Dart and Julia
    treat every non-empty string as true; Perl treats empty array/hash reference values as true while Rust, Dart,
    and Julia treat empty aggregates as false. Lua follows the Perl reference pending this decision. Define one
    language-level truth table and lock it across lazy controls plus eager `and`/`or`/`not` helpers. Normalize
    if-family statement alias shapes too: portable authoring reserves `i`/`elif` for marker chains and
    `when`/`otherwise` for attached chains, while direct probes/source seams show Perl, Dart, and Julia accept all
    four aliases in both shapes and Rust accepts only the documented portable intersection. Either align rejection
    or formally enlarge the language with cross-backend tests; do not rely on the extra forms meanwhile.
    Normalize switch scalar comparison too: all variants make null match empty text, but Perl/Rust/Lua stringify
    booleans as `0/1` so `false` matches numeric zero, while Dart/Julia compare `false` to `0` as distinct text.
    Aggregate subjects/candidates are also not governed: Perl/Lua reject aggregate scalar comparison, Rust
    collapses arrays/hashes to empty text, and Dart/Julia stringify host containers. Select an explicit typed
    equality policy for inline, attached, and marker switch together.
    Normalize ordinary marker-switch statements outside a `case/default` range: direct Perl lowering executes
    statements before the first branch and after explicit `endcase()`, while Rust/Dart/Julia/Lua skip them.
    Either reject the ambiguous placement everywhere or adopt one explicit execution rule; portable specs keep
    every executable statement inside a branch meanwhile.
    Normalize attached-while guard and `next()` boundaries too. Perl/Rust re-evaluate the condition after the
    final allowed body and succeed if it is then false, while Dart/Julia throw immediately after that body; Lua
    follows Perl/Rust. Perl/Lua treat statement `next()` inside the body as inner-loop continue, Rust treats it as
    a no-op, and Dart/Julia propagate it to rule repetition. Choose one exact limit and flow rule before portable
    specs rely on either boundary.
    Normalize required receiver-helper arity too: Perl rejects `.contains()` because the implicit receiver still
    leaves one required authored argument, while Rust, Dart, Julia, and Lua currently default or otherwise accept the absent
    needle and return numeric `0`. This is pre-existing helper semantics, not permission for a punctuation-light alias to
    differ from its parenthesized twin.
    Remove the Perl-only result leak from `start_capture_slice()` too: the public helper catalog and Rust/Dart/Julia/Lua
    define this boundary mutation as void, while current Perl lowering exposes its internal assignment expression; keep
    the source-boundary reference aligned with the void contract and add a five-backend lock.
    Normalize `capture_until_boundary()` minimum arity too: its public signature requires at least one rule, but a
    direct reference probe leaves the zero-argument call raw and fails later as an undefined generated-handler
    subroutine, while Rust/Dart/Julia and Lua return null without moving the cursor. Select one typed boundary and
    lock compile/runtime diagnostics or neutral behavior across all backends.
    Finish with backend locks and mdBook/KM updates rather than silently selecting one host's behavior.
  Verification: `pending`
  Commit: `pending`

  Required receiver-arity execution: .5.6 is activated by TYPE23.2.13; five bounded contains implementation children23.3.13.1-.5 own native/generated missing/extra no-effect and punctuation-light twin locks. This changes only receiver contains shape, preserving free helper signatures/equality and other caveats.

  Captured-source/null-key execution: .5.7 is activated by TYPE23.2.14 and delegates six bounded repairs23.3.14.1-.6. Align existing Perl null distinction for contains/index_of/uniq while preserving defined coercion; cached aggregate source values and eager ordinary Perl has_key key evaluation follow existing typed-read/source contracts.

- ID: `FUTURE-PARITY-BACKLOG.5.1`
  Status: `done`
  Goal: Define and align one five-backend diagnostic-output helper contract.
  Children: `.5.1.0`, `.5.1.1`, `.5.1.2`, `.5.1.3`, `.5.1.4`, `.5.1.5`, `.5.1.6`, `.5.1.7`, `.5.1.8`,
    `.5.1.9`
  Dependencies: complete current Lua parity (satisfied by `LUA-BACKEND-PARITY.8.4`; activate only after clean pivot)
  Acceptance: Specify exact `print`/`say`/`print_each` arities, scalar-to-text rules, concatenation/newline and
    prefix/suffix behavior, eager evaluation, wrong-kind handling, parse-result neutrality, event grouping/order,
    caller-owned sink/trace routing, quiet default execution, sink-failure propagation, Unicode preservation, and
    immediate `exit_now` interaction in a neutral fixture. Align Perl, Rust, Dart, Julia, and Lua native plus
    generated/CLI paths where applicable; remove Rust's direct stderr bypass, Dart's evaluate-and-discard path,
    Julia's omitted-suffix newline drift, and any ungoverned Perl host-output coupling. Finish with shared tests,
    public docs, Knowledge Map, and capability/no-drift gates before structured-format execution can begin.
  Verification: **PASS 2026-07-16.** ADR `0042`, the neutral fixture/checker, five native event seams, every
    generated direct/traced role, exact quiet primary projection, omission-checked recurring orchestration, and
    public no-drift are complete. The final checker reports 8 complete/0 pending, owns 16 authoritative public
    documents plus nine forbidden stale-current claims, and rejects 20 semantic/topology/public-admission
    mutations. Complete backend gates, strict direct composition, unchanged 5x2x62 primary matrix, mdBook,
    Knowledge Map, governance, whitespace, and canonical local CI through reference CLI 62x2, Phase 0 `1..1031`,
    and the registered driver pass. Capability remains 80/0/0. Runtime semantics did not change in the closeout
    and no mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.9 - close diagnostic-output public no-drift`

- ID: `FUTURE-PARITY-BACKLOG.5.1.0`
  Status: `done`
  Goal: Audit and split the five-backend diagnostic-output contract before behavior code.
  Dependencies: completed five-backend parity (`LUA-BACKEND-PARITY.8.4`)
  Acceptance: Use the Knowledge Map and LinkedSpec toolbox before source inference; measure exact Perl lowering and
    native execution plus Rust/Dart/Julia/Lua runtime behavior for `print`, `say`, and `print_each`; inventory
    ActionIR/parser/compiler/runtime/generated/CLI, scalar-to-text, trace, diagnostic-event, sink, and failure seams;
    classify arity, evaluation, formatting, transport, result neutrality, Unicode, wrong-kind, sink-failure, and
    `exit_now` drift; then create dependency-correct neutral-contract, backend rollout, recurring five-backend gate,
    and no-drift children. Change no parser/compiler/runtime/generated/CLI behavior in this audit.
  Verification: **PASS 2026-07-16.** Knowledge Map retrieval and the prescribed `LinkedSpec::Get`,
    `call_spec_handler_subst`, and `dump_parser_source` probes precede source classification. Exact native and
    primary-process probes establish that this is four independent drifts rather than one output-string repair:
    arity/invalid-call handling, eager evaluation, scalar/message formatting, and transport/termination.
    Perl lowers directly to host `print`/`say`/`foreach`, repeats `print_each` prefix and suffix evaluation for
    every item, leaves invalid `print_each` calls raw, emits invalid mixed-encoding primary stdout for Unicode,
    and lets lowered host `exit` bypass canonical primary-command failure framing. Rust eagerly evaluates all
    arguments but writes one stderr line per argument/item and ignores `print_each` decoration. Dart eagerly
    evaluates and discards. Julia eagerly concatenates into low trace records, accepts every measured arity, and
    defaults an omitted `print_each` suffix to newline. Lua alone has exact one-plus/two-or-three arity checks,
    one typed event per call/item, quiet default execution, synchronous sink failure, and pre-exit-only delivery.
    Generated entrypoints expose only trace/configuration seams except Lua, while every primary command deliberately
    invokes its native engine without a rich diagnostic sink; Perl/Rust nevertheless leak through host IO.
    The work is split into one neutral executable contract, five native backend leaves, one generated/CLI
    projection leaf, one recurring symmetric gate, and one public no-drift closeout. No parser, compiler, runtime,
    generated-source, CLI, fixture, capability, or corpus behavior changed.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.0 - split diagnostic output parity`

### `FUTURE-PARITY-BACKLOG.5.1.0` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The canonical source inventory, Perl toolbox probes, exact five-command arity/
  Unicode/exit probes, Rust native test, focused Dart native tests, direct Julia trace probe, and direct Lua sink
  probe observe every current arity, message, grouping, output route, result, failure, Unicode, and side-effect
  difference. In particular, Perl `print_each` produces `1a12b2` and returns counters `[2,2]`, while its Unicode
  primary stdout is not valid UTF-8 and `say(...); exit_now(23)` exits the process as status 23.
- [x] **ROOT CAUSE (WHY + WHERE)** — `perl/LinkedSpec/ActionIR/ControlFlow.pm` emits host statements;
  `rust/linkedspec-runtime/src/engine.rs` eagerly evaluates then calls `eprintln!`; Dart's
  `dart/lib/src/runtime/interpreter.dart` calls `_evaluateValues` and returns; Julia's
  `julia/src/runtime/Interpreter.jl` joins into `log_trace_output!`; and Lua's
  `lua/src/linkedspec/interpreter.lua` owns the typed sink/event path. Source emitters and primary adapters show
  exactly where native options are or are not propagated. Transport drift is therefore separated from arity,
  evaluation, scalar coercion, grouping, and host-process control drift.
- [x] **FIX** — Split one neutral executable contract/decision owner, mechanism-sized backend rollout owners,
  generated/CLI applicability, a symmetric five-backend drift gate, and public no-drift closeout before behavior
  implementation. `.5.1.1` is the sole next leaf; this audit does not silently select a backend policy.
- [x] **ADDRESSED (verified)** — Every acceptance dimension in `.5.1` maps to exact evidence and one future child;
  no runtime path, generated-source path, CLI projection, sink/error case, or authoritative public surface is left
  unowned.
- [x] **NO REGRESSION** — Planning changes no source behavior, fixtures, capability 80/0/0, generated-source state,
  primary CLI bytes, corpus expectations, or mutation policy; focused inventory/probe, governance, mdBook, and
  canonical gates pass in proportion to the docs-only slice; local CI includes primary CLI 61x2 and Phase 0
  true reach `1..1031` in 607 seconds.
- [x] **LOCKSTEP** — Task/index, roadmap, Knowledge Map, mdBook, live docs, and bounded memory identify only neutral
  executable-contract leaf `.5.1.1` after `.5.1.0` commits.

- ID: `FUTURE-PARITY-BACKLOG.5.1.1`
  Status: `done`
  Goal: Ratify and encode the backend-neutral diagnostic-output contract before backend behavior changes.
  Dependencies: `.5.1.0`
  Acceptance: Add a durable decision plus machine-readable neutral fixtures for exact `print`/`say`/`print_each`
    arities; eager once-only left-to-right evaluation; scalar-to-text and wrong-kind rules; call/item event
    grouping; newline/prefix/suffix text; Unicode/order; parse-result neutrality; quiet default; synchronous
    caller-owned sink and sink-failure propagation; immediate `exit_now`; generated entrypoint propagation; and
    canonical primary-CLI quietness. Keep ADR `0024`'s phase-only primary trace separate from native rich events.
    The manifest/checker may describe future backend legs but must not claim or change backend behavior yet.
  Verification: **PASS 2026-07-16.** ADR `0042` and `linkedspec-diagnostic-output-v1` fix three helper
    signatures, 11 scalar-render rows, five invalid arities, four exact neutral programs, six collected/quiet/
    wrong-kind/sink-failure/exit scenarios, native/generated/CLI/trace projections, and eight explicitly pending
    rollout owners. `tools/check_diagnostic_output_contract.py` independently evaluates the fixtures and rejects
    eight representative mutations. Capability remains 80/0/0; generated-source and 246/105+1/122 coverage gates
    remain exact. Memory, Knowledge Map, doctrines, mdBook, shell, and whitespace pass. Canonical local CI passes
    primary CLI 61x2 and Phase 0 true reach `1..1031` in 609 seconds. No parser, compiler, runtime, generated-source,
    primary-CLI, corpus, or current backend-capability behavior/claim changes; mutation campaigns were not run.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.1 - ratify diagnostic output events`

### `FUTURE-PARITY-BACKLOG.5.1.1` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Preserve `.5.1.0`'s exact five-backend evidence as the reason a neutral contract is
  required; do not infer portable behavior from any one host implementation.
- [x] **ROOT CAUSE (WHY + WHERE)** — Separate callable validation, eager argument evaluation, scalar diagnostic
  rendering, typed event formation, caller-owned delivery, generated propagation, primary-CLI projection, and
  immediate termination so each later backend leaf has one exact target seam.
- [x] **FIX** — Ratify ADR `0042`; add one strict machine-readable semantic fixture and an offline checker covering
  exact arity, evaluation, rendering, grouping/order, Unicode, wrong-kind, result neutrality, quiet execution,
  synchronous sink failure, `exit_now`, generated entrypoints, and ADR `0024` separation without changing runtime
  behavior or claiming backend admission.
- [x] **ADDRESSED (verified)** — The checker independently evaluates the neutral fixture, rejects representative
  contract mutations, records every backend leg as pending with its exact task owner, and is registered in the
  canonical local gate as a design-contract check only.
- [x] **NO REGRESSION** — Focused contract/checker, governance, Knowledge Map, mdBook, whitespace, and canonical
  gates pass; capability remains 80/0/0 and no parser/compiler/runtime/generated/CLI behavior or current
  conformance claim changes.
- [x] **LOCKSTEP** — Decision index, task/index, roadmap, live docs, mdBook, capability inventory documentation,
  Knowledge Map, and bounded memory point to Perl native implementation `.5.1.2` only after this slice commits.

- ID: `FUTURE-PARITY-BACKLOG.5.1.2`
  Status: `done`
  Goal: Replace Perl host diagnostic/control coupling with the neutral native event seam.
  Dependencies: `.5.1.1`
  Acceptance: Perl ActionIR/live generated handlers enforce the neutral arities and once-only evaluation, format
    exact typed events through a parse-scoped caller sink, remain quiet without one, propagate sink failure, keep
    parse values structural, preserve strict Unicode, and stop using raw host output or host `exit` as observable
    parser/primary-command behavior. Focused toolbox/generated-source evidence locks every former failure mode.
  Verification: **PASS 2026-07-16.** The new `LinkedSpec::RuntimeDiagnosticOutput` seam consumes the unchanged
    neutral fixture through exact scalar rendering, typed event delivery, invocation-local sink validation,
    sink-failure identity, and typed immediate exit. ActionIR rejects invalid arities before emitting argument
    expressions and snapshots valid arguments exactly once left-to-right before one-call/one-item delivery. Live
    parsers accept `{ diagnostic_sink => CODE }`; absent sinks write no host output; wrapper boundaries preserve
    marked caller/exit errors without `last_error` rewriting. The focused contract passes 16 top-level tests,
    combined focused Perl proof passes 28, the offline contract checker reports 1 complete/7 pending rollout legs,
    generated-source contract stays green, direct Phase 0 passes `1..1031` in 640 seconds, and canonical CI repeats
    it in 637 seconds after CLI 61x2. Independently emitted
    entrypoint option propagation, canonical primary projection admission, other backends, symmetric admission,
    and capability/no-drift remain `.5.1.3-.9`.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.2 - add Perl diagnostic event seam`

## `FUTURE-PARITY-BACKLOG.5.1.2` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Pre-change toolbox lowering and a two-rule live parse prove that `print`, `say`,
  `print_each`, and `exit_now` compiled to Perl host output/process-control operations; exact captured
  bytes and dumped generated source preserve the pre-change failure mechanism: `print "a", "b"`, `say "a"`,
  host `foreach`, and `exit(23)`; a live parser writes `beforeline\n` while returning the structural value.
- [x] **ROOT CAUSE (WHY + WHERE)** — Identify the ActionIR contracts/lowerers that emit host operations, the live
  descriptor/handler boundary that currently has no parse-scoped diagnostic sink, and the wrapper behavior that
  would otherwise swallow a caller sink failure or typed immediate exit. `ControlFlow` owned host lowering,
  `FlowRules` discarded invalid arities before typed lowering, `Compiler` installed no invocation-local channel,
  and `Compiler`/`SpecEntry` eval wrappers converted thrown control into ordinary parser errors.
- [x] **FIX** — Enforce the neutral helper arities before evaluation; evaluate every valid argument exactly once
  left-to-right; deliver exact typed `RuntimeDiagnosticOutputEvent` values through one invocation-local optional
  caller sink; make absent sinks quiet; preserve structural parse values and strict Unicode; replace raw host
  `exit` with typed immediate parser control. `RuntimeDiagnosticOutput`, ActionIR contracts/lowering, scanner,
  compiler/runtime invocation options, and error wrappers now share that one seam.
- [x] **ADDRESSED (verified)** — Focused tests consume `linkedspec-diagnostic-output-v1` and prove exact event
  grouping/order/text, quiet default behavior, once-only effects, wrong-kind handling, result neutrality, Unicode,
  sink-failure identity/short-circuiting, typed exit, arity rejection before evaluation, and live/dumped generated
  handler source free of observable host `print`/`say`/`exit` coupling.
- [x] **NO REGRESSION** — Existing focused ActionIR/runtime/generated-source suites and the canonical local gate
  pass; no generated-entrypoint, primary-CLI projection, other-backend admission, or capability claim moves from
  its later owning leaf. Focused contract/uniform-binding/generated-source proof and Phase 0 `1..1031` are green;
  the contract ledger advances only `perl_native`.
- [x] **LOCKSTEP** — Perl source/tests, task/index/roadmap/live docs, mdBook, Knowledge Map, and bounded memory
  describe the same parse-scoped native event seam and point to Rust rollout `.5.1.3` only after this slice commits.

- ID: `FUTURE-PARITY-BACKLOG.5.1.3`
  Status: `done`
  Goal: Replace Rust direct stderr diagnostic output with the neutral native event seam.
  Dependencies: `.5.1.1`
  Acceptance: Rust exposes the same typed parse-scoped sink/events, exact arities, once-only evaluation, formatting,
    failure, result-neutrality, Unicode, wrong-kind, and exit behavior as the neutral contract; no helper writes
    directly to stderr. Existing runtime diagnostics and native trace remain distinct typed facilities.
  Verification: **PASS 2026-07-16.** Exported `RuntimeDiagnosticOutputEvent`, cloneable caller-owned
    `RuntimeDiagnosticOutputSink`, typed `RuntimeDiagnosticOutputExecutionError`, and typed `RuntimeExitNow`
    provide optional top-rule and direct-value native entrypoints. Raw-AST validation rejects all five invalid
    neutral arities before effects, including fallback/fluent dispatch; valid arguments evaluate once
    left-to-right; one exact Unicode event is delivered per call/item; empty and wrong-kind targets remain
    eventless; absent sinks are quiet; and no diagnostic helper writes stdout/stderr. The caller's concrete sink
    error is retained through the engine's compatibility string unwind and restored as a downcastable shared
    value, while ordinary structured runtime diagnostics and native trace remain separate. The six-test neutral
    consumer covers 11 render rows, five invalid arities, six scenarios, wrapped/direct results, trace separation,
    sink failure identity, and typed exit. The complete Rust gate passes 137 unit tests, 105/105 oracle corpus,
    105/105 generated classification, 197 integrations, existing source-emitter/runtime-diagnostic/trace suites,
    and primary CLI 61x2. The offline checker reports 2 complete/6 pending and rejects eight mutations; canonical
    local CI passes primary CLI 61x2 and Phase 0 `1..1031` in 611 seconds. Capability stays 80/0/0, generated/primary propagation
    remains `.5.1.7`, and no mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.3 - add Rust diagnostic event seam`

## `FUTURE-PARITY-BACKLOG.5.1.3` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Preserve `.5.1.0`'s exact Rust native baseline and reverify its current source
  mechanism: valid calls eagerly evaluate every authored argument left-to-right, zero-argument `print`/`say` and
  invalid `print_each` arities are accepted, `print`/`say` write one added-newline stderr record per argument,
  `print_each` writes one bare item record while discarding evaluated decoration, and `exit_now(23)` returns the
  compatibility string `exit_now(23)` only after any preceding direct stderr leak.
- [x] **ROOT CAUSE (WHY + WHERE)** — `Engine::eval_expr` evaluates every non-lazy helper argument before helper
  dispatch, so output arity cannot reject before effects. `Engine::call_helper` then formats with general
  `RuntimeValue::to_str`, calls `eprintln!` directly, stores `exit_status`, and reduces output, sink, and exit
  control to `Result<RuntimeValue, String>`. `RuntimeContext` has native trace and runtime-failure state but no
  separate invocation-local diagnostic-output channel; the public native APIs therefore cannot preserve typed
  events, caller sink failure, and immediate exit as three distinct outcomes.
- [x] **FIX** — Add exported `RuntimeDiagnosticOutputEvent`, caller-owned per-invocation sink, typed sink/runtime/
  exit outcome, and exact diagnostic-fragment rendering. Validate the three helper arities from raw AST before
  evaluation; evaluate every valid argument once left-to-right; deliver one call/item event synchronously; keep
  absent-sink execution quiet; remove helper `eprintln!`; and expose equivalent top-rule and direct-value native
  entrypoints without modifying generated entrypoints owned by `.5.1.7`.
- [x] **ADDRESSED (verified)** — A focused Rust consumer of `linkedspec-diagnostic-output-v1` proves all 11 scalar
  render rows, all five pre-effect arity failures, collected and quiet Unicode/order scenarios, empty/wrong-kind
  `print_each`, result neutrality, exact item grouping/decorations, unchanged synchronous sink-failure payload and
  short-circuit, and one preceding event followed by typed status 23 with no later evaluation. Source inspection
  proves diagnostic helpers contain no direct stdout/stderr write.
- [x] **NO REGRESSION** — Existing structured `RuntimeDiagnostic`/`RuntimeExecutionError` and native trace remain
  independently typed and unchanged for ordinary failures; legacy native methods retain compatible string/error
  projections while becoming quiet. Focused contract tests, existing runtime diagnostics/trace/source-emitter
  tests, the complete Rust local gate, neutral checker, capability/coverage checks, and canonical local CI pass;
  generated and primary-CLI admission stays pending under `.5.1.7`.
- [x] **LOCKSTEP** — Rust API/source/tests, neutral rollout ledger, task/index/roadmap/live docs, mdBook, Knowledge
  Map, and bounded memory describe the same native-only event seam and point to Dart `.5.1.4` only after this
  slice is verified, committed, and clean.

- ID: `FUTURE-PARITY-BACKLOG.5.1.4`
  Status: `done`
  Goal: Replace Dart's evaluate-and-discard branch with the neutral native event seam.
  Dependencies: `.5.1.1`
  Acceptance: Dart preserves eager once-only argument effects while adding the same typed parse-scoped events,
    exact arity/format/wrong-kind/failure/result/exit semantics and quiet default as the neutral contract. Rich
    trace and structured runtime failures remain separate from diagnostic-output delivery.
  Verification: **PASS 2026-07-16.** Exported `RuntimeDiagnosticOutputEvent`,
    `RuntimeDiagnosticOutputSink`, and `RuntimeExitNow` provide the exact native event/exit types; `parse`,
    `execute`, `parseWithTrace`, and `executeWithTrace` accept one optional invocation-local sink. Raw
    `ActionArgument` validation rejects all five neutral invalid arities at `helper_arity_mismatch` before effects;
    valid arguments evaluate once left-to-right and form one exact Unicode event per call/item; omitted sinks are
    quiet; null/aggregate/codeblock fragments are empty; empty/wrong-kind targets are eventless; and parse results
    remain structural. A private sink-failure carrier passes arbitrary caller objects through action-block and
    runtime-diagnostic wrappers, then restores exact identity and stack, including when the sink itself throws
    `RuntimeInterpreterException`. Typed exit also bypasses ordinary failure wrapping after preceding delivery.
    The six-test neutral consumer covers 11 render rows, five invalid arities, six scenarios, all four native
    aliases, trace separation, sink identity, and typed exit. The complete Dart gate passes format/analyze, 220
    tests, primary CLI 61x2, and corpus 105/105. The offline checker reports 3 complete/5 pending and rejects eight
    mutations. Canonical local CI passes primary CLI 61x2 and Phase 0 `1..1031` in 613 seconds. Capability remains
    80/0/0; generated/primary propagation stays `.5.1.7`; no mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.4 - add Dart diagnostic event seam`

## `FUTURE-PARITY-BACKLOG.5.1.4` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Preserve `.5.1.0`'s measured Dart native baseline and lock it in a focused neutral-
  fixture consumer: `print`, `say`, and `print_each` eagerly evaluate then discard every argument, accept invalid
  arities, expose no caller-owned output event, and report `exit_now` as an ordinary runtime interpreter failure.
- [x] **ROOT CAUSE (WHY + WHERE)** — Confirm `_evaluateCall` strips `ActionArgument` shape before helper dispatch,
  sends all three diagnostic helpers through `_evaluateValues`, and throws `RuntimeInterpreterException` for
  exit; the public engine and `_RuntimeExecutionContext` carry native trace but no independent diagnostic-output
  sink. Account for `_parse`'s runtime-exception wrapper so even a caller sink throwing that same exception type
  can still propagate unchanged.
- [x] **FIX** — Export the exact typed event, per-invocation optional sink, and typed immediate exit; validate raw
  positional arity before effects; evaluate each valid argument once left-to-right; render and synchronously
  deliver exact call/item events; preserve caller sink failure identity; keep absent-sink execution quiet; and
  change only native engine entrypoints while generated propagation remains owned by `.5.1.7`.
- [x] **ADDRESSED (verified)** — A focused Dart consumer of `linkedspec-diagnostic-output-v1` proves all 11 scalar
  rows, five pre-effect arity failures, six collected/quiet/failure/exit scenarios, Unicode, grouping, empty and
  wrong-kind targets, structural result neutrality, once-only order, exact caller failure identity, typed exit,
  and native trace separation.
- [x] **NO REGRESSION** — Existing structured runtime diagnostics, lifecycle/trace, source emission, generated
  entrypoints, native compatibility methods, corpus/classifier/integration tests, primary CLI conformance, neutral
  checker, capability state, and canonical local CI remain green; generated and CLI admission stays `.5.1.7`.
- [x] **LOCKSTEP** — Dart API/source/tests, neutral rollout ledger, task/index/roadmap/live docs, mdBook, Knowledge
  Map, and bounded memory describe the same native-only event seam and advance to Julia `.5.1.5` only after this
  leaf is verified, committed, and clean.

- ID: `FUTURE-PARITY-BACKLOG.5.1.5`
  Status: `done`
  Goal: Separate Julia diagnostic helper events from trace and align the neutral native contract.
  Dependencies: `.5.1.1`
  Acceptance: Julia stops using low trace as the helper transport, removes its omitted-suffix newline and permissive
    arity drift, and exposes the same typed parse-scoped sink, once-only formatting/grouping, quietness, failure,
    result, Unicode, wrong-kind, and exit behavior. Existing native trace remains independently configurable.
  Verification: **PASS 2026-07-16.** Exported `RuntimeDiagnosticOutputEvent`,
    `RuntimeDiagnosticOutputSink`, and `RuntimeExitNow` provide the exact native event/exit types;
    `runtime_parse`, `runtime_execute`, `runtime_parse_with_trace`, and `runtime_execute_with_trace` accept one
    optional invocation-local sink. Raw `ActionArgument` validation rejects all five neutral invalid arities at
    `helper_arity_mismatch` before effects; valid arguments evaluate once left-to-right and form one exact Unicode
    event per call/item; omitted sinks are quiet; null/aggregate/codeblock fragments are empty; omitted
    `print_each` suffixes are empty; empty/wrong-kind targets are eventless; and parse results remain structural.
    A private sink-failure carrier passes arbitrary caller objects through action-block and runtime-diagnostic
    wrappers, then restores exact identity, including when the sink itself throws `RuntimeInterpreterException`.
    Typed exit also bypasses ordinary failure wrapping after preceding delivery, and rich event text no longer
    enters native trace. The focused neutral consumer passes 74 assertions over 11 render rows, five invalid
    arities, six scenarios, all four native aliases, trace separation, sink identity, and typed exit. The complete
    Julia gate passes package tests, primary CLI 61x2, and corpus 105/105. The offline checker reports 4 complete / 4
    pending and rejects eight mutations. Canonical local CI passes primary CLI 61x2 and Phase 0 `1..1031` in 616
    seconds. Capability remains 80/0/0; generated/primary propagation stays `.5.1.7`; no mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.5 - add Julia diagnostic event seam`

## `FUTURE-PARITY-BACKLOG.5.1.5` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Preserve `.5.1.0`'s exact Julia native baseline in a focused neutral-fixture
  consumer: diagnostic helpers share low trace transport, accept invalid arities, and give omitted
  `print_each` suffix an added newline instead of the neutral empty text.
- [x] **ROOT CAUSE (WHY + WHERE)** — Identify the helper dispatcher, scalar formatter, trace-output call, runtime
  context/config seam, and generic exception wrappers that currently conflate helper events, structured runtime
  failures, native trace, sink failure, and immediate exit or would rewrite caller-owned control.
- [x] **FIX** — Export the exact typed event, optional per-invocation caller sink, and typed immediate exit; validate
  positional arity before effects; evaluate each valid argument once left-to-right; render and synchronously
  deliver exact call/item events; preserve arbitrary sink failure unchanged; keep absent sinks quiet; and leave
  generated entrypoint propagation to `.5.1.7`.
- [x] **ADDRESSED (verified)** — A focused Julia consumer of `linkedspec-diagnostic-output-v1` proves all 11 scalar
  rows, five pre-effect arity failures, six collected/quiet/failure/exit scenarios, Unicode, grouping, empty and
  wrong-kind targets, structural result neutrality, once-only order, exact caller failure, typed exit, and native
  trace separation.
- [x] **NO REGRESSION** — Existing structured runtime diagnostics, trace, generated-plan/emitted-state paths,
  package tests, primary CLI 61x2, corpus 105/105, neutral checker, capability 80/0/0, mdBook, governance, and
  canonical CI remain green; generated and primary admission stays `.5.1.7`.
- [x] **LOCKSTEP** — Julia API/source/tests, neutral rollout ledger, task/index/roadmap/live docs, mdBook, Knowledge
  Map, and bounded memory describe the same native-only event seam and advance to Lua `.5.1.6` only after this
  leaf is verified, committed, and clean.

- ID: `FUTURE-PARITY-BACKLOG.5.1.6`
  Status: `done`
  Goal: Admit Lua's existing event design against the neutral contract and close any exact residual.
  Dependencies: `.5.1.1`
  Acceptance: PUC Lua and LuaJIT consume the neutral fixtures through the existing typed per-parse sink, with exact
    arity, once-only evaluation, scalar text, item grouping, quietness, sink failure, Unicode, result, wrong-kind,
    and immediate-exit proof. Change only a measured contract residual; do not create a Lua-specific convention.
  Verification: **PASS 2026-07-16.** The focused Lua consumer directly evaluates the unchanged neutral fixture
    with 109 assertions over 11 render rows, five invalid arities, six scenarios, all four native aliases, exact
    event JSON, trace separation, caller failure identity, and typed exit on both PUC Lua and LuaJIT. Its baseline
    passed 105/109 assertions and isolated exactly two residual mechanisms: `exit_now` used the ordinary
    interpreter-failure metatable, and `runtime_parse` cloned an unwrapped caller-thrown
    `RuntimeInterpreterException` while attaching a structured diagnostic. `RuntimeExitNow` is now distinct typed
    control with the existing status/message, while a private sink-failure carrier restores any exact caller value
    only at the public parse boundary. The complete Lua gate passes 177 tests per ABI, focused 109 per ABI,
    primary CLI 61x2, and corpus 105/105. The offline checker reports 5 complete / 3 pending and rejects eight
    mutations. Canonical local CI passes primary CLI 61x2 plus Phase 0 `1..1031` in 656 seconds. Capability remains
    80/0/0; generated/primary propagation remains `.5.1.7`; no mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.6 - admit Lua diagnostic events`

## `FUTURE-PARITY-BACKLOG.5.1.6` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Consume `linkedspec-diagnostic-output-v1` directly on PUC Lua and LuaJIT, preserving
  the already-correct typed event, exact arity, once-only evaluation, scalar rendering, grouping, Unicode,
  quietness, structural result, wrong-kind, and pre-exit delivery evidence while measuring any exact residual.
- [x] **ROOT CAUSE (WHY + WHERE)** — Account for the public `runtime_parse` failure boundary as well as helper
  dispatch: ordinary `RuntimeInterpreterException` values are copied when a structured runtime diagnostic is
  attached, so a sink that throws that same public type loses caller identity; `exit_now` currently calls the
  ordinary `fail(...)` constructor, so immediate control is not a distinct `RuntimeExitNow` outcome.
- [x] **FIX** — Change only those measured residuals: carry arbitrary sink failures opaquely through internal
  action/rule wrappers and restore the exact caller value at the native parse boundary; expose typed immediate
  exit separately from ordinary runtime failure without changing status, message, or short-circuit behavior.
- [x] **ADDRESSED (verified)** — A focused neutral-fixture consumer proves all 11 render rows, five pre-effect
  arity failures, six scenarios, all four native aliases, exact event JSON, exact sink-failure identity (including
  a caller-thrown interpreter exception), typed exit, and separation from native trace on both Lua ABIs.
- [x] **NO REGRESSION** — The complete Lua gate, primary CLI 61x2, corpus 105/105, offline neutral checker,
  capability/generated-source locks, governance, mdBook, Knowledge Map, whitespace, and canonical CI pass; only
  `lua_native` advances and generated/primary propagation remains `.5.1.7`.
- [x] **LOCKSTEP** — Lua API/source/tests, neutral rollout ledger, task/index/roadmap/live docs, mdBook, Knowledge
  Map, and bounded memory describe the same admitted native event seam and advance to `.5.1.7` only after this
  leaf is verified, committed, and clean.

- ID: `FUTURE-PARITY-BACKLOG.5.1.7`
  Status: `done`
  Goal: Propagate diagnostic sinks through generated entrypoints and lock the exact primary-CLI projection.
  Dependencies: `.5.1.2`, `.5.1.3`, `.5.1.4`, `.5.1.5`, `.5.1.6`
  Acceptance: Every available generated-source API can receive the same caller-owned sink without changing direct
    values, portable generated trace, metadata, plans, or failure attribution. The five primary commands install no
    rich sink, retain ADR `0024`'s independent canonical phase trace, and produce only canonical JSON on successful
    default diagnostic-helper execution; no backend adds an exclusive CLI flag or semantics.
  Checklist:
  - [x] **RETRIEVE / INVENTORY** — Read the generated-source v1, diagnostic-output, and canonical primary-trace
    records; confirm that Perl exposes `Execute`/`ExecuteWithTrace`/`Get`, Rust exposes typed v1 plus compatibility
    direct/traced roles, Dart and Julia expose direct/traced generated functions, Lua exposes option-bearing
    direct/traced module functions, and all five primary adapters already omit rich sinks.
  - [x] **PERL GENERATED** — Make independently loaded `Execute`, `ExecuteWithTrace`, and `Get` accept one validated
    invocation-local sink; preserve exact caller failure and typed `RuntimeExitNow` instead of generated-error
    wrapping, while retaining ordinary generated failure attribution.
  - [x] **RUST GENERATED** — Add idiomatic direct/traced diagnostic-output entrypoints for both typed-v1 and
    compatibility generated roles; preserve sink payload and typed exit in a public generated execution outcome,
    while retaining legacy signatures and exact structured generated errors for existing callers.
  - [x] **DART / JULIA GENERATED** — Thread optional named/keyword sinks through emitted and underlying direct/traced
    APIs; carry arbitrary caller failures opaquely through generated framing, preserve typed exit, and keep ordinary
    failures source-attributed.
  - [x] **LUA GENERATED** — Prove the emitted option-bearing API and unwrap caller sink failures plus
    `RuntimeExitNow` across generated execution framing without changing ordinary generated errors.
  - [x] **PRIMARY PROJECTION** — Add one shared default-execution diagnostic-helper case whose exact projection is
    canonical JSON plus newline, empty stderr, and no helper text; run it unchanged through all five commands under
    default and POSIX environments, retaining the existing ADR `0024` phase-trace cases and adding no CLI option.
    The initial direct default-rule `E` fixture reproduced the already recorded
    `perl-lifecycle-final-value-e-drift`: `call_spec_handler_subst` lowered all four statements correctly, while
    `dump_parser_source` showed the Perl handler body omitted that direct regex/`E` path and returned `0`. The
    corrected fixture uses the established portable action-edge shape, keeping lifecycle normalization outside
    this leaf while still executing all three diagnostic helpers before the exact visible return.
  - [x] **NO REGRESSION** — Prove native and generated values/events/order, quietness, trace separation,
    sink-failure identity, typed exit, metadata/plan/source attribution, all backend gates, generated-source and
    capability contracts, mdBook, Knowledge Map, governance, whitespace, and canonical local CI.
  - [x] **LOCKSTEP** — Update the neutral rollout ledger, task/index/roadmap/live docs, mdBook, Knowledge Map, and
    bounded memory to the exact generated/primary admission, leaving symmetric recurring orchestration solely to
    `.5.1.8` and public no-drift closeout solely to `.5.1.9`.
  Verification: **PASS 2026-07-16.** Focused Perl generated proof; Rust seven-test diagnostic contract and
    source-emitter suite; Dart format/analyze and 13 focused tests; Julia 82-assertion diagnostic contract plus
    emitted-source proof; Lua 119 focused assertions on PUC Lua and LuaJIT; complete Rust, Dart, Julia, and Lua
    gates; exact five-backend/default-POSIX 62-case matrix; diagnostic checker 6 complete/2 pending with eight
    rejected mutations; generated-source/capability 80/0/0, mdBook, Knowledge Map, doctrines, memory, and
    whitespace; canonical CLI 62x2 plus Phase 0 `1..1031` in 623 seconds. The initial direct-`E` fixture failure
    was root-caused with `call_spec_handler_subst` and `dump_parser_source`, then replaced by the already governed
    portable action-edge form before these final passes. Mutation campaigns were not run.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.7 - propagate generated diagnostic events`

- ID: `FUTURE-PARITY-BACKLOG.5.1.8`
  Status: `done`
  Goal: Add one recurring symmetric five-backend diagnostic-output conformance gate.
  Dependencies: `.5.1.7`
  Acceptance: One checker drives the neutral native fixtures through Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT,
    plus every available generated path and exact five-command quiet case. It rejects missing scenarios/backends,
    event-schema/order/message drift, stdout/stderr bypass, sink/error/exit drift, skipped generated proof, and
    capability/corpus regression, and is registered in canonical local CI.
  Checklist:
  - [x] **RETRIEVE / INVENTORY** — Use the neutral and cross-backend Knowledge Map records plus existing recurring
    five-backend driver precedent to identify the authoritative contract checker, six focused native/generated
    consumers, selected quiet-primary case, capability/generated-source/corpus ledgers, and canonical local-CI
    registration seams before changing orchestration.
  - [x] **LOCK GATE TOPOLOGY** — Extend the neutral contract and offline checker with one exact recurring-gate
    topology: driver path, ordered Perl/Rust/Dart/Julia/PUC-Lua/LuaJIT consumers, required native+generated roles,
    quiet CLI case, and capability/generated-source/corpus support checks. Reject omitted/reordered consumers,
    skipped generated roles, wrong CLI projection, and missing support checks through explicit drift mutations.
  - [x] **SYMMETRIC DRIVER** — Add one strict portable shell driver that fails fast, requires every selected host
    toolchain, runs the unchanged neutral checker and each focused native/generated consumer, builds disposable Lua
    adapters for both ABIs, and retains exact caller failure, typed exit, event order/message, and trace separation
    as backend-owned assertions.
  - [x] **EXACT PRIMARY PROJECTION** — Give the existing five-backend primary matrix a repeatable selected-case
    interface and have the diagnostic driver execute only `success_diagnostic_helpers_quiet` under default and
    POSIX environments, preserving full-matrix default behavior and exact stdout/stderr/status comparison.
  - [x] **CAPABILITY / CORPUS REGRESSION** — Run the generated-source, capability-census, and exhaustive language-
    coverage checkers inside the driver so generated-path/corpus proof references and the 80/0/0 census cannot
    regress independently of diagnostic semantics.
  - [x] **CANONICAL REGISTRATION** — Make the driver a tracked/audited/syntax-checked local-CI input and register
    its all-toolchain execution through the established explicit optional-matrix switch; prove both the direct
    driver and canonical registration path.
  - [x] **NO REGRESSION** — Prove shell/Python syntax, offline mutation rejection, all six focused consumers, exact
    five-command/default-POSIX quiet projection, generated-source/capability/corpus ledgers, mdBook, Knowledge Map,
    governance, whitespace, and the complete canonical local gate. Do not change runtime semantics or run mutation
    campaigns.
  - [x] **LOCKSTEP** — Update the rollout ledger, task/index/roadmap/live docs, mdBook, Knowledge Map, and bounded
    memory to recurring-gate admission only; leave public no-drift closeout solely to `.5.1.9`.
  Verification: **PASS 2026-07-16.** Direct composed driver passes the neutral model, Perl 16 tests, Rust 7 tests,
    Dart 7 tests, Julia 82 assertions, PUC Lua 119 assertions, LuaJIT 119 assertions, exact 5x2x1 quiet primary
    projection, generated-source/capability 80/0/0, and exhaustive 246-name/105-corpus-plus-one/122-public-contract
    ledgers. The offline checker reports 7 complete/1 pending and rejects 16 semantic/topology/admission mutations;
    shell/Python syntax, unchanged default 5x2x62 matrix, mdBook, Knowledge Map, memory, doctrines, and whitespace
    pass. Canonical local CI with `LINKEDSPEC_RUN_DIAGNOSTIC_MATRIX=1` passes reference CLI 62x2, Phase 0
    `1..1031`, and the registered composed driver. No runtime semantics changed and mutation campaigns were not
    run.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.8 - add recurring diagnostic-output gate`

- ID: `FUTURE-PARITY-BACKLOG.5.1.9`
  Status: `done`
  Goal: Close diagnostic-output public documentation, Knowledge Map, capability, and no-drift state.
  Dependencies: `.5.1.8`
  Acceptance: The helper catalog, value-flow guide, tracing/API docs, backend handoff, roadmap, capability evidence,
    task/index/live docs, and Knowledge Map teach one exact contract with extensive native/generated examples and
    no historical caveat presented as current behavior. Complete backend and canonical gates pass; parent `.5.1`
    closes and `.5.2` becomes the next PNT candidate.
  Checklist:
  - [x] **RETRIEVE / INVENTORY** — Start from the neutral and cross-backend Knowledge Map cards, then enumerate
    every current helper catalog, value-flow, tracing/API, backend README/handoff, roadmap/status, capability,
    task/index, and mdBook claim that teaches `print`, `say`, `print_each`, their event sink, generated projection,
    typed exit, primary quietness, or recurring proof. Separate historical evidence from current guidance.
  - [x] **ONE PUBLIC CONTRACT** — Align all normative/current surfaces on exact arity-before-effects, once-only
    left-to-right evaluation, 11 scalar renderings, structural event fields/order, quiet absent sink, exact caller
    sink-failure identity, distinct typed `exit_now`, trace/result separation, and five-backend native+generated
    availability. Remove or clearly historicize every conflicting caveat.
  - [x] **EXTENSIVE HOST EXAMPLES** — Give users copyable native and generated sink examples for Perl, Rust, Dart,
    Julia, and Lua, using each backend's real public API and event access style; explain PUC Lua versus LuaJIT,
    primary CLI quietness, and the distinction between rich diagnostic events and ADR `0024` phase trace.
  - [x] **PUBLIC NO-DRIFT GATE** — Extend the machine-readable neutral contract and independent checker with the
    authoritative public-document set and exact durable markers. Reject missing surfaces, stale current caveats,
    omitted backend/native/generated/CLI concepts, and premature parent admission with explicit mutations or
    equivalent deterministic checks; compose it into the recurring five-backend driver.
  - [x] **CAPABILITY / KNOWLEDGE MAP CLOSEOUT** — Advance only `public_no_drift`, retain 80/0/0 capability and
    generated-source/corpus boundaries, refresh the neutral/cross-backend and backend-specific fact cards, and
    regenerate the derived Knowledge Map without inventing behavior beyond the executable contract.
  - [x] **COMPLETE VERIFICATION** — Run the offline checker, public drift scan, strict recurring diagnostic driver,
    complete Perl/Rust/Dart/Julia/dual-ABI-Lua gates, unchanged full 5x2x62 primary matrix, mdBook, Knowledge Map,
    governance, whitespace, and canonical local CI through reference CLI 62x2 plus Phase 0. Do not run mutation
    campaigns or change runtime semantics.
  - [x] **LOCKSTEP / CLOSE PARENT** — Update the task/index, roadmap, architecture/live status, changes/development
    notes, mdBook, capability evidence, and bounded memory together; close `.5.1.9` and parent `.5.1` only after
    proof, then activate logical truthiness `.5.2` as the next clean-pivot PNT leaf.
  Verification: **PASS 2026-07-16.** The independent checker reports 8 complete/0 pending and rejects 20 exact
    mutations while verifying 16 authoritative documents and nine forbidden stale-current claims. Backend
    READMEs, mdBook/API/helper/handoff chapters, user guides, capability evidence, roadmap/status, and Knowledge
    Map now teach one contract with copyable native/generated examples for all five backends. Complete Rust,
    Dart, Julia, and dual-ABI Lua gates pass; the strict recurring driver passes Perl 16, Rust 7, Dart 7, Julia 82,
    PUC Lua 119, LuaJIT 119, exact 5x2x1 quiet CLI, generated-source/capability 80/0/0, and exhaustive coverage. The
    unchanged primary matrix passes 5x2x62. Canonical local CI passes reference CLI 62x2, Phase 0 `1..1031`, and
    the registered driver. mdBook, Knowledge Map, governance, and whitespace pass. Runtime semantics did not
    change and no mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.1.9 - close diagnostic-output public no-drift`

- ID: `FUTURE-PARITY-BACKLOG.5.2`
  Status: `done`
  Goal: Define and align one logical-helper truthiness, arity, and lowering contract.
  Children: `.5.2.0`, `.5.2.1`, `.5.2.2`, `.5.2.3`, `.5.2.4`, `.5.2.5`, `.5.2.6`, `.5.2.7`, `.5.2.8`,
    `.5.2.9`
  Dependencies: complete current Lua parity (satisfied by `LUA-BACKEND-PARITY.8.4`; ordered after `.5.1`)
  Acceptance: Use a neutral fixture to lock eager left-to-right `and`/`or`/`not` evaluation, exact zero/one/
    variadic arities, boolean result types, scalar `"0"`, empty aggregate, null, boolean, numeric, and string
    truthiness, side effects, value/receiver composition, and typed failures across Perl, Rust, Dart, Julia, and
    Lua native plus generated/CLI paths where applicable. Repair Perl `return(and(...))` / `return(or(...))`
    keyword-precedence lowering so the designated reference actually executes the authored helper instead of
    returning host `undef`; align Dart's current decisive-operand short circuit and empty `and()` true result with
    the selected eager/empty contract; then align or explicitly migrate the existing backend truthiness
    differences. Finish with shared tests, mdBook/KM truth tables, and capability/no-drift gates before structured-
    format execution.
  Verification: **PASS 2026-07-17.** All eight rollout legs close against one executable contract. Native,
    generated, selected primary, recurring, capability, exhaustive corpus/public, and 20-document public
    projections agree; 13 stale-current claims and 26 deterministic drift mutations are guarded. Complete
    backend gates, full 5x2x63 primary proof, and canonical local CI with the registered all-toolchain leg pass.
  Commit: closed by `FUTURE-PARITY-BACKLOG.5.2.9 - close logical-helper public no-drift`

- ID: `FUTURE-PARITY-BACKLOG.5.2.0`
  Status: `done`
  Goal: Audit and split the five-backend logical-helper contract before behavior code.
  Dependencies: completed diagnostic-output parent `.5.1`
  Acceptance: Use the Knowledge Map and LinkedSpec toolbox before source inference; reproduce exact Perl lowering
    and native execution for `and`/`or`/`not`; inventory Rust, Dart, Julia, and Lua evaluation, zero/one/variadic
    arity, boolean result, condition/helper truthiness, receiver, generated, and primary seams; measure scalar
    `"0"`, empty aggregate, null, boolean, numeric, string, decisive-operand side effects, and wrong-arity behavior;
    then create dependency-correct neutral-contract, backend, generated/CLI, recurring-gate, and public no-drift
    leaves. Change no runtime semantics in this planning slice.
  Checklist:
  - [x] **RETRIEVE / PRIOR ART** — Read the cross-backend truthiness, Julia logical, Lua logical, and Dart helper
    Knowledge Map records plus the toolbox lowering/live/generated probes before re-deriving any mechanism.
  - [x] **PERL REFERENCE PROOF** — Use `call_spec_handler_subst`, `LinkedSpec::Get`, descriptor/source dump, and
    independent emitted-source execution to distinguish parsing, ActionIR ownership, keyword precedence,
    evaluation order, arity, truthiness, and result behavior for direct/nested/receiver logical calls.
  - [x] **FIVE-BACKEND MATRIX** — Measure current native and generated behavior for zero/one/variadic calls,
    decisive-operand side effects, boolean result types, scalar `"0"`, empty array/harray, null, booleans, numbers,
    ordinary strings, receiver continuations, invalid arities, and lazy-control separation on all five backends.
  - [x] **SEAM INVENTORY** — Identify exact frontend/ActionIR/compiler/runtime/truthiness/generated/primary/test/
    capability/public owners; separate helper eagerness from lazy `if`/`while`, and language truthiness from host
    operators so later leaves cannot repair one projection while leaving another divergent.
  - [x] **SAFE SPLIT** — Ratify one neutral contract first, then schedule Perl, Rust, Dart, Julia, Lua, generated/
    primary projection, one omission-checked recurring gate, and public/KM/capability no-drift closeout with exact
    dependencies and acceptance. Record the intended arity/truthiness decision as pending neutral policy, not as
    behavior in this audit.
  - [x] **NO REGRESSION** — Change no parser, compiler, runtime, generated-source, CLI, fixture, capability, or
    corpus behavior/claim; run focused read-only probes plus governance, Knowledge Map, mdBook, whitespace, and
    canonical gates proportionate to a planning-only slice. Do not run mutation campaigns.
  - [x] **LOCKSTEP** — Update task/index, roadmap, architecture/live status, changes/notes, mdBook/KM facts, and
    bounded memory to point only at neutral logical-contract leaf `.5.2.1` after this audit commits cleanly.
  Verification: Exact Perl toolbox/live/descriptor/emitted probes; current native/primary/generated matrix; Perl
    compact lowerers 4 tests; Rust runtime 137 tests; Dart interpreter 60 tests; complete Julia package suite;
    PUC Lua and LuaJIT 177/177; Knowledge Map, memory, task/doctrine, mdBook, and whitespace checks; canonical
    local CI with reference CLI 62x2 and Phase 0 `1..1031`. PASS. No behavior change or mutation campaign.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.0 - split logical helper parity`

- ID: `FUTURE-PARITY-BACKLOG.5.2.1`
  Status: `done`
  Goal: Ratify an executable backend-neutral logical-helper and truthiness contract.
  Dependencies: `.5.2.0`
  Acceptance: Adopt a decision plus machine-readable fixtures/checker for exact `and`/`or`/`not` arities, eager
    once-only left-to-right evaluation, boolean results, scalar/aggregate/null/boolean/number/string truthiness,
    receiver composition, wrong-arity diagnostics, generated propagation, primary projection, and explicit
    separation from lazy controls. Begin with every backend rollout leg pending.
  Checklist:
  - [x] **RETRIEVE / PRECEDENT** — Apply ADR `0011` typed-AST ownership, ADR `0023` user-observable parity, ADR
    `0029` host-coercion prohibition/exact-arity precedent, ADR `0030` explicit arity metadata, and ADR `0042`
    pre-evaluation arity/eager-once fixture structure; keep ADR `0028` text rendering separate from truthiness.
  - [x] **DECIDE / ADR 0043** — Ratify one typed truth table, eager once-only left-to-right helper evaluation,
    valid zero/one/variadic arities, real boolean results, pre-evaluation structured arity failure, receiver
    composition, and explicit separation from lazy controls. Explain why scalar `"0"`, scalar `"false"`, empty
    aggregates, and codeblocks do or do not pass without delegating policy to any host.
  - [x] **NEUTRAL SCHEMA** — Add strict `linkedspec-logical-helper-v1` data covering every value kind, disputed
    rows, ordinary/edge numbers and strings, zero/one/many calls, decisive-operand side effects, receiver results,
    lazy-control contrast, diagnostic fields, generated/primary obligations, and an eight-leg rollout initialized
    at zero complete / eight pending.
  - [x] **INDEPENDENT CHECKER** — Validate exact schema/order/uniqueness, independently evaluate the truth table and
    helper calls, reject unknown/missing/duplicate cases and premature rollout admission, render deterministic
    `.spec`/expected fixtures, and expose a concise report suitable for canonical CI.
  - [x] **FIXTURE PROOF** — Check in deterministic valid-call, side-effect, receiver/lazy-control, and invalid-arity
    fixtures with exact expected values/effects/diagnostics; prove regeneration is byte-identical and the checker
    rejects representative semantic, arity, effect, diagnostic, topology, and premature-admission mutations.
  - [x] **CI REGISTRATION** — Register only the backend-neutral offline checker in canonical local CI. Backend
    consumers remain pending under `.5.2.2-.7`; recurring composed execution remains `.5.2.8` and public admission
    remains `.5.2.9`.
  - [x] **PUBLIC TARGET** — Update the mdBook, roadmap/architecture/live docs, task/index, changes/notes, decision
    index, Knowledge Map, and bounded memory to distinguish adopted target semantics from measured current backend
    behavior. Do not present any pending backend as conforming.
  - [x] **NO REGRESSION** — Change no parser/compiler/runtime/generated/primary/corpus/capability behavior or current
    backend expectations; run the neutral checker/mutations, focused governance/KM/book/whitespace checks, and the
    canonical local gate. Do not run implementation mutation campaigns.
  - [x] **LOCKSTEP** — Close `.5.2.1` only with exact verification/commit evidence and activate Perl typed-AST/
    lowering rollout `.5.2.2` after a clean commit.
  Verification: `python3 tools/check_logical_helper_contract.py` passes 17 truthiness, ten helper, three effect,
    0-complete/8-pending, and 15-mutation proof; shell syntax, Knowledge Map, memory, doctrines, mdBook, and
    whitespace pass. Canonical local CI passes the registered checker, reference CLI 62x2, and Phase 0 `1..1031`
    in 639 seconds. No behavior change or implementation mutation campaign.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.1 - ratify logical helper contract`

- ID: `FUTURE-PARITY-BACKLOG.5.2.2`
  Status: `done`
  Goal: Repair Perl logical lowering and align the neutral reference truthiness/arity contract.
  Dependencies: `.5.2.1`
  Acceptance: Typed ActionIR owns direct, nested, assignment, return, condition, user-function, receiver, live,
    and emitted `and`/`or`/`not` lowering without raw keyword-call precedence, host `&&`/`||` short-circuiting, or
    legacy optional-scope stripping such as `not(false, true)` selecting the second argument. Arguments evaluate
    exactly as the neutral fixture requires, arity rejects at the governed boundary, results are booleans, and
    condition/helper truthiness is one explicit language policy rather than accidental Perl host context.
  Checklist:
  - [x] **RETRIEVE / TOOLBOX FIRST** — Read the logical audit/neutral-contract Knowledge Map cards, ADR `0043`,
    neutral JSON/checker, and existing callable/typed-AST decisions. Re-run `call_spec_handler_subst`, descriptor,
    source-dump, live, and independently emitted probes before inferring ownership from source.
  - [x] **BASELINE / EXACT GAPS** — Add or extend one Perl consumer of the unchanged neutral artifact and lock the
    pre-repair failures separately from already-green unrelated semantics. Cover valid values, decisive-operand
    effects, receiver composition, lazy-control contrast, invalid arity before effects, and codeblock truth at an
    internal typed boundary without activating `.11` literal syntax.
  - [x] **TYPED LOGICAL OWNERSHIP** — Represent `and`/`or`/`not` as canonical typed expression data across direct,
    nested, assignment, return, condition, user-function, block-value, and receiver sites. Remove raw Perl keyword
    call residue, host precedence dependence, and optional-scope reinterpretation from those admitted calls.
  - [x] **ARITY BEFORE EFFECTS** — Enforce one-plus positional `and`/`or` and exact-one positional `not` before
    evaluating any operand. Project exact `helper_arity_mismatch` fields/code through compile/live/emitted paths
    without changing unrelated helper diagnostics.
  - [x] **ONE TYPED TRUTHINESS SEAM** — Implement ADR `0043` null/boolean/finite-number/string/array/harray/
    codeblock truth exactly, including string `"0"`/`"false"`, negative zero, empty aggregates, nonempty-null
    aggregates, and inert codeblocks. Conditions and logical helpers must call the same seam; scalar rendering and
    numeric conversion stay separate.
  - [x] **EAGER VALUES / LAZY CONTROLS** — Evaluate every valid logical operand once left-to-right and return a real
    boolean to assignments, returns, blocks, functions, and compatible receivers. Preserve lazy selected-branch/
    body execution for `if`, `switch`, and `while` while applying the same typed truth to their conditions.
  - [x] **LIVE / EMITTED PARITY** — Prove descriptor reconstruction, direct execution, standalone emitted source,
    generated role(s), and primary projection preserve exact values, effect order, receiver results, diagnostics,
    and condition behavior without a host-operator shortcut.
  - [x] **NO REGRESSION** — Keep neutral rollout at only `perl_native` complete when proof is sufficient; change no
    Rust/Dart/Julia/Lua behavior, generic codeblock syntax, capability census, corpus contract, or unrelated helper
    semantics. Run focused Perl contract/lowering tests, generated-source/capability/coverage checks, memory/KM/
    doctrine/book/whitespace, and canonical local CI. Do not run an implementation mutation campaign.
  - [x] **LOCKSTEP** — Synchronize the neutral rollout/checker, Perl guides, mdBook current matrix, roadmap/live/
    architecture/task/index, changes/notes, Knowledge Map, and bounded memory. Commit `.5.2.2` cleanly before Rust
    `.5.2.3` becomes active.
  Verification: The focused neutral Perl consumer passes all typed truth/helper/effect/receiver/control/arity,
    live, and standalone-emitted cases; direct host-scalar regressions prove empty count and false comparison are
    false while string `"0"` remains true. The canonical hash-tree callback fixture preserves A/B leaves, and the
    Perl primary command returns the exact canonical logical values plus stable invalid-arity process failure.
    Neutral checker passes 1 complete / 7 pending with 15 mutations; focused ActionIR, codeblock, generated-source,
    and diagnostic tests pass; direct Phase 0 passes `1..1031` in 647 seconds. Knowledge Map, governance, mdBook,
    and whitespace pass; canonical local CI passes reference CLI 62x2 and Phase 0 `1..1031` in 635 seconds.
  Commit: `dcc3a71d` (`FUTURE-PARITY-BACKLOG.5.2.2 - repair Perl logical lowering`)

- ID: `FUTURE-PARITY-BACKLOG.5.2.3`
  Status: `done`
  Goal: Align Rust logical helpers and condition truthiness with the neutral contract.
  Dependencies: `.5.2.1`
  Acceptance: Native, serialized, generated-plan, emitted, and direct-value Rust paths enforce exact logical arity,
    eager evaluation, boolean results, and the neutral truth table through one runtime seam without changing lazy
    control selection or unrelated scalar conversion.
  Checklist:
  - [x] **RETRIEVE / BASELINE** — Read ADR `0043`, the logical audit/neutral-contract/Perl-host Knowledge Map
    cards, neutral JSON/checker, and Rust typed runtime/generated owners; run focused current probes before edits.
  - [x] **ONE RUST TRUTH SEAM** — Give every RuntimeValue kind the exact neutral truth table without reusing text
    rendering or numeric parsing; helper and lazy-control conditions consume the same seam.
  - [x] **ARITY BEFORE EFFECTS / EAGER VALUES** — Enforce one-plus `and`/`or` and exact-one `not` before operand
    evaluation, then evaluate valid arguments once left-to-right and return real booleans.
  - [x] **ALL RUST PROJECTIONS** — Lock native compiled, serialized reconstruction, generated-plan, emitted-source,
    direct-value, receiver, and condition behavior plus exact portable diagnostics from the unchanged fixture.
  - [x] **NO REGRESSION / LOCKSTEP** — Promote only `rust_native`, keep later rollout legs pending, run focused and
    complete Rust/contract/corpus/generated/CLI/governance gates, update docs/KM/task/memory, and commit cleanly.
  Verification: Contract-driven truth/value/effect/receiver/control/four-invalid-call proof passes native,
    serialized, direct-value, generated-plan, and an independently compiled standalone-emitted crate. Complete
    Rust core/runtime packages pass: 188 core units, 137 runtime units, 3-case Perl-oracle corpus including all
    105 fixtures, full 105-case generated-source classifier, 197 integrations, and all contract/emitter/
    diagnostic/binding/Unicode/variadic/doc suites. Rust primary passes 62/62 in default and POSIX environments.
    Neutral checker passes 17 truth rows, ten helper cases, three effects, 2 complete / 6 pending, and 15
    mutations; KM/governance/mdBook/whitespace pass. Canonical local CI passes reference CLI 62x2 and Phase 0
    `1..1031` in 649 seconds. No implementation mutation campaign.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.3 - align Rust logical helpers`

- ID: `FUTURE-PARITY-BACKLOG.5.2.4`
  Status: `done`
  Goal: Replace Dart logical short-circuit/empty-call drift with the neutral contract.
  Dependencies: `.5.2.1`
  Acceptance: Dart evaluates every valid logical argument once left-to-right before composition, enforces exact
    arities and boolean results, uses the neutral truth table across helpers and conditions, and preserves native/
    generated/emitted/CLI values plus structured diagnostics.
  Checklist:
  - [x] **RETRIEVE / BASELINE** — Read ADR `0043`, the logical audit/neutral-contract/Rust/Dart Knowledge Map
    cards, unchanged JSON/checker, and Dart interpreter/compiler/generated/diagnostic owners; run focused current
    native/generated/primary probes before editing behavior.
  - [x] **UNCHANGED NEUTRAL CONSUMER** — Add or extend one Dart consumer of the exact neutral truth/value/effect/
    receiver/control/arity fixtures. Cover every Dart-representable typed row and explicitly classify any syntax or
    runtime kind the current Dart model cannot construct.
  - [x] **ONE DART TRUTH SEAM** — Route logical helpers and lazy control conditions through the same explicit typed
    truth function, preserving ADR `0043` numeric-zero, nonempty-string, empty-aggregate, null, and boolean edges
    without borrowing scalar rendering or host truth.
  - [x] **ARITY BEFORE EFFECTS / EAGER VALUES** — Enforce one-plus positional `and`/`or` and exact-one positional
    `not` before any operand evaluation; evaluate every valid operand once left-to-right and return real booleans.
  - [x] **ALL DART PROJECTIONS** — Lock native compiled, normalized/reconstructed, generated-plan/emitted,
    receiver, lazy-control, structured-diagnostic, and primary roles from the unchanged fixture. Preserve existing
    unrelated diagnostic shapes and source metadata.
  - [x] **NO REGRESSION / LOCKSTEP** — Promote only `dart_native`; keep Julia/Lua/generated/gate/public legs
    pending, run focused and complete Dart/corpus/CLI/contract/governance gates, synchronize docs/KM/task/memory,
    and commit cleanly before Julia `.5.2.5` becomes active. Do not run an implementation mutation campaign.
  Verification: Baseline target consumer recorded skipped decisive effects and all four legacy arity failures.
    After repair, the unchanged consumer passes 24/24 across typed truth, native/normalized/generated-plan/primary,
    four structured failures, and a compiled standalone emitted package. Dart format/analyze, all 245 tests,
    primary 62/62 default plus 62/62 POSIX, full corpus 105/105, neutral checker 3/5 with 15 mutations, governance,
    Knowledge Map, mdBook, and whitespace checks pass. Canonical local CI passes reference CLI 62x2, Phase 0
    `1..1031`, and its optional complete Dart gate. No implementation mutation campaign.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.4 - align Dart logical helpers`

- ID: `FUTURE-PARITY-BACKLOG.5.2.5`
  Status: `done`
  Goal: Align Julia logical arity and truthiness with the neutral contract.
  Dependencies: `.5.2.1`
  Acceptance: Preserve Julia's eager once-only composition while normalizing exact arity and the disputed scalar/
    aggregate truthiness rows across native, reconstructed, emitted, generated, CLI, and lazy-control paths.
  Checklist:
  - [x] **RETRIEVE / BASELINE** — Read ADR `0043`, logical neutral/audit/Julia/Dart Knowledge Map cards, unchanged
    JSON/checker, and Julia parser/compiler/runtime/generated/diagnostic owners; run focused native/generated/
    primary probes before editing behavior.
  - [x] **UNCHANGED NEUTRAL CONSUMER** — Add or extend one Julia consumer of the exact neutral truth/value/effect/
    receiver/control/arity fixtures. Cover every Julia-representable typed row and explicitly classify any syntax
    or runtime kind the current model cannot construct.
  - [x] **ONE JULIA TRUTH SEAM** — Route logical helpers and lazy controls through one explicit typed truth function,
    preserving numeric-zero, nonempty-string, empty-aggregate, null, boolean, and inert-codeblock policy without
    host conversion or rendering shortcuts.
  - [x] **ARITY BEFORE EFFECTS / EAGER VALUES** — Enforce one-plus positional `and`/`or` and exact-one positional
    `not` before any operand evaluation; retain valid once-only left-to-right evaluation and real booleans.
  - [x] **ALL JULIA PROJECTIONS** — Lock native compiled, normalized/reconstructed, generated-plan/emitted,
    receiver, lazy-control, structured-diagnostic, and primary roles from the unchanged fixture. Preserve existing
    unrelated diagnostic shapes, trace behavior, and source attribution.
  - [x] **NO REGRESSION / LOCKSTEP** — Promote only `julia_native`; keep Lua/generated/gate/public legs pending,
    run focused and complete Julia/corpus/CLI/contract/governance gates, synchronize docs/KM/task/memory, and commit
    cleanly before Lua `.5.2.6` becomes active. Do not run an implementation mutation campaign.
  Verification: Baseline target consumer passed all typed truth and valid value/effect/control projections while
    empty helpers returned false/false/true and `not_many` executed its forbidden first operand. After repair, the
    unchanged consumer passes 177 assertions across native/normalized/generated-plan/primary and independently
    compiled emitted roles. Full package 1,671, primary process, shared CLI 62x2, corpus 105/105, neutral 4/4 with
    15 mutations, Knowledge Map, mdBook, memory, task metadata, doctrines, and whitespace pass. Canonical local CI
    passes reference CLI 62x2, Phase 0 `1..1031` in 607 seconds, and the optional complete Julia gate including
    177/177 logical assertions, primary process conformance, and corpus 105/105.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.5 - align Julia logical helpers`

- ID: `FUTURE-PARITY-BACKLOG.5.2.6`
  Status: `done`
  Goal: Align Lua logical arity and truthiness with the neutral contract on both ABIs.
  Dependencies: `.5.2.1`
  Acceptance: Preserve eager ordered boolean composition and receiver flow while enforcing the selected arities/
    truth table through native and serialized execution on PUC Lua and LuaJIT; retain existing helper ownership,
    generated routing, and lazy-control separation.
  Checklist:
  - [x] **RETRIEVE / BASELINE** — Read ADR `0043`, the neutral/audit/Lua logical Knowledge Map facts, unchanged
    JSON/checker, TOOLBOX guidance, and exact Lua parser/compiler/runtime/generated/diagnostic owners before
    behavior edits; measure both PUC Lua and LuaJIT through one target-level consumer.
  - [x] **UNCHANGED DUAL-ABI CONSUMER** — Add or extend one exact neutral consumer over every Lua-representable
    truth/value/effect/receiver/control/arity row across native, serialized/reconstructed, generated, and primary
    roles on both ABIs; classify any model-level row Lua cannot construct without expanding syntax scope.
  - [x] **ONE LUA TRUTH SEAM** — Route eager logical helpers and lazy controls through one explicit typed truth
    function, preserving numeric zero, nonempty strings, empty aggregates, null, booleans, and inert codeblocks
    without host Lua truth coercion or rendering shortcuts.
  - [x] **ARITY BEFORE EFFECTS / EAGER VALUES** — Enforce one-plus positional `and`/`or` and exact-one positional
    `not` before any operand evaluation while preserving valid once-only left-to-right evaluation and booleans.
  - [x] **ALL LUA PROJECTIONS / BOTH ABIS** — Lock native compiled, serialized/reconstructed, generated-plan/
    emitted, receiver, lazy-control, structured-diagnostic, primary, PUC Lua, and LuaJIT roles from the unchanged
    fixture without changing unrelated diagnostics, trace, source attribution, or generated routing.
  - [x] **NO REGRESSION / LOCKSTEP** — Promote only `lua_native`; keep generated/gate/public legs pending, run
    focused and complete dual-ABI Lua/corpus/CLI/contract/governance gates, synchronize docs/KM/task/memory, and
    commit cleanly before generated/primary `.5.2.7` becomes active. Do not run an implementation mutation campaign.
  Verification: Baseline: the unchanged 238-assertion consumer passed 51 and failed 187 identically on PUC Lua
    and LuaJIT; valid eager effects and inert codeblock truth already passed, while failures were confined to
    string-zero/empty-aggregate truth, lazy controls, legacy arity, and exact diagnostic projection. After repair,
    the consumer passes 238/238 on each ABI across native/reconstructed/generated-plan/loaded-emitted/primary roles.
    The authoritative Lua gate passes diagnostic 119/119, logical 238/238, full 177/177 per ABI, shared CLI 62x2,
    and corpus 105/105. The neutral checker passes 5 complete / 3 pending with 15 mutations. Canonical local CI
    passes governance/contracts, reference CLI 62x2, and Phase 0 `1..1031` in 609 seconds. Knowledge Map, memory,
    task metadata, doctrines, mdBook, and whitespace pass; no implementation mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.6 - align Lua logical helpers`

- ID: `FUTURE-PARITY-BACKLOG.5.2.7`
  Status: `done`
  Goal: Propagate the aligned logical contract through generated entrypoints and primary projection.
  Dependencies: `.5.2.2`, `.5.2.3`, `.5.2.4`, `.5.2.5`, `.5.2.6`
  Acceptance: Every available generated direct/traced role preserves exact logical values/effects/diagnostics and
    source metadata; one shared primary case proves the same canonical result under all five commands and both
    option environments without backend-specific flags or semantics.
  Checklist:
  - [x] **RETRIEVE / BASELINE** — Read ADR `0043`, the logical neutral/audit/backend Knowledge Map facts, unchanged
    JSON/checker, TOOLBOX guidance, and the existing diagnostic-output generated/primary precedent before changing
    any projection. Run the current generated consumers and primary matrix to measure the exact residual.
  - [x] **GENERATED ROLE INVENTORY** — Enumerate every supported direct/traced/plan/reconstructed/emitted generated
    role on Perl, Rust, Dart, Julia, and Lua; identify exact contract fixture, diagnostic, source-attribution, and
    caller-owned isolation seams without inventing a role a backend does not expose.
  - [x] **UNCHANGED CROSS-BACKEND PROJECTION** — Drive the neutral values/effects/receiver/arity fixture through
    every available generated role and prove booleans, eager order, exact diagnostic tokens/fields, metadata, and
    ordinary result/trace identity. Repair only projection drift found by that unchanged proof.
  - [x] **SHARED PRIMARY CASE** — Add one backend-neutral logical case to the shared primary manifest with exact
    canonical JSON and invalid-call projection where supported; run all five commands in default and POSIX option
    environments without backend flags or per-command expectations.
  - [x] **LEDGER / NO REGRESSION** — Promote only `generated_and_primary_cli`; keep recurring/public legs pending,
    preserve capability 80/0/0, existing corpus/generated-source contracts, and unrelated diagnostics/traces.
  - [x] **LOCKSTEP / COMMIT** — Run focused consumers, complete affected backend gates, shared primary matrix,
    neutral checker, governance/KM/mdBook/whitespace, and canonical local CI; synchronize all durable layers and
    commit cleanly before recurring gate `.5.2.8`. Do not run an implementation mutation campaign.
  Verification: **PASS 2026-07-17.** Expanded consumers pass Perl 8 top-level subtests, Rust 4 integration tests,
    Dart 24 tests, Julia 232 assertions, and PUC Lua/LuaJIT 359 assertions across every available generated role.
    Complete Rust, Dart, Julia, and dual-ABI Lua gates pass, as do the exact five-backend/default-POSIX 63-case
    matrix, logical checker at 6 complete / 2 pending with 15 rejected mutations, diagnostic checker at 8/0 with
    20 mutations, generated-source/capability 80/0/0, and exhaustive 246-name/105-corpus-plus-one/122-public-
    contract ledgers. Knowledge Map, memory, task metadata, doctrines, mdBook, and whitespace pass. Canonical local
    CI passes reference CLI 63x2 and Phase 0 `1..1031` in 618 seconds. No runtime implementation changed and no
    implementation mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.7 - propagate logical generated projection`

- ID: `FUTURE-PARITY-BACKLOG.5.2.8`
  Status: `done`
  Goal: Add one recurring omission-checked five-backend logical-helper conformance gate.
  Dependencies: `.5.2.7`
  Acceptance: One strict driver composes the neutral checker, all native/generated consumers, exact primary case,
    capability/generated-source/corpus ledgers, and canonical local-CI registration; deterministic mutations reject
    semantic, backend, generated-role, CLI, support-ledger, and registration omissions.
  Checklist:
  - [x] **RETRIEVE / INVENTORY** — Read the logical neutral/audit/generated-primary Knowledge Map facts and the
    diagnostic-output recurring-gate precedent; enumerate the authoritative checker, six focused consumers, exact
    selected primary case, support ledgers, shell/toolchain requirements, and canonical local-CI registration seam.
  - [x] **LOCK GATE TOPOLOGY** — Extend the logical contract and offline checker with one exact recurring-gate
    topology: driver, ordered Perl/Rust/Dart/Julia/PUC-Lua/LuaJIT consumers, required native+generated roles,
    selected CLI case, support checks, and CI registration. Add deterministic mutations for every omission class.
  - [x] **SYMMETRIC DRIVER** — Add one strict fail-fast portable shell driver that requires every host toolchain,
    runs the neutral checker and each focused native/generated consumer, and builds disposable Lua adapters for
    PUC Lua and LuaJIT without weakening backend-owned value/effect/diagnostic/source assertions.
  - [x] **EXACT PRIMARY PROJECTION** — Run only `success_logical_helpers_eager` through the existing five-command
    matrix under default and POSIX environments, retaining unchanged full-matrix behavior and exact bytes/status.
  - [x] **SUPPORT-LEDGER REGRESSION** — Compose generated-source, capability-census, and exhaustive language-
    coverage checkers so the 80/0/0 census and generated/corpus/public proof cannot drift independently.
  - [x] **CANONICAL REGISTRATION** — Make the driver a tracked/audited/syntax-checked local-CI input and register
    explicit opt-in all-toolchain execution through one exact environment switch; prove direct and registered paths.
  - [x] **NO REGRESSION** — Prove shell/Python syntax, offline mutation rejection, all six consumers, selected
    5x2x1 primary projection, support ledgers, unchanged full 5x2x63 matrix, governance/KM/mdBook/whitespace, and
    canonical local CI. Do not run an implementation mutation campaign.
  - [x] **LOCKSTEP / COMMIT** — Promote only `recurring_five_backend_gate`, leave public no-drift `.5.2.9` pending,
    synchronize every durable layer, and commit cleanly before public closeout activates.
  Verification: **PASS 2026-07-17.** Direct and canonical registered drivers pass the 7/1 neutral checker with 22
    rejected semantic/topology mutations; focused Perl 8, Rust 4, Dart 24, Julia 232, and PUC Lua/LuaJIT 359
    consumers; exact selected primary 5x2x1; generated-source/capability 80/0/0; and exhaustive
    246-name/105-corpus-plus-one/122-public-contract ledgers. The unchanged full primary matrix passes 5x2x63.
    Shell/Python syntax, Knowledge Map, memory, task/doctrine, mdBook, and whitespace checks pass. Canonical local
    CI passes reference CLI 63x2, Phase 0 `1..1031` in 623 seconds, and the registered all-toolchain logical leg.
    Only `recurring_five_backend_gate` advances; no runtime implementation or implementation mutation campaign.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.8 - add recurring logical-helper gate`

- ID: `FUTURE-PARITY-BACKLOG.5.2.9`
  Status: `done`
  Goal: Close logical-helper public documentation, Knowledge Map, capability, and no-drift state.
  Dependencies: `.5.2.8`
  Acceptance: Helper catalogs, truth tables, value-flow/action guides, backend READMEs/handoff, roadmap/status,
    capability evidence, task/index/live docs, and Knowledge Map teach one current native/generated contract with
    extensive examples and no historical caveat presented as current behavior. Complete backend and canonical
    gates pass; parent `.5.2` closes and the next roadmap-aligned PNT candidate activates.
  Checklist:
  - [x] **RETRIEVE / PUBLIC INVENTORY** — Read the recurring logical facts and diagnostic public-no-drift
    precedent; enumerate every authoritative logical helper catalog, truth table, value/action guide, backend
    README, handoff/status/roadmap, capability/CLI, task/live, and Knowledge Map surface plus exact stale claims.
  - [x] **LOCK PUBLIC TOPOLOGY** — Extend the neutral contract/checker with an exact ordered public-document marker
    inventory, forbidden-current-claim list, and all-complete rollout; add deterministic public-document, marker,
    stale-claim, and final-admission mutations.
  - [x] **ALIGN USER GUIDANCE** — Make helper catalogs, condition/value-flow guides, emitted-Perl reference, and
    mdBook truth/action sections teach eager once-only values, pre-effect arity, typed truth, lazy controls, and
    receiver composition with copyable examples.
  - [x] **ALIGN BACKEND / GENERATED GUIDANCE** — Give Perl/Rust/Dart/Julia/Lua readers exact native and generated
    entrypoints, result-shape/source distinctions, primary case, recurring command, and local-CI switch without
    presenting implementation details as portable semantics.
  - [x] **ALIGN STATUS / CAPABILITY / CLI** — Close every current roadmap/status/capability/CLI/task/live/KM claim
    at 8/0, retain historical evidence as history, and close parent `.5.2` without activating explicit codeblock
    literals, parenthesis-free conditions, or cursor implementation.
  - [x] **NO-DRIFT / MUTATION PROOF** — Prove the public checker rejects omitted documents/markers/stale claims/
    final admission; run the recurring driver, complete backend gates, full 5x2x63, support ledgers, governance,
    Knowledge Map, mdBook, whitespace, and canonical local CI. Do not run an implementation mutation campaign.
  - [x] **LOCKSTEP / COMMIT** — Synchronize all durable layers, promote only `public_no_drift`, close parent `.5.2`,
    select the next roadmap-aligned frontier, and commit cleanly before pivoting.
  Verification: **PASS 2026-07-17.** The logical checker passes 8/0 over 20 ordered public documents, 13
    forbidden current claims, and 26 rejected semantic/topology/public mutations. Complete Rust, Dart, Julia,
    and dual-ABI Lua gates pass; direct and registered recurring proof passes Perl 8, Rust 4, Dart 24, Julia 232,
    PUC Lua 359, and LuaJIT 359 assertions plus selected primary 5x2x1. The unchanged full primary matrix passes
    5x2x63. Generated-source and capability ledgers pass at 80/0/0; exhaustive coverage passes at 246 current
    names, 105 corpus fixtures plus one exact named-mark fixture, and 122 public contracts. Diagnostic 8/0 plus
    20 mutations, Python/shell syntax, Knowledge Map, memory, task/doctrine, mdBook, and whitespace checks pass.
    Canonical local CI passes reference CLI 63x2, Phase 0 `1..1031` in 640 seconds, and the registered logical
    all-toolchain leg. No runtime implementation changed and no implementation mutation campaign ran.
  Commit: `FUTURE-PARITY-BACKLOG.5.2.9 - close logical-helper public no-drift`

- ID: `FUTURE-PARITY-BACKLOG.5.3`
  Status: `active`
  Goal: Implement the already documented standalone bare-array writeback for split_each, filter_match and uniq on Rust, Dart and Julia, preserving pure value/receiver forms.
  Children: `.5.3.1`, `.5.3.2`, `.5.3.3`, `.5.3.4`
  Authority: Helper Catalog No Mutation Guarantee explicitly defines standalone transform writeback and names the three backend omissions; the parent5 and existing runtime Knowledge cards own the defect. This is alignment to an existing contract, not a new helper or type.
  Schedule: Selected after clean TYPE-REFERENCE-BOOK.1.2.1.1 under director feature-first steering. Full type/helper inventory remains open; implement this known bounded gap before continuing it.
  Acceptance: Each backend enrolls the three statement forms with correct argument/target handling, copied result/rebinding, target errors and operand effects. Pure helper/receiver calls stay nonmutating. Compile/run a small focused check and commit per backend; broad recurrence/admission follows feature coverage.
  Claim verification: none: Parent scheduling only; no complete backend/helper admission.

- ID: `FUTURE-PARITY-BACKLOG.5.3.1`
  Status: `done`
  Activation commit: `15cdc6997a100d7f8ee89780dbac47c340eb3747`
  Goal: Add Rust standalone split_each/filter_match/uniq bare-array writeback using existing pure operation behavior.
  Dependencies: `TYPE-REFERENCE-BOOK.1.2.1.1`
  Owned paths: rust/linkedspec-runtime/src/engine.rs and a focused integration test; existing array-helper fact/book; FUTURE-PARITY-BACKLOG mutable part/root/index, TYPE cross-reference and normal continuity.
  Verification tier: `focused`
  Focused checks: Locked/offline compilation and one small Rust native/reconstructed or emitted regression covering the three statements and pure/guard controls; book and fast continuity checks. Broad verification is deferred.
  Canonical trigger: None for alignment with existing statement contract in this director-authorized implementation phase; broad admission is separately scheduled.
  Claim verification: none: Deterministic implementation and focused regression, no quantified corpus/exhaustive/portable admission measurement.
  Reproduce/impact: Engine::execute_array_string_transform_statement currently accepts only trim_each/filter_nonempty/lowercase_each/uppercase_each. The three omitted calls fall through to pure evaluation and their result is discarded, leaving the bare target unchanged.
  Acceptance: Preserve result element kinds, left-to-right operands and typed target guards; initialize an absent valid target consistently and reject wrong kinds. Stored results/receiver chains must remain pure, and later effects must not mutate retained snapshots.

  Completion: The Rust statement dispatcher enrolls split_each/filter_match with two positional arguments and uniq with one. Existing target-kind validation/snapshot precedes remaining operand evaluation; call_helper supplies unchanged pure operation behavior, then the named array is replaced. Stored/receiver forms remain pure.
  Focused command: `bash tools/run_cargo_local.sh test --manifest-path rust/Cargo.toml --locked --offline -p linkedspec-runtime --test array_transform_writeback` compiles and passes native/restored/generated-plan values plus wrong-kind controls. Rustfmt and book/fast continuity checks pass; broad suites remain deferred.
  Acceptance Checklist
  - [x] **REPRODUCE / ISSUE** — Targeted Rust Engine execution leaves bare arrays unchanged and accepts a scalar target; corrected focused regression is RED before the runtime repair.
  - [x] **ROOT CAUSE (WHY + WHERE)** — Engine::execute_array_string_transform_statement omits these three names, so statement evaluation falls through to pure helpers and discards the result.
  - [x] **FIX** — Enroll correct shapes and reuse existing target validation, call_helper evaluation and array replacement.
  - [x] **ADDRESSED (verified)** — cargo test --test array_transform_writeback compiles and passes for native/restored/generated-plan execution.
  - [x] **NO REGRESSION** — Quick stored/receiver purity, snapshots, typed elements, absent/wrong-kind targets and once-only operands pass. Full suites remain deferred by director instruction.
  - [x] **LOCKSTEP** — Book, canonical array fact/map, indexed task parts and live handoff agree; Dart5.3.2 is next and complete inventory/API admission remains open.
  Harness note: Initial test compilation omitted the generated runner's contract argument; corrected before runtime RED, with no product-defect credit for that setup error.
  Commit: `FUTURE-PARITY-BACKLOG.5.3.1 - rebind Rust standalone array transforms`.

- ID: `FUTURE-PARITY-BACKLOG.5.3.2`
  Status: `done`
  Activation commit: `a0dde7bb477babfe0af52ee84f259eac21c4a2f4`
  Goal: Add the same already documented standalone transform writeback on Dart; preserve pure forms and typed target/effect rules.
  Dependencies: `FUTURE-PARITY-BACKLOG.5.3.1`
  Owned paths: dart/lib/src/runtime/interpreter.dart; dart/test/array_transform_writeback_test.dart; existing Dart array fact/book; indexed task part/root and normal continuity.
  Verification tier: `focused`
  Focused checks: Changed-source Dart analysis/compilation and one small native/restored/generated-plan regression, plus book and fast continuity checks. No full package suite.
  Canonical trigger: None for existing statement-contract alignment in this director-authorized implementation phase; broad5.3.4 follows feature coverage.
  Claim verification: none: Deterministic implementation and small regression; no quantified corpus/exhaustive/portable admission measurement.
  Reproduce/impact: _executeArrayStringTransformStatement already recognizes the three arities and receiver mutation attempts, but an allowlist returns false before dispatch/rebinding for split_each/filter_match/uniq. Their pure results are discarded by statement execution.
  Acceptance: Reuse pure array-helper evaluation, validate target kind before remaining operands, then replace the array. Preserve type/copy/once/purity and absent/wrong-kind boundaries with a small targeted check.

  Completion: Remove the explicit three-helper exclusion and validate the bare array kind before evaluating pattern/delimiter expressions. Existing pure array-helper evaluation and replacement perform writeback; value/receiver forms are unchanged.
  Focused commands: `cd dart && bash ../tools/run_dart_project_data.sh test test/array_transform_writeback_test.dart` and the same wrapper `analyze --fatal-infos --fatal-warnings lib/src/runtime/interpreter.dart test/array_transform_writeback_test.dart` pass. Native/restored/generated-plan values and wrong-kind controls pass; format/book/fast continuity checks pass. No full package suite.
  Acceptance Checklist
  - [x] **REPRODUCE / ISSUE** — Targeted LinkedSpecRuntimeEngine execution retains original arrays and accepts a scalar target; the focused regression is RED before repair.
  - [x] **ROOT CAUSE (WHY + WHERE)** — interpreter.dart::_executeArrayStringTransformStatement recognizes arity/receiver attempts but explicitly returns false for the three transforms, discarding their pure result.
  - [x] **FIX** — Remove that exclusion, prevalidate the target and reuse existing array-helper evaluation/replacement.
  - [x] **ADDRESSED (verified)** — Focused Dart native/restored/generated-plan regression and two-file analysis PASS.
  - [x] **NO REGRESSION** — Quick pure/receiver, snapshot/type, absent/wrong-kind and once-only operand controls pass. Full suites remain deferred by director instruction.
  - [x] **LOCKSTEP** — Book, Dart fact/map and indexed ownership/live handoff agree; Julia5.3.3 is next and broad5.3.4 remains deferred.
  Owned documentation drift fixed: The current Dart array card still used retired split(array(target),source,delimiter); replace it with the uniform-binding bare target spelling. No selector re-admission.
  Commit: `FUTURE-PARITY-BACKLOG.5.3.2 - rebind Dart standalone array transforms`.

- ID: `FUTURE-PARITY-BACKLOG.5.3.3`
  Status: `done`
  Activation commit: `27017fddcfa1580efe3fe8fd08369f242736caf9`
  Goal: Add the same already documented standalone transform writeback on Julia; preserve pure forms and typed target/effect rules.
  Dependencies: `FUTURE-PARITY-BACKLOG.5.3.2`
  Owned paths: julia/src/runtime/Interpreter.jl; julia/test/array_transform_writeback_test.jl and runtests registration; existing Julia array fact/book; indexed task part/root and normal continuity.
  Verification tier: `focused`
  Focused checks: Julia package loading/compilation and one small native/generated-plan/fresh-emitted regression, plus book and fast continuity checks. No full package suite.
  Canonical trigger: None for existing statement-contract alignment in this director-authorized implementation phase; broad5.3.4 follows feature coverage.
  Claim verification: none: Deterministic implementation and small regression; no quantified corpus/exhaustive/portable admission measurement.
  Reproduce/impact: _execute_runtime_array_transform_statement! recognizes the three arities and receiver mutation attempts, then an explicit allowlist returns false for split_each/filter_match/uniq. Their pure statement result is discarded.
  Acceptance: Reuse existing pure array-helper behavior with left-to-right copied operands and target-kind validation before extra effects; record/rebind the named array. Preserve pure/receiver, element/copy and absent/wrong-kind boundaries.

  Completion: Remove the three-helper exclusion, validate the target kind before operands, copy all arguments left-to-right and reuse _call_runtime_array_helper before the existing local-binding record/store. Pure/receiver forms stay unchanged.
  Focused command: `bash tools/run_julia_project_data.sh --project=julia --startup-file=no --history-file=no -e 'using LinkedSpecJulia, JSON3, Test; include("julia/test/array_transform_writeback_test.jl")'` loads/compiles the package and passes native/generated-plan/fresh-emitted values plus wrong-kind controls after actual runtime RED. Book and fast continuity checks pass; no full package suite.
  Acceptance Checklist
  - [x] **REPRODUCE / ISSUE** — Targeted runtime_execute and fresh generated execution retain original arrays and accept a scalar target; the small regression is RED before repair.
  - [x] **ROOT CAUSE (WHY + WHERE)** — Interpreter.jl::_execute_runtime_array_transform_statement! recognizes arities/receiver attempts but explicitly excludes these transforms before writeback.
  - [x] **FIX** — Remove the exclusion, validate before extra operands, evaluate/copy all args and reuse pure helper dispatch plus local-binding/store machinery.
  - [x] **ADDRESSED (verified)** — Targeted Julia package load/compilation and native/generated-plan/fresh-emitted checks PASS.
  - [x] **NO REGRESSION** — Quick pure/receiver, snapshot/type, absent/wrong-kind and once-only operand controls pass. Full suites remain deferred by director instruction.
  - [x] **LOCKSTEP** — Book, Julia fact/map and indexed tasks/live handoff agree. All three implementations are present; broad5.3.4 is deferred while feature/helper inventory continues.
  Commit: `FUTURE-PARITY-BACKLOG.5.3.3 - rebind Julia standalone array transforms`.

- ID: `FUTURE-PARITY-BACKLOG.5.3.4`
  Status: `pending`
  Goal: Broadly verify/reconcile statement writeback across the existing backends and retire the documented omission after feature coverage.
  Dependencies: `FUTURE-PARITY-BACKLOG.5.3.3`
  Schedule: Deferred broad validation; not a prerequisite for the next feature under director instruction.
  Planned tier: Determine at activation; portable admission requires canonical proof.
  Claim verification: none: Unactivated broad verification; no admission claim.

- ID: `FUTURE-PARITY-BACKLOG.5.4`
  Status: `active` / P1 pure function pipeline defect intake
  Goal: Prevent ordinary Perl value-position array transforms from rebinding their named source while preserving explicit standalone statement writeback.
  Children: `.5.4.1`, `.5.4.2`, `.5.4.3`, `.5.4.4`
  Intake owner: `SESSION-STARTUP-READING.87.1`; observed while checking the existing book nested-function recipe, not inferred solely from a grep.
  Schedule: Immediate next feature after87.1 is committed clean; helper inventory remains open. This is a documented existing purity contract, not a new helper/type.
  Claim verification: none: Qualitative defect intake and explicit source/value controls, no aggregate completeness/parity measurement.

- ID: `FUTURE-PARITY-BACKLOG.5.4.1`
  Status: `done`
  Goal: Route ordinary Perl value-position split_each/trim_each/filter_nonempty/lowercase_each/uppercase_each/uniq through pure array values; keep standalone mutation separate.
  Dependencies: `SESSION-STARTUP-READING.87.1`
  Reproduce: Top:: I { fields=["a","b"]; out=uniq(uppercase_each(fields)); return([out,fields]) } returns [["A","B"],["A","B"]] with no last_error. Expected [["A","B"],["a","b"]]. Receiver control fields.uppercase_each().uniq() produces that expected result. Adding outer filter_match(...,/^A/) returns [["A"],["A","B"]], confirming that the nested helper route owns the mutation.
  Root cause: MethodLowering's public value pipeline path chooses legacy array_pipeline mutation and emits fields=BindingRuntime::array_transform(...) for the inner calls; private __array_value_* receiver lowering produces pure snapshots. Existing declarations include the pure helper contracts.
  Impact: Silent source rebinding breaks value-expression composition, stored snapshots and the book's nonmutation guarantee. P1; fix next rather than leave an unscheduled complaint.
  Activation commit: `1088e94261ae50058563ce95cf109a5095888c3a`
  Owned paths: perl/LinkedSpec/ActionIR/MethodLowering.pm; t/array_pipeline_value_contract.t and callable-suite registration; existing action-regex/purity fact/map and current book reference; indexed task/root and normal continuity.
  Verification tier: `focused`
  Focused checks: Perl module/test compilation and small native/fresh pipeline value/statement/receiver regression plus the direct-dependent filter test; book and fast continuity/history checks only.
  Canonical trigger: None for this bounded existing-purity-contract repair under director phase policy; broad5.4.2 stays deferred.
  Planned checks: One small native/fresh regression contrasting value/nested/receiver/statement forms, named/shape/computed/function sources, snapshots and once-only operand effects; module/test compilation and book/fast continuity checks. No full package suite under director cadence.
  Acceptance: Reuse pure implementation without changing explicit standalone writeback, typed values or current quoted/literal pattern policy. Preserve args/order/shape guards and isolate any additional policy question rather than silently expand scope.
  Claim verification: none: Deterministic purity implementation and focused regressions; no quantified corpus/exhaustive/portable admission measurement.

  Additional owned P1 kind-loss subtask (October26; blocks this leaf): Numeric item2 returned by uniq, filter_match or filter_nonempty becomes a string-kind selector. Reproduce typed=[2,"2","x"]; result=uniq(typed); index=first(result); indexed=["zero","one","two"]; indexed[index]="selected". Get reports nested_write_kind_conflict expected harray/found array; filter_match(typed,/^2$/) and filter_nonempty([2,"",undef]) reproduce it. Plain first(typed) succeeds with numeric index2, isolating predicate processing.
  Mechanism/impact: The shared private pure predicates stringify their aliased $_ element (uniqueness key interpolation, regex matching, length), changing public scalar validity/kind before retaining the original item. This breaks array -> selected numeric value -> typed array write. The canonical literal-kind card establishes that BindingRuntime intentionally uses public SV validity. Preserve items by comparing copied scalar operands; no classifier relaxation or new selector policy. Complete this blocking kind repair inside the same value-pipeline slice before landing.
  Function-parameter context: Exact captured generated source shows clean(values)'s nested trim_each argument serialized as $values, then left as trim_each($values) by the legacy array-source recognizer. A direct standalone trim_each(mut) control still lowers/mutates correctly. Resolve only metadata-known function scalar slots back to their DSL binding when reading a pure array source; preserve source AST/readiness and unsupported raw-host distinctions.
  Completion (October26): Public pipeline value calls normalize to existing private pure operations. Shared source lowering reads typed bare values and metadata-known emitted function slots, with array snapshots. Standalone statement dispatch remains separate. Filtering/deduplication predicates compare scalar copies so selected numbers retain public numeric validity; the selector classifier is unchanged.
  Focused commands: `bash tools/project_data_run.sh env PERL5LIB= prove -Iperl t/array_pipeline_value_contract.t` and the same wrapper for `t/filter_match_value_contract.t` both PASS on final production. Module/new-test/registration syntax and book/fast continuity checks pass; no full suite or matrix.
  Acceptance Checklist
  - [x] **REPRODUCE / ISSUE** — LinkedSpec::Get/call_spec_handler_subst show nested functions rebinding fields; receiver controls stay pure. The new focused regression is RED before repair; separate typed selector controls reject predicate-retained numbers before the copy fix.
  - [x] **ROOT CAUSE (WHY + WHERE)** — MethodLowering routes public value helpers into mutable array_pipeline; private predicates stringify aliased elements, and nested function serialization supplies known Perl scalar slots that legacy source inference misses. Exact generated source identifies trim_each($values) in clean.
  - [x] **FIX** — Normalize value helpers to pure operations, snapshot typed/scoped sources and compare copied scalar operands; preserve standalone mutation and original source AST/readiness rules.
  - [x] **ADDRESSED (verified)** — Focused native/fresh pipeline regression and direct-dependent filter regression PASS; three public numeric selector controls pass after original typed RED.
  - [x] **NO REGRESSION** — Quick nested/function/receiver/statement, named/shape/computed sources, snapshots, source effects and numeric/string selection controls pass. Broad5.4.2 remains deferred under director instruction.
  - [x] **LOCKSTEP** — Book examples/current semantics, canonical fact/map, indexed task parts and live handoff agree. Tool capture example defect5.4.3 is owned/deferred; helper inventory selects further features.
  Commit: `FUTURE-PARITY-BACKLOG.5.4.1 - preserve Perl pipeline values and element kinds`.

- ID: `FUTURE-PARITY-BACKLOG.5.4.2`
  Status: `pending`
  Goal: Broader pipeline-purity recurrence and public no-drift after feature coverage.
  Dependencies: `FUTURE-PARITY-BACKLOG.5.4.1`
  Schedule: Deferred broad verification, not a blocker for the next implementation feature.
  Planned tier: Determine at activation from admission scope.
  Claim verification: none: No admission measurement yet.

- ID: `FUTURE-PARITY-BACKLOG.5.4.3`
  Status: `pending` / P3 tooling documentation defect
  Goal: Correct TOOLBOX.md section2.2's generated-source capture example.
  Reproduce/impact: The documented Get(dump_parser_source=>1,runtime_ctx_ref=>ctx) example dereferences ctx.parser_source_chunks_ref as a scalar; current Get prints source to stdout and does not populate that caller field as shown. The example produces no usable captured scalar and can flood diagnostic output. Public generated_source_contract.t uses the working generate_only/dump_parser_source/parser_source_ref scalar combination.
  Repair: Use explicit parser_source_ref scalar capture and print that scalar; check the exact example against the public API. RuntimeContext joins its internal array of chunks before flushing the supplied scalar; no implementation change is required.
  Schedule: Documentation maintenance after feature coverage; current5.4.1 debugging is unblocked by explicit scalar capture. Other repositories remain read-only.
  Planned tier: `focused`; one small public capture example and syntax/book/continuity checks as applicable.
  Claim verification: none: Qualitative executable-doc defect intake; no coverage measurement.

- ID: `FUTURE-PARITY-BACKLOG.5.4.4`
  Status: `done` / P1 retained numeric-kind implementation
  Activation commit: `4aa0f077d12fe9bf0aa3cea10bd04d1aab54b499`
  Owned paths: perl/LinkedSpec/BindingRuntime.pm; existing small pipeline regression; current array book/fact/map; indexed/task/live continuity.
  Verification tier: `focused`
  Focused checks: BindingRuntime/test syntax and one small native/fresh pipeline regression extended with standalone retained numeric selectors and null/string controls; book and fast continuity/history checks only.
  Canonical trigger: None for bounded existing retained-value kind repair under director feature policy; broad5.4.2 stays deferred.
  Reproduce: Public Get for items=[2,"2","x"]; uniq(items); index=first(items); indexed=["zero","one","two"]; indexed[index]="selected" reports nested_write_kind_conflict expected harray/found array. Separate filter_match(items,/^2$/) and filter_nonempty([2,"",undef]) statements reproduce the same typed failure; pure controls are already GREEN from5.4.1.
  Root cause: BindingRuntime::array_transform stringifies aliased retained values in the uniqueness key, regex match and length predicates. The resulting public string-validity flag changes selector kind. Preserve operands by comparing scalar copies; do not relax typed selector classification.
  Acceptance: Preserve original numeric/string/null entries and stable dedup/filter behavior, binding writeback, retained snapshots and selected numeric use through later typed writes.
  Goal: Preserve numeric item kinds in explicit standalone uniq/filter_match/filter_nonempty writeback.
  Intake: BindingRuntime::array_transform still compares aliased retained values with interpolation, regex matching and length; the same pure-value mechanism was reproduced/fixed in5.4.1. Confirm standalone behavior with a tiny public selector/write probe, then repair copied predicate operands if reproduced.
  Schedule: Next bounded feature after5.5.2; independent of deferred broad5.4.2. Own this causal recurrence without a full matrix.
  Claim verification: none: Deterministic retained-kind implementation with focused regression; no quantified corpus/exhaustive/portable admission measurement.

  Completion: Copy each scalar predicate operand before length, regex matching or uniqueness-key interpolation and retain original entries in the result. No selector/classifier, dedup-key or target-mutation policy changes.
  Focused result: BindingRuntime/test syntax and t/array_pipeline_value_contract.t PASS on final production for native/fresh execution after the same regression fails with typed selector errors before repair. Book/fast continuity/history checks pass; no full suite.
  Acceptance Checklist
  - [x] **REPRODUCE / ISSUE** — Separate public Get probes for each statement helper report nested_write_kind_conflict on the selected numeric index; the added small native/fresh regression is RED before repair.
  - [x] **ROOT CAUSE (WHY + WHERE)** — BindingRuntime::array_transform stringifies retained aliased scalars while checking uniqueness, regex matching or nonempty length, changing public value validity.
  - [x] **FIX** — Compare copied scalar operands and retain the original entries, preserving the existing uniqueness key and filter predicates.
  - [x] **ADDRESSED (verified)** — Changed-module/test syntax and targeted native/fresh pipeline regression PASS.
  - [x] **NO REGRESSION** — Selected numeric values write array index2; numeric/string dedup retains numeric2, null differs from empty text, nonempty retains string0, and saved inputs/pure/dynamic/statement controls pass. Broad suites stay deferred.
  - [x] **LOCKSTEP** — Helper examples/current kind guarantee, canonical fact/map, indexed ownership and live handoff agree. Resume helper inventory1.2; no complete API admission.
  Probe note: The initial JSON diagnostic tried serializing the nested blessed error; rerun with string-safe diagnostic fields. Actual public error traces identify the same typed failure for all three helpers; no defect credit for the diagnostic serializer setup error.
  Commit: `FUTURE-PARITY-BACKLOG.5.4.4 - preserve standalone filter element kinds`.

- ID: `FUTURE-PARITY-BACKLOG.5.5`
  Status: `active` / implementations targeted-checked; broader recurrence remains with5.4.2
  Goal: Honor the existing split_each regex-or-scalar delimiter argument when the scalar comes from a variable or computed expression.
  Children: `.5.5.1`, `.5.5.2`
  Intake: Public Get returns unchanged ["a:b","c:d"] for delimiter=":"; split_each(items,delimiter), and computed delimiter effects remain0. Literal ":" and pure split("a:b",delimiter) controls succeed. Silent wrong output and skipped operand effects break composition; own and fix now under feature-first cadence.
  Claim verification: none: Qualitative existing-contract defect, no exhaustive admission measurement.

- ID: `FUTURE-PARITY-BACKLOG.5.5.1`
  Status: `done`
  Activation commit: `a1c6202c364dd12b7e2923a6a49b02959469d512`
  Goal: Evaluate dynamic scalar delimiters once in ordinary Perl split_each values and receiver chains.
  Owned paths: perl/LinkedSpec/ActionIR/MethodLowering.pm; small pipeline regression and registration; current helper book/fact/map; indexed task parts/root and live continuity.
  Verification tier: `focused`
  Focused checks: Module/test syntax and one small native/fresh delimiter regression with source order, effects, parameters, empty input and literal/regex controls; book and fast continuity/history checks only.
  Canonical trigger: None for bounded existing scalar-delimiter alignment under director phase policy; broad verification follows feature coverage.
  Claim verification: none: Deterministic implementation with targeted regression, no quantified corpus/exhaustive/portable admission measurement.
  Root cause: MethodLowering's static normalizer quotemetas every non-slash source after strip_literal_delimiters; that helper returns unquoted expressions unchanged, so variable/code source becomes regex text and never evaluates.
  Acceptance: Snapshot source before delimiter evaluation; evaluate dynamic strings once even for an empty source, quote runtime metacharacters literally, preserve existing static literal/regex flags, trailing-field and standalone policies. No first-class regex type or deferred callable admission.

  Completion: Distinguish authored quoted/regex operands from dynamic scalar expressions. Lower and evaluate the dynamic value once after the source snapshot, then quote runtime text inside each split. Preserve the existing literal path, flags and trailing-field behavior.
  Focused result: Module syntax and t/array_pipeline_value_contract.t PASS on final production for native/fresh execution after the same targeted vector failed before repair. Book build and fast continuity/history checks pass; no full suites.
  Acceptance Checklist
  - [x] **REPRODUCE / ISSUE** — Public variable/computed delimiter probes return unchanged arrays and skip effects; ordinary split control succeeds. The extended native/fresh regression is RED before repair.
  - [x] **ROOT CAUSE (WHY + WHERE)** — MethodLowering's static array pattern normalizer escapes unquoted source instead of evaluating it; source/value controls isolate that branch.
  - [x] **FIX** — Lower dynamic scalar operands once outside the per-item map after snapshotting the source, quoting runtime text literally.
  - [x] **ADDRESSED (verified)** — Targeted native/fresh pipeline regression and module/test compilation PASS.
  - [x] **NO REGRESSION** — Existing pipeline purity/kinds/standalone controls remain in the same small vector; dynamic function/receiver/nested, empty-array/effect-order, metacharacter and regex-flag controls pass. Broader suites remain deferred.
  - [x] **LOCKSTEP** — Public examples, contained canonical fact/derived map, indexed ownership and live handoff agree; standalone5.5.2 is next.
  Containment: Condense old callable-matches proof chronology in the existing fact to its owning leaf and exact prechange Git identity; preserve current causal contracts. No frozen proof producer is replayed or altered and changed inputs have no live claim intersections.
  Commit: `FUTURE-PARITY-BACKLOG.5.5.1 - evaluate dynamic split_each value delimiters`.

- ID: `FUTURE-PARITY-BACKLOG.5.5.2`
  Status: `done`
  Activation commit: `5eaff6564dc9317f689e5ecff7a712c5b1753910`
  Owned paths: ArrayPipeline.pm and BindingRuntime.pm; targeted pipeline regression; current helper book/fact/map and indexed/live continuity.
  Verification tier: `focused`
  Focused checks: Changed-module/test syntax and one small native/fresh pipeline regression plus a wrong-target control; book and fast continuity/history checks only.
  Canonical trigger: None for bounded existing statement-contract alignment under director feature phase; broad suites follow feature coverage.
  Reproduce: Public Get leaves ["a:b","c:d"] unchanged for delimiter=":"; split_each(items,delimiter), and computed delimiter calls remain0. call_spec_handler_subst emits qr/delimiter/ and escaped block text. Static literal and pure dynamic5.5.1 controls work.
  Root cause: ArrayPipeline::_normalize_split_delimiter_expr treats unquoted operand source as static regex text. BindingRuntime can already split on runtime literal/regex operands, but the statement lowering must validate/snapshot its target before evaluating the new dynamic operand.
  Acceptance: Lower only split_each dynamic scalar delimiters through the existing value callback; preserve literal/regex policy. Validate/copy target first, evaluate delimiter once even on empty/absent arrays, then atomically replace target. Preserve function parameters, snapshots and wrong-kind rejection without evaluating later effects.
  Goal: Implement dynamic scalar delimiters in explicit standalone Perl split_each writeback, using its existing target guards and once-only operand policy.
  Dependencies: `FUTURE-PARITY-BACKLOG.5.5.1`
  Schedule: Next feature after clean5.5.1. ArrayPipeline has the same static-source normalization; confirm through public statement probe before repair. Keep literal/regex compatibility and other helper behavior separate.
  Claim verification: none: Scheduled implementation, no measurement.

  Completion: ArrayPipeline lowers dynamic split_each delimiters through the existing value callback. BindingRuntime::array_snapshot validates/copies the target before delimiter effects, then existing array_transform applies the compiled literal runtime text and replaces the binding. The legacy list path captures source and pattern outside its map. Static literals/regexes and other helpers retain their paths.
  Focused result: ArrayPipeline/BindingRuntime/test syntax and t/array_pipeline_value_contract.t PASS on final production for native/fresh execution, including the wrong-target control; book and fast continuity/history checks pass. No full suite.
  Acceptance Checklist
  - [x] **REPRODUCE / ISSUE** — Public Get/substitution show qr/delimiter/ and escaped block source with skipped effects; the small native/fresh vector fails before repair.
  - [x] **ROOT CAUSE (WHY + WHERE)** — ArrayPipeline's static normalization treats dynamic source as pattern text. Capturing validated source before new effects prevents changes to the target from changing the selected input.
  - [x] **FIX** — Add scoped value lowering for split_each delimiters, validate/copy the target, then evaluate the operand once outside the per-item loop and replace the result.
  - [x] **ADDRESSED (verified)** — Changed-module/test compilation and the targeted native/fresh pipeline regression PASS.
  - [x] **NO REGRESSION** — Pure/literal/flag/purity/kind controls remain green; explicit function/empty/absent/effect/retained-snapshot controls pass and a wrong target rejects before failing delimiter evaluation. Broad suites stay deferred.
  - [x] **LOCKSTEP** — Remove the temporary dynamic-statement limitation from book/fact; map/indexed/live handoff agree. Retained numeric-kind feature5.4.4 is next; inventory remains open.
  Harness correction: The first wrong-target assertion stringified the structured last_error hash. Use its established detail field; the corrected pre-repair vector is RED on the actual two value assertions and the preexisting wrong-target control passes. No product-defect credit for that assertion setup error.
  Commit: `FUTURE-PARITY-BACKLOG.5.5.2 - evaluate standalone split_each delimiters`.

- ID: `FUTURE-PARITY-BACKLOG.5.6`
  Status: `active` / five bounded implementations targeted-checked; complete admission remains TYPE23.4
  Goal: Normalize ordinary contains required receiver arity to canonical function[2,2], one authored needle.
  Dependencies: TYPE-REFERENCE-BOOK.1.2.23.2.13 frozen contract; implementations TYPE23.3.13.1-.5 in order.
  Authority: Existing helper signature and punctuation_light_zero_arg_contract.json method_contract_cases prescribe one required authored operand and identical rejection for bare and parenthesized zero-argument forms. Perl direct ordinary missing/extra already returns undef before effects. Rust/Dart/Julia/Lua prior missing-needle numeric0 is explicitly replaced by null/no-effects, with actual named calibration tests updated per backend commit.
  Scope: Receiver contains only; preserve free helper arities, membership equality/kinds/null/empty semantics and all unrelated constructor/control/copy caveats. Perl nested malformed host-call fallthrough is fixed by TYPE23.3.13.1 as part of the guard.
  Acceptance: All five ordinary backends enforce one needle before source/operand effects, identical bare/parenthesized missing results, direct/native/generated controls, compatible result handoff and synchronized book/fact/calibration teaching. Complete domain/portable admission remains TYPE23.4.
  Planned verification tier: `focused`
  Planned focused checks: Delegated per-backend public native/generated required-needle/twin/no-effect and direct punctuation-light calibration checks; small compile/docs/commit. No broad gate per ordinary slice.
  Planned canonical trigger: None for existing bounded receiver signature repair under director feature-first phase; final admission/push separate.
  Planned claim verification: none: existing signature and deterministic authored regression contract, no population/completeness measurement.
  Verification: Perl TYPE23.3.13.1 is implemented/targeted-checked: shared native/fresh hit/miss/numeric/source snapshots and nested missing-twin/extra no-effects pass; direct comparison and syntax pass12 assertions. Perl existing direct invalid-arity policy is preserved; nested host-call fallthrough is fixed. Rust TYPE23.3.13.2 is implemented/targeted-checked too: native/restored/plan source/result/shape checks and named alias calibration now enforce null/no-effects; Dart TYPE23.3.13.3 is targeted-checked too: numeric producer/correct snapshots retained, scalar/required-needle lists and named null-alias calibration pass five tests/fatal analysis; Julia TYPE23.3.13.4 is targeted-checked too: raw Number/not-Bool producer and correct captures retained; guard/named calibration/consumer checks pass with strict compilation. Lua TYPE23.3.13.5 is targeted-checked too: numeric/captured producer retained; native/plan/fresh shared/direct comparison and exact named null-alias contract pass on PUC5.5.1/LuaJIT. All five ordinary implementations are targeted-checked; complete domain/portable/declared5.4 admission remains TYPE23.4. Rust named-source rebinding was repaired using evaluated operands. Actual Rust/Dart/Julia/Lua null/empty membership reference mismatch and unassessed sibling aggregate re-read seams are P1 TYPE23.2.14 immediately after rollout; no equality normalization is inferred here.
  Commit: `pending`; five implementation commits own actual repairs.

- ID: `FUTURE-PARITY-BACKLOG.5.7`
  Status: `active` / six bounded repairs targeted-checked; full admission separate
  Goal: Repair cached aggregate operand reads, Perl has_key key evaluation and null-distinct Array comparison/uniqueness.
  Dependencies: TYPE23.2.14 frozen aggregate-null-and-snapshot-contract.md; execution TYPE23.3.14.1-.6 in order.
  Authority: README behavioral reference; uniform_binding_contract policy.read; existing index/has_key source-before-operand contracts; explicit Perl contains/index_of undef branches and catalog uniq null/empty distinction. No new strict Boolean/number/container/callable equality or source/target namespace policy.
  Acceptance: Rust pure aggregate adapters use cached typed arguments with prior named wrong-kind/absent empty fallback preserved; Perl ordinary has_key evaluates source then key once even for source-null before testing presence. contains/index_of/uniq keep null distinct from empty while preserving defined conversions, first source value/kind/order, arity and copy/source contracts. Independent backend/native/generated checks and current expected artifacts/docs; complete domain/portable admission remains TYPE23.4.
  Planned verification tier: focused
  Planned focused checks: Per bounded execution leaf, public changed-surface/direct consumer and small compile/format checks, docs and commit; no full gate per ordinary slice.
  Planned canonical trigger: Complete admission/final clean push remain separate under feature-first cadence.
  Planned claim verification: none: deterministic authored contract/regression controls, no population/completeness measurement.
  Verification: Rust source adapters TYPE23.3.14.1 are implemented/targeted-checked: native/restored/plan index/has_key/append/merge and named wrong-kind/absent/typed controls plus direct result families and uniform constructor pass seven tests. Existing fallback shapes are preserved. Perl key TYPE23.3.14.2 is targeted-checked too: typed/legacy key temporaries, native/fresh null/missing/valid/empty source effects and malformed guards plus direct has_key/contains pass18 assertions/syntax. Rust null-key TYPE23.3.14.3 is targeted-checked too: private Option<String> keys for contains/index_of/uniq, six Rust tests and six independent Perl reference assertions preserve defined coercion, first values/source/arity and numeric consumers. Dart null-key TYPE23.3.14.4 is targeted-checked too: private actual-null token, shared/native-restored-plan and defined-projection/free-default controls, nine null/contains/index/transform tests plus fatal analysis pass. Julia null-key TYPE23.3.14.5 is targeted-checked too: private tagged text keys, independent null/defined-projection/free-default controls and63 strict native/plan/fresh/direct assertions preserve Number/not-Bool flags and copied values. Lua null-key TYPE23.3.14.6 is targeted-checked too: existing opaque null key, independent native/plan/fresh shared/null-container/defined/free-default controls plus direct contains/index and source loads pass on PUC5.5.1/LuaJIT. All six bounded implementations are targeted-checked; declared5.4/full domains/admission remain separate.
  Commit: Six TYPE23.3.14.1-.6 subjects own the bounded repairs; full admission remains TYPE23.4.

- ID: `FUTURE-PARITY-BACKLOG.6`
  Status: `pending`
  Goal: Decide the fate of Perl legacy plugin machinery.
  Acceptance: Scope whether `PPlugin`, `PluginBridge`, `PluginRegistry`, and deprecated facade stubs
    are retired, relocated, or retained as Perl-reference-only transition machinery; update tests,
    docs, and public API guidance accordingly.
  Verification: `pending`
  Commit: `pending`

- ID: `FUTURE-PARITY-BACKLOG.7`
  Status: `pending`
  Goal: Promote richer legacy/shipped-spec Rust oracle candidates safely.
  Children: `.7.0`
  Acceptance: Triage richer `pplugin`, `tkgui`, `sdce`, recursive `tablegrep`, single-line `simenv`,
    VHDL port-clause, `ds_vhistory` branch, and placeholder `verilog` candidates; promote only
    JSON-safe, portable fixtures or split root-cause leaves.
  Verification: `pending`
  Commit: `pending`

- ID: `FUTURE-PARITY-BACKLOG.7.0`
  Status: `pending`
  Goal: Calibrate the oracle generator's default process timeout to current shipped-spec parser-build costs.
  Acceptance: Measure the slowest current shipped-spec parser construction separately from input parsing; select
    a documented default with bounded headroom so the complete 105-case generator succeeds without an environment
    override; retain the per-case fork plus `SIGKILL` guard and the `ORACLE_TIMEOUT=0` hard-kill proof; update the
    Knowledge Map, generator usage, corpus documentation, and recurring verification command together.
  Verification: `pending`
  Commit: `pending`

- ID: `FUTURE-PARITY-BACKLOG.8`
  Status: `active`
  Goal: Explore spec-derived parser/stimuli closed-loop validation.
  Children: `.8.0`, `.8.1`
  Acceptance: The director's `foo.spec` idea is durable, design work is split before implementation, and any
    later prototype derives both the parser and the stimuli generator solely from the normalized `.spec` contract.
    No second hidden grammar or backend-specific fixture generator may become a competing source of truth.

- ID: `FUTURE-PARITY-BACKLOG.8.0`
  Status: `done`
  Goal: Capture the director's single-source `foo.spec` parser/stimuli roundtrip idea.
  Acceptance: The task tree, index, roadmap/live docs, mdBook, resume pointer, and Knowledge Map record the future
    arc without changing active parser/runtime behavior or pivoting away from the Dart frontier.
  Verification: **PASS 2026-07-09.** `git diff --check`, memory architecture, Knowledge Map generation/check,
    task-tree metadata, doctrine, and mdBook build pass. No implementation code changed.
  Commit: `FUTURE-PARITY-BACKLOG.8.0 - capture spec-derived roundtrip idea`

- ID: `FUTURE-PARITY-BACKLOG.8.1`
  Status: `pending`
  Goal: Design the `.spec`-derived parser/stimuli roundtrip contract before code.
  Acceptance: Define the normalized grammar/semantic metadata needed to construct a parser and a stimuli generator
    from one `.spec`; specify bounded generation, termination/progress guards, expected-output oracles,
    shrink/minimize behavior, negative-case handling, staged parser composition, and cross-backend parity checks;
    explicitly reject any generator rule language that duplicates or drifts from `.spec`.
  Verification: `pending`
  Commit: `pending`

## `FUTURE-PARITY-BACKLOG.5.2.0` Logical-Helper Audit Evidence

Planning evidence recorded on 2026-07-16 before behavior changes:

- Knowledge retrieval covered the existing cross-backend truthiness, Julia logical, Lua logical, and Dart helper
  cards plus `TOOLBOX.md` lowering, live, descriptor, source-dump, and independent-emission probes.
- Perl `call_spec_handler_subst` leaves direct `return(and(...))`, `return(or(...))`, and `return(not(...))` as raw
  keyword calls. Live and independently emitted execution return `undef` for representative `and`/`or` values;
  receiver composition can fail generated-handler compilation. By contrast, condition `and`/`or` lower through
  host `&&`/`||`: a decisive false/true operand skips the second side effect. Condition `not(false, true)` lowers
  as `!(true)` because the one-over-maximum optional-scope normalizer strips the first bare token. Canonical
  descriptors contain `ASSIGN`/`IF`/`RETURN` nodes with logical expression strings, not a first-class logical node.
- The same primary side-effect fixture gives Rust and Julia
  `[and-first,and-second,or-first,or-second,not-first,not-extra]`, while Dart gives only
  `[and-first,or-first,not-first]`. Rust/Julia/Lua accept zero/one/variadic calls eagerly with empty results
  false/false/true; Dart short-circuits, evaluates only the first `not` argument, and gives true/false/true.
- Native and generated probes agree within Rust, Dart, Julia, PUC Lua, and LuaJIT. Compatible logical receiver
  continuations work on Rust/Dart/Julia and focused Lua coverage; Perl direct-value lowering blocks that seam.
- Current truthiness has three profiles: Perl/Lua make scalar `"0"` false, `"false"` true, and empty aggregates
  true; Dart/Julia make every nonempty string true and empty aggregates false; Rust makes both `"0"` and
  `"false"` false and empty aggregates false. Null, boolean false, numeric zero, and empty string remain false.
- Exact owners are Perl `FlowExpr.pm`/`MethodExpr.pm` and missing ActionIR ownership; Rust `RuntimeValue::as_bool`
  plus the eager evaluated-argument dispatcher; Dart AST-argument logical loops plus `_truthy`; Julia's eager
  argument evaluation plus pure helper and `_runtime_truthy`; and Lua's explicit eager value loop plus
  `runtime_truthy`. Generated and primary projections require separate admission despite matching current native
  results.
- The safe split is neutral decision/executable fixture `.5.2.1`, Perl/Rust/Dart/Julia/Lua `.2-.6`, generated/
  primary `.7`, one topology-checked recurring gate `.8`, and public/KM/capability no-drift `.9`. The neutral leaf
  owns exact arities and truthiness; this audit records current facts without silently selecting policy.

## `FUTURE-PARITY-BACKLOG.1.5.1.6.1` Neutral Hex-Byte Fixture Materialization

Implementation evidence recorded on 2026-07-10:

- Schema version 1 input workspace records now require `path` plus exactly one of checked-in `source` or inline
  `bytes_hex`. Existing source-backed cases are unchanged and later backends consume the same manifest.
- `bytes_hex` is validated as a non-empty lowercase even-length sequence of byte pairs. Both/neither source forms,
  empty values, uppercase, odd length, and non-hex text fail manifest validation before command launch.
- Materialization uses `pack('H*', ...)` and the existing raw writer. A focused fake backend reads the generated
  file and proves exact bytes `00 c3 28 ff 0a`, including NUL and invalid UTF-8, inside the canonical workspace.
- `cli_conformance/README.md` documents the portable mechanism and why explicit bytes avoid opaque binary blobs.
  The process suite remained 53 cases until `.6.2` added eight valid/preserved/invalid UTF-8 behavior families.

## `FUTURE-PARITY-BACKLOG.1.5.1.6.2` Strict Perl UTF-8 Adapter Boundary

Implementation evidence recorded on 2026-07-10:

- `bin/linkedspec` decodes every valid raw argument with `Encode::decode(..., FB_CROAK)` before exact option
  parsing. Source/input files are read as raw bytes and strictly decoded at their compilation/input-load phases.
- Raw stdout/stderr remain explicit. Usage/error text is encoded once, and `JSON::PP->utf8(1)` recursively emits
  canonical UTF-8 bytes without the previous byte-string double encoding.
- No normalization, BOM removal, newline conversion, or trimming occurs. An input fixture preserves U+FEFF,
  composed `é`, CRLF, decomposed `e` + U+0301, and LF exactly. A leading spec BOM reaches grammar compilation and
  fails rather than being stripped. Invalid spec/input byte sequences retain compilation/input-load failures.
- Eight shared cases raise the manifest from 53 to 61. Full-level trace proves `xé` is three input bytes and its
  JSON string is five bytes. Nested Unicode object/array output proves recursive JSON encoding.

## `FUTURE-PARITY-BACKLOG.1.5.1.6.1` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — `.6.0` proved invalid source/input bytes are required but the runner only copied
  checked-in files, forcing an opaque binary blob without a schema mechanism.
- [x] **ROOT CAUSE (WHY + WHERE)** — `_validate_manifest` and `_materialize_case_files` required `source` for every
  `files` record; no exact inline byte representation existed.
- [x] **FIX** — Add mutually exclusive validated `bytes_hex`, raw `pack` materialization, focused tests, and docs.
- [x] **ADDRESSED (verified)** — Exact non-text bytes, both/neither/empty/case/length/character validation,
  pre-launch failure, source compatibility, safe paths, and workspace behavior are locked.
- [x] **NO REGRESSION** — Six runner subtests, syntax, checked-in help, full local CI, Knowledge Map, governance,
  mdBook, whitespace, and cleanup pass.
- [x] **LOCKSTEP** — Runner/docs/task/KM/book surfaces expose one neutral mechanism; `.6.2` is active for behavior.

## `FUTURE-PARITY-BACKLOG.1.5.1.6.2` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — LinkedSpec process probe returns UTF-8 argv `xé` as mojibake JSON bytes
  `22 78 c3 83 c2 a9 22 0a`; strict invalid source/input fixture bytes are not rejected by UTF-8 decoding.
- [x] **ROOT CAUSE (WHY + WHERE)** — `bin/linkedspec` parses raw `@ARGV`, `_slurp` returns raw bytes, and
  `JSON::PP` is not in UTF-8 byte mode; decoded native `LinkedSpec::Get` probes already return exact Unicode.
- [x] **FIX** — Strictly decode valid argv and raw source/input files at the adapter boundary, emit canonical JSON
  UTF-8 once, preserve BOM/code points/newlines, and add shared literal/file/invalid/trace fixtures.
- [x] **ADDRESSED (verified)** — Exact neutral cases prove composed/decomposed text, UTF-8 BOM/newlines, Unicode
  source/input/result, phase-stable invalid bytes, and trace input/result byte counts in default/POSIX environments.
- [x] **NO REGRESSION** — CLI/runner/trace syntax and focused suites, complete neutral manifest twice, full local
  CI through Phase 0, Knowledge Map, governance, mdBook, whitespace, and safe generated-artifact cleanup pass.
- [x] **LOCKSTEP** — Adapter/fixtures/task/roadmaps/live docs/book/KM agree on Unicode scalar text encoded as UTF-8;
  UTF-16/UTF-32 remain outside the primary command unless a future explicit encoding contract adopts them.

## `FUTURE-PARITY-BACKLOG.1.5.1.6.3` Reference Closeout Evidence

- Current-state searches separate dated pre-fix/53-case history from live claims. Live surfaces consistently state
  that Perl passes 61 cases, the UTF-8 adapter gap is resolved, and Rust `.1.5.2` is next.
- The exact help snapshot discloses strict UTF-8, preservation, and no implicit UTF-16/UTF-32 detection. The
  mdBook describes Unicode as logical text and UTF-8 as the selected wire encoding.
- No implementation, manifest, expected byte, or shared CLI contract changes in this closeout leaf. It only
  reconciles task parents, current status, retrieval facts, and the next frontier.

## `FUTURE-PARITY-BACKLOG.1.5.1.6.0` Strict UTF-8 Policy Audit and Split

Implementation evidence recorded on 2026-07-10:

- A separated process probe passed UTF-8 argv `xé` through `input_text()`. Perl emitted JSON hex
  `22 78 c3 83 c2 a9 22 0a` (`"xÃ©"`) instead of `22 78 c3 a9 22 0a` (`"xé"`). Isolated `JSON::PP`
  probing showed byte strings `c3 a9` become two code points before UTF-8 output.
- Toolbox-style direct `LinkedSpec::Get` probes passed decoded strings with native trace suppressed. A decoded
  `input_text()` result and a Unicode `/é/` regex both compiled/executed and serialized as exact `c3 a9`. The engine
  already supports this boundary; the primary adapter's missing decode is the root cause.
- Source audit found Julia primary argv/file state is `String` and Rust native boundaries are `&str`/`String` plus
  `read_to_string`. Keeping Perl byte-oriented would guarantee backend drift. Dart will inherit the same explicit
  contract when its primary CLI is repaired.
- ADR `0025` defines strict UTF-8 text, no normalization/BOM removal/newline conversion/trimming, UTF-8 JSON and
  trace byte counts, stable invalid-source/input phase projection, valid argv as interface precondition, and an
  explicit exclusion for accidental binary input.
- The neutral runner can only copy checked-in source files today. `.6.1` adds validated hex-byte materialization,
  `.6.2` implements Perl decode plus valid/invalid shared fixtures, and `.6.3` closes the reference/no-drift gate.

## `FUTURE-PARITY-BACKLOG.1.5.1.6.0` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Exact separated bytes prove UTF-8 argv is currently double-encoded in successful JSON.
- [x] **ROOT CAUSE (WHY + WHERE)** — Raw `@ARGV`/ordinary reads remain byte strings at `bin/linkedspec`; native
  decoded `Get`/regex probes are correct, so the defect is isolated to the CLI process adapter.
- [x] **FIX** — Ratify ADR `0025` and split hex fixture materialization, Perl decode/fixtures, and final closeout
  before changing runner or adapter behavior.
- [x] **ADDRESSED (verified)** — Arg/file/source/input/JSON/trace encoding, preservation, invalid phases, binary
  exclusion, other-backend alignment, and runner capability gap each have an explicit contract/owner.
- [x] **NO REGRESSION** — Read-only probes plus Knowledge Map, governance, mdBook, whitespace, and cleanup pass;
  no implementation source changed.
- [x] **LOCKSTEP** — Roadmap/live/task/KM/book/ADR surfaces identify `.6.1` as the next leaf and keep Rust gated.

## `FUTURE-PARITY-BACKLOG.1.5.1.5` Canonical Trace Protocol and Final Perl Gate

Implementation evidence recorded on 2026-07-10:

- Exact pre-change probes showed that one-token parsing emitted about 1.7 MB at `low` and 6.8 MB at `high`, with
  timestamps, Perl module/function/line locations, and backend-internal compiler events. Emoji file routing also
  leaked host `Wide character in print` warnings to stderr. Those bytes could not be deterministic or portable.
- ADR `0024` defines the primary-command/native-embedding boundary. The CLI now emits exact UTF-8
  `[linkedspec][LEVEL] EVENT` records for portable compile/input/invoke phases. Low owns phase start/outcome,
  medium request controls, high byte counts, full JSON length, and debug protocol version. Native `LinkedSpec::Trace`
  remains unchanged and richer for in-memory users; the primary adapter suppresses its backend-specific stream.
- The initial seven-case matrix covered stdout low, routed reset+emoji, mirrored reset, stdout with a selected file
  left unchanged, none+reset, quiet stdout, and routed compilation failure. Signoff review then found the manifest
  did not yet byte-lock the ADR's medium/high/full/debug records, aliases/numeric thresholds, default route, append,
  or input/invocation error outcomes. Eleven additional cases close that latent cross-backend divergence risk.
  A final byte-representation probe then found raw UTF-8 arguments were double-counted and arbitrary top-rule
  control bytes could forge extra records. Two more fixtures lock process-boundary byte counts and percent-escaped
  field data. The resulting 20 neutral trace cases extend the manifest from 33 to 53 and exact raw channels/files
  prove every declared threshold/event, route/mirror identity, persistence/truncation/append, UTF-8 emoji and byte
  counts, single-line field safety, JSON suffix, and all three failure-phase stderr/exit contracts.
- `tools/run_ci_local.sh` now requires and syntax-checks the primary command, neutral runner/manifest, runner tests,
  and trace tests. It runs the focused runner/trace suites and all 53 cases under both default and POSIX option
  environments before the heavy Phase 0 gate. Untracked CLI fixture inputs are rejected.
- Exact help and usage output identify the portable phase protocol and direct users to native embedding for richer
  backend-internal trace events.

## `FUTURE-PARITY-BACKLOG.1.5.1.5` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Direct stdout/route/mirror/none/emoji probes measured multi-megabyte nondeterministic
  native output and captured emoji encoding warnings before the adapter change.
- [x] **ROOT CAUSE (WHY + WHERE)** — `bin/linkedspec` passed primary trace flags directly into the native Perl
  compiler/runtime stream, whose timestamps, source locations, recursive bootstrap events, and host IO encoding are
  correct backend diagnostics but cannot be an identical multi-backend CLI protocol.
- [x] **FIX** — Add ADR `0024`, canonical phase tracing with raw UTF-8 sink handling, 20 exact fixtures, updated
  focused assertions/help/docs, and one reusable-runner integration in the canonical local gate.
- [x] **ADDRESSED (verified)** — Stdout/route/mirror, default file routing, reset/no-reset/append, every named level
  and alias, numeric threshold projection, emoji at all event levels, exact UTF-8 byte counts, percent-escaped
  user fields, all failure phases, JSON/channel separation, deterministic records, and native-versus-CLI ownership
  are locked.
- [x] **NO REGRESSION** — All 53 cases pass in default/POSIX environments; four runner and three trace subtests,
  full `tools/run_ci_local.sh` including Phase 0 `1..1028`, Knowledge Map, governance, mdBook, whitespace, and
  cleanup pass.
- [x] **LOCKSTEP** — The trace leaf is done and runner/local gate/docs/KM/ADR surfaces use one 53-case trace-aware
  contract. Signoff's pre-existing Unicode finding is owned by active `.1.5.1.6`; Rust `.1.5.2` remains pending
  so it cannot consume a mojibake-prone reference boundary.

## `FUTURE-PARITY-BACKLOG.1.5.1.4` Perl Operational Failures and Stdout Purity

Implementation evidence recorded on 2026-07-10:

- Four shared failure cases extend the manifest from 29 to 33 cases: invalid inline source with a simultaneously
  missing input, a missing spec file, a missing input file after valid compilation, and invocation with a missing
  explicit top rule. The first proves compilation wins before deferred input loading.
- Each operational family now emits exactly one stable line: `linkedspec: parser compilation failed`,
  `linkedspec: input load failed`, or `linkedspec: parser invocation failed`. Stdout is empty, stderr ends in one
  newline, exit is `1`, and no unexpected files appear. Host paths, OS `$!`, Perl exceptions, owner-stage names,
  timestamps, source filenames, and runtime-context wording are not part of the cross-backend command contract.
- Exact help and usage snapshots now document the stable operational heading/exit `1` and usage help/exit `2`
  behavior, so users do not need implementation knowledge to interpret the three status classes.
- With no primary-CLI trace option, the adapter clears backend-specific trace environment inputs and configures an
  internal below-`none` level with an empty route sink. This suppresses the general library's intentionally visible
  `DUMP_NONE` diagnostics without changing `LinkedSpec::Trace`. Any explicit CLI trace option retains the normal
  trace pipeline and remains `.1.5.1.5`'s deterministic matrix/final-gate responsibility.
- `t/trace_cli.t` locks a debug/file/reset ambient environment around the compile-before-input case: exit/stderr
  remain exact, stdout stays empty, and no ambient trace file is created or reset.

## `FUTURE-PARITY-BACKLOG.1.5.1.4` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Separated direct processes captured 755/240 bytes of timestamped `DUMP_NONE` stdout
  on compile/invocation failures plus platform paths, `$!`, internal fields, and raw exceptions on stderr.
- [x] **ROOT CAUSE (WHY + WHERE)** — `LinkedSpec::Trace::log_output` deliberately exposes level-zero diagnostics
  at default verbosity, while `bin/linkedspec::_runtime_error` projected runtime context and raw host errors. The
  general library is correct for embedding/debugging; the primary adapter lacked a deterministic untraced boundary.
- [x] **FIX** — Add four exact failure fixtures, make untraced CLI calls use a below-`none` discard configuration,
  and reduce operational stderr to one shared phase heading. The following `.1.5.1.5` slice then projected explicit
  primary-CLI tracing onto the canonical portable phase protocol while preserving the rich native embedding trace.
- [x] **ADDRESSED (verified)** — Compile/source-load, input-load, invocation, phase precedence, paths, host wording,
  ambient trace state, stdout/stderr, exit `1`, and generated-file absence are byte-locked.
- [x] **NO REGRESSION** — All 33 cases pass twice; CLI/test syntax, four runner subtests, all three trace CLI
  subtests, Knowledge Map, governance, mdBook, whitespace, and cleanup gates pass.
- [x] **LOCKSTEP** — Manifest/docs/book/task/KM surfaces report 2 help + 20 usage + 7 success + 4 failure cases;
  `.1.5.1.5` became active there and has since closed explicit trace plus reusable-runner local-gate integration.

## `FUTURE-PARITY-BACKLOG.1.5.1.3` Perl Source, Input, Parser Controls, and Success Bytes

Implementation evidence recorded on 2026-07-10:

- Seven shared success cases extend the manifest from 22 to 29 cases. They cover the repository `Lispish` named
  spec from the runner's isolated working directory, file source plus file input, inline source plus literal input,
  explicit `--top-rule`, explicit seek and consume modes, and exact file-input byte preservation.
- The file-backed grammar returns a deliberately unsorted nested hash. Perl's canonical JSON writer emits
  `{"a":{"b":2,"d":4},"z":0}` with recursive lexical key ordering. Every success writes empty stderr,
  exits `0`, creates no unexpected files, and terminates the one JSON value with exactly one newline.
- `cli_conformance/cases/success/input.txt` contains `x` plus a newline. The `input_text()` case emits `"x\\n"` plus the JSON
  record newline, proving `_slurp` does not trim or normalize file input before parser invocation.
- Toolbox `LinkedSpec::Get`, `get_parser`, generated-source, and debug-trace probes were used before choosing the
  grammar. They reverified ADR `0020`'s known Perl direct-default-rule `E` omission. The fixtures therefore use the
  established action-edge return shape already present in the cross-variant corpus; lifecycle normalization stays
  outside this CLI-only leaf and remains a later complete-capability parity obligation.

## `FUTURE-PARITY-BACKLOG.1.5.1.3` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Direct CLI probes established exact named/file/inline, literal/file, top-rule,
  seek/consume, nested JSON, stderr, exit, and newline behavior before fixtures were written.
- [x] **ROOT CAUSE (WHY + WHERE)** — `bin/linkedspec` already forwards exact loaded bytes and parser controls to
  `get_parser`/`Get`; its canonical `JSON::PP` writer sorts keys and appends one newline. No success-path code gap
  existed. ADR `0020` explains why direct default-rule `E` is not a portable fixture shape.
- [x] **FIX** — Add seven language-neutral success cases and two raw checked-in source/input files; no backend
  implementation change or expected-output normalization was necessary.
- [x] **ADDRESSED (verified)** — All acceptance dimensions are independently represented, including isolated named
  resolution, nested recursive key ordering, and an input newline visible inside the returned JSON string.
- [x] **NO REGRESSION** — The complete 29-case suite passes in default and POSIX environments; runner/trace focused
  tests, syntax, governance, Knowledge Map, mdBook, whitespace, and cleanup gates pass.
- [x] **LOCKSTEP** — Manifest/docs/book/task/KM surfaces report exactly 2 help + 20 usage + 7 success cases;
  `.1.5.1.4` became active there and has since closed operational failures; `.1.5.1.5` retains trace/final ownership.

## `FUTURE-PARITY-BACKLOG.1.5.1.2` Strict Perl Arguments and Usage Bytes

Implementation evidence recorded on 2026-07-10:

- `bin/linkedspec` no longer delegates public syntax to ambient `Getopt::Long` configuration. One explicit parser
  recognizes only ADR `0023`'s exact case-sensitive long options plus `-h`, supports separate/`--option=value`
  value forms, treats repeated value options as last-wins, and accumulates ordered lexical errors before selector/
  value validation. Help remains an early successful result only after lexical errors are clear.
- No positional or subcommand surface exists. `status`, `corpus`, a trailing word, and literal `--` are usage
  errors. Uppercase and unique-abbreviation long options plus `--no-trace-reset` / `--no-trace-emoji` are unknown;
  boolean flags reject inline values. Missing values, source/input cardinality, seek/consume, all documented
  numeric/named trace levels, and stdout/route/mirror are validated explicitly.
- `cases/usage/stderr.txt` is one exact backend-neutral error-plus-help template. Schema channel variables insert
  only manifest-owned `{{ERROR}}` text and may not override the four reserved runner placeholders. This avoids 20
  duplicated help snapshots without introducing backend-conditioned expected output.
- The manifest now has 22 exact cases: two help forms and 20 usage cases. Every failure requires empty stdout,
  byte-exact stderr, no generated files, and exit `2`. The complete suite passes both with `POSIXLY_CORRECT` unset
  and with `POSIXLY_CORRECT=1`, proving ambient option-parser policy no longer changes the command.

## `FUTURE-PARITY-BACKLOG.1.5.1.2` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — `.1.5.1.0` directly proved ignored positionals, case/abbreviation/negation aliases,
  environment drift, and uncontrolled option-parser warnings.
- [x] **ROOT CAUSE (WHY + WHERE)** — Public syntax inherited `Getopt::Long` defaults, used negatable `!` flags,
  never inspected residual arguments, and let the library write its own warning before CLI-owned usage output.
- [x] **FIX** — Replace that boundary with one explicit ordered parser and add 20 exact shared usage cases plus
  reusable channel-template variables.
- [x] **ADDRESSED (verified)** — Required/help/value/flag/unknown/positional/selector/mode/level/multi-error families
  are byte-locked, case-sensitive, non-abbreviating, non-negatable, and environment-independent.
- [x] **NO REGRESSION** — CLI/runner/test syntax passes; 22/22 cases pass twice (default and POSIX), four runner
  subtests and two trace CLI subtests remain green; parser/compiler/runtime behavior is unchanged.
- [x] **LOCKSTEP** — Manifest/README/TOOLBOX/mdBook/task/live/KM surfaces report exact help+usage scope only;
  `.1.5.1.3` became active there and has since closed success bytes, while failures/trace retain later owners.

## `FUTURE-PARITY-BACKLOG.1.5.1.1` Neutral Fixture Runner and Help Baseline

Implementation evidence recorded on 2026-07-10:

- `cli_conformance/manifest.json` is the language-neutral ordered case inventory. Schema version 1 strictly rejects
  unknown keys, duplicate/invalid ids and output paths, unsafe relative paths, absent fixture/expected files,
  malformed placeholders, invalid channel definitions, and exit statuses outside 0–255.
- `tools/run_cli_conformance.pl` accepts any backend launch array after an explicit `--`; no backend name or
  implementation is embedded in fixture cases. It expands `{{REPO_ROOT}}` for launch, `{{COMMAND}}` for the allowed
  user-facing executable/wrapper difference, and exact `{{WORKSPACE}}`/`{{CASE_ID}}` runner inputs.
- Each case receives a canonicalized private temporary working directory. Checked-in input files are copied as raw
  bytes. `IO::Select` drains child stdout/stderr concurrently as separate raw byte streams, and the runner compares
  exit status, both channels, and expected generated workspace files byte-for-byte.
- A mismatch reports its first byte offset, expected/actual lengths, and escaped excerpts. Runner/schema misuse is
  exit `2`; conformance mismatch is `1`; a completely green selected set is `0`. `--case` can select focused ids.
- The first public case locks complete help stdout, empty stderr, and exit `0`. Its wording is backend-neutral (no
  Perl `Get`/`get_parser` names), documents numeric plus all named trace aliases and `--help`/`-h`, and substitutes
  only `{{COMMAND}}`. Perl passes it exactly.
- Four runner subtests (13 assertions) lock the checked-in Perl case, schema rejection before launch, command/
  workspace/case substitution with input and generated-file bytes, and first-byte mismatch reporting. The existing
  two trace CLI subtests remain green.

## `FUTURE-PARITY-BACKLOG.1.5.1.1` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The split proved there was no checked-in backend-neutral case schema or arbitrary-
  command byte runner; only Perl-specific trace smokes existed.
- [x] **ROOT CAUSE (WHY + WHERE)** — Existing tests owned one command directly and used regex/inline expectations,
  so later backends had no common data model, isolated workspace, generated-file contract, or byte diagnostics.
- [x] **FIX** — Add the strict manifest, arbitrary command-array runner, raw channel/file comparison, exact help
  case, runner tests, backend-neutral help text, and public/toolbox documentation.
- [x] **ADDRESSED (verified)** — Schema, path safety, command/display substitution, macOS canonical workspace
  identity, file materialization/output, stdout/stderr/exit exactness, and mismatch behavior are locked.
- [x] **NO REGRESSION** — `perl -c` passes for CLI/runner/test; four runner subtests and two trace CLI subtests pass;
  direct `help` conformance passes. No parser/compiler/runtime semantics changed.
- [x] **LOCKSTEP** — README, TOOLBOX, mdBook, task/live/roadmap docs, and Knowledge Map describe one reusable suite;
  `.1.5.1.2` became active there and has since closed strict arguments; no later backend has a forked manifest.

## `FUTURE-PARITY-BACKLOG.1.5.1.0` Neutral CLI / Perl Audit and Split

Read-only evidence recorded on 2026-07-10:

- ADR `0023` requires exact option spellings/meanings, no positionals/subcommands, canonical success bytes, stable
  errors and 0/1/2 exits, deterministic trace routing, and one language-neutral fixture suite reused by every
  backend. `bin/linkedspec` is the current parser-oriented reference; `t/trace_cli.t` covers only help flag presence
  plus one routed-trace success.
- Direct process probes prove undocumented surface. An extra positional is ignored and the command exits `0`;
  uppercase long options, unique abbreviations such as `--inl`, and `--no-trace-reset` / `--no-trace-emoji` are
  accepted. `POSIXLY_CORRECT=1` changes abbreviation and option-order behavior, so the public API depends on ambient
  process state. Unknown options also prepend `Getopt::Long`'s uncontrolled warning before the owned usage text.
- Compilation-before-input ordering already holds, and usage/operational statuses are correctly `2`/`1`. However,
  compilation and missing-top-rule probes capture timestamped/source-located `DUMP_NONE` trace records on stdout
  while normalized diagnostics go to stderr. This violates machine-readable failure stdout and cannot be an exact
  cross-backend fixture. Input failures also expose host `$!` text unless normalized.
- The existing trace owner deliberately treats `DUMP_NONE` events as visible at verbosity zero; the CLI adapter,
  not the trace library's general diagnostics contract, must own primary-command stdout purity and deterministic
  projection. Trace fixtures therefore remain a separate final mechanism rather than being folded into argument
  parsing.

## `FUTURE-PARITY-BACKLOG.1.5.1.0` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Run the existing trace CLI test plus direct help/positional/case/abbreviation/
  negation/environment/unknown/compile/input/invocation process probes with stdout and stderr captured separately.
- [x] **ROOT CAUSE (WHY + WHERE)** — `bin/linkedspec` inherits `Getopt::Long` defaults, never rejects residual
  `@ARGV`, declares boolean flags with `!`, lets `GetOptions` print its own warning, and invokes a library whose
  level-zero diagnostic trace is intentionally visible on stdout.
- [x] **FIX / SPLIT** — Split neutral harness/help (`.1`), strict arguments (`.2`), successful source/input/parser
  behavior (`.3`), operational errors/stdout purity (`.4`), and deterministic trace plus final gate (`.5`).
- [x] **ADDRESSED (verified)** — Every observed gap and every ADR `0023` required fixture family has one ordered
  leaf before code changes.
- [x] **NO REGRESSION** — `prove -v -Iperl t/trace_cli.t` passes; this slice changes no CLI/parser/runtime source.
- [x] **LOCKSTEP** — Task index, roadmap/live/book status, Knowledge Map, and resume pointer advance only to
  `.1.5.1.1`; Rust/Dart/Julia remain later consumers of the same not-yet-created fixture manifest.

## `FUTURE-PARITY-BACKLOG.1.5.3.1` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The shared runner establishes the old Dart primary at 0/61; direct staged API
  regression reproduces an ordinary no-`fn` spec failing with `cursor_code_unit=0`.
- [x] **ROOT CAUSE (WHY + WHERE)** — `bin/linkedspec_dart.dart` routed to the corpus command, while
  `UserFunctionDefinitionAstParser.parse(...)` interpreted a no-match extraction as an error instead of the valid
  empty-definition case. Dart `String.trim()` also erases leading U+FEFF unless the adapter preserves policy first.
- [x] **FIX** — Added the exact raw-byte primary adapter, strict manual arguments/help, deterministic resolution,
  compile-before-input UTF-8 loading, source-BOM guard, and empty-definition staged result; kept corpus options only
  in `bin/corpus_runner.dart`.
- [x] **ADDRESSED (verified)** — Six direct adapter tests, the staged ordinary-spec regression, and 29 exact shared
  cases cover every boundary/loading/phase behavior owned by this leaf in default and POSIX environments.
- [x] **NO REGRESSION** — Analyzer, all 147 Dart tests, and the independent 99/99 corpus gate pass.
- [x] **LOCKSTEP** — README, mdBook, Knowledge Map, task/roadmap/live docs, and local gate distinguish the shared
  primary boundary from the separate corpus runner; `.1.5.3.2` owns only native execution/results/failures.

## `FUTURE-PARITY-BACKLOG.1.5.3.2` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The `.1` baseline passes 29/61 and every one of the 11 successful result cases fails
  only because the prepared request deliberately stops at the invocation boundary.
- [x] **ROOT CAUSE (WHY + WHERE)** — `runLinkedSpecDartPrimaryCli(...)` discarded `CompiledSpec`, loaded input only
  for phase proof, and returned the stable invocation failure without calling the existing native engine.
- [x] **FIX** — Retain compiled state, compose `LinkedSpecRuntimeEngine` with native parse-mode/top-rule controls,
  serialize `RuntimeParseResult.value`, recursively sort map keys, encode compact UTF-8 JSON, and append one newline.
- [x] **ADDRESSED (verified)** — Focused nested/top/mode coverage and all 11 unchanged result cases pass in default
  and POSIX environments; quiet trace also passes without trace machinery.
- [x] **NO REGRESSION** — Analyzer, the complete Dart suite, and separate 99/99 corpus gate remain green.
- [x] **LOCKSTEP** — Task/roadmap/live docs, README, mdBook, and Knowledge Map advance to 41/61 and identify exactly
  20 canonical-trace residuals under `.1.5.3.3`.

## `FUTURE-PARITY-BACKLOG.1.5.3.3` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The `.2` full classification is 41/61; all 20 failures are exact trace records,
  routing/reset/append, emoji/escaping/byte counts, or traced phase failures.
- [x] **ROOT CAUSE (WHY + WHERE)** — The primary adapter parsed trace options but intentionally ignored them;
  Dart's existing rich `LinkedSpecTraceEmitter` is backend-specific and cannot satisfy ADR `0024` byte identity.
- [x] **FIX** — Added an adapter-local canonical phase trace with exact thresholds/aliases, UTF-8 byte accounting,
  field escaping, emoji, stdout/route/mirror, reset/append, persistence, failures, and stable IO-error projection.
- [x] **ADDRESSED (verified)** — Focused stdout, routed emoji/reset, and setup-failure tests pass; all 20 previously
  failing trace cases now pass unchanged.
- [x] **NO REGRESSION** — Analyzer, full Dart tests, separate 99/99 corpus, and all 61 shared cases pass in both
  default and POSIX environments; native rich trace remains independent.
- [x] **LOCKSTEP** — README, mdBook, Knowledge Map, task/roadmap/live docs identify Dart at 61/61 and advance only
  to recurring-gate/no-drift `.1.5.3.4`.

## `FUTURE-PARITY-BACKLOG.1.5.3.4` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Dart passes 61/61 manually, but `tools/run_dart_local.sh` did not yet make either
  default/POSIX shared leg recurring and the parent status still advertised active rollout work.
- [x] **ROOT CAUSE (WHY + WHERE)** — The focused gate retained only primary help plus corpus checks from the old
  scoped milestone; global task/roadmap/book/KM/live status had not consumed `.1`-`.3` completion.
- [x] **FIX** — Added both exact shared legs to the focused Dart gate and reconciled every live/public continuity
  surface; closed `.1.5.3` without changing fixtures/help/runtime behavior.
- [x] **ADDRESSED (verified)** — The focused gate passes 151 tests, 61/61 default, 61/61 POSIX, and 99/99 corpus;
  shared help/manifest bytes remain unchanged.
- [x] **NO REGRESSION** — The broader local gate passes doctrines/syntax, 22 ActionIR, nine runner/trace, both Perl
  61-case legs, and Phase 0 `1..1028` in 527 seconds.
- [x] **LOCKSTEP** — Task parents, task index, roadmaps, README, mdBook, Knowledge Map, and live docs close Dart and
  advance only to global four-backend identity `.1.5.4`.

## `FUTURE-PARITY-BACKLOG.1.5.4.0` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Run all 61 unchanged cases against the Julia project command after using its existing
  warmup convention; baseline is 13/61, with 48 exact failures.
- [x] **ROOT CAUSE (WHY + WHERE)** — `_primary_cli_usage()` is a local template; `_read_primary_cli_file` accepts
  Julia invalid strings; `_print_primary_cli_runtime_error` appends backend detail; `_primary_cli_trace_emitter`
  routes rich native events. Cold first load may also emit Julia precompile progress before project warmup.
- [x] **FIX / SPLIT** — `.1` owns help/UTF-8/stable errors, `.2` owns independent canonical trace, and `.3` owns
  warmup plus one recurring four-command driver and final lane closeout.
- [x] **ADDRESSED (verified)** — Every one of the 48 failures maps to one ordered leaf; all 11 native result cases
  already pass unchanged and need no semantic rewrite.
- [x] **NO REGRESSION** — This slice changes no Julia, fixture, help, or driver behavior.
- [x] **LOCKSTEP** — Task/roadmap/live/book/KM surfaces advance only to `.1.5.4.1`; `.1.6` remains behind exact CLI.

## `FUTURE-PARITY-BACKLOG.1.5.4.1` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The warmed 13/61 audit identifies shorter help, malformed-file acceptance, and
  backend-detail stderr independently of canonical trace.
- [x] **ROOT CAUSE (WHY + WHERE)** — `_primary_cli_usage()` was Julia-local; `read(path, String)` creates an
  invalid Julia string without rejecting malformed bytes; `_print_primary_cli_runtime_error(...)` projected rich
  native diagnostics onto the portable process surface.
- [x] **FIX** — Render the exact shared command help, read raw bytes and require `isvalid`, and keep primary stderr
  to its one phase heading. Native structured exceptions and rich trace APIs remain below the adapter.
- [x] **ADDRESSED (verified)** — Focused tests lock exact help, malformed spec/input rejection, and exact errors;
  the package passes 1,019 assertions, the updated nine-family real-process checker passes, and corpus is 99/99.
- [x] **NO REGRESSION** — All non-trace shared cases pass in default and POSIX environments. Julia advances to
  42/61; the 19 failures are exactly the canonical-trace inventory already owned by `.1.5.4.2`.
- [x] **LOCKSTEP** — Task/roadmap/live/book/KM surfaces advance only to `.1.5.4.2`; fixtures and native rich
  diagnostics/trace remain unchanged.

## `FUTURE-PARITY-BACKLOG.1.5.4.2` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — After `.1`, exactly 19/61 failures remain in both environments; every mismatch is
  rich Julia trace instead of ADR `0024` bytes.
- [x] **ROOT CAUSE (WHY + WHERE)** — `run_cli(...)` passed `_primary_cli_trace_emitter(...)` through native
  frontend/compiler/runtime operations, coupling the portable command to backend-internal scopes and events.
- [x] **FIX** — Add an adapter-local canonical recorder and emit compile/input/invoke phases around the unchanged
  native parse/compile/execute calls. Normalize optional-minus ASCII numeric thresholds with arbitrary precision.
- [x] **ADDRESSED (verified)** — Exact tests lock records, UTF-8 counts, percent escaping, huge numeric levels,
  sinks/reset/emoji, and native-trace independence; package/process/corpus gates all pass.
- [x] **NO REGRESSION** — The unchanged suite passes 61/61 default and POSIX; Julia local proof remains 1,019
  assertions, nine direct process families, and 99/99 corpus.
- [x] **LOCKSTEP** — Task/roadmap/README/live/book/KM surfaces report Julia 61/61 and activate only the recurring
  four-command driver `.1.5.4.3`; shared fixtures and native trace APIs are unchanged.

## `FUTURE-PARITY-BACKLOG.1.5.4.3` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — Four commands individually pass the shared suite, but no single recurring owner
  builds/prepares/warms and invokes all four under both option environments.
- [x] **ROOT CAUSE (WHY + WHERE)** — Backend-focused scripts duplicate single-backend invocations; Julia requires
  explicit normal-project warmup, and the core gate intentionally avoids mandatory non-Perl toolchains.
- [x] **FIX** — Add `tools/run_primary_cli_matrix.sh` and an opt-in `LINKEDSPEC_RUN_CLI_MATRIX=1` core-gate hook;
  track every backend script as a protected CI input and syntax-check them together.
- [x] **ADDRESSED (verified)** — The new driver passes 4 backends x 2 environments x 61 unchanged cases after
  building Rust, preparing Dart, and explicitly warming Dart/Julia.
- [x] **NO REGRESSION** — Rust, Dart, and Julia focused gates pass completely after the 4x2x61 matrix; the broader
  core gate also passes doctrines/syntax, 22 ActionIR, nine runner/trace checks, Perl 61x2, and Phase 0 `1..1028`.
- [x] **LOCKSTEP** — Task/roadmap/live/book/KM surfaces close `.1.5` and activate only capability census `.1.6`;
  safe post-verification cleanup removes reproducible Rust, Julia, and Dart caches without retaining in-flight work.

## `FUTURE-PARITY-BACKLOG.1.6.0` Acceptance Checklist

- [x] **REPRODUCE / ISSUE** — The 99-case corpus and 61-case CLI suite are green on all four backends, but neither
  is an exhaustive machine-readable inventory of current mdBook and exported native API capabilities.
- [x] **ROOT CAUSE (WHY + WHERE)** — Capability claims were distributed across the mdBook, public exports, Phase 0,
  backend tests, corpus, trace facts, and codegen facts; no validated row mapped every backend state to evidence and
  a residual owner.
- [x] **FIX** — Add `capability_conformance/manifest.json`, a strict repo-path/owner/schema checker, core-gate
  integration, public documentation, a retrieval fact, and exact `.1.6.1`–`.1.6.6` mechanism leaves.
- [x] **ADDRESSED (verified)** — Fifteen capabilities x four backends classify 47 pass, five partial-proof, and
  eight gap states; every non-pass state and every explicit future/legacy exclusion has a tracked owner.
- [x] **NO REGRESSION** — Checker syntax/self-validation, core gate through Phase 0, docs/KM/governance, mdBook,
  whitespace, and generated-artifact cleanup pass; no parser/compiler/runtime behavior changes.
- [x] **LOCKSTEP** — Matrix/task/roadmaps/README/live docs/book/KM agree; `.1.6.1` becomes the sole active next leaf
  while codegen remains top-level `.3` and no backend is called complete.

<!-- Source ranges and their immutable migration digest are recorded in docs/tasks/FUTURE-PARITY-BACKLOG.index.jsonl. -->
