# RUST-PARITY: Bring Rust Variant to Full Parity with Perl Reference

## Metadata

- Tree ID: `RUST-PARITY`
- Status: `done`
- Roadmap lane: `Phase 9 — Rust variant (parity follow-on)`
- Created: `2026-06-16`
- Last updated: `2026-07-04` (`.9` done — Rust parity follow-on
  finalized; next PNT leaf is `TOP-RULE-AS-NORMAL.3.2`)
- Owner: repo-local workflow

## Goal

Bring the Rust variant (`rust/`) to full behavioral parity with the Perl reference
implementation across all deferred v1 gaps: conditional flow, BACKTRACK, self-hosting,
remaining helpers, strict_syntax, test corpus expansion, and code-gen emitter.

## Non-Goals

- Plugin/legacy support (PluginBridge, PPlugin, .plg) — Perl-specific, out of scope
- Wasm/Julia/Dart backends — ADR 0006 envisions these but they are not this tree
- Architecture convergence — Rust keeps its native pipeline (parse→AST→CompiledSpec→interpret)

## Acceptance Criteria

- All deferred gap items implemented to functional parity with Perl
- All existing 166 Rust tests pass
- New tests added for each gap closed
- `cargo test` and `cargo clippy` clean in `rust/`
- Live docs updated (ROADMAP_V2.md, CHANGES.md, DEVELOPMENT_NOTES.md, MEMORY.md)
- Each completed leaf committed through `COMMIT.md`

## Task Tree

- ID: `RUST-PARITY`
  Status: `done`
  Goal: Bring Rust variant to full parity with Perl reference
  Children: `.1`, `.2`, `.3`, `.4`, `.5`, `.6`, `.7`, `.8`, `.9`

- ID: `RUST-PARITY.1`
  Status: `done`
  Goal: Complete gap inventory — list exact Perl features not yet in Rust with file:line references
  Acceptance: Inventory document with categorized gaps, Perl reference locations, and Rust locations where implementation is needed
  Verification: Done — 2026-06-16: full audit of Rust `engine.rs` (1984 lines, 84 helpers) and `helpers.rs` (470 lines, regex engine) against Perl `LinkedSpec::ActionIR::*` lowering owners. Inventory recorded below.
  Commit: `pending`

- ID: `RUST-PARITY.2`
  Status: `done`
  Goal: Implement conditional control flow — if/elseif/else and switch/case/default
  Acceptance: if/elseif/else/endif and switch/case/default/endswitch interpreters working in Rust runtime; regression tests; all existing tests pass
  Commit: `pending`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.2`.

- ID: `RUST-PARITY.3`
  Status: `done`
  Goal: Implement BACKTRACK/IBACKTRACK cursor save/restore
  Acceptance: BACKTRACK saves cursor, IBACKTRACK restores it; regression tests covering both markers; all existing tests pass
  Verification: Done — 2026-06-16: 181/181 PASS. `backtrack_stack: Vec<usize>` added to RuntimeContext with `push_backtrack()`/`pop_backtrack()`. 4 new tests: save/restore, retry restore, empty stack no-op, multiple push/pop.
  Commit: `pending`

- ID: `RUST-PARITY.4`
  Status: `superseded`
  Goal: Implement self-hosting — Rust compiles and runs spec.spec against itself
  Acceptance: spec.spec compiles in Rust; Rust can parse .spec files using the spec.spec grammar (not just bootstrap); regression test; all existing tests pass
  Commit: WIP checkpoint (this session)
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.4`.

- ID: `RUST-PARITY.5`
  Status: `done`
  Goal: Close the real Rust↔Perl parity gaps found by the audit (retv blocker, match/entry split, char-indexing, dead arms, missing helpers)
  Children: `.5.1` (done), `.5.2` (done), `.5.3` (done), `.5.4` (done), `.5.5` (done — split into `.5.5.1`–`.5.5.4`, all done)
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5`.

- ID: `RUST-PARITY.5.1`
  Status: `done`
  Goal: Fix the child-return (retv) propagation BLOCKER
  Acceptance: After `->`/`=>` dispatch, the child rule's `return(expr)` value is propagated to the parent and readable as `retv` (so `scalar(retv)` in an `LE` block resolves to the child result, not undef); the half-built dead `set_retv` is completed or removed; new regression tests cover retv-in-LE across AND/OR/REP dispatch; `cargo test` + `cargo clippy` clean; the 182-test baseline stays green.
  Commit: `RUST-PARITY.5.1 — fix child-return (retv) propagation in the Rust engine`; prior node reference: `RUST-PARITY.5.1` (see Commit Log); retained completion note: engine.rs + runtime.rs + 4 integration tests; 186/186 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.1`.

- ID: `RUST-PARITY.5.2`
  Status: `done`
  Goal: Separate `match_*` from `entry_*` (stop unifying them at engine.rs:171-174)
  Acceptance: `match_*` reads the current local match while `entry_*` reads the entry match; nested-match reads diverge correctly; regression test; baseline green; clippy clean.
  Commit: `RUST-PARITY.5.2 — separate entry_* from match_* in the Rust engine`; prior node reference: `RUST-PARITY.5.2` (see Commit Log); retained completion note: engine.rs SavedMatchState save/restore + 3 integration tests; 189/189 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.2`.

- ID: `RUST-PARITY.5.3`
  Status: `done`
  Goal: Char-based (not byte) indexing for slicing + cursor line/col; fix hardcoded start positions
  Acceptance: `substr`/`input_slice`/`capture_slice`/`capture_from` and cursor line-col use char offsets (no panic on multibyte UTF-8; parity with Perl's char-based offsets); `entry/match_start_pos` no longer hardcoded to 0; multibyte regression tests; baseline green; clippy clean.
  Commit: `RUST-PARITY.5.3 — char-based offsets/slicing in the Rust engine`; prior node reference: `RUST-PARITY.5.3` (see Commit Log); retained completion note: engine.rs byte→char conversions + runtime.rs match-span fields + 7 multibyte unit tests; 196/196 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.3`.

- ID: `RUST-PARITY.5.4`
  Status: `done`
  Goal: Remove duplicate/unreachable match arms; make the REP zero-progress guard check `pos`
  Acceptance: the shadowed arms (`hash`/`h`, `hash_copy`, `print`) are de-duplicated so the correct behavior wins; the REP loop's zero-progress guard actually compares `pos` before/after and breaks on no advance; regression tests; baseline green; clippy clean.
  Commit: `RUST-PARITY.5.4 — dedup shadowed arms + fix REP zero-progress guard in the Rust engine`; prior node reference: `RUST-PARITY.5.4` (see Commit Log); retained completion note: engine.rs removed 3 duplicate arms + pos-based REP guard + 2 unit tests; 198/198 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.4`.

- ID: `RUST-PARITY.5.5`
  Status: `done`
  Goal: Implement the ~28 missing capture/mark/entry/match/input helpers (+ real aliases `tail`/`drop_last`/`flatten`)
  Children: `.5.5.1` (done), `.5.5.2` (done), `.5.5.3` (done), `.5.5.4` (done)
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.5`.

- ID: `RUST-PARITY.5.5.1`
  Status: `done`
  Goal: Named-group helpers — `entry_named`/`entry_has`/`entry_map`/`entry_named_map` + `match_named`/`match_has`/`match_map`/`match_named_map`
  Acceptance: the 8 named-group readers read the existing `entry_named`/`match_named` maps (`entry_named(name)`→string, `entry_has(name)`→bool, `entry_map()`/`entry_named_map()`→hash; same for `match_*`) to helper-contract-catalog parity; per-family tests; baseline green; clippy clean.
  Commit: `RUST-PARITY.5.5.1 — named-group reader helpers in the Rust engine`; prior node reference: `RUST-PARITY.5.5.1` (see Commit Log); retained completion note: engine.rs +8 `call_helper` arms (entry/match `_named`/`_has`/`_map`+`_named_map`) + `named_map_to_hash` + 6 tests; 204/204 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.5.1`.

- ID: `RUST-PARITY.5.5.2`
  Status: `done`
  Goal: Input-boundary helpers (`input_end_line`, `input_end_col`) + real compat aliases (`tail`, `drop_last`, `flatten`, and `flat` if missing)
  Acceptance: `input_end_line`/`input_end_col` return the char line/col at end-of-input; the aliases map per the catalog (`tail`→`drop_front`, `drop_last`→`drop_back`, `flatten`→`flat`) with `flat` added if absent; resolve the alias-retirement question (book §catalog says "retired alias", `ROADMAP_V2` says "remain compatibility syntax") against the Perl reference before landing; tests; baseline green; clippy clean.
  Commit: `RUST-PARITY.5.5.2 — input-boundary helpers + flat splice in the Rust engine`; prior node reference: `RUST-PARITY.5.5.2` (see Commit Log); retained completion note: engine.rs +3 `call_helper` arms (`input_end_line`/`input_end_col`/`flat`) + 3 tests; retired aliases resolved out; 207/207 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.5.2`.

- ID: `RUST-PARITY.5.5.3`
  Status: `done`
  Goal: Mark-based capture family — `capture_*_from` (`capture_len_from`, `capture_until_cursor_from`, `capture_take_until_cursor_from`, `capture_take_len_from`, `capture_rest_from`, `capture_take_rest_from`), `capture_between`/`capture_len_between`, and `mark_copy`/`mark_input_start`/`mark_input_end`
  Acceptance: each reads the named mark(s) (byte offsets) and returns char-correct text/length per the catalog; `mark_*` set marks; tests with multibyte input; baseline green; clippy clean.
  Commit: `RUST-PARITY.5.5.3 — mark-based capture family in the Rust engine`; prior node reference: `RUST-PARITY.5.5.3` (see Commit Log); retained completion note: engine.rs `capture_from` fixed to match-start + 15 new mark-family arms + `span_text`/`span_char_len` + 16 tests; catalog §7 corrected; knowledge card; 223/223 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.5.3`.

- ID: `RUST-PARITY.5.5.4`
  Status: `done`
  Goal: Anonymous capture-slice variants — `capture_slice_until_cursor`, `capture_take_until_cursor`, `capture_take_len`, `capture_take_rest` (and any `_len` variants from the inventory). **Also fix the existing anonymous `capture_slice`/`capture_slice_len` endpoint** (discovered in `.5.5.3`): they read to `ctx.pos` (cursor/match-end) but the contract (`Contracts.pm` CAPTURE_SLICE = `$LSPOS - $IPOS - length $LMATCH`) and the now-corrected catalog §7 say they end at the **start of the current match** (`ctx.match_start_byte`).
  Acceptance: each operates on the anonymous `capture_start`/cursor per the catalog, char-correct; the anonymous `capture_slice`/`capture_slice_len` endpoint matches match-start (closing the catalog↔Rust gap `.5.5.3` opened in the book); tests; baseline green; clippy clean.
  Commit: `RUST-PARITY.5.5.4 — anonymous capture-slice family in the Rust engine`; prior node reference: `RUST-PARITY.5.5.4` (see Commit Log); retained completion note: engine.rs `capture_slice`/`_len` fixed to match-start + 10 new anonymous arms (`until_cursor`/`take`/`rest`) + 10 tests; catalog §7 anonymous entries added; 2 landed tests updated; `.5.5` + `.5` closed; knowledge card; 233/233 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.5.5.4`.

- ID: `RUST-PARITY.6`
  Status: `done`
  Goal: Implement strict_syntax validation mode
  Acceptance: strict_syntax mode rejects reference warnings as hard errors; test covering strict mode
  Commit: `RUST-PARITY.6 — strict_syntax validation mode in the Rust variant`; prior node reference: `RUST-PARITY.6` (see Commit Log); retained completion note: validation.rs `validate_with_options(spec, strict)` + `check_unused_rules` (unused-rule warning → hard error; undefined already fatal); `validate` kept as non-strict wrapper; 4 tests; Perl semantics verified empirically; knowledge card; 237/237 green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.6`.

- ID: `RUST-PARITY.7`
  Status: `done`
  Goal: Expand the Rust test corpus to match Perl's regression coverage breadth — via a Perl↔Rust output oracle
  Children: `.7.1`, `.7.2`, `.7.3`, `.7.4`, `.7.5`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7`.

- ID: `RUST-PARITY.7.1`
  Status: `done`
  Goal: Build the Perl↔Rust output-oracle mechanism + canonical comparison form + first proof
  Acceptance: a timeout-guarded Perl oracle generator (`tools/`) emits canonical-JSON fixtures into `rust/linkedspec-runtime/tests/corpus/`; a language-neutral fixture format is defined (spec reference + input + expected canonical JSON); a Rust fixture-runner integration test enumerates the corpus and asserts `engine.execute(input)` matches the fixture under the documented Perl↔Rust output-shape rule; the wrapping/canonical mapping (Perl `X` vs Rust `[X]`) is reconciled and documented; proven end-to-end on `tclite` (`[]`, `""`) + `Lispish` (`(x y)`); `cargo test` + clippy zero-new vs baseline (runtime 13, core 10 / validation.rs 4); the 237-test baseline stays green.
  Commit: `RUST-PARITY.7.1 — Perl↔Rust output-oracle mechanism + green first proof`; prior node reference: `RUST-PARITY.7.1` (see Commit Log); retained completion note: new `tools/gen_oracle_corpus.pl` (timeout-guarded Perl generator) + `rust/linkedspec-runtime/tests/corpus_oracle.rs` runner + `tests/corpus/` (2 authored proof fixtures + README); oracle caught tclite/Lispish divergence → new leaf `.7.5`; 238/238 green; knowledge card
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.1`.

- ID: `RUST-PARITY.7.2`
  Status: `done`
  Goal: Expand the oracle corpus to the structurally simple specs (batch 1), authoring inputs
  Acceptance: representative inputs authored + fixtures generated for a first batch of clean specs (candidate set: `BNF`, `ebnf`, `DT`, `ifelse`, `operators_try`, `portmap`, `lib_reader` — exact set decided in-slice); the Rust fixture-runner is green over them; any Perl↔Rust divergence is either fixed in the engine or recorded as a deferred follow-up with evidence; `cargo test` + clippy zero-new; baseline green.
  Commit: `RUST-PARITY.7.2 - expand shipped-spec oracle batch`; prior node reference: `pending`; retained completion note: parser header-rest multiline lifecycle fix; Rust captures-only entry/match group indexing; two `hlink_substitution` raw-string oracle fixtures; 65-fixture corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.2`.

- ID: `RUST-PARITY.7.3`
  Status: `done`
  Goal: Expand the oracle corpus to the remaining/harder specs (batch 2), with timeout/hang risk debugged before
    more broad shipped-spec work.
  Children: `.7.3.1`, `.7.3.2`, `.7.3.3`, `.7.3.4`, `.7.3.5`, `.7.3.6`, `.7.3.7`
  Acceptance: inputs authored + fixtures generated (timeout-guarded) for the remaining specs incl. legacy/plugin/RTL-touching ones (candidate set: `pplugin`, `vhdl`, `simenv`, `tablegrep`, `sdce`, `regdef`, `tkgui`, remaining non-raw `hlink_substitution` delimiter paths, `ds_vhistory`, `verilog`, `spec.spec` — exact set decided in-slice); any current timeout/hang risk is reproduced with LinkedSpec's toolbox first, pinpointed to exact source/rule/regex evidence, and either fixed or proven stale/retired before the broad legacy/plugin/RTL smoke lane continues; parity gaps fixed or recorded; the Rust fixture-runner is green; `cargo test` + clippy zero-new; baseline green.
  Commit: `pending`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3`.

- ID: `RUST-PARITY.7.3.1`
  Status: `done`
  Goal: Split batch-2 shipped-spec oracle work into narrow, evidence-backed lanes, with timeout debugging first.
  Acceptance: Record why `.7.3` is too broad for one signoff slice, preserve `.7.2`'s known divergence evidence,
    split candidate families into follow-up leaves, make the timeout/hang investigation the immediate owned
    frontier, update live trackers and Knowledge Map, and avoid runtime/corpus code changes.
  Commit: `RUST-PARITY.7.3.1 - split batch-2 oracle lanes and timeout owner`; retained completion note: no runtime/corpus code change; splits the broad remaining shipped-spec oracle batch into timeout/hang investigation, hlink, simple-spec divergence, action-parser/null-output, and RTL/plugin/legacy lanes
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.1`.

- ID: `RUST-PARITY.7.3.2`
  Status: `done`
  Goal: Debug and resolve the shipped-spec oracle timeout/hang risk with LinkedSpec trace/toolbox evidence.
  Acceptance: Verify whether the historical `RTLUtils` timeout/hang reference is live in the current tree or stale
    after legacy retirement/noncore quarantine; run LinkedSpec's toolbox before guessing (fork+SIGKILL hard-timeout
    census for any live hang, then `LINKEDSPEC_TRACE_LEVEL=debug` / per-call trace options / parser-source dumps
    on the exact reproducer); record the exact source file, rule, regex, and call path if a hang is live; either
    fix the live root cause under this leaf or split a narrower implementation owner with evidence before code; if
    the timeout is stale, update generator/corpus/task/KM wording so it says the historic RTLUtils hang is retired
    while retaining a generic safety guard for future pathological specs.
  Commit: `RUST-PARITY.7.3.2 - harden oracle timeout guard`; retained completion note: tools/gen_oracle_corpus.pl now enforces per-case fork/SIGKILL timeouts; historic RTLUtils timeout verified retired from current core; corpus README and KM wording updated
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.2`.

- ID: `RUST-PARITY.7.3.3`
  Status: `done`
  Goal: Try the remaining `hlink_substitution` delimiter/link-path shipped-spec fixtures.
  Children: `.7.3.3.1`, `.7.3.3.2`, `.7.3.3.3`, `.7.3.3.4`
  Acceptance: Author representative non-raw `hlink_substitution` inputs, regenerate fixtures with the timeout
    guard, keep `corpus_oracle` green if they match, or record exact divergence evidence and split a narrower
    fix leaf before changing engine behavior.
  Verification: Done/closed 2026-07-03 — JSON-safe `{abc}` is active; bracket/mixed scalar-ref cases are
    deliberately deferred under `.7.3.3.4` with Perl/Rust evidence and do not block `.7.3.4`.
  Commit: `pending`

- ID: `RUST-PARITY.7.3.3.1`
  Status: `done`
  Goal: Triage and split the remaining `hlink_substitution` delimiter fixture candidates before code.
  Acceptance: Read the shipped spec and existing hlink tests/fixtures, identify which non-raw inputs are
    JSON-safe fixture candidates, identify any oracle-representation blockers, split follow-up leaves, and avoid
    generator/corpus/runtime changes.
  Commit: `RUST-PARITY.7.3.3.1 - split hlink delimiter fixtures`; retained completion note: no generator/corpus/runtime code change; splits JSON-safe curly fixture from scalar-ref bracket/mixed representation work
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.3.1`.

- ID: `RUST-PARITY.7.3.3.2`
  Status: `done`
  Goal: Add the JSON-safe `hlink_substitution` curly-brace delimiter fixture.
  Acceptance: Add a representative `{abc}` fixture to the oracle generator, regenerate fixtures with the hardened
    timeout guard, prove Rust `corpus_oracle` remains green, update live docs/KM, and leave scalar-ref bracket
    cases untouched.
  Commit: `RUST-PARITY.7.3.3.2 - add hlink curly oracle fixture`; retained completion note: added `hlink_curly_brace` for `{abc}` to the oracle generator and checked-in corpus; 66-fixture corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.3.2`.

- ID: `RUST-PARITY.7.3.3.3`
  Status: `done`
  Goal: Decide the cross-variant oracle representation for `hlink_substitution` scalar-ref bracket outputs.
  Acceptance: Define whether/how Perl scalar references in reference ASTs are canonicalized into the JSON oracle,
    probe Rust's representable output for `[abc]` and mixed `foo[bar]{baz}`, then either implement a neutral
    representation with tests/docs or explicitly defer bracket/mixed hlink fixtures with evidence.
  Commit: `RUST-PARITY.7.3.3.3 - defer hlink scalar-ref fixtures`; retained completion note: no generator/corpus/runtime code change; records Perl scalar-ref JSON failure plus Rust scalar-ref action-branch failure and defers bracket/mixed fixtures to `.7.3.3.4`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.3.3`.

- ID: `RUST-PARITY.7.3.3.4`
  Status: `deferred`
  Goal: Implement or retire `hlink_substitution` scalar-ref bracket/mixed oracle support.
  Acceptance: Reopen only when the project chooses one language-neutral path: either define a tagged scalar-ref
    JSON oracle contract and add Rust action-parser/runtime support for the current `return(\(...))` payload shape,
    or migrate `specs/hlink_substitution.spec` so bracket payloads use portable value shapes instead of Perl scalar
    references. Then add `[abc]` and `foo[bar]{baz}` oracle fixtures and keep `corpus_oracle` green.
  Verification: Deferred 2026-07-03 by `.7.3.3.3` evidence: Perl emits scalar refs that `JSON::PP` cannot encode,
    and Rust currently cannot execute the scalar-ref action branch in `hlink_substitution`.
  Commit: Deferred by `RUST-PARITY.7.3.3.3 - defer hlink scalar-ref fixtures`

- ID: `RUST-PARITY.7.3.4`
  Status: `done`
  Goal: Triage `.7.2` simple-spec structural divergences (`portmap`, `lib_reader`, `ebnf`).
  Acceptance: Reproduce each recorded mismatch with the oracle/toolbox path, classify whether the first fix is in
    parser, compiler, runtime, or fixture selection, land only a safe green fixture or split an implementation leaf
    with evidence.
  Commit: `RUST-PARITY.7.3.4 - triage structural oracle mismatches`; retained completion note: no runtime/corpus code change; reproduces `portmap`/`lib_reader`/`ebnf` Rust structural divergences and splits parser/runtime implementation owners into `.7.3.4.1`-`.7.3.4.3`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.4`.

- ID: `RUST-PARITY.7.3.4.1`
  Status: `done`
  Goal: Fix Rust parser/compiler handling for header-rest action edges on regex-less top rules, starting with
    `lib_reader`'s `lib_file:: -> group .push`.
  Acceptance: The Rust compiled `lib_file` rule contains the `group` action-edge fluent push; the representative
    `lib_reader` sattribute and cattribute inputs reproduce the Perl wrapped `GROUP` AST through the oracle path or
    are cleanly blocked by a later runtime owner with evidence; focused parser/compiler/runtime tests pass.
  Commit: `RUST-PARITY.7.3.4.1 - fix header-rest action-edge parsing`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.4.1`.

- ID: `RUST-PARITY.7.3.4.4`
  Status: `done`
  Goal: Fix Rust runtime capture propagation for dependency-resolved action-edge child regex matches exposed by
    `lib_reader`.
  Acceptance: `entry_group(0)` and `entry_group(1)` in child rules reached through a parent edge-only,
    dependency-resolved child regex expose the actual child match captures instead of null values; representative
    `lib_reader` sattribute and cattribute inputs reproduce the Perl wrapped `GROUP` AST through the oracle path or
    split again with narrower runtime evidence; focused runtime tests pass.
  Commit: `RUST-PARITY.7.3.4.4 - land lib_reader action-helper parity`; retained completion note: engine.rs statement-form scalar regex substitution + array split mutation helpers; `.7.3.4.4` integration locks; two `lib_reader` oracle fixtures; 68-fixture corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.4.4`.

- ID: `RUST-PARITY.7.3.4.2`
  Status: `done`
  Goal: Fix Rust runtime helper/list-context parity exposed by `portmap` scalar classification.
  Acceptance: Rust recognizes the Perl helper surface needed by `portmap` conditionals (`or` at minimum, plus any
    sibling boolean helper proved necessary) and splices list-context array helper payloads so
    `array(flat_array(entry_parts))` matches the Perl shape; `foo`, `bar[3]`, `baz[7:0]`, and `0x1f` can be added
    or proven blocked with exact remaining evidence; focused runtime tests pass.
  Commit: `RUST-PARITY.7.3.4.2 - land portmap scalar helper parity`; retained completion note: boolean helper/list-context/regex-dispatch parity; four `portmap` scalar oracle fixtures; 72-fixture corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.4.2`.

- ID: `RUST-PARITY.7.3.4.3`
  Status: `done`
  Goal: Fix Rust action-edge fluent child/target aggregation semantics for recursive/grammar-file payloads.
  Acceptance: `push(child, target)` and no-arg `.push` on action edges match the Perl child-call/target semantics
    for `ebnf` rule payloads and `portmap` concatenation; the representative `ebnf_expression_rules`,
    `ebnf_logging_annotation`, and `portmap` concatenation cases either become green oracle fixtures or are split
    again with narrower evidence.
  Commit: `RUST-PARITY.7.3.4.3 - land action-edge child aggregation parity`; retained completion note: edge-scoped child returns, passive terminal child skip, lower-unbounded quantifier normalization; `portmap_concatenation` plus two `ebnf` fixtures; 77-fixture corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.4.3`.

- ID: `RUST-PARITY.7.3.5`
  Status: `done`
  Goal: Triage `.7.2` action-parser/null-output candidates (`BNF`, `DT`, `ifelse`, `operators_try`, and
    `spec.spec` smokes).
  Acceptance: Reproduce the `[]`/`[null]`/action-parser-warning behavior under timeout, separate invalid fixture
    choice from real Rust parity gaps, and land or defer each case with precise evidence.
  Commit: `RUST-PARITY.7.3.5 - close null-output and spec smoke triage`; retained completion note: quoted-brace code-block scanner fix; four `spec.spec` smokes; BNF/DT/ifelse/operators_try null-output candidates documented; 81-fixture corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.5`.

- ID: `RUST-PARITY.7.3.6`
  Status: `done`
  Goal: Audit RTL/plugin/legacy shipped-spec candidates (`pplugin`, `vhdl`, `simenv`, `tablegrep`, `sdce`,
    `regdef`, `tkgui`, `ds_vhistory`, `verilog`) under the oracle timeout guard.
  Acceptance: Pick minimal representative inputs after `.7.3.2` has resolved or retired the timeout/hang concern,
    keep the generic guard active during generation, keep green fixtures only when Rust matches the Perl reference,
    and route plugin/RTL-only blockers to explicit follow-up leaves instead of broadening `.7.3`.
  Commit: `RUST-PARITY.7.3.6 - land legacy shipped-spec safety smokes`; retained completion note: seven RTL/plugin/legacy green smokes; richer mismatches routed to follow-up; 88-fixture corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.6`.

- ID: `RUST-PARITY.7.3.7`
  Status: `done`
  Goal: Re-run the timeout/hang investigation with LinkedSpec trace/toolbox evidence after the user-directed
    correction to debug the timeout "once and for all."
  Acceptance: Build a current shipped-spec/input census that runs each candidate under a fork+SIGKILL wall-clock
    guard; if any case times out, rerun that exact spec/input path with `LINKEDSPEC_TRACE_LEVEL=debug`,
    per-call trace options, parser-source dumps, and descriptor/runtime context as applicable; pinpoint the exact
    file, rule, regex/action path, and source location; then either fix the live root cause under this leaf or split
    a narrower implementation leaf before changing runtime/compiler behavior. If no current timeout exists, record
    the trace/toolbox evidence and preserve the hard-timeout guard as the permanent broad-corpus safety net.
  Commit: `RUST-PARITY.7.3.7 - hard-timeout parser construction too`; retained completion note: oracle generator now hard-timeout guards parser construction plus parse execution; normal regeneration remains 66-fixture byte-identical; corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.3.7`.

- ID: `RUST-PARITY.7.4`
  Status: `done`
  Goal: Regression guard + finalize the oracle corpus
  Acceptance: the fixture-runner provably enumerates ALL corpus fixtures (fails on drift / a missing fixture); a documented way to regenerate fixtures; a book/`DEVELOPMENT_NOTES.md` note on the oracle (incl. the Perl↔Rust wrap rule) as warranted; `.7` closed when every child is `done`/`deferred`.
  Commit: `RUST-PARITY.7.4 - finalize oracle corpus manifest guard`; retained completion note: generator writes manifest and rejects duplicate cases; Rust runner rejects missing/stale fixture drift and executes 88 fixtures in manifest order; `.7` closed
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.4`.

- ID: `RUST-PARITY.7.5`
  Status: `done`
  Goal: Rust engine output-parity fixes for shipped recursive specs — unblock the oracle corpus (`.7.2`/`.7.3`). Discovered by `.7.1`'s oracle.
  Children: `.7.5.1` (done), `.7.5.2` (done), `.7.5.3` (done)
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.5`.

- ID: `RUST-PARITY.7.5.1`
  Status: `done`
  Goal: Fix the header-line-regex → 0-regex parser bug (the shared root cause for tclite + Lispish + most shipped specs)
  Acceptance: a rule with a regex on its **header line** registers that regex (today it is silently dropped, so `-> child[0]` edges "never fire"). **Root cause (confirmed):** `rust/linkedspec-core/src/parser.rs:86` — the header regex `^(\w+)[ \t]*(::|:)[ \t]*(\S*)[ \t]*(.*)` uses `(\S*)` for the mode suffix (group 3 `mode_raw`), which greedily swallows a leading `/…/` regex on the header line; `parse_mode_suffix("/;/")` then falls to `RuleMode::Default` and the regex is discarded (never reaches `rest`/body). It bites BOTH `:` and `::` rules that put a regex on the header line — the passing tests/`::` top-rules only avoid it because they put the regex on a **separate body line** (`Child::` then `/…/`). **Fix:** narrow group 3 to `([^\s/]*)` so a `/`-led regex falls through to `rest` (group 4), where `parse_inline_body` registers it. The bracket-pair semantics are not just preserved but **repaired** — verified.
  Commit: `RUST-PARITY.7.5.1 — fix the header-line-regex → 0-regex parser bug in the Rust variant`; prior node reference: `RUST-PARITY.7.5.1` (see Commit Log); retained completion note: parser.rs:86 `(\S*)`→`([^\s/]*)`; header-line regexes now register, bracket-pairs repaired (open[0]/close[1]); 4 unit tests (3 parser + 1 compiler); 242/242 green; clippy zero-new. Oracle revealed a 2nd tclite blocker (action-edge fluent lowering) → new leaf `.7.5.3`; tclite oracle cases re-deferred
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.5.1`.

- ID: `RUST-PARITY.7.5.2`
  Status: `done`
  Goal: Add `{…}` hash-literal / field-accessor support to the Rust action-code expression parser (the second Lispish gap)
  Acceptance: `scalaref(retv, {content})` parses and evaluates (extract the named field from the referenced hash) so Lispish `(x y)` reproduces the Perl reference `["x",["y"]]`. **Root cause (confirmed):** `rust/linkedspec-core/src/expr.rs:299` — `parse_expr` has no `{` case (no hash/object/field-accessor syntax in the expression language), so `{content}` raises `unexpected character '{'`. **Scope:** larger than `.7.5.1` — needs a new `Expr` variant + parser production + engine evaluation (`scalaref(ref, {field})` reads `field` from the hash the ref points at). Decide the exact `{…}` semantics against the Perl reference (`specs/Lispish.spec:40-43`, `scalaref(retv, {content})`; line 78 `CAPTURE`) before implementing. Depends on `.7.5.1` (done — the Lispish child rules now register their regexes). **Note:** Lispish uses `{ code }` blocks on its edges (not the fluent form), so it does NOT need `.7.5.3`; `.7.5.1` + `.7.5.2` should green it. Re-enable the Lispish case in `tools/gen_oracle_corpus.pl`; fixture-runner green; baseline + green; clippy zero-new.
  Commit: `RUST-PARITY.7.5.2 - land Lispish scalaref parity` (see Commit Log); retained completion note: expr.rs `ScalarRefPath` parser hook + runtime legacy scalaref path evaluation, child-return accumulator containment, explicit action-block call compatibility, aggregate-wrapper assignment replacement, active `lispish_x_y` fixture; 63-fixture corpus oracle green
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.5.2`.

- ID: `RUST-PARITY.7.5.3`
  Status: `done`
  Goal: Lower action-edge fluent continuations (`.push` / `.return(...)` after a `-> edge`) so tclite reproduces the Perl reference (the second, independent tclite blocker the `.7.5.1` oracle uncovered)
  Acceptance: a fluent `.method(...)` chain written after an ACTION edge (`-> Child .push`, `-> Child[1] .return(...)`) is attached to that edge and executed after dispatching the child (push the child result into the rule's accumulator / route the value to `return`), matching the BLIND-edge (`=>`) fluent behavior that already works. **Root cause (confirmed):** the Rust parser attaches a `.method` fluent chain only to a BLIND edge — `parse_single_element` calls `parse_fluent_chain(&rest)` for `=>` (`parser.rs:443`) but for `->` only captures a following `{ }` block (`parser.rs:411-429`); a trailing `.push`/`.return(...)` after a `->` edge therefore parses as a STANDALONE `FluentChain` body element, which the compiler discards (`compiler.rs:171`, `BodyElementKind::FluentChain { .. } => { last_regex_line = None; }` — no codegen). So tclite's `-> command_subst .push` / `-> command_subst[1] .return(...)` dispatch but never accumulate/return, and tclite still yields `[]` even after `.7.5.1` registered the regexes. **Scope:** parser (add a `fluent_chain` field to `BodyElementKind::ActionEdge`, parse the chain after a `->` edge), compiler (lower the chain onto the `AcodeEntry` — like `BcodeEntry.fluent_chain`, or synthesize an attached code block), engine (execute the attached chain after `execute_rule` in the acode-dispatch loop, `engine.rs:340-351`). Decide `.push`/`.return(...)` semantics against the Perl reference (`specs/tclite.spec`; `push(child)` = append the dispatched child's result, `return(...)` = the rule's return). Re-enable the tclite cases (`[]`, `""`) in `tools/gen_oracle_corpus.pl`, regenerate, confirm the fixture-runner is green (`[]`→`["?tcl_script:",[["?command_subst:",[]]]]`, `""`→`["?tcl_script:",[["?double_quote:",[]]]]`). `cargo test` baseline + green; clippy zero-new.
  Commit: `RUST-PARITY.7.5.3 - reconcile action-edge fluent closure` (see Commit Log); retained completion note: no runtime code change; closes stale parity leaf against `SPEC-FORMAT-TERSE.2.3.3.*` implementation evidence, active `tclite_*` oracle fixtures, and current 62-fixture corpus oracle
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.7.5.3`.

- ID: `RUST-PARITY.8`
  Status: `done`
  Goal: Implement code-gen emitter — HandlerIR/CompiledSpec to Rust source generation
  Children: `.8.1` (done), `.8.2` (done), `.8.3` (done/split), `.8.4` (done), `.8.5` (done)
  Acceptance: Rust source emitter produces compilable Rust from HandlerIR/CompiledSpec nodes; tests prove generated code compiles and runs; final all-variant matrix covers the 10 HandlerIR variant families or explicitly documented Rust-native equivalents
  Commit: `pending` (container closes through child commits)
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8`.

- ID: `RUST-PARITY.8.1`
  Status: `done`
  Goal: Split and inventory the Rust source-emitter lane before implementation
  Acceptance: `.8` is decomposed into child leaves; the first implementation leaf is narrow enough to review; live docs and Knowledge Map record that Rust currently interprets `CompiledSpec`, while `.8` will add an emitted-source path from the HandlerIR/CompiledSpec structural contract
  Commit: `RUST-PARITY.8.1 - split Rust source emitter lane` (see Commit Log); retained completion note: no source behavior change; splits generated Rust-source work into scaffold/harness, non-REP families, REP families, and all-variant/oracle integration
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.1`.

- ID: `RUST-PARITY.8.2`
  Status: `done`
  Goal: Add the minimal Rust source-emitter scaffold and compile/run harness
  Acceptance: A focused emitter API can render a minimal generated Rust parser module from the Rust structural contract; a test builds that generated source in an isolated temporary crate or build harness and executes one simple non-recursive parser case; the interpreter path remains unchanged
  Commit: `RUST-PARITY.8.2 - add Rust source emitter scaffold` (see Commit Log); retained completion note: new `source_emitter` module emits a standalone Rust module from `CompiledSpec`; isolated temp-crate compile/run harness proves a simple generated parser that delegates through `Engine`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.2`.

- ID: `RUST-PARITY.8.3`
  Status: `done/split`
  Goal: Emit non-repetition handler families
  Children: `.8.3.1` (done), `.8.3.2` (done), `.8.3.3` (done), `.8.3.4` (done), `.8.3.5` (done)
  Acceptance: Generated Rust covers default, OR, AND single/sequential acode, AND bcode, and OR bcode structural families with representative compile/run tests and parity against the interpreter/oracle for focused fixtures
  Note: Split 2026-07-04 (PNT rule 5). A source audit for the first implementation pass found `.8.3` still bundles multiple independently-reviewable mechanisms: Rust `CompiledRule` lacks enough rule-mode metadata to distinguish OR-bcode from AND-bcode robustly; generated source needs an explicit family plan before per-family runtime execution can be proven; acode, bcode, and final matrix coverage have separate risks and test shapes. No Rust code changed in this split.
  Verification: Done — `.8.3.1` added generated family-plan metadata, `.8.3.2` added direct default/OR acode execution, `.8.3.3` added direct AND acode execution, `.8.3.4` added direct AND/OR bcode execution, `.8.3.5` closed the non-repetition generated-family matrix, and `.8.4` added direct REP generated-family execution. `.8.5` later added the manifest-backed generated-source corpus-subset proof, and `.9` closed the tree.
  Commit: `RUST-PARITY.8.3 - split non-repetition emitter lane` (see Commit Log); retained completion note: no source behavior change; splits non-repetition generated-family emission into `.8.3.1` family metadata/plan, `.8.3.2` default/OR acode, `.8.3.3` AND acode, `.8.3.4` AND/OR bcode, and `.8.3.5` matrix closeout

- ID: `RUST-PARITY.8.3.1`
  Status: `done`
  Goal: Carry rule-mode/family metadata and emit a generated non-REP family plan
  Acceptance: `CompiledRule` preserves enough parsed mode metadata to classify non-repetition generated families; `emit_rust_source` emits an explicit family plan for supported default/OR/AND acode-bcode shapes; focused generated-source tests prove the emitted plan compiles and still executes through the existing harness while leaving direct family execution to later children
  Commit: `RUST-PARITY.8.3.1 - emit generated family plan` (see Commit Log); retained completion note: preserves parsed `RuleMode` in `CompiledRule`; generated Rust source now embeds and validates a non-REP family plan across default/OR/AND acode-bcode cases while still delegating execution through `Engine`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.3.1`.

- ID: `RUST-PARITY.8.3.2`
  Status: `done`
  Goal: Emit direct default and OR acode execution
  Acceptance: Generated-source execution covers default and OR acode structural families without whole-parser delegation, with focused compile/run tests matching interpreter and Perl-oracle expectations for representative fixtures
  Commit: `RUST-PARITY.8.3.2 - emit direct default-or acode execution` (see Commit Log); retained completion note: generated source entered a plan-aware executor; default and OR acode families ran directly, with later leaves owning the remaining non-repetition and REP families
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.3.2`.

- ID: `RUST-PARITY.8.3.3`
  Status: `done`
  Goal: Emit direct AND acode execution
  Acceptance: Generated-source execution covers AND single-acode and AND sequential-acode structural families, including ordered consume behavior, with focused compile/run tests matching interpreter and Perl-oracle expectations for representative fixtures
  Commit: `RUST-PARITY.8.3.3 - emit direct AND acode execution` (see Commit Log); retained completion note: generated source now directly handles AND single-acode and AND sequential-acode; shared Rust loop enforces ordered AND regex/acode sequence before completion
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.3.3`.

- ID: `RUST-PARITY.8.3.4`
  Status: `done`
  Goal: Emit direct AND/OR bcode execution
  Acceptance: Generated-source execution covers AND bcode sequential dispatch and OR bcode first-match dispatch with focused compile/run tests matching interpreter and Perl-oracle expectations for representative fixtures
  Commit: `RUST-PARITY.8.3.4 - emit direct bcode execution` (see Commit Log); retained completion note: generated source now directly handles AND/OR bcode; blind-edge tail execution is shared and OR bcode stops after the first truthy child return
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.3.4`.

- ID: `RUST-PARITY.8.3.5`
  Status: `done`
  Goal: Close the non-repetition generated-family matrix
  Acceptance: The generated-source test matrix covers every non-repetition family named by `.8.3`, documents any Rust-native equivalent boundaries, and advances the `.8` frontier to REP families only when the non-REP generated-source path is green
  Commit: `RUST-PARITY.8.3.5 - close non-REP generated matrix` (see Commit Log); retained completion note: generated-plan routing is exhaustive for all non-REP generated families; source-emitter matrix asserts complete non-REP family coverage; REP remains the only fallback
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.3.5`.

- ID: `RUST-PARITY.8.4`
  Status: `done`
  Goal: Emit repetition handler families and termination guards
  Acceptance: Generated Rust covers REP acode, REP bcode, REP-AND acode, and REP-AND bcode structural families, including min/max bounds and zero-progress/recursion termination behavior; representative compile/run tests pass
  Commit: `RUST-PARITY.8.4 - emit REP generated families` (see Commit Log); retained completion note: generated source classifies and directly runs explicit REP families; source-emitter matrix covers REP subfamilies, termination guards, and legacy `Repetition` compatibility
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.4`.

- ID: `RUST-PARITY.8.5`
  Status: `done`
  Goal: Integrate generated-source validation with the oracle/corpus contract
  Acceptance: Generated-source execution is validated across an all-variant smoke matrix and at least one manifest-backed corpus subset; documented limitations are explicit; `.8` closes only when generated Rust source has compile/run proof for every supported structural family
  Commit: `RUST-PARITY.8.5 - integrate generated source with oracle corpus` (see Commit Log); retained completion note: source-emitter test now validates generated source against all supported structural families plus a manifest-backed 8-case oracle corpus subset
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.8.5`.

- ID: `RUST-PARITY.9`
  Status: `done`
  Goal: Documentation sync and finalization — update book, roadmap, live docs
  Acceptance: ROADMAP_V2.md tracker updated; CHANGES.md + DEVELOPMENT_NOTES.md + MEMORY.md updated; book backend-handoff.md refreshed; ARCHITECTURE_STATE.md updated
  Commit: `RUST-PARITY.9 - finalize Rust parity documentation` (see Commit Log); retained completion note: Rust parity follow-on tree closed; roadmap/live docs/book/architecture state synchronized; next PNT leaf routed to `TOP-RULE-AS-NORMAL.3.2`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.25`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree RUST-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.25 --id RUST-PARITY.9`.

## Current Frontier

| Order | Leaf | Status | Why next |
| --- | --- | --- | --- |
| — | `RUST-PARITY.4` | `superseded` | Rust-self-hosting on spec.spec dropped; parity = reproducing BootstrapSpec::Core output (see Decisions audit) |
| — | `RUST-PARITY.5.1` | `done` | retv-propagation BLOCKER fixed (2026-06-16); child return now readable as `scalar(retv)` after `->`/`=>`/REP dispatch |
| — | `RUST-PARITY.8.2` | `done` | minimal generated-source scaffold and isolated compile/run harness landed; generated code currently delegates through the interpreter |
| — | `RUST-PARITY.8.3` | `done/split` | non-repetition generated-family lane split into metadata/plan, acode, bcode, and matrix children |
| — | `RUST-PARITY.8.3.1` | `done` | generated rule-mode/family metadata and family-plan validation landed; generated source still delegated through the interpreter |
| — | `RUST-PARITY.8.3.2` | `done` | generated-plan executor now directly handles default and OR acode families before falling back for later-family lanes |
| — | `RUST-PARITY.8.3.3` | `done` | generated-plan executor now directly handles AND single-acode and AND sequential-acode, including ordered consume semantics |
| — | `RUST-PARITY.8.3.4` | `done` | generated-plan executor now directly handles AND bcode sequential dispatch and OR bcode first-match dispatch |
| — | `RUST-PARITY.8.3.5` | `done` | non-repetition generated-family matrix closed; direct generated execution covers all six non-REP families |
| — | `RUST-PARITY.8.4` | `done` | REP generated families and termination guards landed |
| — | `RUST-PARITY.8.5` | `done` | generated-source validation now combines the all-family matrix with a manifest-backed oracle corpus subset |
| — | `RUST-PARITY.9` | `done` | documentation/finalization closed the tree and routed PNT to `TOP-RULE-AS-NORMAL.3.2` |
| — | `RUST-PARITY.5.2` | `done` | match_*/entry_* split landed (2026-06-16); entry = dispatcher's match, local = own match, per-handler lexical save/restore |
| — | `RUST-PARITY.5.3` | `done` | char-based indexing + cursor line/col landed (2026-06-16); byte-internal, char-exposed; entry/match spans stored |
| — | `RUST-PARITY.5.4` | `done` | dedupe match arms + REP zero-progress guard landed (2026-06-16); better hash/hash_copy/print arms live, REP breaks on no cursor progress |
| — | `RUST-PARITY.5.5` | `done` | split into `.5.5.1`–`.5.5.4` (2026-06-16, PNT rule 5 — ~28 helpers across families), all children closed |
| — | `RUST-PARITY.5.5.1` | `done` | named-group helpers landed (2026-06-16); entry/match `_named`/`_has`/`_map`(+`_named_map` alias) read the existing maps, deterministic hash projection |
| — | `RUST-PARITY.5.5.2` | `done` | input-boundary helpers + `flat` landed (2026-06-16); Open Question resolved — retired aliases `tail`/`drop_last`/`flatten` NOT added (Perl reference doesn't recognize them; parity = match the reference) |
| — | `RUST-PARITY.5.5.3` | `done` | mark-based capture family landed (2026-06-16); `capture_*_from`/`_between` + `mark_input_*`/`mark_copy`, `capture_from` fixed to match-start parity (option (a)); catalog §7 corrected |
| — | `RUST-PARITY.5.5.4` | `done` | full anonymous capture-slice family landed (2026-06-16); `capture_slice`/`_len` endpoint fixed to match-start + 10 anonymous arms (`until_cursor`/`take`/`rest` families); catalog §7 anonymous entries added; `.5.5` + `.5` containers closed |
| — | `RUST-PARITY.6` | `done` | strict_syntax validation mode landed (2026-06-16); `validate_with_options(spec, strict)` promotes the unused-rule warning to a hard error (undefined already fatal); Perl semantics verified empirically (top rule not exempt) |
| — | `RUST-PARITY.7` | `done` | split into `.7.1`–`.7.5` (2026-06-16 / `.7.5` added 2026-06-17 — oracle proved shipped specs needed lower-level parity fixes); manifest-backed corpus guard finalized in `.7.4` |
| — | `RUST-PARITY.7.1` | `done` | oracle mechanism + canonical wrap rule + green first proof landed (2026-06-17); the oracle proved tclite/Lispish do NOT match (engine gap → `.7.5`), so the proof is on 2 controlled authored grammars |
| — | `RUST-PARITY.7.5` | `done` | all shipped recursive-spec blockers from `.7.1` are closed: header-line regexes, action-edge fluent/default-mode `tclite`, and Lispish after direct-access migration |
| — | `RUST-PARITY.7.5.1` | `done` | header-line-regex → 0-regex parser bug fixed (2026-06-17); `(\S*)`→`([^\s/]*)`; regexes on header lines register, bracket-pairs repaired (open[0]/close[1]); 4 unit tests; 242 green; clippy zero-new. Oracle then revealed a 2nd tclite blocker → `.7.5.3` |
| — | `RUST-PARITY.7.5.3` | `done` | action-edge fluent closure reconciled 2026-07-02 from committed `SPEC-FORMAT-TERSE.2.3.3.*` evidence; shipped `tclite` oracle fixtures are active and green |
| — | `RUST-PARITY.7.5.2` | `done` | Temporary Lispish legacy `scalaref(retv, {content})` parity landed 2026-07-02; `SCALAREF-RETIREMENT.3/.4` then migrated and removed the helper, while `lispish_x_y` remains active and green through direct access |
| — | `RUST-PARITY.7.2` | `done` | first shipped-spec batch landed: `hlink_substitution` raw-string cases plus Rust captures-only group parity; corpus 65 fixtures |
| — | `RUST-PARITY.7.3.1` | `done` | batch-2 oracle work split into timeout/hang, hlink, simple-spec divergence, null-output/action-parser, and RTL/plugin/legacy lanes |
| — | `RUST-PARITY.7.3.2` | `done` | historic RTLUtils timeout verified retired; oracle generator now enforces a process-level fork/SIGKILL hard timeout |
| — | `RUST-PARITY.7.3.3.1` | `done` | hlink delimiter candidates split after bracket outputs exposed a scalar-ref JSON representation gap |
| — | `RUST-PARITY.7.3.3.2` | `done` | added the JSON-safe `{abc}` hlink curly-brace delimiter fixture; corpus 66 fixtures |
| — | `RUST-PARITY.7.3.3.3` | `done` | bracket/mixed hlink scalar-ref fixtures deferred with Perl JSON failure and Rust action-branch evidence |
| — | `RUST-PARITY.7.3.3.4` | `deferred` | neutral scalar-ref/action-payload contract or hlink spec migration needed before bracket/mixed fixtures |
| — | `RUST-PARITY.7.3.7` | `done` | user-directed trace/toolbox timeout census fixed the oracle guard boundary so parser build and parse are both hard-timeout protected |
| — | `RUST-PARITY.7.3.4` | `done` | structural mismatch triage split owners for `portmap`, `lib_reader`, and `ebnf`; no unsafe fixture landed |
| — | `RUST-PARITY.7.3.4.1` | `done` | parser/compiler header-rest action edges now compile compact `lib_reader` top dispatch |
| — | `RUST-PARITY.7.3.4.4` | `done` | statement-form `substr`/`regex_subst` scalar mutation and `split(array, scalar, delim)` array mutation now let `lib_reader` fixtures pass |
| — | `RUST-PARITY.7.3.4.2` | `done` | runtime boolean/list-context parity and regex-dispatch isolation now let `portmap` scalar fixtures pass |
| — | `RUST-PARITY.7.3.4.3` | `done` | action-edge child/target aggregation now lets `ebnf` payloads and `portmap` concatenation pass |
| — | `RUST-PARITY.7.3.5` | `done` | null-output candidates separated from semantic fixtures; quoted-brace `operators_try` parser warning fixed; four `spec.spec` smokes active |
| — | `RUST-PARITY.7.3.6` | `done` | seven RTL/plugin/legacy safety smokes landed; richer mismatches routed to follow-up instead of broadening `.7.3` |
| — | `RUST-PARITY.7.4` | `done` | manifest-backed regression guard finalized the oracle corpus; runner rejects missing/stale fixture drift |
| — | `RUST-PARITY.8` | `done` | code-gen emitter lane split and closed; `.8.1` contract/inventory, `.8.2` scaffold/harness, `.8.3.*` non-REP direct execution, `.8.4` REP direct execution, and `.8.5` oracle/corpus subset integration are complete |
| — | `RUST-PARITY.9` | `done` | documentation sync + finalization closed the tree |

(`.5` split per PNT rule 5 — too broad for one signoff slice; `.5.5` further split the same way; all of `.5` now done. `.6` done. `.7` split the same way into `.7.1`–`.7.5`; all `.7.5` shipped recursive-spec blockers are closed, `.7.2` and `.7.3` expanded the shipped-spec corpus to 88 fixtures, `.7.4` finalized the manifest guard, and `.7` is closed. `.8` split the same way and is now closed: `.8.2` landed the generated-source scaffold/harness, `.8.3.1`–`.8.3.5` landed the non-REP family-plan, acode, bcode direct-execution slices, and matrix closeout, `.8.4` landed REP direct execution, and `.8.5` integrated generated-source validation with a manifest-backed corpus subset. `.9` closed roadmap/live-doc/book/architecture alignment and the `RUST-PARITY` tree is done.)

## Decisions

- `2026-06-16`: Created task tree. Conditional flow (if/switch) is priority after inventory because it's the largest feature gap affecting the most specs. Code-gen emitter is last because interpreted mode works and emitter needs stable HandlerIR shapes.
- `2026-06-16` (`.1`): Inventory complete. 6 gap categories identified.
- `2026-06-16` (`.2`): Conditional flow landed. Lazy evaluation required modifying `eval_expr` to intercept `if`/`switch`/`elseif`/`else`/`case`/`default` before eager arg evaluation. New method `call_helper_lazy` added. 12 new tests. 177/177 PASS.
- `2026-06-16` (audit): 3-agent Rust↔Perl parity audit found the REAL gaps (the actual follow-on, replacing the superseded self-hosting `.4`):
  - **BLOCKER**: child-return value (`retv`) is never propagated to the parent after `->`/`=>` dispatch — `return(expr)` only pushes to the top accumulator and `execute_rule` never sets a `retv` scalar, so `scalar(retv)` in `LE` resolves to undef → virtually every real grammar yields wrong/null output. (`engine.rs` execute_rule + runtime.rs; the in-flight `set_retv` is the half-built, dead fix.)
  - MAJOR: `match_*` is wrongly unified with `entry_*` (`engine.rs:171-174` sets both to the same groups) — nested-match reads via `match_*` get the entry match.
  - MAJOR: byte-indexed slicing in `substr`/`input_slice`/`capture_slice`/`capture_from`/cursor line-col → panic on multibyte UTF-8 and offset divergence from Perl (char-based). Also `entry/match_start_pos` hardcoded to 0.
  - MAJOR: duplicate/unreachable match arms in `engine.rs` — `hash`/`h` (650 vs 1202), `hash_copy` (662 vs 1221, the worse arm wins), `print` (643 vs 798); REP "zero-progress guard" never checks `pos`.
  - MAJOR: ~30 capture/mark/named-entry/match helpers missing (`capture_*_from`, `capture_between`, `mark_*`, `entry_named/has/map`, `match_named/has/map`, `input_end_line/col`, …); `tail`/`drop_last`/`flatten` real Perl helpers also missing (drop `array_values`/`return_imatch`/`return_im` from the inventory — not in Perl).
  - MAJOR: 0/20 shipped specs are runtime-tested in Rust (compile-only) — need a Perl↔Rust output oracle corpus.
- `2026-06-16` (`.4` superseded): in-flight exploration toward `.4` committed as a WIP checkpoint (handoff decision) to preserve it durably; it is NOT signoff (`parse_inline_body` conditional-capture bug, dead `set_retv`, leftover debug `eprintln!`). Fold/clean into the real follow-on above.
- `2026-06-16` (`.5` split): `.5` was a single broad leaf bundling six independently-reviewable audit findings; split into `.5.1`–`.5.5` (the runtime-corpus oracle gap stays in `.7`). The 3-agent audit above is the implementation spec for each child. retv-first because it gates correct output for nearly every grammar. Rust baseline confirmed green (182 tests, 0 failed) before the split.
- `2026-06-16` (`.5.1` implementation): retv BLOCKER fixed. **Design:** the Rust engine shares one `RuntimeContext` and `execute_rule` previously returned `Result<(), String>` — no value channel — so a child's `return(expr)` went only to the single shared accumulator and `set_retv` was dead. Fix: (1) added a per-invocation `return_value: Option<RuntimeValue>` to `RuntimeContext` with `set_return_value`/`take_return_value`/`restore_return_value`; (2) `execute_rule` now returns `Result<RuntimeValue, String>` — it `take`s the channel on entry (saving the caller's pending return) and reads+restores it on exit, so each invocation reports exactly its own last `return(...)` (Runtime Semantics §5.4) and nested dispatch is transparent; (3) after both `->` (acode) and `=>` (bcode) dispatch the engine calls `ctx.set_retv(child_retv)`, so the parent's attached code / `LE` / `E` read the child result as `scalar(retv)` (§3.3/§6.1); (4) `return(expr)` records the channel **in addition to** pushing the accumulator — the accumulator stays `execute()`'s return contract, so the 182-test baseline is untouched. **Wired the dead `set_retv` in** (completed, not removed). **Latent bug found + fixed while here:** `call(child)` resolved the rule name from the *evaluated* arg, but a bare `call(RuleName)` evaluates to undef (a label is not a scalar) — so `call` never resolved a bare rule. Added `resolve_rule_name` (mirrors `resolve_array_target`) so `call(child)` returns the child's value, enabling the Perl reference pattern `assign(s(retv), call(child))` (`specs/tablegrep.spec`). Zero runtime-crate `call(` uses existed, so zero baseline risk. **Book:** no change — the documented `.spec` contract already specifies retv (`appendix/runtime-semantics.md` §3.3/§6.1); the Rust backend now conforms. Rust-parity book sync remains `.9`.

- `2026-06-16` (`.5.2` implementation): match/entry separation landed. **Design:** the single match-set site (`engine.rs`) assigned the rule's own regex match to BOTH `entry_*` and `match_*`, so they could never diverge and a dispatched child clobbered the parent's match. The Perl reference keeps two per-handler `my` lexicals — `IMATCH` (entry, `= $$info{match}`, where a parent passes its own `$minfo` to the child at `ActionIR/MethodLowering.pm:332`, and the preamble sets `IMATCH=$$info{match}` at `SpecEntry::_build_handler_preamble`) and `LMATCH` (local, `= $$minfo{match}` at `HandlerVariantEmitter::_build_lmatch_extraction`). Fix: `execute_rule` now (1) saves the caller's `entry_*`/`match_*` into a `SavedMatchState`; (2) sets THIS invocation's entry match = the caller's local match (`$info = $minfo`) and starts the local match empty; (3) on each own match updates only `match_*`, and seeds `entry_*` from the first own match only when entry is still empty (the top-rule / dispatcher-less case — the framework passes the top rule's own match as `$info`); (4) restores the caller's registers on both the blind-call early return and the normal return, so a child's matching is transparent to the parent. **Oracle note:** the runtime Perl oracle was inconclusive for minimal hand-authored inline specs (`.spec` top-rule/lifecycle authoring friction returned empty/0), so the contract was taken directly from the authoritative Perl source (the three sites above) and pinned by Rust tests — the leaf's parity gate is `cargo test` + `cargo clippy`, not a Perl oracle. **Book:** no change (the `.spec` contract already documents `entry_*`/`match_*` in `dsl/capture-marks-and-source-locations.md`; Rust now conforms — Rust-parity book sync remains `.9`). Group-indexing parity (`match_group(0)` = first capture in Perl vs full match in Rust) is explicitly out of `.5.2` scope.

- `2026-06-16` (`.5.3` implementation): char-based offset/slicing parity. **Design:** the regex engine works in **byte** offsets, so internal positions (`ctx.pos`, `capture_start`, `marks`, `MatchResult.start`/`.end`, the new `entry/match_*_byte` spans) stay byte-based and input slicing between two of them is panic-safe; but the Perl reference exposes **char** offsets (`pos()`/`length`/`substr` are char-based), so every position/length surfaced to the DSL converts byte→char (`byte_to_char_offset`) and every helper taking DSL char-offset args char-slices (`char_substr`/`char_substr_from`). Concretely: `substr`/`input_slice` no longer byte-slice (they panicked on a multibyte boundary); `cursor_pos`/`cursor_col`/`cursor_rest_len`/`input_len`/`input_end_pos`/`capture_slice_len`/`capture_slice_pos`/`mark_pos`/`entry_*_pos`/`entry_len`/`match_*_pos`/`match_len`/`length` return char counts; line numbers (newline counts) were already byte/char-identical, only columns needed char counting. `entry_start_pos`/`match_start_pos` were hardcoded `0.0`; `RuntimeContext` now stores `entry/match_start_byte`+`_end_byte` spans (recorded from `m.start`/`m.end`, part of `SavedMatchState` so they save/restore per invocation like the `.5.2` groups, entry seeded by the same dispatcher-vs-own-first-match rule). **ASCII no-op:** byte==char for ASCII, so the 189 baseline is untouched; 7 multibyte `chars_5_3_*` tests pin the UTF-8 behavior. **Out of scope:** the `.5.2` group-indexing item, and the `entry_line`/`entry_col`/`match_line`/`match_col` arg-taking quirk (only `cursor` line/col was in this leaf's named scope). New knowledge card `docs/knowledge/rust-char-based-offsets.md`.

- `2026-06-16` (`.5.4` implementation): dedup + REP guard. **Dedup:** `call_helper` had three pairs of arms with the same pattern, where Rust matches top-to-bottom so the FIRST (worse) won and the later (better) was unreachable (3 `unreachable_patterns` warnings). Removed the first `print`, `hash`/`h`, and `hash_copy` arms so the later ones win: `hash`/`h` merges Hash-valued args (the dropped one ignored them), `hash_copy` resolves its target through `resolve_array_target` (raw-AST, not bare `to_str()`), and `print` is served by the consolidated `say | print | print_each` arm (identical behavior). **Note discovered while here:** there is no clean DSL idiom to *copy a declared hash by reference* — `hash(name)` eagerly builds an empty new hash (constructor, not a reference) and `resolve_array_target` only recognizes the `array(...)`/`a(...)` raw form, so `hash_copy(hash(config))` returns `{}`; the `hash`-as-reference gap is deeper than `.5.4` (flag for `.5.5`/a later leaf). The `.5.4` regression instead pins the better arm via its *distinguishing* behavior (Hash-arg merge). **REP guard:** the old guard `matches > rep_min && matches > 100` was an iteration cap that never inspected `pos`; replaced with a real progress check — capture `pos_before` at the top of each iteration, break when `ctx.pos == pos_before` (Perl `loop_end_pos == loop_start_pos`); a zero-width REP match now terminates after one no-progress iteration and the post-loop min-bound check fails it if still under `rep_min`. No knowledge card (localized fix, captured by tests + this tree).

- `2026-06-16` (`.5.5.2` implementation): input-boundary helpers + `flat`; retired-alias parity resolution. **Design:** added three `call_helper` arms to `rust/linkedspec-runtime/src/engine.rs`. (1) `input_end_line` returns `1 + (newline count over the whole input)` — parity with the Perl reference's `INPUT_END_LINE_READ` lowering (`Contracts.pm:1255`, `do { 1 + (() = substr($$STRING,0,length($$STRING)) =~ /\n/g) }`); newline counts are byte/char identical so a plain `'\n'` filter suffices. (2) `input_end_col` returns the char distance past the last newline (`+1` when none) — parity with `_build_column_read_expr(pos_expr => 'length($$STRING)')` (`Contracts.pm:111,1266`), modeled exactly on the existing char-based `cursor_col` (`.5.3`) but at end-of-input; multibyte-correct (e.g. `"héllo"` → 6, matching the `cursor_col` test). (3) `flat(container)` is the generic list-context splice (Perl `MethodLowering.pm:199`): an Array splices its elements, a Hash splices its key/value entries, any other value becomes a single-element list — consistent with the established Rust `flat_array` (Array→Array) and `flat_hash` (Hash→Hash) representation, so a parent `array(...)`/`hash(...)` consumes it the same way (the Rust `array(...)` constructor keeps args as-is; the splice is realized by the consuming helper, e.g. `hash(...)` merging Hash args). **Retired-alias resolution (the leaf's parked Open Question):** the Perl reference does NOT recognize `tail`/`drop_last`/`flatten`/`array_values` — absent from all helper-recognition regexes, unused in 20 specs, zero phase0 locks, retired in `COMPAT-ALIAS-RETIREMENT.1`, "Retired" in the book catalog. Cross-variant parity means matching the reference's recognized surface, so those three retired aliases are deliberately NOT added to Rust (an explicit code comment records this); only canonical `flat` was missing and is added. **Book:** no change (catalog §9 already documents `input_end_line`/`input_end_col`; §Compatibility-Aliases already marks the three retired — Rust now conforms; book sync remains `.9`). **Discovered drift:** `ROADMAP_V2` 256–262 still calls `tail`/`drop_last` "compatibility alias … remain supported" (stale pre-retirement text) — flagged for a Perl-side doc-sync slice, not bundled here.

- `2026-06-16` (`.5.5.3` implementation): mark-based capture family + `capture_from` parity fix (option (a)). **Design:** the family was implemented from the authoritative Perl lowering in `perl/LinkedSpec/ActionIR/Contracts.pm` (~690–1047), NOT the book catalog (which was imprecise/wrong — see below). Each reader resolves its named mark(s) from `ctx.marks` (flat `HashMap<String,usize>`, byte offsets) and slices `ctx.input[start..end]` between the mark and one of three endpoints: **match-start** (`ctx.match_start_byte` = Perl `$LSPOS - length $LMATCH`) for the non-cursor readers `capture_from`/`capture_len_from`/`capture_take_len_from`; the **cursor** (`ctx.pos` = `pos $$STRING`) for `_until_cursor_`; **end-of-input** (`ctx.input.len()`) for `_rest_`. Two guarded free helpers `span_text`/`span_char_len` return the slice text / its **char** count (DSL lengths are char-based, `.5.3`), or `None`→`undef` for a missing mark or a reversed/out-of-range span (matching the Perl readers' `defined`/`>=` guards, panic-safe). `_take_*` advance the named mark to the read's endpoint (cursor, or end-of-input for `_rest_`) only when the span is valid; non-take readers never mutate. `mark_input_start`→0, `mark_input_end`→`input.len()` (byte length), `mark_copy(target,source)` is **2-arg** (copy source's pos to target, or delete target when source unset). **The decision (a):** the existing `capture_from` read to `ctx.pos` (match-END); fixed to `ctx.match_start_byte` (match-START) for Perl parity; the one landed test `helpers_5_2_mark_and_capture_from` was updated (`"hello"`→`""`, mark 0 == match-start). The user confirmed (a) and directed fixing the catalog. **Book:** catalog §7 was contract-wrong/imprecise (`capture_from` "to current position"; 1-arg `mark_copy`; mislabeled `_until_cursor_`/`_take_`; anonymous `capture_slice` endpoint; missing `_len_` companions) — rewritten to the contract, kept variant-agnostic. Because the catalog documents the `.spec` contract (= Perl reference), correcting it is contract truth (zero-drift doctrine), tracked book↔Rust-variant gaps (anon `capture_slice`) recorded for `.5.5.4`. Knowledge card `docs/knowledge/rust-mark-based-capture-family.md`.

- `2026-06-16` (`.5.5.4` implementation): anonymous capture-slice family + `capture_slice`/`capture_slice_len` endpoint fix. **Design:** the anonymous family reads the single anonymous capture cursor `ctx.capture_start` (Perl `$IPOS`, set by `start_capture_slice()` in an I-block at the pre-seek cursor), the direct counterpart of the `.5.5.3` named-mark family. Implemented straight from `perl/LinkedSpec/ActionIR/Contracts.pm` ~366–656, reusing the `.5.5.3` guarded free helpers `span_text`/`span_char_len` (panic-safe; reversed/out-of-range span → `undef`). Endpoints: **match-start** (`ctx.match_start_byte`) for `capture_slice`/`capture_slice_len`/`capture_take`/`capture_take_len`; **cursor** (`ctx.pos`) for the `_until_cursor` readers; **end-of-input** for the `_rest` readers. `_take_*` advance `capture_start` to the **cursor** (Perl `$IPOS = pos $$STRING`) — note the match-start take readers (`capture_take`/`capture_take_len`) read to match-start but still advance to the cursor — except `_take_rest` advances to end-of-input. Text → raw slice (correct chars), `_len` → char count (.5.3); `_take_*` mutate only on a valid span (vs Perl's unguarded substr — identical on every realistic `capture_start ≤ match-start ≤ cursor ≤ end`). **The fix:** `capture_slice`/`capture_slice_len` previously read to `ctx.pos` (cursor); now end at `ctx.match_start_byte`, the anonymous analog of the `.5.5.3` `capture_from` fix. The two landed tests `helpers_5_2_capture_slice_basic`/`_len` were updated to the corrected parity values (`"hello"`→`""`, len `>0`→`0`) — capture started at match-start, so nothing precedes the match. **Scope decision:** the leaf named 7 inventoried anonymous variants, but reading `Contracts.pm` showed the `RUST-PARITY.1` inventory itself omitted the same-family `capture_rest`/`capture_rest_len`/`capture_take` (anonymous, no-mark). Rather than ship a deliberately half-finished family mirroring the inventory's gap, all 10 missing anonymous capture-slice helpers were landed together (one coherent, fully-tested family, one file) — distinct from the `.5.5.3`-discovered mark/match/entry-anchored helpers, which remain a deferred follow-up (different family). **Book:** catalog §7 already stated the match-start contract for `capture_slice`/`capture_slice_len` (the `.5.5.3` gap, now closed by the engine fix); added the 10 missing anonymous-variant entries and refined the §7 intro endpoint list + destructive-`_take_` note for accuracy (the take readers advance to the cursor, not the read endpoint), kept variant-agnostic (the catalog documents the `.spec` contract). No knowledge-card change for the mark family; new card `docs/knowledge/rust-anonymous-capture-slice-family.md`.

- `2026-06-16` (`.6` implementation): strict_syntax validation mode. **Design:** added `validate_with_options(spec, strict_syntax: bool)` and made `validate(spec)` a non-strict wrapper, so all existing call sites are untouched and strict is opt-in. The single Perl "option hash" knob (`strict_syntax`) maps to one bool; if more options arrive, refactor to a struct then (YAGNI). **The parity finding (verified empirically against the reference, not assumed):** the Perl `validate_dsl_syntax` emits two reference *warnings* — unused (`defined − used`) and undefined (`used − defined`) — and `strict_syntax => 1` promotes both to hard errors, undefined first. Two non-obvious facts were confirmed by direct `validate_dsl_syntax` probes: (1) the **top rule is not exempt** from the unused check — `Top:: -> Child` (Child defined, Top referenced by nothing) FAILS strict with "Unused rule(s): Top"; (2) undefined is reported before unused. **Backend reconciliation:** this backend already treats undefined edge targets as a hard error in *every* mode (`check_edge_targets`), which is stricter than the reference's default (a warning). That is a pre-existing divergence, left as-is (changing it would relax a deliberate Rust contract and break the landed `validate_rejects_undefined_target` test, out of this leaf's scope). Because `check_edge_targets` runs before the strict check, the reference's "undefined before unused" ordering is preserved, and strict mode's only *new* observable behavior here is the unused-rule rejection (`check_unused_rules`). 4 new `validation.rs` tests pin both promoted warnings, the non-strict pass, and a fully-referenced (self-loop top) strict pass. No book change (`compiler/pipeline-overview.md` already documents the strict contract; Rust now conforms — book sync is `.9`). Knowledge card `docs/knowledge/rust-strict-syntax-validation.md`.

- `2026-06-16` (`.7` split): `.7` was a single broad leaf ("all 20 shipped specs exercised in Rust + corpus files + regression guard"). A two-agent read-only investigation (Rust test/corpus infra + Perl reference output path) confirmed it bundles independently-reviewable work and discovers a lower-level dependency that must be solved first (PNT splitting rules), so it is split into `.7.1`–`.7.4`. **Findings driving the split:** (1) there is **no oracle mechanism and no canonical cross-variant output form yet** — the Rust corpus is 4 inline tests, the Perl side has input fixtures for only ~3 specs; (2) **output-shape reconciliation is required** — the Perl reference returns the top rule's value directly (`tclite` `[]` → `["?tcl_script:",[["?command_subst:",[]]]]`) whereas the Rust engine returns the accumulator wrapped one level (`[<value>]`); (3) ~16 specs need **authored inputs**; (4) the `RTLUtils` hang needs a **hard-timeout guard** in any Perl-over-corpus run. **Architecture decision:** the oracle is a *fixture generator*, not a live cross-process comparison — a timeout-guarded Perl tool emits canonical-JSON fixtures (`JSON::PP->canonical(1)`) into `rust/linkedspec-runtime/tests/corpus/`, and a Rust fixture-runner test compares `engine.execute(input)` against the checked-in fixtures. This keeps `cargo test` Perl-free and realizes ADR 0006 §Phase 8.6's language-neutral corpus. `.7.1` establishes the mechanism + canonical form; `.7.2`/`.7.3` expand the corpus in batches; `.7.4` adds the drift guard and finalizes. No code change (tree structuring only). Frontier → `.7.1`.

- `2026-06-17` (`.7.1` implementation): output-oracle mechanism + green proof + a major finding. **Mechanism:** a Perl generator (`tools/gen_oracle_corpus.pl`) runs the reference parser under a hard `alarm(...)` timeout (RTLUtils-hang-safe) and writes one corpus dir per case (`tests/corpus/<case>/{input.spec, input.txt, expected.json}`, `JSON::PP->canonical(1)`); a Rust fixture-runner (`tests/corpus_oracle.rs`) enumerates the corpus, runs the full pipeline, and reports every entry, failing once at the end. **Format choice:** adopted the book's already-documented `backend-handoff.md` corpus contract (per-entry `input.spec`/`input.txt`/`expected.json`) rather than inventing one — zero added drift, and the corpus is self-contained/language-neutral (ADR 0006). **Wrap rule (reconciled + documented):** `expected.json` holds the backend-neutral reference (Perl top-rule) value; the Rust engine wraps the accumulator one level (`engine.rs` `execute` returns `Array(accumulator)`), so the runner compares `execute(input) == json!([expected])`. **THE FINDING (why the oracle matters):** the `.7`-split note claimed the Perl↔Rust gap on tclite/Lispish was *only* the wrap — the oracle disproved it. Both shipped proof specs DIVERGE: tclite `[]` → Rust `[]` (Perl `["?tcl_script:",[["?command_subst:",[]]]]`), Lispish → `exit_now(1)`. Shared root cause: a single-regex rule written `name : /re/` (single colon) compiles in Rust as **0-regex**, so `-> child[0]` edges never fire (`::` single-regex rules are fine). Lispish additionally needs the `scalaref(retv, {content})` accessor. Also surfaced: Rust child `return` leaks into the parent accumulator (vs Perl `retv`), and Perl *inline-spec* retv returns undef (so retv grammars diverge — Rust is the more-correct side). **Scope decision (PNT splitting rule — discovered lower-level dependency):** these are engine/parser surgery, NOT oracle-mechanism work; deferred to new leaf `.7.5` (now first in the frontier, blocking `.7.2`/`.7.3`). The mechanism is instead proven green on 2 controlled authored grammars that avoid every divergence source (parent→child dispatch, literal edge return, action-less child): scalar `"scalar-ok"`→`["scalar-ok"]` and nested array `["?proof:","ok"]`→`[["?proof:","ok"]]`. `cargo test` 238/238 (237+1); clippy zero-new (core 10/runtime 13/validation.rs 4); self-check exit 0. No book change (format already matched; the wrap-rule note is `.7.4`/`.9`). Knowledge card `docs/knowledge/rust-perl-output-oracle.md`.

- `2026-06-17` (`.7.5` split): split into `.7.5.1` (parser header-line-regex fix) + `.7.5.2` (`scalaref` `{…}` hash-literal). A read-only investigation (+ a direct read of `parser.rs:86`) located two **independent, separately-reviewable** root causes (PNT rule 5). (1) **`.7.5.1` — `rust/linkedspec-core/src/parser.rs:86`:** the header regex `^(\w+)[ \t]*(::|:)[ \t]*(\S*)[ \t]*(.*)` uses `(\S*)` for the mode suffix, which greedily eats a `/…/` regex placed on the header line — `parse_mode_suffix("/;/")` → `RuleMode::Default` and the regex is discarded. So every rule with a header-line regex registers 0 (or, for an open/close pair, drops the first), and `-> child[0]` edges "never fire". It is NOT really "single-colon" — it bites `:` and `::` alike; the passing tests/`::` top-rules dodge it only because they put the regex on a separate **body line** (`Child::` then `/…/`). Fix sketch `(\S*)`→`([^\s/]*)`. **Foundational blast radius** (this regex parses every header), with real subtlety: today an open/close pair (`command_subst`, `parenthesis`, `curlyb`) registers "1 regex" because group 3 eats the first; the fix moves both into `rest`, so the rest/body regex-parser must reproduce the bracket-pair semantics, not two independent regexes — must be verified against the full suite + the oracle (re-enable tclite). This is why it is its own carefully-verified leaf, not bundled. (2) **`.7.5.2` — `rust/linkedspec-core/src/expr.rs:299`:** `parse_expr` has no `{` case, so `scalaref(retv, {content})` (Lispish) raises `unexpected character '{'`; needs a new `Expr` variant + parser + engine semantics (field access). Larger, and depends on `.7.5.1` (Lispish's child rules must first register their regexes). The two are independent (each repros in isolation — `semi_colon : /;/` fails only via the parser bug; an edge with `scalaref(…,{content})` fails only via the expr bug). Frontier → `.7.5.1`. No code change (tree structuring only).

- `2026-06-17` (`.7.5.1` implementation): header-line-regex fix landed + a second tclite blocker discovered → split off `.7.5.3`. **The fix:** `parser.rs:86` `(\S*)`→`([^\s/]*)` (one char class). Group 3 is the mode suffix; `\S*` greedily ate a `/…/` regex on the header line, `parse_mode_suffix` returned `Default`, and the regex was dropped. Narrowing the class to stop at `/` lets the regex fall through to group 4 (`rest`), where `parse_inline_body` registers it. Every real mode suffix (`AND`/`OR+`/`&`/`*`/`?`/`AND{2,4}`) is slash-free, so the change is behaviorally identical for all non-regex header content; the second header regex (`parser.rs:270`, in `collect_body`) is detection-only with a trailing `*` group and was correctly left unchanged. **Bracket pairs repaired, not just preserved:** `command_subst : /open/ /close/` went `[close]` (1 regex; `-> command_subst[1]` out-of-bounds, entry matched the *close*) → `[open, close]` (entry idx 0 = open; `[1]`→idx 1 = close via the self-recursive branch of `build_dependency_regex_map`) — the recursive bracket matcher the spec intends. 4 unit tests pin it (3 parser + 1 compiler). **The discovery (PNT split):** the fix is **necessary but not sufficient** for tclite — with regexes now registering, the oracle still showed tclite → `[]`. Root cause #2 (independent, separately-reviewable): tclite accumulates via fluent continuations on ACTION edges (`-> command_subst .push`, `-> command_subst[1] .return(...)`), but the parser attaches a fluent chain only to a BLIND edge (`=>`, `parser.rs:443`); after a `->` edge the `.push`/`.return(...)` becomes a standalone `FluentChain` the compiler discards (`compiler.rs:171`). Per the splitting rules (independent gap, don't bundle), the action-edge fluent lowering is the new leaf `.7.5.3` (greens tclite), the tclite oracle cases were re-deferred there (corpus back to 2 green proofs), and `.7.5.1` landed as the self-contained parser fix. **Lispish is unaffected by `.7.5.3`** (it uses `{ code }` blocks, not the fluent form) — its remaining blocker is `.7.5.2` (scalaref) only. `cargo test` 242/242 (238 + 4); clippy multiset = baseline (core 10 / runtime 13 / validation.rs 4, zero-new). Pre-existing clippy `--tests` exit-101 (`approx_constant` in untouched `expr.rs:687`/`types_test.rs:143`) recorded in Open Questions, not fixed (out of scope). Frontier → `.7.5.3`.
- `2026-07-04` (`.8.1` split/inventory): code-generation emitter work is split before implementation. The source audit read `docs/knowledge/handler-ir-design.md`, `perl/LinkedSpec/HandlerVariantEmitter.pm`, Rust `CompiledSpec`/`CompiledRule`/`AcodeEntry`/`BcodeEntry`, the Rust runtime execution loop, and backend handoff docs. Durable boundary: Perl HandlerIR has 10 structural variants and emits Perl/JSON; Rust currently interprets a native structural contract with parsed lifecycle `CodeBlock`s and dispatch tables. `.8` now has implementation children for a minimal source-emitter scaffold/compile-run harness (`.8.2`), non-REP structural families (`.8.3`), REP families/termination guards (`.8.4`), and all-variant/oracle integration (`.8.5`). No parser/runtime source behavior changed. Frontier → `.8.2`.
- `2026-07-04` (`.8.2` implementation): the first generated Rust-source path is intentionally a scaffold, not direct handler-family emission. `linkedspec-runtime` now exports `source_emitter::emit_rust_source`, which serializes the current `CompiledSpec` structural contract into a generated Rust module and exposes `parse(input)` by constructing the existing `Engine`. This keeps interpreter behavior unchanged while proving the source-generation API boundary, source-format marker, generated-module compilation, and isolated run harness. The generated-source test builds a temporary crate against the local runtime crate and executes a simple non-recursive parser case; direct source emission for default/OR/AND non-REP handlers is deliberately left to `.8.3`.
- `2026-07-04` (`.8.3` split): non-repetition handler emission is split again before implementation. The first code read found that Rust `CompiledRule` preserves regex/action/blind dispatch tables and parse mode, but not enough parsed rule-mode metadata to robustly distinguish OR-bcode from AND-bcode in a generated-source-only pass. The remaining `.8.3` scope also spans separate acode, bcode, and matrix-closeout risks. Per PNT rule 5, `.8.3.1` now owns rule-mode/family metadata plus generated non-REP family-plan emission; `.8.3.2` owns direct default/OR acode execution; `.8.3.3` owns direct AND acode execution; `.8.3.4` owns direct AND/OR bcode execution; `.8.3.5` owns the non-REP matrix closeout. No Rust source changed in the split.
- `2026-07-04` (`.8.3.1` implementation): generated family-plan metadata landed before direct execution. `CompiledRule` now carries parsed `RuleMode` so source generation does not infer OR/AND family shape from dispatch tables alone. The runtime source emitter now classifies each rule into a `GeneratedRuleFamily`, emits `GENERATED_RULES` beside `COMPILED_SPEC_JSON`, and validates generated labels/families before delegating through `Engine`. The test matrix deliberately proves plan emission/validation for default, OR acode, AND single-acode, AND sequential-acode, AND bcode, and OR bcode generated modules while leaving direct execution to `.8.3.2`+. Frontier → `.8.3.2`.
- `2026-07-04` (`.8.3.2` implementation): direct generated execution started for the default and OR acode families. Generated modules still embed `CompiledSpec` plus `GENERATED_RULES`, but `execute_generated_parser` now calls the plan-aware executor instead of `Engine::execute`. The generated executor directly runs default/OR acode rules with the interpreter's lifecycle semantics: recursion guard, entry/local match lexicals, I/LS/LE/IT/LX/EX/E blocks, action-edge child-return scoping, default-mode repetition, and zero-progress termination. Unsupported AND/bcode/REP families still fall back inside the executor until `.8.3.3`–`.8.4`. Frontier → `.8.3.3`.
- `2026-07-04` (`.8.3.3` implementation): direct generated execution now covers AND acode families. `GeneratedPlanExecutor` treats `AndSingleAcode` and `AndAcodeSeq` as direct acode families, and the Rust regex/acode loop now enforces ordered non-repetition AND sequence before completion: regex slot 0, then slot 1, etc. An out-of-order or incomplete sequence fires `LX` when present and returns `undef` before `E`, matching the Perl HandlerIR `and_acode_seq` ordered-index contract for focused cases while keeping generated and interpreted Rust execution aligned. The source-emitter matrix now proves an AND single-acode return and a two-slot AND sequential-acode case whose payload is produced only by the second ordered edge. Frontier → `.8.3.4`.
- `2026-07-04` (`.8.3.4` implementation): direct generated execution now covers non-repetition bcode families. `GeneratedPlanExecutor` treats `AndBcode` and `OrBcode` as direct families, sharing the interpreter's blind-edge tail execution so child returns become parent `retv`, attached blind-edge code/fluent calls execute in order, and parent `E` reads the resulting value. Explicit OR bcode dispatch stops after the first truthy child return and fires `LX` on no child match. The source-emitter matrix proves ordered AND bcode child-return collection (`A`, `B`), OR bcode first-match behavior on `a b` (`or-bcode:A`, which would become the later child if dispatch kept looping), and OR no-match `LX` on `c` (`or-miss`). Frontier → `.8.3.5`.
- `2026-07-04` (`.8.3.5` implementation): non-repetition generated-family matrix closed. `GeneratedPlanExecutor::execute_rule` now matches exhaustively over `GeneratedRuleFamily`, so every non-REP generated family enters direct execution and `Repetition` is the only fallback-owned family. The source-emitter matrix now asserts that its generated-module cases cover `Default`, `OrAcode`, `AndSingleAcode`, `AndAcodeSeq`, `AndBcode`, and `OrBcode` before REP work starts. Frontier → `.8.4`.
- `2026-07-04` (`.8.4` implementation): repetition generated-family direct execution landed. `GeneratedRuleFamily::Repetition` is retained only as a compatibility enum value; current classification emits explicit `RepAcode`, `RepBcode`, `RepAndAcode`, and `RepAndBcode` families. Generated execution routes all four directly. The shared Rust runtime now loops repeated blind-call OR choices and AND sequences with min/max bounds plus zero-progress termination, and REP-AND acode counts a complete ordered regex group as one repetition. The source-emitter matrix now covers every non-REP and REP generated family, plus zero-progress and recursion-guard cases. Frontier → `.8.5`.
- `2026-07-04` (`.8.5` implementation): generated-source validation is now connected to the oracle/corpus contract. The existing generated-source matrix remains the all-family proof for every supported structural family, while a new manifest-backed subset test loads the real oracle manifest, verifies selected case names are present, checks interpreter output against `[expected.json]`, emits generated Rust modules for the same compiled specs, and compiles/runs those generated modules in an isolated temp crate. The subset deliberately covers authored oracle proofs, terse helper/control/user-function surfaces, shipped recursive `tclite`, and shipped `portmap`. Limitation is explicit: generated-source corpus validation is a curated subset, not all 88 fixtures; the full 88-fixture gate remains `corpus_oracle` on the interpreter path. `.8` is closed; frontier → `.9`.
- `2026-07-04` (`.9` finalization): `RUST-PARITY` is closed. Roadmap, task-tree, live recovery docs, mdBook backend handoff, Rust README, and `ARCHITECTURE_STATE.md` now agree: the Rust interpreter oracle is green over 88 manifest fixtures plus drift guards; generated source directly runs every supported structural family and has all-family plus 8-case manifest-backed subset proof; full corpus generated-source coverage remains future work. Closing `RUST-PARITY` also clears the dependency blocker for `TOP-RULE-AS-NORMAL.3.2`, which is the next PNT leaf.
- `2026-07-02` (`.7.5.3` reconciliation): `.7.5.3` is closed without new runtime code in this slice because the
  implementation landed later under owned `SPEC-FORMAT-TERSE` leaves. `SPEC-FORMAT-TERSE.2.3.3.1` added the
  parser/compiler/runtime metadata path for action-edge fluent chains and no-arg `.push` / `.return(expr)` /
  `.return_undef`; `.2.3.3.3.2` completed explicit-target and flow-control continuations; `.2.3.3.3.3.1` fixed
  the separate default-mode recursive repetition / child-preamble-return gap and restored the two shipped
  `tclite` oracle fixtures. The historical `.7.5.3` acceptance ("action-edge fluent continuations no longer
  dropped, tclite no longer blocked by that surface") is therefore satisfied. The remaining `.7.5` leaf is
  `.7.5.2` for Lispish `scalaref(retv, {content})`; `.7.2`/`.7.3` remain blocked until that shipped-spec gap is
  closed.
- `2026-07-02` (`.7.5.2` implementation): Lispish parity landed by matching the Perl-generated mechanism rather
  than guessing from source text. TOOLBOX-generated Perl source showed block-bearing action edges with explicit
  `call(child)` own the child dispatch inside the lowered block, `scalaref(retv, {content})` lowers to a hashref
  field read (`$retv->{content}`), and Lispish word clearing depends on `assign(array(word), array())` replacing
  `@word` with an empty array. Rust now parses a dedicated `ScalarRefPath` only as `scalaref`'s second positional
  argument, evaluates legacy path segments with literal bare key/index atoms unless wrapped in an explicit value
  expression, contains child return accumulator pushes before returning to the parent, skips automatic action-edge
  pre-dispatch when the attached block explicitly calls the same child, and routes `assign(array(...), array())`
  / `set(hash(...), hash(...))` through aggregate-store replacement. `lispish_x_y` is re-enabled in the oracle
  corpus and passes with expected `["x",["y"]]`; the current corpus is 63 fixtures. Frontier → `.7.2`.
- `2026-07-03` (`.7.3.1` split): `.7.3` is too broad for one signoff slice. Batch 2 now starts with a
  trace-first timeout/hang investigation, then has separate lanes for remaining `hlink_substitution`
  delimiter/link-path fixtures, known simple-spec structural divergences (`portmap`, `lib_reader`, `ebnf`),
  action-parser/null-output candidates (`BNF`, `DT`, `ifelse`, `operators_try`, `spec.spec` smokes), and
  RTL/plugin/legacy specs after the timeout concern is resolved or retired. No parser/runtime/corpus code changes
  belong to the split leaf.
- `2026-07-03` (`.7.3.2` implementation): the historical `RTLUtils` timeout is not live in the current core tree;
  the stale risk was the oracle generator's use of `alarm()` despite the toolbox warning that `alarm()` cannot
  interrupt a catastrophic regex. The oracle now runs each parse in a forked child and enforces
  `ORACLE_TIMEOUT` from the parent with `SIGKILL`. This keeps the generic timeout guard real before broader
  shipped-spec corpus work resumes.
- `2026-07-03` (`.7.3.3.1` split): `hlink_substitution` delimiter fixtures divide by oracle representability.
  `{abc}` returns a JSON-safe string, while `[abc]` and mixed bracket/brace inputs return Perl scalar references
  that `JSON::PP` cannot encode. Add the curly fixture first; do not add bracket/mixed fixtures until the
  scalar-ref representation is explicitly designed.
- `2026-07-03` (`.7.3.3.2` implementation): the JSON-safe `hlink_substitution` curly delimiter is now an active
  oracle fixture (`hlink_curly_brace`, input `{abc}`, expected `["{abc}"]`). This raises the corpus to **66**
  fixtures without Rust runtime/parser changes. Bracket and mixed scalar-ref hlink cases remain out of the JSON
  oracle until `.7.3.3.3` decides or defers their representation.
- `2026-07-03` (`.7.3.3.3` decision): bracket/mixed `hlink_substitution` fixtures are deferred, not encoded under
  an ad hoc oracle shape. Perl returns scalar references for `[abc]` and mixed `foo[bar]{baz}`, and `JSON::PP`
  cannot encode them. Rust currently has no scalar-reference `RuntimeValue` and cannot execute the shipped
  scalar-ref action branch either: the action parser rejects `return(\(my $capt = capture_slice()))`, then the
  `[abc]` path falls through to unmatched-closing-bracket `exit_now(2)`. The follow-up owner `.7.3.3.4` must
  either define a tagged scalar-ref JSON contract with Rust parser/runtime support, or migrate
  `specs/hlink_substitution.spec` to a portable bracket payload shape. Frontier → `.7.3.4`.
- `2026-07-03` (`.7.3.7` implementation): the user-directed timeout re-debug found the remaining live timeout
  weakness in the oracle guard boundary. A build+parse child census made `BNF` time out under 5s, but focused
  probes showed parser execution was fast after construction; `get_parser("BNF")` / `get_parser("ebnf")` are
  slow build paths, and trace reached successful parser generation. Therefore the fix is not a BNF regex rewrite:
  the oracle generator must guard parser construction too. `tools/gen_oracle_corpus.pl` now builds the parser and
  parses inside the forked child, so `ORACLE_TIMEOUT` covers both phases before broad shipped-spec work resumes.
  Frontier → `.7.3.4`.
- `2026-07-04` (`.7.3.5` implementation): null-output candidates were triaged before fixture promotion. Perl
  reference probes return `null` for representative `BNF`, `DT`, `ifelse`, and `operators_try` inputs, so Rust's
  empty accumulator for those diagnostic/debug-print specs is not an actionable semantic oracle target. The real
  Rust gap was the `operators_try` action-parser warning: braces inside quoted debug strings were counted as block
  delimiters by the `.spec` code-block scanner. The scanner now ignores quoted braces with escapes. Four stable
  `spec.spec` smokes are active oracle fixtures (`spec_spec_minimal_rule`, `spec_spec_action_edge`,
  `spec_spec_user_function_definition`, `spec_spec_comment_skip`), raising the corpus to **81 fixtures**.
  Frontier → `.7.3.6`.
- `2026-07-04` (`.7.3.6` implementation): the RTL/plugin/legacy audit is fixture-promotion first, not an
  implementation leaf. Seven measured Rust-green, JSON-safe shipped-spec smokes are active:
  `regdef_nested_register_fields`, `tablegrep_simple_term`, `simenv_multiline_value`, `vhdl_library_use`,
  `ds_vhistory_version_entry`, `pplugin_empty`, and `tkgui_empty`, raising the corpus to **88 fixtures**.
  Richer candidates stay out of the corpus with explicit evidence: `pplugin` subdefs produce Perl coderefs,
  `tkgui` body returns depend on a raw Perl pair-return action, `sdce` capture slicing diverges, recursive
  `tablegrep` groups over-report in Rust, `simenv` single-line values lose their verbatim payload, VHDL port
  clauses collapse to null, `ds_vhistory` branch entries are classified as version entries, and placeholder
  `verilog` returns Perl `0` versus Rust `[]`. Frontier → `.7.4`.
- `2026-07-04` (`.7.4` implementation): the oracle corpus now has an explicit intended fixture set. The generator
  writes root `manifest.json` with `format`, `generated_by`, `case_count`, and ordered `cases`; it rejects
  duplicate case names before writing. The Rust runner loads the manifest, rejects malformed format/count data,
  duplicate or invalid case names, missing fixture directories, and stale extra fixture directories, then executes
  fixtures in manifest order. This closes the "enumerates all fixtures" risk without depending on directory
  listing order or silent stale directories. `.7` is closed; frontier → `.8`.

## Open Questions

- (`.5.5.2`) **RESOLVED 2026-06-16.** Alias-retirement status of `tail`/`drop_last`/`flatten`/`array_values`: the Perl reference does **not** recognize them. They are absent from every current helper-recognition regex (`BootstrapSpec/Core.pm:82`, `FlowExpr.pm:81,270`, `MethodLowering.pm:1627,1635` list canonical `drop_front`/`drop_back`/`flat`/`flat_array`/`array_copy` but none of the four aliases), unused in all 20 shipped specs, and not regression-locked in `t/phase0_regression.t` (grep count 0). They were retired in `COMPAT-ALIAS-RETIREMENT.1` (knowledge card `medium-term-alias-retirement-deferred`), and the book catalog §Compatibility-Aliases lists them "Retired". **Decision:** for cross-variant parity the Rust variant matches the reference's recognized surface — the three retired aliases are NOT added (only `flat`, which is canonical and was missing). `entry_named_map`/`match_named_map` are a separate case (combined-arm retired aliases already added in `.5.5.1`, accepted for legacy specs). **Discovered drift (now FIXED):** `ROADMAP_V2.md`/`ROADMAP.md` + book `appendix/formal-grammar.md:357` still described `tail`/`drop_last`/`flatten`/`array_values` as live "compatibility aliases". Corrected to retirement across 16 lines / 3 files under the dedicated tree `ALIAS-RETIREMENT-DOC-SYNC` (completed 2026-06-16) — the docs are the variant-agnostic universal-contract surface, so this was contract truth to fix, not a deferrable "Perl-side" detail.
- (`.5.5.3`) **RESOLVED 2026-06-16 as option (a)** (user-confirmed; implemented). The mark-family readers have TWO end positions in the Perl reference (`Contracts.pm` ~690–1047), and the existing Rust `capture_from` did not match the non-cursor one. **Non-cursor readers** (`capture_from`/`capture_len_from`/`capture_take`/`capture_take_len_from`) end at `$LSPOS - length $LMATCH` = the **start of the current local match** (= `ctx.match_start_byte` in Rust). **`_until_cursor_` readers** end at `pos $$STRING` = the cursor (= `ctx.pos`). **`capture_rest*`** ends at `length($$STRING)` (end of input). **`_take_` variants MUTATE the mark** (advance it to the read's end position) — non-take variants do not. `capture_between(a,b)` = `substr(start_mark, end_mark - start_mark)`; `capture_len_between` = the width. `mark_input_start(name)` = mark 0; `mark_input_end(name)` = mark `len(input)`; `mark_copy(target, source)` is **2-arg** (copies source's pos to target; returns it, or deletes target + returns undef if source absent — note the book catalog §7 wrongly shows a 1-arg `mark_copy(name)`, another book imprecision to flag). **The discrepancy:** the existing Rust `capture_from` (engine.rs:1044) returns `ctx.input[mark..ctx.pos]` (to match_END), but Perl `capture_from` goes to match_START (`pos - len(LMATCH)`); e.g. test `helpers_5_2_mark_and_capture_from` (mark at 0, whole-input match "hello") asserts `"hello"`, but strict Perl gives `""` (everything before the match). So `capture_len_from` per strict Perl would be `pos - mark - len(LMATCH)`, **inconsistent** with the existing `capture_from`. **Decide before implementing `.5.5.3`:** (a) fix `capture_from` to Perl's match-start semantics and update `helpers_5_2_mark_and_capture_from` (correct parity, but changes a landed test), or (b) implement the family consistent with the existing match-end `capture_from` (internally coherent, but a known parity gap). Recommend (a) with explicit justification, but it is a deliberate call that wants fresh focus. `LMATCH` length in Rust = `ctx.match_end_byte - ctx.match_start_byte` (`.5.2`/`.5.3` spans); positions byte-internal, char at the DSL boundary (`.5.3` `byte_to_char_offset`). **Resolution:** option (a) — `capture_from` fixed to end at `ctx.match_start_byte`; the landed test `helpers_5_2_mark_and_capture_from` updated `"hello"`→`""`. The whole non-cursor family (`capture_from`/`capture_len_from`/`capture_take_len_from`) ends at match-start; `_until_cursor_` at `ctx.pos`; `_rest_` at `ctx.input.len()`; `_take_*` advance the mark to the read's endpoint. Book catalog §7 corrected (incl. the 2-arg `mark_copy` and anonymous `capture_slice` endpoint imprecisions flagged here). See knowledge card `docs/knowledge/rust-mark-based-capture-family.md`.
- (`.5.5.3` discovered) **Parity-inventory gap + anon-slice gap.** Reading `Contracts.pm` fully surfaced mark helpers absent from BOTH the Rust engine and the `RUST-PARITY.1` inventory: `mark_match_start`/`mark_match_end` (`$LSPOS - length $LMATCH` / `$LSPOS`), `mark_entry_start`/`mark_entry_end` (`$IPOS - length $IMATCH` / `$IPOS`), the bare mark-based `capture_take(mark)`, and `capture_take_between`/`capture_take_between_len`. **STILL DEFERRED** — these are mark/match/entry-anchored helpers (a different family from the anonymous capture-slice subject of `.5.5`); flag for a follow-up parity leaf (`.5.5.5`?). The **anon-slice gap is RESOLVED 2026-06-16 in `.5.5.4`**: `capture_slice`/`capture_slice_len` now read to match-start (was the cursor), and the full anonymous capture-slice family was implemented + documented in catalog §7. While implementing, `.5.5.4` also surfaced that the inventory's anonymous list itself omitted `capture_rest`/`capture_rest_len`/`capture_take` (anonymous, no-mark) — these are the same family, so they were folded into `.5.5.4` (the anonymous capture-slice family is now complete in Rust + book).
- None yet — inventory leaf will identify any.
- (`.5.2` note, resolved in `.7.2`) Group indexing used to differ between Perl (`match_group(0)` = first
  capture) and Rust (`entry_group(0)`/`match_group(0)` read index 0 = full match). `.7.2` fixed the Rust helper
  surface to match the documented Perl contract: `entry_group(0)` / `match_group(0)` now read the first
  participating capture, `entry_groups()` / `match_groups()` are captures-only and compacted, and whole-match text
  is read through `entry_text()` / `match_text()` from stored spans.
- (`.5.3`) `entry_line`/`entry_col`/`match_line`/`match_col` take a position **argument** rather than deriving from the stored entry/match span (an existing quirk). `.5.3` fixed only `cursor` line/col (its named scope); revisit these in a later parity leaf alongside the group-indexing item.
- (`.7.5.1` discovered) **Pre-existing `cargo clippy --tests` exit-101.** Clippy's deny-by-default `clippy::approx_constant` lint hard-errors on two `3.14` float literals in test code that predate the RUST-PARITY work and were untouched by `.7.5.1`: `rust/linkedspec-core/src/expr.rs:687` (`(*value - 3.14).abs()`) and `rust/linkedspec-core/tests/types_test.rs:143` (`Some(3.14)`). So `cargo clippy -p linkedspec-core --tests` has exited 101 since before `.7.1` — the prior leaves' "clippy zero-new" gate measured the **warning multiset** (core 10 / runtime 13 / validation.rs 4), not clippy's exit code. Trivial to fix (`#[allow(clippy::approx_constant)]` on the two test fns, or change the literal), but it is a pre-existing hygiene issue unrelated to any parity leaf — flag for a small dedicated hygiene leaf rather than bundle it into a parity slice.

## Blockers

- None.

## Verification Log

| Date | Leaf | Checks | Result |
| --- | --- | --- | --- |
| `2026-06-16` | `RUST-PARITY.1` | Full audit: Rust sources (`engine.rs:1984`, `helpers.rs:470`, `compiler.rs`, `parser.rs`, `validation.rs`) vs Perl lowering owners (`ControlFlow.pm`, `MethodLowering.pm`, `ValueExpr.pm`, `FlowExpr.pm`, `Contracts.pm`) | Done — 6 gap categories, 84/100+ helpers implemented |
| `2026-06-16` | `RUST-PARITY.5.1` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml` (linkedspec-runtime delta) | 186 passed / 0 failed (182 baseline + 4 new retv tests: acode/OR, blind-call/AND, REP, `call`); clippy adds zero new linkedspec-runtime warnings (lib stays at 16 pre-existing `doc_lazy_continuation`) |
| `2026-06-16` | `RUST-PARITY.5.2` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --tests` (baseline-diff) | 189 passed / 0 failed (186 baseline + 3 new `match_5_2_*`: child entry/local divergence, parent-match survives child dispatch, top-rule entry==local); clippy touched-file warning set identical to baseline (14 engine.rs + 1 pre-existing `len_zero` at integration_test.rs:199), only line-shifted — zero new warnings |
| `2026-06-16` | `RUST-PARITY.5.3` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --tests` (baseline-diff vs `.5.2` HEAD) | 196 passed / 0 failed (189 baseline + 7 new `chars_5_3_*`: substr no-panic, input_slice, cursor_pos, cursor_col, match_start_pos, entry_start_pos, length — all multibyte UTF-8); clippy touched-file warning count identical to baseline (15) — zero new warnings |
| `2026-06-16` | `RUST-PARITY.5.4` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --tests` (baseline-diff vs `.5.3` HEAD) | 198 passed / 0 failed (196 baseline + 2 new: `rep_5_4_zero_progress_guard_terminates`, `hash_5_4_better_hash_arm_merges_hash_args`); clippy touched-file warnings 15 → 12 (removed 3 unreachable-pattern duplicates; zero new) |
| `2026-06-16` | `RUST-PARITY.5.5.1` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --tests` (baseline-diff vs `.5.4` HEAD, stashed) | 204 passed / 0 failed (198 baseline + 6 new `helpers_5_5_1_*`: entry/match × named/has/map, present + absent edges + retired `_named_map` aliases); clippy lint multiset byte-identical to the stashed baseline (13 = 13) — zero new warnings |
| `2026-06-16` | `RUST-PARITY.5.5.2` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --tests` (baseline-diff vs `.5.5.1` HEAD) | 207 passed / 0 failed (204 baseline + 3 new `helpers_5_5_2_*`: `input_end_line` newline-count, `input_end_col` char-based incl. multibyte + trailing-newline, `flat` array + hash-into-parent splice); `linkedspec-runtime` lib clippy 13 = baseline 13 (zero new; integration_test `len_zero` :199 pre-existing; vendored pgen/rgx-core ignored) |
| `2026-06-16` | `RUST-PARITY.5.5.3` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --tests` (baseline-diff vs `.5.5.2` HEAD); `mdbook build` | 223 passed / 0 failed (207 baseline + 16 new `helpers_5_5_3_*`: each mark-based helper + missing-mark/reversed-span `undef`, `_take_` mutation, multibyte char-length, match-start vs cursor vs end-of-input endpoints; landed `helpers_5_2_mark_and_capture_from` updated `"hello"`→`""`); `linkedspec-runtime` source clippy 13 = baseline 13 (11 engine.rs + 2 helpers.rs, all pre-existing locations; zero new; vendored pgen/rgx-core ignored); `mdbook build` exit 0 |
| `2026-06-16` | `RUST-PARITY.5.5.4` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --tests` (baseline-diff vs `.5.5.3` HEAD); `mdbook build` | 233 passed / 0 failed (223 baseline + 10 new `helpers_5_5_4_*`: match-start/cursor/end endpoints, `_take_` mutation across all three families, multibyte char-length; landed `helpers_5_2_capture_slice_basic`/`_len` updated `"hello"`→`""` / `>0`→`0`); `linkedspec-runtime` source clippy 13 = baseline 13 (11 engine.rs + 2 helpers.rs, all pre-existing locations outside the new ~1036–1180 range; zero new; vendored pgen/rgx-core ignored); `mdbook build` exit 0 |
| `2026-06-16` | `RUST-PARITY.6` | `cargo test --manifest-path rust/Cargo.toml` (all binaries); `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-core --tests` + `-p linkedspec-runtime --tests` (baseline-diff vs `.5.5.4` HEAD); Perl-reference probe of `validate_dsl_syntax` strict_syntax | 237 passed / 0 failed (233 baseline + 4 new `validation::tests::validate_strict_*`/`_nonstrict_*`: unused-top→error, non-strict pass, undefined→error, fully-referenced pass); `linkedspec-core` clippy validation.rs 4 = baseline 4 (pre-existing `collapsible_match`; zero new), `linkedspec-runtime` 13 = baseline 13 (unchanged — change is in `linkedspec-core`). No book change (strict contract already documented; book sync `.9`) |
| `2026-06-17` | `RUST-PARITY.7.1` | `perl -c tools/gen_oracle_corpus.pl`; `perl tools/gen_oracle_corpus.pl` (generate); `cargo test --manifest-path rust/Cargo.toml` (full); `cargo clippy -p linkedspec-core -p linkedspec-runtime --tests`; `scripts/check_memory_architecture.sh` | generator syntax OK; 2 fixtures generated; `cargo test` = **238 passed / 0 failed** (237 baseline + 1 `corpus_oracle`); clippy core 10 / runtime 13 / validation.rs 4 = baseline (zero-new; `corpus_oracle.rs` clean); self-check exit 0. Oracle caught tclite/Lispish divergence (→ `.7.5`); green proof on 2 authored grammars |
| `2026-06-17` | `RUST-PARITY.7.5.1` | `cargo test --manifest-path rust/Cargo.toml` (full, baseline 238); `cargo clippy -p linkedspec-core -p linkedspec-runtime --tests` (warning-multiset diff); `perl -c tools/gen_oracle_corpus.pl`; `scripts/check_memory_architecture.sh` | `cargo test` = **242 passed / 0 failed** (238 baseline + 4 new: 3 parser + 1 compiler header-line-regex tests; `linkedspec_core` 90→94; corpus_oracle 1 green proof — tclite re-deferred to `.7.5.3`); clippy warning multiset = baseline (linkedspec-core 10 / linkedspec-runtime 13 / validation.rs 4 — zero-new); clippy `--tests` exit-101 is pre-existing `approx_constant` in untouched `expr.rs:687`/`types_test.rs:143` (Open Questions); generator `perl -c` OK; self-check exit 0. Oracle revealed a 2nd tclite blocker (action-edge fluent lowering) → new leaf `.7.5.3` |
| `2026-07-02` | `RUST-PARITY.7.5.3` | KM retrieval; source/corpus evidence audit; Rust `corpus_oracle`; mdBook build; Knowledge Map regenerate/check; memory architecture; doctrine registry; `git diff --check`; full local CI | Reconciliation slice only, no runtime code change. Existing code contains action-edge fluent parsing/compilation/runtime execution (`ActionEdge.fluent_chain`, `AcodeEntry.fluent_chain`, `execute_action_edge_fluent_chain`), and `tools/gen_oracle_corpus.pl` plus the checked-in corpus contain active `tclite_command_subst` and `tclite_double_quote` fixtures. Rust `corpus_oracle` passes on the current **62-fixture** corpus; full local CI remains green. Frontier → `.7.5.2` |
| `2026-07-02` | `RUST-PARITY.7.5.2` | TOOLBOX Perl generated-source probes; `cargo fmt --manifest-path rust/linkedspec-core/Cargo.toml`; `cargo fmt --manifest-path rust/linkedspec-runtime/Cargo.toml`; focused Rust parser/runtime checks; `perl -c tools/gen_oracle_corpus.pl`; `perl tools/gen_oracle_corpus.pl`; Rust `corpus_oracle`; mdBook build; Knowledge Map regenerate/check; memory architecture; doctrine registry; `git diff --check`; full local CI | Lispish `scalaref(retv, {content})` parity landed and `lispish_x_y` is active. Focused parser/runtime checks and 63-fixture corpus oracle pass; full gate evidence is recorded in the commit workflow. Frontier → `.7.2` |
| `2026-07-02` | `RUST-PARITY.7.2` | `cargo fmt --manifest-path rust/linkedspec-core/Cargo.toml`; `cargo fmt --manifest-path rust/linkedspec-runtime/Cargo.toml`; focused Rust parser/runtime checks; `perl -c tools/gen_oracle_corpus.pl`; `perl tools/gen_oracle_corpus.pl`; Rust `corpus_oracle`; mdBook build; Knowledge Map regenerate/check; memory architecture; doctrine registry; `git diff --check`; full local CI | Header-rest multiline lifecycle parsing and captures-only helper indexing landed; `hlink_substitution` raw-string fixtures are active; 65-fixture corpus oracle passes. Broader candidate divergences are recorded and deferred to `.7.3`/later. |
| `2026-07-03` | `RUST-PARITY.7.3.1` | Task/KM context read; `tools/gen_oracle_corpus.pl` audit; corpus README/runner audit; `TOOLBOX.md` hang protocol read; Knowledge Map oracle-card retrieval; Knowledge Map regenerate/check; memory architecture; doctrine registry; `git diff --check` | PASS — batch-2 oracle work split into trace-first timeout/hang, hlink delimiter/link-path, simple-spec structural divergence, action-parser/null-output, and RTL/plugin/legacy lanes. No parser/runtime/corpus code changed. |
| `2026-07-03` | `RUST-PARITY.7.3.2` | KM retrieval (`rtlutils-regex-hang`, `rust-perl-output-oracle`); `perl -Iperl` module-path check; core/spec/corpus `RTLUtils` scan; fork+SIGKILL census around the current generator; `perl -c -Iperl tools/gen_oracle_corpus.pl`; `perl -Iperl tools/gen_oracle_corpus.pl`; forced `ORACLE_TIMEOUT=0` hard-kill check; Rust `corpus_oracle`; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — no live current RTLUtils timeout; generator completed 65 fixtures under a parent hard-timeout wrapper; `run_oracle` now uses per-case fork/SIGKILL instead of `alarm()`; normal regeneration is byte-identical; forced timeout reports `ORACLE_TIMEOUT after 0s (hard kill)`; Rust `corpus_oracle` passes; full local CI passes with phase0 1018 tests. Frontier → `.7.3.3` |
| `2026-07-03` | `RUST-PARITY.7.3.3.1` | Shipped spec read; existing hlink corpus read; phase0 hlink parser-smoke read; direct `JSON::PP` scalar-ref probe | PASS — `{abc}` is JSON-safe; bracket and mixed hlink outputs contain Perl scalar refs that the current oracle cannot encode. No generator/corpus/runtime code changed. Frontier → `.7.3.3.2` |
| `2026-07-03` | `RUST-PARITY.7.3.3.2` | Direct Perl `JSON::PP` curly probe; `perl -c -Iperl tools/gen_oracle_corpus.pl`; `perl -Iperl tools/gen_oracle_corpus.pl`; Rust `corpus_oracle`; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — `hlink_curly_brace` added for `{abc}` with expected `["{abc}"]`; generator produced **66** fixtures; Rust `corpus_oracle` passes over the 66-fixture corpus; full local CI passes with phase0 **1018** tests. Bracket/mixed scalar-ref hlink cases untouched. Frontier → `.7.3.3.3` |
| `2026-07-03` | `RUST-PARITY.7.3.3.3` | Direct Perl `Data::Dumper`/`JSON::PP` scalar-ref probe; Rust source audit of `RuntimeValue`; temporary Rust `hlink_substitution` execution probe then removal; `git diff -- rust/linkedspec-runtime/tests/integration_test.rs`; Rust `corpus_oracle`; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS/DEFERRED — Perl bracket/mixed outputs contain scalar refs that `JSON::PP` cannot encode; Rust has no neutral scalar-ref runtime value and the current hlink scalar-ref action payload fails parsing before falling through to `exit_now(2)`. Bracket/mixed fixtures are deferred to `.7.3.3.4`; temporary probe removed; corpus oracle passes over **66** fixtures; full local CI passes with phase0 **1018** tests. Frontier → `.7.3.4` |
| `2026-07-03` | `RUST-PARITY.7.3.7` | Shipped-spec/input fork+SIGKILL census; focused `BNF` build-vs-parse separation; `LINKEDSPEC_TRACE_LEVEL=debug` trace to `/tmp/linkedspec-bnf-build.trace`; `perl -c -Iperl tools/gen_oracle_corpus.pl`; forced `ORACLE_TIMEOUT=0` generator run; normal generator regeneration; Rust `corpus_oracle` | PASS — `BNF` timeout was parser construction outside the prior oracle guard, not parse execution; trace reached successful parser generation. `tools/gen_oracle_corpus.pl` now builds and parses inside the timeout child; forced timeout reports `hard kill during parser build/parse`; normal regeneration writes **66** byte-identical fixtures; Rust `corpus_oracle` passes. Frontier → `.7.3.4` |
| `2026-07-03` | `RUST-PARITY.7.3.4` | `perl -Iperl` module-path check; Perl reference `LinkedSpec::get_parser`/`JSON::PP` probes for `portmap`, `lib_reader`, and `ebnf`; temporary Rust probe using the `corpus_oracle` parse/validate/compile/execute path; Rust compiled-rule dumps; `LinkedSpec::call_spec_handler_subst` lowering probe | PASS/SPLIT — all three structural mismatches reproduced. `portmap` exposes runtime boolean/list-context and recursive fluent aggregation gaps; `lib_reader` first exposes a parser/compiler drop of header-rest action edges on regex-less top rules; `ebnf` compiles the fluent chains but runtime duplicates rule headers and drops token payloads. No fixture was safe to land; implementation split to `.7.3.4.1`-`.7.3.4.3`. Frontier → `.7.3.4.1` |
| `2026-07-03` | `RUST-PARITY.7.3.4.1` | `cargo fmt --manifest-path rust/linkedspec-core/Cargo.toml`; `cargo fmt --manifest-path rust/linkedspec-runtime/Cargo.toml`; focused core `action_edge` and `parse_blind_edge` tests; focused runtime compact-arrow regression; real `lib_reader` compile/execute probe; Rust `corpus_oracle`; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS/SPLIT — Rust now preserves header-rest body syntax that starts with `->`, `->Child.push`, or lifecycle fluent calls, and `->`/`=>` spacing matches `specs/spec.spec` optional whitespace. `lib_file` now compiles the `group` `.push` dispatch and representative `lib_reader` probes no longer collapse to `[[]]`; remaining null capture fields are split to `.7.3.4.4`. Frontier → `.7.3.4.4` |
| `2026-07-03` | `RUST-PARITY.7.3.4.4` | `cargo fmt --manifest-path rust/Cargo.toml --all`; `perl -c -Iperl tools/gen_oracle_corpus.pl`; `perl -Iperl tools/gen_oracle_corpus.pl`; focused Rust `.7.3.4.4` integration tests; Rust `corpus_oracle`; `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --lib`; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; broad `cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime` residual check | PASS/RESIDUAL — dependency-resolved edge-only child captures are locked, and the actual `lib_reader` blocker is closed by Rust statement-form helper mutation parity: `substr`/`regex_subst` mutates scalar targets with regex replacement flags and `split(array(target), scalar(source), delimiter)` mutates array targets. Added `lib_reader_sattribute` and `lib_reader_cattribute`; the oracle corpus now has **68 fixtures** and Rust `corpus_oracle` passes. Runtime lib clippy exits 0 with the existing warning baseline; `clippy --tests` still exits 101 on the existing `approx_constant` test literal. The broad runtime package run passes 124 unit tests and the 68-fixture corpus oracle, then reproduces the known 9 broader integration failures outside this leaf (141 passed / 9 failed). Frontier → `.7.3.4.2` |
| `2026-07-03` | `RUST-PARITY.7.3.4.2` | `cargo fmt --manifest-path rust/Cargo.toml --all`; focused regex-engine internal-alternation unit test; focused Rust `.7.3.4.2` integration tests; `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-core -p linkedspec-runtime --lib`; `perl -c -Iperl tools/gen_oracle_corpus.pl`; `perl -Iperl tools/gen_oracle_corpus.pl`; Rust `corpus_oracle`; mdBook build; Knowledge Map/memory/doctrine/whitespace gates | PASS — Rust now recognizes `or`/`and`/`not`, splices explicit flattening helper calls in `array(...)` list context, and wraps each rule regex before dispatch alternation joining so internal `|` branches stay inside their owning action edge. Added `portmap_bare`, `portmap_bit`, `portmap_slice`, and `portmap_constant`; the oracle corpus now has **72 fixtures** and Rust `corpus_oracle` passes. Frontier → `.7.3.4.3` |
| `2026-07-04` | `RUST-PARITY.7.3.4.3` | `cargo fmt --manifest-path rust/Cargo.toml --all`; focused Rust `.7.3.4.3` integration tests; lower-unbounded quantifier unit test; focused scalar/aggregate assignment regression tests; `perl -c -Iperl tools/gen_oracle_corpus.pl`; `perl -Iperl tools/gen_oracle_corpus.pl`; Rust `corpus_oracle`; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — Rust action-edge blocks and fluent chains now reuse the already matched child return for `call(child)`, `push(child)`, `push(child,target)`, and child-index push forms instead of re-searching after the parent edge match; passive terminal children skip re-execution like the Perl generated handlers. Scalar-vs-aggregate assignment boundaries and helper-context aggregate bare reads are preserved. Added `portmap_concatenation`, `ebnf_expression_rules`, and `ebnf_logging_annotation`; the oracle corpus now has **77 fixtures** and Rust `corpus_oracle` passes; full local CI passes with phase0 **1021** tests. Frontier → `.7.3.5` |
| `2026-07-04` | `RUST-PARITY.7.3.5` | KM retrieval; Perl reference probes for `BNF`, `DT`, `ifelse`, `operators_try`, and `spec.spec` smokes; temporary Rust probes removed; `cargo fmt --manifest-path rust/Cargo.toml --all`; focused Rust parser quoted-brace tests; `perl -c -Iperl tools/gen_oracle_corpus.pl`; `perl -Iperl tools/gen_oracle_corpus.pl`; Rust `parse_all_shipped_specs`; Rust `corpus_oracle`; mdBook build; Knowledge Map/memory/doctrine/whitespace gates | PASS — `BNF`, `DT`, `ifelse`, and `operators_try` representative inputs are diagnostic/null-output cases in the Perl reference and were not promoted as semantic fixtures. Rust now ignores quoted braces while scanning `.spec` code blocks, fixing the `operators_try` action-parser warnings. Added `spec_spec_minimal_rule`, `spec_spec_action_edge`, `spec_spec_user_function_definition`, and `spec_spec_comment_skip`; the oracle corpus now has **81 fixtures** and Rust `corpus_oracle` passes. Frontier → `.7.3.6` |
| `2026-07-04` | `RUST-PARITY.7.3.6` | KM retrieval; phase0 shipped-spec smoke/source reads; Perl reference JSON probes; temporary Rust candidate probe removed; `perl -c -Iperl tools/gen_oracle_corpus.pl`; `perl -Iperl tools/gen_oracle_corpus.pl`; Rust `corpus_oracle`; Rust `parse_all_shipped_specs`; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS/SPLIT — Seven green RTL/plugin/legacy safety smokes landed: `regdef_nested_register_fields`, `tablegrep_simple_term`, `simenv_multiline_value`, `vhdl_library_use`, `ds_vhistory_version_entry`, `pplugin_empty`, and `tkgui_empty`. The oracle corpus now has **88 fixtures** and Rust `corpus_oracle` passes. Richer `pplugin`, `tkgui`, `sdce`, recursive `tablegrep`, `simenv` single-line value, VHDL port-clause, `ds_vhistory` branch, and placeholder `verilog` candidates remain explicit follow-up blockers. Full local CI passes with phase0 **1021** tests. Frontier → `.7.4` |
| `2026-07-04` | `RUST-PARITY.7.4` | `perl -c -Iperl tools/gen_oracle_corpus.pl`; `perl -Iperl tools/gen_oracle_corpus.pl`; `cargo fmt --manifest-path rust/Cargo.toml --all`; Rust `corpus_oracle`; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — generator emits **88 fixtures plus manifest**; the Rust runner validates `manifest.json`, rejects missing/stale fixture drift, executes fixtures in manifest order, and passes **3 tests** including two focused drift tests plus all **88** oracle fixtures. `.7` is closed. Frontier → `.8` |
| `2026-07-04` | `RUST-PARITY.8.2` | `cargo fmt --manifest-path rust/Cargo.toml --all --check`; `cargo test --manifest-path rust/Cargo.toml -p linkedspec-runtime --test source_emitter -- --nocapture`; `cargo clippy --manifest-path rust/Cargo.toml -p linkedspec-runtime --test source_emitter` | PASS — emitted-source scaffold test parses/validates/compiles the smoke spec, confirms interpreter output, emits generated Rust source, builds it in an isolated temporary crate with `cargo test --offline --quiet`, and executes the generated `parse("hello world")` path. Existing nested `rgx`/core/runtime clippy warning noise remains baseline; no `.8.2` failure. Frontier → `.8.3` |
| `2026-07-04` | `RUST-PARITY.8.3` | Task/KM/code read; `git diff --check`; Knowledge Map/memory/doctrine gates | PASS/SPLIT — `.8.3` was split before code because non-REP emission still bundles metadata/family-plan, acode, bcode, and matrix-closeout mechanisms; Rust `CompiledRule` needs explicit mode/family metadata before generated source can robustly distinguish OR-bcode from AND-bcode. No Rust source changed. Frontier → `.8.3.1` |
| `2026-07-04` | `RUST-PARITY.8.3.1` | focused fmt/tests/clippy; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — `CompiledRule` now preserves parsed `RuleMode`, generated Rust source embeds and validates `GENERATED_RULES`, and the focused generated-source matrix compiles/runs default, OR acode, AND single-acode, AND sequential-acode, AND bcode, and OR bcode generated modules through the existing interpreter delegation. `tools/run_ci_local.sh` passed with 1021 phase0 regression tests. Frontier → `.8.3.2` |
| `2026-07-04` | `RUST-PARITY.8.3.2` | focused Rust fmt/source-emitter/clippy; runtime lib tests; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — generated source now enters the plan-aware executor; default and OR acode rules run directly with interpreter-equivalent lifecycle/action-edge semantics, while later families keep their fallback path. `tools/run_ci_local.sh` passed with 1021 phase0 regression tests. Frontier → `.8.3.3` |
| `2026-07-04` | `RUST-PARITY.8.3.3` | focused Rust fmt/source-emitter/runtime-lib/clippy; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — generated source now directly handles AND single-acode and AND sequential-acode families. The Rust regex/acode loop enforces ordered non-repetition AND sequence, and the generated-source matrix proves a second-slot return payload that would fail if execution stopped after the first regex. `tools/run_ci_local.sh` passed with 1021 phase0 regression tests. Frontier → `.8.3.4` |
| `2026-07-04` | `RUST-PARITY.8.3.4` | focused Rust fmt/source-emitter/runtime-lib/clippy; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — generated source now directly handles AND bcode and OR bcode families. The shared blind-edge tail helper preserves child-return-to-`retv`, attached code/fluent execution, parent `E` behavior, and OR no-match `LX`; OR bcode stops after the first truthy child return. The generated-source matrix proves ordered AND child-return collection, OR first-match behavior, and OR no-match `LX`. `tools/run_ci_local.sh` passed with 1021 phase0 regression tests. Frontier → `.8.3.5` |
| `2026-07-04` | `RUST-PARITY.8.3.5` | focused Rust fmt/source-emitter/runtime-lib/clippy; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — generated-plan routing is exhaustive for all six non-REP families, `Repetition` is the only generated fallback, and the source-emitter matrix asserts complete non-REP family coverage before REP work. `tools/run_ci_local.sh` passed with 1021 phase0 regression tests. Frontier → `.8.4` |
| `2026-07-04` | `RUST-PARITY.8.4` | focused Rust fmt/source-emitter/runtime-lib/clippy; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — generated source now classifies and directly runs `RepAcode`, `RepBcode`, `RepAndAcode`, and `RepAndBcode`; repeated bcode paths honor min/max and zero-progress termination; REP-AND acode counts complete ordered groups; the generated-source matrix covers all REP families plus zero-progress, recursion termination, and legacy `Repetition` plan compatibility. `tools/run_ci_local.sh` passed with 1021 phase0 regression tests. Frontier → `.8.5` |
| `2026-07-04` | `RUST-PARITY.8.5` | focused Rust fmt/source-emitter/corpus/runtime-lib/clippy; mdBook build; Knowledge Map/memory/doctrine/whitespace gates; full local CI | PASS — `source_emitter` now has 3 tests: all-family generated-source matrix, legacy `Repetition` compatibility, and generated-source validation over an 8-case manifest-backed corpus subset (`proof_edge_array_literal`, `proof_edge_scalar_literal`, `autoexist_array_bare_arg`, `terse_1_5_2_primitive_literals`, `terse_2_2_3_attached_if_blocks`, `terse_4_3_2_user_function_runtime`, `tclite_command_subst`, `portmap_bare`). Focused `source_emitter` passed 3/3, `corpus_oracle` passed 3/3, runtime lib passed 126/126, and `tools/run_ci_local.sh` passed with 1021 phase0 regression tests. Frontier → `.9` |
| `2026-07-04` | `RUST-PARITY.9` | mdBook build; memory/doctrine/whitespace gates; full local CI | PASS — roadmap/live docs/book/architecture state now agree on the closed Rust follow-on, generated-source coverage boundary, and next PNT leaf (`TOP-RULE-AS-NORMAL.3.2`). `tools/run_ci_local.sh` passed with 1021 phase0 regression tests. |

### RUST-PARITY.1 Inventory — 2026-06-16

**Gap 1: Conditional control flow (largest gap)**
- `if(cond, then, elseif(...), else(...))` / `if(cond) { ... } elseif(cond) { ... } else { ... }` / `endif()`
- `switch(expr) { case(val) { ... } default { ... } }` / `endswitch()` / `endcase()`
- Perl owners: `ActionIR::ControlFlow.pm` (~20 lowering subs), `ActionIR::FlowExpr.pm`
- Rust: `engine.rs` has no if/elseif/else/switch/case/default match arms

**Gap 2: BACKTRACK/IBACKTRACK**
- `BACKTRACK` saves cursor position, `IBACKTRACK` restores it (local rewind, not systemic backtracking)
- Perl: `ActionIR::MethodLowering.pm`, `RuntimeContext` cursor stack
- Rust: `RuntimeContext` has `pos` and `capture_start` but no cursor stack

**Gap 3: Self-hosting (spec.spec)**
- Rust cannot compile and run `specs/spec.spec` through itself
- Perl: `BootstrapSpec.pm` + `spec.spec` → dual-path parse (bootstrap primary, spec.spec as diagnostic side channel)
- Rust: only bootstrap-style parser in `parser.rs` — no spec.spec-based self-parse path

**Gap 4: strict_syntax validation mode**
- Perl: `Validation.pm` `validate_dsl_syntax(...)` with `strict_syntax => 1` promotes reference warnings to hard errors
- Rust: `validation.rs` has 6 checks but no `strict_syntax` mode

**Gap 5: Remaining helpers** (implemented = ✓, missing = ✗)
- Capture/mark extensions: `capture_len_from` ✗, `capture_until_cursor_from` ✗, `capture_until_cursor_len_from` ✗, `capture_take_until_cursor_from` ✗, `capture_take_until_cursor_len_from` ✗, `capture_take_len_from` ✗, `capture_rest_from` ✗, `capture_rest_len_from` ✗, `capture_take_rest_from` ✗, `capture_take_rest_len_from` ✗, `capture_between` ✗, `capture_len_between` ✗, `mark_copy` ✗, `mark_input_start` ✗, `mark_input_end` ✗
- Entry/match named: `entry_named` ✗, `entry_has` ✗, `entry_map`/`entry_named_map` ✗, `match_named` ✗, `match_has` ✗, `match_map`/`match_named_map` ✗
- Input boundaries: `input_end_line` ✗, `input_end_col` ✗
- Anonymous capture variants: `capture_slice_until_cursor` ✗, `capture_slice_until_cursor_len` ✗, `capture_take_until_cursor` ✗, `capture_take_until_cursor_len` ✗, `capture_take_len` ✗, `capture_take_rest` ✗, `capture_take_rest_len` ✗
- Return helpers: `return(expr)` ✓ (general return works), but `return_imatch`/`return_im` ✗ (compat aliases — low priority)
- Compat aliases: `tail(...)` ✗, `drop_last(...)` ✗ (aliases for `drop_front`/`drop_back`), `array_values(...)` ✗, `flatten(...)` ✗ (aliases for `array_copy`/`flat`)
- `IBACKTRACK` cursor-seek ✗ (tied to Gap 2)

**Gap 6: Code-gen emitter**
- Perl: `HandlerVariantEmitter.pm` dispatches to `%BACKEND_EMITTERS` (Perl default, JSON/AST diagnostic)
- Rust: interpreter-only mode — no `HandlerIR → Rust source` emitter
- Deferred in v0.1 design — needed for `cargo build`-able parser output

**Gap 7: Test corpus breadth**
- Rust `tests/corpus/`: 4 entries (simple_grammar, recursive, lifecycle, AND+REP)
- Perl `t/phase0_regression.t`: 1005 subtests across 20 shipped specs
- All 20 shipped specs parse+validate+compile in Rust (serde roundtrip), but only 4 exercised in runtime execution

## Commit Log

Canonical task-node Commit fields retain every consolidated table label, reference and note. Exact source and
Git comparison are owned by `LIVE-DOCUMENT-PRESSURE-CONTAINMENT.6`; no acceptance or verification field changes.

## Changelog

- `2026-06-16`: Created task tree.
- `2026-06-16`: `.4` (Rust self-hosting on spec.spec) marked `superseded` — wrong target; spec.spec rewritten on the Perl side under `SPEC-SPEC-SELFHOST`. Recorded the 3-agent parity audit (real follow-on). Committed in-flight Rust exploration (expr/parser/runtime/helpers) as a WIP checkpoint.
- `2026-06-16`: Split `.5` (PNT rule 5 — too broad for one signoff slice) into `.5.1` retv-propagation BLOCKER fix, `.5.2` match/entry split, `.5.3` char-based indexing + cursor line/col, `.5.4` dedupe match arms + REP zero-progress guard, `.5.5` ~30 missing helpers + real aliases. Sequenced retv-first. Confirmed the Rust baseline green (182 tests, 0 failed) before splitting. Frontier → `.5.1`. No code change (tree structuring only).
- `2026-06-16`: `.5.1` done — fixed the child-return (retv) propagation BLOCKER. `execute_rule` now returns the rule's value via a per-invocation channel; `->`/`=>` dispatch set `retv` to the child return; `return(...)` feeds the channel without disturbing the accumulator contract; `call(child)` now resolves a bare rule name and returns the child value. 4 new integration tests (acode/OR, blind-call/AND, REP, `call`); `cargo test` 186/186; clippy adds no new warnings. Frontier → `.5.2` (match_*/entry_* split).
- `2026-06-16`: `.5.2` done — separated `entry_*` from `match_*` in the Rust engine. `execute_rule` now emulates Perl's per-handler `IMATCH`/`LMATCH` lexicals via a `SavedMatchState` save/restore on the shared `RuntimeContext`: entry match = the dispatcher's local match (`$info = $minfo`), local match = the rule's own regex match, entry seeded from the first own match only for the dispatcher-less top rule, both restored on exit. 3 new integration tests (child entry/local divergence, parent match survives child dispatch, top-rule entry==local); `cargo test` 189/189; clippy adds no new warnings. New knowledge card `docs/knowledge/rust-entry-match-separation.md`. Frontier → `.5.3` (char-based indexing + cursor line/col).
- `2026-06-16`: `.5.3` done — char-based offsets/slicing in the Rust engine. Internal positions stay byte-based (the regex engine is byte-based); the DSL boundary is now char-based for Perl parity. `byte_to_char_offset`/`char_substr` helpers added; `substr`/`input_slice` char-slice (no multibyte panic); cursor/input/capture/mark/entry/match positions+lengths and `length` convert byte→char; `cursor_col` is char-distance. `entry_start_pos`/`match_start_pos` no longer hardcoded `0.0` — `RuntimeContext` stores `entry/match_*_byte` spans (part of `SavedMatchState`). 7 new multibyte tests (`chars_5_3_*`); `cargo test` 196/196; clippy adds no new warnings. New knowledge card `docs/knowledge/rust-char-based-offsets.md`. Frontier → `.5.4` (dedupe match arms + REP zero-progress guard).
- `2026-06-16`: `.5.4` done — dedup shadowed `call_helper` arms + fix the REP zero-progress guard. Removed the first `print`/`hash`/`hash_copy` arms so the better later arms win (Hash-arg merge for `hash`, raw-AST target resolution for `hash_copy`, consolidated `say|print|print_each`); cleared 3 `unreachable_patterns` warnings. REP loop now captures `pos_before` per iteration and breaks when `ctx.pos == pos_before` (no cursor progress) instead of an iteration cap. 2 new tests; `cargo test` 198/198; clippy touched-file warnings 15 → 12. No knowledge card (localized fix). Frontier → `.5.5` (~30 missing helpers + real aliases).
- `2026-06-16`: `.5.5` split (PNT rule 5 — too broad for one signoff slice). An engine.rs audit confirmed ~28 helpers across ~7 families are genuinely missing (only `drop_front`/`drop_back`/`array_copy`/`flat_array` of the family exist). Split into `.5.5.1` named-group readers (entry/match `_named`/`_has`/`_map`), `.5.5.2` input-boundary helpers + real compat aliases, `.5.5.3` mark-based capture family (`capture_*_from`/`_between`, `mark_*`), `.5.5.4` anonymous capture-slice variants. The `.1` Inventory (Gap 5) + the book helper-contract-catalog are the implementation spec. Surfaced an alias-policy Open Question (book §catalog says `tail`/`drop_last`/`entry_named_map` are "retired aliases"; `ROADMAP_V2` says they "remain compatibility syntax") to resolve against the Perl reference in `.5.5.2`. No code change (tree structuring only). Frontier → `.5.5.1`.
- `2026-06-16`: `.5.5.2` done — input-boundary helpers + the `flat` splice. Added 3 `call_helper` arms in `engine.rs`: `input_end_line` (1 + whole-input newline count), `input_end_col` (char distance past the last newline, +1 when none — modeled on `cursor_col`, multibyte-correct), and generic `flat(container)` (Array→Array / Hash→Hash / scalar→single-element list). **Resolved the parked alias-retirement Open Question against the Perl reference:** `tail`/`drop_last`/`flatten`/`array_values` are NOT recognized by the reference (no recognition regex, unused in 20 specs, 0 phase0 locks, retired in `COMPAT-ALIAS-RETIREMENT.1`, "Retired" in the book catalog) → deliberately NOT added to Rust (parity = match the reference's surface); only canonical `flat` was missing and is added. 3 new tests (`helpers_5_5_2_*`); `cargo test` 207/207; clippy 13 = baseline 13 (zero new). New knowledge card `docs/knowledge/rust-retired-array-aliases-not-added.md`. No book change (catalog already conforms; book sync `.9`). Flagged stale `ROADMAP_V2` 256–262 alias text as a separate Perl-side doc-sync follow-up. Frontier → `.5.5.3` (mark-based capture family).
- `2026-06-16`: `.5.5.1` done — added the 8 named-group reader helpers (`entry_named`/`entry_has`/`entry_map`/`entry_named_map` + the four `match_*`) as `call_helper` arms reading the existing `ctx.entry_named`/`ctx.match_named` maps (populate at engine.rs:280/291, save/restore in `SavedMatchState`). `entry_named_map`/`match_named_map` are combined-arm aliases of `entry_map`/`match_map` (the catalog's retired aliases); a new free `named_map_to_hash` sorts keys for a deterministic hash projection (matching `sorted_keys`/`sorted_values`). Purely additive — no struct/population changes. 6 new tests (`helpers_5_5_1_*`, end-to-end via `(?P<name>…)` regexes). `cargo test` 204/204; clippy lint multiset byte-identical to the stashed baseline (13 = 13; zero new). No book change (catalog §8 conforms; book sync `.9`); no knowledge card (localized additive). Frontier → `.5.5.2`.
- `2026-06-16`: `.5.5.3` done — mark-based capture family + `capture_from` parity fix. Resolved the parked Open Question as **option (a)** (user-confirmed): `capture_from` now ends at the start of the current local match (`ctx.match_start_byte`, Perl `$LSPOS - length $LMATCH`), was the cursor; landed test `helpers_5_2_mark_and_capture_from` updated `"hello"`→`""`. Implemented 15 mark-family `call_helper` arms in `engine.rs` from the authoritative `Contracts.pm` (~690–1047) + guarded free helpers `span_text`/`span_char_len`: match-start readers `capture_len_from`/`capture_take_len_from`; cursor readers `capture_until_cursor_from`(+`_len`)/`capture_take_until_cursor_from`(+`_len`); end-of-input readers `capture_rest_from`(+`_len`)/`capture_take_rest_from`(+`_len`); two-mark `capture_between`/`capture_len_between`; setters `mark_input_start`/`mark_input_end`/`mark_copy` (2-arg). `_take_*` advance the mark; text → slice, `_len_*` → char count; missing mark / reversed span → undef. **Book catalog §7 corrected to the contract** (user-requested): `capture_from` endpoint, 2-arg `mark_copy`, `_until_cursor_`/`_take_` + anonymous `capture_slice` wording, missing `_len_` companions. 16 new tests (`helpers_5_5_3_*`); `cargo test` 223/223; clippy 13 = baseline 13 (zero new); `mdbook build` exit 0. New knowledge card `docs/knowledge/rust-mark-based-capture-family.md`. Discovered + recorded: anonymous `capture_slice`/`_len` Rust endpoint gap (folded into `.5.5.4`) and inventory-missing `mark_match_*`/`mark_entry_*`/`capture_take(mark)`/`capture_take_between(_len)` (follow-up leaf). Frontier → `.5.5.4`.
- `2026-06-16`: `.6` done — strict_syntax validation mode in the Rust variant (audit Gap 4). Added `validate_with_options(spec, strict_syntax: bool)` to `rust/linkedspec-core/src/validation.rs`; `validate(spec)` is now a non-strict wrapper (all ~70 call sites unchanged). Strict mode adds `check_unused_rules` (`unused = defined − used`), promoting the Perl reference's unused-rule warning to a hard error — parity with `Validation.pm validate_dsl_syntax(..., strict_syntax => 1)`, semantics verified empirically (top rule NOT exempt; undefined reported first). Undefined refs are already fatal here in every mode (`check_edge_targets`, runs first — preserving the reference's undefined-before-unused order), so strict's observable addition is the unused-rule rejection (a pre-existing, recorded default-stricter-than-Perl divergence left as-is). 4 new `validation.rs` tests; `cargo test` 237/237; clippy core validation.rs 4 = baseline 4, runtime 13 = baseline 13 (zero new). No book change (strict contract already in `compiler/pipeline-overview.md`; book sync `.9`). Knowledge card `docs/knowledge/rust-strict-syntax-validation.md`. Frontier → `.7` (expand Rust runtime test corpus).
- `2026-06-16`: `.5.5.4` done — full **anonymous** capture-slice family in the Rust engine + `capture_slice`/`capture_slice_len` endpoint fix; this closes `.5.5` and `.5` (all parity-gap children done). Fixed `capture_slice`/`_len` to end at `ctx.match_start_byte` (was `ctx.pos`), the anonymous analog of the `.5.5.3` `capture_from` fix; updated the two landed `helpers_5_2_capture_slice_*` tests (`"hello"`→`""`, `>0`→`0`). Added 10 `call_helper` arms in `engine.rs` (reading `ctx.capture_start` = Perl `$IPOS`, from `Contracts.pm` ~366–656, reusing `span_text`/`span_char_len`): `capture_slice_until_cursor`(+`_len`) → cursor; `capture_take`(+`_len`) → match-start then advance to cursor; `capture_take_until_cursor`(+`_len`) → cursor then advance; `capture_rest`(+`_len`) → end-of-input; `capture_take_rest`(+`_len`) → end then advance. Folded in the inventory-missing-but-same-family `capture_rest`/`capture_rest_len`/`capture_take` so the anonymous family lands complete (the `.5.5.3`-discovered mark/match/entry-anchored helpers stay a separate deferred follow-up). Book catalog §7: added the 10 anonymous entries + refined the intro endpoint list and destructive-`_take_` note (variant-agnostic, no-drift); the `capture_slice` match-start contract was already documented (the `.5.5.3` gap, now closed by the engine fix). 10 new tests (`helpers_5_5_4_*`); `cargo test` 233/233; clippy 13 = baseline 13 (zero new); `mdbook build` exit 0. New knowledge card `docs/knowledge/rust-anonymous-capture-slice-family.md`. Frontier → `.6` (strict_syntax validation mode).
- `2026-06-17`: `.7.1` done — Perl↔Rust output-oracle mechanism + canonical wrap rule + green first proof. New `tools/gen_oracle_corpus.pl` (timeout-guarded Perl generator, `JSON::PP->canonical(1)`) emits `tests/corpus/<case>/{input.spec,input.txt,expected.json}` (the book `backend-handoff.md` corpus format — zero added drift); new Rust runner `tests/corpus_oracle.rs` enumerates the corpus and asserts `engine.execute(input) == [reference]` (Rust wraps the Perl top-rule value one level). **The oracle's first run disproved the `.7`-split premise:** tclite `[]` → Rust `[]` and Lispish → `exit_now(1)` — both blocked by a single-regex `name : /re/` rule compiling as 0-regex (so `-> child[0]` edges never fire). Deferred the engine fix to new leaf `.7.5` (now first in frontier, blocking `.7.2`/`.7.3`). Mechanism proven green on 2 controlled authored grammars (scalar + nested-array) that avoid every divergence source. `cargo test` 238/238 (237+1); clippy zero-new (core 10/runtime 13/validation.rs 4); `perl -c` OK; self-check exit 0. Knowledge card `docs/knowledge/rust-perl-output-oracle.md`. Frontier → `.7.5` (Rust engine output-parity fix).
- `2026-06-17`: `.7.5` split (PNT rule 5 — two independent root causes, confirmed separable by a read-only investigation + a direct read of `parser.rs:86`). `.7.5.1` = fix the header-line-regex → 0-regex parser bug (`parser.rs:86` `(\S*)`→`([^\s/]*)`; the shared root cause for tclite/Lispish/most shipped specs; foundational — every rule header — so the open/close-pair semantics + full suite + oracle must be verified). `.7.5.2` = add `{…}` hash-literal/field-accessor to `expr.rs:299` for Lispish's `scalaref(retv, {content})` (depends on `.7.5.1`). No code change (tree structuring only). Frontier → `.7.5.1`.
- `2026-06-16`: `.7` split (PNT rule 5 — too broad for one signoff slice). A two-agent read-only investigation (Rust test/corpus infra + Perl reference output path) found no oracle mechanism / canonical cross-variant output form exists yet, that the Perl reference returns the top rule's value directly while the Rust engine wraps it one level in the accumulator (shape reconciliation needed), that ~16 of the 20 specs have no input fixtures (authored inputs required), and that the `RTLUtils` hang needs a hard-timeout guard. Split into `.7.1` (oracle mechanism + canonical form + first proof on tclite/Lispish), `.7.2` (expand corpus — simple specs, batch 1), `.7.3` (expand corpus — remaining/harder specs, batch 2, RTLUtils-guarded), `.7.4` (regression guard + finalize). Architecture: a timeout-guarded Perl fixture generator emits canonical-JSON fixtures into `rust/linkedspec-runtime/tests/corpus/`; a Rust fixture-runner test compares `engine.execute(input)` against them (Perl-free `cargo test`; realizes ADR 0006 §Phase 8.6 language-neutral corpus). No code change (tree structuring only). Frontier → `.7.1`.
- `2026-06-17`: `.7.5.1` done — fixed the header-line-regex → 0-regex parser bug (`rust/linkedspec-core/src/parser.rs:86` `(\S*)`→`([^\s/]*)`). A `/…/` regex on a rule's header line is no longer swallowed by the mode-suffix group: single-regex header rules (`semi_colon : /;/`) now register their regex, and `/open/ /close/` bracket pairs register both (open=idx 0, close=idx 1) so the self-recursive `-> name[1]` close edge resolves — the recursive bracket matcher tclite/Lispish intend. 4 new unit tests (3 `parser.rs`, 1 `compiler.rs`); `cargo test` 242/242 (238 + 4); clippy warning multiset = baseline (core 10 / runtime 13 / validation.rs 4, zero-new). **PNT split:** the fix is necessary but NOT sufficient for tclite — the oracle still showed `[]` because tclite accumulates via fluent continuations on ACTION edges (`-> command_subst .push`, `-> command_subst[1] .return(...)`) and the parser attaches `.method` fluent chains only to BLIND edges (`=>`), so the compiler discards them after a `->` edge. That independent gap is the new leaf `.7.5.3` (action-edge fluent lowering, greens tclite); the tclite oracle cases were re-deferred there (corpus back to 2 green proofs) so `cargo test` stays green. Lispish is unaffected by `.7.5.3` (uses `{ code }` blocks) — its remaining blocker is `.7.5.2` (scalaref). Recorded a pre-existing `cargo clippy --tests` exit-101 (`approx_constant` in untouched `expr.rs:687`/`types_test.rs:143`) as an Open Question (not fixed — out of scope). Frontier → `.7.5.3`.
- `2026-07-02`: `.7.5.3` done by reconciliation — the implementation landed later under `SPEC-FORMAT-TERSE`
  leaves and the stale RUST-PARITY frontier is now repaired. Action-edge fluent continuations are carried and
  executed by the current Rust parser/compiler/runtime, the shipped `tclite_command_subst` and
  `tclite_double_quote` fixtures are active in the oracle corpus, and the current corpus oracle passes over 62
  fixtures. Frontier → `.7.5.2` (Lispish `scalaref(retv, {content})`).
- `2026-07-02`: `.7.5.2` done — Lispish `scalaref(retv, {content})` parity landed. Rust now has a scoped legacy
  `scalaref` path parser/evaluator, child-return accumulator containment, explicit action-edge block `call(child)`
  compatibility, and aggregate-wrapper assignment replacement needed by `assign(array(word), array())`. The
  `lispish_x_y` oracle case is active and green; corpus oracle passes over **63 fixtures**. Frontier → `.7.2`.
- `2026-07-02`: `.7.2` done — first shipped-spec oracle expansion after `SCALAREF-RETIREMENT`. Rust header-rest
  parsing now uses the normal body-element parser, so compact header-line lifecycle chains and multiline
  lifecycle blocks are not dropped or double-collected. Rust `entry_group`/`match_group` helpers now match the
  documented Perl contract: captures-only, 0-based over participating captures, compacting non-participating
  optional groups while retaining participating empty captures; `entry_text`/`match_text` remain whole-match span
  readers. Added two clean `hlink_substitution` raw-string fixtures, taking the corpus to **65 fixtures**. Attempted
  broader simple-spec candidates (`portmap`, `lib_reader`, `ebnf`, `BNF`, `DT`, `ifelse`, `operators_try`, and
  selected `spec.spec` smokes) still diverge structurally and are recorded for `.7.3`/later. Frontier → `.7.3`.
- `2026-07-03`: `.7.3.1` done — batch-2 oracle work split before code. `.7.3.2` debugs whether the referenced
  timeout/hang risk is live or stale with LinkedSpec toolbox/trace evidence; `.7.3.3` tries the remaining
  `hlink_substitution` delimiter/link-path fixtures; `.7.3.4` triages `portmap`/`lib_reader`/`ebnf`; `.7.3.5`
  triages `BNF`/`DT`/`ifelse`/`operators_try`/`spec.spec`; `.7.3.6` audits RTL/plugin/legacy candidates after
  the timeout concern is resolved or retired. Frontier → `.7.3.2`.
- `2026-07-03`: `.7.3.2` done — historic `RTLUtils` timeout verified retired from the active core, and the oracle
  generator's generic timeout is now a real process-level guard (`fork` per parse; parent `SIGKILL` on
  `ORACLE_TIMEOUT`) instead of `alarm()`. Frontier → `.7.3.3`.
- `2026-07-03`: `.7.3.3.1` done — hlink delimiter candidates split. `{abc}` is the next JSON-safe fixture;
  `[abc]` and `foo[bar]{baz}` require a scalar-ref oracle representation decision first. Frontier → `.7.3.3.2`.
- `2026-07-03`: `.7.3.3.2` done — added the JSON-safe `hlink_curly_brace` fixture for `{abc}`. The oracle corpus
  now has **66 fixtures** and Rust `corpus_oracle` passes. Frontier → `.7.3.3.3`.
- `2026-07-03`: `.7.3.3.3` done — bracket/mixed `hlink_substitution` fixtures deferred with evidence. Perl
  emits scalar refs that the JSON oracle cannot encode, and Rust currently cannot execute the shipped scalar-ref
  action branch. Added deferred owner `.7.3.3.4`; frontier → `.7.3.4`.
- `2026-07-03`: `.7.3.7` done — user-directed timeout re-debug found the live guard-boundary gap. `BNF` timed out
  under a 5s build+parse child census because parser construction takes about 6.4s; parsing empty input after
  build is fast, and trace reaches successful parser generation. The oracle generator now builds and parses inside
  the forked `ORACLE_TIMEOUT` child, so future parser-build hangs are hard-killed too. Frontier → `.7.3.4`.
- `2026-07-03`: `.7.3.4.4` done — `lib_reader` sattribute/cattribute oracle fixtures landed. A focused
  dependency-resolved edge-only child-regex regression showed child entry captures were already seeded correctly;
  the remaining divergence was shipped-spec action-helper mutation parity. Rust now executes statement-form
  `substr(scalar(target), pattern, replacement, flags)` / `regex_subst(...)` as scalar regex substitution with
  target mutation, and statement-form `split(array(target), scalar(source), delimiter)` as array target
  replacement. Added `lib_reader_sattribute` and `lib_reader_cattribute`; corpus oracle passes over **68 fixtures**.
  Frontier → `.7.3.4.2`.
- `2026-07-03`: `.7.3.4.2` done — `portmap` scalar oracle fixtures landed. Rust now recognizes `or`/`and`/`not`,
  splices explicit flattening helper calls in `array(...)` list context, and isolates each rule regex in the
  dispatch alternation so the internal `0x...` branch no longer routes through the sibling `concatenation` edge.
  Added `portmap_bare`, `portmap_bit`, `portmap_slice`, and `portmap_constant`; corpus oracle passes over
  **72 fixtures**. Frontier → `.7.3.4.3`.
- `2026-07-04`: `.7.3.4.3` done — action-edge child/target aggregation parity landed for `ebnf` payloads and
  `portmap` concatenation. Added `portmap_concatenation`, `ebnf_expression_rules`, and
  `ebnf_logging_annotation`; corpus oracle passes over **77 fixtures**. Frontier → `.7.3.5`.
- `2026-07-04`: `.7.3.5` done — null-output candidates were separated from valid semantic fixtures. `BNF`, `DT`,
  `ifelse`, and `operators_try` representative inputs return Perl `null`, so no fixture was promoted for those
  diagnostic/debug-print cases. Rust now ignores quoted braces while scanning `.spec` code blocks, fixing the
  `operators_try` warnings, and four `spec.spec` smoke fixtures are active. Corpus oracle passes over
  **81 fixtures**. Frontier → `.7.3.6`.
- `2026-07-04`: `.7.3.6` done — RTL/plugin/legacy shipped-spec safety smoke audit landed seven green fixtures
  (`regdef_nested_register_fields`, `tablegrep_simple_term`, `simenv_multiline_value`, `vhdl_library_use`,
  `ds_vhistory_version_entry`, `pplugin_empty`, `tkgui_empty`) and kept richer mismatches out of the corpus with
  explicit evidence. Corpus oracle passes over **88 fixtures**. Frontier → `.7.4`.
- `2026-07-04`: `.7.4` done — oracle corpus finalization guard landed. The generator writes
  `manifest.json`, the Rust runner validates manifest shape and detects missing/stale fixture directory drift, and
  the manifest-ordered 88-fixture corpus plus two focused drift tests pass. `.7` is closed. Frontier → `.8`.
- `2026-07-04`: `.8.1` done — code-generation emitter work split before implementation. Rust remains an
  interpreter over `CompiledSpec`/`CompiledRule`; `.8` now owns the generated Rust-source path through child leaves
  for scaffold/harness, non-REP families, REP families, and all-variant/oracle integration. Frontier → `.8.2`.
- `2026-07-04`: `.8.2` done — minimal generated Rust-source scaffold and compile/run harness landed.
  `source_emitter::emit_rust_source` emits a standalone Rust module from `CompiledSpec`, and the focused test
  builds that module in an isolated temporary crate and executes the generated `parse` entry point. The generated
  code delegates through the existing interpreter; direct handler-family emission is next. Frontier → `.8.3`.
- `2026-07-04`: `.8.3` split — non-repetition generated-family emission is decomposed before code into
  `.8.3.1` rule-mode/family metadata plus generated family-plan emission, `.8.3.2` direct default/OR acode
  execution, `.8.3.3` direct AND acode execution, `.8.3.4` direct AND/OR bcode execution, and `.8.3.5` matrix
  closeout. No Rust source changed. Frontier → `.8.3.1`.
- `2026-07-04`: `.8.3.1` done — generated family-plan metadata landed. `CompiledRule` now preserves parsed
  `RuleMode`; `source_emitter` classifies compiled rules into generated families, emits a `GENERATED_RULES` table,
  validates labels/families before execution, and keeps runtime delegation through `Engine` until the direct
  execution children. The focused generated-source matrix compiles and runs generated modules for default, OR acode,
  AND single-acode, AND sequential-acode, AND bcode, and OR bcode cases. Frontier → `.8.3.2`.
- `2026-07-04`: `.8.3.2` done — direct generated execution now covers default and OR acode families. Generated
  `parse(input)` still validates the family plan, but it now enters `Engine::execute_generated_with_plan(...)`
  instead of `Engine::execute(...)`; that executor runs default/OR acode rules directly and preserves the
  interpreter's lifecycle, action-edge child-return, default repetition, and zero-progress semantics. AND acode is
  next. Frontier → `.8.3.3`.
- `2026-07-04`: `.8.3.3` done — direct generated execution now covers AND single-acode and AND sequential-acode
  families. The Rust regex/acode loop now requires non-repetition AND regex slots to match in ordered index
  sequence before completion; incomplete or out-of-order sequences return `undef` before `E`. The focused
  generated-source matrix proves the second ordered edge can return `and-seq`. Frontier → `.8.3.4`.
- `2026-07-04`: `.8.3.4` done — direct generated execution now covers AND bcode and OR bcode families. The
  generated executor shares blind-edge tail execution with the interpreter, preserving child `retv`, attached
  code/fluent calls, parent `E` behavior, and OR no-match `LX`. OR bcode now stops after the first truthy child
  return. The focused generated-source matrix proves ordered AND bcode collection, OR first-match dispatch, and OR
  no-match `LX`. Frontier → `.8.3.5`.
- `2026-07-04`: `.8.3.5` done — non-repetition generated-family matrix closed. Generated-plan routing is
  exhaustive for `Default`, `OrAcode`, `AndSingleAcode`, `AndAcodeSeq`, `AndBcode`, and `OrBcode`; `Repetition`
  remains the only fallback-owned family. The focused generated-source matrix asserts complete non-REP family
  coverage before REP work starts. Frontier → `.8.4`.
