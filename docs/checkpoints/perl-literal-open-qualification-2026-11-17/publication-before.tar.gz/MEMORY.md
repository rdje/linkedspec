# MEMORY

- activation_commit: `093e62098a94d0fd4c08a60ed49b8c35d0c1c9f8` — clean literal-open activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.1.1.0` — fourteen named Perl includes.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.1.1.1.0` (active); task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: PNT; continue after each clean leaf.
- next_action: Freeze the full145-source literal-open grammar/sites, exact input/output roles and target bytes; preserve unmatched sites for variable/other/constructed follow-ups.
- in_flight_uncommitted: Literal-open source qualification; no background job.
- evidence: docs/checkpoints/perl-named-includes-2026-11-17/REVIEW.md; readonly review.py/optional --current; PPI15/current31/named14/old callable11/eight RED controls. Capture and separate reader first pass; never replay capture.
- findings: Twelve caller-plan-guarded suites, two included package libraries and one nested child context. Parent source selections2/2/1 preserved. Three primary targets absent from old callable-only epoch captured prospectively; historical custody4.2. No application test or child execution.
- limits: Full145 literal1/constructed-helper2, generated-inline, excluded/computed/transitive/semantic, generated Dart/frozen-input and registration remain open. External PPI/Perl/library/native/outer-first-use/per-read/source-origin/physical4.2/SESSION5 and original Lua reader gap remain explicit.
- publication: Activation/cached4683555e estimate1,490,288,908 bytes/127 ahead/9,711,092-byte margin to director1.5GB excludes this slice. Selected telemetry will be retained; native4.2/independent size30 gaps and all publication prerequisites remain.
- locality: Only this repository writable; submodules black boxes. Same-volume serial jobs/shared24GB/director90-percent rising trend policy. Last cleanup November16 10:59UTC remains under24h; nothing removed. Normal hooks mandatory.
