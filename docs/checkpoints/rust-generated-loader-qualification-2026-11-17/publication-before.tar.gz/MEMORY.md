# MEMORY

- activation_commit: `616714b225313e54f86a5c3595b9ed38dbe29551` — clean generated-Rust-loader activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.35` — closed Perl AST task narrative epoch with full recovery.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.2` (active); task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: PNT; continue after each clean leaf.
- next_action: Qualify the generated Rust classifier’s manifest/corpus, focused Count, emitted-package/process and trace roles with source-bound proof; publish and commit before remaining qualification.
- in_flight_uncommitted: Generated Rust source/input qualification; no background job.
- evidence: docs/checkpoints/task-headroom-perl-ast-2026-11-17/REVIEW.md; readonly review.py/optional --current and public epoch reader. All28 IDs/CORE/five unchanged bodies/full52263-byte tail/23 pointers/29 queries/ten controls;88302 to75228 bytes. Existing native tools/schema/limits unchanged.
- findings: 13074 current text bytes renewed; full original source remains queryable. The prior227-byte pressure remainder is dated, not a current allowance. Original SDK observations/claims stay historical. This is data-only preservation, not new Perl AST or runtime admission.
- limits: Generated Rust2/remaining Perl-transitive3 include eleven unresolved Lua routes. Generated Dart2/frozen-input3/default-literal/repeated ActionIR registration and all native/per-read/source-origin/physical4.2/SESSION5 or other prerequisites remain open. Classifier child-status repair remains SESSION77-owned.
- publication: Director1.5GB trigger governs. Activation/cached4683555e estimate1,479,524,364 bytes/122 ahead/20,475,636-byte margin excludes this slice. Selected telemetry retained; raw pack/full logical tables ignored; independent size falsification30/native4.2 gaps. Remeasure after landing;30.2 needs all prerequisites/exact canonical proof.
- locality: Only this repository writable; submodules black boxes. Same-volume serial jobs/shared24GB/director90-percent rising-trend policy. Last cleanup November16 10:59UTC remains under24h; nothing removed. Normal hooks remain mandatory integrity.
