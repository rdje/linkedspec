local real_loadfile = loadfile
local requests, modules, calls = {}, {}, 0
probe_chunk_calls = 0
os.getenv = function(name)
  assert(name == "LINKEDSPEC_ARRAY_CONCAT_INPUT_ROOT")
  return "inert-prefix/"
end
require = function(name)
  modules[#modules+1] = name
  assert(name == "linkedspec")
  return {json={}}
end
loadfile = function(path)
  requests[#requests+1] = path
  local mapped = path
  if "inert-prefix/" ~= "" then
    assert(path:sub(1, #"inert-prefix/") == "inert-prefix/")
    mapped = "docs/checkpoints/lua-ordinary-loader-qualification-2026-11-16/toy_chunk.lua"
  end
  local chunk, err = real_loadfile(mapped)
  if not chunk then return nil, err end
  return function(...)
    assert(mapped == "docs/checkpoints/lua-ordinary-loader-qualification-2026-11-16/toy_chunk.lua", "repository chunk execution forbidden")
    calls = calls + 1
    return chunk(...)
  end
end
local input_root = os.getenv("LINKEDSPEC_ARRAY_CONCAT_INPUT_ROOT") or ""
-- TYPE-REFERENCE-BOOK.1.2.23.3.80.5: installed-host existing concat arity guards.
assert(loadfile(input_root .. "lua/src/linkedspec/interpreter.lua"))()
assert(loadfile(input_root .. "lua/test/run.lua"))
local l = require("linkedspec")
local json = l.json
for _, path in ipairs(requests) do print("REQUEST\t" .. path) end
for _, name in ipairs(modules) do print("MODULE\t" .. name) end
print("COUNTS\t" .. #requests .. "\t" .. calls .. "\t" .. probe_chunk_calls)
