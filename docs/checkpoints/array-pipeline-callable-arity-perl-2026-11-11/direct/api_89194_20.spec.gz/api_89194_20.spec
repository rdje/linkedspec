fn bad(...return) { return(undef) }
Top::
 /x/
