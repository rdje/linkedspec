fn bad(... items) { return(undef) }
Top::
 /x/
