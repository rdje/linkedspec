# Helper Contract Catalog

This appendix is the **canonical behavioral reference** for every ActionIR helper.
Each entry defines the helper's contract — signature, input/output types, semantics,
edge cases — at enough precision for a Rust, Dart, Julia, or Lua backend to implement
identically. No Perl implementation knowledge is required.

Helper calls use the `callee(args)` shape. Whitespace before the opening parenthesis
is accepted (`set (name, value)` is the same call as `set(name, value)`), but the
parentheses remain mandatory; no-parenthesis spellings such as `set name, value` or
`return scalar name` are not helper calls.

## 0. Primitive Value Literals

Primitive literals are value expressions, not helper calls or working-variable names.

- **Strings**: `"text"` and `'text'`.
- **Numbers**: integer and decimal forms such as `42`, `-1`, and `3.14`.
- **Booleans**: `true` and `false`, serialized as JSON booleans when returned or placed in containers.
- **Undefined**: `undef`, serialized as JSON `null`.

These literals are accepted in return payloads, constructor payloads, assignment RHS values,
append RHS values, hash keys/values, and flow predicates:

```text
return(array(true, false, "ready", 42, undef))
flag = true
items += false
meta["enabled"] = true
if(false); return("bad"); else(); return("good"); endif()
```

Literal recognition is exact. Prefix identifiers such as `trueword`, `false_alarm`, and
`undefine` are ordinary identifiers, not primitive literals.

## 0.1 Shape Value Literals

The Perl reference and Rust backend accept direct array and hash shape literals as value expressions:

```text
[]
[value, cat("a", "b"), true, []]
{ key : value, "fixed" : [value] }
```

Shape literals are accepted in value-consuming sites such as `return(payload)`, scalar assignment sources,
array append RHS values, typed-path assignment RHS values, `push(target, value)`, and nested constructor
payloads. Array elements, hash keys, and hash values lower through the scoped DSL value-expression rules:
primitive literals stay typed, recognized helper calls compose, direct nested access keeps its own bracket
semantics, nested shape literals recurse, and non-reserved bare names are scalar working-variable reads.
Perl and Rust both use `:` as the direct hash-literal key/value separator. Old `{ key => value }` ActionIR
value syntax is retired and reports `hash_literal_use_colon`; `=>` remains valid only for other owned surfaces
such as blind-call edges, source-language payloads, generated Perl host hashrefs, and historical records.

A bare hash-literal key is a dynamic scalar key, not a fixed string field name:

```text
set(key, "kind")
set(value, "token")
return({ key : value });       # {"kind": "token"}
return({ "kind" : value });    # fixed "kind" field
```

Direct shape literals are typed RHS values for bare assignment targets on the Perl reference and Rust backend:

```text
items = [value, cat("a", "b")];      # items holds an array value
meta = { key : value };             # meta holds a hash value
set(items, []);                      # items holds an empty array value
set(meta, {});                       # meta holds an empty hash value
set(items, []);               # explicit aggregate array reset
set(meta, {});                 # explicit aggregate hash reset
```

Bare working-variable reads and targets are the current scalar surface:
`set(payload, [value])` stores the whole array payload in `payload`. In value positions, `name` reads the
working variable named `name`.
Direct-access brackets (`payload["items"][i]`), typed-path assignment brackets (`meta[key] = value`),
control-flow/block braces, and all-bare child-call routing remain separate surfaces.

All current native backends accept expression-valued blocks in value-consuming sites. A non-empty
brace payload with no top-level hash-pair delimiter evaluates its statements and yields the final expression. A
`return(expr)` anywhere in the block exits only that expression-valued block, skips later block statements,
and yields `expr` as the block value. Hash literals keep precedence: `{}` and `{ key : value }`
remain hash shapes; old `{ key => value }` is retired and is not a block fallback.

Ordinary braces are eager even on an assignment RHS: `callback = { return("later") }` stores the scalar
`"later"`. Deferred first-class codeblocks use the distinct `{|params| ...}` form; a contextual trailing block
remains structural until the receiving callable executes it.

```text
return({ set(x, "a"); x });                    # "a"
set(out, { set(x, "a"); return(x) });          # $out = "a"
return({ return("a"); "b" });                  # "a"
set(out, { set(x, "a"); return(x); set(x, "b"); x });  # $out = "a"
return(array({ set(x, "a"); x }, { "k" : x }))
return({ [3, 1, 2] }.sorted().join_values(","));        # "1,2,3"
return({ " a-b " }.trim().split("-").count());          # 2
```

Expression-valued blocks are ordinary value expressions when used as receiver-dot receivers. The block
evaluates first, including any block-local `return(expr)`, and the yielded value is consumed by the same
compatible receiver family selected by the first method. Blocks do not create a separate block-only receiver
dispatch rule.

### Trailing block helper: `with(value) { ... }` / `.with() { ... }`

- **Signature**: `with(value?: expr) { block }`; receiver form `receiver.with() { block }`
- **Returns**: the immediate block result.
- **Backend status**: Perl, Rust, Dart, Julia, and Lua support attached and parenthesized contextual helper/receiver
  forms through declared final-codeblock metadata. They also accept an explicit `{|item| ...}` or bound codeblock
  value in that final slot. Bare `with { ... }` and explicit receiver `.with(value) { ... }` are not current
  surfaces.
- **Behavior**: Helper form evaluates the optional value argument, binds scoped working value `value` while the trailing
  block executes, restores any surrounding `value` binding afterward, and yields the block result. `with() { ... }`
  binds `value` to `undef`. Receiver form evaluates the receiver first, binds that receiver value as scoped
  `value`, and yields the block result as the terminal value or as the input to later compatible receiver-family
  links.
- **Execution context**: The block runs immediately in the caller's current action/runtime context. Captures,
  `retv`, cursor state, helper/function visibility, and ordinary working-variable side effects are shared with the
  call site. Only the working binding `value` is portable as the scoped block parameter in this MVP; mutations to
  other variable names persist after `with` returns.
- **Return semantics**: `return(expr)` inside the trailing block is block-local, exactly like expression-valued
  blocks: it yields `expr` from the block and skips later block statements; it does not return from the surrounding
  rule/action.
- **Examples**:
  - `return(with("x") { return(cat(value, "!")) })` yields `"x!"`.
  - `return(with("x", { return(cat(value, "!")) }))` is the same call on Perl, Rust, Dart, and Lua.
  - `return(with() { return(is_undefined(value)) })` yields true.
  - `return(" x ".with() { return(cat(value, "!")) }.trim())` yields `"x !"`.
  - `return(" a-b ".trim().with() { return(value.split("-")) }.count())` yields `2`.
  - `set(value, "outer"); return(array(with("inner") { return(value) }, value))` yields `["inner", "outer"]`.
  - On Lua, array/harray values are copied into `value`; the exact prior or absent uniform binding is restored even
    when the block or result copy fails.

> **Current portability boundary:** The language model has scalar, array, harray/hash, and codeblock values. A
> block-taking callable declares an exact final-only `name: codeblock` parameter, with no callback argument list;
> attached/contextual final-block forms normalize to the same call on helper, user-function, receiver, and tree
> surfaces. ADR 0031 defines explicit `{|args| body }` values, dynamic caller context without lexical capture, and
> retained `with`; ADR 0032 defines the metadata-owned final slot. Perl, Rust, Dart, Julia, and Lua construct and
> invoke explicit values and normalize governed contextual forms through their ordinary codeblock executors.
> Lua's native, reconstructed, generated-plan, and fresh emitted-module paths are implementation-current on PUC
> Lua and LuaJIT under `.11.8.1-.3`; `.11.8.4` admits both ABIs into the recurring five-backend/public proof.
> Five-backend callable recurring/public admission is complete.

## 1. Working Variables and Setup

> **Working variables auto-exist.** Referencing a bare variable in a read, assignment, or type-implying helper
> position creates a per-invocation binding. The target of `set(name, ...)` and the assignment
> operator `name = value`, which bind scalar, array, or hash RHS values as the variable's current
> typed value;
> the scalar source in `return(name)`, `set(out, name)`, and `out = name`; the array target of
> `push(name, ...)` and the array append operator `name += value`; and the harray target of
> `set_key(name, key, value)` auto-exist from a **bare** name too. On all five backends, typed-path assignment
> `name[key] = value` chooses the absent root from the evaluated selector kind instead of fixing it from syntax.
> `copy(name)` snapshots the current array or harray
> value. A backend MUST supply the same auto-existence: a position-referenced variable is a fresh working slot for
> the parse, not a value carried across parses. Recursive re-entry uses explicit fresh-container bindings:
> `set(name, [])` and `set(name, {})` establish rule-local aggregate bindings before
> mutation. New specs should use direct assignment initializers such as `name = value` or explicit
> aggregate resets such as `set(items, [])` and `set(meta, {})`.
> The DSL literals `undef`/`true`/`false` and the engine's own handler locals are never treated as
> working-variable names. Use `[undef]` to construct an array containing the `undef` literal.

### `name = value` assignment operator
- **Signature**: `name = value`
- **Returns**: In statement position, the stored value is ignored. In value position, it yields the typed value stored in the target.
- **Behavior**: Sets the working variable `name` to the evaluated RHS value. If the variable was not previously declared, the reference auto-creates it as a per-invocation working variable (see the note at the top of this section); otherwise it reassigns the existing variable. Later assignments may replace a scalar with an array/hash value, or replace an array/hash value with a scalar.
- **Edge cases**: `name = [value]`, `set(name, [value])`, and `=(name, [value])` bind an array value to `name`; `name = { key : value }` binds a hash value. In scalar assignment source slots, a bare source name reads the current typed working value: `out = value`.
- **Terse spelling**: `name = value` is the preferred operator spelling, and `set(name, value)` remains the helper spelling. In value positions, assignments store and yield the stored typed value. See [Terse Helper Renames](#terse-helper-renames-canonical-going-forward).
- **Worked example**:
  ```text
  demo::
   -> value .push
   LX { return(copy(demo)) }

  value : /(\w+)/
   I {
     value = entry_group(0)
     set(items, [value, cat(value, "!")])
     set(meta, { "value" : value })
     return(array(value, items, meta, name = value, name))
   }
  ```
  Input `ok` returns `[["ok",["ok","ok!"],{"value":"ok"},"ok","ok"]]`.
  The scalar assignment `name = value` stores and yields `"ok"` in value position; the explicit
  aggregate resets establish `items` and `meta`.

## 2. Scalar Helpers

> **Worked examples.** Each example below is a complete, runnable `.spec` written in the
> recommended **two-rule idiom**: a **top (`::`) entry rule** — which carries **no regex**
> of its own (it is the dispatch loop) — plus a **normal (`:`) rule** that carries the
> regex and computes the value. (This is the clean idiom for these helper demos, not a
> hard minimum — `::` is just an entry marker, and a top rule may itself carry a regex or
> recurse; see [.spec Files and Rule Paragraphs](../user-model/spec-files-and-rule-paragraphs.md).)
> The shared shape is:
>
> ```text
> demo::  -> value  .push
> LX { return(copy(demo)) }
>
> value : /<regex>/  I.return( <helper-expression> )
> ```
>
> The top rule dispatches to `value`, pushes its returned value into the accumulator
> (named after the top rule), and a terminal `LX` returns a snapshot of it. The `value`
> rule matches the input and reads its captures with **`entry_group(N)`** (the entering
> match) — `entry_group(0)` is the **first capture group** of `<regex>` (0-based; see
> [Regex in `.spec`](../user-model/regex-in-spec.md#capture-groups)). Because the parser's
> output is the top rule's accumulator, it is a **one-element array** holding the helper's
> value (see [Runtime Semantics §5.5](runtime-semantics.md)). Each compact "over
> `/<regex>/`, `<expr>` on `<input>` → `<output>`" line plugs into this shape: `value`
> carries `/<regex>/`, its `I.return(<expr>)` computes the result, and `<output>` is the
> parser's array. Predicate helper results in these examples surface in the reference
> boolean shape (`1` for true, `0` for false); primitive literal `true`/`false` values
> are typed JSON booleans. An undefined result surfaces as a `null` element. The value-returning predicates
> (`matches`, `starts_with`, `ends_with`, `contains_substr`) may be returned directly. The definedness predicates
> (`is_defined`, `is_undefined`) are portable in `if (...)` conditions and in current Perl/Rust ActionIR AST value
> contexts such as `with() { return(is_undefined(value)) }`.

### `container[key]`
- **Signature**: `container: array|hash[key: int|string]`
- **Returns**: scalar or undef
- **Behavior**: Reads a single value from an array (by 0-based index) or hash (by string key).
- **Edge cases**: Returns `undef` if the key does not exist or container is not array/hash.
- **Example**: over `/(\w+),(\w+),(\w+)/`, `array(entry_group(0), entry_group(1), entry_group(2))[1]` on `a,b,c` → `["b"]`.

### Direct nested access and value-path assignment: `base["key"][index]`
- **Signature**: `base[path_segment...]`, where `base` is a working scalar containing an array/hash payload.
- **Returns**: read form returns the selected value or `undef`; assignment returns the updated root on success.
  Structural failures throw the typed v1 diagnostic on all five backends.
- **Behavior**: Reads any-depth mixed hash/array paths directly from a structured payload. The contract forbids
  creating state; see the executed [read-purity examples and Perl evaluation details](../dsl/value-container-flow-helper-reference.md#read-purity).
  Assignment uses the same spelling. On all five backends, each bracket expression is evaluated and its runtime kind selects
  harray (string) or array (nonnegative integer), so dynamic selectors are not classified from their authored
  spelling. A non-reserved bare path atom such as `[i]` reads the scalar working variable. The assignment target
  remains a bare binding, for example `payload["children"][0]["name"] = value`.
- **Edge cases**: Reads return `undef` when a segment does not exist or the current value has the wrong container
  kind. Writes create an absent root and missing intermediates only when evaluated selectors determine the
  shape; bound null and wrong kinds are conflicts. Arrays may replace or append exactly at length, never create a
  gap. Segments evaluate once left-to-right, then RHS once; typed selector/kind/gap failures commit no partial path.
  Primitive literals and engine locals such as `[true]` or
  `[CAPTURE]` are not claimed as scalar path variables.
- **Example**:
  ```text
  Top::
   -> Done {
     set(payload, hash("children", array(hash("name", "one"), hash("name", "two"))))
     set(i, 1)
     payload["children"][i]["name"] = "updated"
     return(payload["children"][i]["name"])
   }

  Done:
   /[a-z]+/
  ```
  Input `xhello` -> `"updated"`.

### `cat(args...)`
- **Signature**: `cat(a: scalar, b: scalar, ...)`
- **Returns**: scalar
- **Behavior**: Concatenates all arguments as strings. Undef arguments are treated as empty strings.
- **Edge cases**: Non-scalar arguments (arrays, hashes) return `undef` for the whole expression.
- **Argument boundary**: Every argument in an already-valid current value-helper call is an authored value. A bare
  first value is never consumed as a legacy scope label: `cat(key, "@", depth)` reads all three values. The same
  rule applies to variadic arithmetic/coalescing helpers and to the optional-width form
  `substr(value, start, width)`. Legacy optional-scope compatibility is considered only when the raw argument count
  would otherwise be invalid.
- **Retirement note**: the former `concat` spelling diagnoses on current runtimes. See [Terse Helper Renames](#terse-helper-renames-canonical-going-forward).
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /(\w+) (\w+)/  I.return( cat(entry_group(0), "-", entry_group(1)) )
  ```
  Input `hello world` → `["hello-world"]`.

### `coalesce(a, b, ...)`
- **Signature**: `coalesce(values: scalar...)`
- **Returns**: scalar
- **Behavior**: Returns the first argument that is defined (not undef). Evaluates left-to-right, short-circuiting.
- **Edge cases**: Returns `undef` if all arguments are undef.
- **Example**: over `/(\w+)/`, `coalesce(array(entry_group(0))[5], "fallback")` on `hi` → `["fallback"]` (the index-5 read is out of range, so the literal default is used).

### `coalesce_nonempty(a, b, ...)`
- **Signature**: `coalesce_nonempty(values: scalar...)`
- **Returns**: scalar
- **Behavior**: Returns the first argument that is defined and not the empty string `""`. Preserves `0` and other defined values.
- **Edge cases**: Returns `undef` only if all arguments are undef or `""`.
- **Example**: over `/(\w+)/`, `coalesce_nonempty("", entry_group(0))` on `value` → `["value"]` (the empty string is skipped).

### `is_defined(expr)`
- **Signature**: `is_defined(value: expr)`
- **Returns**: boolean
- **Behavior**: Returns true if the value is not undef. Accepts any expression type.
- **Edge cases**: Empty string, `0`, and empty arrays are defined.
- **Usage**: condition-only — `is_defined(...)` is a flow predicate, used inside an
  `if (...)` / `elseif (...)` test, not as a `return(...)` value.
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /(\w+)/  I { if (is_defined(entry_group(0))) { return("present") } else { return("absent") } }
  ```
  Input `hi` → `["present"]`.

### `is_undefined(expr)`
- **Signature**: `is_undefined(value: expr)`
- **Returns**: boolean
- **Behavior**: Returns true if the value is undef. Logical inverse of `is_defined`.
- **Usage**: condition-only, like `is_defined` (use inside `if (...)`).
- **Example**: over `/(\w+)/`, `if (is_undefined(array(entry_group(0))[9])) { return("missing") } else { return("present") }` on `hi` → `["missing"]` (index 9 is out of range, so the read is undef).

### `trim(s)`
- **Signature**: `trim(value: scalar)`
- **Returns**: scalar
- **Behavior**: Removes leading and trailing whitespace. Returns undef if input is undef.
- **Edge cases**: A string of only whitespace becomes `""`.
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /\[([^\]]*)\]/  I.return( trim(entry_group(0)) )
  ```
  Input `[  hello  ]` → `["hello"]` (capture group `0` is the bracketed, padded text).

### `lowercase(s)`
- **Signature**: `lowercase(value: scalar)`
- **Returns**: scalar
- **Behavior**: Applies Unicode 17.0.0 full Default Lowercase (R2), locale-independent, including contextual
  `Final_Sigma`, with no implicit normalization. Returns undef if input is undef.
- **Example**: `lowercase("ΟΣ")` → `"ος"`; `lowercase("İ")` → `"i\u{0307}"`.

### `uppercase(s)`
- **Signature**: `uppercase(value: scalar)`
- **Returns**: scalar
- **Behavior**: Applies Unicode 17.0.0 full Default Uppercase (R1), locale-independent, with expansion and no
  implicit normalization. Returns undef if input is undef.
- **Example**: `uppercase("Straße ﬃ")` → `"STRASSE FFI"`.

### `length(s)`
- **Signature**: `length(value: scalar|array)`
- **Returns**: int
- **Behavior**: Returns the character length of a string or the element count of an array. Returns undef for undef input.
- **Example**: over `/(\w+)/`, `length(entry_group(0))` on `hello` → `[5]`.

### `matches(s, /pattern/)`
- **Signature**: `matches(value: scalar, pattern: regex)`
- **Returns**: boolean
- **Behavior**: Returns true if the value matches the regex pattern. The pattern is a literal `/regex/` — no variable interpolation.
- **Regex flags**: `i`, `m`, `s`, and `x` affect compilation. Operation-only `g` and Perl compile-once `o` are
  accepted compile-time no-ops. Unknown flags or invalid patterns return false.
- **Edge cases**: Returns false for undef input.
- **Example**: over `/(\w+)/`, `matches(entry_group(0), /^\d+$/)` returns `[1]` on `123` and `[0]` on `abc`.

### `starts_with(s, prefix)`
- **Signature**: `starts_with(value: scalar, prefix: scalar)`
- **Returns**: boolean
- **Behavior**: Returns true if the value starts with the exact prefix string.
- **Example**: over `/(\S+)/`, `starts_with(entry_group(0), "foo")` on `foobar` → `[1]`.

### `ends_with(s, suffix)`
- **Signature**: `ends_with(value: scalar, suffix: scalar)`
- **Returns**: boolean
- **Behavior**: Returns true if the value ends with the exact suffix string.
- **Example**: over `/(\S+)/`, `ends_with(entry_group(0), "bar")` on `foobar` → `[1]`.

### `contains_substr(s, needle)`
- **Signature**: `contains_substr(value: scalar, needle: scalar)`
- **Returns**: boolean
- **Behavior**: Returns true if the value contains the needle as a substring.
- **Example**: over `/(\S+)/`, `contains_substr(entry_group(0), "oob")` on `foobar` → `[1]`.

### `replace_substr(s, old, new)`
- **Signature**: `replace_substr(value: scalar, old: scalar, new: scalar)`
- **Returns**: scalar
- **Behavior**: Replaces all literal occurrences of `old` with `new`. Returns undef if value is undef. This is a **literal** replacement, not a regex substitution.
- **Edge cases**: If `old` is empty, returns the value unchanged.
- **Example**: over `/(\S+)/`, `replace_substr(entry_group(0), "-", "_")` on `a-b-c` → `["a_b_c"]`.

### `rm_prefix(s, prefix)`
- **Signature**: `rm_prefix(value: scalar, prefix: scalar)`
- **Returns**: scalar
- **Behavior**: Removes the prefix from the value if present. Returns the value unchanged if the prefix does not match. Returns undef if value is undef.
- **Example**: over `/(\S+)/`, `rm_prefix(entry_group(0), "lib")` on `libparser` → `["parser"]`.

### `rm_suffix(s, suffix)`
- **Signature**: `rm_suffix(value: scalar, suffix: scalar)`
- **Returns**: scalar
- **Behavior**: Removes the suffix from the value if present. Returns the value unchanged if the suffix does not match. Returns undef if value is undef.
- **Example**: over `/(\S+)/`, `rm_suffix(entry_group(0), ".spec")` on `parser.spec` → `["parser"]`.

### `substr(s, start, length?)`
- **Signature**: `substr(value: scalar, start: int, length: int?)`
- **Returns**: scalar
- **Behavior**: Returns a substring of `value` starting at zero-based `start`. When `length` is supplied,
  returns at most that many characters; when omitted, returns from `start` through the end.
- **Edge cases**: Returns undef if `value` or `start` is undef. Negative or non-integer `start` is normalized
  to `0`; negative or non-integer `length` is normalized to `0`.
- **Example**: over `/(\S+)/`, `substr(entry_group(0), 1, 3)` on `abcdef` → `["bcd"]`.

### `substr(target, pattern, replacement, flags)` / `regex_subst(...)`
- **Signature**: `substr(target, pattern: regex-or-scalar, replacement: scalar, flags: scalar)` or
  `regex_subst(target, pattern, replacement, flags)`
- **Returns**: no value; mutates the named scalar target.
- **Behavior**: Applies regex substitution to the current scalar target value. `g` performs global replacement;
  `i`, `m`, `s`, and `x` are regex flags; `o` is accepted as a compatibility no-op. Replacement strings can use
  `$0` for the whole match and numbered capture references such as `$1`.
- **Boundary**: This is the legacy statement-style mutation form used by shipped specs. It is intentionally
  separate from pure `substr(value, start, length?)` character slicing and from literal `replace_substr(...)`.
- **Example**: `substr(value, '"|\s', "", go)` removes quotes and whitespace from `value` in place. Single quotes
  keep the embedded double quote readable; the equivalent double-quoted pattern remains valid.

### `split(target, source, delimiter)`
- **Signature**: `split(target, source: scalar, delimiter: regex-or-scalar)`
- **Returns**: no value; replaces the named explicit array target.
- **Behavior**: Uses the same literal, regex, Unicode-empty-delimiter, and empty-field policy as pure
  `split(source, delimiter)`, then stores a copied typed array. The source scalar is not mutated.
- **Boundary**: Three arguments select target mutation; two arguments remain the pure split expression. An
  ordinary dropped split call is simply a discarded pure expression.

### String receiver-dot value chains
- **Signature**: `string_expr.method(args...).next(args...)`
- **Returns**: the documented return value of the final helper in the chain.
- **Behavior**: A compatible string receiver feeds into the first pure string helper, and each helper's return
  value feeds the next compatible helper. A bare receiver such as `raw.trim()` reads the working value `raw`.
  String literals may
  be receivers too: `"abcdef".substr(1, 3).uppercase()` is equivalent to
  `uppercase(substr("abcdef", 1, 3))`.
- **Allowed string-returning links**: `trim`, `lowercase`, `uppercase`, `replace_substr`, `rm_prefix`,
  `rm_suffix`, `substr`, `cat`, and `coalesce_nonempty`. The old `concat` spelling is retired.
- **Allowed array bridge**: `split(delim)` returns an array and may continue through compatible array
  receiver helpers, for example `raw.trim().split("-").trim_each().lowercase_each().join_values("|")`.
- **Allowed terminal links**: `length`, `starts_with`, `ends_with`, `contains_substr`, and `matches` return
  number/boolean values and end the string-family chain.
- **Boundary**: `substr(value, start, length?)` here is the pure value substring helper. It is separate from
  any statement-style or host-language substitution idiom. A terminal string method followed by another
  receiver-dot call yields `undef` rather than a partially lowered host expression.
- **Block receivers**: An expression-valued block whose value is a string can be the receiver, for example
  `{ " a-b " }.trim().split("-").count()`.

## 3. Array Helpers

> **Worked examples.** Array examples use the same complete two-rule scaffold as the
> Scalar/Numeric examples:
>
> ```text
> demo::
>  -> value .push
>  LX { return(copy(demo)) }
>
> value : /<regex>/
>  I { return(<array-expression>) }
> ```
>
> The top `demo::` rule has no regex; it dispatches to the regex-owning `value:` rule,
> pushes the child value, and returns the accumulator snapshot. Outputs below are therefore
> one-element arrays holding the helper result. Multi-statement examples use the same
> scaffold but put the shown statements inside the `I { ... }` block.

**Verified value examples:**

| Surface | Example | Input | Output |
| --- | --- | --- | --- |
| Construct | `array(entry_group(0), entry_group(1), entry_group(2))` over `/(\w+),(\w+),(\w+)/` | `a,b,c` | `[["a","b","c"]]` |
| Copy | `copy(array(entry_group(0), entry_group(1), entry_group(2)))` over `/(\w+),(\w+),(\w+)/` | `a,b,c` | `[["a","b","c"]]` |
| Splice | `array("tag", flat_array(array(entry_group(0), entry_group(1))))` over `/(\w+),(\w+)/` | `a,b` | `[["tag","a","b"]]` |
| Concatenate | `concat_arrays(array(entry_group(0), entry_group(1)), array(entry_group(2)))` over `/(\w+),(\w+),(\w+)/` | `a,b,c` | `[["a","b","c"]]` |
| Count/select | `count(array(entry_group(0), entry_group(1), entry_group(2)))` / `first(...)` / `last(...)` | `a,b,c` | `[3]` / `["a"]` / `["c"]` |
| Edge slices | `take(..., 2)` / `take_last(..., 2)` / `drop_front(..., 1)` / `drop_back(..., 1)` / `slice(..., 1, 2)` | `a,b,c` | `[["a","b"]]` / `[["b","c"]]` / `[["b","c"]]` / `[["a","b"]]` / `[["b","c"]]` |
| Order | `sorted(array("b", "a", "c"))` / `reversed(array("a", "b", "c"))` | `x` | `[["a","b","c"]]` / `[["c","b","a"]]` |
| Membership | `contains(array("a", "b", "c"), "b")` / `index_of(array("a", "b", "c"), "b")` / missing `index_of(..., "z")` | `x` | `[1]` / `[1]` / `[null]` |
| Emptiness | `is_empty([])` / `is_nonempty(["a"])` | `x` | `[1]` / `[1]` |
| Join | `join_values(",", array("a", "b", "c"))` | `x` | `["a,b,c"]` |
| Split bridge | `entry_group(0).split(",")` over `/(.+)/` | `a,b,c` | `[["a","b","c"]]` |
| Receiver chain | `items.sorted().drop_front(1).first()` after `set(items, ["b", "a", "b", "c"])` | `x` | `["b"]` |
| Pipeline receiver | `items.trim_each().filter_nonempty().join_values("|")` after `set(items, [" a ", "", " b "])` | `x` | `["a|b"]` |

**Verified mutation/pipeline examples:**

| Body inside `value`'s `I { ... }` block | Input | Output |
| --- | --- | --- |
| `set(source, entry_group(0)); split(items, source, /,/); return(copy(items))` over `/(.+)/` | `a,b,c` | `[["a","b","c"]]` |
| `set(items, ["a:b", "c:d"]); split_each(items, ":"); return(copy(items))` | `x` | `[["a","b","c","d"]]` |
| `set(items, [" a ", " b"]); trim_each(items); return(copy(items))` | `x` | `[["a","b"]]` |
| `set(items, ["a", "", undef, "0", "b"]); filter_nonempty(items); return(copy(items))` | `x` | `[["a","0","b"]]` |
| `set(items, ["alpha", "beta", "atom"]); filter_match(items, /^a/); return(copy(items))` | `x` | `[["alpha","atom"]]` |
| `set(items, ["a", "b", "a", "c", "b"]); uniq(items); return(copy(items))` | `x` | `[["a","b","c"]]` |
| `set(items, ["A", "bC"]); lowercase_each(items); return(copy(items))` | `x` | `[["a","bc"]]` |
| `set(items, ["a", "bC"]); uppercase_each(items); return(copy(items))` | `x` | `[["A","BC"]]` |
| `set(value, entry_group(0)); push(items, value); items += "tail"; return(copy(items))` over `/(\w+)/` | `head` | `[["head","tail"]]` |
| `set(value, entry_group(0)); if(is_nonempty(value)) { push(items, value) }; set(value, ""); if(is_nonempty(value)) { push(items, value) }; return(copy(items))` over `/(\w+)/` | `keep` | `[["keep"]]` |

> **Current Perl caveats.** For `split(value, delim)`, prefer receiver form
> `value.split(delim)` or block form `I { return(split(value, delim)) }`. Compact
> lifecycle shorthand `I.return(split(...))` currently routes through an older tagged
> shorthand shape on the Perl reference. For array pipeline helpers (`split_each`,
> `trim_each`, `filter_nonempty`, `lowercase_each`, `uppercase_each`, `uniq`, and
> `filter_match`), return a receiver chain (`items.trim_each()`) or assign/copy the
> named target as shown above; a direct `return(split_each(items, ":"))` is
> shape-sensitive on current Perl and does not document the portable array value.

### `array(e1, e2, ...)`
- **Signature**: `array(elements: expr...)`
- **Returns**: array
- **Behavior**: Constructs a new array from the given elements. Elements are evaluated in order.

### `array_copy(arr)`
- **Signature**: `array_copy(arr: array)`
- **Returns**: array
- **Behavior**: Returns a shallow copy of the array. The new array contains the same elements but is a distinct container.
- **Compatibility**: `array_values(...)` and `array_copy(...)` are retired on current runtimes — use `copy(...)`.
- **Terse spelling**: `copy(arr)` is the canonical spelling — one unified `copy(...)` subsumes both legacy array
  and hash copy forms and dispatches from the current runtime value kind. See
  [Terse Helper Renames](#terse-helper-renames-canonical-going-forward).

### `flat_array(arr)`
- **Signature**: `flat_array(arr: array)`
- **Returns**: list (splices into parent context)
- **Behavior**: Flattens an array into list context for insertion into a parent container. Used with `hash(...)`, `array(...)`, and lifecycle accumulator returns.

### `concat_arrays(a1, a2)`
- **Signature**: `concat_arrays(a: array, b: array)`
- **Returns**: array
- **Behavior**: Returns a new array containing all elements of `a1` followed by all elements of `a2`. Neither input is mutated.

### `push(Child)` / `push(Child, target)`
- **Signature**: `push(child_rule: rule[, target: array])`
- **Returns**: explicit-target form returns an updated array snapshot; the implicit form has no portable expression result yet
- **Behavior**: Calls `Child` and appends the child result to an accumulator array. With one argument, the target is the current rule's implicit accumulator; with a second bare identifier, that identifier is the target accumulator. Use `push(Child)` as a statement: Perl currently leaks the host push count while Lua returns the updated implicit accumulator. `push(Child, target)` evaluates to an independent snapshot of the updated explicit target.
- **Convention**: The all-bare child-call forms keep precedence: `push(Child)`, `push(Child, target)`, `push(Child, index)`, and `push(Child, target, index)` are parser child-call helpers.
- **Action-edge fluent form**: after `-> Child`, `.push(target)` uses the edge's `Child` as the child rule and appends its return value to `target`; `.push(Child, target)` is the explicit child-and-target spelling used inside gated fluent chains.

### `push(Child, index)` / `push(Child, target, index)`
- **Signature**: `push(child_rule: rule, index: int)` or `push(child_rule: rule, target: array, index: int)`
- **Returns**: explicit-target form returns an updated array snapshot; the implicit form has no portable expression result yet
- **Behavior**: Calls `Child`, selects one element from the child result, and appends that element to the implicit or explicit accumulator. Use implicit indexed push as a statement; the explicit-target result is an independent snapshot of the updated accumulator.
- **Edge cases**: The disambiguation relies on integer matching before bare target-name matching. `push(Child, 0)` means index 0 into `Child`'s result; `push(Child, target, 0)` appends index 0 to `target`.

### `push(arr, value)`
- **Signature**: `push(target: array, value: expr)`
- **Returns**: updated array snapshot
- **Behavior**: Terse explicit-value append. Lowers identically to the array append operator for unambiguous value expressions, mutates the named target, and evaluates to an independent snapshot of the update.
- **Examples**: `push(items, "a")`, `push(items, value)`, `push(items, cat("a", "b"))`, and `push(items, call(Child))`.
- **Disambiguation**: For `push(A, B)` with two bare identifiers, a registered static rule `A` keeps child-call
  precedence. Otherwise `A` is the array binding and `B` is the appended working value. `items += value` is the
  unambiguous operator spelling when the author wants to emphasize mutation.

### `items += value`
- **Signature**: `target += value: expr`
- **Returns**: updated array snapshot in value positions; side-effect-only behavior when used as a statement.
- **Behavior**: Array append operator. Lowers/runs identically to explicit append forms, mutates the named working array, and reads a bare RHS identifier as a scalar working variable. In value positions it evaluates to the updated array snapshot after the push.
- **Examples**: `items += "a"`, `items += cat("a", "b")`, and `items += value`.
- **Edge cases**: The target is an array working value and auto-exists when the mutation contract permits creation.
  A bare RHS such as `items += value` reads the current typed value of `value`; reserved literals such as `true`,
  `false`, and `undef` keep their literal meaning.

### `items.push_back(value)` / `items.push_front(value)` / `items.pop_back()` / `items.pop_front()`
- **Signature**: `target.push_back(value: expr)`, `target.push_front(value: expr)`, `target.pop_back()`, `target.pop_front()`
- **Returns**: an independent updated array snapshot.
- **Behavior**: Array end mutations on a named working array. `push_back` appends, `push_front` prepends,
  `pop_back` removes the last element, and `pop_front` removes the first element. Pop methods discard the removed
  value; their expression result is the updated array, not the removed item. An unused result is silently dropped.
- **Examples**: `items.push_back("tail")`, `items.push_front(value)`, `items.pop_back()`, `items.pop_front()`.
- **Edge cases**: The receiver is the bare array working value (`items`) and auto-exists as an array when the
  mutation contract permits creation. A bare push value reads a working variable, just like `items += value`.
  An existing non-array target raises `binding_kind_mismatch`. Saved results are independent snapshots, and a
  compatible continuation consumes the update; for example, `items.push_back(value).count()` yields the new count.
- **Worked example**:
  ```text
  Top::
   -> Done {
    set(value, "b")
    items.push_back("a")
    items.push_back(value)
    items.push_front("z")
    items.pop_back()
    items.pop_front()
    return(copy(items))
   }

  Done:
   /[a-z]+/
  ```
  On input `xhello`, the result is `["a"]`: the push methods build `["z", "a", "b"]`, then `pop_back()`
  removes `"b"` and `pop_front()` removes `"z"`.

### `count(arr)`
- **Signature**: `count(arr: array)`
- **Returns**: int
- **Behavior**: Returns the number of elements in the array. Returns `0` for non-array or undef input.

### `first(arr)`
- **Signature**: `first(arr: array)`
- **Returns**: scalar
- **Behavior**: Returns the first element. Returns undef for empty array or non-array input.

### `last(arr)`
- **Signature**: `last(arr: array)`
- **Returns**: scalar
- **Behavior**: Returns the last element. Returns undef for empty array or non-array input.

### `take(arr, n)`
- **Signature**: `take(arr: array, n: int = 1)`
- **Returns**: array
- **Behavior**: Returns the first `n` elements as a new array. When `n` is omitted, returns the first element as an array.
- **Edge cases**: If `n` > array length, returns the entire array. Returns an empty array for non-array input.

### `take_last(arr, n)`
- **Signature**: `take_last(arr: array, n: int = 1)`
- **Returns**: array
- **Behavior**: Returns the last `n` elements as a new array.
- **Edge cases**: If `n` > array length, returns the entire array.

### `drop_front(arr, n)`
- **Signature**: `drop_front(arr: array, n: int = 1)`
- **Returns**: array
- **Behavior**: Returns a new array with the first `n` elements removed. When `n` is omitted, drops 1 element.
- **Compatibility**: `tail(...)` is a retired alias.

### `drop_back(arr, n)`
- **Signature**: `drop_back(arr: array, n: int = 1)`
- **Returns**: array
- **Behavior**: Returns a new array with the last `n` elements removed.
- **Compatibility**: `drop_last(...)` is a retired alias.

### `slice(arr, start, n)`
- **Signature**: `slice(arr: array, start: int, n: int?)`
- **Returns**: array
- **Behavior**: Returns elements from index `start`. When `n` is provided, returns up to `n` elements. When `n` is omitted, returns from `start` to the end.
- **Edge cases**: If `start` exceeds array length, returns empty array.

### `sorted(arr)`
- **Signature**: `sorted(arr: array)`
- **Returns**: array
- **Behavior**: Returns a new array sorted in ascending (string/lexicographic) order. Does not mutate the input.

### `reversed(arr)`
- **Signature**: `reversed(arr: array)`
- **Returns**: array
- **Behavior**: Returns a new array in reverse order. Does not mutate the input.

### `array(e1, e2, ...)`
- **Signature**: `array(values: expr...)`
- **Returns**: array
- **Behavior**: Constructs an array from evaluated values. Quoted strings are literal payloads, so
  `array("items")` constructs `["items"]`; zero and multiple arguments are also valid constructors.
- **Boundary**: Exact `array(IDENTIFIER)` is a removed selector shape, not a one-element constructor. Use the bare
  identifier to read its typed value or `[identifier]` to construct one element. All five backends reject the
  removed shape before execution.
- **Function values**: Multi-argument `array(value, value)` reads parameter/local values just like `[value, value]`.
  See the [executed function example](../dsl/value-container-flow-helper-reference.md#array-constructors-inside-functions).

### Array receiver-dot value chains
- **Signature**: `array_expr.method(args...).next(args...)`
- **Returns**: the documented return value of the final helper in the chain.
- **Behavior**: A compatible array receiver feeds into verified array helper chains. Pure array links compose
  through later pure links and terminals, for example `items.sorted().drop_front(2).first()` is equivalent to
  `first(drop_front(sorted(items), 2))`. Pipeline links compose through pipeline/terminal continuations that are
  locked by the runtime, for example `items.uniq().join_values(",")` and
  `phrases.split_each("-").filter_match(/^aa$/).count()`.
- **Allowed array-returning links**: `copy`, `sorted`, `reversed`, `take`, `take_last`,
  `drop_front`, `drop_back`, `slice`, `concat_arrays`, `split_each`, `trim_each`, `filter_nonempty`,
  `lowercase_each`, `uppercase_each`, `uniq`, and `filter_match`.
- **Allowed terminal links**: `count`, `first`, `last`, `contains`, `index_of`, `is_empty`, `is_nonempty`,
  `join_values`, `sum`, `avg`, `median`, `range`, `min`, and `max`. Receiver-dot
  `items.join_values(delim)` keeps the helper's canonical delimiter-first contract: it maps to
  `join_values(delim, items)`. Receiver-dot numeric reducers such as `scores.sum()` and `scores.min()` are
  array-consuming terminal links over the same numeric aggregate helper family.
- **Boundary**: `split(value, delim)` belongs to the scalar/string receiver family because its receiver is the
  string being split. Numeric reducer terminals do not continue through later array methods; compose the helper
  form explicitly when another numeric operation is needed. Named end mutations (`push_back`, `push_front`,
  `pop_back`, `pop_front`) update their binding and may feed a compatible continuation from the returned array.
  They are not pure links over arbitrary temporary array receivers. The portable contract does not
  promise every possible pipeline-to-pure continuation; use verified chains such as
  `items.uniq().join_values(",")`, `items.filter_match(/^a/).count()`, or pure chains such as
  `items.sorted().drop_front(1).first()`.
- **Block receivers**: An expression-valued block whose value is an array can be the receiver, for example
  `{ [3, 1, 2] }.sorted().join_values(",")`. A block-local `return(array_expr)` yields the receiver value and
  skips later block statements before the array chain runs.

### Array-tree receiver block traversal: `walk_leaves`, `map_leaves`, `reduce_leaves`
- **Signatures**:
  - `array_expr.walk_leaves() { block }`
  - `array_expr.map_leaves() { block }`
  - `array_expr.reduce_leaves(initial_acc: expr) { block }`
- **Returns**:
  - `walk_leaves` returns the original array tree after running callbacks.
  - `map_leaves` returns a new array tree with the same nested-array structure and each leaf replaced by the
    callback result.
  - `reduce_leaves` returns the final accumulator.
- **Backend status**: Perl reference support landed under `SPEC-FORMAT-TERSE.13.2`; Rust interpreter and
  generated-oracle parity landed under `SPEC-FORMAT-TERSE.13.3`. Dart, Julia, and Lua also support the contract;
  Lua's shared root-kind dispatcher and exact Perl oracle proof pass 114/114 on both Lua ABIs.
- **Tree shape**: The receiver must be an array. Nested arrays are interior nodes. Scalar values and hash values
  are leaves; hash values are not traversed recursively by this surface.
- **Traversal order**: Depth-first by zero-based array index. For `["a", ["b", "c"], { "h" : "H" }]`, callbacks
  run for paths `0`, `1/0`, `1/1`, then `2`.
- **Callback bindings**: Each callback runs immediately in the caller's current action/runtime context with scoped
  scalar bindings:
  - `value`: current leaf value.
  - `index`: zero-based index of the leaf in its parent array.
  - `path`: array value containing root-to-leaf indexes.
  - `depth`: number of path segments.
  - `acc`: current accumulator for `reduce_leaves` only.
- **Binding restoration**: The traversal restores those scoped names after each callback and after traversal
  completes, including callback errors. Inputs, paths, mapped results, and accumulator values are copied, so
  callback mutation cannot alias the source. Mutations to other working variables are ordinary side effects and
  persist.
- **Edge cases**: A non-array receiver yields `undef` and does not execute the callback or evaluate the reduce
  initial. Empty arrays run no callbacks; `reduce_leaves(initial)` returns the initial accumulator. `walk_leaves()` and
  `map_leaves()` take no parenthesized arguments. `reduce_leaves(initial)` requires exactly one parenthesized
  initial accumulator expression. `walk_leaves()` and `map_leaves()` can feed later compatible array receiver links
  such as `.count()`. `reduce_leaves(...)` is terminal.
- **Examples**:
  - After `set(items, ["a", ["b", "c"]])`,
    `return(items.map_leaves() { return(cat(join_values("/", path), "=", value)) })`
    yields `[["0=a",["1/0=b","1/1=c"]]]` through the standard `demo::` wrapper.
  - After `set(items, ["a", ["b", "c"]])`,
    `set(out, items.walk_leaves() { paths += join_values("/", path); return(value) }); return(copy(paths))`
    yields `[["0","1/0","1/1"]]`.
  - After `set(items, ["a", ["b", "c"]])`,
    `return(items.reduce_leaves(0) { return(acc.add(1)) })` yields `[3]`.
  - `return(items.map_leaves() { return(value) }.count())` yields `[2]`: the top-level mapped array has two
    elements, even though traversal visited three leaves.

### Five-backend receiver mutation: `map_leaves!`

- **Signature**: `binding_name.map_leaves!() { block }`
- **Returns**: a detached copy of the updated harray or array root; the named receiver is also rebound atomically.
- **Backend status**: current on Perl under `FUTURE-PARITY-BACKLOG.19.2.2`, Rust under `.19.3.2`, Dart under
  `.19.4.2`, Julia under `.19.5.2`, and shared Lua under `.19.6.2` on PUC Lua and LuaJIT. `.19.7` admits the exact
  portable capability row, `.19.8` completes exact six-runtime recurrence, and `.19.9` closes current public
  no-drift.
- **Addressability**: `binding_name` must be one existing, non-reserved, bare uniform binding that holds an harray
  or array. Literals, temporaries, helper results, bracket/property receivers, function-form `map_leaves!(tree)`,
  other bang methods, and arbitrary user-defined `name!` functions are not valid v1 forms.
- **Traversal and replacement**: the starting root kind determines recursion. An harray root recurses only through
  harrays in sorted-key depth-first order, treating arrays as leaves. An array root recurses only through arrays in
  index order, treating harrays as leaves. The runtime walks a detached snapshot of the original shape. Each block
  result replaces its leaf; a returned container of the root kind is not revisited during this call.
- **Callback bindings**: every callback receives detached `value`, complete copied `path` (also `@path` on Perl),
  `depth`, and `key` for harray roots or `index` for array roots. Changing `value` alone does not update the receiver; return the
  desired replacement. Ordinary effects on unrelated bindings remain visible.
- **Receiver protection**: callback code may not directly mutate the receiver binding. Direct assignment, bracket
  write, nested `map_leaves!`, `set`, `set_key`, `push`, `push_front`/`push_back`/`pop_front`/`pop_back`, and a
  binding-target array pipeline such as `trim_each(items)` fail with `receiver_mutation_reentrant` before writing.
  A distinct scoped binding with the same spelling is allowed because identity, not text, is guarded.
- **Atomicity and continuation**: callback or re-entrant failure leaves the receiver unchanged and releases the
  guard. Complete callback success publishes the rebuilt receiver once. Only then may the detached result enter a
  continuation such as `.count()` or `.count_keys()`. A later continuation failure cannot roll back the commit.
- **Examples**:
  - Harray root: `tree = { "a" : "A", "nested" : { "b" : "B" } }; tree.map_leaves!() {
    return(lowercase(value)) }` leaves `tree` as `{ "a" : "a", "nested" : { "b" : "b" } }`.
  - Array root: `items = ["A", ["B"]]; count = items.map_leaves!() { return(lowercase(value)) }.count()` leaves
    `items` as `["a", ["b"]]` and stores `2` in `count` because the continuation counts top-level elements.
  - Callback-local nested write: for `tree = { "leaf" : [] }`, `tree.map_leaves!() {
    value[0]["name"] = "normalized"; return(value) }` commits
    `{ "leaf" : [{ "name" : "normalized" }] }` without revisiting the new array/hash content.
  - Forbidden receiver write: `tree.map_leaves!() { tree["x"] = value; return(value) }` fails before modifying
    `tree`. Writing an unrelated `journal["seen"][0] = path` remains ordinary and independent.

### `contains(arr, needle)`
- **Signature**: `contains(arr: array, needle: scalar)`
- **Returns**: boolean
- **Behavior**: Returns true if the array contains the needle value. Works on direct arrays and projected expressions (`sorted_keys(...)`, `sorted_values(...)`).
- **Edge cases**: Returns false for non-array or undef input.

### `index_of(arr, needle)`
- **Signature**: `index_of(arr: array, needle: scalar)`
- **Returns**: int or undef
- **Behavior**: Returns the 0-based index of the first match. Returns `0` when the match is at the first position. Returns `undef` for missing, non-array, or no-match cases.

### `is_empty(arr)`
- **Signature**: `is_empty(value: array|hash|expr)`
- **Returns**: boolean
- **Behavior**: Returns true if the array or hash has zero elements. Treats composed array-valued and hash-valued expressions as aggregates, not Perl references.
- **Edge cases**: Returns true for undef (treated as empty).

### `is_nonempty(arr)`
- **Signature**: `is_nonempty(value: array|hash|expr)`
- **Returns**: boolean
- **Behavior**: Logical inverse of `is_empty`. True if the aggregate has at least one element.

### `join_values(delim, arr)`
- **Signature**: `join_values(delim: scalar, arr: array)`
- **Returns**: scalar
- **Behavior**: Joins array elements into a string with the delimiter between each element. Accepts composed array-valued expressions.
- **Edge cases**: Returns empty string for an empty array and undef for a missing/undef array on the reference and
  Lua backends. Do not rely on a non-array source: Perl/Lua and Rust/Dart/Julia currently differ, with normalization
  owned by `FUTURE-PARITY-BACKLOG.5`.

### `split(s, delim)`
- **Signature**: `split(value: scalar, delim: scalar)`
- **Returns**: array
- **Behavior**: Splits a string on the delimiter, returning an array of substrings.
- **Regex flags**: Regex delimiters preserve `i`, `m`, `s`, and `x`; operation-only `g` and Perl compile-once `o`
  are accepted compile-time no-ops. Unknown flags or invalid patterns return an empty array.
- **Examples**: over `/(.+)/`, `entry_group(0).split(",")` on `a,b,c` → `[["a","b","c"]]`.
  `count(entry_group(0).split(","))` on the same input → `[3]`.
- **Current Perl caveat**: use receiver form (`value.split(delim)`) or block form
  `I { return(split(value, delim)) }` in runnable examples. Compact `I.return(split(...))`
  currently surfaces an older tagged shorthand shape in the Perl reference.

### `split(target, source, delimiter)`
- **Signature**: `split(target, source, delimiter: regex-or-scalar)`
- **Returns**: no value; mutates the named array target.
- **Behavior**: Splits `source` on `delimiter` and replaces `target` with the resulting list. Regex delimiters
  split by regex match; scalar delimiters split literally.
- **Boundary**: This statement-style array pipeline helper is separate from pure `split(value, delim)`, which
  returns an array value for expression and receiver-chain use.

### `split_each(arr, delim)`
- **Signature**: `split_each(arr: array, delim: regex-or-scalar)`
- **Returns**: array
- **Behavior**: Splits each element with the governed literal/regex split policy. Results are concatenated into a
  single flat array.
- **Example**: after `set(items, ["a:b", "c:d"])`, `return(items.split_each(":"))`
  yields `[["a","b","c","d"]]`.

### `trim_each(arr)`
- **Signature**: `trim_each(arr: array)`
- **Returns**: array
- **Behavior**: Trims whitespace from each element of the array.
- **Example**: after `set(items, [" a ", " b"])`, `return(items.trim_each())`
  yields `[["a","b"]]`.

### `filter_nonempty(arr)`
- **Signature**: `filter_nonempty(arr: array)`
- **Returns**: array
- **Behavior**: Returns a new array with empty/undef elements removed.
- **Example**: after `set(items, ["a", "", undef, "0", "b"])`,
  `return(items.filter_nonempty())` yields `[["a","0","b"]]`.

### `filter_match(arr, /pattern/)`
- **Signature**: `filter_match(arr: array, pattern: regex)`
- **Returns**: array
- **Behavior**: Returns elements matching the regex pattern.
- **Example**: after `set(items, ["alpha", "beta", "atom"])`,
  `return(items.filter_match(/^a/))` yields `[["alpha","atom"]]`.

### `uniq(arr)`
- **Signature**: `uniq(arr: array)`
- **Returns**: array
- **Behavior**: Returns a new array with duplicates removed. Order of first occurrence is preserved.
- **Example**: after `set(items, ["a", "b", "a", "c", "b"])`,
  `return(items.uniq())` yields `[["a","b","c"]]`.

### `lowercase_each(arr)`
- **Signature**: `lowercase_each(arr: array)`
- **Returns**: array
- **Behavior**: Lowercases each element with the same Unicode 17 contract as `lowercase`.
- **Example**: after `set(items, ["A", "bC"])`, `return(items.lowercase_each())`
  yields `[["a","bc"]]`.

### `uppercase_each(arr)`
- **Signature**: `uppercase_each(arr: array)`
- **Returns**: array
- **Behavior**: Uppercases each element with the same Unicode 17 contract as `uppercase`.
- **Example**: after `set(items, ["a", "bC"])`, `return(items.uppercase_each())`
  yields `[["A","BC"]]`.

### `print_each(arr, prefix, suffix?)`
- **Signature**: `print_each(arr: array, prefix: scalar, suffix?: scalar)`
- **Returns**: void
- **Behavior**: Debug helper — eagerly emits `prefix + item + suffix` for each element in order. The omitted
  suffix is empty text under ADR `0042`. Arguments evaluate exactly once left-to-right before item delivery; an
  empty or wrong-kind target emits no events. No message enters the parser result. Each item is delivered as a
  caller-owned `RuntimeDiagnosticOutputEvent` with exact helper/rule/message fields; an absent sink is quiet and a
  sink failure propagates unchanged. Native and generated execution on all five backends consume this same
  contract; primary commands deliberately install no rich sink. See the [value/container helper
  reference](../dsl/value-container-flow-helper-reference.md#debug-output-helpers) for event rendering, typed exit,
  and host API examples.

## 4. Hash Helpers

> **Worked examples** use the same runnable two-rule scaffold as the Array section:
>
> ```text
> demo::
>  -> value .push
>  LX { return(copy(demo)) }
>
> value : /<regex>/
>  I { <statements>; return(<hash-or-derived-value>) }
> ```
>
> Outputs are the parser's accumulator array after `demo` pushes each `value` result.

**Verified value, mutation, and receiver examples:**

| Surface | Body inside `value`'s `I { ... }` block | Input | Output |
| --- | --- | --- | --- |
| Construct | `return(hash("b", 2, "a", 1))` | `x` | `[{"a":1,"b":2}]` |
| Explicit null value | `return(hash("a", 1, "missing", undef))` | `x` | `[{"a":1,"missing":null}]` |
| Splice count | `return(count(array(flat_hash(hash("a", 1, "b", 2)))))` | `x` | `[4]` |
| Copy snapshot | `set(meta, { "a" : 1 }); set(saved, copy(meta)); meta["b"] = 2; return(array(count_keys(meta), count_keys(saved)))` | `x` | `[[2,1]]` |
| Receiver copy | `set(meta, { "a" : 1, "b" : 2 }); return(meta.copy().flat_hash().count_keys())` | `x` | `[2]` |
| Flat-array hash splice | `return(hash(flat_array(["a", 1, "b", { "nested" : 2 }])))` | `x` | `[{"a":1,"b":{"nested":2}}]` |
| Receiver flat-array hash splice | `set(pairs, ["a", 1]); return(harray(pairs.flat_array()))` | `x` | `[{"a":1}]` |
| Merge override | `return(merge_hash(hash("a", 1, "b", 2), hash("b", 9, "c", 3)))` | `x` | `[{"a":1,"b":9,"c":3}]` |
| Pure `set_key` | `set(meta, { "a" : 1 }); return(array(meta.set_key("b", 2).count_keys(), count_keys(meta)))` | `x` | `[[2,1]]` |
| Statement `set_key` | `set_key(meta, "a", 1); set_key(meta, "b", 2); return(copy(meta))` | `x` | `[{"a":1,"b":2}]` |
| Typed-path assignment (string selector) | `key = "stage"; value = "ok"; meta[key] = value; return(copy(meta))` | `x` | `[{"stage":"ok"}]` |
| Rename/drop/pick | `return(rename_key(hash("old", 1, "keep", 2), "old", "new"))` / `return(drop_keys(hash("a", 1, "b", 2, "c", 3), "b", "c"))` / `return(pick_keys(hash("a", 1, "b", 2, "c", 3), "b", "missing"))` | `x` | `[{"keep":2,"new":1}]` / `[{"a":1}]` / `[{"b":2}]` |
| Membership/count | `return(array(has_key(hash("a", 1), "a"), has_key(hash("a", 1), "missing")))` / `return(count_keys(hash("a", 1, "b", 2)))` | `x` | `[[1,0]]` / `[2]` |
| Sorted views | `return(sorted_keys(hash("b", 2, "a", 1)))` / `return(sorted_values(hash("b", 2, "a", 1)))` | `x` | `[["a","b"]]` / `[[1,2]]` |
| Receiver chain | `set_key(meta, "b", 2); set_key(meta, "a", 1); return(meta.set_key("c", 3).sorted_keys().join_values(","))` | `x` | `["a,b,c"]` |
| Block receiver | `return({ { "b" : 2, "a" : 1 } }.sorted_keys().join_values(","))` | `x` | `["a,b"]` |
| Hash-tree map | `set(meta, { "b" : { "y" : "B" }, "a" : "A" }); return(meta.map_leaves() { return(cat(join_values("/", path), "=", value)) })` | `x` | `[{"a":"a=A","b":{"y":"b/y=B"}}]` |
| Hash-tree walk | `set(meta, { "b" : { "y" : "B" }, "a" : "A" }); return(array(meta.walk_leaves() { paths += cat(key, "@", depth); return(value) }.count_keys(), paths))` | `x` | `[[2,["a@1","y@2"]]]` |
| Hash-tree reduce | `set(meta, { "b" : { "y" : "B" }, "a" : "A" }); return(meta.reduce_leaves("") { return(cat(acc, key, "@", depth, ";")) })` | `x` | `["a@1;y@2;"]` |

> **Current Perl caveat.** Direct odd-arity constructor calls such as
> `hash("a", 1, "missing")` are not the portable "trailing undef" spelling on the
> current Perl reference; they lower to an unsupported-helper sentinel and return
> `undef` (`[null]` through this scaffold). Spell the missing value explicitly
> as `hash("a", 1, "missing", undef)`, or pass a list-valued splice such as
> `hash(flat_array(array("a", 1, "missing")))` when that list context is intended.

### `hash(k1, v1, k2, v2, ...)`
- **Signature**: `hash(keys_and_values: scalar...)`
- **Returns**: hash
- **Behavior**: Constructs a hash from flat key/value pairs. Quoted strings are literal constructor payloads, so
  `hash("key", value)` constructs a hash entry whose key is `"key"`. Zero and paired multi-argument calls are
  valid. Arguments are interpreted as alternating keys and values. Accepts
  `flat_array(...)` and `flat_hash(...)` for list-context insertion. Direct call or terminal receiver
  `flat_array(...)` results splice their copied array members as ordered alternating tokens; an unwrapped array
  argument remains one value, and an empty splice adds no tokens.
- **Boundary**: Exact `hash(IDENTIFIER)` is a removed selector shape. Use the bare identifier to read its harray
  value or `{ identifier : value }` / `{ "identifier" : value }` to construct a field. All five backends reject
  the removed selector before execution.
- **Edge cases**: Duplicate keys: last value wins. Direct multi-argument constructor calls should pass paired
  key/value arguments; use an explicit `undef` value for a null-valued trailing key.

### `flat_hash(h)`
- **Signature**: `flat_hash(h: hash)`
- **Returns**: list (splices into parent context)
- **Behavior**: Flattens a hash into alternating key/value list context for insertion into `hash(...)` or `array(...)`.
- **Ordering boundary**: Do not currently depend on the order of key/value pairs when a harray is flattened into an
  array. Lua sorts keys for deterministic output, while the admitted backends do not yet share one portable map-
  iteration sequence. `FUTURE-PARITY-BACKLOG.5` owns normalization.

### `hash_copy(h)`
- **Signature**: `hash_copy(h: hash)`
- **Returns**: hash
- **Behavior**: Shallow copy. The new hash has the same keys and values but is a distinct container.
- **Compatibility status**: Retired on current runtimes.
- **Terse spelling**: `copy(h)` / receiver `.copy()` is the unified canonical spelling (the same `copy(...)` that subsumes legacy array/hash copy helpers). See [Terse Helper Renames](#terse-helper-renames-canonical-going-forward).
- **Receiver boundary**: `value.copy()` evaluates `value` once, deep-copies that current runtime value, and keeps
  its array/hash/scalar kind available to later compatible receiver links. Missing `value` remains undefined/null.
  Function-form `copy(value)` evaluates and copies its explicit argument; zero-argument `copy()` remains undefined.

### `merge_hash(h1, h2)`
- **Signature**: `merge_hash(base: hash, overlay: hash)`
- **Returns**: hash
- **Behavior**: Merges `h2` into `h1`. Keys in `h2` override keys in `h1`. Neither input is mutated — returns a new hash.
- **Bare bindings**: Both positions accept bare typed harray bindings, so `merge_hash(base, overlay)` is canonical.
  `merge_hash(copy(base), overlay)` is equivalent when an explicit source snapshot makes the intent clearer; no
  aggregate-selector wrapper is required or accepted.

### `set_key(h, key, value)`
- **Signature**: `set_key(h: hash, key: string, value: expr)`
- **Returns**: hash
- **Behavior**: Returns a new hash with the key set to the value. Does not mutate the input.
- **Statement form**: `set_key(name, key, value)` mutates the named working hash `name` directly. An absent target
  starts as an empty harray; an incompatible existing value fails with `binding_kind_mismatch`.
- **Operator form**: `name[key] = value` is a separate typed-path contract on all five backends. An evaluated string has the
  same field-update effect, while a nonnegative integer selects an array. It yields an independent updated root
  snapshot in value positions; bare key/RHS identifiers read scalar working variables. Receiver-dot
  `name.set_key(key, value)` remains pure.

### `name[key] = value`
- **Signature**: `target[key_expr] = value_expr`
- **Returns**: updated typed-root snapshot in value positions; side-effect-only behavior when used as a statement.
- **Behavior**: Typed path assignment on all five backends. It evaluates the selector and value once, chooses harray for a
  string or array for a nonnegative integer, mutates an isolated root copy, then commits and returns a detached
  updated root. It is not identical lowering to harray-only `set_key`.
- **Examples**: `meta["stage"] = "normalized"`, `meta[cat("source", "_kind")] = kind`,
  `meta[field_name] = field_value`, `items[position] = field_value`.
- **Edge cases**: The left side is a bare typed binding. Absence creates the root chosen by the selector;
  explicitly bound null or another wrong kind is a typed conflict. Array indexes replace or append at len, never
  create a gap. Bare key/RHS identifiers read scalar working variables in this mutation slot. Receiver-dot
  `meta.set_key(key, value)` remains pure copy-valued composition; use `meta[key] = value` when you want mutation.

### `rename_key(h, old, new)`
- **Signature**: `rename_key(h: hash, old_key: string, new_key: string)`
- **Returns**: hash
- **Behavior**: Returns a new hash with the key renamed. The value is preserved. If the old key does not exist, the hash is returned unchanged.
- **Portable collision boundary**: Keep `new_key` absent from the source. When it already exists, Perl/Julia keep
  the renamed old value while Dart/Rust keep the pre-existing destination; Lua currently follows Perl/Julia.
  `FUTURE-PARITY-BACKLOG.5` owns normalization.

### `drop_keys(h, k1, k2, ...)`
- **Signature**: `drop_keys(h: hash, keys: string...)`
- **Returns**: hash
- **Behavior**: Returns a new hash with the named keys removed. Does not mutate the input.

### `pick_keys(h, k1, k2, ...)`
- **Signature**: `pick_keys(h: hash, keys: string...)`
- **Returns**: hash
- **Behavior**: Returns a new hash containing only the named keys. Does not mutate the input.

### `has_key(h, key)`
- **Signature**: `has_key(h: hash, key: string)`
- **Returns**: boolean
- **Behavior**: Returns true if the hash contains the named key.

### `count_keys(h)`
- **Signature**: `count_keys(h: hash)`
- **Returns**: int
- **Behavior**: Returns the number of keys in the hash. Returns `0` for missing or non-hash input.

### `sorted_keys(hash)`
- **Signature**: `sorted_keys(h: hash)`
- **Returns**: array
- **Behavior**: Returns the hash's keys as an array, sorted alphabetically. Deterministic — does not depend on host-language hash iteration order.

### `sorted_values(hash)`
- **Signature**: `sorted_values(h: hash)`
- **Returns**: array
- **Behavior**: Returns the hash's values as an array, sorted by their corresponding keys alphabetically. Deterministic.

### Hash receiver-dot value chains
- **Signature**: `hash_expr.method(args...).next(args...)`
- **Returns**: the documented return value of the final helper in the chain.
- **Behavior**: A compatible hash receiver feeds into the first pure hash helper, and each helper's return
  value feeds the next compatible helper. For example,
  `meta.set_key("stage", "normalized").count_keys()` is equivalent to
  `count_keys(set_key(meta, "stage", "normalized"))`. `meta.sorted_keys().join_values(",")` first
  derives the sorted key array, then continues through the array receiver-chain family.
- **Allowed hash-returning links**: `copy`, `merge_hash`, `set_key`, `rename_key`, `drop_keys`,
  `pick_keys`, and `flat_hash`. `merge_hash` preserves the canonical helper contract: later arguments
  override earlier keys.
- **Allowed terminal/bridge links**: `sorted_keys` and `sorted_values` return arrays and may continue through
  compatible array receiver helpers. `count_keys` and `has_key` return number and boolean terminal values.
  Field reads from a named working hash use `name.pick_keys(key).sorted_values().first()` after storing
  expression receivers in a named hash. Direct bracket reads such as `retv["key"]` are for scalar hashref
  payloads, not working-hash value reads.
- **Boundary**: `set_key(name, key, value)` mutates the named working harray. On all five backends,
  `name[key] = value` is typed-path assignment and may instead select array for an integer; it yields the updated
  root snapshot in value positions.
  Receiver-dot `meta.set_key(key, value)` is pure value composition; it mutates nothing unless assigned back.
- **Block receivers**: An expression-valued block whose value is a hash can be the receiver, for example
  `{ { "b" : 2, "a" : 1 } }.sorted_keys().join_values(",")`.

### Hash-tree receiver block traversal: `walk_leaves`, `map_leaves`, `reduce_leaves`
- **Signatures**:
  - `hash_expr.walk_leaves() { block }`
  - `hash_expr.map_leaves() { block }`
  - `hash_expr.reduce_leaves(initial_acc: expr) { block }`
- **Returns**:
  - `walk_leaves` returns the original hash tree after running callbacks.
  - `map_leaves` returns a new hash tree with each leaf replaced by the callback result.
  - `reduce_leaves` returns the final accumulator.
- **Backend status**: Perl, Rust, Dart, Julia, and Lua support this hash-root contract. Lua's harray proof passes
  113/113 and locks the exact Perl callback result; the shared root-kind dispatcher then closes array roots without
  changing hash semantics and passes 114/114 on both Lua ABIs.
- **Tree shape**: The receiver must be a hash. Nested hashes are interior nodes. Every non-hash value is a leaf,
  including arrays.
- **Traversal order**: Sorted-key depth-first traversal. For `{ "a" : "A", "arr" : ["u", "v"], "b" : { "y" : "B" } }`,
  callbacks run for paths `a`, `arr`, then `b/y`.
- **Callback bindings**: Each callback runs immediately in the caller's current action/runtime context with scoped
  scalar bindings:
  - `value`: current leaf value.
  - `key`: current leaf key.
  - `path`: array value containing root-to-leaf path segments.
  - `depth`: number of path segments (`count(path)`); a root leaf has depth 1.
  - `acc`: current accumulator for `reduce_leaves` only.
- **Binding restoration**: The traversal restores those scoped names after each callback and after traversal
  completes, including callback errors. Inputs, paths, mapped results, and accumulator values are copied, so
  callback mutation cannot alias the source. Mutations to other working variables are ordinary side effects and
  persist.
- **Return semantics**: `return(expr)` inside the callback is block-local and supplies that callback's result. In
  `map_leaves`, the result replaces the current leaf. In `reduce_leaves`, the result becomes the next accumulator.
  In `walk_leaves`, the result is ignored.
- **Edge cases**: A non-hash receiver yields `undef` and does not execute the callback. `walk_leaves()` and
  `map_leaves()` take no parenthesized arguments. `reduce_leaves(initial)` requires exactly one parenthesized
  initial accumulator expression. `walk_leaves()` and `map_leaves()` return hash values and can feed later hash
  receiver links such as `.count_keys()`. `reduce_leaves(...)` is terminal. These are immediate receiver block
  methods, not closures or delayed callbacks.
- **Examples**:
  - After `set(meta, { "b" : { "y" : "B" }, "a" : "A" })`,
    `return(meta.map_leaves() { return(cat(join_values("/", path), "=", value)) })`
    yields `[{"a":"a=A","b":{"y":"b/y=B"}}]` through the standard `demo::` wrapper.
  - After `set(meta, { "b" : { "y" : "B" }, "a" : "A" })`,
    `return(array(meta.walk_leaves() { paths += cat(key, "@", depth); return(value) }.count_keys(), paths))`
    yields `[[2,["a@1","y@2"]]]`.
  - After `set(meta, { "b" : { "y" : "B" }, "a" : "A" })`,
    `return(meta.reduce_leaves("") { return(cat(acc, key, "@", depth, ";")) })` yields `["a@1;y@2;"]`.

## 5. Numeric Helpers

All numeric helpers return `undef` if any input is missing, non-numeric, wrong-arity, non-finite, or (for
division/modulo) a zero divisor, unless wrapped in `coalesce(...)`. Numeric inputs are finite numbers or untrimmed
decimal strings matching `-?(?:digits(?:.digits)?|.digits)`. Booleans, null, arrays, harrays, plus/exponent/hex,
surrounding-whitespace, and trailing-dot strings are not numeric. Comparisons return numeric `1`/`0` when valid and
`undef` when invalid. Rounding sends exact halves away from zero; signed integer modulo uses floor/Euclidean
remainder, so a nonzero result has the divisor's sign. These rules are versioned by
`capability_conformance/scalar_numeric_contract.json` rather than delegated to host arithmetic APIs.

`num_add`, `num_mul`, and scalar `num_min`/`num_max` accept two or more operands. `num_sub`, `num_div`, `num_mod`,
and numeric comparisons require exactly two; unary helpers exactly one; clamp exactly three. Array-form min/max
and aggregate reducers keep their one-array signatures below.

Number receiver-dot value chains are pure value composition over this same family. Receiver methods use terse
names and map to `num_*`: `value.abs()` -> `num_abs(value)`, `value.add(2, 3)` -> `num_add(value, 2, 3)`,
`value.clamp(0, 10)` -> `num_clamp(value, 0, 10)`, and `value.gt(3)` -> `num_gt(value, 3)`. Bare receiver
identifiers read scalar working variables. Integer and float literal receivers are accepted (`5.mod(2)`,
`3.5.floor().add(1)`). Comparisons (`eq`, `ne`, `gt`, `ge`, `lt`, `le`) are terminal boolean values; a later
receiver-dot call after a comparison returns `undef`/`null`. Statement and lifecycle methods are not numeric receiver methods. An expression-valued block whose value is numeric can be the
receiver, for example `{ 3.5 }.floor().add(2)`.

The same numeric family also has function-form word aliases:
`add`, `sub`, `mul`, `div`, `mod`, `abs`, `floor`, `ceil`, `round`, `min`,
`max`, `clamp`, `sum`, `avg`, `median`, `range`, `eq`, `ne`, `gt`, `ge`, `lt`,
and `le`. These are exact aliases for the corresponding `num_*` helpers.
Arithmetic symbol callees are accepted as the same ordinary call form for the
arithmetic subset: `+(a, b)`, `-(a, b)`, `*(a, b)`, `/(a, b)`, and `%(a, b)`
map to `num_add`, `num_sub`, `num_mul`, `num_div`, and `num_mod`. These aliases
remain ordinary `callee(args)` calls, so there is no operator precedence; write
`+(*(a, b), c)` when you need explicit grouping. Comparison symbol callees are
accepted as numeric aliases too: `==(a, b)`, `!=(a, b)`, `>(a, b)`, `>=(a, b)`,
`<(a, b)`, and `<=(a, b)` map to the corresponding `num_*` comparison helpers.
The shipped explicit string bridge names are `str_eq`, `str_ne`, `str_gt`,
`str_ge`, `str_lt`, and `str_le`; use them for lexical string comparisons.

> **Worked examples** use the same runnable two-rule shape as §2 (a top `::` entry rule
> — no regex — dispatching to a `value` rule that carries the regex and reads
> `entry_group(N)`; output = the parser's one-element accumulator array). The array-form
> reducers (`num_sum`, `num_avg`, `num_median`, `num_range`, and the array form of
> `num_min`/`num_max`) take an array of numeric values: use explicit `array(...)` in function form, or a
> compatible array receiver such as `scores.sum()` / `scores.min()`. Build literal arrays from
> capture groups (`array(entry_group(0), entry_group(1), …)`) or numeric literals. An
> `undef` result (e.g. divide-by-zero) surfaces as a `null` element.

### `num_add(a, b)`
- **Signature**: `num_add(a: numeric, b: numeric)`
- **Returns**: numeric
- **Behavior**: Adds two numbers. Returns `undef` if either operand is non-numeric.
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /(\d+)\+(\d+)/  I.return( num_add(entry_group(0), entry_group(1)) )
  ```
  Input `2+3` → `[5]`.

### `num_sub(a, b)`
- **Signature**: `num_sub(a: numeric, b: numeric)`
- **Returns**: numeric
- **Behavior**: Subtracts `b` from `a`.
- **Example**: over `/(\d+)-(\d+)/`, `num_sub(entry_group(0), entry_group(1))` on `10-4` → `[6]`.

### `num_mul(a, b)`
- **Signature**: `num_mul(a: numeric, b: numeric)`
- **Returns**: numeric
- **Behavior**: Multiplies two numbers.
- **Example**: over `/(\d+)x(\d+)/`, `num_mul(entry_group(0), entry_group(1))` on `6x7` → `[42]`.

### `num_div(a, b)`
- **Signature**: `num_div(a: numeric, b: numeric)`
- **Returns**: numeric
- **Behavior**: Divides `a` by `b`. Returns `undef` on divide-by-zero.
- **Example**: over `/(\d+)\/(\d+)/`, `num_div(entry_group(0), entry_group(1))` gives `[5]` on `20/4`, `[3.5]` on `7/2`, and `[null]` on `5/0`.

### `num_mod(a, b)`
- **Signature**: `num_mod(a: numeric, b: numeric)`
- **Returns**: int
- **Behavior**: Modulo operation. Returns `undef` for divide-by-zero or non-integer operands.
- **Example**: over `/(\d+)%(\d+)/`, `num_mod(entry_group(0), entry_group(1))` on `17%5` → `[2]`.

### `num_abs(x)`
- **Signature**: `num_abs(x: numeric)`
- **Returns**: numeric
- **Behavior**: Absolute value.
- **Example**: over `/(-?\d+)/`, `num_abs(entry_group(0))` on `-7` → `[7]`.

### `num_floor(x)`
- **Signature**: `num_floor(x: numeric)`
- **Returns**: int
- **Behavior**: Floor — largest integer ≤ x.
- **Example**: over `/([\d.]+)/`, `num_floor(entry_group(0))` on `3.7` → `[3]`.

### `num_ceil(x)`
- **Signature**: `num_ceil(x: numeric)`
- **Returns**: int
- **Behavior**: Ceiling — smallest integer ≥ x.
- **Example**: over `/([\d.]+)/`, `num_ceil(entry_group(0))` on `3.2` → `[4]`.

### `num_round(x)`
- **Signature**: `num_round(x: numeric)`
- **Returns**: int
- **Behavior**: Rounds to nearest integer (half-up).
- **Example**: over `/([\d.]+)/`, `num_round(entry_group(0))` on `3.5` → `[4]`.

### `num_min(a, b)` / `num_min(arr)`
- **Signature**: `num_min(a: numeric, b: numeric)` or `num_min(arr: array)`
- **Returns**: numeric
- **Behavior**: Two-argument form: returns the smaller of two numbers. Array form: returns the minimum element. Returns `undef` for empty array, non-array, or non-numeric elements.
- **Example**: 2-arg — over `/(\d+),(\d+)/`, `num_min(entry_group(0), entry_group(1))` on `8,3` → `[3]`. Array — over `/(\d+),(\d+),(\d+),(\d+)/`, `num_min(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3)))` on `8,3,5,1` → `["1"]` on current Perl (numeric-string result; see below).

### `num_max(a, b)` / `num_max(arr)`
- **Signature**: `num_max(a: numeric, b: numeric)` or `num_max(arr: array)`
- **Returns**: numeric
- **Behavior**: Two-argument form: returns the larger. Array form: returns the maximum element.
- **Example**: 2-arg — over `/(\d+),(\d+)/`, `num_max(entry_group(0), entry_group(1))` on `8,3` → `[8]`. Array — over `/(\d+),(\d+),(\d+),(\d+)/`, `num_max(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3)))` on `8,3,5,1` → `["8"]` on current Perl (numeric-string result; see below).

### `num_clamp(x, lo, hi)`
- **Signature**: `num_clamp(x: numeric, lo: numeric, hi: numeric)`
- **Returns**: numeric
- **Behavior**: Clamps `x` to the `[lo, hi]` range. Returns `undef` if bounds are inverted (`lo > hi`).
- **Example**: over `/(\d+)/`, `num_clamp(entry_group(0), 0, 10)` gives `[10]` on `42` and `[7]` on `7`.

### `num_sum(arr)`
- **Array value sources (Perl)**: Literals, bindings, direct reads and function arguments/results are accepted.
  See the [complete six-reducer example](../dsl/value-container-flow-helper-reference.md#numeric-reducers-consume-array-values), including empty arrays and receiver form.
- **Signature**: `num_sum(arr: array)`
- **Returns**: numeric
- **Behavior**: Sum of array elements. Returns `0` for empty array. Returns `undef` for non-array or non-numeric element sources.
- **Example**:
  ```text
  demo::  -> value  .push
  LX { return(copy(demo)) }

  value : /(\d+),(\d+),(\d+),(\d+)/  I.return( num_sum(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3))) )
  ```
  Input `1,2,3,4` → `[10]`.

### `num_avg(arr)`
- **Signature**: `num_avg(arr: array)`
- **Returns**: numeric
- **Behavior**: Arithmetic mean of array elements. Returns `undef` for empty array, non-array, or non-numeric elements.
- **Example**: over `/(\d+),(\d+),(\d+)/`, `num_avg(array(entry_group(0), entry_group(1), entry_group(2)))` on `2,4,6` → `[4]`.

### `num_median(arr)`
- **Signature**: `num_median(arr: array)`
- **Returns**: numeric
- **Behavior**: Median of array elements after numeric sort. For even-length arrays, returns the average of the two middle elements. Returns `undef` for empty array, non-array, or non-numeric elements.
- **Example**: over `/(\d+),(\d+),(\d+),(\d+),(\d+)/`, `num_median(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3), entry_group(4)))` on `5,1,3,2,4` → `["3"]` on current Perl (sorted `1,2,3,4,5`; middle element).

Current Perl type limitation: array-form `num_min`/`num_max` and odd-length
`num_median` preserve the selected element's string kind when the array contains
numeric text, including capture groups. Even-length median, sum, average and range
perform arithmetic and return numbers. `SESSION-STARTUP-READING.95` owns correction
of these numeric result kinds; the scalar two-argument min/max forms return numbers.

### `num_range(arr)`
- **Signature**: `num_range(arr: array)`
- **Returns**: numeric
- **Behavior**: `max - min` of array elements. Returns `undef` for empty array, non-array, or non-numeric elements.
- **Example**: over `/(\d+),(\d+),(\d+),(\d+)/`, `num_range(array(entry_group(0), entry_group(1), entry_group(2), entry_group(3)))` on `3,9,1,7` → `[8]` (`9 - 1`).

## 6. Control Flow Helpers

> **Worked examples** use the standard `demo:: -> value .push` scaffold unless stated otherwise.
> Examples that read `entry_group(0)` use a regex with an explicit capture group.

**Verified branch, loop, and return examples:**

| Surface | Body inside `value`'s `I { ... }` block | Input | Output |
| --- | --- | --- | --- |
| Inline `if(...)` value | `return(if(str_eq(entry_group(0), "hot"), "H", else("C")))` over `/([A-Za-z]+)/` | `hot` | `["H"]` |
| Marker `if`/`elseif`/`else` | `kind = entry_group(0); if(str_eq(kind, "a")); return("A"); elseif(str_eq(kind, "b")); return("B"); else(); return("Z"); endif()` over `/([A-Za-z]+)/` | `b` | `["B"]` |
| Attached `if` blocks | `kind = entry_group(0); if(str_eq(kind, "a")) { return("A") } elseif(str_eq(kind, "b")) { return("B") } else { return("Z") }` over `/([A-Za-z]+)/` | `b` | `["B"]` |
| `when` / `otherwise` | `kind = entry_group(0); when(str_eq(kind, "yes")) { return("Y") } otherwise { return("N") }` over `/([A-Za-z]+)/` | `yes` | `["Y"]` |
| Inline `switch(...)` value | `kind = entry_group(0); return(switch(kind, case("a", "A"), case("b", "B"), default("Z")))` over `/([A-Za-z]+)/` | `b` | `["B"]` |
| Attached `switch` blocks | `kind = entry_group(0); switch(kind) { case("a") { return("A") } case("b") { return("B") } default { return("Z") } }` over `/([A-Za-z]+)/` | `b` | `["B"]` |
| `while` loop | `count = 0; while(num_lt(count, 3)) { count = num_add(count, 1) }; return(count)` | `x` | `[3]` |
| `return(value)` | `return(entry_group(0))` over `/([A-Za-z]+)/` | `ok` | `["ok"]` |
| `return_undef()` | `if(str_eq(entry_group(0), "skip")) { return_undef() } else { return(entry_group(0)) }` over `/([A-Za-z]+)/` | `skip` | `[null]` |

**Verified repetition-control example:**

```text
demo::
 -> value .push
 LX { return(copy(demo)) }

value : /(keep|skip|take)\s*/
 I { if(str_eq(entry_group(0), "skip")) { next() } else { return(entry_group(0)) } }
```

Input `keep skip take ` yields `["keep","take"]`: `next()` consumes the `skip` repetition without appending a
value to `demo`'s accumulator.

**Compile-only fatal-exit example:** `exit_now(2)` is descriptor-verified as language-agnostic control metadata
(`ready=1`, `raw=0`, `fallback=0`, `unresolved=0`, canonical nodes `["EXIT"]`). It is not run in the example
table because its runtime behavior is to terminate the parser process.

### `and(value, ...)`, `or(value, ...)`, and `not(value)`
- **Target signatures**: `and` and `or` require at least one positional value; `not` requires exactly one.
- **Target returns**: a real boolean. One-argument `and`/`or` are boolean projections.
- **Target evaluation**: after arity succeeds, every operand runs exactly once from left to right. Logical helpers
  do not short-circuit; `if`/`switch`/`while` remain the lazy mechanisms.
- **Target truthiness**: null, false, numeric zero, the empty string, and empty arrays/harrays are false. Other
  finite numbers, every nonempty string (including `"0"` and `"false"`), nonempty aggregates, and codeblocks are
  true. Testing a codeblock does not invoke it.
- **Target failures**: empty `and`/`or`, empty `not`, and multi-argument `not` report
  `helper_arity_mismatch` before evaluating any operand.
- **Scope boundary**: the codeblock value-kind row is model/backend-unit evidence; it does not activate the
  separately owned `{|...| ... }` literal syntax.
- **Current portability status**: ADR `0043` and `linkedspec-logical-helper-v1` are adopted. Perl native/live/
  standalone-emitted execution conforms under `FUTURE-PARITY-BACKLOG.5.2.2`; Rust native, serialized,
  generated-plan, direct-value, and compiled emitted execution conforms under `.5.2.3`; Dart native, normalized,
  generated-plan, standalone-emitted, and primary execution conforms under `.5.2.4`; Julia native, normalized,
  generated-plan, independently compiled emitted, and primary execution conforms under `.5.2.5`; Lua native,
  reconstructed, generated-plan, loaded emitted-module, and primary execution conforms on both ABIs under
  `.5.2.6`. Generated/primary `.5.2.7` proves every available direct/traced generated role, exact failure/source
  attribution, Rust's established direct-value versus compatibility-output split, and one common five-command
  default/POSIX primary case. Recurring `.5.2.8` now composes the neutral checker, exact native/generated roles
  for Perl/Rust/Dart/Julia/PUC-Lua/LuaJIT, selected 5x2x1 case, and support ledgers under one omission-checked
  driver. Public no-drift `.5.2.9` locks the authoritative guide/backend/status set and closes rollout at
  8 complete / 0 pending. Run `bash tools/check_logical_helper_five_backend.sh` for the recurring all-toolchain
  behavior proof; the offline checker also rejects public document, marker, stale-claim, and admission drift.

### `if(cond, then, elseif(cond2, then2), else(default))`
- **Signature**: Inline composite value form.
- **Returns**: value of the selected branch in supported value positions.
- **Behavior**: Evaluates conditions left-to-right and evaluates only the selected branch payload. First true
  condition's branch is returned. If none match, the `else(...)` branch or plain third-argument fallback is
  returned. If no fallback matches, returns `undef`.
- **Portability status**: Implemented on Perl, Rust, Dart, Julia, and Lua in `return(...)`, assignment RHS, and
  fluent `.return(...)` value positions. Perl, Rust, Dart, Julia, and Lua consume ADR `0043` through one
  helper/condition truth seam per backend. `FUTURE-PARITY-BACKLOG.5.2.8` owns the recurring six-consumer
  native/generated/primary/support proof; `.5.2.9` closes public no-drift and parent `.5.2` at 8/0.

### `if(cond); ... elseif(cond2); ... else(); ... endif()`
- **Signature**: Statement-marker form.
- **Returns**: no value of its own; branch statements provide side effects or `return(...)` values.
- **Behavior**: Conditions are evaluated left-to-right. Only statements in the active branch execute. `else`
  runs when no prior branch matched, and `endif()` closes the chain.
- **Sugar**: `else` and `endif` bare-keyword forms are equivalent to `else()` and `endif()`.

### `if(cond) { ... } elseif(cond2) { ... } else { ... }`
- **Signature**: Attached-block statement form.
- **Returns**: no value of its own; branch statements provide side effects or `return(...)` values.
- **Behavior**: Conditions are evaluated left-to-right. Only statements in the active branch execute. The
  implicit close at the end of the attached chain is equivalent to `endif()`.
- **Sugar**: Compact continuations such as `} elseif(cond2) {` and `} else {` are accepted. A following
  same-line statement still needs the normal semicolon separator after the final `}`.

### `when(cond) { ... } otherwise { ... }`
- **Signature**: Attached-block alias form.
- **Returns**: no value of its own; branch statements provide side effects or `return(...)` values.
- **Behavior**: Equivalent to `if(cond) { ... } else { ... }`. The Perl reference and Rust backend
  normalize the aliases to canonical `if`/`else` control flow; they are not host-language `when` blocks.
- **Portability boundary**: Use `when/otherwise` only in this attached shape and `i/elif` only in marker chains.
  Perl, Dart, and Julia currently accept more combinations than Rust; backlog `.5` owns normalization.

### `switch(expr, case(val, body), default(body))`
- **Signature**: Inline composite form.
- **Returns**: value of the first matching `case` body, or the `default` body when no case matches.
- **Behavior**: Evaluates `expr` once, compares it to each `case(val)` in order, and evaluates only the
  selected branch payload. A bare switch subject such as `switch(kind, ...)` reads scalar `kind`; a bare case
  value such as `case(foo, body)` is a literal tag named `foo`, matching attached-switch case labels.
- **Portability status**: Implemented on Perl, Rust, Dart, Julia, and Lua in `return(...)`, assignment RHS, and
  fluent `.return(...)` value positions.
- **Comparison boundary**: Null matches empty text on all current backends. Boolean/number and aggregate
  comparison are not yet portable: Perl/Rust/Lua make `false` match numeric `0`; Dart/Julia do not. Perl/Lua do
  not scalar-compare arrays/harrays, Rust currently collapses them to empty text, and Dart/Julia stringify host
  containers. Use text/number predicates to normalize a subject before switching when these kinds are possible;
  `FUTURE-PARITY-BACKLOG.5` owns the final typed-equality policy.

### `switch(expr) { case(val) { ... } default { ... } }`
- **Signature**: Attached-block statement form.
- **Returns**: no value of its own; branch statements provide side effects or `return(...)` values.
- **Behavior**: Evaluates `expr` once. `case(...)` branches are tested in order, only the first matching branch
  executes, and `default` executes only when no case matched. A bare switch subject reads the working scalar; a
  bare case label is a literal tag, so `switch(kind) { case(foo) { ... } }` compares scalar `kind` to `"foo"`.
- **Sugar**: `default() { ... }` is equivalent to `default { ... }`. A following same-line statement still
  needs the normal semicolon separator after the final `}`.
- **Portability status**: Implemented on Perl, Rust, Dart, Julia, and Lua. It shares the inline form's pending
  boolean/number and aggregate comparison boundary above.

### `switch(expr); case(val); ...; endcase(); default(); ...; endswitch()`
- **Signature**: Marker-delimited statement form.
- **Returns**: no value of its own; selected branch statements provide side effects or `return(...)` values.
- **Behavior**: Evaluates `expr` once, selects the first matching `case` or one `default`, and skips every later
  candidate and body. `endcase()` is an optional explicit branch boundary; the next same-depth `case`, `default`,
  or `endswitch()` also closes the current branch. Nested marker switches own their inner markers.
- **Portability status**: Implemented on Perl, Rust, Dart, Julia, and Lua. Bare labels and the comparison boundary
  are identical to inline and attached switch. Keep every executable statement inside a case/default range:
  Perl currently executes statements outside all ranges, while Rust/Dart/Julia/Lua skip them. Backlog `.5` owns
  normalization.

### `while(cond) { ... }`
- **Signature**: Attached-block statement form.
- **Returns**: no value of its own; body statements provide side effects or `return(...)` values.
- **Behavior**: Perl, Rust, Dart, Julia, and Lua evaluate `cond` before every iteration and expose body mutation to
  the next condition. A `return(expr)` exits the surrounding action, or stays local when the loop is inside an
  expression-valued block.
- **Safety**: The default deterministic guard is 10000 body executions. Perl/Rust/Lua recheck the condition after
  the final allowed body and fail only if it remains true; Dart/Julia currently fail immediately. Lua's typed
  failure includes code, keyword, ActionIR kind, configured limit, and rule.
- **Portability boundary**: Do not rely on `next()` inside the body yet. Perl/Lua treat it as inner-loop continue,
  Rust treats it as a no-op, and Dart/Julia propagate it to rule repetition. Backlog `.5` owns guard/flow
  normalization.

### `case(val, body)`
- **Signature**: Inline switch branch.
- **Returns**: branch body value.
- **Behavior**: Embedded in inline-composite `switch(expr, case(...), ...)`. A bare first argument is a literal
  tag. Use a value expression such as `case(cat(foo, ""), body)` when the case value should be read dynamically
  from a working variable.

### `default(body)`
- **Signature**: Default switch branch.
- **Returns**: branch body value.

### `exit_now(status)`
- **Signature**: `exit_now(status: int)`
- **Returns**: never returns — terminates parser immediately.
- **Behavior**: Exits the parser with the given exit status. Used for fatal diagnostic paths.
- **Compatibility**: Bare `exit` is legacy; `exit_now(...)` contributes canonical `EXIT` metadata.

### `next()`
- **Signature**: `next()`
- **Returns**: control flow — skips to next repetition.
- **Behavior**: Skip the current repetition and advance to the next in repeated-rule loops. Consumes/recognizes input without appending a value.
- **Syntax**: Perl, Rust, Dart, Julia, and Lua accept standalone bare `next`; it is the same zero-argument operation as `next()`.

### `return(value)`
- **Signature**: `return(value: expr)`
- **Returns**: the supplied value through the active return channel.
- **Behavior**: As a top-level action or lifecycle statement, writes the surrounding rule/action return channel. Inside an expression-valued block, it is block-local: it yields that block's value and skips later statements in the block.
- **Edge cases**: `return(array(...))` returns an array value. A bare scalar source such as `return(count)` reads the working scalar `count`; primitive literals stay exact, so `return(true)` is the boolean literal and `return(undef)` is `undef`. A final non-`return(...)` statement in a lifecycle block is evaluated as a statement and is not an implicit rule return.

### `return_undef()`
- **Signature**: `return_undef()`
- **Returns**: undef.
- **Behavior**: Explicitly returns undef. Used for flow-stop edges.

## 7. Capture and Mark Helpers

LinkedSpec tracks two kinds of capture origin: a single **anonymous capture
cursor** (set by `start_capture_slice()`) and any number of **named marks** (set
by `mark_here(name)`, `mark_input_start(name)`, and the other `mark_*` helpers).
The capture readers below extract text — or its character length — between such
an origin and one of three endpoints:

- the **start of the current match** — the non-cursor readers (`capture_slice`,
  `capture_slice_len`, `capture_take`, `capture_take_len`, `capture_from`,
  `capture_len_from`, `capture_take_len_from`);
- the **current scan position** (the cursor) — the `*_until_cursor*` readers;
- the **end of input** — the `*_rest*` readers.

The `capture_until_boundary(rule[, ...])` helper is the structural-lookahead
member of this family. It does not read from the anonymous capture cursor or a
named mark. It starts at the live cursor, seeks for named rule boundaries, and
captures the text before the earliest boundary match without consuming that
boundary.

Text readers return the captured substring; `*_len*` readers return its length in
**characters** (not bytes). A reader whose mark is unset, or whose span is
reversed (end before start), returns `undef`. The `capture_take*` variants are
destructive: after reading they advance the capture origin — the anonymous cursor
or the named mark — to the **current scan position** (or to **end of input** for
the `_rest` readers), so the next capture continues from there. Note that the
match-start readers (`capture_take`, `capture_take_len`, `capture_take_len_from`)
read up to the match start but still advance the origin to the scan position.

> **Worked examples.** Boundary-oriented capture examples are often naturally
> default/OR-family snippets: an opener match records a boundary, the rule seeks to a
> later delimiter match, and the capture helper reads the text between them.

Anonymous capture cursor:

```text
demo::
 -> body .push
 LX { return(copy(demo)) }

body: /BEGIN/ /END/
 -> body[1] {
   return(hash("body", trim(capture_slice()), "width", capture_slice_len()))
 }
```

With `body:` deriving intrinsic `seek`, input `BEGIN alpha END` returns
`[{"body":"alpha","width":7}]`: `capture_slice()` spans the text between the
`BEGIN` match and the later `END` match, while `trim(...)` removes the surrounding
spaces for the displayed body.

Named marks and explicit span endpoints:

```text
demo::AND
 => pair

pair:AND
 /\[/
 /\w+/
 /:/
 /\w+/
 /\]/
 -> pair[0] { mark_here(body_start) }
 -> pair[2] {
   mark_match_start(colon_start)
   left = capture_between(body_start, colon_start)
   mark_here(right_start)
 }
 -> pair[4] {
   mark_match_start(close_start)
   return(hash(
     "left", left,
     "left_len", capture_len_between(body_start, colon_start),
     "right", capture_between(right_start, close_start)
   ))
 }
```

With `pair:AND` deriving intrinsic contiguous `consume`, input `[left:right]` returns
`[{"left":"left","left_len":4,"right":"right"}]`. The first action records the
left boundary, the colon action records an exact right boundary for `left` and a
new start for `right`, and the closing-bracket action records the final right edge.

### `start_capture_slice()`
- **Signature**: `start_capture_slice()`
- **Returns**: void
- **Behavior**: Moves the anonymous capture cursor to the current scan position.
- **Compatibility**: `capture_slice_here()` is a retired alias.

### `capture_slice()`
- **Signature**: `capture_slice()`
- **Returns**: scalar
- **Behavior**: Returns the text from the anonymous capture cursor to the start of the current match.
- **Compatibility**: `capture_from_rule_start()` is a retired alias.

### `capture_slice_len()`
- **Signature**: `capture_slice_len()`
- **Returns**: int
- **Behavior**: Character length of `capture_slice()`. Preferred over raw position arithmetic.
- **Compatibility**: `capture_slice_length()` and `capture_len_from_rule_start()` are retired aliases.

### `capture_slice_until_cursor()`
- **Signature**: `capture_slice_until_cursor()`
- **Returns**: scalar or undef
- **Behavior**: Returns the text from the anonymous capture cursor to the **current scan position** (cursor).

### `capture_slice_until_cursor_len()`
- **Signature**: `capture_slice_until_cursor_len()`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_slice_until_cursor()`.

### `capture_until_boundary(...)`
- **Signature**: `capture_until_boundary(rule[, rule...])`
- **Returns**: scalar or undef
- **Behavior**: Treats each argument as a named boundary rule, quoted or bare. From the current live cursor, seeks for the earliest match of any valid boundary rule, returns the text from the original cursor to that boundary start, and moves the live cursor to that boundary start. The boundary match itself is not consumed. If at least one valid boundary rule exists but no boundary is found, captures through end-of-input and moves the cursor to end-of-input. If no requested boundary rule can be resolved to a pattern, returns `undef` and leaves the cursor unchanged.
- **Use it when**: an open-ended body should stop at the next structural token and that token must remain available to the normal rule path. This is different from `save_cursor()` / `restore_cursor()` and from `rewind_match_start()` / `rewind_entry_start()`: those helpers move an already-consumed cursor, while `capture_until_boundary(...)` avoids consuming the structural boundary in the first place.
- **Backend status**: Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT implement the named-rule boundary behavior. Lua
  uses a boundary-specific compiled-alternation cache and unconditional seek, so consume mode does not anchor the
  lookahead. The signature requires at least one rule; zero-argument behavior is not portable and is owned by
  `FUTURE-PARITY-BACKLOG.5`.

- **Perl quoted labels**: `capture_until_boundary("a,b,c", end)` requests two labels,
  `a,b,c` and `end`; it never expands the first into `a`, `b`, and `c`. Empty
  quoted labels are omitted. Escaped quotes and backslashes are decoded; spaces
  inside quotes remain significant. A quoted unresolved label follows the same
  no-usable-rule behavior as a bare unresolved label. See the
  [boundary reference](../dsl/source-boundary-helper-reference.md)
  for executable examples and the separately tracked Perl nested unknown-escape
  limitation. These escape examples do not establish new rule-definition syntax
  or cross-backend escape parity.

### `capture_take()`
- **Signature**: `capture_take()`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_slice()` (anonymous cursor to the start of the current match), then advances the anonymous cursor to the **current scan position**.

### `capture_take_len()`
- **Signature**: `capture_take_len()`
- **Returns**: int or undef
- **Behavior**: Character length from the anonymous cursor to the start of the current match, then advances the anonymous cursor to the **current scan position**.

### `capture_take_until_cursor()`
- **Signature**: `capture_take_until_cursor()`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_slice_until_cursor()`, then advances the anonymous cursor to the cursor.

### `capture_take_until_cursor_len()`
- **Signature**: `capture_take_until_cursor_len()`
- **Returns**: int or undef
- **Behavior**: Like `capture_slice_until_cursor_len()`, then advances the anonymous cursor to the cursor.

### `capture_rest()`
- **Signature**: `capture_rest()`
- **Returns**: scalar or undef
- **Behavior**: Returns the text from the anonymous capture cursor to the **end of input**.

### `capture_rest_len()`
- **Signature**: `capture_rest_len()`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_rest()`.
- **Compatibility**: `capture_rest_length()` is a retired alias.

### `capture_take_rest()`
- **Signature**: `capture_take_rest()`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_rest()`, then advances the anonymous cursor to end of input.

### `capture_take_rest_len()`
- **Signature**: `capture_take_rest_len()`
- **Returns**: int or undef
- **Behavior**: Like `capture_rest_len()`, then advances the anonymous cursor to end of input.

### `mark_input_start(name)`
- **Signature**: `mark_input_start(mark_name: string)`
- **Returns**: void
- **Behavior**: Stores the absolute start-of-input position (0) under the named mark. Used for whole-input capture.

### `mark_input_end(name)`
- **Signature**: `mark_input_end(mark_name: string)`
- **Returns**: void
- **Behavior**: Stores the absolute end-of-input position under the named mark.

### `mark_copy(target, source)`
- **Signature**: `mark_copy(target_mark: string, source_mark: string)`
- **Returns**: void
- **Behavior**: Copies the `source` mark's position onto the `target` mark. If `source` is unset, the `target` mark is removed instead.

### `capture_from(name)`
- **Signature**: `capture_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Returns text from the named mark to the **start of the current match**.

### `capture_len_from(name)`
- **Signature**: `capture_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_from(name)`.

### `capture_until_cursor_from(name)`
- **Signature**: `capture_until_cursor_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Returns text from the named mark to the **current scan position** (cursor).

### `capture_until_cursor_len_from(name)`
- **Signature**: `capture_until_cursor_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_until_cursor_from(name)`.

### `capture_take_until_cursor_from(name)`
- **Signature**: `capture_take_until_cursor_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_until_cursor_from(name)`, then advances the mark to the cursor.

### `capture_take_until_cursor_len_from(name)`
- **Signature**: `capture_take_until_cursor_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Like `capture_until_cursor_len_from(name)`, then advances the mark to the cursor.

### `capture_take_len_from(name)`
- **Signature**: `capture_take_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Character length from the mark to the start of the current match, then advances the mark to the cursor.

### `capture_rest_from(name)`
- **Signature**: `capture_rest_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Returns text from the named mark to the **end of input**.

### `capture_rest_len_from(name)`
- **Signature**: `capture_rest_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_rest_from(name)`.

### `capture_take_rest_from(name)`
- **Signature**: `capture_take_rest_from(mark_name: string)`
- **Returns**: scalar or undef
- **Behavior**: Like `capture_rest_from(name)`, then advances the mark to end of input.

### `capture_take_rest_len_from(name)`
- **Signature**: `capture_take_rest_len_from(mark_name: string)`
- **Returns**: int or undef
- **Behavior**: Like `capture_rest_len_from(name)`, then advances the mark to end of input.

### `capture_between(start, end)`
- **Signature**: `capture_between(start_mark: string, end_mark: string)`
- **Returns**: scalar or undef
- **Behavior**: Returns text between two named marks (requires `start` ≤ `end`).

### `capture_len_between(start, end)`
- **Signature**: `capture_len_between(start_mark: string, end_mark: string)`
- **Returns**: int or undef
- **Behavior**: Character length of `capture_between(start, end)`.

## 8. Entry and Match Helpers

These helpers read from the **current match** — the regex capture that triggered the current code block.

> **Worked example: entry versus local match.** A no-regex top dispatcher enters an
> ordered child rule through the first slot (`name`) and the child returns from a
> later local slot (`Alpha`):
>
> ```text
> demo::
>  -> value .push
>  LX { return(copy(demo)) }
>
> value:AND
>  /(?<head>name)/
>  /\s*=\s*/
>  /(?<value>[A-Za-z_]+)/
>  -> value[1] {
>    eq = match_text()
>  }
>  -> value[2] {
>    return(hash(
>      "entry_text", entry_text(),
>      "entry_named", entry_named(head),
>      "entry_groups", entry_groups(),
>      "entry_map", entry_map(),
>      "entry_start", entry_start_pos(),
>      "entry_end", entry_end_pos(),
>      "local_text", match_text(),
>      "local_named", match_named(value),
>      "local_groups", match_groups(),
>      "local_map", match_map(),
>      "local_start", match_start_pos(),
>      "local_end", match_end_pos(),
>      "separator", trim(eq)
>    ))
>  }
> ```
>
> Input `name=Alpha` returns
> `[{"entry_end":4,"entry_groups":["name"],"entry_map":{"head":"name"},"entry_named":"name","entry_start":0,"entry_text":"name","local_end":10,"local_groups":["Alpha"],"local_map":{"value":"Alpha"},"local_named":"Alpha","local_start":5,"local_text":"Alpha","separator":"="}]`.
> The `entry_*` helpers read the match that entered `value` (the first slot, `name`);
> the `match_*` helpers in the final action read the current local slot (`Alpha`).

### `entry_text()`
- **Signature**: `entry_text()`
- **Returns**: scalar
- **Behavior**: Full text matched by the current match entry.

### `entry_group(index)`
- **Signature**: `entry_group(index: int)`
- **Returns**: scalar or undef
- **Behavior**: Numbered capture group by 0-based index over the **captured groups**.
  Index `0` is the **first** capture group (not the whole match — read the whole match
  with `entry_text()`). The list is **compacted**: capture groups that did not participate
  in the match are omitted, which shifts the indices of the groups that follow. Returns
  `undef` for an out-of-range index. See [Regex in `.spec`](../user-model/regex-in-spec.md#capture-groups).

### `entry_groups()`
- **Signature**: `entry_groups()`
- **Returns**: array (flat list of all captured groups, compacted — see `entry_group(index)`)

### `entry_named(name)`
- **Signature**: `entry_named(name: string)`
- **Returns**: scalar or undef
- **Behavior**: Named capture group. Returns undef if the group does not exist.

### `entry_has(name)`
- **Signature**: `entry_has(name: string)`
- **Returns**: integer `1` or `0`
- **Behavior**: Returns `1` if the named capture group exists in the entry match, else `0`.

### `entry_map()`
- **Signature**: `entry_map()`
- **Returns**: hash
- **Behavior**: All named capture groups as a hash (name → value).
- **Compatibility**: `entry_named_map()` is a retired alias.

### `entry_len()`
- **Signature**: `entry_len()`
- **Returns**: int
- **Behavior**: Length of the matched text.

### `entry_start_pos()`, `entry_end_pos()`
- **Signature**: `entry_start_pos()`, `entry_end_pos()`
- **Returns**: int
- **Behavior**: Absolute start/end positions in the input.

### `entry_end_line()`, `entry_end_col()`
- **Signature**: `entry_end_line()`, `entry_end_col()`
- **Returns**: int
- **Behavior**: Line number and column of the match end position.

### `match_text()`, `match_group(index)`, `match_groups()`, `match_named(name)`, `match_has(name)`, `match_map()`, `match_len()`, `match_start_pos()`, `match_end_pos()`
- Same semantics as their `entry_*` counterparts but for the **local match** (the immediate regex match inside a code block, which may differ from the rule's entry match in nested contexts).
- If no local match exists, text/group/named/length/start/end values are `undef`, `match_groups()` is `[]`,
  `match_map()` is `{}`, and `match_has(name)` is `0`. Line and column readers retain their 1-based default of `1`.
  A real zero-width local match is different: its text/capture may be empty, but its length is `0`, its positions
  are the actual (possibly zero) offsets, and a present named empty capture makes `match_has(name)` return `1`.

## 9. Input Helpers

> **Worked example.** Input helpers read the whole input, not the current cursor,
> entry match, or local match:
>
> ```text
> demo::
>  -> value .push
>  LX { return(copy(demo)) }
>
> value : /.+/
>  I {
>    return(hash(
>      "text", input_text(),
>      "len", input_len(),
>      "slice", input_slice(1, 2),
>      "line", input_end_line(),
>      "col", input_end_col()
>    ))
>  }
> ```
>
> Input `abcd` returns `[{"col":5,"len":4,"line":1,"slice":"bc","text":"abcd"}]`.

### `input_text()`
- **Signature**: `input_text()`
- **Returns**: scalar
- **Behavior**: Returns the entire current input as a string.

### `input_slice(start, len)`
- **Signature**: `input_slice(start: int, length: int)`
- **Returns**: scalar
- **Behavior**: Returns a substring of the current input from `start` for `length` characters.

### `input_len()`
- **Signature**: `input_len()`
- **Returns**: int
- **Behavior**: Total length of the current input.

### `input_end_line()`, `input_end_col()`
- **Signature**: `input_end_line()`, `input_end_col()`
- **Returns**: int
- **Behavior**: Line/column of the last character in the input. Computed without storing explicit marks.

## 10. Call Expression

### `call(child_rule)`
- **Signature**: `call(rule_name: bare rule-label token)`
- **Returns**: the child rule's return value
- **Behavior**: Invokes a child rule directly from action code and returns its result. Used for nested parsing delegation.
- **Edge cases**: The child rule must exist and be a valid body rule in the same `.spec` file. Use the bare
  rule label (`call(child)`), not a quoted string: current runtimes resolve the target from the raw action
  argument token. Inside an action edge, calling that edge's current target reads the one cached selected-child
  result; it does not launch a second child search or permit a later fallback dispatch. A body-less passive
  terminal has already been consumed by the parent dependency match, so its cached result is undefined/null and
  the child is not re-searched. Calling a different rule name remains an ordinary independent call.
- **Worked example**:
  ```text
  demo::
   -> child {
     retv = call(child)
     return(hash("child", retv, "len", length(retv)))
   }

  child: /(\w+)/
   I { return(uppercase(entry_text())) }
  ```
  Input `abc` returns `{"child":"ABC","len":3}`. The top action calls `child`, stores the child return in
  `retv`, and returns a hash directly; this example does not use the top accumulator wrapper. The `-> child`
  edge selects `child`, and `call(child)` consumes that selected result exactly once.

## Cross-Cutting Contracts

### Composition Guarantee
Pure value helpers support **unlimited nested composition**. Example:
```
count(drop_front(sorted_keys(merge_hash(copy(base), overlay))))
```
Any portable pure helper that accepts an array can receive the output of an array-returning helper. Any
portable pure helper that accepts a scalar can receive the output of a scalar-returning helper. Hash-consuming
helper argument slots accept bare harray working variables as snapshots, including both arguments of
`merge_hash(base, overlay)`. `copy(base)` is optional explicit-copy composition; removed single-name aggregate-
selector syntax is not a required type marker. Array-consuming helper argument slots likewise accept bare
array working variables as snapshots, so `count(drop_front(sorted(items)))` is portable. Array receiver-dot
value chains are the same composition written from the receiver side, so
`items.sorted().drop_front(2).first()` and `items.filter_match(/^a$/).count()` are portable. Hash receiver-dot
value chains apply the same rule to hash helpers, so
`meta.set_key("stage", "normalized").sorted_keys().join_values(",")` is portable and pure. String receiver-dot
chains apply the same rule to scalar string helpers, so `raw.trim().lowercase().substr(0, 12)` is portable,
and `raw.trim().split("-").lowercase_each().join_values("_")` bridges explicitly into the array family. Bare typed
bindings are accepted anywhere the helper contract admits the runtime value kind; quoted strings are literal
constructor payloads, not aliases or indirect lookup. Mutation statement forms remain available, and assignment/mutation operators also have
expression values where documented: `name = value` yields the stored value, `items += value` yields the updated
array snapshot, and `name[key] = value` yields the updated typed-root snapshot. Array end mutations likewise yield an
independent updated array and can continue through compatible receivers. Inline value `if`/`switch` is portable in the supported
value-consuming slots (`return(...)`,
assignment RHS, and fluent `.return(...)`), and its contract is the selected payload value rather than any
specific compatibility tag string.

### Receiver-Dot Method Families
Receiver-dot methods are available for the value families that have a typed receiver table:

- **String/scalar** receivers support pure string links such as `trim`, `lowercase`, `uppercase`,
  `replace_substr`, `rm_prefix`, `rm_suffix`, `substr`, `cat`, and `coalesce_nonempty`; `split(delim)`
  bridges to array chains; `length`, `starts_with`, `ends_with`, `contains_substr`, and `matches` are terminal.
- **Array/list** receivers support pure array links such as `copy`, `sorted`, `reversed`, `take`, `drop_front`,
  `slice`, `concat_arrays`, `split_each`, `trim_each`, `filter_nonempty`, `uniq`, and `filter_match`. Terminal
  links include `count`, `first`, `last`, `contains`, `index_of`, `is_empty`, `is_nonempty`, `join_values`,
  `sum`, `avg`, `median`, `range`, `min`, and `max`.
- **Hash** receivers support pure hash links such as `copy`, `merge_hash`, `set_key`, `rename_key`,
  `drop_keys`, `pick_keys`, and `flat_hash`; `sorted_keys` and `sorted_values` bridge to array chains; `count_keys`
  and `has_key` are terminal. Hash-tree traversal receiver methods `walk_leaves`, `map_leaves`, and
  `reduce_leaves` are immediate block-bearing links with their own scoped callback bindings.
- **Array-tree traversal** uses the same block-bearing receiver method names on array-valued receivers, with
  Perl reference support from `SPEC-FORMAT-TERSE.13.2`, Rust/oracle parity from `SPEC-FORMAT-TERSE.13.3`, and
  Dart/Julia/Lua parity. Lua's shared root-kind proof passes 114/114 on both ABIs.
- **Number** receivers support terse numeric links such as `abs`, `floor`, `ceil`, `round`, `add`, `sub`, `mul`,
  `div`, `mod`, `clamp`, `min`, and `max`; `eq`, `ne`, `gt`, `ge`, `lt`, and `le` are terminal numeric
  comparisons.

Booleans and flow-result values are terminal today. Expression-valued blocks and pure user-function returns do not
have separate method tables: the yielded runtime value selects the compatible family above. Mutation forms,
lifecycle/control helpers, parser-state readers (`entry_*`, `match_*`, capture/input/mark helpers), declaration
helpers, and child-dispatch calls remain function, statement, or lifecycle surfaces unless a future task explicitly
adds type-correct receiver semantics.

### Fluent / Block Equivalence
For the locked ordinary helper families, structured-block form (`I { name = value }`) and compact
lifecycle-marker fluent-chain form (`I.set(name, value)`) produce the same behavior. Receiver-fluent
`when/otherwise` block chains are portable on action-edge and lifecycle-marker surfaces, and no-arg
action-edge `.push` / `.return(expr)` continuations are portable too. Explicit/flow action-edge chains beyond
that subset remain a separately locked surface.

### Undef Propagation
Most helpers propagate `undef` from their inputs to their outputs. Explicit `coalesce(...)` is the canonical way to provide a default. No helper silently converts `undef` to `0` or `""` unless documented otherwise.

### No Mutation Guarantee
Value and receiver forms that return arrays or hashes (`copy`, `merge_hash`, value-form `set_key(hash_expr, key, value)`, `rename_key`, `drop_keys`, `pick_keys`, `sorted_keys`, `sorted_values`, `map_leaves`, `drop_front`, `drop_back`, `take`, `take_last`, `slice`, `sorted`, `reversed`, `concat_arrays`, `filter_nonempty`, `filter_match`, `uniq`, `split`, `split_each`, `trim_each`, `lowercase_each`, `uppercase_each`) do **not** mutate their inputs. They return new containers. A standalone `split_each(name, delimiter)`, `trim_each(name)`, `filter_nonempty(name)`, `filter_match(name, regex)`, `lowercase_each(name)`, `uppercase_each(name)`, or `uniq(name)` call is a statement form and writes its result back to that explicit working array on the Perl reference and Lua backend. Rust, Dart, and Julia currently omit write-back for `split_each`, `filter_match`, and `uniq`; `FUTURE-PARITY-BACKLOG.5` owns repair. `walk_leaves` is the explicit tree side-effect traversal: it returns the original hash or array tree and preserves ordinary callback side effects. On all five backends, `binding.map_leaves!() { block }` is the distinct atomic receiver-rebinding traversal. Other explicit mutation forms include `name = value`, `items += value`, `items.push_back(value)`, `items.push_front(value)`, `items.pop_back()`, `items.pop_front()`, `set_key(name, key, value)`, and `name[key] = value`.

### Canonical Terse Forms
The `.spec` format has migrated these helper families to terser spellings. The **terse spelling is canonical**:

| Canonical form | Related form | Notes |
|---|---|---|
| `set(target, value)` | `target = value` | typed value assignment. Both spellings bind scalar, array, harray, or codeblock RHS values and yield the stored value in value positions. A bare source `set(out, name)` reads `name`. |
| `name = value` / `=(name, value)` | `set(name, value)` / `name = value` | assignment expression/operator spelling. It stores the target and yields the stored typed value in value positions. |
| `items += value` | `push(items, value)` | array append operator. A bare RHS reads a scalar working variable; all-bare `push(A,B)` remains child-call syntax; in value positions it yields the updated array snapshot. |
| `items.push_back(value)` / `items.push_front(value)` / `items.pop_back()` / `items.pop_front()` | `items += value` for back append only | named array end mutations. They mutate a bare array binding and evaluate to an independent updated snapshot; pop methods discard the removed value. |
| `meta[key] = value` | `set_key(meta, key, value)` for explicit harray intent | typed-path assignment operator on all five backends (string→harray, nonnegative integer→array). Bare key/RHS identifiers read scalar working variables; value positions yield the updated root snapshot. |
| `payload["items"][0]["name"] = value` | direct nested access assignment | mutates a scalar-held array/harray path. All five backends create absent/unambiguous missing containers from evaluated string/integer selectors. Wrong kinds are never coerced and array gaps remain invalid. |
| `cat(args...)` | string value expression | String concatenation through the portable scalar-to-text contract: strings unchanged, booleans `1`/`0`, stable finite decimal text (`-0.0` → `0`, `1.0` → `1`), and null for any null/array/harray/codeblock argument. Retired `concat` remains unsupported. |
| `copy(container)` | array/harray snapshot | one unified `copy(...)` dispatches from the current runtime value kind. |

Direct nested access, for example `payload["children"][0]["name"]` or `payload["children"][i]["name"]`, is
also part of the terse surface. It is not a helper rename; it is the replacement surface for the older nested
path helper spelling. For reads, quoted segments are hash keys and bare path atoms such as `[i]` read scalar
working variables. As a lvalue on any backend, every segment is instead classified from its evaluated value kind.
A direct nested path mutates a scalar-held array/harray value tree with the vivifying rules described above.

The current helper aliases above lower within their supported statement/helper families. Assignment forms
(`set(...)`, `name = value`, and `=(name, value)`) now compose as value expressions when the
target receives a scalar, array, or hash RHS value. Mutation assignment operators also compose as value
expressions: `items += value` yields the updated array snapshot and `meta[key] = value` yields the updated typed-root
snapshot. Typed path failures throw exact diagnostics on every backend.
Array end mutations yield updated arrays too; pop methods still discard the removed element.
Value-producing helper aliases such as `cat(...)` and `copy(...)` compose in the value positions documented by
their contracts. New `.spec` authoring should prefer the terse names.

### Removed Helper Spellings

This catalog intentionally lists the current helper surface only. Deleted helper spellings are not contract
entries, not canonical ActionIR events, and not compatibility lowering paths. Update old specs to the current
forms documented above.
