# Value, Container, and Flow Helper Reference

This chapter is the public reference for LinkedSpec's value, container, array-pipeline, predicate, and structured-flow helper family.

Read [Values, Containers, and Flow Helpers](values-containers-and-flow-helpers.md) first if the mental model is still new. That chapter explains the style. This chapter is for authors who are writing `.spec` action blocks and need exact helper choices, rationale, and examples.

The design goal is simple: rule actions should say what parser-facing value they are building instead of hiding that intent inside host-language Perl fragments. A reader should be able to see "copy this array", "normalize this scalar", "append this child result", or "branch on this parser predicate" directly from the helper name.

## Where value helpers compose

Most value helpers return one expression. They become useful when they are placed inside a statement or another helper that consumes values.

| Site | Shape | Use it when |
| --- | --- | --- |
| Working-variable initializer | `name = expr` / `items = []` / `meta = {}` | a working variable should start with one explicit scalar, array, or hash value. |
| Assignment | `set(target, source)` / `target = source` | an existing working value should be replaced. |
| Array append | `items += expr` / `push(target, expr)` | one explicit value expression should be appended without replacing the whole array. |
| Hash field assignment | `meta[key_expr] = expr` / `set_key(name, key_expr, expr)` | one field of a named working hash should be updated in place. |
| Return payload | `return(payload)` | the rule should return one structured value. |
| Predicate | `if(condition)` / `elseif(condition)` | helper logic should drive control flow. |
| Switch driver | `switch(value)` | one value should drive equality cases. |
| Constructor payload | `array(...)` / `hash(...)` | nested values should become one array or hash payload. |

Input/cursor readers yield scalar values. On ordinary Perl, their values can be passed as explicit pure-function arguments; calling these parser-state readers inside a pure function is unsupported and keeps that call unready. Ordinary Perl, Rust, Dart, Julia and Lua (available PUC5.5.1/LuaJIT) enforce this boundary for catalogued entry/match group, Array/Hash capture, mark and cursor helpers, including compatibility spellings: `fn bad(){return(entry_groups())}` is unready in Perl and raises an unsupported parser-state-helper runtime error in Rust/Dart/Julia/Lua, while `fn upper(text){return(text.uppercase())}` with `upper(entry_group(0))` reads the capture explicitly in the caller. Nested calls and discarded helper results retain this boundary; similarly prefixed user functions such as `entry_custom(text)` remain valid. Ordinary Perl, Rust, Dart, Julia and Lua (available PUC5.5.1/LuaJIT) support direct defaults and inter-type flow: `input_text().coalesce("fallback").split("=")[-1].uppercase()` selects the final field, and `input_len().coalesce(0).add(1)` preserves a Number result. Empty String and zero are defined, so their fallback operands stay skipped. Array/Hash-only consumers reject scalar results before their operands. Source arguments run once in order, before later consumers. A scoped block can change the kind: `input_text().with() {return(["a","b"])}.last().uppercase()` yields `"B"`; the outer `value` binding is restored. Named readers remain equivalent; source signatures/bounds/cursor rules, deferred vocabulary and declared Lua5.4/full-admission checks keep their owners. Scalar working variables are read with bare names such as `name`. Use that spelling when a payload should
visibly come from the working variable named `name`:

```text
set(value, "ok");
set(payload, [value]);          # payload now holds the array value [value]
return(array(value, payload));
```

Bare direct-shape assignment binds the shape as the variable's typed value. `set(payload, [value])`
stores the whole array value in `payload`; `payload = [value]` is the operator spelling for the same binding.

Example:

```text
Top::
 -> Token .push
 LX { return(copy(Top)) }

Token: /(\w+)/
 I {
   text = lowercase(trim(entry_group(0)));
   return(hash(
     "kind", "token",
     "text", text,
     "text_length", length(text)
   ));
 }
```

That rule keeps each concern explicit:

- `entry_group(0)` reads the match group.
- `trim(...)` removes boundary whitespace.
- `lowercase(...)` normalizes case.
- `text = ...` names the intermediate scalar value.
- `return(hash(...))` returns one structured payload.

## Per-rule default accumulator convention

Each generated rule handler starts with one rule-local array named after that rule. A rule named `Parent` has a fresh `@Parent` array for that handler invocation; a rule named `logging_annotation` has `@logging_annotation`; a rule named `sub_gui_list` has `@sub_gui_list`.

This is a convention, not global state. The array is local to the generated handler call and starts empty for that call. It exists so simple accumulator rules do not need to declare a separate array just to collect repeated child results.

The current helper surface uses that convention in these implicit child-call forms:

```text
push(Child)
push(Child, 1)
```

Read those as:

```text
# inside rule Parent
push(Child)     # append call(Child) into @Parent
push(Child, 1)  # append call(Child)->[1] into @Parent
```

LinkedSpec standardizes child-call appends on `push(...)`: the first argument is the child rule being called, the optional second bare-word argument is the target array, and a numeric final argument selects one indexed element from the child return.

Use implicit `push(Child)` and `push(Child, index)` as statements. Their append behavior is portable, but their
expression results are not yet: Perl currently exposes the host push count, while Lua exposes the updated implicit
accumulator. Explicit-target child push returns the updated target. `FUTURE-PARITY-BACKLOG.5` owns normalization.

Use the convention when the rule itself is the natural accumulator:

```text
Parent::
 -> Child {
   push(Child)
 }
 LX {
   return(hash("kind", "parent", "children", copy(Parent)));
 }
```

If the accumulator has a domain name that is clearer than the rule name, use an explicit target instead:

```text
Parent:: I { children = []; }
 -> Child {
   push(Child, children)
 }
 LX {
   return(hash("kind", "parent", "children", copy(children)));
 }
```

Other modern helpers do not silently guess the current rule accumulator. They can still use it when you name it explicitly:

```text
push(Parent, capture_slice());
parent_part = trim(capture_slice());
if(is_nonempty(parent_part)) { push(Parent, parent_part); }
set(Parent, array());
return(hash("children", copy(Parent)));
```

Some capture helpers also use this convention:

| Helper | Current-rule accumulator behavior | Modern direction |
| --- | --- | --- |
| `capture(label)` | appends the anonymous capture slice into `@CurrentRule`; the label argument is compatibility syntax | prefer `push(CurrentRule, capture_slice())` or an explicit domain array |
| `capture_if(label)` | trims and conditionally appends the anonymous capture slice into `@CurrentRule`; the label argument is compatibility syntax | prefer `part = trim(capture_slice()); if(is_nonempty(part)) { push(CurrentRule, part) }` or an explicit domain array |
| `CAPTURE_IF()` | trims and conditionally appends the anonymous capture slice into `@CurrentRule` | prefer `part = trim(capture_slice()); if(is_nonempty(part)) { push(CurrentRule, part) }` |
For tagged aggregate returns, spell each payload part explicitly:

```text
return(array(
  "?generate_statement:",
  flat_array(entry_groups()),
  copy(generate_statement)
));
```

For new specs, prefer `push(...)` for child-call appends. Prefer explicit targets when there is any chance the reader would wonder which collection is being mutated.

### Historical convention audit

A June 2026 pre-migration audit of the then-20 shipped `.spec` files counted 88 accumulator operations. The table
preserves that historical evidence; its selector-wrapped rows are removed syntax, not current authoring examples:

| Form | Count | Share |
| --- | --- | --- |
| removed selector-wrapped `push` form | 63 | 71.6% |
| Fluent `.push(…)` with explicit target | 19 | 21.6% |
| explicit `is_nonempty(...)` guard + removed selector-wrapped `push` form | 2 | 2.3% |
| Convention-based `push(Child)` | 4 | 4.5% |

**95.5% of accumulator operations already use explicit targets.** The four remaining convention-based uses (across `regdef`, `tkgui`, and `ebnf`) are idiomatic — the rule name is the clearest name for the collection.

**Bottom line:** the per-rule default accumulator is a deliberate framework design choice, not migration debt. `push(...)` is the preferred explicit spelling for new `.spec` code, and the convention-based `push(Child)` remains fully supported when the rule IS the natural accumulator.

## Containers and accessors

These helpers are the entry point into local working state and structured values.

> **Working variables auto-exist.** A bare `name` reads its current scalar, array, harray, or codeblock value.
> `set(name, value)` and `name = value` bind the evaluated typed RHS; `push(name, value)` / `name += value` mutate
> an array; `set_key(name, key, value)` / `name[key] = value` mutate an harray; and `copy(name)` snapshots a
> container. Exact `array(IDENTIFIER)` and `hash(IDENTIFIER)` are removed language forms and must not be introduced in `.spec`
> code. All five backends reject them before execution and execute the bare replacement contract. All tracked
> source has migrated. Quoted/computed constructor calls such as
> `array("items")` and valid key/value `hash("key", value)` remain ordinary values. See
> [Working Variables and Setup](declaration-helper-reference.md#auto-existing-variables).

> **Primitive literals are typed values.** Quoted strings (`"text"` or `'text'`), numbers
> (`42`, `3.14`), `true`, `false`, and `undef` can be used anywhere an explicit value
> expression is accepted: returns, constructor payloads, assignment RHS values, append RHS
> values, hash keys/values, and flow predicates. `true` and `false` are JSON booleans when
> returned or placed in containers, not the strings `"true"` and `"false"`; `undef` serializes
> as JSON `null`. Literal matching is exact, so names like `trueword` and `undefine` remain
> identifiers; in supported scalar source slots they are working-variable names, not booleans
> or `undef`.

Examples:

```text
return(array(true, false, "ready", 42, undef));
flag = true;
items += false;
push(items, true);
meta["enabled"] = true;
if(false); return("unreachable"); else; return("reachable"); endif
```

### Regex patterns and variable values

Regex is not a separate builtin variable type in the shared value model. A slash-delimited pattern is supported as an operand of regex-aware helpers:

```text
return(matches("abc", /b/));
return(split("a,b", /,/));
return(["ax", "by"].filter_match(/^a/));
```

A pattern can also be kept as a string for a helper that accepts a string pattern:

```text
pattern = "b";
return(matches("abc", pattern));
```

The variable holds a string and `matches` returns a scalar truth result. Do not use `pattern = /b/` to create a portable reusable regex object: no such value contract is defined. Current Perl evaluates that standalone expression as a match against its implicit host subject; Rust evaluates it to the pattern string. Parser recognition of regex syntax does not make those behaviors equivalent.

Legacy Perl raw assignments preserve a complete multiline slash payload when its first physical line is an incomplete raw expression. LF/CRLF, escapes and character classes remain authored; helper-looking pattern text does not execute DSL effects. For example, this matches an implicit host subject containing `14,2 }`, a newline and `tail`:

```text
rx = /(14,2) \}
tail/; return(rx)
```

A complete first-line DSL expression keeps its existing boundary: `out = /(14,2)` followed by a newline computes `7`; it does not become a multiline pattern. Other bootstrap validation exclusions remain unchanged.

Perl callable bodies now execute this same helper with literal and string patterns:

```spec
Top:: I { cb={|| return(matches("abc",/b/)) }; return(cb()) }
```

Native and independently loaded emitted parsers return numeric `1`; the no-match
counterpart returns numeric `0`. A caller pattern binding or copied pattern parameter
also works. Literal `i`, `m`, `s`, `x` and `g` comparisons are covered by the matched
public regression; physical multiline subjects avoid the separate string-escape drift.

The subject evaluates once first. An undefined subject returns `0` and skips the
pattern operand, including its effects. Otherwise the pattern evaluates once after
the subject. Wrong arity rejects before operand work. Invalid dynamic patterns retain a typed `invalid_matches_pattern` error with the regex reason and operand source span; failures restore actual caller parameter slots. The helper takes precedence over a same-named callable variable. Literal handling is limited to this pattern position: returning a bare regex from a deferred body still raises `unsupported_codeblock_actionir`/`regex`, without adding a regex value type.

The [Perl integration guide](../public-api/integration-perl.md#regex-and-division-in-action-code)
also gives working multiline match/substitution patterns and quoted subjects,
generated-parser coverage, grouped-pattern support, and the remaining
string-escape limitation.

### Composite values

> **Shape literals are value expressions on the Perl reference and Rust backend.** Direct array and hash literals are
> accepted in value positions: `[]`, `[value, cat("a", "b")]`, `{ key : value }`, and nested combinations.
> Shape members lower through the same scoped DSL value-expression rules as the surrounding site: primitive
> literals stay typed, recognized helpers compose, direct access keeps its own bracket rules, and non-reserved
> bare names read scalar working variables. A direct hash key is any accepted value expression before the
> top-level `:`. A bare hash key is therefore dynamic (`{ key : value }` reads working value `key`), and a helper expression
> such as `{ cat(prefix, suffix) : value }` uses the helper result as the runtime key. Quote fixed field names
> (`{ "kind" : value }`). When a direct shape literal
> is the RHS of a bare assignment target, the array or hash is stored as the variable's typed value on both
> variants: `items = [value]` / `set(items, [])` bind array values, and
> `meta = { key : value }` / `set(meta, {})` bind hash values. In value positions, direct-shape assignments yield
> the stored typed value.

On Perl and Rust, whitespace around the hash-pair colon is optional:
`{key:value}` and `{ key : value }` evaluate the same key and value expressions.
An adjacent colon does not turn a bare key into a fixed field name; quote fixed
names. Portable binding names use ASCII letters, digits and underscores, with a
letter or underscore first. Key values may contain Unicode text.

This shared example returns a dynamic field, a quoted field, and a nested computed
key when given input `x`:

```text
{{#include ../../../../examples/compact-hash-keys.spec}}
```

```json
{"stage":7,"fixed":"stage","é🦀":{"stage_nested":7}}
```

The example source is exercised directly by the Perl native/generated tests and
the Rust emitted-source test. Recompile saved or generated parsers after updating
the Rust compiler to pick up parser fixes.

Single-level reads such as `items[0]` use the current typed array binding on Perl
and Rust. This applies after assignment, `set`, append, and split, including a
later replacement of the binding. Perl and Rust support existing-position tail reads such as `items[-1]`; see [signed selectors](values-containers-and-flow-helpers.md#signed-array-selectors-in-perl-and-rust). Use nonnegative integer indexes for portable
array reads; a bare index variable or an expression such as `items[add(0,1)]`
selects an element too. An out-of-range element is `undef` (JSON `null`).

<a id="read-purity"></a>

The read contract forbids creating missing containers; the stricter typed write-path
rules below govern assignments through brackets.

On Perl, direct reads now preserve absent roots, null values, missing children,
and wrong-kind containers. They return `undef` (JSON `null`) without creating or
replacing a container, changing binding presence, or copying a selected container.
The following executable example also checks that a read of an absent binding
leaves it available for a later write to create the required harray:

```text
{{#include ../../../../examples/direct-read-purity.spec}}
```

With input `x`, it returns:

```json
{"tree":{"present":["kept"],"null":null},"missing":null,"null_child":null,"wrong_kind":null,"absent":null,"document":{"created":"write"},"null_root":null,"null_read":null,"present":"kept"}
```

Perl native and fresh-process generated parsers execute this exact source with
LF and CRLF line endings. Regenerate saved Perl parser source to pick up the repair.

Perl evaluates the base once and retains each observed container while evaluating
its selector. Selectors run once from left to right, including after an earlier
missing or wrong-kind segment; a selector exception stops the read and propagates.
Authored selector side effects still occur. For example,
`document[set(document, ["new0", "new1"]).count()]` over
`document = ["old0", "old1", "old2"]` selects `"old2"` and leaves the binding
as `["new0", "new1"]`, whether or not another binding retains the old array.
This order is Perl-specific. For portable code, evaluate effectful selectors
before the read and use nonnegative integer array indexes.

This executable example selects elements, saves a detached array value, replaces
the original binding, and uses an element as a computed hash key:

```text
{{#include ../../../../examples/indexed-value-reads.spec}}
```

With input `x`, it returns:

```json
{"first":"first","selected":"second","snapshot":["saved"],"current":"rebound","missing":null,"rebound":7}
```

Perl native/generated and Rust native/emitted tests execute this exact source.
Regenerate and rebuild emitted Rust parsers with the updated runtime to pick up
the indexed-read repair.

> **Expression-valued blocks are receiver-capable value expressions.** A non-empty block without a top-level
> hash-pair delimiter can feed a compatible receiver-dot helper chain. The yielded value enters the normal helper family
> selected by the method being called: `{ [3, 1, 2] }.sorted().join_values(",")` uses the array family,
> `{ " a-b " }.trim().split("-").count` uses string helpers and the explicit `split` array bridge,
> `{ { "b" : 2, "a" : 1 } }.sorted_keys().join_values(",")` uses hash then array helpers, and
> `{ 3.5 }.floor().add(2)` uses the number family. `return(expr)` inside the block is still block-local.

| Helper | Result | Use it when |
| --- | --- | --- |
| `name` | scalar value | read the working scalar `name`. |
| `items.drop_front(index).first` | stored value or `undef` | read one zero-based element from an array value. |
| `meta.pick_keys(key).sorted_values().first` | stored value or `undef` | read one field from a hash value. |
| `base["field"][0][i]` | scalar value or `undef` | read a nested hash/array path directly from a working scalar container; a bare path atom such as `[i]` reads scalar `i` as an array index. |
| `array(...)` | array value | construct an empty or argument-list array payload; prefer `[...]` as the terse constructor spelling in new examples. |
| `hash(...)` | hash value | construct an empty or multi-argument hash/object payload from key/value pairs or flattened hashes; use `{ "key" : undef }` for a one-field literal hash with no value. |
| `[]` / `[expr, ...]` | array value | construct one new array payload with direct literal syntax. |
| `{ key_expr : value_expr, ... }` | hash value | construct one new hash/object payload with direct literal syntax; key expressions are evaluated and stringified at runtime, so quote fixed field names. |
| `copy(array_expr)` / `copy(name)` | array value | snapshot an array value as one nested payload. A bare name reads the working array of that name. |
| `copy(hash_expr)` / `copy(name)` | hash value | snapshot a hash value as one nested payload. A bare name reads the working hash of that name. |

Use bare `name` for typed access and `array(...)` / `hash(...)` only for retained constructor shapes.

### Array constructors inside functions

`array(value, value)` reads the current parameter or local value twice, just as
`[value, value]` does. Strings stay strings, `undef` stays null, and container
arguments remain nested values. Quotes make an identifier spelling literal:
`array("value", value)` contains the word `"value"` followed by the bound value.

This complete example runs on the Perl reference and its fresh generated parsers:

```text
{{#include ../../../../examples/function-array-values.spec}}
```

On input `x`, the result is:

```json
[[7,7],["tag","x",["x","x"]],[null,null]]
```

The function-local assignment is separated from `return(...)` by its newline;
a line-ending `;` is optional and valid. See [statement separators](fluent-and-block-forms.md#statement-separators).
For one bare value, use `[value]`: exact `array(value)` remains removed selector syntax. A separate current
Perl constructor defect makes `array(3)` return `[]`; use `[3]` for a single numeric
literal. The constructor repair is tracked under `SESSION-STARTUP-READING.94`;
multiple numeric arguments such as `array(3,1,2)` work.

### Nested values in hash constructors

A value argument to `hash(...)` can combine bindings, shape literals and helper results:

```text
value = 7
return(hash("items", [value, trim(" x ")], "detail", {"kept":value}))
```

This returns `{"items":[7,"x"],"detail":{"kept":7}}`. The unquoted `value` reads its
binding even beside a helper call; `"value"` would be literal text. The same rule
applies to function parameters and locals, preserving nulls, booleans and nested containers.
Perl native and fresh emitted parser regressions cover this composition and recursive source spans.
The [bounded nesting example](../architecture/structured-format-program.md#bounded-nesting-trial)
uses this form to record each list's opening and closing positions.


In scalar value positions, a bare scalar name reads the working variable:
`return(count)`, `set(out, count)`, `out = count`, `if(count, ...)`,
`num_lt(count, 5)`, and `switch(kind, ...)` read the current working scalar. Mutation slots use the
same scalar read for array append RHS and hash mutation key/RHS positions: `items += value`,
`set_key(meta, key, value)`, and `meta[key] = value` read `$value` / `$key` where those slots are scalar-valued.
Direct path atoms use the same scalar read rule when the atom is not a primitive literal or engine local. Switch
case labels are the deliberate exception: `case(foo)` is a literal tag named `foo`; write a quoted tag for fixed
labels and a value expression such as `case(cat(foo, ""), body)` when the case value must be read dynamically.

> **Terse spellings (canonical going forward).** The `.spec` format is migrating to terser helper
> names: use `set(target, source)` or `target = source` for assignment, `cat(...)` for concatenation,
> and a single unified `copy(container)` subsumes the former array-copy and hash-copy helpers by dispatching from
> the current runtime value kind. The assignment operator `name = value` is equivalent to `set(name, value)`; in value
> positions it yields the stored typed value. The
> array append operator `items += expr` is equivalent to the explicit
> append form `push(items, expr)`; when the value is a working variable,
> `items += value` reads that typed value, and in value positions the expression yields the updated array snapshot.
> The typed-path operator `meta["key"] = expr` has the same field-update effect as
> `set_key(meta, "key", expr)` on all five backends, but it is not the same runtime contract: its evaluated string selector
> chooses harray, while a nonnegative integer chooses array. `meta[key] = value` reads working values `key` and
> `value`, and in value positions yields the updated root snapshot.
> Direct nested access `payload["children"][0]["name"]` is accepted for mixed path segments.
> Reads retain their existing direct-access interpretation and never create state; see [read purity](#read-purity). For assignment on all five backends, every
> bracket is an ordinary expression whose evaluated value selects the path kind: string means harray and
> nonnegative integer means array. Non-reserved bare path atoms such as `[i]` read scalar working variables.
> The same path can be an assignment target: `payload["children"][0]["name"] = value` mutates the
> scalar-held array/harray value. All five backends create an absent root and missing intermediates when the
> selector kind determines their shape; bound null and wrong kinds are conflicts, and arrays remain dense.
> Structural failures throw typed diagnostics and commit no partial path.
> Direct shape literals `[]` and `{ key : value }` are accepted as value expressions on the Perl reference and
> Rust backend. Bare elements/keys/values inside the shape read scalar working variables, and fixed hash field
> names should be quoted. Direct shape literals bind as typed values for bare assignment targets on both variants:
> `items = [value]` / `set(items, [value])` store an array value, and `meta = { key : value }` /
> `set(meta, { key : value })` store a harray value. In value positions, assignment yields the stored value.
> Current examples use only the terse spellings.
> See the
> [Helper Contract Catalog](../appendix/helper-contract-catalog.md#terse-helper-renames-canonical-going-forward).

### Copying a container stored in a scalar on Perl

On Perl, a single receiver `.copy()` on a bound working variable preserves its runtime container type, just like `copy(name)`. A hash stays a hash, including an empty hash; an array stays an array, including an empty array.

```text
meta = { "k": "v", "nested": [1, 2] };
empty_hash = {};
items = [1, 2];
return([meta.copy(), empty_hash.copy(), items.copy()]);
```

The returned value is:

```json
[{"k":"v","nested":[1,2]}, {}, [1,2]]
```

The copy creates a new outer container. Nested array and hash references remain shared with the original, matching Perl's function-form `copy(name)` semantics. Changing an outer entry of the snapshot therefore leaves the original outer container alone; changing a shared nested container can affect both. Ordinary `copy(value)` on Perl, Rust, Dart, Julia and the tested Lua hosts preserves Bool, Number, String and null: `copy(false)` stays false, `copy(0)` stays numeric zero, `copy("0")` stays text and `copy(undef)` stays null. A missing binding supplies null. The source runs once; `copy(false).cat("!")` yields `"0!"`, while `copy(false).take(effect)` yields null without running `effect`. Copy is not a conversion. Ordinary `value.copy()` uses the same typed producer, including selected, block, function and prior-result values. For example, `and(false).copy()` is false, `num_add(1,2).copy().add(1)` is `4`, `" a ".trim().copy().uppercase()` is `"A"`, and `[].first().copy().coalesce([7]).first()` is `7`. Repeated `.copy()` preserves primitive kind. Extra receiver operands reject before source/operand effects, and original source errors propagate. Inside Perl explicit deferred callbacks, existing free `copy(value)` also preserves primitives/null; receiver `.copy()` remains unavailable there. That executor retains its existing recursive container copying and copied-callable recursion protection. Its wrong-Array `take` guard keeps its existing empty-array result and skips the count operand. Full portable admission remains separate.

Reading an uninitialized ordinary working value supplies null: `copy(items)` preserves null until `items` has a value. Initialize `items=[]` when an empty Array is intended, or `meta={}` for an empty Hash; copying preserves those distinct container kinds. Copying itself does not initialize an accumulator. Existing mutation operations establish their containers under the binding rules.

For a null binding `u`, `u.copy().count_keys()` returns null: the copied result is still null and cannot supply a Hash-only continuation. Direct `count_keys(u)` retains its existing zero result. An explicit Hash fallback, `u.copy().coalesce({}).count_keys()`, returns zero. Empty and filled Hash copies continue normally; copying a missing value does not manufacture an empty Hash.

On ordinary Perl, a canonical Count chain also keeps an earlier incompatible-consumer rejection
through `.copy()` and repeated copies. Copying cannot restart that chain through a default or
an immediate `with` block. A legitimate null result still permits both operations:

```text
count([]).copy().add(1)                                      # 1: zero stays Number
count([]).take(1).copy().coalesce([7]).first()                 # null: take rejects Number
count([]).count().copy().with(){return("ran")}                # null: body skipped
count([]).add("bad").copy().coalesce([7]).first()              # 7: valid numeric-domain null
count([]).add("bad").copy().with(){return("valid-null")}      # "valid-null"
```

The rejected consumer skips its operands and later defaults/bodies; completed source effects
remain. Source errors propagate, and copying preserves the captured Count result before later
operand effects. These ordinary checks do not extend deferred callback syntax or establish full
portable admission.

Canonical ordinary Perl copy results and zero-extra first copy prefixes now retain
that same rejection state. An incompatible consumer skips its operands and later
copies, defaults, logical operands and immediate `with` bodies:

```text
copy(["a"]).set_key("k",1).with(){return("ran")}       # null; body skipped
copy(["a"]).set_key("k",1).coalesce({"x":1}).count_keys() # null; fallback skipped
["a"].copy().set_key("k",1).with(){return("ran")}       # null; body skipped
copy(undef).with(){return("valid-null")}                # "valid-null"
copy(1).add("bad").coalesce(7)                          # 7; valid numeric-domain null
```

A valid copied null remains an ordinary input; it is distinct from a rejected
consumer. Empty copied Arrays also remain valid `with` inputs. Copy kinds, depth,
signatures and existing callback/deferred boundaries are preserved. Perl76.0 is
implemented with focused native/fresh and direct-dependent checks; regenerate
affected emitted Perl. Full source/context/portable admission remains separate.

Ordinary Perl also keeps that Count rejection through eager `.and(rhs,...)`,
`.or(rhs,...)` and `.not()` links, with or without copy or a final `with`:

```text
count([]).take(1).and(true).with(){return("ran")}     # null: logical operand/body skipped
count([]).take(1).copy().or(true)                     # null: copy does not restart rejection
count([]).add("bad").and(true).not()                 # true: legitimate null is false
count([]).and(true)                                  # false, a real Boolean
```

For a valid logical call, every operand still runs eagerly once from left to right,
even when Count is zero or an earlier numeric operation returned null. Operand
errors propagate. Malformed receiver shapes still reject before source effects.

Rust's ordinary Count source producer now follows the reference Array-only rule:
Arrays return their element count; accepted null, String, Hash, Number and Boolean
initial sources return Number0. Source expressions still run once and propagate
their errors. A copied or earlier produced receiver keeps its result-kind guard:

```text
count("text")                 # 0
"text".count()                # 0: initial source fallback
count(copy("text"))           # 0: explicit free Count source
copy("text").count()          # null: copied String cannot supply Array Count
count([]).count()             # null: prior Count result is Number
length("text")                # 4: general length still measures text
```

Regenerate/rebuild Rust applications using the runtime. These focused source and
copy checks keep full source/context/portable admission separate.

Initial Boolean Count sources in Dart and Julia also reach the same Number0 fallback. A
copied or previously produced Boolean retains its result guard:

```text
{false}.count().copy().add(1)                # 1
{true}.count().with(){return(value.add(1))}  # 1
copy(false).count()                         # null
and(false).count()                          # null
```

The initial source executes once, zero skips an unnecessary coalesce default,
and later incompatible consumers still skip their operands. Scalar-result state
and needed source errors are preserved. Rebuild Dart or Julia runtime/apps; full admission
remains separate.

A projected copy can be stored directly. On Perl, this returns the normalized three-field snapshot followed by the unchanged source:

```text
meta = {"kind":"token","source":"fixture","debug":1};
set(snapshot, copy(pick_keys(merge_hash(meta, hash("stage","normalized")), "kind","source","stage")));
return([snapshot,meta]);
```

```json
[{"kind":"token","source":"fixture","stage":"normalized"},{"kind":"token","source":"fixture","debug":1}]
```

The source expression runs once. Assigning another outer field in the snapshot leaves the source fields intact; nested-copy depth still follows the backend-specific rule above.

Examples:

```text
first_item = items.first();
kind = meta.pick_keys("kind").sorted_values().first();
content = retv["content"];
child_name = retv["children"][0]["name"];
dynamic_child_name = retv["children"][i]["name"];
set(snapshot, copy(items));
set(meta_snapshot, copy(meta));
set(field, "kind");
set(value, "token");
return({ field : value, "seen" : true, "parts" : [value, entry_text()] });
```

Use `binding[index]` or nested access for a working Array/Hash binding; older path helpers are retirement-bound.

Perl, Rust, Dart, Julia and Lua support brackets on fluent results, Array/Hash literals, immediate blocks, statically governed data-helper calls and registered function results. Lua's focused checks use available PUC5.5.1/LuaJIT; declared PUC5.4 verification remains open. String/Array/Hash value-method helpers, numeric/logical helpers and Array/Hash constructors reuse their existing source/signature rules. The source evaluates once, selectors run left-to-right, and selected values retain their kinds for compatible methods; `copy([false])[0]` remains false. Reads do not create storage; missing/out-of-range/wrong-kind entries yield undef. Selector assignments inside a function stay local. Perl's explicit deferred literals and registered contextual final blocks keep their previous call-result grammar and diagnostics. For example, a registered `fn apply(callback: codeblock) {return(callback())}` rejects `split("a,b",",")[0]` in `{|| return(...)}`, `apply() {return(...)}` and `apply({return(...)})` alike with `unsupported_codeblock_actionir` / `raw_perl`; its descriptor retains a raw dependency and reports unready. Bind the collection first and use its named read inside the callback, or perform computed selection in an ordinary action or immediate `.with()` block. A callback invoked inside a pure function sees that invocation's parameters and locals; pass required values explicitly. Unregistered bound calls retain their existing reader and result policies, including Rust/Dart/Julia/Lua count-on-missing behavior. Perl, Rust, Dart, Julia and Lua also support the existing readonly capture collection sources: `entry_groups()[-1].uppercase()`, `entry_map()["head"].split(/a/)[-1]`, `match_groups()[-1]` and `match_map()["value"]`, including accepted `entry_named_map()`/`match_named_map()` aliases. Entry and local registers stay distinct; empty captured text and String "0" retain their kinds. Missing paths still evaluate later selectors, and wrong-kind consumers reject before operands. Full capture-source/context admission, list splices, other context/control/rule helpers, grouping/writes and complete source/context/portable admission remain separate.

```text
split("aXb",/[x]/i)[1].uppercase()                # "B"
hash("items",["a","b"])["items"][-1].uppercase()    # "B"
fn entries() {return([" a "," b "])}
Top:: I {return(entries()[-1].trim().uppercase())} # "B" for input x
```

Example:

```text
retv = call(Child);
child_kind = retv["kind"];
first_child_name = retv["children"][0]["name"];
second_child_name = retv["children"][1]["name"];
dynamic_child_name = retv["children"][child_index]["name"];
```

Example write:

```text
payload = { "children" : [{ "name" : "old" }] };
payload["children"][0]["name"] = "new";
payload["children"][1] = { "name" : "second" };
return(payload);
```

## Constructors, snapshots, and flattening

The most important collection distinction is snapshot versus flatten.

| Helper | Meaning |
| --- | --- |
| `copy(items)` | produce one nested array payload containing the items. |
| `copy(meta)` | produce one nested hash payload containing the fields. |
| `flat_array(items)` | splice array items into the surrounding constructor. |
| `flat_hash(meta)` | splice hash key/value pairs into the surrounding constructor. |
| `flat(expr)` | generic flatten/splice helper for array or hash expressions, including inside direct `[...]` literals. |

`flat(...)` also accepts bound or computed containers, including function parameters and nested reads.
See the [complete flattening example](values-containers-and-flow-helpers.md#flattening-bound-and-computed-values)
for splicing, ordinary nesting, and empty-container behavior.

Snapshot example:

```text
return(hash(
  "kind", "list",
  "items", copy(items)
));
```

That returns one `items` field whose value is the array payload.

Flatten example:

```text
return(array("?node:", flat_array(items)));
```

That injects the array items directly into the returned array. The returned array does not contain a nested `items` array unless you explicitly ask for one with `copy(...)`.

Hash flattening is the same idea for key/value pairs:

```text
return(hash(
  flat_hash(meta),
  "stage", "normalized"
));
```

Use flattening when a surrounding `array(...)` or `hash(...)` is already the payload boundary and the existing collection should be opened into that boundary.

## Assignment, calls, appends, and returns

These helpers mutate or dispatch rule state. The assignment forms also have the value contracts noted below.

| Helper | Effect | Use it when |
| --- | --- | --- |
| `name = expr` | replace the named typed value | a working variable should hold the expression result, whether scalar, array, or hash. |
| `set(name, expr)` | replace the named typed value | a working variable should visibly hold the expression result, including direct shape payloads such as `[value]`. |
| `items += expr` | append one value and yield the updated array snapshot when used as an expression | a named array should grow by one explicit value expression; equivalent to `push(items, expr)` for accepted RHS shapes. |
| `meta[key_expr] = expr` | update one typed path and yield the updated root snapshot when used as an expression | on all five backends, an evaluated string selects harray and a nonnegative integer selects array; use `set_key` when harray-only intent must be explicit. |
| `call(rule)` | dispatch to another rule | a child rule should run and optionally provide a value. |
| `retv = call(rule)` | capture a child result | later helper logic needs the child payload. |
| `push(rule)` | call one rule and append its result | the shortest spelling is desired for appending a child result into the current rule accumulator. |
| `push(rule, index)` | call one rule and append one indexed result | one element from a shaped child return should go straight into the current rule's conventional array accumulator. |
| `push(rule, target)` | call one rule and append into a named array | a child rule result should go straight into an explicit array accumulator. |
| `push(rule, target, index)` | call one rule and append one indexed result into a named array | one element from a shaped child return should go straight into an explicit array accumulator. |
| `push(name, expr)` | append one value | an array should grow by one item. |
| `part = expr; if(is_nonempty(part)) { push(name, part) }` | append one meaningful value | empty captures or optional child results should be ignored instead of becoming payload items. |
| `set_key(name, key, value)` | set one hash field | a named working hash should be updated in place. |
| `return(payload)` | return one value | the rule should emit a structured result. |
| `return_undef()` | return `undef` | an optional rule branch has no value. |
| `next()`; Perl also accepts `next` | skip the current action path | comments or ignored delimiters should be recognized without adding to the current accumulator. |
| `exit_now(status)` | exit immediately with an optional status | a fatal parse-time diagnostic should stop execution after emitting its message. |

Nested lvalue paths use the same assignment surface on every backend. For example,
`document["sections"][0]["title"] = "Intro"` creates an absent harray/array/harray path, while an array write may
replace an existing index or append exactly at `length`. A larger index raises `nested_write_array_gap`; a bound
null, scalar, or other wrong-kind intermediate raises `nested_write_kind_conflict`. All segments evaluate once
left-to-right, then the RHS once, before isolated structural validation. Success publishes once and yields a
detached updated root. The read contract forbids creating containers; see the
[read-purity examples and Perl evaluation details](#read-purity).

Canonical child-result pattern:

```text
Parent::AND
 I { children = []; retv = undef; }
 Child
 -> Parent[0] {
   retv = call(Child);
   push(children, retv);
   return(hash("kind", "parent", "children", copy(children)));
 }
```

Direct child-accumulator pattern:

```text
Parent::
 -> Child {
   push(Child)
 }
 LX {
   return(hash("kind", "parent", "children", copy(Parent)));
 }
```

`push(rule)` is the compact form for a very common parser action: run one child rule and append that child result into the current rule's conventional array. In a rule named `Parent`, `push(Child)` means "call `Child` and push the return value into `@Parent`."

Use the one-argument form when the current rule's conventional array is the accumulator:

```text
push(Item);
push(Field);
push(Node);
```

Use the targeted two-argument form when the destination should be a separate array variable:

```text
push(Item, items);
push(Field, fields);
push(Node, children);
```

This is intentionally shorter than spelling the lower-level pieces:

```text
push(children, call(Child));
```

That longer shape is still valid. It is just not the clearest spelling when the whole intent is "call and push."

Use `push(...)` instead when the pushed value is not simply the child result:

```text
push(items, trim(match_text()));
push(children, hash("kind", "wrapped", "node", call(Node)));
```

The terse operator form is equivalent for explicit value expressions and bare scalar RHS reads:

```text
items += trim(match_text());
children += hash("kind", "wrapped", "node", call(Node));
items += value;
items += value;
```

In the operator form, a bare RHS identifier is a scalar working-variable read. The all-bare `push(A,B)`
function-call shape remains child-call syntax, so use `items += value` when appending a working scalar by name.

Hash field assignment has the same statement shape for named hashes:

```text
meta["kind"] = "token";
meta[cat("source", "_kind")] = kind;
meta[field_name] = field_value;
meta[field_name] = field_value;
```

In statement hash mutation slots, bare key/RHS identifiers read scalar working variables, so
`meta[key] = "token"` reads working value `key` and `meta["kind"] = value` reads working value `value`.

When the child returns an array-like payload and the current rule accumulator needs one element from it, pass a zero-based index as the second argument:

```text
push(quoted_string, 1);
```

That is the helper equivalent of pushing `call(quoted_string)->[1]` into the current rule's array. If the target should be a separate array, use the three-argument form:

```text
push(quoted_string, logging_annotation, 1);
```

Keep indexed forms for shaped child payloads whose convention is already clear; otherwise, prefer returning a clearer hash or typed payload from the child and pushing the whole child result.

Conditional append pattern:

```text
logging_annotation: /@(\w+)\s*\(\s*/ /\s*\)/ @capture_slice
I { logging_annotation = []; }

-> quoted_string {
  push(quoted_string, 1)
}
-> comma {
  logging_annotation_part = trim(capture_slice())
  if(is_nonempty(logging_annotation_part)) { push(logging_annotation, logging_annotation_part) }
}
-> logging_annotation[1] {
  logging_annotation_part = trim(capture_slice());
  if(is_nonempty(logging_annotation_part)) { push(logging_annotation, logging_annotation_part); }
  return(hash(
    "kind", "logging_annotation",
    "name", match_group(0),
    "args", copy(logging_annotation)
  ))
}
```

Use an explicit non-empty guard for accumulator rules where an optional parse span may be empty after normalization. Evaluate the value once, check `is_nonempty(...)`, and then append through `push(...)`. This skips `undef`, the empty string, empty arrays, and empty hashes while preserving the string `"0"` because `"0"` is data, not absence. Other reference values count as present values and are appended.

Use the explicit filter when the empty value is parser noise:

```text
part = trim(capture_slice());
if(is_nonempty(part)) { push(parts, part); }

child = call(OptionalChild);
if(is_nonempty(child)) { push(children, child); }

tag = lowercase(trim(match_text()));
if(is_nonempty(tag)) { push(tags, tag); }
```

Do not use it when an empty string is a meaningful token:

```text
push(fields, field_text);
```

That distinction is deliberate. `push(...)` says "append exactly what I computed." The explicit guard says "append the computed value only if it survived the emptiness filter."

Append versus replace:

```text
push(children, retv);
```

That appends one value.

```text
set(children, [retv]);
```

That replaces the whole array with a one-item array. It is correct only when replacement is the intent.

## Scalar normalization helpers

These helpers produce scalar values and preserve parser intent inside the DSL expression layer.

| Helper | Result | Use it when |
| --- | --- | --- |
| `trim(value)` | scalar | remove leading and trailing whitespace. |
| `lowercase(value)` | scalar | normalize text to lower case. |
| `uppercase(value)` | scalar | normalize text to upper case. |
| `replace_substr(value, needle, replacement)` | scalar | perform a literal substring rewrite. |
| `rm_prefix(value, prefix)` | scalar | remove one literal prefix when present. |
| `rm_suffix(value, suffix)` | scalar | remove one literal suffix when present. |
| `substr(value, start, length?)` | scalar | slice at a zero-based character offset; omitted length means through end, explicit null means null. Boolean offsets/widths use 1/0; bounded backend checks and limits appear below. |
| `cat(value, value, ...)` | scalar | build one string from scalar fragments. |
| `length(value)` | scalar number or `undef` | measure string or array length; [Perl pipeline examples](values-containers-and-flow-helpers.md#registered-array-pipelines-and-length). |

`lowercase` and `uppercase` are Unicode operations, not byte operations; UTF-8, UTF-16, and UTF-32 are only host
representations. The canonical contract is Unicode 17.0.0 full Default Case Conversion, locale-independent, with
standard context rules and no implicit normalization. Thus `uppercase("ß")` is `"SS"`, `lowercase("İ")` is
`"i\u{0307}"`, and `uppercase("ﬃ")` is `"FFI"`. Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT execute generated
tables for function, receiver, and array forms; these special cases are portable across every variant.

`cat` now uses one scalar-to-text contract on every variant. Strings are unchanged; booleans become `1` or `0`;
finite numbers use stable decimal text, so negative zero becomes `0`, `1.0` becomes `1`, and `1.25` remains
`1.25`. Null, array, harray, and codeblock values are not scalar text, so any such argument makes the whole `cat`
result null rather than silently contributing an empty fragment. The codeblock rule is a value-kind contract;
portable explicit final-codeblock call syntax remains separately tracked and is not implied here. The current
helper is `cat`; retired `concat` remains unsupported.

```text
cat("value=", true, "/", 1.0, "/", 1.25)  # "value=1/1/1.25"
cat("prefix", undef, "suffix")             # undef / JSON null
cat("prefix", [1], "suffix")               # undef / JSON null
```

Examples:

```text
name = lowercase(trim(entry_group(0)));
key = replace_substr(lowercase(trim(name)), "-", "_");
core = rm_prefix(key, "node_");
base = rm_suffix(core, "_end");
full_key = cat(base, "::", stage);
name_len = length(name);
short_key = raw.trim().lowercase().replace_substr("-", "_").substr(0, 12);
set(parts, raw.trim().split("-").trim_each().filter_nonempty());
public = raw.trim().split("-").lowercase_each().join_values("_");
```

String receiver-dot value chains are accepted for the pure scalar string helpers. The receiver is the first
helper argument, so `raw.trim().lowercase()` maps to `lowercase(trim(raw))`, and
`"abcdef".substr(1, 3).uppercase()` maps to `uppercase(substr("abcdef", 1, 3))`. Scalar string-helper links
(`trim`, `lowercase`, `uppercase`, `replace_substr`, `rm_prefix`, `rm_suffix`, `substr`, and `cat`)
can keep chaining through compatible helpers. Empty-old replacement and empty/unmatched affix removal preserve the original scalar kind; these operations need not produce String. Perl native/fresh and Rust/Dart native/restored/in-process plan and Julia/Lua native/plan/fresh scalar-result and shape boundaries are targeted-checked: explicit split permits Array consumers; incompatible container tails skip their operands while retaining source/prefix effects. Affix identity Numbers also remain valid typed Array indices. Lua uses available PUC5.5.1/LuaJIT; declared5.4/full admission remains separate; the frozen slice target gives `"abc".substr(1)` → `"bc"`, `"abc".substr(1, undef)` → null and `"abc".substr(true, true)` → `"b"`. Perl/Rust/Dart/Julia and safe Lua PUC5.5.1/LuaJIT agree on these targeted argument examples; declared Lua5.4 and complete signature/context/portable admission remain separate. This helper compatibility does not change strict Boolean rejection in numeric arithmetic. Defaults preserve the selected kind: ordinary Perl/Rust/Dart/Julia/Lua `undef.coalesce(["a","b"]).last().uppercase()` gives `"B"`, while `"".coalesce("late").cat("!")` retains `"!"`; one-or-more fallbacks are required, selection is lazy, and unused fallbacks stay skipped. Lua uses available PUC5.5.1/LuaJIT; declared5.4/full domain/context/portable admission remain separate. `split(delim)` is the explicit bridge from a
string chain into the array receiver family, so `raw.trim().split("-").trim_each().join_values("|")` is
portable. `length` feeds compatible scalar/number methods, for example `"abcd".length().add(2)` returns `6`; on Perl/Rust/Dart/Julia/Lua, `"abc".starts_with("a").cat("!")` returns `"1!"` and `"abc".matches(/^z/).coalesce_nonempty("late").cat("!")` returns `"0!"`. Predicates require one operand before effects; their scalar results reject container-only consumers until an explicit bridge produces a container.
A string-yielding expression-valued block can be the receiver, for example
`{ " a-b " }.trim().split("-").count()`.

Rationale:

- Use `replace_substr(...)` for literal replacement, not regex replacement.
- Use `rm_prefix(...)` and `rm_suffix(...)` when the boundary itself is meaningful parser metadata.
- Use `substr(...)` when the parser contract is a fixed offset/width slice of a value.
- Use `cat(...)` when the rule already knows the fragments and does not need array staging.
- Use `coalesce(length(...), 0)` when missing text should count as zero. Plain `length(undef)` stays undefined.

Statement-style regex substitution is a separate mutation form used by some shipped specs:

```text
substr(value, '"|\s', "", go)
regex_subst(value, /^\[(\d+)\]$/, "$1", o)
```

Those forms mutate the named scalar target. `g` applies the replacement globally; `i`, `m`, `s`, and `x` are regex
flags; `o` is accepted as a compatibility no-op. Keep this form out of receiver-dot value chains, where
`substr(value, start, length?)` means character slicing. Single-quoted and double-quoted scalar literals are the
same variant-agnostic `.spec` surface on every backend; prefer the delimiter that keeps the pattern readable.

Example:

```text
if(num_gt(coalesce(length(trim(name)), 0), 3))
  return(hash("kind", "long_name", "name", name));
else()
  return(hash("kind", "short_name", "name", name));
endif()
```

## Scalar predicates and string comparisons

These helpers usually appear in `if(...)`, `elseif(...)`, and `switch(...)` expressions, and many can be assigned or returned. Ordinary Perl definedness receivers now continue: `"abc".is_defined().cat("!")` returns `"1!"`; `[].first().is_defined().coalesce_nonempty("late").cat("!")` returns `"late!"` because its existing false result is empty text. Rust/Dart/Julia/Lua support this bounded family with Boolean results (Lua: PUC5.5.1/LuaJIT; declared5.4 proof remains separate): `[].first().is_defined().coalesce_nonempty("late").cat("!")` retains `"0!"`; `false.is_defined()` and `undef.is_undefined()` return true. Empty text/Array/Hash, false and zero themselves are defined; these predicates test null rather than emptiness.

| Helper | Meaning; Perl/Rust/Dart/Julia/Lua receiver examples with `word="abc"` |
| --- | --- |
| `str_eq(lhs, rhs)` | string equality; `word.str_eq("abc").cat("!")` → `"1!"`; `word.str_eq("z").cat("!")` → `"0!"`. |
| `str_ne(lhs, rhs)` | string inequality; `word.str_ne("z").cat("!")` → `"1!"`; `word.str_ne("abc").cat("!")` → `"0!"`. |
| `str_gt(lhs, rhs)` | string greater-than; `word.str_gt("aaa").cat("!")` → `"1!"`; `word.str_gt("zzz").cat("!")` → `"0!"`. |
| `str_ge(lhs, rhs)` | string greater-than-or-equal; `word.str_ge("abc").cat("!")` → `"1!"`; `word.str_ge("zzz").cat("!")` → `"0!"`. |
| `str_lt(lhs, rhs)` | string less-than; `word.str_lt("zzz").cat("!")` → `"1!"`; `word.str_lt("aaa").cat("!")` → `"0!"`. |
| `str_le(lhs, rhs)` | string less-than-or-equal; `word.str_le("abc").cat("!")` → `"1!"`; `word.str_le("aaa").cat("!")` → `"0!"`. |
| `starts_with(value, prefix)` | value begins with the literal prefix. |
| `ends_with(value, suffix)` | value ends with the literal suffix. |
| `contains_substr(value, needle)` | value contains the literal substring. |
| `matches(value, /regex/)` | value matches the regex. |

Examples:

```text
if(str_eq(lowercase(trim(kind)), "word"))
  return(hash("kind", "word", "text", text));
elseif(starts_with(lowercase(trim(kind)), "node_"))
  return(hash("kind", "node", "text", text));
elseif(matches(kind, /^[A-Z_]+$/))
  return(hash("kind", "keyword", "text", text));
else()
  return(hash("kind", "unknown", "text", text));
endif()
```

Use string comparisons for lexical text semantics. Use numeric comparisons for counts, offsets, depths, and computed numeric helpers.

Compatibility bridge status:

- The explicit bridge names `str_eq`, `str_ne`, `str_gt`, `str_ge`, `str_lt`, and `str_le` are shipped and
  preferred for lexical text comparisons.
- The bare helpers `eq`, `ne`, `gt`, `ge`, `lt`, and `le` are numeric comparison aliases. They are no longer
  lexical string comparisons.
- The `str_*` names are not numeric helpers or comparison-symbol calls. Current Perl/Rust/Dart/Julia/Lua free/nested and ordinary receiver counterparts work: `cat(str_eq("a","a"),"!")` and `"a".str_eq("a").cat("!")` both return `"1!"`. All six methods take one operand before effects; compatible scalar/generic consumers see the comparison result. `"a".str_eq("a").cat(",x").split(",").last().uppercase()` bridges to Array and returns `"X"`; container-only consumers directly after a comparison return undef. Other-backend/full admission remains separate. False renders `"0!"` and remains present through `coalesce_nonempty`. Perl/Rust currently compare undef as empty text; preserve this compatibility without inferring a portable null domain. Dart/Julia/Lua propagate null operands instead; Dart’s tracked UTF-16 ordering limitation is unchanged.

## Numeric value helpers

Under the scalar numeric contract, inputs are finite numbers or untrimmed decimal strings such as
`".5"`, `"-.5"` and `"007"`. Typed booleans, null, arrays, harrays and codeblocks
are invalid scalar numeric operands. Invalid input, arity, nonfinite results,
zero divisors, fractional modulo operands and inverted clamp bounds return `undef`.
Unary helpers take one operand; subtraction/division/modulo and comparisons take
two; clamp takes three; addition/multiplication/scalar min/max take at least two.
Comparisons return numeric `1`/`0`. Rounding uses halves away from zero; integer
modulo is `a - floor(a/b)*b`, with a nonzero result having the divisor's sign.
Array-form min/max and array reducers have their separate signatures below.

| Helper | Result | Use it when |
| --- | --- | --- |
| `num_abs(value)` | scalar number or `undef` | absolute value. |
| `num_floor(value)` | scalar number or `undef` | round down to an integer. |
| `num_ceil(value)` | scalar number or `undef` | round up to an integer. |
| `num_round(value)` | scalar number or `undef` | round to nearest integer. |
| `num_sum(array_expr)` | scalar number or `undef` | sum numeric array items. |
| `num_avg(array_expr)` | scalar number or `undef` | average numeric array items. |
| `num_median(array_expr)` | scalar number or `undef` | median of numeric array items. |
| `num_range(array_expr)` | scalar number or `undef` | max minus min across numeric array items. |
| `num_add(lhs, rhs, ...)` | scalar number or `undef` | add two or more operands. |
| `num_sub(lhs, rhs)` | scalar number or `undef` | subtract `rhs` from `lhs`. |
| `num_mul(lhs, rhs, ...)` | scalar number or `undef` | multiply two or more operands. |
| `num_div(lhs, rhs)` | scalar number or `undef` | divide `lhs` by `rhs`; division by zero returns `undef`. |
| `num_mod(lhs, rhs)` | scalar number or `undef` | integer remainder; non-integer operands return `undef`. |
| `num_clamp(value, lower, upper)` | scalar number or `undef` | keep a number inside inclusive bounds. |
| `num_min(array_expr)` | scalar number or `undef` | minimum numeric array item. |
| `num_min(lhs, rhs, ...)` | scalar number or `undef` | minimum of two or more operands. |
| `num_max(array_expr)` | scalar number or `undef` | maximum numeric array item. |
| `num_max(lhs, rhs, ...)` | scalar number or `undef` | maximum of two or more operands. |

The non-comparison numeric helpers also accept terse function-form aliases:
`abs`, `floor`, `ceil`, `round`, `sum`, `avg`, `median`, `range`, `add`, `sub`,
`mul`, `div`, `mod`, `clamp`, `min`, and `max`. They lower to the corresponding
`num_*` helper and compose as ordinary nested calls.

Perl callable bodies also execute the six array reducers and their terminal
receiver forms. These retain the separate aggregate checks: every item must be
decimal-looking; empty sum is `0` and the other empty reducers are `undef`.
See [aggregate callback examples](values-containers-and-flow-helpers.md#aggregate-numeric-helpers-in-codeblocks)
for parameters, effects, min/max overloads and the selected-string index limit.

Arithmetic symbols are accepted as the equivalent call names for the binary or
variadic arithmetic family: `+(a, b)` -> `num_add(a, b)`, `-(a, b)` ->
`num_sub(a, b)`, `*(a, b)` -> `num_mul(a, b)`, `/(a, b)` -> `num_div(a, b)`,
and `%(a, b)` -> `num_mod(a, b)`. There is no operator precedence in either
form; write grouping explicitly with nested calls such as `+(*(a, b), c)` or
`add(mul(a, b), c)`.

On the current Perl backend, ordinary rule actions support the arithmetic calls
above, including a final `/(14, 2)` before a block-closing brace. The
[complete division example](../public-api/integration-perl.md#regex-and-division-in-action-code)
also shows an action edge on the same line and explains current parsing limits.
Perl callable bodies also execute the scalar names, word/symbol aliases and
numeric receiver links described here. See the
[callable examples](values-containers-and-flow-helpers.md#scalar-numeric-helpers-in-codeblocks)
for caller effects, operand snapshots, terminal chains and the remaining
boolean-literal and deferred pipeline limits. The separate grouping boundary remains:

- Wrapping the entire call in extra parentheses, as in `out = (div(14, 2))`
  or `out = (/(14, 2))`, currently reaches a host-function or regex error.
  Use the direct call `out = div(14, 2)` in ordinary actions. The supported
  grouping boundary and its diagnostics are tracked under
  `SESSION-STARTUP-READING.87.4`; these failing probes do not establish an
  additional grouping syntax.

Comparison symbols are accepted as the equivalent call names for the numeric
comparison family: `==(a, b)` -> `num_eq(a, b)`, `!=(a, b)` -> `num_ne(a, b)`,
`>(a, b)` -> `num_gt(a, b)`, `>=(a, b)` -> `num_ge(a, b)`, `<(a, b)` ->
`num_lt(a, b)`, and `<=(a, b)` -> `num_le(a, b)`. They are still ordinary
function calls, not infix operators. For lexical string comparisons, use
`str_eq(...)`, `str_ne(...)`, `str_gt(...)`, `str_ge(...)`, `str_lt(...)`, and
`str_le(...)`.

Examples:

```text
part_count = count(parts);
next_depth = num_add(depth, 1);
next_depth = add(depth, 1);
next_depth = +(depth, 1);
distance = num_abs(num_sub(end_pos, start_pos));
distance = abs(sub(end_pos, start_pos));
bucket = num_mod(count(parts), 3);
bucket = %(count(parts), 3);
bounded_count = num_clamp(count(parts), 1, 5);
score_total = num_sum(scores);
score_total = sum(scores);
score_total = scores.sum();
score_average = num_avg(scores);
score_average = scores.avg();
score_median = num_median(scores);
score_range = num_range(scores);
score_floor = scores.min();
score_ceiling = scores.max();
next_depth = depth.add(1);
weighted_count = count(parts).add(2, offset).mul(3);
score_bucket = score.abs().ceil().clamp(0, 10);
has_parts = >(count(parts), 0);
```

Number receiver-dot value chains are accepted with terse method names. The receiver is the first argument to
the corresponding `num_*` helper, so `score.abs().ceil().add(2)` maps to
`num_add(num_ceil(num_abs(score)), 2)`, and `3.5.floor().add(1)` maps to
`num_add(num_floor(3.5), 1)`. Number-returning links (`abs`, `floor`, `ceil`, `round`, `add`, `sub`, `mul`,
`div`, `mod`, `min`, `max`, and `clamp`) can keep chaining through number helpers. Ordinary Perl/Rust/Dart/Julia/Lua arithmetic results also feed compatible methods: `2.add(3).cat("!")` gives `"5!"`, `0.add(0).coalesce_nonempty("late").cat("!")` gives `"0!"`, and `2.add(1).cat(",x").split(",").last().uppercase()` gives `"X"`. Invalid numeric results keep their ordinary null policy: `2.div(0).coalesce_nonempty(["a","b"]).last().uppercase()` gives `"B"`. A Hash fallback remains a Hash: `2.div(0).coalesce_nonempty({"b":"b","a":"a"}).sorted_values().first().uppercase()` gives `"A"`; the same projection works from a direct `undef` default. Lua checks use available PUC5.5.1/LuaJIT; declared5.4/full arithmetic admission remains separate. Comparison links (`eq`,
`ne`, `gt`, `ge`, `lt`, `le`) return numeric `1`/`0` or invalid-input `undef`; ordinary results feed compatible scalar or explicit-container continuations, as shown in [Numeric comparisons](#numeric-comparisons). Array reducers are array-consuming: use
function form such as `num_sum(scores)` / `sum(scores)` or array receiver form such as
`scores.sum()` / `scores.avg()`. Ordinary Perl/Rust/Dart/Julia/Lua results continue through compatible scalar/number methods: `[2,4,6].sum().add(1)` returns `13`, `[].sum().add(1)` returns `1`, and `[].avg().add(1)` returns null.
Reducers are not scalar number receiver links; array-only consumers stay invalid until an explicit string-to-array bridge. Lua checks use available PUC5.5.1/LuaJIT; declared5.4/full admission remains open. A number-yielding expression-valued block can be the receiver,
for example `{ 3.5 }.floor().add(2)`.

### Numeric reducers consume array values

On Perl, `sum` and `avg` accept the same array-valued sources as `median`,
`range`, `min` and `max`: literals, bindings, direct reads, function arguments
and function results. Their `num_*` spellings are equivalent. A selector is
evaluated once, and reduction leaves the source array unchanged.

This complete example uses line breaks as statement separators; trailing
semicolons are optional and valid:

```text
{{#include ../../../../examples/numeric-array-values.spec}}
```

Input `x` returns:

```json
[[6,2,2,2,1,3],[0,null,null,null,null,null],6,6]
```

The first row contains sum, average, median, range, minimum and maximum.
The second row shows the empty-array results: sum is `0`; the other five
reducers return `undef` (JSON `null`). A missing direct-read result, a non-array source,
or an array containing `undef` or nonnumeric text also returns `undef`.
Decimal strings such as `"3"` are accepted as numeric elements. Current Perl
`min`/`max` and odd-length `median` preserve a selected numeric string as a string;
for example, `min(["3","1","2"])` returns `"1"`. This numeric-result defect is
tracked under `SESSION-STARTUP-READING.95`. The scalar numeric contract is separate;
this example does not change numeric coercion.

Numeric helpers compose with array helpers:

```text
top_score_average = num_avg(take(sorted(scores), 3));
top_score_average = scores.sorted().take(3).avg();
score_floor = num_min(take(scores, 5));
score_ceiling = num_max(concat_arrays(scores, extra_scores));
```

## Numeric comparisons

Use numeric comparisons when the operands are numbers, counts, or numeric helper results.

| Helper | Meaning |
| --- | --- |
| `num_eq(lhs, rhs)` | numeric equality. |
| `num_ne(lhs, rhs)` | numeric inequality. |
| `num_gt(lhs, rhs)` | numeric greater-than. |
| `num_ge(lhs, rhs)` | numeric greater-than-or-equal. |
| `num_lt(lhs, rhs)` | numeric less-than. |
| `num_le(lhs, rhs)` | numeric less-than-or-equal. |
| `eq(lhs, rhs)` | alias for `num_eq(lhs, rhs)`. |
| `ne(lhs, rhs)` | alias for `num_ne(lhs, rhs)`. |
| `gt(lhs, rhs)` | alias for `num_gt(lhs, rhs)`. |
| `ge(lhs, rhs)` | alias for `num_ge(lhs, rhs)`. |
| `lt(lhs, rhs)` | alias for `num_lt(lhs, rhs)`. |
| `le(lhs, rhs)` | alias for `num_le(lhs, rhs)`. |
| `==(lhs, rhs)` | alias for `num_eq(lhs, rhs)`. |
| `!=(lhs, rhs)` | alias for `num_ne(lhs, rhs)`. |
| `>(lhs, rhs)` | alias for `num_gt(lhs, rhs)`. |
| `>=(lhs, rhs)` | alias for `num_ge(lhs, rhs)`. |
| `<(lhs, rhs)` | alias for `num_lt(lhs, rhs)`. |
| `<=(lhs, rhs)` | alias for `num_le(lhs, rhs)`. |

Examples:

```text
if(num_gt(count(parts), 0))
  return(hash("kind", "nonempty", "count", count(parts)));
endif()

if(gt(count(parts), 0))
  return(hash("kind", "nonempty", "count", count(parts)));
endif()

if(>(count(parts), 0))
  return(hash("kind", "nonempty", "count", count(parts)));
endif()

if(num_eq(index_of(sorted_keys(meta), "kind"), 0))
  return(hash("kind", "kind_first"));
endif()

if(num_ge(num_avg(take(scores, 3)), 5))
  return(hash("kind", "high_score", "average", num_avg(take(scores, 3))));
endif()

if(count(parts).gt(0))
  return(hash("kind", "nonempty", "count", count(parts)));
endif()
```

Do not use `str_gt(...)` or `str_lt(...)` for counters. They are string comparisons and can produce surprising ordering for numeric-looking text.

Numeric comparisons can use `num_eq`/`num_ne`/`num_gt`/`num_ge`/`num_lt`/`num_le`, bare word aliases such as
`gt(...)`, symbol callees such as `>(...)`, or number receiver comparisons such as
`count(parts).gt(0)`. The explicit string bridge names are shipped as
`str_eq`/`str_ne`/`str_gt`/`str_ge`/`str_lt`/`str_le`; prefer those names in lexical string comparisons. Numeric comparison functions return numeric `1`/`0`, or `undef` for invalid numeric inputs; `cat(num_eq(2,3),"!")` gives `"0!"` and `num_add(num_eq(2,3),2)` gives `2`. Ordinary Perl/Rust/Dart/Julia/Lua short `eq/ne/gt/ge/lt/le` receiver results now continue: `2.eq(3).coalesce_nonempty("late").cat("!")` gives `"0!"`, `2.eq(3).add(2)` gives `2`, and `2.eq(2).cat(",x").split(",").last().uppercase()` gives `"X"`. Invalid numeric inputs remain `undef` and can use explicit defaults: `"x".eq(2).coalesce_nonempty(7).add(1)` gives `8`. One RHS is required before effects; container-only consumers return `undef` until a bridge produces a container. Lua checks use available PUC5.5.1/LuaJIT; declared5.4, deferred/full admission remains separate.

## Array helpers

Array helpers return either scalar information about an array or a new array value derived from it.

| Helper | Result | Use it when |
| --- | --- | --- |
| `count(array_expr)` | scalar count | count array items; undefined array expressions count as `0`. |
| `first(array_expr)` | scalar value or `undef` | read the first item. |
| `last(array_expr)` | scalar value or `undef` | read the last item. |
| `index_of(array_expr, needle)` | scalar index or `undef` | find the first matching item by zero-based index. |
| `contains(array_expr, needle)` | `1` or `0` | test array membership. Perl/Rust/Dart/Julia/Lua `["a"].contains("a").cat("!")` → `"1!"`; false survives `coalesce_nonempty` as `"0!"`. One needle is required before effects; scalar results reject container-only consumers until an explicit bridge. |
| `drop_front(array_expr)` | array value | drop the first item. |
| `drop_front(array_expr, count)` | array value | drop the first `count` items. |
| `take(array_expr)` | array value | keep the first item. |
| `take(array_expr, count)` | array value | keep the first `count` items. |
| `slice(array_expr, start)` | array value | keep from zero-based `start` through the end. |
| `slice(array_expr, start, count)` | array value | keep at most `count` items from `start`. |
| `take_last(array_expr)` | array value | keep the last item. |
| `take_last(array_expr, count)` | array value | keep the last `count` items. |
| `drop_back(array_expr)` | array value | drop the last item. |
| `drop_back(array_expr, count)` | array value | drop the last `count` items. |
| `concat_arrays(array_expr, array_expr, ...)` | array value | concatenate multiple array values without mutating them. |
| `sorted(array_expr)` | array value | return a lexical sorted copy. |
| `reversed(array_expr)` | array value | return a reversed copy. |

Examples:

```text
first_part = first(parts);
last_part = last(parts);
kind_index = index_of(sorted_keys(meta), "kind");
has_tail = contains(parts, "tail");
set(rest_parts, drop_front(parts));
set(first_two, take(parts, 2));
set(middle, slice(parts, 1, 3));
set(last_two, take_last(parts, 2));
set(without_last, drop_back(parts));
set(combined, concat_arrays(parts, extra_parts, ["tail"]));
set(canonical, sorted(combined));
set(reverse_view, reversed(canonical));
first_after_sort = items.sorted().drop_front(2).first();
public_count = items.filter_match(/^public_/).count();
csv = items.uniq().join_values(",");
```

Array helpers are pure value helpers unless you use `set(...)` to store their result. For example, `sorted(parts)` does not sort `parts` in place. This is intentional: the rule text says when a working container changes.

Array receiver-dot value chains are accepted for the same pure array helpers. The receiver is the first helper argument, except `join_values`, where `items.join_values(delim)` maps to the canonical `join_values(delim, items)` contract. The named mutating end methods `items.push_back(value)`, `items.push_front(value)`, `items.pop_back()`, and `items.pop_front()` return independent updated arrays; pop discards the removed element, and a continuation such as `.count()` consumes the update. An array-yielding expression-valued block can be the receiver too: `{ [3, 1, 2] }.sorted().join_values(",")`.

Ordinary Perl/Rust/Dart/Julia/Lua index results continue on recorded hosts: `["a","b"].index_of("b").add(1)` returns `2`,
`["a","b"].index_of("a").add(1)` returns `1`, and `["a","b"].index_of("b").cat("!")` returns `"1!"`.
A missing/empty result stays undef; `["a"].index_of("z").coalesce_nonempty(7).add(1)` returns `8`.
The receiver takes one needle; malformed shapes return undef before effects. Source, needle and consumer operands run once in order.
With `parts=["a"]`, `parts.index_of({parts+="b";"b"})` returns undef and leaves `parts` as `["a","b"]`. Lua checks use available PUC5.5.1/LuaJIT; declared5.4/full admission remains open.

Perl callable bodies also support `sorted` and `take`, including their receiver forms and reducer continuations. See the [worked sorting and selection examples](values-containers-and-flow-helpers.md#sorting-and-taking-inside-perl-codeblocks) for count rules, copies, evaluation order and remaining callable limits.
Sorting also preserves numeric and string scalar kinds through codeblock copies; see the [typed copy examples](values-containers-and-flow-helpers.md#scalar-kinds-after-sorting).
For Perl callable `count`/`first`, see the [worked selection, terminal and effect examples](values-containers-and-flow-helpers.md#counting-and-selecting-first-inside-perl-codeblocks).

<a id="array-transform-continuations-guarded-perl-results"></a>

### Array transform continuations: guarded results

`take`, `take_last`, `drop_front`, `drop_back`, `slice`, `sorted`, `reversed` and
`concat_arrays` return Arrays. Their ordinary Perl, Rust, Dart, Julia and installed Lua results now retain actual-kind
guards through later consumers, `copy`, logical helpers and immediate `with`:

```text
take(["head","tail"],1).last().uppercase()             # "HEAD"
take_last(["head","tail"],1).last().uppercase()        # "TAIL"
drop_front(["head","tail"],1).count()                 # 1
drop_back(["head","tail"],1).first()                   # "head"
slice(["head","tail","end"],1,1).join_values(",")     # "tail"
reversed([{"k":"tail"}]).last().pick_keys("k").count_keys() # 1
sorted(["b","a"]).join_values(",")                   # "a,b"
concat_arrays(["head"],["tail"]).last().uppercase()    # "TAIL"
take(["tail"],0).with(){return(value.count())}          # 0; body runs
```

An incompatible Hash consumer returns null before either operand runs. This
action returns `[null, ""]`:

```text
order="";
out=take(["head","tail"],1).set_key(
  {order=cat(order,"K");"k"},
  {order=cat(order,"V");1});
return([out,order]);
```

The rejection survives later links. For example, this also returns `[null, ""]`:

```text
order="";
out=reversed(["tail"]).set_key(
  {order=cat(order,"K");"k"}, {order=cat(order,"V");1})
  .copy().with(){order=cat(order,"W");return("ran")};
return([out,order]);
```

The same rule skips later logical operands and `with` bodies after rejection.
Legitimate empty Arrays still enter `with`, as the zero-count example shows.
Producer operands run once, source snapshots and nested Bool/null/Number values
are preserved, and needed producer errors still propagate.

The bounded Perl, Rust, Dart, Julia and installed Lua forms retain their existing arities: four take/drop helpers
accept an optional count, `slice` requires a start and permits an omitted count,
and `sorted`/`reversed` take no extra receiver operands. Perl and Rust guarded
`concat_arrays` forms now retain the existing one-or-more Array signature; the
bounded Dart/Julia/Lua proof here covers free-two/receiver-one. Source, coercion, sorting, copy depth, splices and
mutation keep their existing contracts. Other backends are assessed
independently; descriptor readiness alone does not establish execution behavior.

The existing `concat_arrays` helper also supports several Array inputs, as in
`concat_arrays(array("head"),["tail"],["end"])`, which returns
`["head","tail","end"]`. Perl and Rust additionally accept the single-Array terminal
`concat_arrays(array("head"))` and receiver `array("head").concat_arrays()`;
both return `["head"]`. Registered-function Array sources retain these terminal
forms. Compatible `.last().uppercase()` and immediate `.with()` also pass the
recorded one/two/three-Array Perl and independent Rust controls, including empty Arrays entering with.

Perl80.1 and Rust80.2 now retain result guards through these existing arities for
ordinary and valid fixed/rest function sources. Source S and additional Arrays
T/U evaluate once in order; a later Hash consumer rejects before its K/V operands.
Rejection persists through copy/logical/with and skips D/W. Needed source or
operand errors propagate, and source snapshots and nested Bool/Number/null kinds
remain intact. For example:

```text
concat_arrays(array("head")).set_key("k",1)                # null
concat_arrays(array("head"),["tail"],["end"]).last().uppercase() # "END"
array("head").concat_arrays(["tail"],["end"]).set_key("k",1) # null
concat_arrays(array()).with() { return(value.count()) }     # 0
```

The finite Perl checks keep80 initial-input policies exact. Two legacy non-Array
excess-operand continuations now retain their original terminal producer effects;
these are compatibility controls, without broader input-kind authority. Two
already-rejected free function requests now retain the original bad callee's
diagnostic and terminal operand effects; they remain unready and rejected.
Helper signatures, producers and fixed/rest function acceptance are unchanged.
Rust independently retains all80 initial-input controls and eight invalid-signature
records. Its legacy terminal concat includes scalar operand elements; two old
continuations now reject a later Hash consumer after preserving their terminal SX
effects. These are separate compatibility controls, with no non-Array admission.
Two additional older ordinary expectations at that same scalar-operand boundary
are independently qualified by exact old/current terminal/composed probes; their
terminal values/effects stay exact and their later Hash consumer now skips K/W.
The original failed direct run remains recorded. These controls sit outside504.
Its16 supported repairs retain source-once S/T/U, valid rest-argument X effects,
needed complete error strings and snapshots through native/restored/plan/fresh
execution. The original producer, function dispatch and source formats are
unchanged. Rebuild Rust applications. Dart/Julia/Lua independently acquire their
existing policies before implementation; full continuation/context admission is separate.

Perl source-isolation78.0 keeps Number literals out of the eight legacy named-Array
shortcuts. The bounded native/emitted controls now ignore unrelated Perl host Arrays,
while preserving the existing computed-source fallback, genuine Arrays, optional
counts, needed errors and source snapshots. Regenerate previously emitted Perl.
Portable programs pass Arrays; these Number examples describe Perl compatibility:

```text
take(3,1)                    # []; never reads an unrelated host Array named 3
3.take_last(1)               # []
concat_arrays(3,["tail"])    # ["tail"]; later Array operands still contribute
```

Rust retains its own initial Number/null/Hash source behavior. The following
compatibility examples describe Rust, and do not extend portable input authority:

```text
take(3,1)                         # []
sorted({"k":1})                    # []
concat_arrays(undef,["tail"])       # [null,"tail"]
concat_arrays(3,["tail"])           # [3,"tail"]
```

The first producer keeps that policy; its resulting Array then owns subsequent
kind checks. Earlier produced or copied values keep their existing guards.
Omitted take/drop counts retain the default of one, and `slice` with an omitted
count keeps the remaining tail. Malformed or variadic calls retain their existing
backend behavior and gain no new guarded-result authority.

Dart, Julia and installed Lua independently retain their initial source behavior too. Seven transforms
return an empty Array for the observed Number/null/Hash sources; `concat_arrays`
keeps that source as one element before adding the second Array. These are backend
compatibility examples; portable programs supply Arrays:

```text
take(3,1)                         # []
reversed({"k":1})                 # []
concat_arrays(undef,["tail"])     # [null,"tail"]
concat_arrays({"k":1},["tail"])   # [{"k":1},"tail"]
```

An initial empty result remains a valid `with` receiver:

```text
order="";
out=3.take(1).with(){order=cat(order,"W");return(value.count())};
return([out,order]);              # [0,"W"] on Dart, Julia and installed Lua
```

An earlier produced or copied value keeps its existing guard instead of gaining
this initial-source fallback. Needed source/count errors still propagate through
later consumers and defaults. Extra-arity calls retain their existing behavior
and are outside the newly guarded forms.

Perl composition78.1.1 is focused-checked on native and full emitted-fresh routes;
regenerate previously emitted Perl to receive these guards. Rust78.2 is
focused-checked on native, restored compiled state, generated plans and compiled
emitted-fresh routes; rebuild Rust applications/runtime. Dart78.3 is independently
focused-checked on native, restored SpecFile, generated-plan and full emitted-fresh
routes; rebuild Dart applications with the updated package. Emitted and serialized
formats are unchanged. Julia78.4 is independently focused-checked on the same four
routes; rebuild Julia applications/runtime. Installed Lua78.5 is independently
focused-checked on Lua5.5.1 and LuaJIT2.1.1788460057 across those four routes; reload
applications with the updated runtime. Declared Lua5.4 and full source/context/
admission remain open. Dart's additional direct tests now have a separate qualified
292-test run with complete selected fixture/grammar bindings under23.4.20. The
original six omitted first-use identities stay unknown; its own Array-transform
cases and inverse remain bound.

### Registered-function Array transforms

A pure registered function can return the Array consumed by these transforms.
Compatible free and receiver forms work on the recorded Perl and Rust routes:

```text
fn supply(seed) {return(seed)}

Value:: I {
 return([take(supply(["head","tail"]),1),
         supply(["head","tail"]).take(1)])
}
```

Both members are `["head"]`. The existing guarded free wrapper also rejects an
incompatible later Hash consumer before its operands; this returns `[null, ""]`:

```text
fn supply(seed) {return(seed)}

Value:: I {
 order="";
 out=take(supply(["head","tail"]),1).set_key(
   {order=cat(order,"K");"k"}, {order=cat(order,"V");1});
 return([out,order]);
}
```

The corresponding receiver prefix now uses the same result-kind guards on Perl, Rust, Dart, Julia and the recorded installed Lua hosts.
This covers the eight transform names above, later copy/logical/with rejection,
needed errors and source effects. Source and required operands run once before
result rejection; rejected Hash operands and later work remain skipped:

```text
fn supply(seed) {return(seed)}

Value:: I {
 order="";
 out=supply({order=cat(order,"S");["b","a","c"]}).take({order=cat(order,"N");1}).set_key(
   {order=cat(order,"K");"k"},{order=cat(order,"V");1}
 ).copy().and({order=cat(order,"D");true}).with(){order=cat(order,"W");return("ran")};
 return([out,order]);
}
```

This returns `[null,"SN"]`. Valid empty Array results still enter `with`.
Valid fixed or final-rest function signatures remain required; malformed calls
retain their existing rejection and do not become valid empty Arrays. Perl descriptor
readiness is checked independently of values, including matching null results.
Regenerate previously emitted Perl modules to receive the guards; rebuild Rust
applications with the updated runtime, and rebuild Dart applications. The bounded
Perl implementation has passing focused normals, independent old/current controls
and historical recovery. Rust
has independently passing native, restored, generated-plan and compiled emitted
controls, same-path old/current proof, direct regressions and historical recovery.
Dart, Julia and installed PUC Lua5.5.1/LuaJIT2.1.1788460057 independently pass
the same four public route classes, their own old/current controls and focused
regressions. Reload Lua applications with the updated runtime. Declared Lua5.4
and complete portable admission remain separate.

The recorded Perl initial-input policies differ by context. A registered function
returning Number/Hash input to receiver `sorted` or `reversed` raises a typed
array-binding error; the corresponding free helper returns an empty Array. Null
keeps its empty behavior. These compatibility observations do not expand portable
input authority: portable programs supply Arrays. Errors and argument order
follow the existing terminal operation.

Rust keeps its own initial-source policy. Number, null and Hash inputs to the
seven non-concat transforms still produce empty Arrays, and those empty Arrays
still enter an immediate `with`. For example, this Rust compatibility program
returns `[0,"W"]`:

```text
fn supply(seed) {return(seed)}

Value:: I {
 order="";
 out=supply(3).take(1).with(){order=cat(order,"W");return(value.count())};
 return([out,order]);
}
```

The resulting empty Array then owns later kind checks. Adding `set_key` before
`with` rejects before the key and later block run; this returns `[null,""]`:

```text
fn supply(seed) {return(seed)}

Value:: I {
 order="";
 out=supply(3).take(1).set_key({order=cat(order,"K");"k"},1
 ).with(){order=cat(order,"W");return("ran")};
 return([out,order]);
}
```

Rust's Number/null/Hash compositions previously ran the rejected Hash operands
and later `with`. Their changed continuations are recorded as compatibility
movements separately from supported Array-input fixes. The first producer and
immediate `with` policies are unchanged. `concat_arrays` still retains an initial
scalar or Hash as one element before the second Array. These examples describe
Rust compatibility; portable programs supply Arrays.

Dart preserves its independently observed Number/null/Hash empty-Array policies
for the seven non-concat transforms and retains a scalar or Hash as one element
for `concat_arrays`. Its three initial-source continuations are recorded separately
from supported Array-input fixes. Boolean source behavior differs between receiver
and free helper: this Dart compatibility program returns `[null,""]`, because
the receiver producer returns null and the block stays skipped:

```text
fn supply(seed) {return(seed)}

Value:: I {
 order="";
 out=supply(false).take(1).with(){order=cat(order,"W");return(value.count())};
 return([out,order]);
}
```

Replacing the prefix with `take(supply(false),1)` returns `[0,"W"]`: the free
helper produces an empty Array and the block runs. Both policies are unchanged
by result guarding. Portable programs supply Arrays; these compatibility examples
do not grant a new input domain. Installed Lua independently retains the same
Boolean receiver/free contrast, verified against its own runtime.

Julia independently preserves all of its initial producer and immediate-`with`
observations, including `[null,""]` for Boolean receiver `take` and `[0,"W"]`
for the corresponding free helper. Its Number/null/Hash inputs retain empty Arrays
for the seven non-concat transforms, and `concat_arrays` retains an initial scalar
or Hash as one element. Only the later rejected continuations change. These are
compatibility observations; portable programs supply Arrays. Installed Lua also
retains its independently observed Number/null/Hash terminal and immediate-`with`
policies. Its three changed later continuations are recorded separately from
supported Array-input repairs. For example, the `supply(3).take(1).with()`
program above returns `[0,"W"]` on each recorded installed Lua host; adding the
rejected `set_key` continuation returns `[null,""]`.

Excluded argument shapes also keep their current behavior. On Perl, some receiver
shapes fold directly to null before effects while free helper forms are unresolved;
their different readiness flags alone do not establish a required policy change.
Signature inventory1.2.1.4.3 owns that contextual question. Rust retains its observed
missing/excess transform evaluation and fixed/minimum function-arity errors; those
transform shapes gain no new guarded-result authority. Dart also retains its own
missing/excess shapes: free `sorted`/`reversed` skip an ignored extra operand, while
their receiver forms evaluate it. Julia evaluates the extra operand in both
free and receiver forms: its observed order remains `SXKVW` for the excluded
Hash/with continuation. Installed Lua independently preserves `SXKVW` in both
forms. Function fixed/rest arity checks and complete published error JSON remain
intact on these recorded routes. Lua also preserves the observer's named outer
flags; this does not establish preservation of every raw native error-table field.
Lua evaluates positional argument values before its invocation arity preparation,
while rejecting keywords earlier; this repair keeps that order. Wider open-arity
`concat_arrays` continuations are selected as bounded family80 after selection23.1.42; Perl80.1 and independent Rust80.2 have focused proof; Dart/Julia/Lua lanes remain pending.

Initial wrong-input policy remains separate from produced-result guards. The
established constructor contrast uses `array(...)`; a direct literal Array with
an incompatible Hash consumer currently raises a wrapped host error on Perl.
Receiver inventory1.2.1.3.1 owns that policy question. No universal wrong-input
normalization, function signature change or complete portable admission follows.

## Hash helpers

Hash helpers return scalar information about an object or a new hash/array value derived from it.

On Perl, `drop_keys(meta, "debug")` and `meta.drop_keys("debug")` leave `meta` unchanged and return a copy. Use `flat_array(keys)` to expand an array of keys; an empty splice removes none. Each key value is captured before the next key operand runs. Scalar-key generated parsers also load with fatal syntax warnings. See [Removing keys in Perl](values-containers-and-flow-helpers.md#removing-keys-in-perl) for complete copy, splice and callback-order examples.

Ordinary Perl `set_key` accepts eager String key blocks in value, receiver and statement forms: `meta.set_key({return("kind")},{return("node")})` produces a copy with `"kind":"node"`. Block returns stay local. Pure source, key and value evaluate once in that order; the source copy and selected key survive later operand effects. With `meta={"old":1}; key="before"`, `changed=set_key(meta,key,{key="after";2})` yields `{"old":1,"before":2}`, leaves `meta` as `{"old":1}` and leaves `key` as `"after"`. Statement `set_key(meta,key,...)` and String-key `meta[key]=...` also capture the key before their value.

Bare key and value operands read their working bindings. `key="stage"; value="stored"; meta={}; set_key(meta,key,value); return(meta)` returns `{"stage":"stored"}`. A literal key is explicit: `set_key(meta,"stage",value)` reads the same value binding. The key is captured before the value expression runs.

The pure and mutating forms can be used together. This Perl action returns `[{"old":1,"before":2},{"old":1,"stored":7},"after"]`:

```text
meta = {"old":1};
key = "before";
out = set_key(meta, key, {key="after";2});
set_key(meta, "stored", 7);
return([out,meta,key]);
```

The pure result keeps the earlier key and original source fields. The statement adds `stored` to the working Hash after that result has been captured.

Perl's existing first-collection-method fallback remains: `n=5; n.set_key("k",1)` produces `{"k":1}`. A scalar-producing prefix has its own guarded result boundary: `n.add(0).set_key("k",1)` yields undef. This compatibility rule does not change helper arities, copy depth, mutation target kinds or deferred callable permissions.

| Helper | Result | Use it when |
| --- | --- | --- |
| `count_keys(hash_expr)` | scalar count | count object keys; undefined hash expressions count as `0`. |

| `sorted_keys(hash_expr)` | array value | get keys in stable lexical order. |
| `sorted_values(hash_expr)` | array value | get values in the stable lexical order of their keys. |
| `has_key(hash_expr, key)` | `1` or `0` | test key existence, not value definedness. |
| `merge_hash(hash_expr, hash_expr, ...)` | hash value | layer object fields; later arguments override earlier keys. |
| `set_key(hash_expr, key, value)` | hash value | return a copy with one key set. |
| `rename_key(hash_expr, old_key, new_key)` | hash value | return a copy with one key renamed if it exists. |
| `drop_keys(hash_expr, key, ...)` | hash value | return a copy without selected keys. |
| `pick_keys(hash_expr, key, ...)` | hash value | return a copy containing only selected keys that exist. |
| `hash_expr.walk_leaves() { block }` | hash value | visit every non-hash leaf for side effects and return the original tree. |
| `hash_expr.map_leaves() { block }` | hash value | return a new tree with every non-hash leaf replaced by the block result. |
| `hash_expr.reduce_leaves(initial) { block }` | value | fold every non-hash leaf into an accumulator. |
| `binding_name.map_leaves!() { block }` | updated hash/array value | All five backends: atomically replace leaves and rebind one bare named receiver. |

Sorted Hash views produce Arrays and already support compatible continuations:
`sorted_keys({"b":2,"a":1}).join_values(",")` is `"a,b"`, and
`sorted_values({"b":"tail","a":"head"}).last().uppercase()` is `"TAIL"`.
On the Perl, Rust, Dart, Julia and installed Lua (PUC5.5.1/LuaJIT) routes
covered by focused checks, canonical ordinary free-one calls and zero-extra receiver prefixes guard
their Array results before incompatible Hash consumers. For example,
`sorted_keys({"a":1}).set_key("k",1)` and
`{"a":1}.sorted_values().set_key("k",1)` return null. Consumer operands are
skipped; later `.copy().with(){return("ran")}` and eager logical operands keep
that rejection. Valid empty Arrays still enter a body:
`sorted_keys({}).with(){return(value.count())}` returns0.
The backend handoff records focused
[Perl](../appendix/backend-handoff.md#perl-ordinary-hash-view-result-guards) and
[Rust](../appendix/backend-handoff.md#rust-ordinary-hash-view-result-guards) and
[Dart](../appendix/backend-handoff.md#dart-ordinary-hash-view-result-guards) and
[Julia](../appendix/backend-handoff.md#julia-ordinary-hash-view-result-guards) and
[installed Lua](../appendix/backend-handoff.md#installed-lua-ordinary-hash-view-result-guards) proof
and remaining independent backend work. Ordering and copy depth are retained;
backend initial-source policies and remaining contexts are listed there.

Initial-source permissions are separate from guards on already produced results.
These focused input examples preserve each backend's existing policy:

| Initial receiver example | Perl | Rust | Dart | Julia | Lua (installed) |
| --- | --- | --- | --- | --- | --- |
| `3.sorted_values()` or `undef.sorted_keys()` | `[]` | `[]` | `[]` | `[]` | `[]` |
| `[1].sorted_keys()` or `[1].sorted_values()` | initial source error (`Not a HASH reference`) | `[]` | `[]` | `[]` | `[]` |
| `undef.sorted_values().with(){return(value.count())}` | `0`; body runs | `0`; body runs | `0`; body runs | `0`; body runs | `0`; body runs |

Perl76.6 restores these initial-input behaviors after the earlier guard change.
Numeric `sorted_keys` sources also keep[] independently of unrelated numeric host
Hashes: `sorted_keys(3)`, `3.sorted_keys()` and `sorted_keys(length("abc"))` use
the evaluated DSL data. Actual Hashes still project ordered keys. Regenerate
affected emitted Perl. Rebuild Rust, Dart and Julia applications against their updated runtimes. Load the
updated Lua runtime in applications; emitted Lua module bytes remain unchanged.

Registered Hash-function results also compose on the focused-checked Perl, Rust,
Dart, Julia and installed PUC5.5.1/LuaJIT routes. With `fn make_hash(){return({"k":1})}`,
`make_hash().count_keys().add(1)` yields `2`, and
`make_hash().count_keys().cat(" keys").uppercase()` yields `"1 KEYS"`.
An incompatible `.take(effect)` returns null and skips `effect`; a following
`.copy().with(){return("ran")}` keeps that rejection. An explicit compatible bridge,
`make_hash().count_keys().with(){return([1,2])}.count()`, yields `2`.
Dart/Julia/installed Lua Boolean-function receiver terminal/composed results remain null/null;
Perl/Rust return0/1. Free `count_keys(make_bool()).add(1)` remains1 for a function
returning false. These are independently observed focused backend profiles;
declared Lua5.4 and full admission remain separate.

`rename_key` preserves a field's value while returning a new Hash. On Perl, this returns `[{"stage":"draft"},{"old_stage":"draft"}]`:

```text
meta = {"old_stage":"draft"};
out = rename_key(meta, "old_stage", "stage");
return([out,meta]);
```

A missing old key leaves the result contents unchanged; false and null field values remain false and null. For portable code, keep the destination key absent: [the helper catalog](../appendix/helper-contract-catalog.md#rename_keyh-old-new) records the existing backend-specific collision boundary.

Each `pick_keys` key belongs to that call and is evaluated in argument order. A later call can select different keys from the same snapshot; it does not inherit an earlier key. For example, `meta={"first":"b","rest":"ar"}; return([meta.pick_keys("first"),meta.pick_keys("rest"),pick_keys(meta,"first","rest")])` returns `[{"first":"b"},{"rest":"ar"},{"first":"b","rest":"ar"}]`. A computed key block runs once for its operand: `pick_keys(meta,{seen=num_add(seen,1);"first"},"rest")` increments `seen` once and retains both existing keys. The source Hash stays unchanged. Regenerate affected Perl parsers emitted before the per-key lowering repair; their generated source may contain repeated earlier keys.

On Perl, evaluated scalar inputs to `sorted_values` keep the existing empty Array fallback: `sorted_values(3)`, `sorted_values("3")` and `sorted_values(length("abc"))` return `[]`, independently of unrelated host hashes. The source is evaluated once. Actual Hash values still project values by sorted keys: `sorted_values({"b":"B","a":"A"})` returns `["A","B"]`. Produced-Length guards retain their own policy: both `"abc".length().sorted_values()` and `"abc".length().copy().sorted_values()` return null because that Number result rejects a Hash consumer. This does not define a universal wrong-kind policy or resolve absent/legacy binding behavior in other collection helpers. Regenerate Perl parsers emitted before the scalar-isolation or Hash-view guard repairs. Generated metadata and format v2 are unchanged.

### Hash-valued helper continuations: selected open repair

`merge_hash`, pure `set_key`, `rename_key`, `drop_keys` and `pick_keys` return
Hashes. Bounded Perl77.1.1, Rust77.2, Dart77.3, Julia77.4 and installed Lua77.5 now retain actual-kind and rejection
guards for their ordinary results; full source/context admission stays open.
Compatible examples:

```text
merge_hash({"a":1},{"b":2}).count_keys()                # 2
{"a":1}.rename_key("a","b").sorted_keys().join_values(",") # "b"
pick_keys({"b":"tail","a":"head"},"b").sorted_values().last().uppercase() # "TAIL"
pick_keys({"a":1},"missing").with(){return(value.count_keys())} # 0; body runs
```

The selected Perl, Rust, Dart, Julia and installed Lua program now returns `[null, ""]`. Its incompatible Array
consumer rejects before evaluating the `A` operand:

```text
order="";
out=pick_keys({"a":1,"b":2},"b").take({order=cat(order,"A");1});
return([out,order]);
```

Perl literal receiver forms now compile through the same guards. Rejection skips
later `.copy()`, logical and `.with()` operands/bodies, rather than becoming a
legitimate null that runs them. Required source/value producer errors propagate
through composed `.take()`/`.coalesce()` exactly as in their terminal controls.
All original48 Perl source/arity/error profiles remain: initial Number3 helper-with
keeps its Hash/count/W behavior, initial Array helper-with keeps its error, and
an earlier view/copy/Array-constructor result still rejects a Hash consumer before
its operands. Nested false/null values, source snapshots and valid empty Hash
with bodies retain their existing semantics. Independent peers assess their own
policies; these finite controls do not establish portable source authority.

Rust independently reproduces thirteen guard failures and preserves its own
source policies. The selected wrong-kind source controls retain overlay Hashes
for `merge_hash`, original Number/Array/null for `set_key`/`rename_key`/`drop_keys`,
and null for `pick_keys`. Their initial `with` bodies still run. Rust's selected
extra-argument and zero-key controls keep their original behavior; they do not
gain canonical guard authority. Earlier Count/CountKeys/Length/view/copy/Array
results retain their guards. Required source/value errors already propagated on
Rust and remain exact. Rebuild Rust applications/runtime; emitted source and
serialized format are unchanged. Use actual Hash inputs under the published
signatures; these preservation controls do not define portable fallback behavior.

Dart77.3 independently repairs thirteen guard gaps and preserves65 own source/
error profiles. Both original free and receiver wrong take forms returned `[]`
after running A; they now return null before that operand. Its own source controls
retain overlay Hashes for merge, original Number/Array/null for set/rename/drop,
and null for pick; initial with bodies still run. Required errors already
propagated and keep full native/restored diagnostics and generated framing.
Malformed extra/zero-key profiles and earlier result guards remain unchanged.
Rebuild Dart applications against the updated interpreter; actual emitted modules
and parsed inputs are unchanged. These finite controls establish no portable
wrong-kind policy or complete context admission.

Julia77.4 independently preserves the same selected initial Number/null/Array
source outcomes, with-body counts, malformed extra/zero-key profiles and prior
result guards. Its thirteen result guard gaps are repaired across native,
restored, generated-plan and fresh-module routes. Valid contextual `with` bodies
remain supported; explicit deferred operands and other callbacks gain no new role. Required errors keep their full
native diagnostics and generated framing. Scalar-result and mutation-loop rules
stay unchanged. Rebuild Julia applications/runtime; emitted and parsed formats
stay unchanged. Full context admission remains open.

Installed PUC Lua5.5.1 and LuaJIT independently repair the same thirteen selected
guard gaps while preserving each host's own initial source outcomes, with-body
counts, excluded extra/zero-key profiles and earlier result guards. Required
producer errors retain their runtime/generated flags and diagnostic framing.
The update preserves scalar and mutation rules. Load the updated Lua runtime in
applications; emitted and parsed formats stay unchanged. This focused outcome
does not establish the declared Lua5.4 target or full context admission.

Use at least one key for `drop_keys`/`pick_keys`; the four selected Perl zero-key
forms are unready profiles. Keep rename destinations absent for portable collision
behavior. Initial source policies, key splices, copy depth and `set_key` statement
or indexed mutation retain their existing contracts. See the
[backend handoff](../appendix/backend-handoff.md#selected-hash-valued-helper-result-guards)
for the bounded evidence and repair prerequisites.

Perl's bounded source-isolation77.0 repair now keeps the observed Number3,
String `"3"`, computed Number and merge-overlay controls independent of unrelated
host `%main::3` data on native/fresh routes. `merge_hash(3,{"b":2})` keeps its
existing `{ "b":2 }` fallback even with that host Hash populated. Number ASTs no
longer enter these five named-Hash shortcuts; computed non-reference sources get
a dereference barrier. Original Array errors and null/key branches remain: the
selected Number3 pick/drop controls run source/key effects `SK`, while null runs
only `S`. All48 original own policies remain exact. Regenerate Perl parsers
emitted before this repair; metadata and format v2 are unchanged. Use actual Hash
inputs under the published signatures. Bounded Perl composition77.1.1 is
focused-checked; broad source/isolation/portable admission remains separate.

`pick_keys` uses field existence, so requested false and null fields are retained while missing fields are omitted. For example, with `meta={"off":false,"nil":undef,"other":1}`, `pick_keys(meta,"off","nil","missing")` returns `{"off":false,"nil":null}` and leaves `meta` unchanged. `has_key(pick_keys(meta,"nil"),"nil")` remains true even though that stored value is null.

Examples:

```text
meta_count = count_keys(meta);
set(public_keys, sorted_keys(pick_keys(meta, "kind", "source", "stage")));
set(public_values, sorted_values(pick_keys(meta, "kind", "source", "stage")));
has_kind = has_key(meta, "kind");
set(layered, merge_hash(meta, hash("stage", "normalized")));
set(with_owner, set_key(layered, "owner", rule_name));
set(renamed, rename_key(with_owner, "old_stage", "stage"));
set(public_meta, drop_keys(renamed, "debug", "span"));
set(summary_meta, pick_keys(public_meta, "kind", "source", "stage"));
public_key_csv = meta.pick_keys("kind", "source").sorted_keys().join_values(",");
flat_count = meta.copy().flat_hash().count_keys();
set(layered, meta.merge_hash(hash("kind", "fallback")));
layered_kind = layered.pick_keys("kind").sorted_values().first();
summary_count = meta.drop_keys("debug", "span").count_keys();

tree = { "a" : "A", "b" : { "y" : "B" }, "arr" : ["u", "v"] };
mapped = tree.map_leaves() {
  leaf_text = if(count(value), join_values("", value), else(value));
  return(cat(join_values("/", path), "=", leaf_text))
};
leaf_count = tree.reduce_leaves(0) {
  return(acc.add(1))
};
```

Use `has_key(...)` when the question is "does this field exist?" Use `is_defined(meta.pick_keys("kind").sorted_values().first())` or `is_defined(retv["kind"])` when the question is "is the value defined?" Those are different questions.

Stored null and false values still have keys. On Perl, this returns `[1,1,0]`:

```text
meta = {"off":false,"nil":undef};
return([meta.has_key("off"),meta.has_key("nil"),meta.has_key("missing")]);
```

A missing-key result remains numeric zero for compatible text consumers: `meta.has_key("missing").coalesce_nonempty("late").cat("!")` yields `"0!"`. The fallback keeps zero because zero is data. Existence checks leave the Hash unchanged.

`set_key(...)` has two deliberate forms. As a statement with a named target, `set_key(meta, "stage", "normalized")` mutates the working hash `meta`. As a value expression, `set_key(meta, "stage", "normalized")` returns a new hash value and leaves `meta` unchanged unless you store the result with `set(meta, ...)`.

Hash receiver-dot value chains are accepted for the same pure hash helpers. The receiver is the first helper
argument, so `meta.set_key("stage", "normalized").count_keys()` maps to
`count_keys(set_key(meta, "stage", "normalized"))`. Hash-returning links can continue through more
hash helpers, and `sorted_keys()` / `sorted_values()` can continue through array receiver helpers such as
`join_values(...)`, `drop_front(...)`, and `first()`. For field reads from hash-returning receiver chains, assign
the chain result to a named hash and use `name.pick_keys(key).sorted_values().first()`. Direct bracket reads such as `retv["key"]`
are for scalar hashref payloads, not named working-hash value reads. Named mutation forms remain separate from receiver-dot pure composition:
`set_key(meta, key, value)` explicitly mutates the named harray. On Perl, `meta[key] = value` instead uses typed
path selection and yields the updated root snapshot; a string selector has the same field-update effect, while an
integer selector selects array. Receiver-dot `meta.set_key(key, value)` is a pure derived value unless assigned
back. A hash-yielding expression-valued block can enter the same family, for example
`{ { "b" : 2, "a" : 1 } }.sorted_keys().join_values(",")`.

Hash-tree traversal receiver blocks are the non-pure block-bearing part of the hash receiver family:

- `walk_leaves() { block }` visits leaves for side effects and returns the original hash tree.
- `map_leaves() { block }` returns a new hash tree whose leaves are the block results.
- `reduce_leaves(initial) { block }` evaluates `initial`, then folds each leaf by binding the current accumulator
  as `acc` and using the block result as the next accumulator.

A hash tree has a hash root. Nested hash values are interior nodes. Every non-hash value is a leaf, including
arrays. Traversal order is stable sorted-key depth-first order. For the tree
`{ "a" : "A", "arr" : ["u", "v"], "b" : { "y" : "B" } }`, the leaf paths are `a`, `arr`, and `b/y`.
During each callback the runtime binds scoped scalars:

| Binding | Meaning |
| --- | --- |
| `value` | current leaf value. |
| `key` | current leaf key. |
| `path` | array value containing root-to-leaf path segments. |
| `depth` | number of path segments (`count(path)`); a root leaf has depth 1. |
| `acc` | current accumulator, for `reduce_leaves` only. |

The scoped callback bindings are restored after each callback and after traversal completes. Ordinary side effects
to other working variables remain visible, so `walk_leaves()` is the side-effect traversal form. Calling any of the
three traversal methods on a non-hash receiver returns `undef` and does not execute the callback. `walk_leaves()`
and `map_leaves()` take no parenthesized arguments; `reduce_leaves(initial)` requires exactly one initial
accumulator argument. `walk_leaves()` and `map_leaves()` return hash values and can continue into later hash
receiver methods such as `.count_keys()`. `reduce_leaves(...)` returns the accumulator as a terminal value.

Array-tree traversal uses the same receiver method names on array-valued receivers. An array tree has an array root,
nested arrays as interior nodes, and scalar or hash leaves. Hash leaves are not traversed recursively. Traversal is
depth-first by zero-based index. Callback blocks get scoped `value`,
`index`, `path`, `depth`, and reduction-only `acc`. Empty arrays run no callbacks and
`reduce_leaves(initial)` returns `initial`; scalar receivers return `undef` without callbacks. `walk_leaves()` and
`map_leaves()` can feed array-family links such as `.count()`.

```text
items = ["a", ["b", "c"], { "h" : "H" }];
paths = [];

mapped = items.map_leaves() {
  return(cat(join_values("/", path), "=", value))
};

items.walk_leaves() {
  paths += join_values("/", path)
};

leaf_count = items.reduce_leaves(0) {
  return(acc.add(1))
};
```

### Five-backend `map_leaves!` receiver update

`binding_name.map_leaves!() { block }` is the mutating twin of `map_leaves()` on Perl, Rust, Dart, Julia, PUC Lua,
and LuaJIT. The receiver
must already exist as an harray or array and must be a bare uniform-binding name. The starting root kind chooses
the same traversal rule described above. Mapping reads a detached original-shape snapshot, uses each callback
result as the replacement leaf, commits the complete rebuilt receiver once, and returns a separate detached copy.

Callbacks receive detached `value`, `path` (also `@path` on Perl), `depth`, and root-kind-specific `key` or
`index`. Returning a
new aggregate replaces the current leaf but does not add new work to the traversal. Changing `value` without
returning it has no receiver effect.

```text
items = ["A", ["B"], { "opaque" : "C" }];

top_level_count = items.map_leaves!() {
  return(lowercase(value))
}.count();
```

For this array root, the strings are leaves and the harray is also one opaque leaf. All callbacks must succeed
before `items` changes. A callback may write unrelated bindings, but it may not directly write `items` by
assignment, nested path, nested bang, mutation helper, array-end method, or binding-target array pipeline. Such an
attempt raises `receiver_mutation_reentrant` before the write. A same-spelling parameter/local in a distinct scope
is a different identity and remains legal.

The receiver guard is released before fluent continuation. Therefore a continuation runs against the detached
updated value, and its later failure does not undo the already completed receiver commit. Lua carries this state
through native, reconstructed, generated-plan, emitted-module, primary-CLI, and user-function-body routes on both
ABIs. `map_leaves!(items)`, temporary or nested receivers, other bang methods, and arbitrary user-defined bang
functions are outside v1. `.19.7` admits the exact portable capability row, `.19.8` completes exact six-runtime
recurrence, and `.19.9` closes current public no-drift for the exact v1 surface.

The terse hash-index operator is the statement form written with the key next to the target:

```text
meta["stage"] = "normalized";
meta[cat("source", "_kind")] = kind;
meta[field_name] = field_value;
meta[field_name] = field_value;
```

These update the named working hash in place, exactly like `set_key(meta, key, value)`. In statement mutation
slots, bare key/RHS identifiers read scalar working variables. The expression form remains explicit:
`set_key(meta, key, value)` returns a copy instead of mutating `meta`.

## Fallback and presence helpers

Fallback helpers choose values. Presence helpers ask what shape or value is available.

| Helper | Meaning |
| --- | --- |
| `coalesce(value1, value2, ...)` | first defined value wins. |
| `coalesce_nonempty(value1, value2, ...)` | first defined nonempty scalar wins. |
| `is_defined(value)` | true when the value is defined, even if empty. |
| `is_undefined(value)` | true when the value is undefined. |
| `is_empty(value)` | true for undefined/empty scalar, empty array, or empty hash. |
| `is_nonempty(value)` | inverse convenience helper for nonempty values. |

Examples:

```text
name = coalesce(retv["name"], IMATCH, "UNKNOWN");
public_name = coalesce_nonempty(trim(name), "anonymous");
has_public_name = is_defined(public_name);
missing_kind = is_undefined(meta.pick_keys("kind").sorted_values().first());
has_items = is_nonempty(items);
no_public_meta = is_empty(pick_keys(meta, "kind", "source"));
```

Emptiness tests consume the yielded value: `is_empty(sorted_values(pick_keys(meta,"kind")))` is true when the projection has no values. Both projection and test leave `meta` unchanged. Empty text, Arrays and Hashes are empty; numeric `0`, String `"0"` and `false` are data. On the recorded Perl native/fresh routes, `return([is_empty([]),is_nonempty({}),is_empty("0"),is_nonempty(false)])` yields `[1,0,0,1]`. A computed source runs once, and its predicate result is captured before a later consumer changes that source. These value rules do not add a new normalization policy for unrelated condition paths.

Rationale:

- `coalesce(...)` keeps `0`, `""`, empty arrays, and empty hashes because they are defined.
- `coalesce_nonempty(...)` is for text fallback where blank text means "keep searching".
- `is_defined(...)` is not the same as `is_nonempty(...)`.
- `has_key(...)` is not the same as `is_defined(hash(...)[key])`.

Example:

```text
if(and(
  has_key(meta, "kind"),
  is_nonempty(meta.pick_keys("kind").sorted_values().first())
))
  return(hash("kind", meta.pick_keys("kind").sorted_values().first()));
else()
  return(hash("kind", "unknown"));
endif()
```

## Array pipelines

Array-pipeline helpers are statements or composable array-valued transformations for common token-list cleanup.

| Helper | Effect |
| --- | --- |
| `split(target, source, delimiter?)` | replace `target` with the pieces from splitting `source`. |
| `split_each(target, delimiter)` | split every current array item and flatten the result back into `target`. |
| `trim_each(target)` | trim every array item in place. |
| `filter_nonempty(target)` | remove empty string items. |
| `lowercase_each(target)` | apply the Unicode 17 full lowercase contract to every array item. |
| `uppercase_each(target)` | apply the Unicode 17 full uppercase contract to every array item. |
| `uniq(target)` | remove duplicates while preserving first-seen order. |
| `filter_match(target, /regex/)` | keep only items that match the regex. |
| `split_tagged_records(source, delimiter, tag, field...)` | build one tagged array record for each split source item. |

Worked example:

```text
Top::
 -> FieldList .push
 LX { return(copy(Top)) }

FieldList: /([A-Za-z_, ]+)/
 I {
   set(fields, []);
   raw = entry_group(0);
   split(fields, raw, /,/);
   trim_each(fields);
   filter_nonempty(fields);
   lowercase_each(fields);
   uniq(fields);
   return(hash(
     "kind", "field_list",
     "fields", copy(fields),
     "field_count", count(fields),
     "first_field", first(fields)
   ));
 }
```

Nested composition is useful when the transformation reads naturally as one expression:

```text
public_count = count(filter_match(fields, /^[A-Z_]+$/));
```

Standalone `split_each(name, delimiter)`, `trim_each(name)`, `filter_nonempty(name)`, `filter_match(name, regex)`, `lowercase_each(name)`, `uppercase_each(name)` and `uniq(name)` write their transformed items back to that working array.
In a value expression or receiver chain, the operation returns a transformed array and preserves its input binding.
Perl, Rust, Dart, Julia and Lua implement the statement forms; broader validation remains owned by `FUTURE-PARITY-BACKLOG.5.3.4` after feature coverage.

Receiver-dot form is equivalent for a named array or array-valued expression. Ordinary Perl values also accept dynamic scalar delimiters: `delimiter="."; return(split_each(["a.b","c.d"],delimiter))` returns `["a","b","c","d"]`. The source is snapshotted before the delimiter evaluates once; runtime scalar text is literal. The standalone form `split_each(items,delimiter)` validates/snapshots the target before evaluating the delimiter and writes the result back; a wrong target fails before delimiter effects:

```text
set(public_fields, fields.uppercase_each().uniq().filter_match(/^[A-Z_]+$/));
public_csv = fields.uppercase_each().uniq().filter_match(/^[A-Z_]+$/).join_values(",");
```

Ordinary Perl actions support `return(filter_match(["ax", "by"], /^a/))` and its receiver equivalent; both return `["ax"]`. Named/computed arrays, user-function parameters, nested helper arguments and compatible receiver continuations use the same pure filter behavior. Standalone bare-target calls retain write-back.
Quoted text follows the existing Perl receiver policy: `filter_match(["a.b","axb"], "a.b")` returns `["a.b"]`; slash regex literals retain their flags, such as `/^a/i`.
Pure nested function composition preserves the source:

```text
fields = ["a", "b", "a"]; out = uniq(uppercase_each(fields));
return([out, fields]);
```

This returns `[["A","B"],["a","b","a"]]`. Filtering and deduplication preserve selected value kinds in both value/receiver and standalone writeback forms: `uniq([2,"2"])` yields `[2]`, whose entry remains a numeric array selector. Element kinds follow the existing producer policy. In the observed Perl compatibility control, trimming an unchanged numeric entry preserves Number3; portable token-normalization examples here supply Strings. Deferred codeblocks retain their separately qualified helper vocabulary.

Ordinary selection on Perl, Rust, Dart, Julia and Lua can bridge back to scalar methods: `parts=[" A "," B "]; return(parts.last().trim().lowercase())` returns `"b"` and preserves `parts`. Similarly, `return([2,3].last().mul(4).sub(1))` returns `11`. Function parameters and computed sources use the same boundary, evaluated once; `[].first().trim()` returns `undef`. Selected containers continue too: `[[3,1],[2]].first().copy().sorted().last().add(4)` returns `7`; `[{"b":2,"a":1}].first().copy().sorted_keys().last().uppercase()` returns `"B"`. Copy and pure transforms preserve their source containers. Lua checks use available PUC5.5.1/LuaJIT; the declared PUC5.4 proof and complete fluent-family admission remain tracked separately. Bounded Rust source/null-operand repairs are implemented; complete scalar-helper domain/context admission remains separate. Use statement style when each step deserves a readable line. Use nested style when the operation is compact and local.

Use `split_tagged_records(...)` when a comma-separated identifier list should become repeated tagged payload rows:

```text
return(split_tagged_records(
  identifier_list,
  /\s*,\s*/o,
  "?signal_declaration:",
  subtype_indication,
  signal_kind,
  expression
))
```

For `identifier_list = "a, b"`, `subtype_indication = "integer"`, `signal_kind = "register"`, and
`expression = "0"`, the exact value is:

```json
[
  ["?signal_declaration:", "a", "integer", "register", "0"],
  ["?signal_declaration:", "b", "integer", "register", "0"]
]
```

The helper can initialize a working Array directly. This Perl action returns `[["?row:","A","wire","1"],["?row:","B","wire","1"]]`; the carried `"1"` stays text:

```text
identifier_list = "A,B";
kind = "wire";
expr = "1";
rows = split_tagged_records(identifier_list, /\s*,\s*/o, "?row:", kind, expr);
return(copy(rows));
```

The outer array holds all records; each inner array is one record, with no extra wrapper. Ordinary helper arguments (source, delimiter, tag and carried fields) evaluate once left-to-right before record construction, even if no records result; earlier values survive later rebinding.
The scalar receiver equivalent is `"a,b".split_tagged_records(",", "?item:").count()` → `2`, with text as input and an Array result that can feed selection and other Array methods. For carried Arrays, `"a,b".split_tagged_records(",","row",["x","y"]).last().last().last().uppercase()` returns `"Y"`.
Perl, Rust, Dart, Julia and Lua support the scalar bridge and retain their pure splitters’ trailing items: `" a,b ".trim().split_tagged_records(",","row").last().last().uppercase()` gives `"B"`. Carried Number/Bool/null/Array/Hash values retain their kinds and can feed compatible selected-value methods; malformed receiver calls with fewer than delimiter/tag reject before effects.
The bounded eager helper/scalar bridge is targeted-checked on all five runtimes (Lua on safe PUC5.5.1/LuaJIT; declared5.4 remains separately owned). Complete cross-backend empty-source/empty-delimiter/zero-width/variable-regex and contextual admission remain separate; do not infer a universal split policy from this example.

### Pipeline continuations: selected repair

The seven pure pipeline helpers above return transformed Arrays while preserving
source bindings. Ordinary Perl, Rust, Dart, Julia and installed Lua results now retain their actual kind through
subsequent methods, copy, logical operations and immediate `with`:

```text
trim_each([" tail "]).last().uppercase()       # "TAIL"
split_each(["head:tail"],":").join_values(",")  # "head,tail"
filter_nonempty([""]).with(){return(value.count())} # 0; body runs
uniq(["head","head"]).set_key("k",1)           # null
[" tail "].trim_each().set_key("k",1)          # null; compiles cleanly
```

An incompatible Hash consumer returns null before evaluating its operands.
Rejection persists through later copy, logical operands and `with` bodies. For
example, this program returns `[null,""]` in Perl, Rust, Dart, Julia and installed Lua:

```text
order="";
out=uniq(["tail","tail"]).set_key(
  {order=cat(order,"K");"k"}, {order=cat(order,"V");1}
).copy().with(){order=cat(order,"W");return("ran")};
return([out,order]);
```

The producer runs first, preserving required source and delimiter errors. A
Perl receiver `split_each` with an erroring computed delimiter now forwards that
original error through its consumer chain. On Perl, balanced invalid regexes still
fail at regex compilation before consumer execution. Earlier guarded prefixes retain
their rejection, and valid empty Arrays enter `with` normally.

This bounded Perl repair covers canonical `split_each`, `trim_each`,
`filter_nonempty`, `lowercase_each`, `uppercase_each`, `uniq` and `filter_match`.
Initial producer fallback, excluded arities, regex/Unicode, copy/mutation and
standalone writeback keep their existing policies. Each backend is assessed independently; full source/context/portable admission
remains open.

Rust covers the same seven canonical producers on native execution, restored
compiled specifications, generated plans and compiled emitted modules. Its
initial Number/null/Hash sources still yield empty Arrays, and immediate `with`
bodies run on those Arrays: `trim_each(3).with(){return(value.count())}` returns
`0`. Earlier guarded Number/Hash results still reject incompatible Array work.
Required source/delimiter errors retain their original diagnostics. Rust's
`filter_match(["head"],/[z-a]/)` still warns and returns `[]`; a subsequent
`.set_key("k",1).coalesce("masked")` now returns null after rejection. Missing
and excess arities retain their previous behavior and gain no new authority.
Rebuild Rust applications to obtain these runtime guards; compiled-spec and
emitted-source formats are unchanged.

Dart also covers the same canonical seven helpers on native execution, restored
specifications, generated plans and compiled emitted modules. Initial Number/null/
Hash sources keep their empty Arrays and enter immediate `with` bodies normally.
Required source/delimiter errors retain their structured runtime diagnostics.
An invalid-range `filter_match` still quietly returns `[]` on Dart; a following
`.set_key("k",1).coalesce("masked")` now returns null after rejection. The acquired excess free
arguments retain their previous unevaluated behavior, while the acquired receiver
extras keep their effects; neither form gains canonical authority. Rebuild Dart
applications for these runtime guards; emitted and serialized formats stay stable.

Julia covers these canonical results on native execution, restored specifications,
generated plans and fresh emitted modules. Initial Number/null/Hash sources keep
their empty Arrays and immediate `with` behavior. Both free and receiver excess
arguments retain their acquired evaluation effects. Required source/delimiter
errors keep their original diagnostics. Terminal invalid-range `filter_match`
still quietly returns `[]`; an incompatible Hash continuation now returns null
before operands, coalesce and later bodies. Existing contextual `with` remains
supported; deferred callback authority is unchanged. Rebuild Julia applications
for these runtime guards; parsed and emitted formats remain stable.

Installed Lua (PUC5.5.1 and LuaJIT) also guards these seven canonical results on
native execution, restored specifications, generated plans and fresh emitted
modules. Initial Number/null/Hash inputs retain empty Arrays and enter immediate
`with`; acquired excess arguments retain their effects. Required source,
delimiter and computed pattern-operand errors propagate before consumers. For
example, `filter_match(["head"],{items="bad";items+=1;"^head"})` still reports the
binding-kind error; a later `.set_key("k",1).coalesce("masked")` cannot hide it.
The known native malformed-regex diagnostic defect remains separately owned;
these safe checks use valid pattern text. Earlier guarded prefixes, source
snapshots, nested kinds and standalone writeback stay intact. Reload applications
with the updated Lua SDK; declared PUC5.4 and full native admission remain open.

Perl also supports the existing seven canonical pipelines on valid registered
function results through guarded consumers, copying, logical continuations and
`with`. The source runs once. An incompatible Hash consumer rejects before its
key/value operands and skips later continuations, while preserving source effects.
This tested form returns `[null,"S"]` with a ready full-source descriptor:

```text
fn supply(seed) {return(seed)}
Value:: I {
  order="";
  out=supply({order=cat(order,"S");[" tail "]}).trim_each().set_key(
    {order=cat(order,"K");"k"}, {order=cat(order,"V");1}
  ).copy().with(){order=cat(order,"W");return("ran")};
  return([out,order]);
}
```

The ordinary `trim_each(supply(...))` spelling remains supported. Compatible
receiver chains retain their value kinds. Initial Number/null/Hash results retain
Perl's empty-Array producer policy and still enter an immediate `with`; rejecting
a later consumer is distinct from rejecting the original function result.
Existing valid variadic functions also work: `fn all_values(...values) {return(values)}`
permits `all_values().trim_each()` (empty Array) and
`all_values(" head "," tail ").trim_each()` (`["head","tail"]`). Invalid fixed or
variadic signatures retain their previous rejection and unready descriptor;
result guards do not turn an invalid call into a valid empty Array.

Required source/delimiter errors and literal regex errors keep their original
provenance before consumer operands or later bodies. Existing terminal pattern
normalization remains unchanged: composed String/bare/block pattern observations
may gain canonical readiness without gaining eager pattern execution. Use the
documented regex operand syntax; computed DSL blocks are not an admitted eager
Perl `filter_match` pattern contract. Matching payloads alone do not establish
readiness. Regenerate older emitted Perl modules for these compiler guards.
This focused Perl repair makes no peer verdict; independent backends and full
source/context/native admission remain separate. Native Lua malformed-pattern
handling and declared PUC5.4 admission remain separately qualified.

Perl rejects malformed first pipeline calls on registered-function receivers
before source/operand effects or later continuations. Missing binary operands or
excess arguments yield null with an unready descriptor naming the public helper;
they no longer leave DSL or undefined private-helper calls in generated handlers.
Given `fn supply(seed) {return(seed)}`, `supply({order=cat(order,"S");["x"]}).split_each().with(){return("ran")}` skips S and the body.
Canonical receiver arities remain zero for `trim_each`, `filter_nonempty`,
`lowercase_each`, `uppercase_each` and `uniq`, and one delimiter/regex operand for
`split_each`/`filter_match`. Terminal function forms provide the rejection oracle;
malformed composed function forms remain unadmitted. Regenerate older emitted Perl.

Rust now preserves callable pipeline guards through later `with`, copying and
logical continuations too. Its original producer still runs once, and a rejected
Hash consumer skips its operands and later bodies. For example, this valid
variadic call returns `[null,"S"]`:

```text
fn all_values(...values) {return(values)}
Value:: I {
  order="";
  out=all_values({order=cat(order,"S");" head "}," tail ").trim_each().set_key(
    {order=cat(order,"K");"k"}, {order=cat(order,"V");1}
  ).with(){order=cat(order,"W");return("ran")};
  return([out,order]);
}
```

Valid empty function results still enter an immediate `with`; a later incompatible
consumer has a separate rejection boundary. Existing fixed/rest arity errors and
required source/delimiter/pattern errors propagate before consumer work, retaining
Rust's native/restored text and generated-parser wrapper. Noncanonical pattern
observations retain their existing producers without broader pattern admission;
use the documented regex operands. Rebuild Rust applications. Serialized/emitted
formats, pure function scope and other backends' independent qualifications stay.

Dart supports these registered-function pipeline continuations too: the variadic
example above returns `[null,"S"]`, preserving the caller's source effect while
skipping K/V and the later body. Initial non-Array producer fallbacks and valid
empty-Array `with` behavior remain unchanged. Required source/delimiter/pattern
errors keep their native diagnostics and generated source attribution; later
`coalesce` cannot hide them. Invalid fixed/rest calls retain their invocation
errors. Existing excess-argument behavior is excluded from the canonical contract;
portable code uses the documented arities. Noncanonical pattern observations gain
no broader admission. Rebuild Dart applications; parsed/emitted formats stay.

Julia also retains guards after canonical registered-function pipeline results,
including later copying, logical continuations and `with`. Existing variadic
functions keep their invocation rules: with `fn all_values(...items) {return(items)}`,
`all_values().trim_each()` still yields an empty Array. A later incompatible Hash
consumer rejects before its operands or subsequent bodies, while preserving the
caller's source effects. Genuine empty Arrays still enter an immediate `with`;
initial non-Array producer fallbacks retain Julia's original empty-Array policy.
Needed source/delimiter/pattern errors keep their native and generated provenance,
and invalid fixed/rest signatures retain their invocation errors. Use canonical
arities and documented regex operands; String/bare/block compatibility observations
add no broader pattern or callback admission. Reload the updated Julia runtime
and rebuild deployed applications; parsed/emitted formats remain unchanged.

Installed PUC Lua5.5.1 and LuaJIT also support these canonical callable pipeline
continuations. Valid empty variadic results remain empty Arrays; a wrong Hash
consumer rejects before K/V and later copying, logical or `with` work, preserving
source effects. Initial non-Array fallbacks, immediate empty-Array `with` and
existing fixed/rest invocation errors keep Lua's own behavior. Native errors keep
their diagnostic stage and outer helper/arity metadata; generated failures keep
source attribution. Needed pattern errors are checked with valid text after a
DSL binding error. String/bare/block pattern observations retain empty Arrays
and existing block effects, without broader pattern or callback admission; use
the documented regex syntax. Reload the updated Lua SDKs. Parsed/emitted formats
stay unchanged, while malformed native-pattern handling and declared PUC5.4
remain separately owned and unadmitted.

Perl source79.0 also sends literal Number sources through the existing computed
actual-Array fallback. `trim_each(3)` and its receiver counterpart yield an empty
Array rather than reading unrelated host Array data. Genuine Array sources and
computed values retain their existing behavior. Portable programs supply Arrays.
Regenerate older emitted Perl to obtain the source and result fences.

## Boolean composition

Boolean helpers make branch conditions portable and analyzable. Perl, Rust, Dart, Julia and safe Lua hosts (PUC5.5.1/LuaJIT) support `value.and(rhs,...)` and `value.or(rhs,...)` with at least one RHS, plus `value.not()` with none, using the same eager typed truth and real Boolean results: `false.or(true).not().coalesce("late").cat("!")` gives `"0!"`. Full method/domain/context admission and declared Lua5.4 proof remain separate; the free helper forms below retain their existing contracts. Ordinary scalar/null copying now preserves the actual value on those bounded routes; see [Copying values](#copying-a-container-stored-in-a-scalar-on-perl). Existing container-copy depths and separate full-admission qualifications remain.

| Helper | Meaning |
| --- | --- |
| `and(condition, condition, ...)` | all conditions must pass. |
| `or(condition, condition, ...)` | any condition may pass. |
| `not(condition)` | invert one condition. |

ADR `0043` adopts the portable target: these are eager boolean value helpers. `and` and `or` require at least one
positional argument; `not` requires exactly one. An invalid call fails with `helper_arity_mismatch` before any
argument runs. On a valid call, every argument evaluates exactly once from left to right—even an operand after the
result is already known—and the result is a real boolean. A one-argument `and(value)` or `or(value)` is therefore
an explicit boolean projection. Empty `and()`/`or()` are diagnostics, not mathematical identity values.

The target truth table is typed rather than inherited from a host:

| Value | Target truth |
| --- | --- |
| `undef`, `false` | false |
| numeric zero, including `-0.0` | false |
| any other finite number | true |
| empty string `""` | false |
| every nonempty string, including `"0"`, `"false"`, whitespace, and Unicode | true |
| empty array or harray | false |
| nonempty array or harray, even when its only value is `undef` | true |
| codeblock value | true, without invoking it |

The codeblock row defines value-kind semantics; it does not activate the separately planned first-class
`{|...| ... }` literal syntax. Backends can lock that row at their typed runtime boundary while generic literal
admission remains under `FUTURE-PARITY-BACKLOG.11`.

Logical helpers are distinct from lazy structured or inline `if`/`switch` and loop control. Those controls use
the same target truthiness for conditions but execute only the selected branch or body. Use a control when later
side effects must be skipped; use `and`/`or` when all operand effects must occur.

Current implementation status (2026-07-17):

| Backend | Current evaluation | Empty `and/or/not` | `"0"` / `"false"` truth | Empty aggregates |
| --- | --- | --- | --- | --- |
| Perl | eager once left-to-right; lazy controls share truthiness but select one branch/body | diagnostic / diagnostic / diagnostic | true / true | false |
| Rust | eager once left-to-right; lazy controls share truthiness but select one branch/body | diagnostic / diagnostic / diagnostic | true / true | false |
| Dart | eager once left-to-right; lazy controls share truthiness but select one branch/body | diagnostic / diagnostic / diagnostic | true / true | false |
| Julia | eager once left-to-right; lazy controls share truthiness but select one branch/body | diagnostic / diagnostic / diagnostic | true / true | false |
| Lua | eager once left-to-right; lazy controls share truthiness but select one branch/body | diagnostic / diagnostic / diagnostic | true / true | false |

All five native backends now share the target evaluation, arity, and truth table. Planning audit `.5.2.0`
dependency-orders neutral policy, five backend repairs, generated/primary projection, a recurring gate, and public
no-drift under `.5.2.1-.9`. Neutral policy `.5.2.1` is now executable as
`linkedspec-logical-helper-v1`: 17 truthiness rows, ten helper cases, three eager-effect scenarios, four arity
failures, deterministic fixtures, and 22 semantic/topology drift mutations pass offline. Perl `.5.2.2` now represents logical calls
as typed ActionIR and lowers native/live/standalone-emitted execution through `LinkedSpec::RuntimeLogical`, with
pre-effect arity failure, eager once-only operands, real booleans, and one typed condition/helper seam. Rust
`.5.2.3` now applies the same truth and arity policy through `RuntimeValue::as_bool` across native, serialized,
generated-plan, direct-value, and compiled emitted roles. Dart `.5.2.4` shares `runtimeLogicalTruth` across helpers
and controls, validates arity before effects, and proves native, normalized, generated-plan, standalone-emitted,
and primary roles. Julia `.5.2.5` preserves `_runtime_truthy` plus eager composition, validates arity before
effects, and proves native, normalized, generated-plan, standalone-emitted, and primary roles. Lua `.5.2.6`
aligns `runtime_truthy`, validates arity before effects, and proves native, reconstructed, generated-plan, loaded
emitted-module, and primary roles on both PUC Lua and LuaJIT. Generated/primary `.5.2.7` now locks every available
direct/traced generated role, exact typed failure/source attribution, Rust's direct-value versus compatibility-
output distinction, and shared five-command case `success_logical_helpers_eager` under default and POSIX options.
Recurring `.5.2.8` locks the neutral checker, six exact native/generated runtime consumers, selected 5x2x1
primary case, and generated-source/capability/coverage ledgers under one strict driver. Public no-drift `.5.2.9`
locks this truth table, the action/value guides, every backend README, status/capability/CLI guidance, and the
Knowledge Map. Rollout is 8 complete / 0 pending and parent `.5.2` is closed, with no known native or generated
truthiness split.

When all five backend toolchains are installed, run the complete recurring logical proof with:

```bash
bash tools/check_logical_helper_five_backend.sh
```

The driver requires Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT, builds disposable Lua native adapters, and fails
on any missing native/generated role, primary projection, or support ledger. Canonical local CI exposes the same
all-toolchain leg behind `LINKEDSPEC_RUN_LOGICAL_MATRIX=1`; ordinary local CI still audits the tracked driver and
its shell syntax.

Examples:

```text
if(and(
  has_key(meta, "kind"),
  str_eq(lowercase(trim(meta.pick_keys("kind").sorted_values().first())), "node")
))
  return(hash("kind", "node"))
endif()

if(or(
  str_eq(kind, "word"),
  str_eq(kind, "identifier"),
  matches(kind, /^name_/)
))
  return(hash("kind", "named"))
endif()

if(not(is_empty(items)))
  return(hash("kind", "items", "items", copy(items)))
endif()
```

Prefer helper conditions over raw host-language boolean expressions. The helper form gives the compiler one explicit expression tree to lower, inspect, and port.

Target-value examples once the pending backend rollout completes:

```text
string_flag = and("0")       # true: nonempty string
empty_items = not([])        # true: empty array is false
all_ready = and(check_a(), check_b())
```

Both `check_a()` and `check_b()` run once in the last call, even if `check_a()` is false. For lazy behavior, write
an `if(check_a()) { ... }` branch instead. `and()`, `or()`, `not()`, and `not(a, b)` fail before evaluating an
operand.

## Structured `if` flow

Use marker-style `if` flow when the branch body is more than a trivial expression.

| Helper | Meaning |
| --- | --- |
| `if(condition)` | open the first branch. |
| `i(condition)` | short alias for `if(condition)`. |
| `elseif(condition)` | open a later conditional branch. |
| `elif(condition)` | short alias for `elseif(condition)`. |
| `else` / `else()` | open the fallback branch. |
| `endif` / `endif()` | close the flow. |

Example:

```text
if(is_undefined(meta.pick_keys("kind").sorted_values().first()))
  set(meta, set_key(meta, "kind", "unknown"))
elseif(str_eq(lowercase(trim(meta.pick_keys("kind").sorted_values().first())), "word"))
  set(meta, set_key(meta, "normalized_kind", "word"))
else
  set(meta, set_key(meta, "normalized_kind", "other"))
endif

return(copy(meta));
```

Inline composite `if(...)` and `switch(...)` are portable value-producing helpers for compact cases in
`return(...)`, assignment RHS, and fluent `.return(...)` value slots. They evaluate only the selected payload
branch. Use marker or attached-block flow when branches contain multiple statements or read better as
statement control.

```text
set(result,
  if(is_nonempty(items),
    hash("kind", "items", "items", copy(items)),
    else(undef)
  )
)
```

Use the marker form when branches contain multiple statements, nested flow, or should be visibly statement
oriented. Inline value control is the shorter portable form for single-expression branch payloads.

Attached-block form is also portable. It lowers to the same marker flow and supplies the closing
`endif` implicitly (the parenthesized `endif()` twin is also valid):

```text
if(is_nonempty(items)) {
  return(hash("kind", "items", "items", copy(items)))
} else {
  return_undef()
}
```

For attached blocks, `when(condition) { ... }` is a readable alias for the first `if` branch and
`otherwise { ... }` is a readable alias for the fallback `else` branch:

```text
when(matches(kind, /^node_/)) {
  return(hash("kind", "node", "text", kind))
} otherwise {
  return(hash("kind", "other", "text", kind))
}
```

## Inline value-control flow

Inline `if(...)` and `switch(...)` are portable value expressions when simple branch payloads need to feed
`return(...)`, an assignment RHS, or fluent `.return(...)`. They evaluate only the selected payload branch. Ordinary Perl direct methods already work: `if(true,["a","b"],[]).last().uppercase()` returns `"B"`. Ordinary Perl, Rust, Dart, Julia and Lua (available PUC5.5.1/LuaJIT) also support direct brackets: `if(true,["a","b"],[])[-1].uppercase()` returns `"B"`, and `switch("k",case("k",{"items":["a","b"]}),default({}))["items"][-1].uppercase()` returns `"B"`. The selected source is captured once before left-to-right selectors; missing paths yield undef while later selectors still run. Compatible methods use the selected value's actual kind and incompatible consumers skip their operands. Named bindings remain equivalent. This applies to inline value calls; statement headers, marker aliases and deferred callable vocabularies keep their existing boundaries. Declared Lua5.4 and full admission remain separate. Ordinary Perl inline `if`/`elseif` conditions accept eager value blocks and typed predicates: `if({touched="yes";false},"bad",elseif(is_defined(false),"defined"),else("bad"))` selects `"defined"` and leaves `touched` as `"yes"`. Conditions run once in branch order; only the reached payload runs, and block returns stay local. This also preserves the distinction between a false value and a missing value: `is_defined(false)` is true. Branch payload blocks and eager `switch` subjects keep the same value/block rules.
Perl callable bodies also execute attached and marker branches, including nested local returns. Conditions
use the same truthiness and skip unselected bodies. A statement conditional yields null unless
an explicit return exits the callable; an eager expression block keeps its own return boundary.
See the [complete callable examples](../architecture/structured-format-program.md#current-perl-deferred-conditional-boundary).
Callable value `if` also preserves the selected payload and laziness, including ordered `elseif`
arms and wrapped or plain final fallback. In these callable bodies,
`return()`/`return_undef()` now exit with null; eager blocks keep a local return boundary.
Attached while also executes in Perl callables with the existing guarded statement/local-return
semantics. `return(undef)` continues to work.

Use attached-block control flow when a branch needs substantial statement bodies or repeated side effects.
The short `i`/`elif` spellings are statement-marker aliases, while `when`/`otherwise` are attached-block aliases;
they are not alternate names for these inline value helpers. Some backends currently accept the aliases in the
opposite statement shape as an extension, but Rust does not; portable specs use only the documented pairing until
`FUTURE-PARITY-BACKLOG.5` normalizes acceptance.

| Helper | Meaning |
| --- | --- |
| `if(cond, then_value, branches...)` | evaluate `cond`; return `then_value` when true, otherwise choose an `elseif(...)`, `else(...)`, or plain third fallback. |
| `elseif(cond, value)` | additional inline `if` branch. |
| `else(value)` | fallback inline `if` branch. |
| `switch(value, branches...)` | evaluate `value` once and choose the first matching branch; a bare switch subject reads a working scalar. |
| `case(value, body)` | one equality case; a bare case value such as `case(foo, body)` is the literal tag `foo`, not a scalar read. |
| `default(body)` | fallback branch. |

Inline `if` example:

```text
return(if(
  is_nonempty(flag),
  cat("prefix-", flag),
  else("missing")
))
```

The plain third-argument fallback is also accepted for Rust-compatible compact forms:

```text
set(out, if(false, "bad", "fallback"))
```

Inline `switch` example:

```text
return(switch(
  lowercase(trim(kind)),
  case("word", hash("kind", "word", "text", text)),
  case("space", hash("kind", "space", "text", text)),
  default(hash("kind", "unknown", "text", text))
))
```

Bare switch subjects and bare case labels intentionally mean different things:

```text
set(kind, "word")
set(other, "space")
return(switch(
  kind,
  case(word, "literal tag matched"),
  case(cat(other, ""), "dynamic expression matched"),
  default("unknown")
))
```

Here `kind` reads the scalar working variable, while `case(word, ...)` matches the literal tag
`"word"`. `case(cat(other, ""), ...)` evaluates `other` as a value expression. Prefer quoted strings such as
`case("word", ...)` when teaching fixed labels; the bare-label form is kept for parity with attached
`case(word) { ... }` labels.

Switch equality is currently portable for normalized scalar text and for null versus empty text. Do not rely on
boolean/number cross-kind or aggregate comparisons yet: Perl, Rust, and Lua make `false` match numeric zero while
Dart and Julia do not; Perl and Lua exclude arrays/harrays from scalar comparison, Rust collapses them to empty
text, and Dart/Julia retain host container spellings. Normalize those subjects explicitly before `switch` until
`FUTURE-PARITY-BACKLOG.5` fixes one typed-equality contract.

Expression-valued branch blocks are allowed in selected branches:

```text
return(if(
  true,
  { set(text, "branch"); return(text) },
  else("fallback")
))
```

Perl-reference condition truthiness treats null, false, numeric zero, `""`, and `"0"` as false. Array and harray
values are references and therefore true even when empty. Lua follows that reference boundary. Rust currently
also treats `"0"` as false but treats empty aggregates as false; Dart and Julia treat every non-empty string as
true and empty aggregates as false. Until `FUTURE-PARITY-BACKLOG.5` selects and locks one six-backend truth table,
portable conditions should use explicit predicates such as `is_empty`, `is_nonempty`, `is_defined`, and numeric
or string comparisons at those disputed boundaries.

Use attached-block `switch` for portable branch logic:

```text
switch(kind) {
  case("word") {
    return(hash("kind", "word", "text", text))
  }
  case("space") {
    return(hash("kind", "space", "text", text))
  }
  default {
    return(hash("kind", "unknown", "text", text))
  }
}
```

The attached statement form is implemented on Perl, Rust, Dart, Julia, and Lua. It uses first-match semantics and
runs `default` only when no case matched.

Marker-delimited switch is the equivalent statement-range form:

```text
switch(kind)
case(word)
  return(hash("kind", "word", "text", text))
endcase
case(space)
  return(hash("kind", "space", "text", text))
endcase
default
  return(hash("kind", "unknown", "text", text))
endswitch
```

The subject evaluates once. `endcase` is optional when the next same-depth marker already bounds the branch;
nested marker switches keep their own `endswitch` boundary. The parenthesized spellings remain valid, and all five
current backends implement both forms.
Keep every executable statement inside a `case/default` range. Perl currently executes ordinary statements before
the first branch or after `endcase()`, while Rust, Dart, Julia, and Lua skip them; backlog `.5` owns normalization.

Use `switch(...)` when the rule is classification-by-one-value. Use `if(...)` / `elseif(...)` when each branch asks a different question.

## Attached `while` flow

All five current backends accept attached-block `while` for repeated statement bodies. The condition is evaluated
before each iteration, and body statements can update the values used by the next condition:

```text
set(count, 0);
while(num_lt(count, 3)) {
  set(count, num_add(count, 1));
}
return(count);
```

`return(expr)` inside the loop returns from the surrounding action; inside an expression-valued block it remains
local to that block. The default deterministic guard is 10000 body executions. Perl, Rust, and Lua recheck the
condition after the final allowed body and succeed if it has become false; Dart and Julia currently throw at that
boundary. Avoid `next()` inside portable loop bodies too: Perl/Lua continue the inner loop, Rust treats it as a
no-op, and Dart/Julia propagate it to rule repetition. `FUTURE-PARITY-BACKLOG.5` owns both normalizations.

In Perl callable bodies, attached while follows that same condition-before-guard-before-body
order and local return boundary. A loop statement itself yields null; preceding body effects
survive guard failure, and fixed/rest parameter slots restore. The private typed error includes
the while-node span and the exact completed-body count. See the
[executed callable loop examples](../architecture/structured-format-program.md#current-perl-callable-while-boundary).
Numeric helpers in deferred Perl bodies remain a separate repair; use the supported
matching/string helper examples there to isolate loop execution.

## Debug output helpers

`say(...)`, `print(...)`, and `print_each(...)` are statement helpers for simple diagnostic output in rule actions.

| Helper | Effect |
| --- | --- |
| `say(value, ...)` | concatenate one or more values and add one trailing newline. |
| `print(value, ...)` | concatenate one or more values without adding a newline. |
| `print_each(target, prefix, suffix?)` | emit `prefix + item + suffix` for every array item; omitted suffix is empty text. |

Examples:

```text
say("normalized kind: ", kind)
print("token=", text, " kind=", kind, "\n")
print_each(matches, "match:<<", ">>\n")
```

Use `print_each(...)` when debug output should walk an accumulated array. It is the helper-form replacement for raw Perl loops such as `print "...$_..." foreach (@matches)`.

ADR `0042` and `capability_conformance/diagnostic_output_contract.json` now ratify the portable target before
backend repair. Arity is checked before evaluation: `print`/`say` require one or more positional arguments and
`print_each` requires exactly two or three. A valid call evaluates every argument exactly once from left to right,
then returns null without placing messages in rule accumulators or parse-result output. Strings remain unchanged,
booleans render as `1`/`0`, finite numbers use the portable shortest decimal spelling, and null/array/harray/
codeblock fragments render as empty text for these diagnostic helpers. That last rule is diagnostic-specific and
does not change `cat`'s whole-expression null propagation.

Output routing is caller-owned and quiet by default. A native sink receives synchronous
`RuntimeDiagnosticOutputEvent` values with exactly `helper_name`, current `rule_label`, and Unicode `message`.
`print` and `say` group one event per call; `print_each` groups one per array item and evaluates its decoration only
once per call. Empty-array and wrong-kind targets emit no event after valid-call arguments evaluate. A sink failure
propagates unchanged and stops later items/actions; an event before `exit_now(status)` is delivered before the
typed exit stops everything later. Generated entrypoints must propagate the same per-invocation sink. Primary
commands install none, add no diagnostic-output option, and keep rich events out of ADR `0024`'s separate phase
trace.

The Perl native parser returned by `LinkedSpec::Get` now accepts its sink in the optional second invocation
argument:

```perl
my @events;
my $input = "xx";
my $value = $parser->(
  \$input,
  { diagnostic_sink => sub { push @events, $_[0] } },
);
```

Every callback argument is a `LinkedSpec::RuntimeDiagnosticOutputEvent` hash object with exactly the three
contract fields. Sink exceptions and `LinkedSpec::RuntimeExitNow` propagate out of the parser unchanged; neither
is converted to a structural parse value or ordinary parser `last_error`. Omitting the second argument, or its
`diagnostic_sink`, remains quiet. Lua exposes its corresponding native form through the invocation options:

```lua
local events = {}
local result = linkedspec.runtime_parse(engine, input, {
  diagnostic_sink = function(event)
    events[#events + 1] = event
  end,
})
```

Lua restores the exact caller-thrown sink value after internal rule/action unwinding, including a public
`RuntimeInterpreterException`; `is_runtime_exit_now(error)` distinguishes the separate `RuntimeExitNow` control
object and its `status` from ordinary runtime diagnostics. `runtime_parse`, `runtime_execute`, and both traced
aliases preserve the same event/failure/exit behavior.

Rust exposes the same native event boundary for top-rule and direct-value execution:

```rust
use linkedspec_runtime::{RuntimeDiagnosticOutputEvent, RuntimeDiagnosticOutputSink};
use std::{cell::RefCell, convert::Infallible, rc::Rc};

let events = Rc::new(RefCell::new(Vec::<RuntimeDiagnosticOutputEvent>::new()));
let captured = Rc::clone(&events);
let sink = RuntimeDiagnosticOutputSink::new(move |event| {
    captured.borrow_mut().push(event);
    Ok::<(), Infallible>(())
});

let output = engine.execute_with_diagnostic_output("input", Some(&sink))?;
let value = engine.execute_value_with_diagnostic_output("input", &options, Some(&sink))?;
```

Passing `None` stays quiet. `RuntimeDiagnosticOutputExecutionError` keeps ordinary structured
`RuntimeExecutionError`, the caller's concrete sink failure, and `RuntimeExitNow { status }` in separate variants;
event text never enters native trace.

Dart exposes the same native boundary directly on its parse and traced aliases:

```dart
final events = <RuntimeDiagnosticOutputEvent>[];
final result = engine.parse(
  input,
  diagnosticOutputSink: events.add,
);
```

`RuntimeDiagnosticOutputEvent` exposes `helperName`, `ruleLabel`, and `message`, with exact snake-case keys from
`toJson()`. Omitting `diagnosticOutputSink` is quiet. If the callback throws, Dart restores the exact object and
stack instead of letting action or runtime wrappers reinterpret it; `RuntimeExitNow.status` is the separate typed
immediate-exit outcome. `parse`, `execute`, `parseWithTrace`, and `executeWithTrace` accept the sink.

Julia exposes the sink as an optional keyword on its native parse and traced aliases:

```julia
events = RuntimeDiagnosticOutputEvent[]
result = runtime_parse(
    engine,
    input;
    diagnostic_output_sink = event -> push!(events, event),
)
```

Each event exposes `helper_name`, `rule_label`, and `message`; `to_json(event)` returns the exact neutral record.
Omitting `diagnostic_output_sink` is quiet. Callback failures retain exact object identity through Julia's
action/runtime wrappers, and `RuntimeExitNow.status` is separate immediate control. `runtime_parse`,
`runtime_execute`, `runtime_parse_with_trace`, and `runtime_execute_with_trace` accept the sink.

Generated modules expose the same invocation-local channel without changing their existing sinkless signatures.
The host-language shape stays idiomatic:

```perl
# Independently emitted Perl package
my @events;
my $value = GeneratedParser::Execute(
  \$input,
  { diagnostic_sink => sub { push @events, $_[0] } },
);
```

```rust,ignore
// Independently emitted Rust module
let value = generated_parser::execute_with_diagnostic_output(
    input,
    Some(&sink),
)?;
let traced = generated_parser::execute_with_trace_and_diagnostic_output(
    input,
    trace_config,
    Some(&sink),
)?;
```

Rust uses paired functions because its existing `execute(input)` and `execute_with_trace(input, config)`
signatures cannot acquire an optional argument. Compatibility generated roles likewise expose
`parse_with_diagnostic_output` and `parse_with_trace_and_diagnostic_output`. All four return
`GeneratedDiagnosticOutputExecutionError`, whose generated-source, compatibility, caller-sink, and immediate-exit
variants remain distinct.

```dart
// Independently emitted Dart library
final value = execute(
  input,
  diagnosticOutputSink: events.add,
);
final traced = executeWithTrace(
  input,
  traceConfig,
  diagnosticOutputSink: events.add,
);
```

```julia
# Independently emitted Julia module
value = LinkedSpecGeneratedParser.execute(
    input;
    diagnostic_output_sink = event -> push!(events, event),
)
traced = LinkedSpecGeneratedParser.execute_with_trace(
    input,
    trace_config;
    diagnostic_output_sink = event -> push!(events, event),
)
```

```lua
-- Independently loaded generated Lua module
local value = generated.execute(input, {
  diagnostic_sink = function(event) events[#events + 1] = event end,
})
local traced = generated.execute_with_trace(input, trace_config, {
  diagnostic_sink = function(event) events[#events + 1] = event end,
})
```

Perl, Dart, Julia, and Lua add optional invocation data to their direct and traced generated roles. Rust adds
paired entrypoints and preserves every legacy signature. In every language, no sink remains quiet, direct and
traced results match, rich events do not enter portable generated trace, caller sink failures and typed immediate
exit cross generated framing unchanged, and ordinary parser failures retain generated-source identity and stage.

Native and generated rollout is aligned:

| Backend | Current state or caveat |
| --- | --- |
| Perl | Native and independently emitted `Execute`/`ExecuteWithTrace`/`Get` consume the neutral contract through invocation options; failures and exit cross generated framing unchanged. |
| Rust | Native top/direct-value execution plus paired typed-v2 and compatibility generated functions consume the optional typed sink without changing compatibility signatures. |
| Dart | Native parse/execute/traced aliases and emitted direct/traced functions consume the optional named sink and preserve caller object plus stack. |
| Julia | Native parse/execute/traced aliases and emitted direct/traced functions consume the optional keyword sink; rich events stay outside native and portable generated trace. |
| Lua | Native and emitted option-bearing direct/traced functions consume the same sink on PUC Lua and LuaJIT with exact arbitrary caller identity and typed `RuntimeExitNow`. |

Primary commands deliberately do not expose or install this rich sink. The shared
`success_diagnostic_helpers_quiet` conformance case executes all three helpers and returns `"visible"`; every Perl,
Rust, Dart, Julia, and Lua command emits exactly `"visible"\n` as canonical JSON on stdout, nothing on stderr, and
status 0 in both default and POSIX environments. Existing ADR `0024` phase-trace cases remain unchanged and contain
no `RuntimeDiagnosticOutputEvent` data.

When all current host toolchains are installed, run the complete recurring proof with:

```bash
bash tools/check_diagnostic_output_five_backend.sh
```

That one driver runs the neutral model and 16 drift mutations; Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT
native+generated consumers; the exact quiet primary case through five commands in default and POSIX environments;
and generated-source, capability, and corpus-coverage ledgers. It uses disposable Lua native adapters and fails if
either ABI is unavailable. Canonical local CI registers the same all-toolchain leg behind
`LINKEDSPEC_RUN_DIAGNOSTIC_MATRIX=1` while its ordinary run still audits the driver, topology, and shell syntax.

The pre-repair Perl lowering placed stateful prefix and suffix expressions inside a host `foreach`, so two items
advanced each effect twice. Native Perl now snapshots all valid-call arguments before event delivery; that old
result remains root-cause evidence, not portable behavior. Planning leaf `FUTURE-PARITY-BACKLOG.5.1.0` measures
the mechanisms; neutral leaf `.5.1.1` ratifies ADR `0042` plus 11 rendering rows, five invalid arities, and six
semantic scenarios; Perl `.5.1.2`, Rust `.5.1.3`, Dart `.5.1.4`, Julia `.5.1.5`, and Lua `.5.1.6` are complete
native rollout legs. Generated/primary propagation `.5.1.7` and recurring symmetric gate `.5.1.8` are complete
too. Public no-drift `.5.1.9` locks this exact document set and closes the parent; the executable contract records
8 complete / 0 pending rollout legs.

Use `next` when a rule edge should consume a recognized item, such as a comment, and then skip adding a value to
the current accumulator. The parenthesized `next()` spelling remains equivalent on Perl, Rust, Dart, Julia, and Lua:

```text
-> comment { next }
```

Keep public examples focused on structured return values. Use debug output helpers when the example is genuinely about tracing or demonstrating a branch.

## Worked example: normalize a child node

This example shows child capture, fallback, normalization, hash shaping, and a structured return.

```text
Node::
 I { retv = undef; set(meta, {}); }
 -> Child {
   retv = call(Child);
   set(meta, hash(
     "kind", coalesce_nonempty(trim(retv["kind"]), "node"),
     "name", coalesce_nonempty(trim(retv["name"]), "anonymous")
   ));
   set(meta, set_key(meta, "normalized_name", replace_substr(lowercase(trim(meta.pick_keys("name").sorted_values().first())), " ", "_")));
   return(copy(meta));
 }

Child: /[A-Za-z_]+/
 I { return(hash("kind", "word", "name", entry_text())) }
```

Why this reads well:

- `call(Child)` is the only child dispatch.
- `coalesce_nonempty(...)` states the fallback policy.
- `set_key(...)` states that one field is added to a copy of the object.
- `copy(...)` states that the final object is returned as a payload.

## Worked example: head/tail array result

This example shows array appends, boundary reads, array helpers, and branch predicates.

```text
Sequence::
 I { set(items, []); retv = undef; }
 -> Item {
   retv = call(Item);
   items += retv;

   if(num_gt(count(items), 1))
     return(hash(
       "kind", "sequence",
       "head", first(items),
       "rest", drop_front(items),
       "item_count", count(items)
     ));
   else()
     next();
   endif()
 }
 LX { return(hash("kind", "single", "item", first(items))) }

Item: /\s*[A-Za-z_]+/
 I { return(hash("text", trim(entry_text()))) }
```

The important choice is the append operation: each child result is appended, here with `items += retv`. The final `return(...)` uses pure array helpers to read or derive views from the accumulated array without mutating it.

## Worked example: classify with switch

This example shows value normalization and switch classification.

```text
Top::
 -> Kind .push
 LX { return(copy(Top)) }

Kind: /[A-Za-z_]+/
 I {
   raw = entry_text();
   kind = replace_substr(lowercase(trim(raw)), "-", "_");

   switch(kind) {
     case("word") { return(hash("kind", "word", "raw", raw)) }
     case("space") { return(hash("kind", "space", "raw", raw)) }
     case("node") { return(hash("kind", "node", "raw", raw)) }
     default { return(hash("kind", "unknown", "raw", raw)) }
   }
 }
```

The switch is better than a long `elseif` ladder because every branch is driven by the same normalized value.

## Practical guidance

- Prefer `return(payload)` for new structured returns.
- Prefer `copy(array(...))` and `copy(hash(...))` when returning a nested snapshot.
- Prefer `flat_array(...)` and `flat_hash(...)` when splicing into a surrounding constructor.
- Prefer `items += expr` / `push(...)` when appending; do not use whole-array assignment as a disguised append.
- Prefer `meta["field"] = expr` / `set_key(meta, "field", expr)` when updating one hash field; use `set_key(hash_expr, key, value)` when you need a copied hash value.
- Prefer `has_key(...)` for field existence and `is_defined(...)` for value definedness.
- Prefer `coalesce_nonempty(trim(...), fallback)` for human text fallback.
- Prefer numeric helpers and `num_*` comparisons for counts, indexes, depths, and lengths.
- Prefer statement-style array pipelines when each normalization step deserves a readable line.
- Prefer `switch(...)` when one value drives classification; prefer `if(...)` when each branch has different logic.
