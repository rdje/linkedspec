fn main() {
let result = array_concat_open_arity_rust_fresh::case_extra_concat_arrays_free_terminal::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("ARRAY_CONCAT_RUST_FRESH extra_concat_arrays_free_terminal {}", observed);
let result = array_concat_open_arity_rust_fresh::case_extra_concat_arrays_free_composed::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("ARRAY_CONCAT_RUST_FRESH extra_concat_arrays_free_composed {}", observed);
let result = array_concat_open_arity_rust_fresh::case_extra_concat_arrays_receiver_terminal::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("ARRAY_CONCAT_RUST_FRESH extra_concat_arrays_receiver_terminal {}", observed);
let result = array_concat_open_arity_rust_fresh::case_extra_concat_arrays_receiver_composed::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("ARRAY_CONCAT_RUST_FRESH extra_concat_arrays_receiver_composed {}", observed);
}
