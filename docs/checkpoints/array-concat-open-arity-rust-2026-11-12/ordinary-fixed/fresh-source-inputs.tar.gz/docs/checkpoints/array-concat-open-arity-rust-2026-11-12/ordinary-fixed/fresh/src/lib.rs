#[path = "generated/extra_concat_arrays_free_terminal.rs"] pub mod case_extra_concat_arrays_free_terminal;
#[path = "generated/extra_concat_arrays_free_composed.rs"] pub mod case_extra_concat_arrays_free_composed;
#[path = "generated/extra_concat_arrays_receiver_terminal.rs"] pub mod case_extra_concat_arrays_receiver_terminal;
#[path = "generated/extra_concat_arrays_receiver_composed.rs"] pub mod case_extra_concat_arrays_receiver_composed;
