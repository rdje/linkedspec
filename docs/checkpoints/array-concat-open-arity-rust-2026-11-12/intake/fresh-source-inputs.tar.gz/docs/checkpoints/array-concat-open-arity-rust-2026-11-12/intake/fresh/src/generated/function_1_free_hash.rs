//! Generated LinkedSpec parser module.
//! Contract id: linkedspec-generated-source-v2.
//! Source format: linkedspec-runtime source_emitter v2.
//! Source identity: LINKEDSPEC_GENERATED_SOURCE_IDENTITY.

use linkedspec_runtime::source_emitter::{execute_generated_parser, execute_generated_parser_v2, execute_generated_parser_v2_with_options, execute_generated_parser_with_diagnostic_output, execute_generated_parser_with_diagnostic_output_and_options, execute_generated_parser_with_diagnostic_output_v2, execute_generated_parser_with_diagnostic_output_v2_with_options, execute_generated_parser_with_options, execute_generated_parser_with_trace, execute_generated_parser_with_trace_and_diagnostic_output, execute_generated_parser_with_trace_and_diagnostic_output_and_options, execute_generated_parser_with_trace_and_diagnostic_output_v2, execute_generated_parser_with_trace_and_diagnostic_output_v2_with_options, execute_generated_parser_with_trace_and_options, execute_generated_parser_with_trace_v2, execute_generated_parser_with_trace_v2_with_options, validate_generated_parser_plan_v2, GeneratedDiagnosticOutputExecutionError, GeneratedPlanRow, GeneratedSourceError, GeneratedSourceMetadata};
use linkedspec_runtime::engine::ExecutionOptions;
use linkedspec_runtime::RuntimeDiagnosticOutputSink;
use linkedspec_runtime::trace::TraceConfig;

pub const LINKEDSPEC_GENERATED_SOURCE_CONTRACT: &str = "linkedspec-generated-source-v2";
pub const LINKEDSPEC_GENERATED_SOURCE_FORMAT: u32 = 2;
pub const LINKEDSPEC_REGEX_SLOT_IDENTITY_CONTRACT: &str = "linkedspec-duplicate-regex-slot-identity-v1";
pub const LINKEDSPEC_GENERATED_SOURCE_IDENTITY: &str = "array-concat-open-arity-result/function_1_free_hash.spec";
const COMPILED_SPEC_JSON: &str = "{\"functions\":[{\"name\":\"supply\",\"params\":[\"seed\"],\"arity\":1,\"body\":{\"statements\":[{\"expr\":{\"kind\":\"call\",\"name\":\"return\",\"args\":[{\"kind\":\"variable\",\"name\":\"seed\"}]}}]},\"body_source\":\"return(seed)\",\"body_payload\":{\"arity\":1,\"function_name\":\"supply\",\"kind\":\"staged_payload\",\"node_kind\":\"function_definition\",\"params\":[\"seed\"],\"parent_ast_path\":[\"functions\",\"0\",\"body_source\"],\"payload_kind\":\"function_body\",\"provenance\":[{\"kind\":\"source_slice\",\"source_span\":{\"end\":29,\"line_end\":1,\"line_start\":1,\"start\":17}}],\"source_span\":{\"end\":29,\"line_end\":1,\"line_start\":1,\"start\":17},\"text\":\"return(seed)\",\"version\":1},\"body_parse_job\":{\"arity\":1,\"diagnostic_owner\":\"function_body\",\"failure_policy\":\"fail\",\"function_name\":\"supply\",\"job_id\":\"parse_job:function_body:functions.0.body_source:actionir-body.spec:action_block:17-29\",\"kind\":\"parse_job\",\"node_kind\":\"function_definition\",\"params\":[\"seed\"],\"parent_ast_path\":[\"functions\",\"0\",\"body_source\"],\"parser_spec_id\":\"actionir-body.spec\",\"payload_kind\":\"function_body\",\"result_field\":\"body_ast\",\"result_policy\":\"replace_field\",\"source_span\":{\"end\":29,\"line_end\":1,\"line_start\":1,\"start\":17},\"text\":\"return(seed)\",\"top_rule\":\"action_block\",\"version\":1},\"body_ast\":{\"kind\":\"action_block\",\"statements\":[{\"drops_value\":true,\"expr\":{\"args\":[{\"kind\":\"variable\",\"name\":\"seed\"}],\"kind\":\"call\",\"name\":\"return\"},\"kind\":\"action_stmt\"}]},\"source\":\"fn supply(seed) {return(seed)}\",\"source_span\":{\"line_start\":1,\"line_end\":1},\"body_span\":{\"line_start\":1,\"line_end\":1}}],\"rules\":[{\"label\":\"Value\",\"is_top\":true,\"mode\":\"Default\",\"regex_patterns\":[],\"regex_slots\":[],\"dependency_refs\":[],\"acode_dispatch\":[],\"bcode_dispatch\":[],\"preamble\":{\"statements\":[{\"expr\":{\"kind\":\"assign_scalar\",\"name\":\"order\",\"value\":{\"kind\":\"string\",\"value\":\"\"}}},{\"expr\":{\"kind\":\"assign_scalar\",\"name\":\"out\",\"value\":{\"kind\":\"fluent_chain\",\"receiver\":{\"kind\":\"call\",\"name\":\"concat_arrays\",\"args\":[{\"kind\":\"call\",\"name\":\"supply\",\"args\":[{\"kind\":\"block_value\",\"block\":{\"statements\":[{\"expr\":{\"kind\":\"assign_scalar\",\"name\":\"order\",\"value\":{\"kind\":\"call\",\"name\":\"cat\",\"args\":[{\"kind\":\"variable\",\"name\":\"order\"},{\"kind\":\"string\",\"value\":\"S\"}]}}},{\"expr\":{\"kind\":\"array_literal\",\"items\":[{\"kind\":\"string\",\"value\":\"head\"}]}}]}}]}]},\"calls\":[{\"method\":\"set_key\",\"args\":[{\"kind\":\"block_value\",\"block\":{\"statements\":[{\"expr\":{\"kind\":\"assign_scalar\",\"name\":\"order\",\"value\":{\"kind\":\"call\",\"name\":\"cat\",\"args\":[{\"kind\":\"variable\",\"name\":\"order\"},{\"kind\":\"string\",\"value\":\"K\"}]}}},{\"expr\":{\"kind\":\"string\",\"value\":\"k\"}}]}},{\"kind\":\"block_value\",\"block\":{\"statements\":[{\"expr\":{\"kind\":\"assign_scalar\",\"name\":\"order\",\"value\":{\"kind\":\"call\",\"name\":\"cat\",\"args\":[{\"kind\":\"variable\",\"name\":\"order\"},{\"kind\":\"string\",\"value\":\"V\"}]}}},{\"expr\":{\"kind\":\"number\",\"value\":1.0}}]}}]}]}}},{\"expr\":{\"kind\":\"call\",\"name\":\"return\",\"args\":[{\"kind\":\"array_literal\",\"items\":[{\"kind\":\"variable\",\"name\":\"out\"},{\"kind\":\"variable\",\"name\":\"order\"}]}]}}]},\"lxcode\":null,\"lscode\":null,\"lecode\":null,\"ecode\":null,\"excode\":null,\"itcode\":null,\"rep_min\":0,\"rep_max\":null}]}";

const GENERATED_PLAN: &[GeneratedPlanRow] = &[
    GeneratedPlanRow { label: "Value", family: "default" },
];

pub fn metadata() -> GeneratedSourceMetadata {
    GeneratedSourceMetadata::new(LINKEDSPEC_GENERATED_SOURCE_IDENTITY)
}

pub fn plan() -> &'static [GeneratedPlanRow] {
    GENERATED_PLAN
}

pub fn validate_plan(actual: &[GeneratedPlanRow]) -> Result<(), GeneratedSourceError> {
    validate_plan_for_contract(actual, LINKEDSPEC_GENERATED_SOURCE_CONTRACT)
}

pub fn validate_plan_for_contract(
    actual: &[GeneratedPlanRow],
    actual_contract: &str,
) -> Result<(), GeneratedSourceError> {
    validate_generated_parser_plan_v2(
        COMPILED_SPEC_JSON,
        actual,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        actual_contract,
    )
}

pub fn execute(input: &str) -> Result<serde_json::Value, GeneratedSourceError> {
    execute_generated_parser_v2(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
    )
}

pub fn execute_with_diagnostic_output(
    input: &str,
    sink: Option<&RuntimeDiagnosticOutputSink>,
) -> Result<serde_json::Value, GeneratedDiagnosticOutputExecutionError> {
    execute_generated_parser_with_diagnostic_output_v2(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
        sink,
    )
}

pub fn execute_with_trace(input: &str, trace_config: TraceConfig) -> Result<serde_json::Value, GeneratedSourceError> {
    execute_generated_parser_with_trace_v2(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        trace_config,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
    )
}

pub fn execute_with_trace_and_diagnostic_output(
    input: &str,
    trace_config: TraceConfig,
    sink: Option<&RuntimeDiagnosticOutputSink>,
) -> Result<serde_json::Value, GeneratedDiagnosticOutputExecutionError> {
    execute_generated_parser_with_trace_and_diagnostic_output_v2(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        trace_config,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
        sink,
    )
}

pub fn execute_with_options(
    input: &str,
    options: &ExecutionOptions,
) -> Result<serde_json::Value, GeneratedSourceError> {
    execute_generated_parser_v2_with_options(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
        options,
    )
}

pub fn execute_with_options_and_diagnostic_output(
    input: &str,
    options: &ExecutionOptions,
    sink: Option<&RuntimeDiagnosticOutputSink>,
) -> Result<serde_json::Value, GeneratedDiagnosticOutputExecutionError> {
    execute_generated_parser_with_diagnostic_output_v2_with_options(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
        sink,
        options,
    )
}

pub fn execute_with_trace_and_options(
    input: &str,
    trace_config: TraceConfig,
    options: &ExecutionOptions,
) -> Result<serde_json::Value, GeneratedSourceError> {
    execute_generated_parser_with_trace_v2_with_options(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        trace_config,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
        options,
    )
}

pub fn execute_with_trace_and_options_and_diagnostic_output(
    input: &str,
    trace_config: TraceConfig,
    options: &ExecutionOptions,
    sink: Option<&RuntimeDiagnosticOutputSink>,
) -> Result<serde_json::Value, GeneratedDiagnosticOutputExecutionError> {
    execute_generated_parser_with_trace_and_diagnostic_output_v2_with_options(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        trace_config,
        LINKEDSPEC_GENERATED_SOURCE_IDENTITY,
        LINKEDSPEC_GENERATED_SOURCE_CONTRACT,
        sink,
        options,
    )
}

pub fn parse(input: &str) -> Result<serde_json::Value, String> {
    execute_generated_parser(COMPILED_SPEC_JSON, GENERATED_PLAN, input)
}

pub fn parse_with_diagnostic_output(
    input: &str,
    sink: Option<&RuntimeDiagnosticOutputSink>,
) -> Result<serde_json::Value, GeneratedDiagnosticOutputExecutionError> {
    execute_generated_parser_with_diagnostic_output(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        sink,
    )
}

pub fn parse_with_trace(input: &str, trace_config: TraceConfig) -> Result<serde_json::Value, String> {
    execute_generated_parser_with_trace(COMPILED_SPEC_JSON, GENERATED_PLAN, input, trace_config)
}

pub fn parse_with_trace_and_diagnostic_output(
    input: &str,
    trace_config: TraceConfig,
    sink: Option<&RuntimeDiagnosticOutputSink>,
) -> Result<serde_json::Value, GeneratedDiagnosticOutputExecutionError> {
    execute_generated_parser_with_trace_and_diagnostic_output(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        trace_config,
        sink,
    )
}

pub fn parse_with_options(
    input: &str,
    options: &ExecutionOptions,
) -> Result<serde_json::Value, String> {
    execute_generated_parser_with_options(COMPILED_SPEC_JSON, GENERATED_PLAN, input, options)
}

pub fn parse_with_options_and_diagnostic_output(
    input: &str,
    options: &ExecutionOptions,
    sink: Option<&RuntimeDiagnosticOutputSink>,
) -> Result<serde_json::Value, GeneratedDiagnosticOutputExecutionError> {
    execute_generated_parser_with_diagnostic_output_and_options(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        sink,
        options,
    )
}

pub fn parse_with_trace_and_options(
    input: &str,
    trace_config: TraceConfig,
    options: &ExecutionOptions,
) -> Result<serde_json::Value, String> {
    execute_generated_parser_with_trace_and_options(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        trace_config,
        options,
    )
}

pub fn parse_with_trace_and_options_and_diagnostic_output(
    input: &str,
    trace_config: TraceConfig,
    options: &ExecutionOptions,
    sink: Option<&RuntimeDiagnosticOutputSink>,
) -> Result<serde_json::Value, GeneratedDiagnosticOutputExecutionError> {
    execute_generated_parser_with_trace_and_diagnostic_output_and_options(
        COMPILED_SPEC_JSON,
        GENERATED_PLAN,
        input,
        trace_config,
        sink,
        options,
    )
}
