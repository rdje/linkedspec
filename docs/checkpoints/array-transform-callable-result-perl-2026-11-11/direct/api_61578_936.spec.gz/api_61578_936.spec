fn collect(head,...rest) {return([head])}

Value:: I {order="";out=collect().trim_each();return([out,order])}
