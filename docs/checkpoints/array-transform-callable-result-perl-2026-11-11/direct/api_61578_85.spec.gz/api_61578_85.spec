fn supply(seed) {return(seed)}

Value:: I {order="";out=uniq(supply(["head","tail","head"])).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
