Value:: I {return({"k":"tail"}.drop_front(1).with(){return(value)})}
