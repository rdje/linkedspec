fn collect(head,...rest) {return([head])}

Value:: I {order="";out=collect().trim_each().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).with(){order=cat(order,"W");return("ran")};return([out,order])}
