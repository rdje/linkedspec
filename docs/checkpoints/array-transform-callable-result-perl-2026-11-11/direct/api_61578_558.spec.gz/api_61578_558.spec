fn supply(seed) {return(seed)}

Value:: I {order="";out=uppercase_each(supply(undef)).with(){order=cat(order,"W");return(value.count())};return([out,order])}
