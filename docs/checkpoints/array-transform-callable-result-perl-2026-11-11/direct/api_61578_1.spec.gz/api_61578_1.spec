fn supply(seed) {return(seed)}

Value:: I {return([split_each(supply(["head:tail"]),":"),supply(["head:tail"]).split_each(":")])}
