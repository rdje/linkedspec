fn supply(seed) {return(seed)}

Value:: I {return(supply(undef).split_each(":"))}
