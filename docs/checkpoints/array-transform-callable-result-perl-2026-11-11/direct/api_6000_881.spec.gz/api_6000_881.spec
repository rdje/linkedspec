Value:: I {return(undef.drop_front(1).with(){return(value)})}
