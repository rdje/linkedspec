fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(["head"]).split_each().with(){order=cat(order,"W");return("ran")};return([out,order])}
