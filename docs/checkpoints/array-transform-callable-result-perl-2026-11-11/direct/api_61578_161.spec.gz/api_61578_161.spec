fn supply(seed) {return(seed)}

Value:: I {return([trim_each(supply(3)),supply(3).trim_each()])}
