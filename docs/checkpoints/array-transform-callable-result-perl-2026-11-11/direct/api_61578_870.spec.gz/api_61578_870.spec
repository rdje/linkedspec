fn supply(seed) {return(seed)}

Value:: I {order="";needle="h";out=supply(["head"]).filter_match({order=cat(order,"P");"h"});return([out,order])}
