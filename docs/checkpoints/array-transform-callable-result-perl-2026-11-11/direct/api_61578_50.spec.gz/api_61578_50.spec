fn supply(seed) {return(seed)}

Value:: I {return([lowercase_each(supply(["HEAD","TAIL"])),supply(["HEAD","TAIL"]).lowercase_each()])}
