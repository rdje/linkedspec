fn supply(seed) {return(seed)}

Value:: I {order="";out=trim_each(supply(3)).with(){order=cat(order,"W");return(value.count())};return([out,order])}
