Value:: I {items=["head","tail"];out=take(items,{items=["changed"];1});return([out,items])}
