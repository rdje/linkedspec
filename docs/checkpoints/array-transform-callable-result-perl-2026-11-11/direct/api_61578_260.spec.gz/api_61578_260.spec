fn supply(seed) {return(seed)}

Value:: I {return(supply({"k":"head"}).split_each(":"))}
