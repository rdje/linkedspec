Value:: I {return({"k":"tail"}.take(1).with(){return(value)})}
