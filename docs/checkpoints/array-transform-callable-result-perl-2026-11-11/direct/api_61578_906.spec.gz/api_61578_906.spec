fn all_values(...values) {return(values)}

Value:: I {order="";out=all_values({order=cat(order,"S");" head "}," tail ").trim_each();return([out,order])}
