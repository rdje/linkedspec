Value:: I {source=["head","tail","end"];return(take_last(source))}
