fn supply(seed) {return(seed)}

Value:: I {order="";needle="h";out=supply(["head"]).filter_match(needle);return([out,order])}
