Value:: I {return(drop_front().with(){return(value)})}
