fn supply(seed) {return(seed)}

Value:: I {return([filter_nonempty(supply(["head","","tail"])),supply(["head","","tail"]).filter_nonempty()])}
