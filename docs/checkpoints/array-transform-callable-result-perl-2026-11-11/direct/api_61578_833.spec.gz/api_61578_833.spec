fn supply(seed) {return(seed)}

Value:: I {order="";out=supply();return([out,order])}
