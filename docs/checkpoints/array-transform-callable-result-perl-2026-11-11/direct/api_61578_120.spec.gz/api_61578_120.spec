fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(["TAIL"]).lowercase_each().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).and({order=cat(order,"D");true}).with(){order=cat(order,"W");return("ran")};return([out,order])}
