fn supply(seed) {return(seed)}

Value:: I {order="";return(supply(["head"]).filter_match(/[z-a]/))}
