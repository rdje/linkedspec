fn supply(seed) {return(seed)}

Value:: I {order="";out=supply([""]).filter_nonempty().with(){order=cat(order,"W");return(value.count())};return([out,order])}
