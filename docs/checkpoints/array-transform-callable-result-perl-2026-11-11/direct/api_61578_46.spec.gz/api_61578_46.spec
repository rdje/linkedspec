fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(["head","","tail"]).filter_nonempty().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
