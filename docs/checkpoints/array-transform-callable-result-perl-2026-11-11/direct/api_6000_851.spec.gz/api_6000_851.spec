Value:: I {return(undef.take_last(1).with(){return(value)})}
