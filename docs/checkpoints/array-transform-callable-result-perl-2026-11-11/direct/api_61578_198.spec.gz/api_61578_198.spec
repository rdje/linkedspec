fn supply(seed) {return(seed)}

Value:: I {order="";return(filter_match(supply(["head"]),/[z-a]/).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).coalesce("masked"))}
