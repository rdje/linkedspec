fn supply(seed) {return(seed)}

Value:: I {order="";out=supply({order=cat(order,"S");[" tail "]}).trim_each().last().uppercase();return([out,order])}
