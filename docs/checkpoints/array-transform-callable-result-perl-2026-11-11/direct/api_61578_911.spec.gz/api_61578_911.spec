fn all_values(...values) {return(values)}

Value:: I {order="";out=all_values({order=cat(order,"S");" head "}," tail ").trim_each().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).with(){order=cat(order,"W");return("ran")};return([out,order])}
