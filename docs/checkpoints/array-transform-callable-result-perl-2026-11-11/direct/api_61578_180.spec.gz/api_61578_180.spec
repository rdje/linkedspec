fn supply(seed) {return(seed)}

Value:: I {return([trim_each(supply({"k":"head"})),supply({"k":"head"}).trim_each()])}
