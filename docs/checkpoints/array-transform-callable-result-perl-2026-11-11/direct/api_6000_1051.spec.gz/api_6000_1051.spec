Value:: I {return(["head","tail"].slice().with(){return(value)})}
