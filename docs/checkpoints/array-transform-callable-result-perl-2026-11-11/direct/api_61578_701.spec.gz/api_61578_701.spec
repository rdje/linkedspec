fn supply(seed) {return(seed)}

Value:: I {return(supply(3).filter_match(/^head/))}
