Value:: I {source={"k":"tail"};return(take(source,1))}
