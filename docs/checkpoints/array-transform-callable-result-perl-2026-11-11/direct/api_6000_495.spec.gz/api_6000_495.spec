Value:: I {source=undef;return(source.reversed())}
