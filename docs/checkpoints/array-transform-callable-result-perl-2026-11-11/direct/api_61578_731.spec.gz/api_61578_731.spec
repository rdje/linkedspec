fn supply(seed) {return(seed)}

Value:: I {return(filter_match(supply({"k":"head"}),/^head/))}
