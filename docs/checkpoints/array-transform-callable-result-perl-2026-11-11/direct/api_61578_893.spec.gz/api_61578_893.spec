fn supply(seed) {return(seed)}

Value:: I {order="";out=supply({order=cat(order,"S");[" tail "]}).trim_each().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).copy().with(){order=cat(order,"W");return("ran")};return([out,order])}
