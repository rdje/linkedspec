fn supply(seed) {return(seed)}

Value:: I {return(supply(undef).uppercase_each())}
