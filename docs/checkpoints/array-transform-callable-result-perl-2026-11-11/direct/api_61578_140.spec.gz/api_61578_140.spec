fn supply(seed) {return(seed)}

Value:: I {order="";return(supply({items="bad";items+=1;["head"]}).trim_each())}
