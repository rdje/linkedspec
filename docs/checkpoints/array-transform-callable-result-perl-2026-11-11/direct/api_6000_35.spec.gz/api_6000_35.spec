Value:: I {return([drop_front(["head","tail"],1),["head","tail"].drop_front(1)])}
