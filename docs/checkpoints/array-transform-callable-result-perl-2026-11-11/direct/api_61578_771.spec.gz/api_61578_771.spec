fn supply(seed) {return(seed)}

Value:: I {order="";out=split_each(supply(["head"])).with(){order=cat(order,"W");return("ran")};return([out,order])}
