Value:: I {return({"k":"tail"}.sorted().with(){return(value)})}
