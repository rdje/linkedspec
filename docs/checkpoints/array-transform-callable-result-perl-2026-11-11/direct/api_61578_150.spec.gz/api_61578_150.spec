fn supply(seed) {return(seed)}

Value:: I {order="";return(supply(["head:tail"]).split_each({items="bad";items+=1;":"}))}
