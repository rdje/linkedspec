Value:: I {order="";out=array("tail").set_key({order=cat(order,"K");"k"},1);return([out,order])}
