fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_nonempty(supply(["head","","tail"])).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
