fn supply(seed) {return(seed)}

Value:: I {return([filter_match(supply(["head","other"]),/^h/),supply(["head","other"]).filter_match(/^h/)])}
