fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_match(supply({"k":"head"}),/^head/).with(){order=cat(order,"W");return(value.count())};return([out,order])}
