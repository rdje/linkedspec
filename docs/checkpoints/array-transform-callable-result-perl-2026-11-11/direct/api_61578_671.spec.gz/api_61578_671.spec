fn supply(seed) {return(seed)}

Value:: I {order="";out=uniq(supply({order=cat(order,"S");["head:tail"]}),{order=cat(order,"X");1}).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).with(){order=cat(order,"W");return("ran")};return([out,order])}
