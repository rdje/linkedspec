Value:: I {return(undef.drop_back(1).with(){return(value)})}
