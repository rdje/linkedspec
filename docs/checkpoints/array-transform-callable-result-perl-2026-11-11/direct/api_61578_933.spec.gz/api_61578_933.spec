fn pair(left,right) {return([left,right])}

Value:: I {order="";out=pair("head","tail",{order=cat(order,"X");"extra"}).trim_each().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).with(){order=cat(order,"W");return("ran")};return([out,order])}
