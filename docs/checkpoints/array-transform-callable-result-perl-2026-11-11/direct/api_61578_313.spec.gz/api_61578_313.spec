fn supply(seed) {return(seed)}

Value:: I {return(trim_each(supply(undef)))}
