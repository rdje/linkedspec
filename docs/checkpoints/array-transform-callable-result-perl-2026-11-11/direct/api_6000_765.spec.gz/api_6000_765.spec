Value:: I {source={"k":"tail"};return(source.reversed().with(){return(value)})}
