Value:: I {source=undef;return(take(source,1))}
