fn supply(seed) {return(seed)}

Value:: I {order="";out=sorted_keys(supply({"a":1})).trim_each().with(){order=cat(order,"W");return(value)};return([out,order])}
