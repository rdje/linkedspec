Value:: I {order="";out=set_key({"k":"tail"},"n",1).take({order=cat(order,"N");1});return([out,order])}
