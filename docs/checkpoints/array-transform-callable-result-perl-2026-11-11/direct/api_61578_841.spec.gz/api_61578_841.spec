fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(["head"],{order=cat(order,"F");1});return([out,order])}
