Value:: I {order="";source=["head","tail"];out=drop_front(source,1,{order=cat(order,"E");2});return([out,order])}
