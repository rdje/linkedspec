fn supply(seed) {return(seed)}

Value:: I {return([trim_each(supply([" head "," tail "])),supply([" head "," tail "]).trim_each()])}
