fn supply(seed) {return(seed)}

Value:: I {return([trim_each(supply(undef)),supply(undef).trim_each()])}
