fn supply(seed) {return(seed)}

Value:: I {order="";out=supply({"k":"head"}).uniq().with(){order=cat(order,"W");return(value.count())};return([out,order])}
