fn supply(seed) {return(seed)}

Value:: I {items=[3];return([trim_each(supply(items)),filter_nonempty(supply(items)),uniq(supply(items)),items])}
