fn pair(left,right) {return([left,right])}

Value:: I {order="";out=pair("head","tail",{order=cat(order,"X");"extra"}).trim_each();return([out,order])}
