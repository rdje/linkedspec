Value:: I {return(undef.take(1).with(){return(value)})}
