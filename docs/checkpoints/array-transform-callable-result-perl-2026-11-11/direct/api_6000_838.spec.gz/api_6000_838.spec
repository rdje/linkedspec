Value:: I {return(3.take_last(1).with(){return(value)})}
