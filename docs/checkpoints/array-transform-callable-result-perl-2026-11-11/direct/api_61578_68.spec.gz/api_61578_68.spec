fn supply(seed) {return(seed)}

Value:: I {return([uppercase_each(supply(["head","tail"])),supply(["head","tail"]).uppercase_each()])}
