Value:: I {return(slice(["head","tail"]).with(){return(value)})}
