fn supply(seed) {return(seed)}

Value:: I {order="";out=uppercase_each(supply(["head","tail"])).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
