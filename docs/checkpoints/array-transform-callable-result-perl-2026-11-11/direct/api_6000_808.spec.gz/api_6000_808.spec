Value:: I {return(3.take(1).with(){return(value)})}
