fn supply(seed) {return(seed)}

Value:: I {items=["head:tail"];out=supply(items).split_each({items=["changed"];":"});return([out,items])}
