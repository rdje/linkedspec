fn supply(seed) {return(seed)}

Value:: I {order="";out=set_key(supply({}),"k",1).trim_each().with(){order=cat(order,"W");return(value)};return([out,order])}
