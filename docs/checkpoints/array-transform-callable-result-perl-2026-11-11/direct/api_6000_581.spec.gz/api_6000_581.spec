Value:: I {return(take({return(num_clamp(1,2))}).with(){return("masked")})}
