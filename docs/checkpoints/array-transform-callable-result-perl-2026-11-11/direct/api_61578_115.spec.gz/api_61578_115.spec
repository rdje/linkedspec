fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(["tail","tail"]).uniq().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).copy().with(){order=cat(order,"W");return("ran")};return([out,order])}
