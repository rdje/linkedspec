fn supply(seed) {return(seed)}

Value:: I {return(supply(undef).trim_each())}
