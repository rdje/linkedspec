Value:: I {return({"k":"tail"}.concat_arrays(["extra"]).with(){return(value)})}
