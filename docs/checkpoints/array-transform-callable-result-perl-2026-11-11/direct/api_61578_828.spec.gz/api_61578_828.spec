fn supply(seed) {return(seed)}

Value:: I {order="";return(supply(["head:tail"]).split_each({items="bad";items+=1;":"}).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).coalesce("masked"))}
