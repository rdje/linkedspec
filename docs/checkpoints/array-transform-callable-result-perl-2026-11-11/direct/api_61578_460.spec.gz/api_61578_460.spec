fn supply(seed) {return(seed)}

Value:: I {return(supply(3).lowercase_each())}
