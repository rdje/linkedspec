fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(["HEAD","TAIL"]).lowercase_each().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
