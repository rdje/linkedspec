fn supply(seed) {return(seed)}

Value:: I {order="";out=lowercase_each(supply(["HEAD","TAIL"])).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
