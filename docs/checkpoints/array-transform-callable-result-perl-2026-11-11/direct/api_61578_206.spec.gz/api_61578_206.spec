fn supply(seed) {return(seed)}

Value:: I {order="";return(supply(["head"]).filter_match(/[z-a]/).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).coalesce("masked"))}
