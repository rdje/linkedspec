fn pair(left,right) {return([left,right])}

Value:: I {order="";out=pair({order=cat(order,"S");"head"}).trim_each();return([out,order])}
