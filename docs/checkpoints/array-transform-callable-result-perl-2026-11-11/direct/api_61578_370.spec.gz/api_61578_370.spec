fn supply(seed) {return(seed)}

Value:: I {return(filter_nonempty(supply(3)))}
