Value:: I {return(take(["tail"],{items="bad";items+=1;1}))}
