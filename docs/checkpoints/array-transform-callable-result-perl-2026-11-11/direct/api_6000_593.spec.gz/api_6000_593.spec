Value:: I {return(drop_front({return(num_clamp(1,2))}).with(){return("masked")})}
