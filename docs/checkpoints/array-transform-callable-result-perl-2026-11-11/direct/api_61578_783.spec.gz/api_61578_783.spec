fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_match(supply(["head"])).with(){order=cat(order,"W");return("ran")};return([out,order])}
