Value:: I {order="";source=["head","tail"];out=reversed(source,{order=cat(order,"E");2});return([out,order])}
