fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(["head"]).filter_match().with(){order=cat(order,"W");return("ran")};return([out,order])}
