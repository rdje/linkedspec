fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(3).uppercase_each().with(){order=cat(order,"W");return(value.count())};return([out,order])}
