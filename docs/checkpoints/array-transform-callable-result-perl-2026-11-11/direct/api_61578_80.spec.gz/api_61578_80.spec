fn supply(seed) {return(seed)}

Value:: I {return([uniq(supply(["head","tail","head"])),supply(["head","tail","head"]).uniq()])}
