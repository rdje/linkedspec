fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_nonempty(supply(3)).with(){order=cat(order,"W");return(value.count())};return([out,order])}
