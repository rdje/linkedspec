Value:: I {source=undef;return(reversed(source))}
