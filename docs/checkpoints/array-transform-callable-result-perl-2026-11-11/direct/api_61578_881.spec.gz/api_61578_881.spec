fn supply(seed) {return(seed)}

Value:: I {items=[false,0,undef,"0",""];out=uniq(supply(items));return([out,items])}
