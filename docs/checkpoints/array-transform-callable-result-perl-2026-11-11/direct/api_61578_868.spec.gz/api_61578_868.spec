fn supply(seed) {return(seed)}

Value:: I {order="";needle="h";out=supply(["head"]).filter_match(needle).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).with(){order=cat(order,"W");return("ran")};return([out,order])}
