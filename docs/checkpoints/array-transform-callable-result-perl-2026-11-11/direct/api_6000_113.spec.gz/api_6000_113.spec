Value:: I {return([concat_arrays(["head"],["tail"]),["head"].concat_arrays(["tail"])])}
