fn supply(seed) {return(seed)}

Value:: I {order="";out=supply("abc").length().trim_each().with(){order=cat(order,"W");return(value)};return([out,order])}
