fn supply(seed) {return(seed)}

Value:: I {return(supply(3).uppercase_each())}
