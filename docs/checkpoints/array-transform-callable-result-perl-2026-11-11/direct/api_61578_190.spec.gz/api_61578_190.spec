fn supply(seed) {return(seed)}

Value:: I {order="";return(filter_match(supply(["head"]),/[z-a]/))}
