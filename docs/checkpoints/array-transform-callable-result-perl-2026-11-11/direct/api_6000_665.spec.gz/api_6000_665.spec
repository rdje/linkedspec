Value:: I {source={"k":"tail"};return(source.drop_front(1).with(){return(value)})}
