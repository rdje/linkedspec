fn all_values(...values) {return(values)}

Value:: I {order="";out=all_values().trim_each();return([out,order])}
