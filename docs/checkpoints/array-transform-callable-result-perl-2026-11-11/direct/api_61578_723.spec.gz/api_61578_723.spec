fn supply(seed) {return(seed)}

Value:: I {return(supply(undef).filter_match(/^head/))}
