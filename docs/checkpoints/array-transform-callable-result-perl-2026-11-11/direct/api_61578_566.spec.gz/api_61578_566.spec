fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(undef).uppercase_each().with(){order=cat(order,"W");return(value.count())};return([out,order])}
