Value:: I {return({"k":"tail"}.drop_back(1).with(){return(value)})}
