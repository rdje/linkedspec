fn supply(seed) {return(seed)}

Value:: I {order="";return(supply({items="bad";items+=1;["head"]}).trim_each().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1}).coalesce("masked"))}
