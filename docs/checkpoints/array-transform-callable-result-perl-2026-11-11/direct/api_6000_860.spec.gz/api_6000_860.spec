Value:: I {return(take_last().with(){return(value)})}
