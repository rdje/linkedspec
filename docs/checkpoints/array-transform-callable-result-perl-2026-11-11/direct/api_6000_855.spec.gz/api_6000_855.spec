Value:: I {return({"k":"tail"}.take_last(1).with(){return(value)})}
