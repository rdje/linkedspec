Value:: I {return(slice().with(){return(value)})}
