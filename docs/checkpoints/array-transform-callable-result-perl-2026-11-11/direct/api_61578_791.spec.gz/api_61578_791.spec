fn supply(seed) {return(seed)}

Value:: I {order="";out=supply([1]).count().trim_each().with(){order=cat(order,"W");return(value)};return([out,order])}
