Value:: I {source=undef;return(source.drop_back(1))}
