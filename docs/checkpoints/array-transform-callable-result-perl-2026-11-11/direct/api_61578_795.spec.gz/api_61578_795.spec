fn supply(seed) {return(seed)}

Value:: I {order="";out=supply({"a":1}).count_keys().trim_each().with(){order=cat(order,"W");return(value)};return([out,order])}
