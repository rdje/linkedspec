fn yield_items(payload) {return(payload)}

Value:: I {order="";out=yield_items({order=cat(order,"S");["head","tail"]}).filter_match(/^head/);return([out,order])}
