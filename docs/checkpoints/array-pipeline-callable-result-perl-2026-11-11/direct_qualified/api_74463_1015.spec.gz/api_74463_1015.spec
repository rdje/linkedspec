Value:: I {order="";out=undef.filter_nonempty().with(){order=cat(order,"W");return(value)};return([out,order])}
