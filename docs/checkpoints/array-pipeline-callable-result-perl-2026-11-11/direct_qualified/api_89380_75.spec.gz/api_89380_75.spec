fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_match(supply({order=cat(order,"S");["head:tail"]}),/^head/,{order=cat(order,"X");1});return([out,order])}
