fn supply(seed) {return(seed)}

Value:: I {return(uppercase_each(supply({"k":"head"})))}
