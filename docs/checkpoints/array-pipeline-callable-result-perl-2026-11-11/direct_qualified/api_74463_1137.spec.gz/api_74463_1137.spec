Value:: I {order="";out={"k":"tail"}.uniq().with(){order=cat(order,"W");return(value)};return([out,order])}
