Value:: I {order="";out={"k":1}.uppercase_each().with(){order=cat(order,"W");return(value.count())};return([out,order])}
