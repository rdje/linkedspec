Value:: I {order="";out={"k":"tail"}.filter_nonempty().with(){order=cat(order,"W");return(value)};return([out,order])}
