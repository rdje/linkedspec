Value:: I {return([lowercase_each(["HEAD","TAIL"]),["HEAD","TAIL"].lowercase_each()])}
