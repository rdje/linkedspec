fn supply(seed) {return(seed)}

Value:: I {order="";out=supply(undef).uniq().with(){order=cat(order,"W");return(value.count())};return([out,order])}
