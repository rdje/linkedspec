Value:: I {order="";out={"k":1}.trim_each().with(){order=cat(order,"W");return(value.count())};return([out,order])}
