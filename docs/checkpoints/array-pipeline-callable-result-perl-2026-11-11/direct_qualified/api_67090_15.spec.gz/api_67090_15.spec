fn bad(...left, ...right) { return(undef) }
Top::
 /x/
