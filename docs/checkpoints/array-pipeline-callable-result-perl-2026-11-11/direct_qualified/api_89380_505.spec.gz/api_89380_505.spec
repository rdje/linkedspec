fn supply(seed) {return(seed)}

Value:: I {return(supply({"k":"head"}).filter_match(/^head/))}
