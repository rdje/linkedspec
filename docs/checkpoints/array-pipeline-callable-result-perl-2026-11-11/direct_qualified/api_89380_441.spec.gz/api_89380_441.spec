fn supply(seed) {return(seed)}

Value:: I {order="";out=uniq(supply({"k":"head"})).with(){order=cat(order,"W");return(value.count())};return([out,order])}
