Value:: I {order="";out=uniq({order=cat(order,"S");["head:tail"]},{order=cat(order,"A");0}).set_key({order=cat(order,"K");"k"},1).with(){order=cat(order,"W");return("ran")};return([out,order])}
