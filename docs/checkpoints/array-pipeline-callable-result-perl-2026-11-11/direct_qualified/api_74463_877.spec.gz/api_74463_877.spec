Value:: I {return(["head:tail"].split_each({items="bad";items+=1;":"}))}
