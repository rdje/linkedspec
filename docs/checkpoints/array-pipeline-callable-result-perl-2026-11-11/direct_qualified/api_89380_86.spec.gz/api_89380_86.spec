fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_match(supply({order=cat(order,"S");["head:tail"]}));return([out,order])}
