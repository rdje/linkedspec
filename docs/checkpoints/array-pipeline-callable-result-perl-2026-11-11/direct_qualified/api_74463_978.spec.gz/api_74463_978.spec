Value:: I {order="";out={"k":"tail"}.trim_each().with(){order=cat(order,"W");return(value)};return([out,order])}
