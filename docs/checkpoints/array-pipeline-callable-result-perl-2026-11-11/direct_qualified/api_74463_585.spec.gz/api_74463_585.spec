Value:: I {order="";out={"k":1}.filter_match(/./).with(){order=cat(order,"W");return(value.count())};return([out,order])}
