Value:: I {order="";out=["head"].filter_match().with(){order=cat(order,"W");return(value)};return([out,order])}
