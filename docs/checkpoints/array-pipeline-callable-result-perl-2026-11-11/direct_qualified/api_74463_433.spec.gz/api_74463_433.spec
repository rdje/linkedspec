Value:: I {return(3.uppercase_each())}
