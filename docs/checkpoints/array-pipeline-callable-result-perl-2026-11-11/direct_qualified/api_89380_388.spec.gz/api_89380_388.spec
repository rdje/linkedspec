fn supply(seed) {return(seed)}

Value:: I {return(supply({"k":"head"}).uppercase_each())}
