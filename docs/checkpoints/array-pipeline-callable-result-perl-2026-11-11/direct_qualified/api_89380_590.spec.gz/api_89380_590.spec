fn yield_items(payload) {return(payload)}

Value:: I {order="";out=lowercase_each(yield_items({order=cat(order,"S");["HEAD","TAIL"]}));return([out,order])}
