Value:: I {return([uniq(["head","tail","head"]),["head","tail","head"].uniq()])}
