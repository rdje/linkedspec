Value:: I {order="";out=filter_match().with(){order=cat(order,"W");return(value)};return([out,order])}
