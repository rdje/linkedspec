fn supply(seed) {return(seed)}

Value:: I {return(uniq(supply({"k":"head"})))}
