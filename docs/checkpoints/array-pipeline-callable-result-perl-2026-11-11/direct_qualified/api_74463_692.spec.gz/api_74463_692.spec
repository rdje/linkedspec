Value:: I {return(trim_each(3))}
