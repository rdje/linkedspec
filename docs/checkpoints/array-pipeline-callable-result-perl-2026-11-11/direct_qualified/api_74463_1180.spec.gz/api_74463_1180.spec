Value:: I {order="";out={"k":"tail"}.filter_match(/^head/).with(){order=cat(order,"W");return(value)};return([out,order])}
