fn yield_items(payload) {return(payload)}

Value:: I {order="";out=filter_nonempty(yield_items({order=cat(order,"S");["head","",undef,"tail"]}));return([out,order])}
