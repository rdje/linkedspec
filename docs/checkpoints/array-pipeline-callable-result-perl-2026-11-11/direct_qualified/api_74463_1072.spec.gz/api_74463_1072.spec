Value:: I {order="";out=lowercase_each().with(){order=cat(order,"W");return(value)};return([out,order])}
