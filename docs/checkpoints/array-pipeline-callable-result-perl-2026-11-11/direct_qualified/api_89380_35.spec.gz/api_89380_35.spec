fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_nonempty(supply({order=cat(order,"S");["head:tail"]}),{order=cat(order,"X");1});return([out,order])}
