Value:: I {order="";out={"k":"tail"}.uppercase_each().with(){order=cat(order,"W");return(value)};return([out,order])}
