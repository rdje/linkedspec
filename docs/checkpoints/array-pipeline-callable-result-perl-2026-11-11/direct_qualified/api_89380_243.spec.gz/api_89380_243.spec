fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_nonempty(supply(undef)).with(){order=cat(order,"W");return(value.count())};return([out,order])}
