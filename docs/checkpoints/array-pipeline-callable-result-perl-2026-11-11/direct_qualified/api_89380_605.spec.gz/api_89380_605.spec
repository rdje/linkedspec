fn yield_items(payload) {return(payload)}

Value:: I {order="";out=yield_items({order=cat(order,"S");["head","tail"]}).uppercase_each();return([out,order])}
