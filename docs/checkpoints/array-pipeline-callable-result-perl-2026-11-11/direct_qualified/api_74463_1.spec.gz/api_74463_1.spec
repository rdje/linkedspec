Value:: I {return([split_each(["head:tail"],":"),["head:tail"].split_each(":")])}
