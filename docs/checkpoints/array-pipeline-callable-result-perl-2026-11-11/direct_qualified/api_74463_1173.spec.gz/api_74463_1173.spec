Value:: I {order="";out=undef.filter_match(/^head/).with(){order=cat(order,"W");return(value)};return([out,order])}
