fn bad(...items, tail) { return(undef) }
Top::
 /x/
