Value:: I {order="";out={"k":"tail"}.lowercase_each().with(){order=cat(order,"W");return(value)};return([out,order])}
