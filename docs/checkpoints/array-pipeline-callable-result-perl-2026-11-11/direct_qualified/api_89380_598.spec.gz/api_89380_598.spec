fn yield_items(payload) {return(payload)}

Value:: I {order="";out=yield_items({order=cat(order,"S");["HEAD","TAIL"]}).lowercase_each();return([out,order])}
