Value:: I {return([trim_each([" head "," tail "]),[" head "," tail "].trim_each()])}
