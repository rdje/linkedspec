Value:: I {order="";out={"k":1}.uniq().with(){order=cat(order,"W");return(value.count())};return([out,order])}
