Value:: I {order="";out=undef.uniq().with(){order=cat(order,"W");return(value)};return([out,order])}
