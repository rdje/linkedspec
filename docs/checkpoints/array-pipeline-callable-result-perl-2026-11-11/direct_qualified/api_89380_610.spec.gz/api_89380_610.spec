fn yield_items(payload) {return(payload)}

Value:: I {order="";out=uniq(yield_items({order=cat(order,"S");["head","head","tail"]}));return([out,order])}
