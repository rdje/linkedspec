Value:: I {order="";out={3}.filter_match(/^head/).with(){order=cat(order,"W");return(value)};return([out,order])}
