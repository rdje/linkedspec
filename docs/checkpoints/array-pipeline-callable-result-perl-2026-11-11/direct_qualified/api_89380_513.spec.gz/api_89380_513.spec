fn supply(seed) {return(seed)}

Value:: I {order="";out=supply({"k":"head"}).filter_match(/^head/).with(){order=cat(order,"W");return(value.count())};return([out,order])}
