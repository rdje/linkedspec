Value:: I {return(split_each(["head:tail"],{items="bad";items+=1;":"}))}
