fn yield_items(payload) {return(payload)}

Value:: I {order="";out=yield_items({order=cat(order,"S");["head","",undef,"tail"]}).filter_nonempty();return([out,order])}
