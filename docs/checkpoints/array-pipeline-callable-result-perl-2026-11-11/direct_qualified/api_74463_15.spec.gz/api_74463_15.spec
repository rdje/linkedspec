Value:: I {order="";out=["head:tail"].split_each(":").set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
