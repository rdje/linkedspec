fn supply(seed) {return(seed)}

Value:: I {order="";out=lowercase_each(supply({order=cat(order,"S");["head:tail"]}),{order=cat(order,"X");1});return([out,order])}
