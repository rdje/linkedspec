fn yield_items(payload) {return(payload)}

Value:: I {order="";out=trim_each(yield_items({order=cat(order,"S");[" head "," tail "]}));return([out,order])}
