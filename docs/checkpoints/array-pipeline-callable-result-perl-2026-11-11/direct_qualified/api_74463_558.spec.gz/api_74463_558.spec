Value:: I {order="";out=3.filter_match(/./).with(){order=cat(order,"W");return(value.count())};return([out,order])}
