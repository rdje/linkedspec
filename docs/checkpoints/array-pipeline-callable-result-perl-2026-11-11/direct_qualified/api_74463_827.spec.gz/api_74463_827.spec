Value:: I {return(filter_nonempty({3}))}
