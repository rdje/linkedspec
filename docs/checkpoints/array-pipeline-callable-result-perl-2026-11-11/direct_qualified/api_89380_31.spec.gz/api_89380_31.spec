fn supply(seed) {return(seed)}

Value:: I {order="";out=supply({order=cat(order,"S");["head:tail"]}).trim_each({order=cat(order,"X");1});return([out,order])}
