fn supply(seed) {return(seed)}

Value:: I {order="";out=filter_match(supply(3),/^head/).with(){order=cat(order,"W");return(value.count())};return([out,order])}
