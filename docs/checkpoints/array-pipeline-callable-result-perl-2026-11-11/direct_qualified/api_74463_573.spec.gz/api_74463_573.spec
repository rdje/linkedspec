Value:: I {order="";out=undef.filter_match(/./).with(){order=cat(order,"W");return(value.count())};return([out,order])}
