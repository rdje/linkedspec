Value:: I {order="";out=trim_each({order=cat(order,"S");[" tail "]}).last().uppercase();return([out,order])}
