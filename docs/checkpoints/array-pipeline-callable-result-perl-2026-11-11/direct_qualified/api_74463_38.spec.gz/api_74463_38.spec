Value:: I {return([filter_nonempty(["head","","tail"]),["head","","tail"].filter_nonempty()])}
