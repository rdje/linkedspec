Value:: I {order="";out=["HEAD","TAIL"].lowercase_each().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
