fn supply(seed) {return(seed)}

Value:: I {return(split_each(supply(3),":"))}
