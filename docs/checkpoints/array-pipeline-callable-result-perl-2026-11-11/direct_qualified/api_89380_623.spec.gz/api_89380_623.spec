fn yield_items(payload) {return(payload)}

Value:: I {order="";out=filter_match(yield_items({order=cat(order,"S");["head","tail"]}),/^head/);return([out,order])}
