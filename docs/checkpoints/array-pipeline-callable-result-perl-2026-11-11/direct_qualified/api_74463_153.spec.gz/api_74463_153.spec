Value:: I {return(split_each({items="bad";items+=1;["head:tail"]},":"))}
