fn supply(seed) {return(seed)}

Value:: I {order="";out=uniq(supply(undef)).with(){order=cat(order,"W");return(value.count())};return([out,order])}
