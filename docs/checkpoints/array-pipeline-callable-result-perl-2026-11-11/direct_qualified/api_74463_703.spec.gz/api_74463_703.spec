Value:: I {return(3.trim_each())}
