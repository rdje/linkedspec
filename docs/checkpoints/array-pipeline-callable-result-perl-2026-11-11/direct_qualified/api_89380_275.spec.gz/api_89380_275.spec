fn supply(seed) {return(seed)}

Value:: I {return(lowercase_each(supply(3)))}
