Value:: I {order="";out=undef.uppercase_each().with(){order=cat(order,"W");return(value.count())};return([out,order])}
