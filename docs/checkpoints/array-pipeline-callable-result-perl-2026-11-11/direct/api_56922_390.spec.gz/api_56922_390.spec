Value:: I {order="";out=undef.lowercase_each().with(){order=cat(order,"W");return(value.count())};return([out,order])}
