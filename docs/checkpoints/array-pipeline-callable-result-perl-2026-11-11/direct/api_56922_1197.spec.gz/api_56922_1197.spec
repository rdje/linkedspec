Value:: I {order="";out=split_each(["head"]).with(){order=cat(order,"W");return(value)};return([out,order])}
