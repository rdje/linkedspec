Value:: I {order="";out=3.uniq().with(){order=cat(order,"W");return(value.count())};return([out,order])}
