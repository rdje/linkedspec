fn all_values(...items) { return(items) }
Top::
 /x/ -> Done {
   value = "";
   set(out, all_values(value = cat(value, "a"), value = cat(value, "b")));
   return([out, value])
 }
Done::
 /x/
