Value:: I {items=[" a "," a "];out=trim_each(items);return([out,items])}
