Value:: I {return(uppercase_each({"k":1}))}
