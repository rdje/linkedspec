Value:: I {order="";out=array("tail").trim_each().set_key({order=cat(order,"K");"k"},1).with(){order=cat(order,"W");return("ran")};return([out,order])}
