Value:: I {order="";out=[].uppercase_each().with(){order=cat(order,"W");return(value)};return([out,order])}
