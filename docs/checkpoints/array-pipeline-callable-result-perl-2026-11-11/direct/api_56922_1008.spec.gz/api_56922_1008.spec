Value:: I {order="";out=3.filter_nonempty().with(){order=cat(order,"W");return(value)};return([out,order])}
