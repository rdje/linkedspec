Value:: I {order="";out=3.lowercase_each().with(){order=cat(order,"W");return(value.count())};return([out,order])}
