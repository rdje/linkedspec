Value:: I {return(trim_each({"k":1}))}
