"""Immutable result-guard recovery; current SDK freshness is a separate boundary."""
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[3]
BASE = Path('docs/checkpoints/array-pipeline-callable-result-perl-2026-11-11')
INTAKE = Path('docs/checkpoints/array-pipeline-callable-perl-2026-11-11')
ACTIVATION = '5f22dae8d3a10cd10f4d2ecfbc6d0be9fd71e172'
OWNER = 'perl/LinkedSpec/ActionIR/MethodLowering.pm'
PRIVATE = '.linkedspec-data/scratch/callable-pipeline-result-perl/owner.pm'
NORMAL = 't/array_pipeline_callable_result_guard_composition.t'
FIXTURE = 'tests/fixtures/array_pipeline_callable_result_guard_perl_cases.json'

def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    # Python equality conflates Boolean false and Number0; JSON does not.
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True)


def same(a, b):
    assert encoded(a) == encoded(b)


def recover(phase):
    folder = ROOT / BASE / phase
    rows = json.loads((folder / 'input-identities.json').read_bytes())
    needed = {OWNER, PRIVATE, NORMAL, FIXTURE, str(INTAKE / 'classification.json')}
    bodies, seen = {}, set()
    with tarfile.open(folder / 'inputs-before-use.tar.gz') as archive:
        for member in archive:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and '..' not in path.parts
            assert member.name not in seen; seen.add(member.name)
            raw = archive.extractfile(member).read(); row = rows[member.name]
            assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
            assert member.mode & 0o777 == row['mode']
            if member.name in needed:
                bodies[member.name] = raw
    assert seen == rows.keys()
    return bodies, rows


def channel(phase, name, stream):
    return gzip.decompress((ROOT / BASE / phase / (name + '-' + stream + '.log.gz')).read_bytes())


def parsed(raw, tag):
    rows = {}
    pattern = re.compile(re.escape(tag) + r' (\w+) (\{.*\})$')
    for line in raw.decode().splitlines():
        match = pattern.search(line)
        if match:
            key, body = match.groups(); assert key not in rows
            rows[key] = json.loads(body)
    return rows


def normalized(value):
    if isinstance(value, dict):
        return {key: normalized(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalized(item) for item in value]
    if isinstance(value, str):
        return re.sub(r'\(eval \d+\)', '(eval SERIAL)', value)
    return value


def projection(row):
    return normalized({key: value for key, value in row.items()
        if key not in ('module_input', 'handler_input', 'substitution')})


def metadata(ready, helper=None):
    return dict(language_agnostic_action_ir_ready=ready, raw_perl_dependency_count=0,
        canonical_action_ir_fallback_count=0, unresolved_helper_count=0 if ready else 1,
        unresolved_helpers=[] if ready else [helper])


def accepted(row, value, ready, helper=None):
    assert row['native_callable'] == row['loaded'] == 1
    for field in ('descriptor_error', 'emission_error', 'build_error', 'native_error', 'load_error', 'fresh_error'):
        assert field in row and row[field] is None, field
    assert row.get('build_context_error') is None
    same(row['native'], value); same(row['fresh'], value)
    same(row['metadata'], metadata(ready, helper))
    same(row['warnings'], [])
    if 'host_before' in row:
        same(row['host_after'], row['host_before'])


def command(phase, name, argv):
    record = json.loads((ROOT / BASE / phase / (name + '-command.json')).read_bytes())
    same(record, dict(cwd='.', argv=argv))


def artifacts(phase, observations, inputs, cases):
    assert inputs.keys() == observations.keys() == cases.keys()
    for key, row in observations.items():
        assert inputs[key]['source'] == cases[key]['source']
        for field, body in (('module_input', 'emitted'), ('handler_input', 'handler')):
            record = row[field]; path = PurePosixPath(record['path'])
            assert not path.is_absolute() and '..' not in path.parts
            assert str(path).startswith(str(BASE / phase) + '/')
            raw = gzip.decompress((ROOT / str(path)).read_bytes())
            assert len(raw) == record['bytes'] and digest(raw) == record['sha256']
            assert raw == inputs[key][body].encode()
        if not row['loaded']:
            assert 'fresh' not in row and 'fresh_error' not in row and 'fresh_cursor' not in row


