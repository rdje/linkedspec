Value:: I {order="";out=[].uniq().with(){order=cat(order,"W");return(value)};return([out,order])}
