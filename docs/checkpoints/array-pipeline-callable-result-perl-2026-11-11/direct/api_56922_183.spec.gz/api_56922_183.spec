Value:: I {items=[" a "," a "];trim_each(items);return(items)}
