fn pair(left, right) { return([left, right]) }
fn collect(prefix, ...items) { return(items) }
Top::
 /x/ -> Done { return([pair(1, 2, 3), collect()]) }
Done::
 /x/
