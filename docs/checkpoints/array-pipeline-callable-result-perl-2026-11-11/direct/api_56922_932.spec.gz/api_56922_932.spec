Value:: I {order="";out=undef.split_each(":").with(){order=cat(order,"W");return(value)};return([out,order])}
