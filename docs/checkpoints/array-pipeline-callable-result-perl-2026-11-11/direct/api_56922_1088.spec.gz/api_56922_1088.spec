Value:: I {order="";out=3.uppercase_each().with(){order=cat(order,"W");return(value)};return([out,order])}
