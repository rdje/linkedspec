Value:: I {items=["head:tail"];out=split_each(items,{items=["changed"];":"});return([out,items])}
