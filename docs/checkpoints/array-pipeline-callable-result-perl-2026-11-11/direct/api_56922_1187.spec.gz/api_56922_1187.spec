Value:: I {order="";out=[].filter_match(/^head/).with(){order=cat(order,"W");return(value)};return([out,order])}
