Value:: I {order="";out={"k":"tail"}.split_each(":").with(){order=cat(order,"W");return(value)};return([out,order])}
