Value:: I {order="";out=["head"].split_each().with(){order=cat(order,"W");return(value)};return([out,order])}
