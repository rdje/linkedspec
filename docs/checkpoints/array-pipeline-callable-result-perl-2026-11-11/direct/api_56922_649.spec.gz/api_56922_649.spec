Value:: I {return(["head:tail"].split_each({items="bad";items+=1;":"}).set_key({order=cat(order,"K");"k"},1).coalesce("masked"))}
