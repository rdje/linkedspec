Value:: I {items=[false,0,undef,"0",""];out=uniq(items);return([out,items])}
