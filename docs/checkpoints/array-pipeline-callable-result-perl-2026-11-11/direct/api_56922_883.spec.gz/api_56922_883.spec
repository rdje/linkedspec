Value:: I {order="";out=["head:tail"].split_each({order=cat(order,"D");":"});return([out,order])}
