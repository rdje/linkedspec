Value:: I {return([uppercase_each(["head","tail"]),["head","tail"].uppercase_each()])}
