Value:: I {order="";out=[].trim_each().with(){order=cat(order,"W");return(value)};return([out,order])}
