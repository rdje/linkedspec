fn bad(...) { return(undef) }
Top::
 /x/
