fn bad(item, ...item) { return(undef) }
Top::
 /x/
