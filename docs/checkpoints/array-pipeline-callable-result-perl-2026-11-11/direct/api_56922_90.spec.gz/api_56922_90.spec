Value:: I {order="";out=["head","tail","head"].uniq().set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
