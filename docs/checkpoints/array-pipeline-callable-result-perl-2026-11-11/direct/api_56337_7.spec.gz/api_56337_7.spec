fn pair(left, right) { return([left, right]) }
fn all_values(...items) { return(items) }
fn collect(prefix, ...items) { return({ "prefix" : prefix, "items" : items }) }

Top::
 /x/ -> Done {
   return({
     "fixed_exact" : pair("left", "right"),
     "rest_only_empty" : all_values(),
     "rest_only_mixed_values" : all_values(1, [2], { "k" : 3 }, false, undef),
     "fixed_prefix_empty_rest" : collect("p"),
     "fixed_prefix_nonempty_rest" : collect("p", "a", "b"),
     "rest_result_receiver_chain" : all_values(1, 2, 3).length()
   })
 }

Done::
 /x/
