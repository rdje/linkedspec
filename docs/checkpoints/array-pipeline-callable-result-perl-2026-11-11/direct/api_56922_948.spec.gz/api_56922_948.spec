Value:: I {order="";out=[].split_each(":").with(){order=cat(order,"W");return(value)};return([out,order])}
