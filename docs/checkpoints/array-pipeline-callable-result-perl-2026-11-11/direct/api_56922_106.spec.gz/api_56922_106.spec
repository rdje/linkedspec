Value:: I {order="";out=["head","other"].filter_match(/^h/).set_key({order=cat(order,"K");"k"},{order=cat(order,"V");1});return([out,order])}
