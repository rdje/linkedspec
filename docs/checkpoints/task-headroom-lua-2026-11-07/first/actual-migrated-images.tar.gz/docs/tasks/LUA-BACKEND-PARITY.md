# LUA-BACKEND-PARITY: Lua LinkedSpec Backend Parity

## Metadata

- Tree ID: `LUA-BACKEND-PARITY`
- Status: `done` / `closed`
- Roadmap lane: `Overall roadmap - future backend parity (Lua third)`
- Created: `2026-07-11`
- Last updated: `2026-07-16` (`.8.4` admits Lua as the fifth exact backend at 80/0/0 and closes the tree)
- Owner: repo-local workflow

## Goal

Implement a native Lua LinkedSpec backend that consumes the same universal `.spec` language and exposes the same
observable features and behavior as Perl, Rust, Dart, and Julia. The primary product is an idiomatic in-process Lua
module; `linkedspec-lua` is a thin distinct executable implementing the exact shared primary CLI contract.

## Fixed constraints

- PUC Lua 5.4 is the primary conformance runtime. LuaJIT is a secondary compatibility leg and may not weaken or
  fork semantics because it implements Lua 5.1 language behavior.
- The backend may not create Lua-only `.spec` syntax, helper names, value kinds, diagnostics, regex behavior,
  result shapes, trace roles, CLI options, or corpus fixtures.
- Lua tables must project the four LinkedSpec value kinds without ambiguity: scalar, array, harray, and codeblock.
  Array versus harray identity may not be guessed from incidental key layout at public boundaries.
- Physical newlines separate statements. Semicolons only separate multiple statements on one physical line; the
  last statement on that line needs no trailing semicolon.
- For callables accepting a final codeblock, `call(args) { ... }` and `call(args, { ... })` are one AST/behavior
  contract across helper, user-function, and receiver-method surfaces.
- Single- and double-quoted DSL strings remain universal source syntax. Host Lua literal rules may not leak into
  `.spec` parsing or generated-source payloads.
- Lua patterns and LPeg are not presumed regex-compatible. The selected matching adapter must prove seek/consume,
  alternatives, captures, named captures, Unicode character projection, and the 105-fixture corpus contract.
- No Perl plugin machinery is part of the backend-neutral product contract.
- No implementation change occurs until its exact leaf is active and task-owned.

## Acceptance criteria

- `lua/` contains a repository-owned module/test/CLI layout that runs without untracked global state.
- Native APIs accept `.spec` source and input as in-memory Lua values, parse/validate/compile/execute in the current
  process, and return structured Lua results/diagnostics without a required CLI, subprocess, or temporary file.
- The source frontend, typed ActionIR, compiled state, runtime, staged parser registry, user functions, diagnostics,
  trace, native named/file loading, descriptors, and generated source implement the same contracts as the four
  admitted backends.
- The runtime passes the complete checked-in 105-case interpreter manifest with exact expected JSON values and the
  current 246-name public ActionIR surface checks.
- `linkedspec-lua` passes the same 61 primary CLI cases under default and POSIX option environments: identical
  options/meanings, zero positionals/subcommands, canonical output/error/trace bytes, and exit codes.
- Generated Lua source implements contract v1: deterministic compiled-state-plus-identity emission, Unicode text
  persisted as strict UTF-8, metadata/errors, exact ten-family authoritative plans, four rejections, portable trace,
  isolated host load, all-family proof, and the exact contract-sourced accepted 8/105 subset.
- The executable capability census expands deliberately for Lua and reaches all-pass before the backend is called
  complete. Existing 60/0/0 Perl/Rust/Dart/Julia states may not regress.
- mdBook, roadmap, Knowledge Map, live docs, task state, and artifact cleanup stay aligned after every leaf.
- Every leaf commits through `COMMIT.md` with its leaf id.

## Task tree

- ID: `LUA-BACKEND-PARITY`
  Status: `done`
  Goal: Implement Lua as the third full-parity future backend.
  Children: `.1`, `.2`, `.3`, `.4`, `.5`, `.6`, `.7`, `.8`
  Commit: `LUA-BACKEND-PARITY.8.4 - admit Lua capability parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY`.

- ID: `LUA-BACKEND-PARITY.1`
  Status: `done`
  Goal: Establish toolchain, package layout, test harness, and corpus IO before parser behavior.
  Children: `.1.1`, `.1.2`, `.1.3`

- ID: `LUA-BACKEND-PARITY.1.1`
  Status: `done`
  Goal: Lock Lua runtime/tooling and repository layout choices.
  Acceptance: Reverify PUC Lua/LuaJIT/LPeg availability; record the absence or adoption of LuaRocks, Busted,
    Luacheck, and StyLua; choose dependency/test strategy, module search paths, `lua/` layout, `linkedspec-lua`,
    corpus runner, writable cache boundaries, and primary-versus-secondary runtime gates before source code.
  Commit: `LUA-BACKEND-PARITY.1.1 - lock Lua toolchain and package policy`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.1.1`.

- ID: `LUA-BACKEND-PARITY.1.2`
  Status: `done`
  Goal: Add the minimal native Lua module, CLI/corpus-runner stubs, and repo-owned test driver.
  Acceptance: In-memory module load, backend status, exact entrypoint identities, primary PUC Lua smoke, optional
    LuaJIT compatibility smoke, and cleanup work without network/global package installation.
  Commit: `LUA-BACKEND-PARITY.1.2 - scaffold native Lua backend`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.1.2`.

- ID: `LUA-BACKEND-PARITY.1.3`
  Status: `done`
  Goal: Add strict manifest/fixture IO without parser execution.
  Acceptance: Validate the 105-case manifest, exact directory membership, required UTF-8 files, expected JSON, and
    stale/missing fixtures; keep execution disabled until runtime ownership exists.
  Commit: `LUA-BACKEND-PARITY.1.3 - add strict Lua corpus IO`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.1.3`.

- ID: `LUA-BACKEND-PARITY.2`
  Status: `done`
  Goal: Implement the universal `.spec` frontend.
  Children: `.2.1`, `.2.2`, `.2.3`, `.2.4`

- ID: `LUA-BACKEND-PARITY.2.1`
  Status: `done`
  Goal: Define typed source AST and lossless JSON/provenance projection.
  Acceptance: Spec/rule/mode/body/edge/lifecycle/function/parse-job/source-span types match the neutral schema;
    explicit tagged representations preserve scalar/array/harray/codeblock identity.
  Commit: `LUA-BACKEND-PARITY.2.1 - add typed Lua source AST`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.2.1`.

- ID: `LUA-BACKEND-PARITY.2.2`
  Status: `done`
  Goal: Parse rule paragraphs and universal source syntax.
  Acceptance: Headers/modes, regex slots, action/blind edges, lifecycle/plain blocks, markers, fluent continuations,
    comments, nested blocks, quote forms, and newline/semicolon statement boundaries have focused fixtures.
  Commit: `LUA-BACKEND-PARITY.2.2 - parse Lua rule source`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.2.2`.

- ID: `LUA-BACKEND-PARITY.2.3`
  Status: `done`
  Goal: Add exact source validation and strict-syntax behavior.
  Acceptance: Top rule, duplicates, edge families/targets/indexes, raw fallback, helper/function collisions, regex
    structure, and strict unused rules match the admitted variants with typed diagnostics.
  Commit: `LUA-BACKEND-PARITY.2.3 - validate Lua source AST`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.2.3`.

- ID: `LUA-BACKEND-PARITY.2.4`
  Status: `done`
  Goal: Consume spec-driven top-level user-function shells.
  Acceptance: `specs/user_function_definition.spec` owns shell parsing/projection; Lua has no competing raw scanner;
    body payload/jobs/AST and provenance remain ordered and exact.
  Commit: `LUA-BACKEND-PARITY.2.4 - project Lua function shells`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.2.4`.

- ID: `LUA-BACKEND-PARITY.3`
  Status: `done`
  Goal: Implement typed ActionIR, contracts, function registry, and compiled state.
  Children: `.3.1`, `.3.2`, `.3.3`, `.3.4`

- ID: `LUA-BACKEND-PARITY.3.1`
  Status: `done`
  Goal: Parse action/helper text into typed AST nodes.
  Acceptance: Calls/args, four value kinds, access, assignments, controls, block values, receiver chains, generic
    final-codeblock syntax, and value-drop statements are structural nodes rather than Lua code rewrites.
  Commit: `LUA-BACKEND-PARITY.3.1 - parse typed Lua ActionIR`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.3.1`.

- ID: `LUA-BACKEND-PARITY.3.2`
  Status: `done`
  Goal: Resolve current ActionIR contracts and generic diagnostics.
  Acceptance: The governed current-name inventory drives helpers/controls/methods; aliases canonicalize; registered
    functions resolve first; unknown/non-current calls never fall through to arbitrary Lua globals.
  Commit: `LUA-BACKEND-PARITY.3.2 - resolve Lua ActionIR contracts`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.3.2`.

- ID: `LUA-BACKEND-PARITY.3.3`
  Status: `done`
  Goal: Add ordered user-function and staged body-job registries.
  Acceptance: Exact arity, eager values, fresh frames, body source/payload/job/AST, and recursion diagnostics match
    neutral semantics; no implicit caller mutation or Lua closure leakage.
  Commit: `LUA-BACKEND-PARITY.3.3 - add Lua function registry`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.3.3`.

- ID: `LUA-BACKEND-PARITY.3.4`
  Status: `done`
  Goal: Compile source AST into typed effective state and descriptors.
  Acceptance: Ordered effective rules/functions, modes, regex/dependency state, action/blind/lifecycle payloads,
    source identities, and outward descriptor JSON match the exact shared contract.
  Commit: `LUA-BACKEND-PARITY.3.4 - compile Lua spec state`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.3.4`.

- ID: `LUA-BACKEND-PARITY.4`
  Status: `done`
  Goal: Implement matching and runtime execution.
  Children: `.4.1`, `.4.2`, `.4.3`, `.4.4`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4`.

- ID: `LUA-BACKEND-PARITY.4.1`
  Status: `done`
  Goal: Select and prove the regex/match-state adapter.
  Acceptance: Compare available Lua/LPeg/native-extension options against neutral regex fixtures; implement
    seek/consume, alternatives, captures/named captures, entry/local state, UTF-8 character offsets, line/column,
    zero progress, and invalid-pattern diagnostics without backend-specific regex semantics.
  Commit: `LUA-BACKEND-PARITY.4.1 - add Lua runtime matching`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.1`.

- ID: `LUA-BACKEND-PARITY.4.2`
  Status: `done`
  Goal: Execute rule modes, dispatch, lifecycles, recursion, and result channels.
  Acceptance: Default/OR/AND/repetition acode/bcode paths, bounds, cursor state, explicit return/next/exit, retv,
    local stores, lifecycle order, recursion/safety cutoffs, and direct output shape match the oracle.
  Commit: `LUA-BACKEND-PARITY.4.2 - add Lua runtime rule interpreter`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.2`.

- ID: `LUA-BACKEND-PARITY.4.3`
  Status: `done`
  Goal: Implement the complete helper/value/control/method surface in recursively split batches.
  Children: `.4.3.0`, `.4.3.1`, `.4.3.2`, `.4.3.3`, `.4.3.4`, `.4.3.5`, `.4.3.6`, `.4.3.7`, `.4.3.8`,
    `.4.3.9`
  Acceptance: Every current governed helper and method is behavior-tested, including scalar/string/number,
    array/harray mutation and pure operations, captures/positions/cursor/marks, controls, assignments, tree walks,
    diagnostic calls, and final-codeblock equivalence; split by mechanism before broad implementation.
  Commit: closed by `.4.3.9.2`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3`.

- ID: `LUA-BACKEND-PARITY.4.3.0`
  Status: `done`
  Goal: Split the complete Lua helper/value/control/method surface into mechanism-sized executable leaves.
  Acceptance: Every current family has one ordered owner with explicit dependencies, scope, verification, and
    no-drift closeout; no broad helper implementation starts before the split is durable.
  Commit: `LUA-BACKEND-PARITY.4.3.0 - split Lua runtime helper families`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.0`.

- ID: `LUA-BACKEND-PARITY.4.3.1`
  Status: `done`
  Goal: Centralize Lua's four-kind runtime stores, structural access/assignment, snapshots, and entry/match reads.
  Dependencies: `.4.2`
  Acceptance: Scalar/array/harray/codeblock/null/boolean/number values retain typed identity; named and bare store
    reads/writes, append/hash-index/nested assignment without autovivification, copy/array/hash snapshots, and all
    `entry_*` / `match_*` text/group/map/position helpers pass focused cross-backend examples.
  Commit: `LUA-BACKEND-PARITY.4.3.1 - add Lua runtime value capture helpers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.1`.

- ID: `LUA-BACKEND-PARITY.4.3.2`
  Status: `done`
  Goal: Implement scalar/string helpers and compatible receiver chains.
  Children: `.4.3.2.0`, `.4.3.2.1`, `.4.3.2.2`
  Dependencies: `.4.3.1`
  Acceptance: Definedness/emptiness/coalesce, `cat`, trim/case/length, substring/prefix/suffix/contains/replace,
    regex match/substitution flags, split bridges, lexical comparisons, scalar statement mutation, and receiver
    forms match catalog examples across the child leaves.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.5.1 - close Lua string helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2`.

- ID: `LUA-BACKEND-PARITY.4.3.2.0`
  Status: `done`
  Goal: Split pure scalar evaluation from regex-aware split/substitution and statement mutation before code.
  Acceptance: The two mechanisms have ordered owners and `.4.3.2.1` is the sole executable frontier.
  Commit: `LUA-BACKEND-PARITY.4.3.2.0 - split Lua scalar string mechanisms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.0`.

- ID: `LUA-BACKEND-PARITY.4.3.2.1`
  Status: `done`
  Goal: Implement pure scalar/string helpers, lexical comparisons, aliases, and compatible receiver chains.
  Children: `.4.3.2.1.0`, `.4.3.2.1.1`, `.4.3.2.1.2`, `.4.3.2.1.3`
  Dependencies: `.4.3.1`
  Acceptance: `concat`/`cat`, coalesce families, defined/undefined/empty predicates, trim/case/length, prefix/
    suffix/contains/remove, literal substring/replace, explicit `str_*` comparisons, stable scalar conversion,
    null propagation, and function/receiver composition match cross-backend examples.
  Verification: **PASS 2026-07-12.** Deterministic non-case strings, pinned Unicode 17 casing, and portable
    scalar-to-text coercion are complete through `.1.1`, `.1.2`, and `.1.3`.
  Commit: closed by `.4.3.2.1.3`

- ID: `LUA-BACKEND-PARITY.4.3.2.1.0`
  Status: `done`
  Goal: Isolate deterministic pure-string execution from the newly measured cross-backend Unicode casing policy gap.
  Dependencies: `.4.3.1`
  Acceptance: Measure special-case lower/uppercase behavior through real Perl, Rust-source, Dart, and Julia paths;
    record the root cause and exact divergent examples; give non-casing helpers and canonical Unicode casing separate
    ordered owners before runtime code changes.
  Commit: `LUA-BACKEND-PARITY.4.3.2.1.0 - split Unicode casing parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.1.0`.

- ID: `LUA-BACKEND-PARITY.4.3.2.1.1`
  Status: `done`
  Goal: Implement deterministic pure scalar/string helpers and compatible receiver chains except case conversion.
  Dependencies: `.4.3.2.1.0`
  Acceptance: `cat`, coalesce families, defined/undefined/empty predicates, trim/length, prefix/suffix/contains/remove,
    literal substring/replace, explicit `str_*` comparisons, stable scalar conversion, null propagation, lazy fallback,
    and function/receiver composition match cross-backend examples on both Lua ABIs.
  Commit: `LUA-BACKEND-PARITY.4.3.2.1.1 - add Lua pure string helpers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.1.1`.

- ID: `LUA-BACKEND-PARITY.4.3.2.1.2`
  Status: `done`
  Goal: Define and implement one versioned Unicode lower/uppercase contract across every LinkedSpec variant.
  Children: `.4.3.2.1.2.0`, `.4.3.2.1.2.1`, `.4.3.2.1.2.2`, `.4.3.2.1.2.3`, `.4.3.2.1.2.4`
  Dependencies: `.4.3.2.1.1`
  Acceptance: Select a canonical Unicode version and simple/full/special-casing policy; add a neutral fixture covering
    ordinary non-ASCII and divergent special cases (`ß`, `İ`, and `ﬃ`); align Perl, Rust, Dart, Julia, PUC Lua, and
    LuaJIT values and receiver chains without confusing Unicode semantics with UTF-8/UTF-16 host representation.
  Verification: **PASS 2026-07-12.** Unicode 17 full-default behavior is generated from one checksum-locked contract
    and passes the same 12 fixtures on Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT.
  Commit: closed by `.4.3.2.1.2.4`

- ID: `LUA-BACKEND-PARITY.4.3.2.1.2.0`
  Status: `done`
  Goal: Adopt the signoff Unicode casing policy and split its data/backend rollout before implementation.
  Dependencies: `.4.3.2.1.1`
  Acceptance: Record one versioned full-default locale-independent policy, normative data inputs, context behavior,
    normalization/encoding boundaries, generated-artifact drift gates, and bounded backend rollout owners.
  Commit: `LUA-BACKEND-PARITY.4.3.2.1.2.0 - adopt Unicode casing contract`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.1.2.0`.

- ID: `LUA-BACKEND-PARITY.4.3.2.1.2.1`
  Status: `done`
  Goal: Add the reproducible Unicode 17.0.0 data, generator, neutral contract, fixtures, and drift checker.
  Dependencies: `.4.3.2.1.2.0`
  Acceptance: Verified official `UnicodeData.txt`, `SpecialCasing.txt`, and `DerivedCoreProperties.txt` inputs plus
    license/source hashes generate deterministic lower/upper maps and Cased/Case_Ignorable ranges; the executable
    neutral fixture covers identity, expansion, combining output, supplementary characters, and Final_Sigma context;
    regeneration and schema/count/hash checks fail closed without requiring network during ordinary gates.
  Commit: `LUA-BACKEND-PARITY.4.3.2.1.2.1 - add Unicode casing data contract`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.1.2.1`.

- ID: `LUA-BACKEND-PARITY.4.3.2.1.2.2`
  Status: `done`
  Goal: Align Perl and Rust casing helpers to the generated Unicode 17.0.0 contract.
  Dependencies: `.4.3.2.1.2.1`
  Acceptance: Function and receiver lower/uppercase paths consume generated tables/context rules, not host Unicode
    versions; neutral fixture and focused/full Perl/Rust gates pass without changing null/aggregate boundaries.
  Commit: `LUA-BACKEND-PARITY.4.3.2.1.2.2 - align Perl and Rust Unicode casing`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.1.2.2`.

- ID: `LUA-BACKEND-PARITY.4.3.2.1.2.3`
  Status: `done`
  Goal: Align Dart and Julia casing helpers to the generated Unicode 17.0.0 contract.
  Dependencies: `.4.3.2.1.2.2`
  Acceptance: Function and receiver lower/uppercase paths consume generated tables/context rules, not host Unicode
    versions; the same neutral fixture and focused/full Dart/Julia gates pass with exact strings.
  Commit: `LUA-BACKEND-PARITY.4.3.2.1.2.3 - align Dart and Julia Unicode casing`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.1.2.3`.

- ID: `LUA-BACKEND-PARITY.4.3.2.1.2.4`
  Status: `done`
  Goal: Enable generated Unicode casing on PUC Lua/LuaJIT and admit exact six-variant parity.
  Dependencies: `.4.3.2.1.2.3`
  Acceptance: Lua function/receiver lower/uppercase paths use the same generated maps/context rules without native
    byte/locale casing; both ABIs pass, six-variant fixture outputs are byte-identical UTF-8, full gates/docs/KM pass,
    and `.4.3.2.1.2` closes before scalar-to-text `.1.3` begins.
  Commit: `LUA-BACKEND-PARITY.4.3.2.1.2.4 - admit six-variant Unicode casing`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.1.2.4`.

- ID: `LUA-BACKEND-PARITY.4.3.2.1.3`
  Status: `done`
  Goal: Define one scalar-to-text coercion contract and align every LinkedSpec variant.
  Dependencies: `.4.3.2.1.2`
  Acceptance: A neutral fixture fixes `cat`/string-helper handling for null, array, harray, codeblock, booleans,
    integral-looking decimals, and nonintegral numbers; Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT return identical
    values and nulls. Retired `concat` remains rejected rather than becoming an accidental alias.
  Commit: `LUA-BACKEND-PARITY.4.3.2.1.3 - align scalar text coercion`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.1.3`.

- ID: `LUA-BACKEND-PARITY.4.3.2.2`
  Status: `done`
  Goal: Implement regex-aware scalar matching/substitution, split bridges, flags, and statement mutation.
  Children: `.4.3.2.2.0`, `.4.3.2.2.1`, `.4.3.2.2.2`, `.4.3.2.2.3`, `.4.3.2.2.4`, `.4.3.2.2.5`
  Dependencies: `.4.3.2.1`
  Acceptance: `matches`, regex/literal replacement, dual `substr`, scalar/array split bridges, governed flags and
    capture expansion, pure versus statement-only mutation, invalid-pattern boundaries, and receiver composition
    match the oracle on both Lua ABIs.
  Verification: **PASS 2026-07-12.** Ordered children close helper regex/matches, pure split, scalar regex mutation,
    explicit array split mutation, focused no-drift, and correct phase-6 routing for broader shipped fixtures.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.5.1 - close Lua string helper parity`

- ID: `LUA-BACKEND-PARITY.4.3.2.2.0`
  Status: `done`
  Goal: Measure and split Lua regex, split, and statement-mutation mechanisms before runtime code.
  Dependencies: `.4.3.2.1`
  Acceptance: LinkedSpec lowering/runtime probes and Lua ActionIR projections identify the distinct value,
    regex-compilation, receiver, scalar-store mutation, and array-store mutation seams; signoff-sized children own
    them in dependency order without changing runtime behavior.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.0 - split Lua regex string mechanisms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.2.0`.

- ID: `LUA-BACKEND-PARITY.4.3.2.2.1`
  Status: `done`
  Goal: Add one strict Lua helper-regex value/flag adapter and execute `matches` in function/receiver form.
  Dependencies: `.4.3.2.2.0`, `.4.1`
  Acceptance: Lua ActionIR regex values compile through the existing in-process PCRE2 owner; `i/m/s/x` affect
    compilation, `g/o` are accepted no-ops for predicates, unknown flags and invalid patterns follow the documented
    fail-closed helper boundary, null/non-text inputs return false, and terminal receiver composition is exact on
    PUC Lua and LuaJIT. The pre-existing Perl invalid-literal generation boundary is recorded, not silently treated
    as Lua authorization to change the reference engine.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.1 - add Lua helper regex matches`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.2.1`.

- ID: `LUA-BACKEND-PARITY.4.3.2.2.2`
  Status: `done`
  Goal: Implement pure literal/regex `split` values and the string receiver-to-array bridge.
  Dependencies: `.4.3.2.2.1`
  Acceptance: Function and receiver `split(value, delimiter)` preserve empty fields, distinguish literal and regex
    delimiters, split an empty literal delimiter by Unicode characters, apply the governed flag adapter, return an
    empty array on invalid regex input, and return a typed copied array from string receiver form without mutating
    sources. Downstream array-method continuation remains owned by `.4.3.4`, which depends on this bridge. Pure
    Unicode `substr` and literal `replace_substr` remain distinct and regression-locked.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.2 - add Lua pure split bridge`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.2.2`.

- ID: `LUA-BACKEND-PARITY.4.3.2.2.3`
  Status: `done`
  Goal: Implement statement-context scalar regex substitution through `substr` and `regex_subst`.
  Dependencies: `.4.3.2.2.1`
  Acceptance: A dropped four-argument call with a bare scalar target mutates that target; `g` selects global
    replacement, `i/m/s/x` compile, `o` is a no-op, `$0`/`$n` replacement expansion is deterministic, invalid
    patterns diagnose with rule attribution, and pure character-slice `substr(value,start,width?)` stays a value
    helper even when its result is discarded.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.3 - add Lua scalar regex mutation`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.2.3`.

- ID: `LUA-BACKEND-PARITY.4.3.2.2.4`
  Status: `done`
  Goal: Implement explicit array-target split replacement without crossing pure value semantics.
  Dependencies: `.4.3.2.2.2`, `.4.3.2.2.3`
  Acceptance: Dropped `split(array(target), source, delimiter)` replaces the named aggregate store for literal and
    regex delimiters, respects rule-local reset/snapshot behavior, leaves pure split source values untouched, and
    preserves scalar-held versus explicit aggregate boundaries on both Lua ABIs.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.4 - add Lua array split mutation`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.2.4`.

- ID: `LUA-BACKEND-PARITY.4.3.2.2.5`
  Status: `done`
  Goal: Close regex/split/mutation mechanism and public-documentation no-drift.
  Children: `.4.3.2.2.5.0`, `.4.3.2.2.5.1`
  Dependencies: `.4.3.2.2.2`, `.4.3.2.2.3`, `.4.3.2.2.4`
  Acceptance: Neutral focused fixtures cover the complete landed mechanism on both ABIs; catalog/book/README/task/
    KM/live state contain no retired `concat`, helper-flag, pure-versus-mutation, or frontier drift. Exact shipped
    execution stays owned by `.6.2`, after the later helper/control/output families and executable corpus runner.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.5.1 - close Lua string helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.2.5`.

- ID: `LUA-BACKEND-PARITY.4.3.2.2.5.0`
  Status: `done`
  Goal: Diagnose and correctly route the premature shipped-corpus acceptance before closeout work.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.5.0 - route Lua string corpus proof`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.2.5.0`.

- ID: `LUA-BACKEND-PARITY.4.3.2.2.5.1`
  Status: `done`
  Goal: Close focused regex/split/mutation and public-surface no-drift.
  Dependencies: `.4.3.2.2.5.0`
  Acceptance: Both Lua ABIs pass the complete focused gate; public docs explain pure versus statement mutation,
    strict flags, captures, empty fields, and the current explicit-target compatibility boundary; current authored
    surfaces contain no retired `concat`; task/roadmap/KM/book/status state agrees before numeric helpers.
  Commit: `LUA-BACKEND-PARITY.4.3.2.2.5.1 - close Lua string helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.2.2.5.1`.

- ID: `LUA-BACKEND-PARITY.4.3.3`
  Status: `done`
  Goal: Implement numeric helpers, aliases, symbol callees, reducers, and number receiver chains.
  Children: `.4.3.3.0`, `.4.3.3.1`, `.4.3.3.2`, `.4.3.3.3`, `.4.3.3.4`
  Dependencies: `.4.3.1`
  Acceptance: Arithmetic/unary/clamp/comparison/range and aggregate min/max/sum/avg/median behavior, invalid-input
    null propagation, division/modulo fences, word aliases, symbol callees, and receiver forms match the oracle.
  Commit: `LUA-BACKEND-PARITY.4.3.3.4 - close Lua numeric helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3`.

- ID: `LUA-BACKEND-PARITY.4.3.3.0`
  Status: `done`
  Goal: Audit the neutral numeric contract and split implementation by runtime mechanism before code.
  Commit: `LUA-BACKEND-PARITY.4.3.3.0 - split Lua numeric helper mechanisms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.0`.

- ID: `LUA-BACKEND-PARITY.4.3.3.1`
  Status: `done`
  Goal: Implement strict scalar numeric helper evaluation.
  Children: `.4.3.3.1.0`, `.4.3.3.1.1`, `.4.3.3.1.2`, `.4.3.3.1.3`, `.4.3.3.1.4`
  Dependencies: `.4.3.3.0`
  Acceptance: Canonical unary, variadic arithmetic, integer modulo, clamp, scalar min/max, and comparisons accept
    only portable finite decimal values; invalid/missing/aggregate/boolean inputs, zero divisors, non-integer
    modulo operands, inverted bounds, and non-finite results return null identically on PUC Lua and LuaJIT.

- ID: `LUA-BACKEND-PARITY.4.3.3.1.0`
  Status: `done`
  Goal: Measure cross-backend scalar numeric drift and split neutral policy from backend implementation.
  Dependencies: `.4.3.3.0`
  Commit: `LUA-BACKEND-PARITY.4.3.3.1.0 - split scalar numeric contract alignment`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.1.0`.

- ID: `LUA-BACKEND-PARITY.4.3.3.1.1`
  Status: `done`
  Goal: Adopt a versioned neutral scalar numeric helper contract and executable fixtures.
  Dependencies: `.4.3.3.1.0`
  Acceptance: An ADR and machine-readable contract define accepted finite decimal inputs, exact/variadic arities,
    invalid-to-null behavior, numeric comparison truth, half-away rounding, min/max, clamp, division, and signed
    integer modulo without host-language fallback; an offline checker validates schema/cases and tracked inputs.
  Commit: `LUA-BACKEND-PARITY.4.3.3.1.1 - adopt scalar numeric helper contract`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.1.1`.

- ID: `LUA-BACKEND-PARITY.4.3.3.1.2`
  Status: `done`
  Goal: Align Perl and Rust scalar numeric helpers with the neutral contract.
  Dependencies: `.4.3.3.1.1`
  Acceptance: Direct canonical helper execution in both backends consumes every contract case; booleans and invalid
    operands return null, arities are exact/variadic as governed, signed modulo and numeric strings match, and full
    Perl/Rust gates pass without weakening unrelated generic scalar coercion.
  Commit: `LUA-BACKEND-PARITY.4.3.3.1.2 - align Perl Rust scalar numeric helpers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.1.2`.

- ID: `LUA-BACKEND-PARITY.4.3.3.1.3`
  Status: `done`
  Goal: Align Dart and Julia scalar numeric helpers with the neutral contract.
  Dependencies: `.4.3.3.1.1`, `.4.3.3.1.2`
  Acceptance: Both native interpreters consume every unchanged contract case through direct canonical calls;
    numeric parsing, arity, invalid/null, signed modulo, and result normalization agree with Perl/Rust, and full
    package/CLI/corpus gates pass.
  Commit: `LUA-BACKEND-PARITY.4.3.3.1.3 - align Dart Julia scalar numeric helpers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.1.3`.

- ID: `LUA-BACKEND-PARITY.4.3.3.1.4`
  Status: `done`
  Goal: Implement Lua scalar numeric helpers and admit exact six-runtime behavior.
  Dependencies: `.4.3.3.1.2`, `.4.3.3.1.3`
  Acceptance: One Lua evaluator consumes every neutral case for canonical helpers on PUC Lua and LuaJIT, never
    delegates syntax/rounding/modulo policy to host accident, full dual-ABI tests pass, and one six-runtime checker
    proves exact results before aliases/receivers `.4.3.3.2`.
  Commit: `LUA-BACKEND-PARITY.4.3.3.1.4 - implement Lua scalar numeric helpers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.1.4`.

- ID: `LUA-BACKEND-PARITY.4.3.3.2`
  Status: `done`
  Goal: Admit numeric word aliases, symbol callees, and number receiver chains through the scalar evaluator.
  Dependencies: `.4.3.3.1`
  Acceptance: All governed word/symbol spellings canonicalize to the same evaluator; integer/float/bare-scalar
    receivers inject exactly one first argument; number-returning links compose; comparison links return numeric
    truth values and terminate later receiver continuation on both Lua ABIs.
  Commit: `LUA-BACKEND-PARITY.4.3.3.2 - add Lua numeric call and receiver forms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.2`.

- ID: `LUA-BACKEND-PARITY.4.3.3.3`
  Status: `done`
  Goal: Implement aggregate numeric reducers and array receiver terminals.
  Dependencies: `.4.3.3.1`, `.4.3.3.2`
  Acceptance: `num_sum`/`avg`/`median`/`range` and one-array `min`/`max` preserve typed arrays, reject any
    non-numeric element, implement the governed empty-array results, leave source values unchanged, and execute
    equivalent explicit-array, bare-array, and terminal receiver forms on both Lua ABIs.
  Commit: `LUA-BACKEND-PARITY.4.3.3.3 - add Lua numeric aggregate reducers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.3`.

- ID: `LUA-BACKEND-PARITY.4.3.3.4`
  Status: `done`
  Goal: Close focused numeric helper and public-surface no-drift.
  Dependencies: `.4.3.3.1`, `.4.3.3.2`, `.4.3.3.3`
  Acceptance: Focused canonical/alias/symbol/receiver/reducer/invalid-boundary proof passes the full dual-ABI gate;
    Lua README, mdBook, task/index/roadmaps, Knowledge Map, architecture/live docs, and runtime status agree before
    array helpers `.4.3.4`; exact shipped-corpus proof remains owned by dependency-complete phase 6.
  Commit: `LUA-BACKEND-PARITY.4.3.3.4 - close Lua numeric helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.3.4`.

- ID: `LUA-BACKEND-PARITY.4.3.4`
  Status: `done`
  Goal: Implement array construction, pure helpers, mutation, bridges, reducers, and receiver chains.
  Children: `.4.3.4.0`, `.4.3.4.1`, `.4.3.4.2`, `.4.3.4.3`, `.4.3.4.4`, `.4.3.4.5`, `.4.3.4.6`
  Dependencies: `.4.3.1`, `.4.3.2`, `.4.3.3`
  Acceptance: Typed construction/copy/flatten/concat, selection/order/membership/join/split/filter/map-style
    transforms, append/end mutations, child push/index reuse, numeric terminals, and snapshot isolation match the
    catalog without false/null or empty-array drift.
  Commit: closed by `LUA-BACKEND-PARITY.4.3.4.6 - close Lua array helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.4`.

- ID: `LUA-BACKEND-PARITY.4.3.4.0`
  Status: `done`
  Goal: Audit current Lua array mechanisms and split the family before behavior code.
  Acceptance: Inventory every governed array helper against Lua call admission, runtime dispatch, focused tests,
    earlier Dart/Julia rollouts, and current binding semantics; distinguish construction/splicing, copied
    selection, scalar/regex transforms, mutations/child flow, tagged records, and closeout; route any cross-cutting
    contract drift before implementation.
  Commit: `LUA-BACKEND-PARITY.4.3.4.0 - split Lua array helper mechanisms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.4.0`.

- ID: `LUA-BACKEND-PARITY.4.3.4.1`
  Status: `done`
  Goal: Implement copied array construction, explicit flatten splicing, concatenation, and copy boundaries.
  Dependencies: `.4.3.4.0`, `FUTURE-PARITY-BACKLOG.12.1.11`
  Acceptance: `array`, literals, `copy`, `flat`, `flat_array`, and `concat_arrays` evaluate in order, splice only
    explicit flat values in constructor context, preserve ordinary nested arrays, cover the empty/missing list
    boundaries already shared by Rust/Dart/Julia, route any Perl/catalog arity contradiction to an explicit owner,
    and never alias source containers on either Lua ABI.
  Commit: `LUA-BACKEND-PARITY.4.3.4.1 - add Lua array construction splicing`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.4.1`.

- ID: `LUA-BACKEND-PARITY.4.3.4.2`
  Status: `done`
  Goal: Implement copied selection, slicing, ordering, membership, and uniqueness helpers plus receivers.
  Dependencies: `.4.3.4.1`
  Acceptance: `count`, `first`, `last`, `take`, `take_last`, `drop_front`, `drop_back`, `slice`, `sorted`,
    `reversed`, `contains`, `index_of`, and `uniq` match zero-based/default/empty/invalid policy, preserve sources,
    and compose through bare, literal, function, and receiver forms on both ABIs.
  Commit: `LUA-BACKEND-PARITY.4.3.4.2 - add Lua copied array selection`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.4.2`.

- ID: `LUA-BACKEND-PARITY.4.3.4.3`
  Status: `done`
  Goal: Implement scalar/regex array transforms, joins, split pipelines, and standalone rebinding.
  Dependencies: `.4.3.2`, `.4.3.4.1`, `.4.3.4.2`
  Acceptance: Delimiter-first `join_values`, `split_each`, `trim_each`, `filter_nonempty`, `filter_match`,
    `lowercase_each`, and `uppercase_each` reuse governed scalar/PCRE2/Unicode policy; pure calls and receivers copy,
    dropped bare calls for all seven array-returning transforms, including `.4.3.4.2`'s `uniq`, rebind and return
    updated targets under uniform binding, and sources stay exact. Pre-existing Rust/Dart/Julia omission of dropped
    `split_each`/`filter_match`/`uniq` rebinding is explicitly routed to `FUTURE-PARITY-BACKLOG.5`, not copied into
    Lua.
  Commit: `LUA-BACKEND-PARITY.4.3.4.3 - add Lua array transform pipelines`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.4.3`.

- ID: `LUA-BACKEND-PARITY.4.3.4.4`
  Status: `done`
  Goal: Close append, end-mutation, mutable split, and child-push/index execution through one binding seam.
  Dependencies: `.4.3.4.0`, `.4.3.4.2`, `FUTURE-PARITY-BACKLOG.12.1.11`
  Acceptance: `push`/`+=`, three-argument split, push/pop end methods, action-edge push, static-rule precedence,
    implicit/explicit accumulators, and zero-based child-result selection mutate or append exactly once, return
    independent updated values where governed, diagnose wrong kinds, and preserve pure two-argument split.
  Commit: `LUA-BACKEND-PARITY.4.3.4.4 - close Lua array mutation flow`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.4.4`.

- ID: `LUA-BACKEND-PARITY.4.3.4.5`
  Status: `done`
  Goal: Implement tagged-record construction and remaining array-to-array/scalar bridges.
  Dependencies: `.4.3.4.1`, `.4.3.4.3`
  Acceptance: `split_tagged_records(source, delimiter, tag, fields...)` evaluates its source and carried fields
    once, preserves regex/literal split policy and typed record shapes, composes with array values/receivers, and
    matches shipped helper examples without beginning tree callbacks owned by `.4.3.6`.
  Commit: `LUA-BACKEND-PARITY.4.3.4.5 - add Lua tagged record construction`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.4.5`.

- ID: `LUA-BACKEND-PARITY.4.3.4.6`
  Status: `done`
  Goal: Close complete Lua array helper, receiver, mutation, and public-surface no-drift.
  Dependencies: `.4.3.4.1`, `.4.3.4.2`, `.4.3.4.3`, `.4.3.4.4`, `.4.3.4.5`
  Acceptance: Focused construction/selection/transform/mutation/tagged/receiver/invalid proof passes both Lua
    ABIs; numeric terminals remain exact; Lua README, mdBook, task/index/roadmaps, Knowledge Map, architecture/live
    docs, runtime status, cleanup, and doctrines agree before hash helpers `.4.3.5`; tree callbacks stay `.4.3.6`.
  Commit: `LUA-BACKEND-PARITY.4.3.4.6 - close Lua array helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.4.6`.

- ID: `LUA-BACKEND-PARITY.4.3.5`
  Status: `done`
  Goal: Implement harray construction, pure helpers, mutation, views, and receiver chains.
  Children: `.4.3.5.0`, `.4.3.5.1`, `.4.3.5.2`, `.4.3.5.3`, `.4.3.5.4`, `.4.3.5.5`
  Dependencies: `.4.3.1`, `.4.3.4`
  Acceptance: Typed hash/harray construction/copy/flatten, key/value views, merge/pick/drop/rename/set-key,
    hash-index assignment, scalar-held maps, deterministic ordering, receiver forms, and nested-map preservation
    match the catalog.
  Commit: `LUA-BACKEND-PARITY.4.3.5.5 - close Lua harray helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5`.

- ID: `LUA-BACKEND-PARITY.4.3.5.0`
  Status: `done`
  Goal: Audit current Lua harray mechanisms and split the family before behavior code.
  Dependencies: `.4.3.1`, `.4.3.4`
  Acceptance: Inventory all 16 ActionIR hash names against Lua runtime dispatch, typed stores/access, focused
    tests, current Perl/catalog behavior, later Dart/Julia implementations, receiver routing, constructor splice
    classification, deterministic ordering, mutations, callbacks, and existing caveat owners; create executable
    children before changing runtime behavior.
  Commit: `LUA-BACKEND-PARITY.4.3.5.0 - split Lua harray helper mechanisms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5.0`.

- ID: `LUA-BACKEND-PARITY.4.3.5.1`
  Status: `done`
  Goal: Implement copied harray construction, explicit flat splicing, and identity boundaries.
  Dependencies: `.4.3.5.0`
  Acceptance: `hash(...)`, harray literals, `copy`, `flat`, and `flat_hash` evaluate once, preserve ordinary nested
    harray values, splice only explicit direct/terminal flat ASTs in hash-constructor context, never alias sources,
    and leave odd-arity normalization with `FUTURE-PARITY-BACKLOG.5`.
  Commit: `LUA-BACKEND-PARITY.4.3.5.1 - add Lua harray construction splicing`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5.1`.

- ID: `LUA-BACKEND-PARITY.4.3.5.2`
  Status: `done`
  Goal: Implement copied deterministic harray views and membership terminals.
  Dependencies: `.4.3.5.1`
  Acceptance: `count_keys`, `sorted_keys`, `sorted_values`, and `has_key` return exact typed zero/array/boolean
    boundaries, sort values by key, preserve nested values, and compose through function and receiver forms.
  Commit: `LUA-BACKEND-PARITY.4.3.5.2 - add Lua deterministic harray views`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5.2`.

- ID: `LUA-BACKEND-PARITY.4.3.5.3`
  Status: `done`
  Goal: Implement copied harray transforms and receiver chains.
  Children: `.4.3.5.3.0`, `.4.3.5.3.1`
  Dependencies: `.4.3.5.1`, `.4.3.5.2`
  Acceptance: `merge_hash`, value-form `set_key`, `rename_key`, `drop_keys`, and `pick_keys` copy inputs, preserve
    deterministic override/order semantics and nested values, accept governed bare typed operands, and continue
    through compatible harray or array-view receiver chains.
  Commit: `LUA-BACKEND-PARITY.4.3.5.3.1 - add Lua copied harray transforms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5.3`.

- ID: `LUA-BACKEND-PARITY.4.3.5.3.0`
  Status: `done`
  Goal: Revalidate the harray-transform contract after uniform binding and aggregate-selector retirement.
  Dependencies: `.4.3.5.2`, `FUTURE-PARITY-BACKLOG.12.1`
  Acceptance: Toolbox and neutral-corpus probes establish current Perl/Rust/Dart/Julia behavior for bare-first
    `merge_hash(base, overlay)`, `copy(base)`, removed selector spelling, override/collision rules, pure transform
    boundaries, and compatible receiver chains; stale current-facing Knowledge Map/mdBook/runtime fact claims are
    corrected and the Lua implementation leaf receives one exact contract.
  Commit: `LUA-BACKEND-PARITY.4.3.5.3.0 - revalidate harray transform contracts`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5.3.0`.

- ID: `LUA-BACKEND-PARITY.4.3.5.3.1`
  Status: `done`
  Goal: Implement the revalidated copied harray transforms and receiver chains in Lua.
  Dependencies: `.4.3.5.3.0`
  Acceptance: Implement and focus-test the parent transform contract on PUC Lua and LuaJIT without crossing the
    named-mutation boundary owned by `.4.3.5.4`.
  Commit: `LUA-BACKEND-PARITY.4.3.5.3.1 - add Lua copied harray transforms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5.3.1`.

- ID: `LUA-BACKEND-PARITY.4.3.5.4`
  Status: `done`
  Goal: Close named harray mutation and direct assignment through one binding seam.
  Dependencies: `.4.3.5.3`
  Acceptance: Standalone `set_key(target, key, value)` and direct `target[key] = value` mutate named typed harrays,
    return independent updated snapshots, create only permitted absent targets, reject wrong kinds with neutral
    fields, and leave pure function/receiver transforms non-mutating.
  Commit: `LUA-BACKEND-PARITY.4.3.5.4 - add Lua named harray mutation`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5.4`.

- ID: `LUA-BACKEND-PARITY.4.3.5.5`
  Status: `done`
  Goal: Close complete Lua non-callback harray helper and public-surface no-drift.
  Dependencies: `.4.3.5.1`, `.4.3.5.2`, `.4.3.5.3`, `.4.3.5.4`
  Acceptance: Focused construction/view/transform/mutation/receiver/invalid proof passes both ABIs; Lua README,
    mdBook, task/index/roadmaps, Knowledge Map, architecture/live docs, cleanup, and doctrines agree before
    callbacks `.4.3.6`; cross-backend caveats stay explicitly owned rather than silently normalized.
  Commit: `LUA-BACKEND-PARITY.4.3.5.5 - close Lua harray helper parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.5.5`.

- ID: `LUA-BACKEND-PARITY.4.3.6`
  Status: `done`
  Goal: Execute immediate codeblock values, structured controls, contextual built-in blocks, and tree callbacks.
  Children: `.4.3.6.0`, `.4.3.6.1`, `.4.3.6.2`, `.4.3.6.3`, `.4.3.6.4`, `.4.3.6.5`, `.4.3.6.6`
  Dependencies: `.4.3.1`-`.4.3.5`
  Acceptance: Immediate blocks return their last values and support block-local return; attached/marker/inline
    if/switch/while forms, signature-governed built-in final-codeblock equivalence, scoped `with`, and deterministic
    array/harray walk/map/reduce callbacks match the governed surface; unsupported built-in block arities fail
    generically. General user-function invocation and its contextual final-codeblock path remain owned by `.5.1`;
    explicit callable literals and dynamic codeblock-variable calls remain owned by `FUTURE-PARITY-BACKLOG.11.7`.
  Commit: closed by `LUA-BACKEND-PARITY.4.3.6.6 - close Lua block control callback parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6`.

- ID: `LUA-BACKEND-PARITY.4.3.6.0`
  Status: `done`
  Goal: Audit and split Lua block, control, contextual-callback, and traversal mechanisms before behavior code.
  Dependencies: `.4.3.1`-`.4.3.5`
  Acceptance: Current Knowledge Map contracts, ActionIR parser/resolver nodes, interpreter dispatch, backend tests,
    callable-codeblock decisions, and staged-function ownership identify each missing execution seam; executable
    leaves are dependency ordered, and no child claims general user-function execution before `.5.1` or explicit
    callable-codeblock v1 before `FUTURE-PARITY-BACKLOG.11.7`.
  Commit: `LUA-BACKEND-PARITY.4.3.6.0 - split Lua block control callback mechanisms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.0`.

- ID: `LUA-BACKEND-PARITY.4.3.6.1`
  Status: `done`
  Goal: Execute immediate expression-valued blocks with block-local return.
  Dependencies: `.4.3.6.0`
  Acceptance: Eager no-pair brace blocks evaluate statements once in order, return the last expression or null for
    an empty/no-value path, and consume local `return` without leaking it to the enclosing rule. Harray literals
    remain pair-classified, and trailing contextual block arguments remain inert until their callable consumes them.
  Commit: `LUA-BACKEND-PARITY.4.3.6.1 - execute Lua eager block values`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.1`.

- ID: `LUA-BACKEND-PARITY.4.3.6.2`
  Status: `done`
  Goal: Execute lazy inline value controls over the expression-valued block seam.
  Dependencies: `.4.3.6.1`
  Acceptance: Inline `if` with `elseif`/`else` branches and inline `switch` with `case`/`default` branches
    evaluate only the selected value branch, preserve false/null distinctions, one-time switch subjects, literal
    bare case labels, and block-local return, diagnose malformed arity generically, and compose as helper,
    assignment, and fluent-return operands on both Lua ABIs. `i`/`elif` remain statement-marker aliases,
    `when`/`otherwise` remain attached-block aliases, and retired/non-surface `unless` remains unknown.
  Commit: `LUA-BACKEND-PARITY.4.3.6.2 - execute Lua lazy inline controls`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.2`.

- ID: `LUA-BACKEND-PARITY.4.3.6.3`
  Status: `done`
  Goal: Execute attached and marker-delimited statement controls.
  Children: `.4.3.6.3.1`, `.4.3.6.3.2`, `.4.3.6.3.3`
  Dependencies: `.4.3.6.1`
  Acceptance: If-family, switch-family, and while-family statements share the scoped block executor, preserve
    parser order and local return, and never evaluate unselected branches or an extra loop body.
  Commit: `LUA-BACKEND-PARITY.4.3.6.3.1` through `.4.3.6.3.3` child commits
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.3`.

- ID: `LUA-BACKEND-PARITY.4.3.6.3.1`
  Status: `done`
  Goal: Execute attached and marker `if`/`elseif`/`else` plus `when`/`otherwise` statement forms.
  Dependencies: `.4.3.6.1`
  Acceptance: Exactly one selected branch executes, condition aliases and marker boundaries match ActionIR order,
    empty branches are neutral, and malformed/orphaned control nodes retain structured diagnostics.
  Commit: `LUA-BACKEND-PARITY.4.3.6.3.1 - execute Lua if statement controls`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.3.1`.

- ID: `LUA-BACKEND-PARITY.4.3.6.3.2`
  Status: `done`
  Goal: Execute attached and marker `switch`/`case`/`default` statement forms.
  Dependencies: `.4.3.6.3.1`
  Acceptance: The switch subject evaluates once; the first matching case or one default executes; later cases are
    skipped; comparison and null behavior reuse governed scalar equality without host-table coercion.
  Commit: `LUA-BACKEND-PARITY.4.3.6.3.2 - execute Lua switch statement controls`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.3.2`.

- ID: `LUA-BACKEND-PARITY.4.3.6.3.3`
  Status: `done`
  Goal: Execute attached `while` statements through a deterministic loop-control seam.
  Dependencies: `.4.3.6.3.2`
  Acceptance: Conditions re-evaluate before each body, false initially runs zero bodies, body state is visible to
    the next condition, local return exits only the current block contract, and the governed runaway guard fails
    deterministically with rule attribution.
  Commit: `LUA-BACKEND-PARITY.4.3.6.3.3 - execute Lua attached while controls`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.3.3`.

- ID: `LUA-BACKEND-PARITY.4.3.6.4`
  Status: `done`
  Goal: Execute signature-governed built-in final blocks and scoped `with`.
  Dependencies: `.4.3.6.1`
  Acceptance: For current built-ins declaring a final `codeblock` parameter, `call(args) { ... }` and
    `call(args, { ... })` are identical in helper and receiver form; `with` installs copied temporary bindings and
    restores all prior/absent bindings on success, local return, and error. This leaf does not claim general
    user-function dispatch, which remains `.5.1`.
  Commit: `LUA-BACKEND-PARITY.4.3.6.4 - execute Lua built-in final blocks`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.4`.

- ID: `LUA-BACKEND-PARITY.4.3.6.5`
  Status: `done`
  Goal: Execute deterministic harray and array leaf callbacks.
  Children: `.4.3.6.5.1`, `.4.3.6.5.2`
  Dependencies: `.4.3.6.1`, `.4.3.6.4`
  Acceptance: `walk_leaves`, `map_leaves`, and `reduce_leaves` use one scoped callback frame, deterministic paths,
    copied inputs/results, exact continuation, and generic invalid-kind/block-arity boundaries.
  Commit: closed by `LUA-BACKEND-PARITY.4.3.6.5.2 - execute Lua array callbacks`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.5`.

- ID: `LUA-BACKEND-PARITY.4.3.6.5.1`
  Status: `done`
  Goal: Implement the scoped callback frame and deterministic harray leaf traversal.
  Children: `.4.3.6.5.1.0`, `.4.3.6.5.1.1`, `.4.3.6.5.1.2`
  Dependencies: `.4.3.6.4`
  Acceptance: Lexically sorted harray keys produce stable path/value bindings; walk side effects, mapped copies,
    and typed reduce accumulation match the governed contract without leaking callback locals or aliasing sources.
  Commit: closed by `LUA-BACKEND-PARITY.4.3.6.5.1.2 - execute Lua harray callbacks`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.5.1`.

- ID: `LUA-BACKEND-PARITY.4.3.6.5.1.0`
  Status: `done`
  Goal: Split the reproduced Perl callback append-RHS defect from Lua harray behavior before implementation.
  Dependencies: `.4.3.6.4`
  Acceptance: Use the toolbox and typed AST dump to locate the exact corruption boundary; give the reference repair
    and Lua traversal separate commit-sized owners; record the public depth contract from executable evidence.
  Commit: `LUA-BACKEND-PARITY.4.3.6.5.1.0 - split callback append scope repair`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.5.1.0`.

- ID: `LUA-BACKEND-PARITY.4.3.6.5.1.1`
  Status: `done`
  Goal: Stop callback append RHS values from being consumed as legacy optional scope labels.
  Dependencies: `.4.3.6.5.1.0`
  Acceptance: `cat(key, ...)` and comparable value helpers retain every authored bare first argument inside
    `+=` callback side effects; direct helper behavior stays unchanged, typed AST/lowering/runtime tests lock the
    exact source location, and accepted optional-scope forms outside the affected value-helper path do not change.
  Commit: `LUA-BACKEND-PARITY.4.3.6.5.1.1 - preserve authored callback values`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.5.1.1`.

- ID: `LUA-BACKEND-PARITY.4.3.6.5.1.2`
  Status: `done`
  Goal: Implement the shared scoped callback frame and deterministic Lua harray leaf traversal.
  Dependencies: `.4.3.6.5.1.1`
  Acceptance: Lexically sorted harray keys produce stable copied `value`/`key`/`path`/`depth` bindings; walk side
    effects, mapped copies, and typed reduce accumulation match the corrected reference contract without leaking
    callback locals or aliasing sources. Public docs define depth as `count(path)`, so a root leaf has depth 1.
  Commit: `LUA-BACKEND-PARITY.4.3.6.5.1.2 - execute Lua harray callbacks`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.5.1.2`.

- ID: `LUA-BACKEND-PARITY.4.3.6.5.2`
  Status: `done`
  Goal: Extend leaf traversal to array roots and close root-kind callback continuation.
  Dependencies: `.4.3.6.5.1`
  Acceptance: Zero-based array path components preserve source order while traversal recurses only into nested
    arrays; harrays remain leaves, just as arrays remain leaves under a hash root. One root-kind dispatcher keeps
    harray lexical order intact. Walk/map/reduce return exact types, continuation is exact, callback frames restore
    atomically, and empty/invalid inputs stay lazy and neutral.
  Commit: `LUA-BACKEND-PARITY.4.3.6.5.2 - execute Lua array callbacks`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.5.2`.

- ID: `LUA-BACKEND-PARITY.4.3.6.6`
  Status: `done`
  Goal: Close Lua immediate-block/control/contextual-built-in/tree-callback no-drift and dependency routing.
  Dependencies: `.4.3.6.2`, `.4.3.6.3`, `.4.3.6.4`, `.4.3.6.5`
  Acceptance: Focused dual-ABI proof, catalog/README/mdBook/KM/task/live state, and unsupported-block diagnostics
    agree; general user-function contextual blocks are explicitly handed to `.5.1`, explicit callable literals and
    dynamic codeblock calls to `FUTURE-PARITY-BACKLOG.11.7`, with no premature parity claim.
  Commit: `LUA-BACKEND-PARITY.4.3.6.6 - close Lua block control callback parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.6.6`.

- ID: `LUA-BACKEND-PARITY.4.3.7`
  Status: `done`
  Goal: Implement capture-slice, named-mark, input, and explicit cursor-state helper families.
  Children: `.4.3.7.0`, `.4.3.7.1`, `.4.3.7.2`, `.4.3.7.3`, `.4.3.7.4`, `.4.3.7.5`, `.4.3.7.6`
  Dependencies: `.4.3.1`, `.4.3.6`
  Acceptance: Capture anchors/slices/boundaries, rule-local named marks, Unicode character positions/lengths,
    input views, save/restore and entry/local rewinds, consume continuation, earliest boundary selection, and
    unresolved-rule behavior match the runtime contract.
  Commit: closed by `LUA-BACKEND-PARITY.4.3.7.6 - close Lua capture cursor parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.7`.

- ID: `LUA-BACKEND-PARITY.4.3.7.0`
  Status: `done`
  Goal: Audit the canonical capture/cursor state model and split it into mechanism-sized executable owners.
  Dependencies: `.4.3.1`, `.4.3.6`
  Acceptance: Contract sources, toolbox probes, Knowledge Map facts, governed fixtures, current Lua state seams,
    split-marker compilation, Unicode projections, and dependency order are inspected before behavior changes;
    every discovered obligation has one explicit child owner and the first executable leaf is dependency-ready.
  Commit: `LUA-BACKEND-PARITY.4.3.7.0 - split Lua capture cursor mechanisms`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.7.0`.

- ID: `LUA-BACKEND-PARITY.4.3.7.1`
  Status: `done`
  Goal: Implement absolute input/live-cursor views and explicit cursor save/restore/rewind controls.
  Dependencies: `.4.3.7.0`
  Acceptance: Input text/length/slice/end position/line/column and cursor position/line/column/rest/rest length use
    Unicode character units at the DSL boundary; cursor save/restore is LIFO and entry/local rewinds preserve
    register snapshots while changing only the live cursor; consume-mode continuation observes the restored cursor.
  Commit: `LUA-BACKEND-PARITY.4.3.7.1 - add Lua input cursor controls`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.7.1`.

- ID: `LUA-BACKEND-PARITY.4.3.7.2`
  Status: `done`
  Goal: Implement the anonymous capture-boundary helper family.
  Dependencies: `.4.3.7.1`
  Acceptance: Start/current position/line/column, match-start, live-cursor, and end-of-input stable/length/advancing
    reads share one byte-safe state seam and expose text widths/positions in Unicode characters; invalid spans are
    neutral, advancing forms mutate only after a valid read, and receiver continuation/terminality is exact.
    `start_capture_slice()` follows the governed void mutation contract shared by the helper catalog and the
    Rust/Dart/Julia runtimes; it must not copy Perl's incidental assignment-expression result into Lua.
  Commit: `LUA-BACKEND-PARITY.4.3.7.2 - add Lua anonymous capture helpers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.7.2`.

- ID: `LUA-BACKEND-PARITY.4.3.7.3`
  Status: `done`
  Goal: Implement the governed current rule-local named marks, named spans, and anonymous/named bridges.
  Dependencies: `.4.3.7.2`, `FUTURE-PARITY-BACKLOG.17.5`
  Acceptance: Current/input-boundary/anonymous mark writers, copy/existence/position readers, match-start/live-
    cursor/end-of-input/two-mark stable and advancing spans, and both bridge directions match the governed
    reference; bare mark identifiers remain symbolic, mark state is isolated by rule label for the parser
    execution, and the exact anonymous/named fixture passes unchanged. `FUTURE-PARITY-BACKLOG.17.4` already
    supplies the parse-scoped rule-label mark store plus `mark_entry_start/end`, `mark_match_start/end`,
    `mark_line`, `mark_col`, and `clear_mark`; this leaf extends that implementation for the remaining governed
    named writers, spans, and bridges rather than creating a Lua-only dialect or parallel mark frame. Final
    shared-inventory admission `.17.5` is complete before this leaf's complete-family parity claim.
  Commit: `LUA-BACKEND-PARITY.4.3.7.3 - execute Lua named mark spans`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.7.3`.

- ID: `LUA-BACKEND-PARITY.4.3.7.4`
  Status: `done`
  Goal: Execute placement-sensitive split and named-mark rule members.
  Dependencies: `.4.3.7.2`, `.4.3.7.3`
  Acceptance: `@capture_slice`, compatibility capture-boundary aliases, and `@mark(name)` compile into explicit
    rule-slot events whose mutations become visible after that matched action site; helper calls remain available
    for in-block timing, malformed names stay typed, and the shipped `@move_pos` source has an executable owner.
  Commit: `LUA-BACKEND-PARITY.4.3.7.4 - execute Lua rule slot markers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.7.4`.

- ID: `LUA-BACKEND-PARITY.4.3.7.5`
  Status: `done`
  Goal: Implement non-consuming earliest-boundary capture.
  Dependencies: `.4.3.7.1`
  Acceptance: `capture_until_boundary(rule[, ...])` seeks all usable compiled regex-bearing rules from the live
    cursor, selects the earliest match independent of surrounding parse mode, returns text before the boundary,
    leaves the boundary unconsumed, captures to end-of-input when usable rules have no later match, and returns
    null without cursor movement when every supplied rule is unresolved or unusable. Until helper-caveat owner
    `FUTURE-PARITY-BACKLOG.5` normalizes the public minimum arity, a zero-argument call follows Rust/Dart/Julia by
    returning null without movement rather than copying Perl's generated-handler undefined-subroutine failure.
  Commit: `LUA-BACKEND-PARITY.4.3.7.5 - add Lua boundary capture`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.7.5`.

- ID: `LUA-BACKEND-PARITY.4.3.7.6`
  Status: `done`
  Goal: Close exhaustive Lua capture/cursor helper and public-surface no-drift.
  Dependencies: `.4.3.7.1`-`.4.3.7.5`
  Acceptance: Helper inventory, governed fixtures, marker timing, dual-ABI runtime gates, API docs, mdBook,
    Knowledge Map, task/live state, and later capability routing agree with no premature generated-source or
    capability claim; the documented-mark inventory gap has an explicit cross-backend disposition; parent
    `.4.3.7` closes and diagnostic helper `.4.3.8` becomes the sole active frontier.
  Commit: `LUA-BACKEND-PARITY.4.3.7.6 - close Lua capture cursor parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.7.6`.

- ID: `LUA-BACKEND-PARITY.4.3.8`
  Status: `done`
  Goal: Implement runtime diagnostic output helpers over a caller-owned event boundary.
  Dependencies: `.4.3.2`, `.4.3.4`, `.4.3.7`
  Acceptance: `print`, `say`, and `print_each` evaluate eagerly, stay out of parse-result values, are quiet without
    a sink, preserve message ordering/Unicode, and expose an event seam that `.4.4` can instrument without changing
    helper semantics; `exit_now` remains immediate typed control.
  Commit: `LUA-BACKEND-PARITY.4.3.8 - add Lua diagnostic output events`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.8`.

- ID: `LUA-BACKEND-PARITY.4.3.9`
  Status: `done`
  Goal: Close exhaustive Lua helper/value/control/method no-drift.
  Children: `.4.3.9.0`, `.4.3.9.1`, `.4.3.9.2`
  Dependencies: `.4.3.1`-`.4.3.8`
  Acceptance: Every governed current name is execution-covered or has a later explicit non-helper owner; exact
    246-name admission, mdBook examples, both runtime gates, statuses, API docs, task trees, Knowledge Map, and
    capability claims agree with zero hidden partial surface before `.4.4`.
  Commit: closed by `.4.3.9.2`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.9`.

- ID: `LUA-BACKEND-PARITY.4.3.9.0`
  Status: `done`
  Goal: Audit and split exhaustive Lua runtime-call closure before behavior code.
  Dependencies: `.4.3.8`
  Acceptance: Probe all 246 admitted names through the Lua parser/compiler/interpreter; classify every unsupported
    result as a real missing value helper or an explicit statement/receiver-only surface; inspect status and focused
    evidence drift; split repair from final admission; route any cross-backend/reference contradiction durably.
  Commit: `LUA-BACKEND-PARITY.4.3.9.0 - split Lua exhaustive helper closeout`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.9.0`.

- ID: `LUA-BACKEND-PARITY.4.3.9.1`
  Status: `done`
  Goal: Execute Lua eager logical value helpers.
  Dependencies: `.4.3.9.0`
  Acceptance: `and`, `or`, and `not` eagerly evaluate every authored argument once left-to-right, compose through
    Lua's already-governed runtime truthiness, return booleans including empty-call false/false/true behavior, work
    in value/receiver-compatible positions, and pass exact Unicode-neutral side-effect proof on PUC Lua and LuaJIT;
    no cross-backend truthiness or Perl-lowering normalization is claimed.
  Commit: `LUA-BACKEND-PARITY.4.3.9.1 - execute Lua eager logical helpers`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.9.1`.

- ID: `LUA-BACKEND-PARITY.4.3.9.2`
  Status: `done`
  Goal: Admit exhaustive Lua runtime helper/value/control/method no-drift.
  Dependencies: `.4.3.9.1`
  Acceptance: A recurring exact 246-name probe reports only the thirteen documented non-function owners and zero
    unowned names; direct `call(rule)` execution is focused; the reported duplicate inventory row is resolved from
    source history; public backend status names the completed native helper/value/control boundary without implying
    trace, functions, corpus, CLI, or generated support; dual-ABI, 246/105+1/122, capability, API, book, Knowledge
    Map, task, and canonical gates agree; parent `.4.3` closes and `.4.4` activates.
  Commit: `LUA-BACKEND-PARITY.4.3.9.2 - close Lua runtime helper no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.3.9.2`.

- ID: `LUA-BACKEND-PARITY.4.4`
  Status: `done`
  Goal: Implement structured runtime diagnostics and runtime trace controls.
  Children: `.4.4.0`, `.4.4.1`, `.4.4.2`, `.4.4.3`, `.4.4.4`
  Acceptance: Typed runtime diagnostics carry neutral stage/source/top/deepest-rule/handler identity; default-quiet
    caller-owned tracing exposes exact ordered levels, event primitives, sinks, and runtime interpreter events
    without changing parse results. Full frontend/compiler/function/staged propagation remains `.5.3`, after `.5.1`
    and `.5.2` provide the general staged-function and native-loading owners it must traverse.
  Commit: closed by `LUA-BACKEND-PARITY.4.4.4 - close Lua diagnostics trace no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.4`.

- ID: `LUA-BACKEND-PARITY.4.4.0`
  Status: `done`
  Goal: Split the broad Lua diagnostics/trace leaf into dependency-correct signoff-sized implementation leaves.
  Acceptance: Structured failure payloads, trace controls/sinks, runtime instrumentation, and no-drift closeout are
    separately owned; dependency-incomplete full-pipeline propagation is explicitly retained by `.5.3` rather than
    being claimed before general staged functions and native loading exist.
  Commit: `LUA-BACKEND-PARITY.4.4.0 - split Lua diagnostics trace controls`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.4.0`.

- ID: `LUA-BACKEND-PARITY.4.4.1`
  Status: `done`
  Goal: Add Lua runtime structured diagnostic payloads and diagnostic-carrying runtime exceptions.
  Acceptance: Runtime failures expose stable `type`, `stage`, `owner_stage`, `summary`, `detail`, `top_rule`,
    `rule_label`, `handler_source_label`, and optional `spec_name` / `spec_path` fields; the deepest available rule
    and source attribution survive stack unwinding, richer inner diagnostics are preserved, textual errors remain
    useful, and successful parse results are unchanged on PUC Lua and LuaJIT.
  Commit: `LUA-BACKEND-PARITY.4.4.1 - add Lua runtime diagnostics`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.4.1`.

- ID: `LUA-BACKEND-PARITY.4.4.2`
  Status: `done`
  Goal: Add Lua trace levels, controls, structured event primitives, and caller-owned sink routing.
  Acceptance: Ordered none/low/medium/high/full/debug levels, explicit and documented environment configuration,
    enter/exit/decision/mark/dump/log events, stdout/routed-file/mirror sinks, route reset/truncate behavior, and
    direct traced runtime entrypoints are default-quiet and preserve successful parse results on both Lua ABIs.
  Commit: `LUA-BACKEND-PARITY.4.4.2 - add Lua trace controls`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.4.2`.

- ID: `LUA-BACKEND-PARITY.4.4.3`
  Status: `done`
  Goal: Instrument the Lua runtime interpreter with exact rule, branch, dispatch, lifecycle, cursor, and boundary events.
  Acceptance: The optional emitter covers parse/rule scopes, recursion cutoffs, regex match/no-match, action/blind
    child dispatch, lifecycle blocks, cursor controls, source-boundary capture, and governed mark/capture positions
    where applicable; disabled or absent tracing is a no-op and traced/untraced results are identical on both ABIs.
  Commit: `LUA-BACKEND-PARITY.4.4.3 - instrument Lua runtime trace`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.4.3`.

- ID: `LUA-BACKEND-PARITY.4.4.4`
  Status: `done`
  Goal: Close Lua runtime diagnostics/trace no-drift.
  Acceptance: Focused dual-ABI proofs, public API/status, README/mdBook, Knowledge Map, task/index/roadmaps, live
    docs, and canonical gates agree on the implemented runtime boundary without claiming dependency-incomplete
    full-pipeline tracing; parent `.4.4` closes and staged-function/native-loading `.5.1` becomes active.
  Commit: `LUA-BACKEND-PARITY.4.4.4 - close Lua diagnostics trace no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.4.4.4`.

- ID: `LUA-BACKEND-PARITY.5`
  Status: `done`
  Goal: Implement general current staged-function execution and native loading.
  Children: `.5.1`, `.5.2`, `.5.3`
  Commit: `LUA-BACKEND-PARITY.5.3.3 - close Lua descriptor trace no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5`.

- ID: `LUA-BACKEND-PARITY.5.1`
  Status: `done`
  Goal: Add staged parser registry/function-body dispatch and fixed-v1/variadic-v2 runtime calls.
  Children: `.5.1.0`, `.5.1.1`, `.5.1.2`, `.5.1.3`, `.5.1.4`, `.5.1.5`
  Acceptance: Provider identity, ordered jobs, parse/normalize/stitch phases, failures, and trace match the admitted
    variants without Lua-only queues or cache behavior. Consume `linkedspec-callable-signature-v1` through the
    spec-owned shell, typed function/job records, registry-first ActionIR resolution, and isolated invocation
    frames: fixed v1 calls remain exact; final-rest v2 calls are positional-only, require `min_arity`, evaluate once
    left-to-right, and bind extras as one fresh typed array without Lua vararg/closure dispatch. The unchanged
    neutral fixture, seven invalid definitions, keyword rejection, exact/minimum diagnostics, receiver continuation,
    mixed/empty/fresh rest values, and recursion fence pass on PUC Lua and LuaJIT. Preserve a final
    `callback: codeblock` declaration in spec-owned function signatures/registries and execute attached
    and parenthesized contextual final blocks equivalently in the caller's dynamic context, with copied/restored
    bindings and no harray promotion. Explicit `{|params| ...}` literals and dynamic codeblock-variable calls remain
    routed through `FUTURE-PARITY-BACKLOG.11.7` to dependency-complete Lua owners.
  Commit: `LUA-BACKEND-PARITY.5.1.5 - close Lua staged functions no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1`.

- ID: `LUA-BACKEND-PARITY.5.1.0`
  Status: `done`
  Goal: Split staged-function and contextual-codeblock work into dependency-correct signoff-sized leaves.
  Acceptance: Existing Lua shell/registry/compiled/runtime seams and neutral staged/callable contracts are audited
    before code; staged dispatch, fixed execution, variadic metadata/runtime, contextual-codeblock metadata/runtime,
    and no-drift each receive an exact owner without pulling dynamic callable literals out of `.11.7`.
  Commit: `LUA-BACKEND-PARITY.5.1.0 - split Lua staged function execution`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.0`.

- ID: `LUA-BACKEND-PARITY.5.1.1`
  Status: `done`
  Goal: Add the minimal Lua staged action-body provider, deterministic job execution, and immutable body stitching.
  Acceptance: Validate and stable-sort exact `StagedParseJob` values by parent path/span/job id; resolve only
    `actionir-body.spec` to `builtin:actionir-body.spec`; record the governed digest/cache/compiled identity; parse
    exact body text through `parse_action_block(...)`; stitch `body_ast` under replace-field policy; expose composed
    shell+dispatch APIs; reject unsupported providers and sidecar drift on PUC Lua and LuaJIT.
  Commit: `LUA-BACKEND-PARITY.5.1.1 - add Lua staged body dispatch`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.1`.

- ID: `LUA-BACKEND-PARITY.5.1.2`
  Status: `done`
  Goal: Execute registered fixed-v1 user functions through the Lua runtime.
  Dependencies: `.5.1.1`
  Acceptance: Registry-first calls evaluate positional arguments once left-to-right in caller scope, execute staged
    `body_ast` in fresh scalar/array/harray stores, return local final/early-return values, restore caller stores on
    success/failure, feed receiver chains, execute-and-discard standalone calls, and diagnose arity/keyword/
    direct-mutual recursion without helper fallback on both ABIs.
  Commit: `LUA-BACKEND-PARITY.5.1.2 - execute Lua fixed user functions`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.2`.

- ID: `LUA-BACKEND-PARITY.5.1.3`
  Status: `done`
  Goal: Consume the fixed-v1/variadic-v2 callable-signature union natively.
  Children: `.5.1.3.1`, `.5.1.3.2`
  Dependencies: `.5.1.2`
  Acceptance: The spec-owned shell, typed state, registry resolution, and runtime consume the unchanged neutral
    signature contract; descriptor admission remains `.5.3` and generated preservation/execution remains `.8`.
  Commit: children `.5.1.3.1`, `.5.1.3.2`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.3`.

- ID: `LUA-BACKEND-PARITY.5.1.3.1`
  Status: `done`
  Goal: Preserve variadic-v2 callable signatures through Lua shell, AST, staged records, registry, and compiled state.
  Dependencies: `.5.1.2`
  Acceptance: Fixed v1 retains exact params/arity; variadic v2 uses only the typed callable signature with final
    rest, minimum/unbounded maximum arity, positional-only resolution, identical staged copies, and all seven exact
    invalid-definition diagnostics without prematurely changing outward descriptor or generated-source contracts.
  Commit: `LUA-BACKEND-PARITY.5.1.3.1 - preserve Lua variadic signatures`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.3.1`.

- ID: `LUA-BACKEND-PARITY.5.1.3.2`
  Status: `done`
  Goal: Execute Lua variadic-v2 user functions through fresh typed rest arrays.
  Dependencies: `.5.1.3.1`
  Acceptance: Arguments evaluate once left-to-right; fixed prefixes bind normally; extras bind as one fresh copied
    typed array including the empty case and nested/null/boolean/codeblock identities; minimum-arity and keyword
    failures are typed; results chain; the unchanged neutral fixture passes on PUC Lua and LuaJIT.
  Commit: `LUA-BACKEND-PARITY.5.1.3.2 - execute Lua variadic functions`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.3.2`.

- ID: `LUA-BACKEND-PARITY.5.1.4`
  Status: `done`
  Goal: Consume final contextual `name: codeblock` parameters for Lua user functions.
  Children: `.5.1.4.1`, `.5.1.4.2`
  Dependencies: `.5.1.3`
  Acceptance: Declaration metadata and attached/parenthesized contextual execution match the neutral final-codeblock
    contract without implementing explicit callable literals or bound codeblock-variable invocation.
  Commit: `LUA-BACKEND-PARITY.5.1.4.2 - execute Lua contextual codeblocks`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.4`.

- ID: `LUA-BACKEND-PARITY.5.1.4.1`
  Status: `done`
  Goal: Preserve final codeblock parameter kind through Lua shell, staged records, registry, and call normalization.
  Dependencies: `.5.1.3.2`
  Acceptance: Final-only `callback: codeblock` carries exact typed metadata; attached and parenthesized contextual
    blocks normalize equivalently; invalid non-final/argument-list/missing-name/unknown-type forms reject; harray
    literals are never promoted; built-in contracts remain unchanged.
  Commit: `LUA-BACKEND-PARITY.5.1.4.1 - preserve Lua final codeblock metadata`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.4.1`.

- ID: `LUA-BACKEND-PARITY.5.1.4.2`
  Status: `done`
  Goal: Execute Lua user-function contextual final blocks in the caller's dynamic context.
  Dependencies: `.5.1.4.1`
  Acceptance: Attached and parenthesized zero-positional contextual blocks execute equivalently through the declared
    final slot, see current dynamic bindings, preserve copied/restored parameter stores, keep nonparameter effects
    visible where governed, return ordinary chainable values, and reject wrong-kind/missing callbacks on both ABIs.
  Commit: `LUA-BACKEND-PARITY.5.1.4.2 - execute Lua contextual codeblocks`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.4.2`.

- ID: `LUA-BACKEND-PARITY.5.1.5`
  Status: `done`
  Goal: Close Lua staged-function/variadic/contextual-codeblock execution no-drift.
  Dependencies: `.5.1.1`, `.5.1.2`, `.5.1.3`, `.5.1.4`
  Acceptance: Focused dual-ABI proof, neutral contract checkers/fixtures, public API/status, docs/book, task/index/
    roadmaps/live/KM, and canonical gates agree; parent `.5.1` closes and native loading `.5.2` activates without
    claiming descriptors/full-pipeline trace `.5.3`, generated execution `.8`, or dynamic callable literals `.11.7`.
  Commit: `LUA-BACKEND-PARITY.5.1.5 - close Lua staged functions no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.1.5`.

- ID: `LUA-BACKEND-PARITY.5.2`
  Status: `done`
  Goal: Add portable native named/path resolution and in-memory composition.
  Children: `.5.2.0`, `.5.2.1`, `.5.2.2`, `.5.2.3`, `.5.2.4`
  Acceptance: Consume exact name/path/root/UTF-8/stage contract; expose load/compile/create-engine conveniences as
    adapters over native in-memory APIs; remove any backend-local fallback or implicit transcoding.
  Commit: `LUA-BACKEND-PARITY.5.2.4 - close Lua native loading no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.2`.

- ID: `LUA-BACKEND-PARITY.5.2.0`
  Status: `done`
  Goal: Split portable native loading into dependency-correct signoff-sized leaves before code.
  Acceptance: Audit ADR `0026`, the executable 14/9/4 fixture, completed Rust/Dart/Julia public loaders, current
    Lua filesystem/UTF-8/parser/function-shell/staged/compiler/engine seams, and exact later trace/descriptor owners;
    prove whether the current Lua runtime can execute `specs/user_function_definition.spec`; separately own
    resolution/loading, automatic function-shell parsing, full pipeline/engine composition, and no-drift.
  Commit: `LUA-BACKEND-PARITY.5.2.0 - split Lua native spec loading`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.2.0`.

- ID: `LUA-BACKEND-PARITY.5.2.1`
  Status: `done`
  Goal: Add portable native spec requests, deterministic resolution, byte loading, and strict UTF-8 decoding.
  Dependencies: `.5.2.0`
  Acceptance: Export typed/identifiable named and exact-path requests, load options, resolved/loaded values, and
    structured pipeline errors; validate all portable name/path boundaries; check cwd exact, cwd suffix, and direct
    roots in declared order with first-candidate deduplication and first-regular-file selection; never recurse or
    use implicit roots; preserve exact caller path identity; read bytes in process; strictly decode UTF-8 without
    BOM removal, normalization, newline conversion, trimming, replacement, or implicit UTF-16/32 transcoding; and
    consume every shared 14 name, 9 resolution, and 4 text case directly on PUC Lua and LuaJIT.
  Commit: `LUA-BACKEND-PARITY.5.2.1 - add Lua native spec loading`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.2.1`.

- ID: `LUA-BACKEND-PARITY.5.2.2`
  Status: `done`
  Goal: Add automatic spec-defined top-level function-shell parsing for loaded and inline source.
  Dependencies: `.5.2.1`
  Acceptance: Resolve the repository-owned `specs/user_function_definition.spec` through one deterministic
    bundled/module-relative owner rather than user search roots or recursive fallback; parse/validate/compile it
    once through current native APIs; execute it in process over caller source; normalize only its typed output;
    feed those nodes through the existing Unicode-exact shell projector and deterministic body-job dispatcher;
    expose a composed `parse_spec_with_staged_user_function_definitions(...)` API; and reject parser execution,
    output-shape, projection, or staged failures without introducing a raw `fn` scanner.
  Commit: `LUA-BACKEND-PARITY.5.2.2 - automate Lua function parsing`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.2.2`.

- ID: `LUA-BACKEND-PARITY.5.2.3`
  Status: `done`
  Goal: Compose native loaded text through parse, validation, compilation, and identity-bearing engine creation.
  Dependencies: `.5.2.2`
  Acceptance: Export `load_and_compile_spec(...)` plus a loaded-compiled result that retains request kind/value,
    resolved path, exact source text, and backend-native compiled state; map parse/validation/compile failures to
    the exact neutral stages/codes; create a runtime engine with named identity only for name requests and resolved
    path for both request kinds; prove top-level function compilation/execution, parse-versus-validation ownership,
    runtime diagnostic identity, exact missing-name JSON, and unchanged inline in-memory APIs without CLI,
    subprocess, temporary-file, serialized-handoff, descriptor, or full-pipeline-trace claims.
  Commit: `LUA-BACKEND-PARITY.5.2.3 - compose Lua native spec pipeline`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.2.3`.

- ID: `LUA-BACKEND-PARITY.5.2.4`
  Status: `done`
  Goal: Close Lua portable native loading no-drift.
  Dependencies: `.5.2.1`, `.5.2.2`, `.5.2.3`
  Acceptance: Focused dual-ABI proof, direct neutral fixture consumption, public APIs/status, docs/book, task/index/
    roadmaps/live/KM, and canonical gates agree; parent `.5.2` closes and descriptor/full-pipeline trace `.5.3`
    activates without claiming generated source, corpus execution, or the parser CLI.
  Commit: `LUA-BACKEND-PARITY.5.2.4 - close Lua native loading no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.2.4`.

- ID: `LUA-BACKEND-PARITY.5.3`
  Status: `done`
  Goal: Admit exact outward descriptors, runtime diagnostics, and full-pipeline trace.
  Children: `.5.3.0`, `.5.3.0.1`, `.5.3.1`, `.5.3.2`, `.5.3.3`
  Dependencies: `.4.4`, `.5.1`, `.5.2`
  Acceptance: Consume shared fixtures/checkers directly, including the exact fixed-v1/variadic-v2 outward function
    descriptor union plus neutral final-codeblock-v3 records and identical staged metadata copies; propagate one
    caller-owned emitter through native loading, frontend, validation, compilation, function-shell, staged dispatch,
    and runtime phases; preserve the four-backend census until all-pass Lua admission `.8.4`; no partial/gap state
    lacks a concrete next owner.
  Commit: `LUA-BACKEND-PARITY.5.3.3 - close Lua descriptor trace no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.3`.

- ID: `LUA-BACKEND-PARITY.5.3.0`
  Status: `done`
  Goal: Audit and dependency-split Lua descriptor, full-pipeline trace, and capability-admission work before code.
  Dependencies: `.4.4`, `.5.1`, `.5.2`
  Acceptance: Inspect the exact neutral fixed-v1/variadic-v2 outward contracts, contextual-codeblock metadata,
    current Lua descriptor fences, every emitter propagation seam, completed Dart/Julia trace precedent, current
    capability-manifest admission policy, and the history of any contradictory owner text; record foundational
    contract conflicts durably; split decision, descriptor, trace, and admission work so no behavior leaf starts
    before its exact source of truth and dependency are settled.
  Commit: `LUA-BACKEND-PARITY.5.3.0 - split Lua descriptor trace admission`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.3.0`.

- ID: `LUA-BACKEND-PARITY.5.3.0.1`
  Status: `done`
  Goal: Resolve the outward final-codeblock descriptor schema and Lua capability-census admission timing.
  Dependencies: `.5.3.0`
  Acceptance: Adopt one backend-neutral outward descriptor policy for final-codeblock metadata or retain the
    explicit Lua fence under its exact future cross-backend owner; reconcile `.5.3` census wording with the newer
    full-backend admission policy; update the governing contract/decision/task/docs consistently before descriptor
    or census code changes.
  Commit: `LUA-BACKEND-PARITY.5.3.0.1 - settle descriptor and census policy`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.3.0.1`.

- ID: `LUA-BACKEND-PARITY.5.3.1`
  Status: `done`
  Goal: Admit exact Lua outward user-function descriptors.
  Dependencies: `.5.3.0.1`
  Acceptance: Extend the executable neutral contract/checker with exact final-codeblock-v3 fields before emitter
    code; consume the shared fixed-v1/variadic-v2/v3 descriptor union directly; preserve identical callable
    signatures/parameter kinds through staged and outward copies; remove the Lua fence without a Lua-only record
    shape; reject schema drift; and keep compiled descriptor metadata/order exact on both Lua ABIs. Do not promote
    generic callable-codeblock capability or force unrelated backend runtime work into this leaf.
  Commit: `LUA-BACKEND-PARITY.5.3.1 - admit Lua function descriptors`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.3.1`.

- ID: `LUA-BACKEND-PARITY.5.3.2`
  Status: `done`
  Goal: Propagate one caller-owned trace emitter through the complete native Lua parser pipeline.
  Dependencies: `.5.3.0.1`, `.5.3.1`
  Acceptance: One emitter identity crosses native resolution/loading, source frontend, validation, compilation,
    spec-owned function parser, function-shell projection, staged body resolve/load/compile/execute/stitch, engine
    creation, and runtime execution; ordered phase/rule events, quiet-default behavior, level filtering, sinks,
    error attribution, result neutrality, and no hidden emitter creation match the shared trace precedent.
  Commit: `LUA-BACKEND-PARITY.5.3.2 - propagate Lua full-pipeline trace`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.3.2`.

- ID: `LUA-BACKEND-PARITY.5.3.3`
  Status: `done`
  Goal: Close Lua descriptor/full-pipeline-trace no-drift while preserving completion-time census admission.
  Dependencies: `.5.3.1`, `.5.3.2`
  Acceptance: Focused dual-ABI proof, neutral descriptor/trace fixtures and checkers, public API/status, docs/book,
    task/index/roadmaps/live/KM, and canonical gates agree; the census remains the exact four-backend all-pass
    surface and `.8.4` remains its sole Lua expansion owner; parent `.5.3` closes without claiming generated source,
    corpus execution, or the primary parser CLI.
  Commit: `LUA-BACKEND-PARITY.5.3.3 - close Lua descriptor trace no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.5.3.3`.

- ID: `LUA-BACKEND-PARITY.6`
  Status: `done`
  Goal: Reach complete interpreter-corpus parity.
  Children: `.6.1`, `.6.2`, `.6.3`
  Commit: `LUA-BACKEND-PARITY.6.3 - close full Lua corpus gate`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6`.

- ID: `LUA-BACKEND-PARITY.6.1`
  Status: `done`
  Goal: Admit controlled/core and governed capability fixture windows.
  Children: `.6.1.0`, `.6.1.1`, `.6.1.2`, `.6.1.3`, `.6.1.4`
  Acceptance: Run ordered subsets, classify failures by mechanism, split repairs before code, and preserve exact
    expected values/endpoints rather than weakening fixtures.
  Commit: `LUA-BACKEND-PARITY.6.1.4 - admit Lua capability corpus window`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.1`.

- ID: `LUA-BACKEND-PARITY.6.1.0`
  Status: `done`
  Goal: Measure and dependency-split controlled/core and governed-capability corpus admission before code.
  Dependencies: `.5.3.3`
  Acceptance: Identify the exact ordered manifest windows owned by `.6.1`; execute them through the existing native
    parse/validate/compile/runtime APIs without changing source or fixtures; classify every failure by stage and
    mechanism; retrieve the canonical semantic contract for each residual; and create narrowly owned repair,
    executor, permanent-window, and closeout leaves before behavior work.
  Commit: `LUA-BACKEND-PARITY.6.1.0 - split Lua controlled corpus admission`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.1.0`.

- ID: `LUA-BACKEND-PARITY.6.1.1`
  Status: `done`
  Goal: Preserve nested assignment segment kinds and reject wrong-shape transitions.
  Dependencies: `.6.1.0`
  Acceptance: Evaluate path segments and RHS in the governed order, require numeric index segments to traverse or
    write arrays and key segments to traverse or write hashes, preserve copy-on-write/no-autovivification behavior,
    return null without root mutation for missing/wrong-kind/gap paths, and pass the exact offset-20 oracle case on
    both Lua ABIs without weakening its expected JSON.
  Commit: `LUA-BACKEND-PARITY.6.1.1 - preserve Lua nested path segment kinds`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.1.1`.

- ID: `LUA-BACKEND-PARITY.6.1.2`
  Status: `done`
  Goal: Add reusable native library corpus execution and controlled proof records.
  Dependencies: `.6.1.1`
  Acceptance: Validate the strict manifest, execute selected fixtures through automatic spec-defined parsing,
    validation, compilation, source-identified engine construction, and runtime; compare exact one-level wrapped
    output structurally; retain actual value/output/match/endpoints/trace/diagnostic/failure stage; report every
    selected fixture without aborting; and prove controlled scalar/aggregate/dispatch/lifecycle/function/boundary/
    failure cases while keeping the validation-only corpus CLI unchanged.
  Commit: `LUA-BACKEND-PARITY.6.1.2 - add Lua library corpus execution`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.1.2`.

- ID: `LUA-BACKEND-PARITY.6.1.3`
  Status: `done`
  Goal: Permanently admit the ordered 40-case core corpus prefix.
  Dependencies: `.6.1.2`
  Acceptance: The exact manifest offsets 0-39 pass in order on PUC Lua and LuaJIT through the library executor;
    permanent assertions lock count, first/last names, zero failures, exact expected outputs, and unchanged
    endpoints without parser/runtime or fixture work outside routed failures.
  Commit: `LUA-BACKEND-PARITY.6.1.3 - admit Lua core corpus prefix`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.1.3`.

- ID: `LUA-BACKEND-PARITY.6.1.4`
  Status: `done`
  Goal: Admit the six governed capability fixtures and close controlled/core no-drift.
  Dependencies: `.6.1.3`
  Acceptance: Exact manifest offsets 99-104 pass in order on both Lua ABIs; permanent assertions lock the six
    governed names, endpoints, and outputs; API/status/tests/root and Lua docs/mdBook/KM/task/live state agree;
    parent `.6.1` closes without changing capability-census membership; and `.6.2` activates for offsets 40-98.
  Commit: `LUA-BACKEND-PARITY.6.1.4 - admit Lua capability corpus window`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.1.4`.

- ID: `LUA-BACKEND-PARITY.6.2`
  Status: `done`
  Goal: Admit shipped-spec, recursion, function, and advanced helper windows.
  Children: `.6.2.0`, `.6.2.1`, `.6.2.2`, `.6.2.3`, `.6.2.4`, `.6.2.5`, `.6.2.6`
  Acceptance: Expand monotonically through all named manifest families with exact failure inventories and no
    backend-local expected files. This includes exact `portmap_constant`, `simenv_multiline_value`,
    `ebnf_expression_rules`, `ebnf_logging_annotation`, `lib_reader_sattribute`, and `lib_reader_cattribute` proof
    after the helper/control/output owners on which those cases depend.
  Commit: `LUA-BACKEND-PARITY.6.2.6 - admit Lua advanced corpus window`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.2`.

- ID: `LUA-BACKEND-PARITY.6.2.0`
  Status: `done`
  Goal: Measure and dependency-split exact advanced/shipped offsets 40-98 before behavior changes.
  Dependencies: `.6.1.4`
  Acceptance: Execute the exact 59-case window through the production library executor on PUC Lua and LuaJIT;
    retain exact names, stages, outputs, endpoints, trace evidence, and canonical Perl generated-source evidence;
    retrieve existing Knowledge Map mechanisms before diagnosis; and create narrowly owned repair, residual-
    measurement, permanent-admission, and no-drift leaves before changing runtime behavior or expected values.
  Commit: `LUA-BACKEND-PARITY.6.2.0 - split Lua advanced corpus residuals`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.2.0`.

- ID: `LUA-BACKEND-PARITY.6.2.1`
  Status: `done`
  Goal: Reuse the current action-edge child result for `call(child)` exactly once.
  Dependencies: `.6.2.0`
  Acceptance: When `call(target)` names the current action edge's compiled target, dispatch through that edge state,
    cache one child result, refresh `retv`, and prevent fallback re-execution for self-recursive and non-self edges;
    unrelated named calls retain normal execution. Focused tests lock call count, cursor, value, recursion, and
    passive-child behavior on both Lua ABIs; the six currently affected corpus cases are re-executed unchanged and
    the full offsets 40-98 window is remeasured to route any successor mechanism.
  Commit: `LUA-BACKEND-PARITY.6.2.1 - reuse Lua action-edge child calls`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.2.1`.

- ID: `LUA-BACKEND-PARITY.6.2.2`
  Status: `done`
  Goal: Preserve evaluated values through receiver-form `.copy()` continuation.
  Dependencies: `.6.2.1`
  Acceptance: Generic receiver `copy()` deep-copies its current value exactly once, while function-form
    `copy(value)`, missing/undefined values, nested isolation, and subsequent array/harray/string-compatible
    continuations retain their governed behavior. The unchanged hash-receiver corpus fixture returns its expected
    sixth value `2` on both Lua ABIs.
  Commit: `LUA-BACKEND-PARITY.6.2.2 - preserve Lua receiver copy values`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.2.2`.

- ID: `LUA-BACKEND-PARITY.6.2.3`
  Status: `done`
  Goal: Splice `flat_array(...)` key/value tokens into hash construction.
  Dependencies: `.6.2.2`
  Acceptance: `hash(flat_array(values))` / equivalent harray construction consumes the flattened array as ordered
    key/value tokens rather than stringifying the Lua table as one key; empty input yields an empty harray, nested
    values remain copied, and ordinary non-splice arguments retain their existing boundaries. The unchanged
    `pplugin_empty` fixture returns `[{}]` on both Lua ABIs.
  Commit: `LUA-BACKEND-PARITY.6.2.3 - splice Lua flat arrays into hashes`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.2.3`.

- ID: `LUA-BACKEND-PARITY.6.2.4`
  Status: `done`
  Goal: Mirror the Perl public parser's leading blank/comment-line cursor initialization.
  Dependencies: `.6.2.3`
  Acceptance: Public in-memory `runtime_parse(...)` initializes the top-rule cursor after leading blank and comment
    lines exactly as the Perl wrapper does, while ordinary indexed-variable reads and nonleading content remain
    unchanged. Focused entry-boundary tests and the unchanged `ds_vhistory_version_entry` oracle pass on both Lua
    ABIs without weakening expected output.
  Commit: `LUA-BACKEND-PARITY.6.2.4 - mirror Lua public leading trivia`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.2.4`.

- ID: `LUA-BACKEND-PARITY.6.2.5`
  Status: `done`
  Goal: Remeasure offsets 40-98 and dependency-split every successor residual before further behavior work.
  Dependencies: `.6.2.4`
  Acceptance: Execute the exact 59-case window on both Lua ABIs after the four measured repairs; classify every
    remaining failure with production trace, Knowledge Map retrieval, and canonical toolbox/generated-source
    evidence; create mechanism-sized child leaves before changing behavior; or record a zero-residual boundary and
    activate permanent admission when all 59 pass unchanged.
  Commit: `LUA-BACKEND-PARITY.6.2.5 - record Lua advanced zero residual`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.2.5`.

- ID: `LUA-BACKEND-PARITY.6.2.6`
  Status: `done`
  Goal: Permanently admit exact advanced/shipped offsets 40-98 and close parent no-drift.
  Dependencies: `.6.2.5`
  Acceptance: One recurring production-library test locks all 59 names in manifest order, exact one-level wrapped
    expected outputs, match/endpoints, 59 passes, and zero failures on PUC Lua and LuaJIT; docs/KM/task/roadmap/
    architecture/live state agree; parent `.6.2` closes and full-manifest `.6.3` activates without premature CLI,
    generated-source, public-status, or capability-census promotion.
  Commit: `LUA-BACKEND-PARITY.6.2.6 - admit Lua advanced corpus window`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.2.6`.

- ID: `LUA-BACKEND-PARITY.6.3`
  Status: `done`
  Goal: Make 105/105 exact interpreter execution recurring.
  Acceptance: One strict manifest-driven library gate and corpus runner pass all fixtures, reject manifest drift,
    and run through native in-memory APIs before CLI work is admitted.
  Commit: `LUA-BACKEND-PARITY.6.3 - close full Lua corpus gate`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.6.3`.

- ID: `LUA-BACKEND-PARITY.7`
  Status: `done`
  Goal: Implement and admit the exact primary CLI.
  Children: `.7.1`, `.7.2`, `.7.3`

- ID: `LUA-BACKEND-PARITY.7.1`
  Status: `done`
  Goal: Add `linkedspec-lua` as a thin native-library adapter.
  Acceptance: Implement the exact ADR `0023` option/argument schema, strict UTF-8 source/input boundaries,
    canonical JSON, failures/exits, and trace without subcommands, positionals, environment-dependent parsing, or
    semantics unavailable to in-memory callers.
  Commit: `LUA-BACKEND-PARITY.7.1 - implement Lua primary CLI adapter`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.7.1`.

- ID: `LUA-BACKEND-PARITY.7.2`
  Status: `done`
  Goal: Pass the shared 61-case process suite in default and POSIX environments.
  Acceptance: Add Lua as a first-class backend to the recurring neutral CLI matrix; stdout/stderr/files/exit bytes
    and executable-display substitution are exact.
  Commit: `LUA-BACKEND-PARITY.7.2 - admit Lua primary CLI matrix`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.7.2`.

- ID: `LUA-BACKEND-PARITY.7.3`
  Status: `done`
  Goal: Close CLI/native/corpus no-drift and public usage docs.
  Acceptance: Direct process families, package/corpus gates, executable installation guidance, limitations, mdBook,
    KM, and local CI agree; primary CLI contains no corpus/status extensions.
  Commit: `LUA-BACKEND-PARITY.7.3 - close Lua primary usage no drift`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.7.3`.

- ID: `LUA-BACKEND-PARITY.8`
  Status: `done`
  Goal: Implement generated Lua source and complete capability admission.
  Children: `.8.1`, `.8.2`, `.8.3`, `.8.4`
  Commit: `LUA-BACKEND-PARITY.8.4 - admit Lua capability parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.8`.

- ID: `LUA-BACKEND-PARITY.8.1`
  Status: `done`
  Goal: Add deterministic contract-v1 Lua emitter scaffold and isolated load/run.
  Children: `.8.1.0`, `.8.1.1`, `.8.1.2`
  Acceptance: Effective compiled state, including exact fixed-v1/variadic-v2/final-codeblock-v3 callable records, stable
    identity/metadata/errors, Unicode/strict-UTF-8 payload boundary, direct/traced entrypoints, caller-owned
    isolation, and cleanup pass without altering native interpreter/CLI.
  Commit: `LUA-BACKEND-PARITY.8.1.2 - isolate generated Lua hosts`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.8.1`.

- ID: `LUA-BACKEND-PARITY.8.1.0`
  Status: `done`
  Goal: Audit the post-ADR-0041 generated-source scaffold contract and split implementation before code.
  Dependencies: `.7.3`, `.5.3.1`
  Acceptance: Root-cause the stale v1/v2-only wording against the executable v1/v2/v3 descriptor union; inventory
    the neutral generated-source contract, effective Lua compiled state, canonical JSON/strict-UTF-8 boundary,
    public trace/runtime seams, completed backend emitters, and fresh-process cleanup requirements; then create
    separate deterministic-emission and isolated-load/run leaves with no runtime, CLI, corpus, or census change.
  Commit: `LUA-BACKEND-PARITY.8.1.0 - split Lua generated scaffold`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.8.1.0`.

- ID: `LUA-BACKEND-PARITY.8.1.1`
  Status: `done`
  Goal: Emit deterministic contract-v1 Lua source from exact effective typed state.
  Dependencies: `.8.1.0`
  Acceptance: Add compatibility and source-identified public emitters, exact metadata and typed portable errors,
    last-definition rule order, source-ordered callable records across fixed-v1/variadic-v2/final-codeblock-v3,
    canonical strict-UTF-8 payload encoding, and generated direct/traced entrypoint roles. Repeated equivalent input
    emits identical native Lua source without changing native interpreter, CLI, corpus, plan, or census behavior.
  Commit: `LUA-BACKEND-PARITY.8.1.1 - emit deterministic Lua source`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.8.1.1`.

- ID: `LUA-BACKEND-PARITY.8.1.2`
  Status: `done`
  Goal: Load and run generated Lua source in caller-owned fresh-process isolation.
  Dependencies: `.8.1.1`
  Acceptance: PUC Lua and LuaJIT write one generated module plus host runner into unique caller-owned temporary
    storage, load it in a fresh process with explicit repository/native module paths, prove exact Unicode metadata,
    direct and traced result identity, stable missing-rule and corrupt-payload failures, and remove every generated
    file/directory on success or failure. Portable generated family trace roles remain owned by `.8.2`.
  Commit: `LUA-BACKEND-PARITY.8.1.2 - isolate generated Lua hosts`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.8.1.2`.

- ID: `LUA-BACKEND-PARITY.8.2`
  Status: `done`
  Goal: Add exact ten-family plan and authoritative direct generated execution.
  Acceptance: Ordered public rows, four rejections, per-root/nested family dispatch, portable trace/source identity,
    one isolated all-family matrix, and the unchanged variadic callable fixture execute independently with values
    equal to the native interpreter; generated Lua uses reconstructed typed rest arrays, not host vararg dispatch.
  Commit: `LUA-BACKEND-PARITY.8.2 - execute generated Lua families`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.8.2`.

- ID: `LUA-BACKEND-PARITY.8.3`
  Status: `done`
  Goal: Admit the exact contract-sourced generated 8/105 subset.
  Acceptance: Interpreter-first values, independent generated load, metadata/plans/trace identity, callable-
    signature preservation/execution, checker-owned path/order/no-skip/cleanup, and complete Lua package/CLI/corpus
    gates pass before capability promotion.
  Commit: `LUA-BACKEND-PARITY.8.3 - admit generated Lua subset`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.8.3`.

- ID: `LUA-BACKEND-PARITY.8.4`
  Status: `done`
  Goal: Close Lua capability parity and backend handoff.
  Acceptance: As the sole Lua census-admission owner under ADR `0041`, expand the capability manifest all-pass and
    retire the Lua-owned
    `future.variadic_user_functions` entry only after native and generated callable proofs pass; PUC Lua primary and
    LuaJIT compatibility policies are honest; roadmap/book/KM/live docs/local CI/cleanup pass; no outstanding Lua
    behavior is hidden as a limitation.
  Commit: `LUA-BACKEND-PARITY.8.4 - admit Lua capability parity`
  Narrative epoch: `TYPE-REFERENCE-BOOK.1.2.23.4.16`; exact accepted source via `bash tools/run_python_project_data.sh tools/read_task_narrative.py --tree LUA-BACKEND-PARITY --epoch TYPE-REFERENCE-BOOK.1.2.23.4.16 --id LUA-BACKEND-PARITY.8.4`.

