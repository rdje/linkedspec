# MEMORY

- activation_commit: `83f3ccc5669dff67a823e977fc20455c5c7d863d` — clean Perl-token-census activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.0` — bounded Lua named-selection qualification.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.1.0` (active); task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: PNT; continue after each clean leaf.
- next_action: Freeze Perl145 source/lexer inputs, distinguish actual loader/caller tokens from quoted expectations and select bounded edge populations; publish and commit before expansion.
- in_flight_uncommitted: Perl145 token observations captured; readonly review/publication/commit pending. No background job.
- evidence: docs/checkpoints/lua-transitive-selection-2026-11-17/REVIEW.md; readonly review_epoch_qualified.py/optional --current and diagnose_setup_qualified.py. Current23/1107 scoped blobs/eleven zero named routes/44 operands per isolated ABI block/83 shared dofile/16 earlier names; two actual Bash REDs/positive locator/seven exact helpers/three reader controls. No SDK.
- findings: Syntax loadfile compiles without calling the chunk. Named selection and computed reachability remain distinct. Used reader body was expanded after capture; actual body/failures are retained, seven shared helpers exact. Missing before-use capture/first setup raw channels/separate outer producer exit stay explicit4.2; no retrospective custody credit.
- limits: Perl145 loader1 and relevant excluded/computed/transitive/semantic2 remain open, as do generated Dart/frozen-input/default-literal/repeated ActionIR registration and all native/per-read/source-origin/physical4.2/SESSION5 or other prerequisites.
- publication: Activation/cached4683555e estimate1,485,050,242 bytes/125 ahead/14,949,758-byte margin to director1.5GB excludes this slice. Selected telemetry will be retained; raw pack/full tables ignored; independent size30/native4.2 gaps. All prerequisites/exact canonical proof remain.
- locality: Only this repository writable; submodules black boxes. Same-volume serial jobs/shared24GB/director90-percent rising trend policy. Last cleanup November16 10:59UTC remains under24h; nothing removed. Normal hooks remain mandatory.
