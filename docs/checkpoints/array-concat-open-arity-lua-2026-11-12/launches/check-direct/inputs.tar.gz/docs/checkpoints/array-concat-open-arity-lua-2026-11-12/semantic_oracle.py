"""Finite source intents; no peer observations or backend verdicts."""
import copy
import json
import re
def wire(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"))
def require(condition,reason):
    assert condition,reason
ROUTES=("native","restored","plan","fresh")
def semantic_oracle(cases, cold):
    require(len(cases) == 508 and list(cold) == [row['id'] for row in cases], 'program census')
    require(all(set(row) == set(ROUTES) for row in cold.values()), 'route census')
    require(all(not {'expected', 'role', 'expected_error', 'expected_observation'} & row.keys() for row in cases), 'source-only questions')
    expected = copy.deepcopy(cold)
    supported, compatibility = [], []
    for case in cases:
        key, origin = case['id'], case['origin']
        wanted = None
        if origin == 'shared84':
            if case.get('question') == 'needed-producer-error':
                terminal = re.sub(r'_(hash|terminal)$', '_terminal', key)
                require(all('error' in row for row in cold[terminal].values()), 'needed terminal error')
                wanted = copy.deepcopy(cold[terminal])
                for route in ('plan', 'fresh'):
                    prefix = 'array-concat-open-arity-result-guard/'
                    require(wanted[route]['error_json']['source_identity'] == prefix + terminal + '.spec', 'needed source identity')
                    wanted[route]['error_json']['source_identity'] = prefix + key + '.spec'
            else:
                values = [] if case['empty'] else ['head', 'tail', 'end'][:case['array_count']]
                effects = ('S' if case['source_kind'] == 'function' else '') if case['empty'] else 'STU'[:case['array_count']]
                tail = case['tail']
                if tail == 'terminal':
                    value = [values, effects]
                elif tail == 'compatible':
                    value = [values[-1].upper(), effects]
                elif tail == 'with_':
                    value = [len(values), effects + 'W']
                else:
                    require(tail in ('hash', 'later'), 'authored tail')
                    value = [None, effects]
                wanted = {route: dict(value=copy.deepcopy(value)) for route in ROUTES}
        elif origin == 'questions108':
            question = case['question']
            if question == 'valid-rest-source':
                effects = 'SXTU' if case['signature'] == 'rest_multi' else 'STU'
                value = [['head', 'tail', 'end'], effects] if case['tail'] == 'terminal' else [None, effects]
            elif question == 'source-snapshot':
                value = [['head', 'tail', 'end'] if case['tail'] == 'terminal' else None, ['head', 'changed']]
            elif question == 'nested-kinds':
                value = ['', '0', False, 0, None, {'k': [1]}, [False, 0], 'tail', 'end']
            else:
                require(question in ('initial-producer-policy', 'invalid-signature'), 'own policy scope')
                continue
            wanted = {route: dict(value=copy.deepcopy(value)) for route in ROUTES}
        if wanted is not None:
            if wire(wanted) != wire(cold[key]):
                require(case.get('tail') in ('hash', 'later', 'composed'), 'own supported terminal')
                supported.append(key)
            expected[key] = wanted
    for form in ('free', 'receiver'):
        for key, terminal in (
            ('own_extra_concat_arrays_' + form, 'own_extra_concat_arrays_' + form + '_terminal_probe'),
            ('ordinary_legacy_extra_concat_arrays_' + form + '_composed', 'ordinary_legacy_extra_concat_arrays_' + form + '_terminal'),
        ):
            require(all(set(row) == {'value'} and isinstance(row['value'][0], list)
                and isinstance(row['value'][1], str) for row in cold[terminal].values()), 'own legacy terminal')
            wanted = {route: dict(value=[None, cold[terminal][route]['value'][1]]) for route in ROUTES}
            require(wire(cold[key]) != wire(wanted), 'own legacy continuation RED')
            compatibility.append(key)
            expected[key] = wanted
    require(len(supported) == 20 and len(compatibility) == 4, 'own role census')
    changed = {key for key in cold if wire(cold[key]) != wire(expected[key])}
    require(changed == set(supported + compatibility), 'preservation classification')
    return expected, sorted(supported), sorted(compatibility)


def compare_records(actual, expected):
    require(wire(actual) == wire(expected), 'complete route records')

