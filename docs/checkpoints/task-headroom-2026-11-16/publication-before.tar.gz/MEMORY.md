# MEMORY

- activation_commit: `e476d208dcee58f67ca4d0d7a950d5aa8bdcab00` — clean headroom34 activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.0` — bounded Perl roles and selection.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.34` (active); task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: PNT; continue after each clean leaf.
- next_action: Qualify an eligible unpartitioned closed-task epoch source, preserve its complete contracts/frontier and renew task capacity before remaining qualification.
- in_flight_uncommitted: Headroom34 activation is saved; source qualification/migration/proof/publication and normal commit remain. No required background job.
- evidence: docs/checkpoints/perl-consumer-roles-2026-11-16/REVIEW.md; readonly review_qualified.py; optional --current compares164 retained bodies/modes. Perl145 candidates/134 feature/nine compatibility/two maintenance; seven controls. No Perl test executed.
- findings: Default literal suite3.6.1.2 lacks direct/named-callable selection; pipeline retains selected callable include. Two repeated direct ActionIR selections remain explicit. Registration4.1.2 owns repairs before push.
- landing: First normal hook rejected task-evidence pressure; full own rejected text/log survive and four readonly controls protect routing to the checkpoint. Current task delta589 preserves all older bytes/contracts; renew headroom before more task growth. No partial-hook/global-scan PASS credit. Use normal hooks without a duplicate standalone global scan.
- limits: No complete dynamic include/input/native discovery/population/canonical claim. Remaining roles/direct loaders stay under TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1. Full per-read/native/source-origin/physical closure remains4.2/SESSION5; prior declared5.4/formatter/context/shadowing/launcher/literal/excluded owners stay open.
- preparation: Original952/proposals221/candidate direct Perl omissions131 is dated preparation only; new132 counts only bounded Perl candidates with neither direct nor named-callable route. These populations are different. Prior Dart six-consumer loader ledger stays intact.
- publication: Director1.5GB trigger governs. Clean e476 diagnostic .linkedspec-data/push-monitor/20261116T171858.448209Z estimates1,463,675,787 bytes/114 ahead/cached4683555e;36,324,213-byte margin is dated and has existing30/4.2 gaps. Remeasure after headroom landing;30.2 requires all prerequisites and exact canonical proof.
- locality: Only this repository writable; submodules black boxes. Same-volume serial jobs/shared24GiB/current90-percent rising-trend policy. Cleanup docs/ARTIFACT_CLEANUP.md is current; nothing removed.
