# Documentation Workflow

LinkedSpec needs both public documentation and internal continuity documentation.

Those two documentation families are intentionally separate.

The repository landing page is a third, deliberately smaller surface. Root `README.md` is for stable purpose,
one first-use path, top-level architecture, canonical navigation, contribution/support entry points, and accurate
notices. It is not another public manual, roadmap, status ledger, file inventory, or gate catalog. Route detail to
the book or continuity owner first, then link from README only when that destination is part of stable navigation.

ADR `0063` and `README_POLICY.md` govern that boundary. The adopted budget is at most 128 lines and 6,144 bytes,
derived from a reviewed 105-line / 5,072-byte lossless prototype. The registered `README-STABILITY` doctrine
enforces both limits; raising either requires a new accepted, indexed decision record rather than an ordinary
feature edit. Policy/checker admission was implemented by `README-STABILITY-POLICY.1`, recomposed unchanged and
closed by `.2`, and is checked with:

```bash
bash scripts/check_readme_stability.sh
```

Routing-pressure revision `.4.0` audited the next boundary before changing that checker. Implementation `.4.1`
adds `doctrine/readme_stability/routes.jsonl` and an unconditional core-Perl resulting-tree check. It classifies
reader navigation separately from author-overflow destinations, follows routes transitively, assigns
lifecycle-specific controls, and records legacy high-water marks as debt rather than healthy targets. Every focused run now
proves 62 exact routes over 20 surfaces and all 32 mutation classes before the README doctrine can pass.

The audit also found and traced a stale root `test_input/` layout entry introduced during the original README
trim. LinkedSpec's current fixture roots are `t/` and `tests/`; `.4.1` removes the false route and checks every local
target for existence and symlinks. Four already-large neighboring families—live status, task evidence, changes, and engineering
notes—have a separate `LIVE-DOCUMENT-PRESSURE-CONTAINMENT` owner so the README revision does not silently bless
their present size or mix semantic migration into doctrine admission.

The implementation's definitive local gate passes all seven doctrines, repository containment and moved-root
proof, primary CLI 66/66 in both option environments, and Phase 0 1,031/1,031 in 694 seconds. This closes
implementation signoff without changing parser, runtime, backend, fixture, MCP, or CLI behavior.

Closeout `.4.2` then byte-compares the seven admitted policy/README/registry/checker/doctrine/gate owners with
commit `5c570719` and reruns the full proof without a replacement implementation. The independent gate passes
primary CLI 66/66 twice and Phase 0 1,031/1,031 in 673 seconds, closing routing-pressure revision `.4` unchanged.
`LIVE-DOCUMENT-PRESSURE-CONTAINMENT.0-.4` then preserve exact live/change/note history, partition future task
evidence by stable ID, install bounded current views and complete-record rollover, and independently recompose
the four current routes unchanged. That documentation-sustainability program is composition-closed.

The public book explains LinkedSpec to the outside world. The continuity docs help the project survive crashes, handoffs, and long refactoring sessions.

## Public book

This book is for:

- users
- adopters
- contributors
- evaluators
- future readers outside the immediate implementation loop

It should explain the project clearly and transparently.

The public book lives at:

```text
docs/linkedspec-book/
```

Its job is to answer questions like:

- What is LinkedSpec?
- How do I write and read `.spec` files?
- How do I call `Get(...)` and `get_parser(...)`?
- What does descriptor introspection expose?
- What helper DSL methods exist and why?
- How does compilation work internally?
- How does runtime context and tracing work?
- What shipped material exists?
- What are the real architectural boundaries?

If the outside world needs to understand it, it belongs in the book.

## Internal continuity docs

The repo continuity docs are for:

- crash recovery
- session handoff
- implementation continuity
- commit hygiene

Examples:

- `CHANGES.md`
- `DEVELOPMENT_NOTES.md`
- `MEMORY.md`
- `COMMIT.md`

The latest artifact-maintenance date and disposition live in `docs/ARTIFACT_CLEANUP.md`.
An owned census may retain every artifact: reusable caches, dependency data and
verification evidence are preserved unless an exact deletion is proved safe.
The task tree records the census scope and exclusions; the date record is overwritten
after each cleanup rather than accumulating another history log.
A dated census records file metadata at that moment; it does not prove content ownership
or authorize deletion. Keep the retained snapshot immutable. A later live census is a new
observation, while a read-only reviewer can still check the old recorded totals and inputs.
For a retained daily snapshot, the review order is census completion, fresh scoped comparison,
and independent per-file metadata checks. Save the actual producers, exit statuses and both
output channels before advancing the latest date. A successful review may remove zero files.
For example, the retained October4 snapshot can be checked without recapturing changing state:

```bash
bash tools/run_python_project_data.sh docs/checkpoints/REPO-HYGIENE.9-review.py
```

All other Git repositories and submodules are excluded before traversal. A project task or
notification does not authorize modifying them; their owners apply any upstream repair.
Retained verification logs and canonical receipts are evidence, so their size or age
alone does not authorize deletion. A handoff finishes the current slice, clears
`git_message_brief.txt`, and verifies clean Git state and no required background job
before leaving the next task in `MEMORY.md`.

Continuity docs answer different questions:

- What changed in this slice?
- Why was the implementation shaped this way?
- What should a future session remember after interruption?
- What validation was run before the commit?
- What workflow rules should be followed when committing?

They are optimized for execution continuity, not public onboarding.

## Commit identity and the resume pointer

A tracked file cannot contain the literal hash of the Git commit that contains it: changing that literal changes
the tree and therefore changes the content-addressed commit identity. Current commit identity belongs to Git and
is obtained with `git rev-parse HEAD` or `git log`, never copied back into the same commit.

ADR `0065` adopts a satisfiable boundary for `MEMORY.md`. The bounded pointer names the clean
`activation_commit` from which a leaf started. That value equals `HEAD` while the leaf is being prepared and
equals `HEAD^1` after its normal commit lands. The leaf ID in the commit subject is the durable join key from the
activation boundary to the landing commit. Before committing, the rest of `MEMORY.md` is written as the intended
clean post-landing handoff: the latest leaf has completed task-tree status; an idle pointer has no uncommitted work;
and a completed active leaf is not still described as staged/uncommitted or scheduled for another commit/push.

`MEMORY-COMMIT-POINTER-ENFORCEMENT.0` ratifies this contract, and `.1` implements it through one
read-only phase-aware checker. The pre-commit hook is a hard gate over staged `MEMORY.md` and current
`HEAD`. The post-commit hook is a non-mutating verification signal over committed `HEAD:MEMORY.md`
and `HEAD^1`. The canonical local gate uses an automatic mode that selects a worktree, staged, or clean
committed view and rejects ambiguous staged-plus-unstaged pointer edits. Hermetic tests cover the initial
`root` sentinel, ordinary success, malformed/duplicate fields, genuine drift, and phase ambiguity.
The composed memory doctrine also runs `tools/check_memory_handoff_state.py`: three active/clean/idle twins pass,
while six mutations reject task-status and post-landing contradictions that commit ancestry alone cannot detect.
Closeout `.2` independently recomposed the committed checker, both hook views, all eleven cases, and the current
and historical documentation owners without implementation change; it found no current contradiction and made
the only two unqualified historical task statements point explicitly to ADR `0065`.

## Publishing a measured result

A published measurement carries three different checks: re-derive it from the actual
source at the claim's granularity, falsify a competing hypothesis with a distinguishing
oracle and a control observed failing, then retain the producer and gate all artifact
inputs. A count of search hits is a population to classify; it is not automatically a
count of defects. Aggregate conservation cannot establish correct per-item assignment.

The local contract is `DOCTRINE_ENFORCEMENT.md` section 12, adopted under ADR0126.
`COMMIT.md` contains the review template. New task leaves declare a bounded record in
`docs/claims/`, or explain why no measured claim is published. Checked records name the
command/result, hypothesis/oracle/RED and tracked producer/input hashes. Missing legs
name a reason and an open repair task. The adoption record is a complete schema example.

For instance, an output-count assertion should identify the exact source population and
command, a deliberate dropped/wrong-row control, and the tracked observer that wrote the
result. If the observer exists only in ignored scratch, publish **durability gap** and its
repair owner until its source is retained. Repeating that observer does not cure the gap.
For stochastic performance use intervals and method; named cases and contract counts
require exact agreement. Explain differences from earlier adjudicated sibling cases.

```bash
bash scripts/check_claim_verification.sh
```

The registered checker validates disclosure and declared regular tracked byte identities;
it never executes commands from a record. `live` hashes watch index inputs; `historical`
hashes preserve an explicit existing Git capture rather than today's counter. Re-measure
or explicitly preserve/supersede a stale record; changing its hash alone is not verification.
The selected tests and canonical gate still establish actual behavior. The checker cannot
establish that a source list is complete, a RED happened, or an oracle is independent.

A test can read more than its own source file. Phase 0 discovers shipped specs,
corpora and book Markdown, reads JSON contracts and runs nested consumers. A
file hash for the named suite therefore does not identify every input. Retain
both the contents and directory membership of its input trees. A fixed input
capsule also lets continuity documents change after a run without changing the
bytes that the run actually examined. Gate the capsule against its declared Git
boundary and any explicit candidate overlays before and after execution; retain
complete output channels and reject missing inputs or incomplete TAP plans.
Passing older transcripts retain their original boundary until remeasurement
supersedes them. Preparation alone is not consumer acceptance.

The selected thirteen-suite remeasurement preserves two actual input boundaries.
Twelve suites complete 1,298 groups using the original fixed capsule. The last
suite initially fails before its first assertion because its checkpoint case
file is absent. Its probe, fresh-process program and shared observer are also
required inputs. Adding those four exact files from the same Git revision lets
that suite complete its 39 groups. Every shared input byte and mode stays the
same; the earlier passing runs retain their original capsule identity. Independent
review checks complete plans, ordered results, exits, producer identities and
input membership, and rejects missing inputs and altered or incomplete evidence.
The combined result is 1,337 groups across thirteen unchanged suites. The failed
run remains available; the new result supersedes the older broader observation
without inventing its unretained document reads. The final public book has its
own complete input capsule and render, separate from historical test inputs.

This bounded working-rule/checker adoption does not finish the broader published-constant,
ignored-producer, control and alignment audit owned by startup task .5. Diagnostic path
repair .29 remains required before that audit closeout. Older checkpoints and their
historical results retain their original scope and bytes.


### Replayed diagnostic source

A logical compile filename supplies coordinates; it does not bind the source text
that Python displays in a traceback. If retained bytes contain
`raise RuntimeError("original")` but a newer file at that filename contains
`raise RuntimeError("newer")`, a replay can raise the original exception while
printing the newer line. That displayed line is another artifact input.

The retained reviewer replay supplies the exact original text to the traceback
formatter before execution and independently compares every displayed logical frame
with the executed source at its reported line number. Its source hashes, commands,
input guards, exit codes and both channels are retained. Two original diagnostics
with mismatched context remain explicitly limited historical evidence; fresh bound
replays reproduce their same failures with the correct original lines. Distinguishing
controls reject the old context, incomplete runs, changed producers, erased failures
and forged channels. A filename alone is never evidence of diagnostic source identity.

### Reference identity in provenance probes

An origin must reference the actual event returned by the scanner. Comparing
`origin.event` with a local variable assigned from that same field checks the object
against itself; it cannot establish the returned-event relationship. Compare against
`result.events[index]` instead. Equal JSON values do not establish reference identity.

The retained original pipeline diagnosis contains that limited self-comparison marker.
Its original bytes and adjudication remain available. A corrected probe compares the
actual returned array, and a distinguishing control copies that array while preserving
the origins: values remain equal, the old marker still passes, and the required reference
relationship fails. Dedicated constructor/argument identity tests retain their own scope.

## Definition of done

If a slice changes what the outside world needs to understand about LinkedSpec, the book should move too.

If a slice changes implementation continuity, rationale, or crash-recovery knowledge, the continuity docs should move too.

Those two obligations overlap sometimes, but they are not the same obligation.

Examples:

- Adding or renaming a public DSL helper should update the relevant public helper docs and continuity docs.
- Refactoring an internal owner boundary should update the architecture section if the public mental model changes, plus continuity docs.
- Tightening a diagnostics payload should update compiler/runtime docs if users can observe it, plus continuity docs.
- A purely internal cleanup with no public story may only need continuity docs and validation notes.
- A book-only documentation slice still needs continuity docs so future sessions know what public area was expanded.

## mdBook workflow

Build the book with:

```bash
bash tools/run_mdbook_local.sh
```

The wrapper derives the checkout at runtime, keeps default/generated output on the repository filesystem, and
rejects an external `MDBOOK_BUILD__BUILD_DIR` or `-d`/`--dest-dir` before mdBook starts.

The source files live under:

```text
docs/linkedspec-book/src/
```

The generated HTML output goes under:

```text
docs/linkedspec-book/book/
```

When adding a new chapter, update:

```text
docs/linkedspec-book/src/SUMMARY.md
```

When editing existing chapters, keep the chapter in the section where a reader would naturally look first. If a subject crosses boundaries, prefer a short cross-reference over duplicating a long explanation in several places.

## Documentation style

The public book should be:

- explicit about current behavior,
- transparent about historical or legacy surfaces,
- example-heavy for user-facing APIs and DSL methods,
- clear about maturity and caveats,
- honest about current backend limits such as generated Perl handlers,
- organized by reader need rather than implementation accident.

Avoid hiding transitional areas. If a surface is legacy, say so. If a spec is a placeholder, say so. If a chapter is only a map and deeper walkthroughs still need to be written, say so.

## DSL documentation bar

DSL methods need especially strong documentation.

For each public DSL method or method family, the public docs should eventually explain:

- rationale,
- semantics,
- when to use it,
- when not to use it,
- expected input/output shape,
- how it lowers conceptually,
- several worked `.spec` examples,
- interaction with related methods.

New methods are not fully landed until users can understand and adopt them from the docs. Older methods are held to the same bar as they are revisited.

## Continuity update pattern

For each committed slice, continuity docs usually need:

- a `CHANGES.md` entry with concrete changes and validation commands,
- a `DEVELOPMENT_NOTES.md` entry with rationale and future guidance,
- a `MEMORY.md` entry with interruption-safe resume context.

Keep these entries concise but specific. They should tell the next session what happened and what should be done next.

## Validation pattern

For documentation-only book work, run:

```bash
git diff --check
bash tools/run_mdbook_local.sh
```

For implementation work, run the relevant code/spec tests. The full shared gate is:

```bash
bash tools/run_ci_local.sh
```

If validation could not be run, say so in the final answer and record the limitation when appropriate.
