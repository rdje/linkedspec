fn main() {
let result = key_count_source_rust_fresh::case_count_to_keys::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("KEY_COUNT_RUST_FRESH count_to_keys {}", observed);
let result = key_count_source_rust_fresh::case_count_to_keys_effects::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("KEY_COUNT_RUST_FRESH count_to_keys_effects {}", observed);
let result = key_count_source_rust_fresh::case_initial_keys_controls::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("KEY_COUNT_RUST_FRESH initial_keys_controls {}", observed);
}
