// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "key-count-source/count_to_keys.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJrZXktY291bnQtc291cmNlL2NvdW50X3RvX2tleXMuc3BlYyIsImZ1bmN0aW9ucyI6W10sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7cmV0dXJuKFtjb3VudChbMV0pLmNvdW50X2tleXMoKSxjb3VudChbXSkuY291bnRfa2V5cygpLFsxXS5jb3VudCgpLmNvdW50X2tleXMoKSxbXS5jb3VudCgpLmNvdW50X2tleXMoKV0pfSIsImxpbmUiOjF9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJyZXR1cm4oW2NvdW50KFsxXSkuY291bnRfa2V5cygpLGNvdW50KFtdKS5jb3VudF9rZXlzKCksWzFdLmNvdW50KCkuY291bnRfa2V5cygpLFtdLmNvdW50KCkuY291bnRfa2V5cygpXSkifSwic291cmNlIjoiSSB7cmV0dXJuKFtjb3VudChbMV0pLmNvdW50X2tleXMoKSxjb3VudChbXSkuY291bnRfa2V5cygpLFsxXS5jb3VudCgpLmNvdW50X2tleXMoKSxbXS5jb3VudCgpLmNvdW50X2tleXMoKV0pfSIsImxpbmUiOjF9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
