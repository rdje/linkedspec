# MEMORY

- activation_commit: `7553dbde0a380fc94d1f150899a91dfd448d74ae` — clean Lua-selection activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.2` — generated Rust classifier source/input qualification.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.0` (active); task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: PNT; continue after each clean leaf.
- next_action: Qualify the eleven Lua candidates’ named transitive/caller selection separately from syntax checks; publish and commit this bounded source proof before Perl145 and reconciliation.
- in_flight_uncommitted: Lua transitive source selection qualification; no background job.
- evidence: docs/checkpoints/rust-generated-loader-qualification-2026-11-17/REVIEW.md; readonly review_qualified.py/optional --current. Bindings320/targets319/parent3/template2/command3/fs11/Count17/trace2/current442/historical321/control12. Original capture1 and derived scoped reader0 retained. No Cargo/SDK.
- findings: Corpus paths are potential dependencies, prepared subset controls emitted files. Focused Count checks child status; full-manifest run status gap remains SESSION77. Trace output is generated, without Cargo in that parent. Current identities do not prove actual older embedded bytes, execution or native origins.
- limits: Remaining Perl-transitive3 includes eleven unresolved Lua routes. Generated Dart2/frozen-input3/default-literal/repeated ActionIR registration and all native/per-read/source-origin/physical4.2/SESSION5 or other prerequisites remain open. Full independent semantic qualification remains3.
- publication: Activation/cached4683555e estimate1,484,126,518 bytes/124 ahead/15,873,482-byte margin to director1.5GB excludes this slice. Selected telemetry will be retained; raw pack/full tables ignored; independent size30/native4.2 gaps. Remeasure after landing; all prerequisites/exact canonical proof remain.
- locality: Only this repository writable; submodules black boxes. Same-volume serial jobs/shared24GB/director90-percent rising trend policy. Last cleanup November16 10:59UTC remains under24h; nothing removed. Normal hooks remain mandatory.
