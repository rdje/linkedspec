// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "key-count-callable/compatible_counts.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJrZXktY291bnQtY2FsbGFibGUvY29tcGF0aWJsZV9jb3VudHMuc3BlYyIsImZ1bmN0aW9ucyI6W3sibmFtZSI6Im1ha2VfaGFzaCIsInBhcmFtcyI6W10sImFyaXR5IjowLCJib2R5X3NvdXJjZSI6InJldHVybih7XCJrXCI6MX0pIiwiYm9keV9wYXlsb2FkIjp7ImtpbmQiOiJzdGFnZWRfcGF5bG9hZCIsInZlcnNpb24iOjEsIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJmdW5jdGlvbl9uYW1lIjoibWFrZV9oYXNoIiwicGFyYW1zIjpbXSwiYXJpdHkiOjAsInRleHQiOiJyZXR1cm4oe1wia1wiOjF9KSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxNSwiZW5kIjozMCwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwcm92ZW5hbmNlIjpbeyJraW5kIjoic291cmNlX3NsaWNlIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjE1LCJlbmQiOjMwLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XX0sImJvZHlfcGFyc2Vfam9iIjp7ImtpbmQiOiJwYXJzZV9qb2IiLCJ2ZXJzaW9uIjoxLCJqb2JfaWQiOiJwYXJzZV9qb2I6ZnVuY3Rpb25fYm9keTpmdW5jdGlvbnMuMC5ib2R5X3NvdXJjZTphY3Rpb25pci1ib2R5LnNwZWM6YWN0aW9uX2Jsb2NrOjE1LTMwIiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsImZ1bmN0aW9uX25hbWUiOiJtYWtlX2hhc2giLCJwYXJhbXMiOltdLCJhcml0eSI6MCwidGV4dCI6InJldHVybih7XCJrXCI6MX0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjE1LCJlbmQiOjMwLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInBhcnNlcl9zcGVjX2lkIjoiYWN0aW9uaXItYm9keS5zcGVjIiwidG9wX3J1bGUiOiJhY3Rpb25fYmxvY2siLCJyZXN1bHRfcG9saWN5IjoicmVwbGFjZV9maWVsZCIsInJlc3VsdF9maWVsZCI6ImJvZHlfYXN0IiwiZmFpbHVyZV9wb2xpY3kiOiJmYWlsIiwiZGlhZ25vc3RpY19vd25lciI6ImZ1bmN0aW9uX2JvZHkifSwiYm9keV9hc3QiOnsia2luZCI6ImFjdGlvbl9ibG9jayIsInNvdXJjZSI6InJldHVybih7XCJrXCI6MX0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTV9LCJzdGF0ZW1lbnRzIjpbeyJraW5kIjoiYWN0aW9uX3N0bXQiLCJzb3VyY2UiOiJyZXR1cm4oe1wia1wiOjF9KSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjE1fSwiZXhwciI6eyJraW5kIjoiY2FsbCIsInNvdXJjZSI6InJldHVybih7XCJrXCI6MX0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTV9LCJuYW1lIjoicmV0dXJuIiwic291cmNlX21ldGhvZCI6InJldHVybiIsImFyZ3MiOlt7ImtpbmQiOiJoYXNoX2xpdGVyYWwiLCJzb3VyY2UiOiJ7XCJrXCI6MX0iLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6NywiZW5kIjoxNH0sImVudHJpZXMiOlt7ImtleSI6eyJraW5kIjoic3RyaW5nIiwic291cmNlIjoiXCJrXCIiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6OCwiZW5kIjoxMX0sInZhbHVlIjoiayIsInF1b3RlIjoiXCIifSwidmFsdWUiOnsia2luZCI6Im51bWJlciIsInNvdXJjZSI6IjEiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MTIsImVuZCI6MTN9LCJ2YWx1ZSI6MX19XX1dfSwiZHJvcHNfdmFsdWUiOnRydWV9XX0sInNvdXJjZSI6ImZuIG1ha2VfaGFzaCgpe3JldHVybih7XCJrXCI6MX0pfSIsInNvdXJjZV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwiYm9keV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge3JldHVybihbbWFrZV9oYXNoKCkuY291bnRfa2V5cygpLG1ha2VfaGFzaCgpLmNvdW50X2tleXMoKS5hZGQoMSksY291bnRfa2V5cyhtYWtlX2hhc2goKSkuYWRkKDEpLG1ha2VfaGFzaCgpLmNvdW50X2tleXMoKS5jYXQoXCIga2V5c1wiKS51cHBlcmNhc2UoKV0pfSIsImxpbmUiOjF9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJyZXR1cm4oW21ha2VfaGFzaCgpLmNvdW50X2tleXMoKSxtYWtlX2hhc2goKS5jb3VudF9rZXlzKCkuYWRkKDEpLGNvdW50X2tleXMobWFrZV9oYXNoKCkpLmFkZCgxKSxtYWtlX2hhc2goKS5jb3VudF9rZXlzKCkuY2F0KFwiIGtleXNcIikudXBwZXJjYXNlKCldKSJ9LCJzb3VyY2UiOiJJIHtyZXR1cm4oW21ha2VfaGFzaCgpLmNvdW50X2tleXMoKSxtYWtlX2hhc2goKS5jb3VudF9rZXlzKCkuYWRkKDEpLGNvdW50X2tleXMobWFrZV9oYXNoKCkpLmFkZCgxKSxtYWtlX2hhc2goKS5jb3VudF9rZXlzKCkuY2F0KFwiIGtleXNcIikudXBwZXJjYXNlKCldKX0iLCJsaW5lIjoxfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
