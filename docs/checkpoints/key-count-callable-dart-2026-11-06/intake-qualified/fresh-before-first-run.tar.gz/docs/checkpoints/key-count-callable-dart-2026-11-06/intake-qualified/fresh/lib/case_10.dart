// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "key-count-callable/needed_argument_error.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJrZXktY291bnQtY2FsbGFibGUvbmVlZGVkX2FyZ3VtZW50X2Vycm9yLnNwZWMiLCJmdW5jdGlvbnMiOlt7Im5hbWUiOiJtYWtlX2hhc2giLCJwYXJhbXMiOlsiaWdub3JlZCJdLCJhcml0eSI6MSwiYm9keV9zb3VyY2UiOiJyZXR1cm4oe1wia1wiOjF9KSIsImJvZHlfcGF5bG9hZCI6eyJraW5kIjoic3RhZ2VkX3BheWxvYWQiLCJ2ZXJzaW9uIjoxLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwiZnVuY3Rpb25fbmFtZSI6Im1ha2VfaGFzaCIsInBhcmFtcyI6WyJpZ25vcmVkIl0sImFyaXR5IjoxLCJ0ZXh0IjoicmV0dXJuKHtcImtcIjoxfSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjIsImVuZCI6MzcsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicHJvdmVuYW5jZSI6W3sia2luZCI6InNvdXJjZV9zbGljZSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyMiwiZW5kIjozNywibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV19LCJib2R5X3BhcnNlX2pvYiI6eyJraW5kIjoicGFyc2Vfam9iIiwidmVyc2lvbiI6MSwiam9iX2lkIjoicGFyc2Vfam9iOmZ1bmN0aW9uX2JvZHk6ZnVuY3Rpb25zLjAuYm9keV9zb3VyY2U6YWN0aW9uaXItYm9keS5zcGVjOmFjdGlvbl9ibG9jazoyMi0zNyIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJmdW5jdGlvbl9uYW1lIjoibWFrZV9oYXNoIiwicGFyYW1zIjpbImlnbm9yZWQiXSwiYXJpdHkiOjEsInRleHQiOiJyZXR1cm4oe1wia1wiOjF9KSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyMiwiZW5kIjozNywibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwYXJzZXJfc3BlY19pZCI6ImFjdGlvbmlyLWJvZHkuc3BlYyIsInRvcF9ydWxlIjoiYWN0aW9uX2Jsb2NrIiwicmVzdWx0X3BvbGljeSI6InJlcGxhY2VfZmllbGQiLCJyZXN1bHRfZmllbGQiOiJib2R5X2FzdCIsImZhaWx1cmVfcG9saWN5IjoiZmFpbCIsImRpYWdub3N0aWNfb3duZXIiOiJmdW5jdGlvbl9ib2R5In0sImJvZHlfYXN0Ijp7ImtpbmQiOiJhY3Rpb25fYmxvY2siLCJzb3VyY2UiOiJyZXR1cm4oe1wia1wiOjF9KSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjE1fSwic3RhdGVtZW50cyI6W3sia2luZCI6ImFjdGlvbl9zdG10Iiwic291cmNlIjoicmV0dXJuKHtcImtcIjoxfSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxNX0sImV4cHIiOnsia2luZCI6ImNhbGwiLCJzb3VyY2UiOiJyZXR1cm4oe1wia1wiOjF9KSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjE1fSwibmFtZSI6InJldHVybiIsInNvdXJjZV9tZXRob2QiOiJyZXR1cm4iLCJhcmdzIjpbeyJraW5kIjoiaGFzaF9saXRlcmFsIiwic291cmNlIjoie1wia1wiOjF9Iiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MTR9LCJlbnRyaWVzIjpbeyJrZXkiOnsia2luZCI6InN0cmluZyIsInNvdXJjZSI6Ilwia1wiIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjgsImVuZCI6MTF9LCJ2YWx1ZSI6ImsiLCJxdW90ZSI6IlwiIn0sInZhbHVlIjp7ImtpbmQiOiJudW1iZXIiLCJzb3VyY2UiOiIxIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjEyLCJlbmQiOjEzfSwidmFsdWUiOjF9fV19XX0sImRyb3BzX3ZhbHVlIjp0cnVlfV19LCJzb3VyY2UiOiJmbiBtYWtlX2hhc2goaWdub3JlZCl7cmV0dXJuKHtcImtcIjoxfSl9Iiwic291cmNlX3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJib2R5X3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV0sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7cmV0dXJuKG1ha2VfaGFzaCh7aXRlbXM9XCJ0ZXh0XCI7cHVzaChpdGVtcyxcInhcIil9KS5jb3VudF9rZXlzKCkuY29hbGVzY2UoXCJtYXNrZWRcIikpfSIsImxpbmUiOjF9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJyZXR1cm4obWFrZV9oYXNoKHtpdGVtcz1cInRleHRcIjtwdXNoKGl0ZW1zLFwieFwiKX0pLmNvdW50X2tleXMoKS5jb2FsZXNjZShcIm1hc2tlZFwiKSkifSwic291cmNlIjoiSSB7cmV0dXJuKG1ha2VfaGFzaCh7aXRlbXM9XCJ0ZXh0XCI7cHVzaChpdGVtcyxcInhcIil9KS5jb3VudF9rZXlzKCkuY29hbGVzY2UoXCJtYXNrZWRcIikpfSIsImxpbmUiOjF9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
