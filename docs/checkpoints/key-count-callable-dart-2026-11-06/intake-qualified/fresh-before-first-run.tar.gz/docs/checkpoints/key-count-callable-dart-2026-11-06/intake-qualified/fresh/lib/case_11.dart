// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "key-count-callable/boolean_receiver_profile.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJrZXktY291bnQtY2FsbGFibGUvYm9vbGVhbl9yZWNlaXZlcl9wcm9maWxlLnNwZWMiLCJmdW5jdGlvbnMiOlt7Im5hbWUiOiJtYWtlX2Jvb2wiLCJwYXJhbXMiOltdLCJhcml0eSI6MCwiYm9keV9zb3VyY2UiOiJyZXR1cm4oZmFsc2UpIiwiYm9keV9wYXlsb2FkIjp7ImtpbmQiOiJzdGFnZWRfcGF5bG9hZCIsInZlcnNpb24iOjEsIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJmdW5jdGlvbl9uYW1lIjoibWFrZV9ib29sIiwicGFyYW1zIjpbXSwiYXJpdHkiOjAsInRleHQiOiJyZXR1cm4oZmFsc2UpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjE1LCJlbmQiOjI4LCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInByb3ZlbmFuY2UiOlt7ImtpbmQiOiJzb3VyY2Vfc2xpY2UiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MTUsImVuZCI6MjgsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dfSwiYm9keV9wYXJzZV9qb2IiOnsia2luZCI6InBhcnNlX2pvYiIsInZlcnNpb24iOjEsImpvYl9pZCI6InBhcnNlX2pvYjpmdW5jdGlvbl9ib2R5OmZ1bmN0aW9ucy4wLmJvZHlfc291cmNlOmFjdGlvbmlyLWJvZHkuc3BlYzphY3Rpb25fYmxvY2s6MTUtMjgiLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwiZnVuY3Rpb25fbmFtZSI6Im1ha2VfYm9vbCIsInBhcmFtcyI6W10sImFyaXR5IjowLCJ0ZXh0IjoicmV0dXJuKGZhbHNlKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxNSwiZW5kIjoyOCwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwYXJzZXJfc3BlY19pZCI6ImFjdGlvbmlyLWJvZHkuc3BlYyIsInRvcF9ydWxlIjoiYWN0aW9uX2Jsb2NrIiwicmVzdWx0X3BvbGljeSI6InJlcGxhY2VfZmllbGQiLCJyZXN1bHRfZmllbGQiOiJib2R5X2FzdCIsImZhaWx1cmVfcG9saWN5IjoiZmFpbCIsImRpYWdub3N0aWNfb3duZXIiOiJmdW5jdGlvbl9ib2R5In0sImJvZHlfYXN0Ijp7ImtpbmQiOiJhY3Rpb25fYmxvY2siLCJzb3VyY2UiOiJyZXR1cm4oZmFsc2UpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTN9LCJzdGF0ZW1lbnRzIjpbeyJraW5kIjoiYWN0aW9uX3N0bXQiLCJzb3VyY2UiOiJyZXR1cm4oZmFsc2UpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTN9LCJleHByIjp7ImtpbmQiOiJjYWxsIiwic291cmNlIjoicmV0dXJuKGZhbHNlKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjEzfSwibmFtZSI6InJldHVybiIsInNvdXJjZV9tZXRob2QiOiJyZXR1cm4iLCJhcmdzIjpbeyJraW5kIjoiYm9vbGVhbiIsInNvdXJjZSI6ImZhbHNlIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MTJ9LCJ2YWx1ZSI6ZmFsc2V9XX0sImRyb3BzX3ZhbHVlIjp0cnVlfV19LCJzb3VyY2UiOiJmbiBtYWtlX2Jvb2woKXtyZXR1cm4oZmFsc2UpfSIsInNvdXJjZV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwiYm9keV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge3JldHVybihtYWtlX2Jvb2woKS5jb3VudF9rZXlzKCkuYWRkKDEpKX0iLCJsaW5lIjoxfSwiYm9keSI6W3sia2luZCI6eyJraW5kIjoiY29kZV9ibG9jayIsImxpZmVjeWNsZSI6IkkiLCJjb2RlIjoicmV0dXJuKG1ha2VfYm9vbCgpLmNvdW50X2tleXMoKS5hZGQoMSkpIn0sInNvdXJjZSI6Ikkge3JldHVybihtYWtlX2Jvb2woKS5jb3VudF9rZXlzKCkuYWRkKDEpKX0iLCJsaW5lIjoxfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
