// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "key-count-callable/parameter_source_control.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJrZXktY291bnQtY2FsbGFibGUvcGFyYW1ldGVyX3NvdXJjZV9jb250cm9sLnNwZWMiLCJmdW5jdGlvbnMiOlt7Im5hbWUiOiJlY2hvX2hhc2giLCJwYXJhbXMiOlsicGF5bG9hZCJdLCJhcml0eSI6MSwiYm9keV9zb3VyY2UiOiJyZXR1cm4ocGF5bG9hZCkiLCJib2R5X3BheWxvYWQiOnsia2luZCI6InN0YWdlZF9wYXlsb2FkIiwidmVyc2lvbiI6MSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sImZ1bmN0aW9uX25hbWUiOiJlY2hvX2hhc2giLCJwYXJhbXMiOlsicGF5bG9hZCJdLCJhcml0eSI6MSwidGV4dCI6InJldHVybihwYXlsb2FkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyMiwiZW5kIjozNywibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwcm92ZW5hbmNlIjpbeyJraW5kIjoic291cmNlX3NsaWNlIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjIyLCJlbmQiOjM3LCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XX0sImJvZHlfcGFyc2Vfam9iIjp7ImtpbmQiOiJwYXJzZV9qb2IiLCJ2ZXJzaW9uIjoxLCJqb2JfaWQiOiJwYXJzZV9qb2I6ZnVuY3Rpb25fYm9keTpmdW5jdGlvbnMuMC5ib2R5X3NvdXJjZTphY3Rpb25pci1ib2R5LnNwZWM6YWN0aW9uX2Jsb2NrOjIyLTM3IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsImZ1bmN0aW9uX25hbWUiOiJlY2hvX2hhc2giLCJwYXJhbXMiOlsicGF5bG9hZCJdLCJhcml0eSI6MSwidGV4dCI6InJldHVybihwYXlsb2FkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyMiwiZW5kIjozNywibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwYXJzZXJfc3BlY19pZCI6ImFjdGlvbmlyLWJvZHkuc3BlYyIsInRvcF9ydWxlIjoiYWN0aW9uX2Jsb2NrIiwicmVzdWx0X3BvbGljeSI6InJlcGxhY2VfZmllbGQiLCJyZXN1bHRfZmllbGQiOiJib2R5X2FzdCIsImZhaWx1cmVfcG9saWN5IjoiZmFpbCIsImRpYWdub3N0aWNfb3duZXIiOiJmdW5jdGlvbl9ib2R5In0sImJvZHlfYXN0Ijp7ImtpbmQiOiJhY3Rpb25fYmxvY2siLCJzb3VyY2UiOiJyZXR1cm4ocGF5bG9hZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxNX0sInN0YXRlbWVudHMiOlt7ImtpbmQiOiJhY3Rpb25fc3RtdCIsInNvdXJjZSI6InJldHVybihwYXlsb2FkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjE1fSwiZXhwciI6eyJraW5kIjoiY2FsbCIsInNvdXJjZSI6InJldHVybihwYXlsb2FkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjE1fSwibmFtZSI6InJldHVybiIsInNvdXJjZV9tZXRob2QiOiJyZXR1cm4iLCJhcmdzIjpbeyJraW5kIjoidmFyaWFibGUiLCJzb3VyY2UiOiJwYXlsb2FkIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MTR9LCJuYW1lIjoicGF5bG9hZCJ9XX0sImRyb3BzX3ZhbHVlIjp0cnVlfV19LCJzb3VyY2UiOiJmbiBlY2hvX2hhc2gocGF5bG9hZCl7cmV0dXJuKHBheWxvYWQpfSIsInNvdXJjZV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwiYm9keV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge3JldHVybihbZWNob19oYXNoKHtcInhcIjoxfSkuY291bnRfa2V5cygpLGNvdW50X2tleXMoZWNob19oYXNoKHtcInhcIjoxfSkpLGVjaG9faGFzaCh7XCJ4XCI6MX0pXSl9IiwibGluZSI6MX0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6InJldHVybihbZWNob19oYXNoKHtcInhcIjoxfSkuY291bnRfa2V5cygpLGNvdW50X2tleXMoZWNob19oYXNoKHtcInhcIjoxfSkpLGVjaG9faGFzaCh7XCJ4XCI6MX0pXSkifSwic291cmNlIjoiSSB7cmV0dXJuKFtlY2hvX2hhc2goe1wieFwiOjF9KS5jb3VudF9rZXlzKCksY291bnRfa2V5cyhlY2hvX2hhc2goe1wieFwiOjF9KSksZWNob19oYXNoKHtcInhcIjoxfSldKX0iLCJsaW5lIjoxfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
