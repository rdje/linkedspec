// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "key-count-callable/explicit_bridges.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJrZXktY291bnQtY2FsbGFibGUvZXhwbGljaXRfYnJpZGdlcy5zcGVjIiwiZnVuY3Rpb25zIjpbeyJuYW1lIjoibWFrZV9oYXNoIiwicGFyYW1zIjpbXSwiYXJpdHkiOjAsImJvZHlfc291cmNlIjoicmV0dXJuKHtcImtcIjoxfSkiLCJib2R5X3BheWxvYWQiOnsia2luZCI6InN0YWdlZF9wYXlsb2FkIiwidmVyc2lvbiI6MSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sImZ1bmN0aW9uX25hbWUiOiJtYWtlX2hhc2giLCJwYXJhbXMiOltdLCJhcml0eSI6MCwidGV4dCI6InJldHVybih7XCJrXCI6MX0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjE1LCJlbmQiOjMwLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInByb3ZlbmFuY2UiOlt7ImtpbmQiOiJzb3VyY2Vfc2xpY2UiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MTUsImVuZCI6MzAsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dfSwiYm9keV9wYXJzZV9qb2IiOnsia2luZCI6InBhcnNlX2pvYiIsInZlcnNpb24iOjEsImpvYl9pZCI6InBhcnNlX2pvYjpmdW5jdGlvbl9ib2R5OmZ1bmN0aW9ucy4wLmJvZHlfc291cmNlOmFjdGlvbmlyLWJvZHkuc3BlYzphY3Rpb25fYmxvY2s6MTUtMzAiLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwiZnVuY3Rpb25fbmFtZSI6Im1ha2VfaGFzaCIsInBhcmFtcyI6W10sImFyaXR5IjowLCJ0ZXh0IjoicmV0dXJuKHtcImtcIjoxfSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MTUsImVuZCI6MzAsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicGFyc2VyX3NwZWNfaWQiOiJhY3Rpb25pci1ib2R5LnNwZWMiLCJ0b3BfcnVsZSI6ImFjdGlvbl9ibG9jayIsInJlc3VsdF9wb2xpY3kiOiJyZXBsYWNlX2ZpZWxkIiwicmVzdWx0X2ZpZWxkIjoiYm9keV9hc3QiLCJmYWlsdXJlX3BvbGljeSI6ImZhaWwiLCJkaWFnbm9zdGljX293bmVyIjoiZnVuY3Rpb25fYm9keSJ9LCJib2R5X2FzdCI6eyJraW5kIjoiYWN0aW9uX2Jsb2NrIiwic291cmNlIjoicmV0dXJuKHtcImtcIjoxfSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxNX0sInN0YXRlbWVudHMiOlt7ImtpbmQiOiJhY3Rpb25fc3RtdCIsInNvdXJjZSI6InJldHVybih7XCJrXCI6MX0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTV9LCJleHByIjp7ImtpbmQiOiJjYWxsIiwic291cmNlIjoicmV0dXJuKHtcImtcIjoxfSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxNX0sIm5hbWUiOiJyZXR1cm4iLCJzb3VyY2VfbWV0aG9kIjoicmV0dXJuIiwiYXJncyI6W3sia2luZCI6Imhhc2hfbGl0ZXJhbCIsInNvdXJjZSI6IntcImtcIjoxfSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0Ijo3LCJlbmQiOjE0fSwiZW50cmllcyI6W3sia2V5Ijp7ImtpbmQiOiJzdHJpbmciLCJzb3VyY2UiOiJcImtcIiIsInNvdXJjZV9zcGFuIjp7InN0YXJ0Ijo4LCJlbmQiOjExfSwidmFsdWUiOiJrIiwicXVvdGUiOiJcIiJ9LCJ2YWx1ZSI6eyJraW5kIjoibnVtYmVyIiwic291cmNlIjoiMSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxMiwiZW5kIjoxM30sInZhbHVlIjoxfX1dfV19LCJkcm9wc192YWx1ZSI6dHJ1ZX1dfSwic291cmNlIjoiZm4gbWFrZV9oYXNoKCl7cmV0dXJuKHtcImtcIjoxfSl9Iiwic291cmNlX3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJib2R5X3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV0sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7cmV0dXJuKFttYWtlX2hhc2goKS5jb3VudF9rZXlzKCkuY2F0KFwiLHRhaWxcIikuc3BsaXQoXCIsXCIpLmxhc3QoKS51cHBlcmNhc2UoKSxtYWtlX2hhc2goKS5jb3VudF9rZXlzKCkud2l0aCgpe3JldHVybihbMSwyXSl9LmNvdW50KCksbWFrZV9oYXNoKCkuY291bnRfa2V5cygpLndpdGgoKXtyZXR1cm4oe1wieFwiOjF9KX0uY291bnRfa2V5cygpXSl9IiwibGluZSI6MX0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6InJldHVybihbbWFrZV9oYXNoKCkuY291bnRfa2V5cygpLmNhdChcIix0YWlsXCIpLnNwbGl0KFwiLFwiKS5sYXN0KCkudXBwZXJjYXNlKCksbWFrZV9oYXNoKCkuY291bnRfa2V5cygpLndpdGgoKXtyZXR1cm4oWzEsMl0pfS5jb3VudCgpLG1ha2VfaGFzaCgpLmNvdW50X2tleXMoKS53aXRoKCl7cmV0dXJuKHtcInhcIjoxfSl9LmNvdW50X2tleXMoKV0pIn0sInNvdXJjZSI6Ikkge3JldHVybihbbWFrZV9oYXNoKCkuY291bnRfa2V5cygpLmNhdChcIix0YWlsXCIpLnNwbGl0KFwiLFwiKS5sYXN0KCkudXBwZXJjYXNlKCksbWFrZV9oYXNoKCkuY291bnRfa2V5cygpLndpdGgoKXtyZXR1cm4oWzEsMl0pfS5jb3VudCgpLG1ha2VfaGFzaCgpLmNvdW50X2tleXMoKS53aXRoKCl7cmV0dXJuKHtcInhcIjoxfSl9LmNvdW50X2tleXMoKV0pfSIsImxpbmUiOjF9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
