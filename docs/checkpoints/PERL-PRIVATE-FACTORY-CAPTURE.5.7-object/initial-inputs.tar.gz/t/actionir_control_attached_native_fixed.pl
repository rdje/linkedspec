use strict;
use warnings;
use utf8;
use JSON::PP ();
use Scalar::Util qw(refaddr reftype);
use FindBin ();
use Cwd qw(abs_path);
use File::Spec ();
use LinkedSpec::ActionIR::ControlFlow ();

my $cold = @ARGV && $ARGV[0] eq 'cold';
unless ($cold) {
 require LinkedSpec::ActionIR::SourceOrigins;
 require LinkedSpec::ActionIR::SourceEmissions;
}
my $json = JSON::PP->new->canonical->ascii;
my $root = abs_path($FindBin::Bin.'/..');
my %owners = (
 parse => \&LinkedSpec::ActionIR::ControlFlow::_parse_method_expr_with_optional_attached_block,
);
my @keys = qw(trim_action_ir_value parse_method_function_expr);
my %required = (parse => [@keys]);
my %cases = (
 plain => {owner => 'parse', input => 'foo(first, second)'},
 spaced_plain => {owner => 'parse', input => '  foo(first)  '},
 attached => {owner => 'parse', input => 'foo() { first; second }', decline_attached => 1},
 native_attached => {owner => 'parse', input => 'foo() { first; second }'},
 empty_body => {owner => 'parse', input => 'foo() {}', decline_attached => 1},
 nested_body => {owner => 'parse', input => 'foo() { bar() { inner }; last }', decline_attached => 1},
 quoted_brace => {owner => 'parse', input => 'foo("{ inside }")'},
 escaped_quote => {owner => 'parse', input => q!foo("a\"{b") { body }!, decline_attached => 1},
 bracket_brace => {owner => 'parse', input => 'foo(["{"]) { body }', decline_attached => 1},
 quote_body => {owner => 'parse', input => q{foo() { say("}"); say('{') }}, decline_attached => 1},
 leading_regex => {owner => 'parse', input => '/{(}\/)/', parser_never => 1},
 malformed_body => {owner => 'parse', input => 'foo() { body', parser_never => 1},
 trailing_text => {owner => 'parse', input => 'foo() { body } extra', parser_never => 1},
 unbalanced_head => {owner => 'parse', input => 'foo( { body }', parser_never => 1},
 empty_input => {owner => 'parse', input => ''},
 undefined_input => {owner => 'parse', input => undef},
 whitespace_input => {owner => 'parse', input => '   '},
 identity_whitespace => {owner => 'parse', input => '   ', trim_identity => 1},
 zero_input => {owner => 'parse', input => '0'},
 otherwise => {owner => 'parse', input => 'otherwise'},
 else_marker => {owner => 'parse', input => 'else'},
 endif_marker => {owner => 'parse', input => 'endif'},
 default_marker => {owner => 'parse', input => 'default'},
 endcase_marker => {owner => 'parse', input => 'endcase'},
 endswitch_marker => {owner => 'parse', input => 'endswitch'},
 next_marker => {owner => 'parse', input => 'next'},
 if_source => {owner => 'parse', input => 'if(true) { say("λ😀") }', decline_attached => 1},
 while_source => {owner => 'parse', input => 'while(false) { next }', decline_attached => 1},
 switch_source => {owner => 'parse', input => 'switch(value) { case("x") { say("x") } default { say("d") } }', decline_attached => 1},
 typed_if => {owner => 'parse', input => {kind => 'control_if', keyword => 'if',
  source => 'poison', condition => {kind => 'boolean', value => 1, source => 'poison'},
  body => {kind => 'action_block', source => 'poison', statements => [
   {kind => 'call', name => 'poison', source_method => 'cat', source => 'poison',
    args => [{kind => 'string', value => "λ😀", source => 'poison'}]}]}}, decline_attached => 1},
 typed_else => {owner => 'parse', input => {kind => 'control_else', keyword => 'otherwise',
  source => 'poison', body => {kind => 'action_block', statements => []}}, decline_attached => 1},
 typed_while => {owner => 'parse', input => {kind => 'control_while', source => 'poison',
  condition => {kind => 'boolean', value => 0}, body => {kind => 'action_block', statements => []}}, decline_attached => 1},
 typed_switch => {owner => 'parse', input => {kind => 'control_switch', source => 'poison',
  source_expr => {kind => 'variable', name => 'value'}, cases => [{kind => 'control_case',
   match => {kind => 'string', value => 'x'}, body => {kind => 'action_block', statements => []}}],
  default => {kind => 'control_default', body => {kind => 'action_block', statements => []}},
  body => {kind => 'action_block', statements => [{kind => 'variable', name => 'poison'}]}}, decline_attached => 1},
);
for my $kind (qw(undefined empty zero one hash array blessed code)) {
 $cases{'return_'.$kind} = {owner => 'parse', input => 'foo()', parser_kind => $kind};
}
$cases{retained_child} = {owner => 'parse', input => 'foo()', parser_kind => 'outer'};
my %routes = (parse => {map {$_ => 'attached'} @keys});

sub context { return !defined($_[0]) ? 'void' : $_[0] ? 'list' : 'scalar' }
sub same { return ref($_[0]) && ref($_[1]) && refaddr($_[0]) == refaddr($_[1]) ? 1 : 0 }
sub snapshot {
 my ($state, $value, $visiting) = @_;
 return $value unless ref $value;
 $visiting ||= {};
 my $address = refaddr($value);
 my $id = $state->{ids}{$address} //= 1 + scalar(keys %{$state->{ids}});
 my $result = {id => $id, type => ref($value)};
 return {%$result, cycle => 1} if $visiting->{$address};
 local $visiting->{$address} = 1;
 my $type = reftype($value) || '';
 $result->{items} = [map {snapshot($state, $_, $visiting)} @$value] if $type eq 'ARRAY';
 $result->{value} = snapshot($state, $$value, $visiting) if $type eq 'SCALAR' || $type eq 'REF';
 $result->{fields} = {map {$_ => snapshot($state, $value->{$_}, $visiting)} sort keys %$value} if $type eq 'HASH';
 return $result;
}
sub ordinary {
 my ($state, $key, $args) = @_;
 if ($key eq 'trim_action_ir_value') {
  my $value = $args->[0];
  return $value if $state->{case}{trim_identity} || !defined($value) || ref($value);
  $value =~ s/^\s+//o;
  $value =~ s/\s+$//o;
  return $value;
 }
 if ($key eq 'parse_method_function_expr') {
  return undef if $state->{case}{parser_never};
  my $kind = $state->{case}{parser_kind} || '';
  return undef if $kind eq 'undefined';
  return '' if $kind eq 'empty';
  return '0' if $kind eq 'zero';
  return 1 if $kind eq 'one';
  return 'outer' if $kind eq 'outer';
  return $state->{call} if $kind eq 'hash';
  return $state->{args} if $kind eq 'array';
  return $state->{unrelated} if $kind eq 'code';
  return bless($state->{call}, 'ControlAttachedNative::Call') if $kind eq 'blessed';
  return undef if $state->{case}{decline_attached} && defined($args->[0]) && !ref($args->[0])
   && $args->[0] =~ /\}\s*\z/s;
  require LinkedSpec::ActionIR::MethodExpr;
  return LinkedSpec::ActionIR::MethodExpr::_parse_method_function_expr($args->[0]);
 }
 die "unhandled native probe callback $key";
}

sub observe {
 my ($label, $case_name, $options) = @_;
 my $case = $json->decode($json->encode($cases{$case_name}));
 my $state = {case => $case, input => $case->{input}, ids => {}, calls => [],
  authority => [], effects => [], counts => {}, held => [], returns => [], return_refs => [], args => $case->{parts} || []};
 $state->{input} = $options->{input} if exists $options->{input};
 $state->{call} = {method => $case->{method}, args => $state->{args}};
 $state->{fatal} = bless({label => $label}, 'ControlAttachedNative::Fatal');
 my (%deps, %callbacks);
 my $publish = sub {
  my $builder = LinkedSpec::ActionIR::SourceEmissions::_new_builder($state->{event});
  LinkedSpec::ActionIR::SourceEmissions::_append_generated($builder, 'outer');
  LinkedSpec::ActionIR::SourceEmissions::_finish_emission($builder);
 };
 for my $key (@keys) {
  $callbacks{$key} = sub {
   my $want = wantarray;
   my $incoming = $@;
   my $number = ++$state->{counts}{$key};
   push @{$state->{calls}}, {key => $key, number => $number, context => context($want),
    args => [map {snapshot($state, $_)} @_], incoming_error => snapshot($state, $incoming),
    first_readonly => @_ ? (Internals::SvREADONLY($_[0]) ? 1 : 0) : undef,
    first_is_caller_slot => @_ ? same(\$_[0], \$state->{input}) : 0,
    first_is_argument_array => @_ ? same($_[0], $state->{args}) : 0};
   push @{$state->{held}}, {key => $key, number => $number, slot => \$_[0]} if @_;
   unless ($cold) {
    my $call = $LinkedSpec::ActionIR::SourceEmissions::_call;
    push @{$state->{authority}}, {key => $key, number => $number,
     eligible => LinkedSpec::ActionIR::SourceEmissions::_eligible_call() ? 1 : 0,
     actual_callback => ref($call) eq 'HASH' ? same($call->{callback}, $callbacks{$key}) : 0};
   }
   my $target = defined($options->{key}) && $options->{key} eq $key && $number == ($options->{number} // 1);
   $publish->() if $target && $options->{authority};
   if ($target && ($options->{effect} || '') eq 'mutate') {
    if (ref($_[0]) eq 'ARRAY') { push @{$_[0]}, 'extra' }
    elsif (defined($_[0]) && !ref($_[0])) { $_[0] .= '!' }
    push @{$state->{effects}}, {key => $key, after => snapshot($state, $_[0])};
   }
   if ($target && ($options->{effect} || '') eq 'replace') {
    $deps{$key} = sub { push @{$state->{effects}}, {replacement => $key}; return ordinary($state, $key, \@_) };
    push @{$state->{effects}}, {replaced => $key};
   }
   if ($target && ($options->{effect} || '') eq 'replace_downstream') {
    $deps{parse_method_function_expr} = sub {
     push @{$state->{effects}}, {replacement => 'parse_method_function_expr'};
     return {method => 'replacement', args => []};
    };
    push @{$state->{effects}}, {replaced => 'parse_method_function_expr'};
   }
   $@ = 'successful-'.$key if $target && ($options->{effect} || '') eq 'error';
   die $state->{fatal} if $target && ($options->{effect} || '') eq 'fatal';
   return undef if $target && ($options->{effect} || '') eq 'undefined';
   my $value = ordinary($state, $key, \@_);
   push @{$state->{return_refs}}, $value if ref($value);
   push @{$state->{returns}}, {key => $key, number => $number, value => snapshot($state, $value)};
   return $value;
  };
  $deps{$key} = $callbacks{$key};
 }
 $deps{unrelated} = sub { die 'unrelated ControlFlow dependency invoked' };
 $state->{unrelated} = $deps{unrelated};
 delete $deps{$options->{missing}} if defined $options->{missing};
 $deps{$options->{bad}} = 'not CODE' if defined $options->{bad};
 my $before = {input => snapshot($state, $state->{input}), args => snapshot($state, $state->{args}),
               call => snapshot($state, $state->{call}), map => snapshot($state, \%deps)};
 my $parent = sub {
  if ($options->{context} eq 'list') {
   my @values = $owners{$case->{owner}}->($state->{input}, \%deps);
   $state->{result} = [map {snapshot($state, $_)} @values];
  } elsif ($options->{context} eq 'void') {
   $owners{$case->{owner}}->($state->{input}, \%deps);
   $state->{result} = {context => 'void'};
  } else {
   my $value = $owners{$case->{owner}}->($state->{input}, \%deps);
   $state->{result} = snapshot($state, $value);
  }
  $state->{owner_error} = snapshot($state, $@);
  return 'outer';
 };
 my $work = sub {
  unless ($cold) {
   $state->{event} = {raw => 'origin'};
   LinkedSpec::ActionIR::SourceOrigins::_remember_source_origin($state->{event},
    {event => $state->{event}, source => 'origin', source_span => {start => 0, end => 6}});
   LinkedSpec::ActionIR::SourceEmissions::_register_emission_producer($parent);
   LinkedSpec::ActionIR::SourceEmissions::_register_emission_producer($publish);
   LinkedSpec::ActionIR::SourceEmissions::_register_emission_producer($callbacks{$options->{key}})
    if $options->{known};
  }
  my ($capture, $successful);
  my $ok = eval {
   $@ = 'caller-error';
   if ($cold) { $parent->() }
   else { $capture = LinkedSpec::ActionIR::SourceEmissions::_capture_emission($parent) }
   $successful = snapshot($state, $@);
   1;
  };
  $state->{fatal_result} = snapshot($state, $@) unless $ok;
  $state->{successful_error} = $successful if $ok;
  unless ($cold) {
   $state->{parent_packet} = $capture && $capture->{emission} ? 1 : 0;
   my $registry = $LinkedSpec::ActionIR::SourceEmissions::_producers;
   $state->{child_packets} = scalar grep {
    same($_->{callback}, $callbacks{$options->{key} // ''})
   } values %{$registry->{captures}};
  }
 };
 if ($cold) { $work->() }
 else { LinkedSpec::ActionIR::SourceOrigins::_with_source_origins('origin', sub {
  LinkedSpec::ActionIR::SourceEmissions::_with_emission_producers([], $work);
 }) }
 return {label => $label, case => $case_name, options => $options,
  native => {before => $before, result => $state->{result}, calls => $state->{calls},
   effects => $state->{effects}, held_slots => snapshot($state, $state->{held} || []),
   callback_returns => $state->{returns} || [], returned_references => snapshot($state, $state->{return_refs} || []),
   input_after => snapshot($state, $state->{input}),
   args_after => snapshot($state, $state->{args}), call_after => snapshot($state, $state->{call}),
   map_after => snapshot($state, \%deps), owner_error => $state->{owner_error},
   successful_error => $state->{successful_error}, fatal => $state->{fatal_result}},
  authority => {calls => $state->{authority}, parent_packet => $state->{parent_packet},
                child_packets => $state->{child_packets}}};
}

my @rows;
for my $name (sort keys %cases) {
 for my $context (qw(scalar list void)) {
  push @rows, observe("ordinary/$name/$context", $name, {context => $context});
 }
}
for my $owner (sort keys %required) {
 for my $key (@{$required{$owner}}) {
  my $case = $routes{$owner}{$key};
  for my $number (1 .. ($key eq 'trim_action_ir_value' ? 3 : 2)) {
   for my $effect (qw(mutate replace error fatal undefined)) {
    push @rows, observe("effect/$owner/$key/$number/$effect", $case,
     {context => 'scalar', key => $key, number => $number, effect => $effect});
   }
   next if $cold;
   for my $known (0, 1) {
    for my $context (qw(scalar list void)) {
     push @rows, observe("authority/$owner/$key/$number/$known/$context", $case,
      {context => $context, key => $key, number => $number, known => $known, authority => 1});
    }
   }
  }
  for my $kind (qw(missing bad)) {
   push @rows, observe("validation/$owner/$key/$kind", $case,
    {context => 'scalar', $kind => $key, input => undef});
  }
 }
}
push @rows, observe('selection/parse/replace-downstream', 'attached',
 {context => 'scalar', key => 'trim_action_ir_value', number => 1, effect => 'replace_downstream'});
unless ($cold) {
 for my $known (0, 1) {
  push @rows, observe("retained-child/$known", 'retained_child',
   {context => 'scalar', key => 'parse_method_function_expr', number => 1, known => $known, authority => 1});
 }
}

my @loaded;
for my $path (values %INC) {
 next unless defined($path) && -f $path;
 my $absolute = abs_path($path);
 next unless index($absolute, $root.'/') == 0;
 push @loaded, File::Spec->abs2rel($absolute, $root);
}
my %loaded = map {$_ => 1} @loaded;
print $json->encode({mode => $cold ? 'cold' : 'warm', rows => \@rows,
 loaded_project_modules => [sort keys %loaded], perl_version => "$^V",
 emission_loaded => exists($INC{'LinkedSpec/ActionIR/SourceEmissions.pm'}) ? 1 : 0,
 trace_loaded => exists($INC{'LinkedSpec/Trace.pm'}) ? 1 : 0,
 toolchain_scope => 'System Perl and standard libraries reused read-only; no immutable portable toolchain claim.'}), "\n";
