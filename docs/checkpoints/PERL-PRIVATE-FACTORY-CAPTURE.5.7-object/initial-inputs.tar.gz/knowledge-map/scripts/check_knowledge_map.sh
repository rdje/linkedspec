#!/usr/bin/env bash
# check_knowledge_map.sh — validate Knowledge Map fact files and assert the map is in sync.
#
# Part of the Knowledge Map (KM) bundle. See ../KNOWLEDGE_MAP_ARCHITECTURE.md.
# Exits NONZERO on any violation (wire it into pre-commit + CI). Checks:
#   1. every KM fact (front-matter has `answers:`) carries the required fields
#      (id, title, date, and at least one of evidence/reverify), and block-list
#      items follow a key with an empty value rather than a scalar/inline list;
#   2. fact ids are unique;
#   3. the committed map equals a fresh regeneration (derive-and-diff — no drift possible).
# Portable: POSIX shell + awk (BSD or GNU).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT="$(git -C "$SCRIPT_DIR" rev-parse --show-toplevel 2>/dev/null || pwd)"

[ -f "$ROOT/.knowledge_map.conf" ] && . "$ROOT/.knowledge_map.conf"
[ -f "$SCRIPT_DIR/knowledge_map.conf" ] && . "$SCRIPT_DIR/knowledge_map.conf"
: "${KM_SCAN_DIRS:=docs/knowledge docs/decisions}"
: "${KM_OUTPUT:=KNOWLEDGE_MAP.md}"
: "${KM_ENV_INITIALIZER:=}"
: "${KM_RUN_INITIALIZER:=}"
: "${KM_OUTPUT_VALIDATOR:=}"

if [ -n "$KM_ENV_INITIALIZER" ]; then
  case "$KM_ENV_INITIALIZER" in
    /*) _km_env_initializer=$KM_ENV_INITIALIZER ;;
    *) _km_env_initializer="$ROOT/$KM_ENV_INITIALIZER" ;;
  esac
  [ -f "$_km_env_initializer" ] || {
    printf 'knowledge-map: environment initializer not found: %s\n' "$KM_ENV_INITIALIZER" >&2
    exit 1
  }
  source "$_km_env_initializer"
  unset _km_env_initializer
fi

if [ -n "$KM_RUN_INITIALIZER" ]; then
  command -v "$KM_RUN_INITIALIZER" >/dev/null 2>&1 || {
    printf 'knowledge-map: run initializer not found: %s\n' "$KM_RUN_INITIALIZER" >&2
    exit 1
  }
  "$KM_RUN_INITIALIZER" "$SCRIPT_DIR/check_knowledge_map.sh" "$@"
fi

cd "$ROOT"
fail=0
note() { printf 'knowledge-map: %s\n' "$1" >&2; fail=1; }
warn() { printf 'knowledge-map: WARNING: %s\n' "$1" >&2; }

if [ -n "$KM_OUTPUT_VALIDATOR" ]; then
  command -v "$KM_OUTPUT_VALIDATOR" >/dev/null 2>&1 || {
    printf 'knowledge-map: output validator not found: %s\n' "$KM_OUTPUT_VALIDATOR" >&2
    exit 1
  }
  "$KM_OUTPUT_VALIDATOR" "$KM_OUTPUT" "Knowledge Map output"
fi

ids_file=""; tmpmap=""
cleanup() { [ -n "$ids_file" ] && rm -f "$ids_file"; [ -n "$tmpmap" ] && rm -f "$tmpmap"; }
trap cleanup EXIT
ids_file="$(mktemp)"; tmpmap="$(mktemp)"

# --- 1 + 2: per-file required-field validation; collect ids ---
for d in $KM_SCAN_DIRS; do
  [ -d "$d" ] || continue
  while IFS= read -r f; do
    res="$(awk '
      BEGIN { infm=0; started=0; hasans=0; anskey=0; curkey=""; orphan="" }
      NR==1 { if ($0 ~ /^---[ \t]*$/) { infm=1; started=1; next } }
      infm==1 && $0 ~ /^---[ \t]*$/ { infm=0; next }
      infm==1 {
        if ($0 ~ /^[ \t]+-[ \t]+/) {
          if (curkey=="") orphan=orphan (orphan!="" ? ", " : "") NR
          if (curkey=="answers") hasans=1
          next
        }
        if (match($0, /^[A-Za-z_][A-Za-z0-9_]*:/)) {
          key=substr($0,1,RLENGTH-1); rest=substr($0,RLENGTH+1)
          gsub(/^[ \t]+/,"",rest); gsub(/[ \t]+$/,"",rest)
          curkey=(rest=="" ? key : "")
          if (key=="answers") anskey=1
          if (key=="answers" && rest ~ /\[.*[A-Za-z0-9].*\]/) hasans=1
          if (key=="id")       { gsub(/^"|"$/,"",rest); vid=rest }
          if (key=="title")    okt=1
          if (key=="date")     okd=1
          if (key=="evidence") oke=1
          if (key=="reverify") okr=1
        }
        next
      }
      END {
        # Keep malformed answers-plus-list headers visible to validation even
        # though their detached items cannot constitute a valid answers list.
        if (!started || (!hasans && !(anskey && orphan!=""))) { print "NOTFACT"; exit }
        miss=""
        if (vid=="") miss=miss " id"
        if (!okt)    miss=miss " title"
        if (!okd)    miss=miss " date"
        if (!oke && !okr) miss=miss " evidence-or-reverify"
        print "FACT\t" vid "\t" miss "\t" orphan
      }
    ' "$f")"
    case "$res" in
      FACT*)
        vid="$(printf '%s' "$res" | cut -f2)"
        miss="$(printf '%s' "$res" | cut -f3)"
        orphan="$(printf '%s' "$res" | cut -f4)"
        [ -n "$vid" ] && printf '%s\t%s\n' "$vid" "$f" >> "$ids_file"
        [ -n "$(printf '%s' "$miss" | tr -d ' ')" ] && note "$f: KM fact missing required front-matter:$miss"
        [ -n "$orphan" ] && note "$f: KM fact front-matter orphan list item at line $orphan (requires a key with an empty value)"
        ;;
      *) : ;;  # NOTFACT or empty — ignore non-fact markdown
    esac
  done < <(find "$d" -type f -name '*.md' 2>/dev/null | LC_ALL=C sort)
done

if [ -s "$ids_file" ]; then
  dups="$(cut -f1 "$ids_file" | LC_ALL=C sort | uniq -d || true)"
  [ -n "$dups" ] && printf '%s\n' "$dups" | while IFS= read -r dd; do
    [ -n "$dd" ] && note "duplicate fact id: '$dd' (ids must be unique across all scanned dirs)"
  done
  # surviving fail-state from the subshell above is lost; re-detect:
  [ -n "$dups" ] && fail=1
fi

# --- 3: map-in-sync (derive-and-diff) ---
if KM_OUTPUT="$tmpmap" bash "$SCRIPT_DIR/gen_knowledge_map.sh" >/dev/null 2>&1; then
  if [ -f "$KM_OUTPUT" ]; then
    if ! diff -q "$KM_OUTPUT" "$tmpmap" >/dev/null 2>&1; then
      note "$KM_OUTPUT is OUT OF SYNC with the fact files — run knowledge-map/scripts/gen_knowledge_map.sh and commit the result"
    fi
  else
    note "$KM_OUTPUT does not exist — run knowledge-map/scripts/gen_knowledge_map.sh and commit it"
  fi
else
  note "gen_knowledge_map.sh failed to run"
fi

[ "$fail" -eq 0 ] && printf 'knowledge-map: OK (facts valid, ids unique, map in sync)\n' >&2
exit "$fail"
