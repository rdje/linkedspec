# Post-Parity Structured-Text Program

LinkedSpec's next product program after current backend parity is a library of strong, accurate, fast,
Unicode-aware text-to-AST parsers. The initial scope is the 91 eligible rows in the project's structured-text
catalog: general configuration formats, documents and markup, RDF/graph syntaxes, schema and interface languages,
feeds and messaging text, geospatial text, and domain-specific JSON/XML/YAML serializations.

This work has two readiness requirements: `.spec` must express the selected parsing objectives clearly without
routine host-language escape hatches, and Perl, Rust, Dart, Julia, and Lua must have the required feature and
behavior parity. The broad campaign is not active. Planning it does not make any format currently supported or
relax an open backend obligation.

## Strengthen `.spec` before the campaign

The September 2026 priority is ordinary `.spec` expressiveness. The long-term ambition is parsing power comparable
to grammar-oriented tools through LinkedSpec's linked rules, explicit cursor control, captures and transformations.
That is a design goal, not a current equivalence claim. An optional EBNF-like frontend remains a separate later step.

The language already has admitted foundations for selecting and linking rules, composing seek/consume policies,
recognition-only transactions, Unicode source spans and lossless gap capture. Their neutral checks pass, but a
green feature inventory does not prove a difficult grammar is correct or pleasant to author. Known defects remain
tracked, including Perl's unfinished-recognition abort restoring private state without restoring the caller's
input cursor. That limitation must be resolved before relying on abort-safe speculative parsing.

Readiness work uses small representative objectives before committing to entire standards:

| Objective | What the evidence must show |
| --- | --- |
| Nested document grammar | Exact ASTs and source spans, malformed-input and trailing-text rejection, and advancing recursion. |
| Context-dependent syntax | Clearly scoped delimiter or indentation state, correct nested restoration, and useful rejection diagnostics. |
| Lossless extraction and child parsing | Exact prefix/interstitial/tail reconstruction, bounded child inputs, retained provenance and explicit dispatch authority. |

These bounded composition probes do not establish supported formats or confirmed missing primitives. If a probe
fails, its tools and minimized input must distinguish grammar mistakes, engine defects, missing general mechanisms,
and awkward authoring. The result then selects a bounded implementation slice with portable semantics and tests.

Recognition rollback covers cursor, boundaries and marks; it does not undo arbitrary AST or user-variable writes.
For example, a grammar that tentatively builds an AST must separate recognition from committed construction or
establish a different, explicitly accepted mechanism. Merely adding alternate syntax would not solve that requirement.

The owning task is `SPEC-LANGUAGE-SELF-CONTAINMENT.1.1`; its first inventory records existing contracts and exact
backend consumers. The state/control/result inventory is also recorded. Bounded nesting, context-name matching and
lossless actual-child composition are reconciled across Perl, Rust, Dart, Julia and both Lua ABIs. The comparison
below preserves each objective's authoring costs and limits. The finite gap review now routes those observations
to existing repairs, closure definition and further composed objectives.
The format program's `.1` readiness gate remains pending. The original catalog and parked language extension retain
all their conformance, Unicode, diagnostics, performance and backend obligations.

For the lossless objective, the parent must retain both recognized items and the exact text between them. An
extraction grammar can preserve malformed candidates as gap text; preserving all input does not by itself mean
the input is a valid document. Readiness proof therefore compares item/gap classification, scalar spans and exact
reconstruction separately.

Child composition uses the existing public exact `parse_job(...)` assignment on source-bound item text.
The caller supplies an already-compiled child grammar and frozen authority; the child grammar performs recognition.
The annotation cannot use `gap_text()`, copied strings or an arbitrary span as its text operand. The private
`dispatch_span(...)` intrinsic has a separate authority contract and is not a public helper. The Perl proof below
retains original item text beside child results and tests child rejection, source provenance and unauthorized
identity selection. Equivalent Rust, Dart, Julia, PUC Lua and LuaJIT proof is described below.

The state inventory distinguishes three existing forms that a grammar author can compose:

| Form | State and execution boundary |
| --- | --- |
| User function | Explicit positional/final-rest arguments and fresh function-local state; ordinary typed return values. No implicit caller capture or recursive function calls. |
| Callable block | Deferred construction, temporary copied parameters and invocation-time caller state for other bindings; block-local return. No lexical environment is captured. |
| Linked grammar rule | Recognition, cursor, capture and lifecycle behavior; advancing rule recursion is separate from function recursion. |

Typed bindings, lazy controls, structural writes and leaf transformations supply further building blocks. They
need composition proof: a logical helper's eager operands differ from a selected control branch, and a receiver
mutation's atomic publication does not roll back effects on other bindings. Known mixed-control and mutation-guard
defects remain repair obligations. Numeric AST tests must also distinguish JSON numbers from numeric-looking
strings; value equality alone can hide an incorrect result kind.

Named user-function arguments remain an approved, parked direction. Recording this limitation does not make
that syntax current or prove it is the next feature the format campaign needs.

### What the three probes establish together

The ordinary language composes all three finite objectives with the existing primitives. Nesting and context-name
matching require strict document acceptance; lossless extraction preserves malformed candidates as gaps. Their
successes answer different questions and cannot be combined into a whole-format conformance claim.

| Probe | Independently authored inputs | Proven composition | Remaining authoring work |
| --- | --- | --- | --- |
| Nesting | 6 accepted / 7 rejected | Advancing recursion, restored parent state, exact typed trees and Unicode spans | Explicit prefix/gap/end/missing-close guards and AST/span constructors; one rejection status |
| Context names | 11 accepted / 17 rejected | Opening capture, lexical comparison, recursive state restoration and three typed statuses | The same strictness guards; messages, failure spans and in-document repair need further proof |
| Lossless / actual child | 13 segment cases / 39 segments; child 4 accepted / 15 rejected | Exact item/gap classification and reconstruction; source-bound staged requests to a real compiled child | Skipped-prefix retention, correct loop/LX lifecycle, strict child entry/end guards and caller-prepared registry/provenance |

Carrier routes repeat these inputs. Retained parsers demonstrate immediate success after typed rejection; entries
that create an engine per call demonstrate isolation. Neither establishes repair inside a failed document.
The detailed route and mutation tables below preserve those distinctions. Actual child recognition lives in the
child `.spec`; the caller supplies frozen compiled authority and projects its span. The public staged operand
exclusions and private `dispatch_span` boundary remain unchanged.

No missing primitive is selected by these successes. Explicit guard work and limited diagnostics are concrete
costs for the next requirement review. Indentation, quoted/escaped text, realistic complete standards, resource
safety, performance and speculative AST/user-state rollback remain unassessed by these probes. Known engine,
provenance, accounting, result and documentation defects retain their repair owners. The format campaign and
optional alternate frontend remain gated until their own requirements are met.

To verify the committed evidence without rerunning every runtime, use:

```sh
bash tools/run_python_project_data.sh tests/language-readiness/verify_objectives.py
```

This audit checks historical checkpoint/source/log identities and independently slices the original authored
oracles. It rejects executable drift and controlled corrupted evidence. Its output describes historical runtime
proof, with current evidence integrity; it does not claim a fresh six-runtime execution. The commands below
rerun the individual runtime proofs when their inputs change.


### What the finite gap review selects

All nine areas have existing contracts or bounded evidence: grammar, recursion, cursor, capture, state,
callables, control, transformation and results. No new missing parsing primitive follows from the three
successful probes. The review keeps narrower engine and proof defects with their existing repair owners;
explicit guards and AST/span construction remain concrete authoring work.

| Finding | Consequence for the next work |
| --- | --- |
| Existing primitives express the finite probes | Define closure using their actual scope, including intrinsic rule cursor policy, advancing recursion and recognition-only rollback. |
| Recognition abort, mixed controls, mutation guards, numeric kinds and staged boundaries have open repairs | Repair and reverify an affected boundary before extending a claim that depends on it. Successful bounded workarounds do not close broad defects. |
| Caller supplies precompiled child authority and span projection | Keep recognition in `.spec` and authorization at the caller boundary; no ambient parser loading follows. |
| Diagnostics, indentation, quoted/escaped text and richer transformation objectives need composition proof | Select small independent positive/negative oracles before claiming support or proposing a primitive. |
| Arbitrary depth, regex resources and performance remain unassessed | Describe measured bounds precisely and verify resource repairs; finite success supplies no universal guarantee. |

Named fixed-parameter arguments remain an approved, parked feature. Their absence does not establish a
prerequisite for this campaign. Lexical closures, recursive user calls, arbitrary user-state rollback and
new staged operands likewise need an agreed objective before a semantic extension is selected.

The capability census now describes explicit entry selection and intrinsic family cursor policy accurately;
its stable historical ID does not grant a global parse-mode override. Fifteen reason-sensitive mutations bind
that row to the existing root-selection and cursor authorities. The closure plan now binds sixteen existing
authorities and separates authored work, state/effects and caller responsibilities:

| Authored work | Boundary the closure contract must preserve |
| --- | --- |
| Compute and recognize | Typed expressions, distinct pure-function/deferred-block scopes and linked rules whose children own cursor policy. |
| Observe and mutate | Authorized source-bound captures and scoped state; recognition restores cursor/boundary/marks, while structural publication preserves its own completed effects. |
| Return and diagnose | Typed payloads remain separate from match booleans and failure projections; optional caller diagnostic sinks receive ordered events, and absent sinks are quiet. |
| Compose parsers | Caller freezes compiled authority; each child receives fresh state and narrowing operational grants. Child work does not establish parent cursor progress. |
| Bound work | Existing scoped progress/resource policies and known repairs precede guarantees; finite accounting supplies no global numerical or regex-preemption bound. |

The operation/scope freeze, deterministic/resource/failure freeze and independent reconciliation are separate
steps before new composition objectives. The scoped policy review distinguishes ordinary guards from active
recognition/observation and owner-specific error channels. Raw host fallback and compatibility behavior do not establish portable closure or
sandbox security. Existing dynamic callback, token, boolean-kind and resource defects retain their owners and
prerequisites. Neutral fixtures then distinguish selected dimensions with independent value/effect/failure
oracles and mutations. Only demonstrated reusable gaps become implementation leaves. The format campaign and
optional EBNF-like frontend retain their separate gates.

The versioned definition is `capability_conformance/language_closure_contract.json`
(`linkedspec-language-closure-v1`). Its structure and scoped policies bind sixteen existing
authorities through 90 semantic anchors, retaining all 66 original bindings. Seven authored categories cover computation, recognition, observation,
mutation, return, diagnostics and parser composition; caller authority is a separate boundary. Eight scopes
keep rule invocation, pure functions, deferred blocks, recognition attempts, recursive observations, nested
writes, leaf transformation and child parsing distinct.

Definition reconciliation preserves the original 66 bindings and all 90 policy anchors.
Structural closure is complete; composed objective execution remains pending.
Known repair prerequisites remain mandatory before dependent promotion.
This closeout establishes no new runtime admission or sandbox guarantee.
The separate evidence audit compares committed baselines, matrix rows, static checker
registers, repair-task bytes and rendered claims; it does not execute an authored grammar:

```sh
bash tools/run_mdbook_local.sh
bash tools/run_python_project_data.sh tests/language-readiness/verify_closure_definition.py
```

For example, rolling back recognition restores its cursor, boundary and marks. A nested write instead evaluates
its segments and value before taking the publication snapshot; a later structural failure preserves completed
expression effects. A deferred block sees live caller nonparameters when invoked, while a pure function starts
with fresh local state. An output event goes to an optional caller sink, with quiet execution when none is installed.
These differences must survive composition; listing their mechanisms does not close known narrower defects.

```sh
bash tools/run_python_project_data.sh tools/check_language_closure_contract.py
```

This check validates definition structure, exact source bindings and producing/repair ownership. Selected anchors
use SHA-256 over sorted compact UTF-8 JSON with literal Unicode; unrelated historical rollout metadata is excluded.
Reason-sensitive mutations challenge every declared category and scope, source drift and CI registration.
The checker does not execute a `.spec` or establish a new composed objective. Independent definition reconciliation is complete. Composed execution and
runtime objective admission remain pending; runtime admission,
whole-format readiness and the optional frontend have not advanced through this definition alone.

### Selected compositions and their current limits

The next bounded proof has nine diagnostic cases and seven parsed-pair normalization cases.
The original nesting, context-name and lossless/child probes retain their source and evidence.
These new cases select independent expectations before neutral fixtures and backend execution.
They do not admit a complete format or close existing repair prerequisites.

The diagnostic example recognizes one lowercase ASCII word and supplies explicit start/end/fallback
guards. Its immediate arguments record `left`, then `right`; rich output goes to the caller's sink:

```text
Top::
 -> Word {
   if(num_ne(match_start_pos(), 0)) { exit_now(1) }
   if(num_ne(match_end_pos(), input_end_pos())) { exit_now(1) }
   effects = []
   print({ push(effects, "left"); return("begin:") },
         { push(effects, "right"); return(match_text()) })
   if(str_eq(match_text(), "stop")) { say("stop"); exit_now(7) }
   print_each(["α", undef, [], "🙂"], "part:", "!")
   say("done")
   return({ "word": match_text(), "effects": copy(effects), "payload": false })
 }
LX { exit_now(1) }

Word:
 /([a-z]+)/
```

For `go`, the result is `{"word":"go","effects":["left","right"],"payload":false}`.
The six event messages are `begin:go`, `part:α!`, `part:!`, `part:!`, `part:🙂!`, then
`done\n`. No sink preserves the result and effects with zero delivery. `stop` delivers
`begin:stop`, then `stop\n`, and raises typed exit7 before later work. A caller error on
delivery2 remains that identical error and stops later delivery. Invalid prefix and empty input
exit1 before output. These are fresh Perl pilots; other selected cases and backend lanes remain pending.
They establish controlled diagnostics, rather than richer expected-token or recovery support.

The normalization objective parses `ab-cd`, constructs a nested harray, then invokes a deferred
callback and pure registered function during leaf transformation. The invocation-time prefix is
`new:`, the temporary text parameter restores `outside`, and a later nested write adds count2
without changing the detached mapped result or original. Its independent expected result is:

```json
{
  "tree":{"a":"new:AB","b":{"c":"new:CD"},"meta":{"count":2}},
  "mapped":{"a":"new:AB","b":{"c":"new:CD"}},
  "original":{"a":"ab","b":{"c":"cd"}},
  "seen":["ab","cd"],"text":"outside","visits":2
}
```

The call-form normalization now passes all seven selected cases on native and fresh emitted Perl.
The original frozen source remains historical evidence: `while(i < count(pieces))` and its infix increments
retain host text without lowering and fail at the undefined host `count` function. Arithmetic and comparison
use calls such as `num_lt(i,count(pieces))` and `num_add(i,1)`. Source correction `.1.3.3.0.4.1` binds an explicit
successor with only that loop changed; it preserves the original source and all sixteen selected case oracles.
The valid `x,y` callback-literal prerequisite is repaired at its lexical boundary below. Attached-control,
residual-event-order and nested raw-expression readiness gaps retain their independent owners.
The complete requirements and mutation/oracle plan are in
`docs/language-readiness/composed-objective-selection.md`; no new primitive or syntax is selected.

#### Callable signature pipes in Perl action splitting

Perl protects the exact `{|` opener and its matching signature pipe before host quote recognition.
The signature closes even when its final fixed/rest parameter is named `y`, `tr`, `s`, `q`, `qq`,
`qx`, `qr`, or `m`. Once it closes, ordinary body strings, regexes, nested literals and host quote
lexing resume. Callable records retain their eight fields, signatures, authored source and spans.

```spec
Top:: I { cb={|x,y| return(x) }; return(cb("ok","unused")) }
```

This returns `ok`. The rest-parameter twin preserves the same result:

```spec
Top:: I { cb={|x,...q| return(x) }; return(cb("ok","unused")) }
```

Nested callable bodies retain their own signature boundaries:

```spec
Top:: I {
  cb={|x,y| nested={|s,q| return(s) }; return(nested(x,y)) };
  return(cb("ok","unused"))
}
```

Before the repair, the splitter read the final `y|` as host transliteration, merged the following
return and left raw invalid literal text in generated Perl. Standalone literal parsing was correct,
and ready1/raw0/fallback0/unresolved0 metadata could still accompany compilation failure.
`.0.2.1.3.0` retains its exact diagnosis/intervention/restoration. `.0.2.1.3.1` retains twenty unchanged
native/fresh emitted sources, exact old-Core restoration and re-applied proof: nineteen return `ok`.
The additional attached-`if` source historically loaded after the pipe fix but raised typed
`unsupported_codeblock_actionir`/`control_if` on both routes. `.0.5.1` now repairs that attached
statement boundary; its exact earlier failure remains in the original captures.
Residual unmatched-helper descriptor events can also change order across controlled process hash seeds
while selected lowered code stays identical. `.0.6` owns ordering/overlap and readiness diagnosis;
the snapshots preserve each observed order. Neither defect is waived by the healthy pipe controls.

### Governed fixtures and bounded Perl normalization

The sixteen selected cases now have frozen sources and independent expected observations in
`capability_conformance/composed_objective_contract.json` (`linkedspec-composed-objectives-v1`).
The selected sources are `tests/language-readiness/composed/diagnostic.spec`,
`tests/language-readiness/composed/normalization-calls.spec` and an isolated
`tests/language-readiness/composed/diagnostic-invalid-arity.spec`. The closed correction record binds
the original `normalization.spec`, its successor and their exact one-loop difference. Original probes,
selection/checkpoints, sixteen oracles and closure semantics stay unchanged.

```sh
bash tools/run_python_project_data.sh tools/check_composed_objective_contract.py
```

The checker independently builds ASCII word/pair, shape and event expectations without evaluating the DSL.
It rejects152 structural,16 observation and44 producer-report corruptions, with two unrelated-error and two
strict-JSON controls. It distinguishes boolean false from numeric0, rich events from returned values,
quiet evaluation from omitted effects, typed exit from caller failure, and arity rejection from argument work.

A private producer report preserves native failure evidence and compile/runtime phase beside portable
observations. Serialized flags cannot establish native error classification, identity or actual-object
detachment by themselves. Backend lanes must execute public producers, mutate the actual returned objects,
and reject deliberately aliased controls. They must pass a healthy baseline before semantic mutants count.
The default checker executes no DSL and changes no runtime admission. The bounded Perl registered-function
bridge is implemented and the literal signature prerequisite is repaired. Seven paired normalization cases pass;
Canonical bridge reconciliation is complete. Deferred conditional execution, residual-event-order and
nested raw-expression readiness prerequisites remain before complete neutral execution. `docs/language-readiness/composed-objective-governance.md`
records the oracle and evidence boundary. Whole formats and unassessed requirements remain pending.

The complete call-form normalization source is:

```spec
{{#include ../../../../tests/language-readiness/composed/normalization-calls.spec}}
```

`map_leaves!` invokes the callback with a temporary `text` parameter and the caller's live `prefix`.
The callback records each original leaf, calls pure `decorate`, then publishes a detached mapped result.
The later `tree.meta.count` write changes the tree while preserving `mapped` and `original`; `text` restores
to `outside`. For `ab-cd`, the full returned value is the JSON shown above, and the ordered messages are
`leaf:ab!`, `leaf:cd!`, then `done:2\n`.

| Input / sink | Result and delivery |
| --- | --- |
| `ab-cd`, collecting | `new:AB` / `new:CD`, original `ab` / `cd`, three ordered messages. |
| `AB-cd`, collecting | Same normalized leaves; original `AB` / `cd` and matching leaf messages. |
| `x-y`, collecting | `new:X` / `new:Y`, original `x` / `y`, three ordered messages. |
| `ab-cd`, absent | Same complete value, zero delivered events. |
| `!ab-cd`, `ab-cd!`, or empty | Typed exit1 before value or delivery. |

```sh
bash tools/project_data_run.sh env PERL5LIB= prove -Iperl t/composed_normalization_perl.t
```

The regression passes21 top-level tests. For four accepted cases on each route, it mutates the actual returned
tree at root and nested leaves, checks that mapped/original objects remain unchanged, then deliberately aliases
the actual tree to `mapped` and confirms that the same predicate detects the alias. A JSON consumer copy cannot
replace these eight object controls. Complete diagnostic/normalization execution and the sixteen runtime semantic
mutation roles remain a separate lane; other backends are not admitted by this bounded Perl proof.

Historical objective-audit integrity is separate from fresh-checkout recovery. The original hash capture
verified134 retained local logs while leaving their byte recovery open. `.0.4.2.1` now closes recovery for
that exact selected population through a tracked archive and isolated proof. The historical runtime
observations and seven-case normalization proof retain their original scope.
Normalization review controls recover their required audit metadata from the tracked checkpoint and run
without the historical logs or an ignored intermediate report. Those controls recovered metadata;
the original log bytes required their own recovery proof.

The bounded census reconstructs the original nesting/context/lossless populations
(48/39/47 entries) and verifies all 134 old hashes. They total 84,613,241 bytes.
The 24 selected checkpoints contain
no complete log identity among their whole bytes, UTF-8 strings or joined string
arrays. Other encodings and archival surfaces remain unassessed. The implemented
closed ZIP/manifest retains opaque bytes in 3,406,206 bytes, restores into a newly
created repository-volume directory and runs the historical audit while denying
reads of the original logs. Every restored size/hash matches; regeneration from
those restored bytes is byte-exact. No historical runtime result is replaced.

Validate without writing, or explicitly restore into an unused directory:

```sh
bash tools/run_python_project_data.sh tests/language-readiness/recover_objective_audit_inputs.py
bash tools/run_python_project_data.sh tests/language-readiness/recover_objective_audit_inputs.py --restore .linkedspec-data/scratch/objective-artifact-recovery/manual-review
```

Validation reports134 inputs/84,613,241 bytes. An existing destination, traversal or
symlink is rejected before restoration. ZIP member names never become extraction
paths; the independent closed manifest supplies the original relative identities.
The recurring proof exercises22 actual recovery rejections, four audit input/two
path controls and15 CI/six storage/three Phase0 governance mutations. Its deliberate
read/write probes test the guards; the subsequent healthy replay makes zero original
log reads and zero tracked writes. Bridge reconciliation and complete composed
execution remain separate tasks.

### Deferred push on Perl

Perl deferred codeblocks can now append to a caller's live array binding using the existing
`push(name, value)` operation. An absent or null target becomes an array; an incompatible value retains
the existing `binding_kind_mismatch` diagnostic. Operands evaluate once before the update snapshot.
Each push publishes a new array, so a saved earlier result remains unchanged:

```spec
Top:: I {
  seen = []
  append = {|text| return(push(seen, text)) }
  first = append("a")
  second = append("b")
  return([first, second, seen])
}
```

This returns `[["a"], ["a", "b"], ["a", "b"]]`. Nonparameters such as `seen` use caller slots at
invocation time. Parameters use copied values in separate temporary slots; caller values and reference
mappings restore on both success and failure. Mutating an array parameter therefore leaves its input
argument and a same-named caller binding unchanged.

An explicit invocation context preserves `push(rule, destination)` priority for two bare identifiers,
including nested codeblock calls and `.with()` invocation. The plain eight-field codeblock record gains
no closure or captured environment. The receiver guard checks the actual destination scalar identity:
appending to an active `map_leaves!` receiver fails even through an alias, while a same-named temporary
parameter remains independent and writable.

The bounded regression has17 sources on native Perl and a fresh emitted process,147 top-level tests
with23 nested actual-reference/failure-restoration assertions. At that push-repair boundary the original seven controls had six
successes and one registered-function failure. The normalization fixture then stopped at `decorate`;
its complete neutral execution and semantic mutations remain pending. Existing assignment-guard,
caller-function-shadowing, boolean-kind and regex/numeric callback repairs remain separate.

```sh
bash tools/project_data_run.sh env PERL5LIB= prove -Iperl t/codeblock_push_composition_perl.t
```

### Pure-function callback scope on Perl

A pure function has fresh parameters and working variables. A callback invoked inside that function
resolves nonparameters in the function frame; it has no implicit access to the outer rule:

```spec
fn apply(callback: codeblock) { return(callback()) }
Top:: I {
  secret = "outer"
  cb = {|| return(secret) }
  return(apply(cb))
}
```

This returns null on Perl native Get and fresh emitted execution. Declaring `secret="local"` inside
apply makes the callback read `"local"`. Writes to a function's declared local or parameter update
that actual function slot, while the outer rule's same-named slot remains unchanged. Callable lookup
also uses function locals and parameters; an unbound function call cannot borrow a rule's callback.
It retains the existing unresolved-helper diagnostic and is not claimed ready.

A callback can create a working slot absent from the function's source. That slot persists across
callbacks within one invocation, then resets on the next function invocation:

```spec
fn collect(callback: codeblock) {
  first = callback("a")
  second = callback("b")
  return([first, second])
}
Top:: I {
  items = ["outside"]
  append = {|text| return(push(items, text)) }
  first = collect(append)
  second = collect(append)
  return([first, second, items])
}
```

This returns `[[["a"], ["a", "b"]], [["a"], ["a", "b"]], ["outside"]]`.
The two function invocations have independent working slots. Within each invocation, push still
publishes a new array, so the saved first result stays `["a"]`. Nested function calls get separate
frames too. Callback parameters remain copied temporary slots and restore function-slot mappings
on success or failure. `.with()` temporarily exposes its invocation value and restores a function's
same-named `value` slot even when the callback fails.

The combined regression now executes 33 exact native/fresh emitted sources and 279 top-level tests,
including 23 original push identity assertions, 17 actual function-frame/slot assertions and four
callable-diagnostic checks. A deliberately aliased frame control fails the same identity observation.
Plain callable records retain eight fields with no closure or stored environment. The earlier scope
leak is corrected under `.1.3.3.0.2.0.1`; existing argument/local-name shadowing remains separately
owned by startup32. Scope prerequisite `.0.2.0.2` closes this repair under canonical acceptance.
The registered-function bridge below extends the combined regression to 71 sources and 605 tests;
full normalization execution remains subject to source correction and the separately owned control/metadata prerequisites.

### Determinism, progress and failure boundaries

Determinism fixes the canonical program/versions, decoded source/identity, explicit values/options,
initial authorized state, frozen registry and effective grants. Cancellation, deadline, remaining budget
and sink behavior are operational inputs. A cancelled run and an uninterrupted run need not produce the
same outcome. Authored code gains no clock or transport authority through those caller observations.

Progress is scoped. Active recognition/observation requires strict cursor advance on accepted repeated
or recursive work, while one-shot zero-width recognition can succeed. Ordinary recursion has a separate
same-rule/same-position cutoff; its selected Perl public probe returns null with null `last_error` and a
trace decision. A child parse does not advance the parent cursor. These distinctions do not select one
global threshold or prove unrestricted termination.

Inherited child limits narrow authority through intersections and stricter minima. Calculated effective
metadata is separate from actual enforcement. Progressive limits/source detail, staged counters and
diagnostic bytes retain known repair owners; Dart lexical helpers retain a supplementary-character order
exception. Dependent guarantees require their repairs and recurrence. No regex preemption, hard wall-clock
bound, global number or performance envelope is inferred.

Failure effects follow the operation:

| Example | Publication / effect boundary |
| --- | --- |
| Recognition rolls back a candidate | Restore cursor, boundary and marks, without general AST/user-state rollback. |
| A nested write evaluates its key/value, then rejects the structural path | Preserve completed expression effects from the post-expression snapshot. |
| A leaf callback fails after an unrelated write | Withhold receiver publication while preserving the unrelated effect. |
| A continuation fails | The receiver was already committed; the later failure does not undo it. |
| A staged child fails | `fail` aborts; `keep_text` materializes original text with a sidecar diagnostic; `diagnostic_node` publishes its selected detached diagnostic node. |
| A caller sink fails | Propagate that failure unchanged and stop later evaluation or delivery. |

Typed diagnostics, `last_error`, native exceptions, diagnostic-aware results and legacy text adapters retain
their own APIs; null results and trace are not universal failure schemas.
[Runtime semantics](../appendix/runtime-semantics.md#9-zero-progress-guard) explains the public channels.

The preferred portable policy excludes authored filesystem, process, network, environment, clock,
randomness, package-loading and FFI effects. Callers still authorize input, compilation, registries,
transports and sinks. Path-like parsed strings, identities, spans and markers grant no loading authority.
Compatibility exclusions and finite portable evidence are not default ambient-isolation or sandbox proof.

### Bounded nesting trial

This readiness grammar parses zero or more parenthesized lists containing bare atoms or other lists. It accepts
ASCII whitespace between forms and records half-open Unicode scalar spans. It has no quoted-string syntax,
escape processing, comments or standard-format conformance claim; quote characters are ordinary atom characters.
A bare atom at document level, an unmatched parenthesis, or other text outside the lists is rejected with
`exit_now(1)`. The explicit prefix guard also rejects text that entry preprocessing might otherwise skip.

```text
{{#include ../../../../tests/language-readiness/nested-tree/grammar.spec}}
```

For `(a (β) c)`, the result is:

```json
[{"kind":"list","span":[0,9],"items":[
  {"kind":"atom","span":[1,2],"text":"a"},
  {"kind":"list","span":[3,6],"items":[{"kind":"atom","span":[4,5],"text":"β"}]},
  {"kind":"atom","span":[7,8],"text":"c"}
]}]
```

Recursive rule calls restore the enclosing list's `start` and `items` bindings. The two constructor forms
`hash("span", [start, cursor_pos()])` and `{"span":[start, cursor_pos()]}` must preserve the same bound values.
The trial exposed and repairs a Perl constructor lowering defect; the original expected spans remain unchanged.
The bounded native proof passes the same six accepted and seven rejected inputs on Perl, Rust, Dart, Julia,
Lua and LuaJIT, including CRLF and a supplementary Unicode character. Each public-loaded engine returns exact
ASTs and spans for twelve accepted parses. The Perl proof also covers fresh-process emitted parsers, five-rule ActionIR readiness and immediate recovery after each typed rejection. Prefix/gap/span mutations demonstrate sensitivity to each claimed boundary.

The bounded nesting objective now has carrier evidence on all six runtimes:

| Runtime | Carrier routes | Retained parsers | Rejection-to-success transitions on retained parsers |
| --- | ---: | ---: | ---: |
| Perl | 2 | 2 | 28 |
| Rust | 6 | 4 | 56 |
| Dart | 6 | 4 | 56 |
| Julia | 5 | 2 | 28 |
| PUC Lua | 5 | 2 | 28 |
| LuaJIT | 5 | 2 | 28 |

Each route runs the same 13 authored cases in a 40-call sequence and detects three deliberate grammar mutations.
These counts show repeated use and coverage of particular boundaries, not a large conformance corpus. Every
carrier rejection must have typed status1; a successful null-like return cannot count as rejection.

The 33-line grammar illustrates both expressive power and authoring cost. Recursion and rule-local bindings
express the tree directly, and explicit constructors make its AST and spans visible. Strict document acceptance
needs several guards: reject skipped prefix text, reject gaps through both `Invalid` edges, check the final
cursor, and reject an unfinished list at its end. For example, removing the prefix guard admits `#skip\n(a)`;
removing the two catch-all edges admits interstitial junk. Replacing a list's saved start with the final cursor
changes its span to `[9,9]` for `(a (β) c)`, which the original `[0,9]` oracle detects.

This grammar reports typed rejection but does not explain a missing close versus stray text with distinct
messages. Starting another parse after rejection is also different from recovering inside the same document.
Neither this trial nor its line count establishes arbitrary-depth safety, performance, speculative AST rollback,
or format conformance. No new primitive was needed for this bounded objective; the completed context-dependent
and lossless probes below supply the other bounded evidence for general language-gap selection.

To repeat a prepared runtime's public-loader check, run from the repository root:

```sh
bash tools/run_python_project_data.sh tests/language-readiness/nested-tree/verify_native.py --runtime rust
```

Replace `rust` with `perl`, `dart`, `julia`, `puc` or `luajit` for the other routes. Prepare the selected example
using its [public integration guide](../public-api/integration.md). The text adapters stop at the first rejected
input; this check does not establish same-engine recovery after rejection. Rust's adapter prints its error as
text, while the others preserve typed JSON.

A separate Rust regression covers native and JSON-reconstructed engines, generated-plan execution, serialized
v2 execution and freshly compiled emitted modules. All six routes preserve the same values, JSON kinds and
Unicode spans, reject malformed inputs with typed status1 exits, and detect prefix/gap/span grammar mutations.
Four routes retain their engine across 14 rejection-to-success transitions each; the serialized and emitted entry
functions construct an engine per call, so their subsequent successful calls do not prove retained-engine recovery.
Run this proof with:

```sh
bash tools/run_cargo_local.sh test --locked --offline --manifest-path rust/Cargo.toml \
  -p linkedspec-runtime --test nested_tree_readiness
```

The emitted test builds four independent modules in repository-local storage and requires their process to exit
successfully with all four tests executed.

Dart now has the same six-route nesting proof, using a JSON roundtrip of `SpecFile` before recompilation for its
reconstructed routes. Its retained native/generated engines also prove 56 rejection-to-success transitions.
Public v2 and emitted entry functions create an engine per call. A separate emitted package validates and runs
four modules after offline dependency resolution and strict analysis. Repeat the two regression tests with:

```sh
cd dart
bash ../tools/run_dart_project_data.sh test test/nested_tree_readiness_test.dart
```

These are bounded nesting results. Package-wide Dart analysis still reports two separately owned SDK deprecations
in its regex adapters; the new test and emitted package pass strict analysis.

Julia's proof covers five public routes: native and JSON-reconstructed `SpecFile` engines, generated v2 entry for
each compiled form, and fresh emitted modules. Only the two native routes retain an engine, proving 28 immediate
rejection-to-success transitions. All five preserve exact JSON kinds and Unicode spans and detect the three
grammar mutations. The existing emitter suite includes this proof:

```sh
bash tools/run_julia_project_data.sh --project=julia -e \
  'using LinkedSpecJulia, JSON3, Test; const REPO_ROOT=pwd(); include("julia/test/source_emitter_test.jl")'
```

The child process loads four emitted modules using the retained offline dependencies and checks their metadata,
plans and results.

PUC Lua and LuaJIT now each prove five routes using native and JSON-reconstructed `SpecFile` engines, generated
v2 entry for both compiled forms and fresh emitted modules. Every route preserves the authored values/spans,
requires typed status1 rejection and detects the three mutations. Two retained engines prove28 immediate recovery
transitions per ABI; generated entries create an engine per call. Repeat the expanded emitter consumer with:

```sh
bash tools/run_lua_project_data.sh puc lua/test/rule_local_cursor_generated_source_test.lua
bash tools/run_lua_project_data.sh luajit lua/test/rule_local_cursor_generated_source_test.lua
```

Both pass133 assertions and independently load four emitted modules with checked child status, exact output and
cleanup. The storage census now rejects enumeration errors and passes its controlled and real-root checks.
The bounded nesting milestone reconciles these routes and their limits through canonical verification. It does
not establish the separately tracked malformed-regex native error path.
This example does not open the structured-format campaign or establish arbitrary-depth resource safety.


### Bounded context-name trial

This second readiness grammar tests names whose validity depends on an enclosing rule invocation. It accepts
zero or more elements such as `<a>x<b>β</b>y</a>`, stores each opening name, and compares the closing name with
that saved value. Names start with an ASCII letter and continue with ASCII letters, digits, `_` or `-`.
Text preserves its Unicode content and whitespace. ASCII whitespace between top-level elements is ignored.

This is a small authored language, not XML: there are no attributes, self-closing elements, comments, entity
expansion or Unicode tag names. For example, `<a>&amp;</a>` returns the literal text `&amp;`.

```text
{{#include ../../../../tests/language-readiness/context-names/grammar.spec}}
```

`entry_group(0)` reads the opening name when `Element` is called. `match_group(0)` in the closing edge reads
the current closing name. These are captures-only indices; group 0 means the first parenthesized capture.
`str_ne` performs the case-sensitive string comparison. Bare `ne` is a numeric comparison and is unsuitable here.
The saved `name`, `start` and `children` bindings must survive calls to nested elements.

For `<a>x<b>β</b>y</a>`, the exact result is:

```json
[{"kind":"element","name":"a","span":[0,17],"children":[
  {"kind":"text","span":[3,4],"text":"x"},
  {"kind":"element","name":"b","span":[4,12],"children":[
    {"kind":"text","span":[7,8],"text":"β"}
  ]},
  {"kind":"text","span":[12,13],"text":"y"}
]}]
```

Further controls make the context requirement visible:

| Input | Expected behavior |
| --- | --- |
| `<a></a>` | One empty element, name `a`, span `[0,7]`. |
| `<item>β🙂</item>` | Text span `[6,8]` and element span `[0,15]`, measured in Unicode scalars. |
| `<a><b></b><c></c></a>` | Child names `b` and `c`; closing the parent still compares against `a`. |
| `<a><b><c>🙂</c></b></a>` | Restore `b`, then `a`, across two successive returns; outer span `[0,22]`. |
| `<a><a>z</a></a>` | Equal nested names remain separate scoped elements. |
| `<A></A>` / `<A></a>` | The first succeeds; the second is a case-sensitive mismatch. |

This grammar assigns its own diagnostic statuses:

| Status | Meaning in this grammar | Examples |
| --- | --- | --- |
| 1 | Invalid syntax or text outside an element | `<a/>`, `<a x></a>`, `outside`, `<a></a>tail` |
| 2 | Closing name differs from the saved opening name | `<a></b>`, `<a><b></a></b>` |
| 3 | End of input before a required close | `<a><b></b>`, `<a><b>` |

These are typed exits, not successful partial ASTs. They distinguish three reasons but do not themselves provide
an expected-name message, an error span or in-document recovery. Prefix/gap/final-cursor guards retain the strict
acceptance discipline from the nesting trial; checking the closing name alone would not make a complete parser.

The Perl proof covers native and independently loaded emitted parsers. Each runs 90 original calls over
11 accepted and 17 rejected cases, including 34 immediate rejection-to-success transitions on the same parser.
Three deliberate grammar changes remove the name comparison, overwrite parent state after a child returns, or
replace the saved start coordinate. The unchanged oracles detect the intended wrong acceptance, rejection or span.
All five rules are ActionIR-ready. Repeat the proof with:

```sh
bash tools/project_data_run.sh prove -v -Iperl t/nested_tree_readiness.t
```

The same authored fixture also passes the public native loaders on Perl, Rust, Dart, Julia, PUC Lua and LuaJIT:
11 accepted cases, 17 rejected cases and 22 accepted parses in forward/reverse order through one loaded engine per
runtime. All return exact JSON kinds, values and Unicode spans. The adapters exit on the first rejection, so
this native-adapter proof does not establish recovery after rejection. Perl, Dart, Julia and both Lua runtimes
preserve typed JSON errors; Rust's published adapter exposes the grammar status through Display text.
The application process exits with code 1 for a rejection, independently of the grammar's status 1, 2 or 3.

To repeat the public-native trial for a prepared runtime:

```sh
bash tools/run_python_project_data.sh tests/language-readiness/nested-tree/verify_native.py \
  --fixture context-names --runtime rust
```

Replace `rust` with `perl`, `dart`, `julia`, `puc` or `luajit`. Omitting `--fixture` retains the original
nesting trial. Both fixtures pass on all six routes after this verifier extension.

Rust additionally verifies six typed routes: native and JSON-reconstructed engines, both engines with generated
plans, the public serialized v2 entry, and an independently compiled emitted module. Each runs the same 90 calls
and three mutations. The four retained-engine routes each recover immediately after 34 typed rejections, for
136 transitions. Serialized/emitted entry functions create an engine per call and establish call isolation.
Every rejected input must carry its exact typed status; a successful null value cannot count as rejection.
Both nesting and context emitted modules must compile and execute in real fresh Cargo children.

```sh
bash tools/run_cargo_local.sh test --locked --offline --manifest-path rust/Cargo.toml \
  -p linkedspec-runtime --test nested_tree_readiness -- --nocapture
```

Dart also passes six routes: native and SpecFile-JSON reconstructed engines, both generated-plan variants,
the public v2 entry and a fresh emitted module. Its four retained routes prove 136 immediate recoveries;
per-call entries prove isolation. Each route runs the same 90 calls and three mutations. Fresh emitted
packages must pass offline preparation, fatal analysis and actual execution with an exact four-module report.

```sh
cd dart
bash ../tools/run_dart_project_data.sh test test/nested_tree_readiness_test.dart
```

Julia passes five public routes: native and SpecFile-JSON reconstructed engines, public v2 execution on both
compiled forms, and a fresh emitted module. Each runs 90 calls and three mutations. The two retained native
engines prove 68 immediate recoveries; the other three routes create engines per invocation. Fresh hosts must
return the exact report with successful exit status, validated metadata/plans and verified cleanup.

```sh
bash tools/run_julia_project_data.sh --project=julia -e 'using LinkedSpecJulia, JSON3, Test; const REPO_ROOT=pwd(); include("julia/test/source_emitter_test.jl")'
```

PUC Lua and LuaJIT independently pass five routes each: native and SpecFile-JSON reconstructed engines,
public v2 on both compiled forms, and a fresh emitted module. Each route runs 90 calls and three mutations.
The two retained native engines prove 68 immediate recoveries per ABI; the other entries prove isolation.
Fresh children require actual success, empty stderr, exact four-module reports and verified workspace cleanup.

```sh
bash tools/run_lua_project_data.sh puc lua/test/rule_local_cursor_generated_source_test.lua
bash tools/run_lua_project_data.sh luajit lua/test/rule_local_cursor_generated_source_test.lua
```

The reconciled typed-carrier evidence is:

| Runtime | Typed routes | Retained parsers | Immediate recovery transitions |
| --- | ---: | ---: | ---: |
| Perl | 2 | 2 | 68 |
| Rust | 6 | 4 | 136 |
| Dart | 6 | 4 | 136 |
| Julia | 5 | 2 | 68 |
| PUC Lua | 5 | 2 | 68 |
| LuaJIT | 5 | 2 | 68 |

Each route runs the same 11 accepted and 17 rejected authored cases for 90 calls, plus three grammar mutations.
Those repeated calls are not additional corpus cases. Every retained parser contributes 34 immediate
rejection-to-success transitions; per-call entries establish isolation. Public native adapter results remain
separate from typed recovery proof.

This bounded objective demonstrates composition of captures, lexical comparison and recursive state across all
six runtimes. The 37-line grammar still needs explicit prefix/gap/final-cursor/missing-close guards. Its three
statuses distinguish causes, while expected-name messages, precise error spans and in-document repair remain
unassessed. No new comparison or state primitive is selected from this result. Lossless segmentation and
bounded child parsing below supply the remaining bounded objective before broader language-gap selection. The format
campaign, indentation handling, arbitrary-depth/resource safety and speculative rollback remain outside this proof.


### Bounded lossless segmentation trial

This extraction grammar recognizes bracketed ASCII integers such as `[12]`. Everything else remains text, including
malformed candidates such as `[x]` or an unfinished `[2`. It preserves every decoded input scalar without claiming
that all the input belongs to a valid integer-document language.

```text
{{#include ../../../../tests/language-readiness/lossless-segments/grammar.spec}}
```

For `α[12]🙂`, its ordered result has these segments. The item additionally retains the named `token` slot;
gap spans retain the source identity and `gap` provenance.

| Kind | Half-open scalar span | Exact text |
| --- | --- | --- |
| prefix | `[0, 1)` | `α` |
| item | `[1, 5)` | `[12]` |
| tail | `[5, 6)` | `🙂` |

Adjacent items retain an empty interstitial gap. Empty input returns one empty tail, while input with no selected
items returns all of its unskipped text as the tail. Public entry skips complete leading blank/comment lines before
the grammar starts, so the grammar also records any skipped `[0, cursor_pos())` text as `entry_prefix`. For example,
`\n[4]` begins with a one-scalar entry prefix and then an empty loop prefix; a blank CRLF line is retained by the
loop itself. Original source coordinates remain absolute in both cases.

The unadorned `Segments::` selects the default scan loop, whose successful terminal miss runs `LX`. Explicit
repetition modes have different terminal lifecycle rules; changing this header to `::OR` while retaining `LX`
does not preserve this program's result construction.

The thirteen authored cases pass through native Perl and independently loaded emitted Perl source. They compare
exact records and scalar slices, reconstruct the original input, repeat calls on retained parsers and mutate returned
gap data before another call. Deliberate changes to item selection, tail retention, item spans and entry-prefix
retention are detected. The Rust carrier proof below uses the same records and four mutations.

### An actual bounded child grammar

The staged parent keeps the same segmentation rules and annotates each recognized item. Its source-bound
`entry_group(0)` supplies only the digits inside the brackets:

```text
{{#include ../../../../tests/language-readiness/lossless-child/parent.spec}}
```

The caller prepares a frozen registry entry named `integer` with an already-compiled `Number` parser. The child
accepts canonical unsigned decimal text, so `0` and `12` succeed while `00`, whitespace and trailing text fail:

```text
{{#include ../../../../tests/language-readiness/lossless-child/child.spec}}
```

The explicit start/end guards make the bounded child strict, including when public entry would skip a leading
blank or comment line. Its result preserves a textual lexeme; it does not convert that lexeme to a numeric value.
The registry adapter passes the authorized text to this parser and rebases the returned local span through the
dispatch context. Recognition and semantic result construction stay in the child `.spec`.

For `α[12]🙂`, the child receives exactly `12`. Its local span is `[0, 2)`; rebasing gives `[2, 4)` in the original
decoded input with `entry_group` provenance. The parent's item still has text `[12]` and span `[1, 5)`. The consumed
`child` field retains `12`, and the `parsed` sibling contains the child AST, its local span and rebased `source_span`.
Prefix and tail are unchanged, so concatenating every original segment's `text` still gives `α[12]🙂`.

The same retained parent rejects `[12][00][7]` after calling children `12` and `00`; the third child does not run,
and no partial parent AST is returned. A subsequent `[8]` succeeds with fresh invocation accounting. An invocation
without a staged seed returns an inert marker. Missing identity, unapproved top rule and exhausted steps fail
before the first child call; a one-call limit rejects the second job after one completed call.

Repeat the proof with:

```sh
bash tools/project_data_run.sh env PERL5LIB= prove -q -Iperl t/lossless_child_readiness.t
```

It covers native/native, both native/emitted combinations, and emitted/emitted in a fresh interpreter that never
loads the compiler. Every route preserves the thirteen original segmentation cases twice, exact child requests,
sidecars, result detachment and rejection recovery. Independent child cases and three grammar mutations detect
permissive leading-zero recognition, wrong local/rebased spans and delimiter-inclusive child requests.

This finite composition proves selected step/call denials, not recursive resource safety, every diagnostic/result
ceiling or conflicting stitch-target preparation. Distinct item objects avoid the separately tracked Perl/Rust
destination-conflict defect. Whole-format conformance remains outside this result.

Rust now runs the unchanged parent and child grammars through six matched carrier pairs:

| Parent and child route | Reuse boundary |
| --- | --- |
| Native execution of compiled engines | Retained engines |
| Generated-plan execution of compiled engines | Retained engines |
| Native execution of JSON-reconstructed engines | Retained engines |
| Generated-plan execution of JSON-reconstructed engines | Retained engines |
| Public serialized v2 entry | New engines per call |
| Independently compiled emitted modules | New engines per call |

Each pair repeats the thirteen original segmentation cases and their enriched counterparts twice, executes the
four accepted/fifteen rejected child cases, and detects all seven segmentation/child mutations. Exact source
slicing and reconstruction remain separate from child AST and provenance assertions. The first four pairs retain
the parent and child engines after failure; the last two demonstrate isolated subsequent calls. The five in-process
pairs also compare their complete successful enriched values. Fresh emitted modules use the same independent
assertions, with successful child process status and three executed child tests required by the outer test.

```sh
bash tools/run_cargo_local.sh test --locked --offline --manifest-path rust/Cargo.toml \
  -p linkedspec-runtime --test nested_tree_readiness lossless -- --nocapture
```

Rust preserves exact staged failure codes through its execution error wrappers and typed status1 exits for the
standalone child. This proof does not claim identical error objects across languages. It also leaves returned-marker
validation, maximum-counter exhaustion and competing stitch targets with their existing repair owners.

Dart verifies the same six matched routes using a `SpecFile` JSON roundtrip before recompilation for its
reconstructed engines. Its staged entry returns the enriched AST directly; a caller-supplied outcome callback
receives the detached AST, sidecars, diagnostics, cache and resource records. The readiness checks compare both
outputs, including mutation of returned child data and exposed outcome data before another invocation. Failed
children and authority denials publish no successful outcome.

The original segment and child cases, seven mutations, exact staged codes and typed child exits all pass.
The first four Dart pairs retain engines; v2 and emitted entries construct them per call. Five in-process pairs
agree on complete successful outcome records. A fresh package contains all ten emitted modules, passes offline
dependency preparation and fatal analysis, then must return the exact completion report after executing the same
oracles. The shared checks run under that package's analysis context.

```sh
cd dart
bash ../tools/run_dart_project_data.sh test --reporter expanded \
  test/nested_tree_readiness_test.dart --name lossless
```

This does not close Dart's known malformed-provenance, diagnostic-byte or extreme-counter defects, nor its
separate whole-package SDK compatibility gate.

Julia verifies five matched parent/child routes with the same source and JSON oracles. Native compiled and
`SpecFile`-JSON reconstructed engines retain their instances. Generated v2 execution of each compiled form and a
fresh emitted host provide three routes that construct engines per call. Each runs the original and enriched
thirteen-case sequences twice, child4/15 controls, all seven grammar mutations, exact typed staged failures and
typed status1 child rejection.

The Julia isolation check mutates two fields of an actual returned child, then verifies that a second returned
result and the next parse remain exact. A deliberately aliased pair must fail that same check. Mutating a detached
copy would not establish this property. The fresh host loads ten emitted modules, validates metadata/plans and must
exit successfully with the exact corpus, mutation and alias-control report; its scratch directory is then verified
absent. All four in-process pairs also agree on complete successful enriched records.

```sh
bash tools/run_julia_project_data.sh --project=julia --startup-file=no --history-file=no \
  -e 'using LinkedSpecJulia, JSON3, Test; const REPO_ROOT=pwd(); include("julia/test/source_emitter_test.jl")'
```

This bounded direct-result check does not repair the separately tracked general staged-consumer isolation test.
Registry-pattern validation and diagnostic-byte containment remain separate Julia obligations.

PUC Lua and LuaJIT each verify five matched routes using one shared consumer: retained native and SpecFile-JSON
reconstructed engines, generated v2 on both compiled forms, and a fresh emitted process on the selected ABI.
All five run the same original/enriched thirteen-case sequences twice, strict child4/15, seven grammar mutations
and exact staged failures. The three generated/emitted routes construct engines per call.

The Lua checker independently slices UTF-8 scalars and verifies exact item/gap classification, spans, adjacency
and reconstruction. It invokes the actual child grammar, compares local/rebased spans and callback order, and
checks selected authority and accounting fields. Four in-process pairs agree on complete successful records.
As in Julia, an actual returned child is mutated and a deliberately aliased pair must fail the isolation oracle.
A fresh selected-ABI process validates ten emitted modules and must exit successfully with empty stderr and the
exact corpus/mutation/alias-control report. The existing test owner removes and verifies its temporary workspace.

```sh
bash tools/run_lua_project_data.sh puc lua/test/rule_local_cursor_generated_source_test.lua
bash tools/run_lua_project_data.sh luajit lua/test/rule_local_cursor_generated_source_test.lua
```

This bounded Lua proof leaves malformed host snapshots/provenance, marker cycles, diagnostic-byte containment
and extreme or malformed resource seeds as separately tracked obligations. It does not admit a standard format,
arbitrary gap dispatch or recursive resource safety.

The reconciled lossless trial covers the following matched parent/child routes:

| Runtime | Carrier pairs | Pairs retaining both engines | Pairs creating engines per call |
| --- | ---: | ---: | ---: |
| Perl | 4 | 4 | 0 |
| Rust | 6 | 4 | 2 |
| Dart | 6 | 4 | 2 |
| Julia | 5 | 2 | 3 |
| PUC Lua | 5 | 2 | 3 |
| LuaJIT | 5 | 2 | 3 |

Each pair repeats the thirteen enriched inputs twice, checks strict child recognition, source coordinates,
selected authority denials and subsequent success after failure. Only retained pairs establish same-engine
recovery. Perl's separate segmentation routes check four extraction mutants; all four child pairs check three
child mutants. Every other matched route checks all seven. Counts describe execution routes, not additional
grammars or general format support.

This trial requires no new language primitive. Its authoring costs are explicit prefix preservation, correct
loop/lifecycle selection, strict child entry/end guards and a caller-prepared compiled registry. The host projects
the child's own span but does not recognize its language. This division permits bounded composition while keeping
input preservation, child validity and dispatch authority separate. The next assessment combines the nesting,
context-name and lossless trials before selecting language gaps; broader format work remains gated.


## Approved and parked: language coverage and authoring difficulty

On 8 September 2026, the director approved an extension of this program: an explicit programming-language
coverage track and a matrix showing which parsing mechanisms are exercised and how difficult the grammars are
to author. This is recorded direction for future work. The readiness gate remains inactive; no language parser,
corpus campaign, or matrix implementation starts with this approval.

The original 91 catalog rows retain their identities and scope. Programming-language coverage will have a
separate, explicitly selected inventory, reusing existing foundations and catalog entries without double counting.
The purpose is to expose both capability gaps and unnecessary difficulty in expressing correct parsers.

A format count alone cannot show this. Many formats reuse JSON or XML, while one language can exercise several
different mechanisms. The future matrix will keep these dimensions separate:

| Dimension | Evidence to record when work is activated |
| --- | --- |
| Conformance | Exact format/language version and dialect, parsing boundary, valid/invalid cases, AST and diagnostic expectations, and results for each backend and route. |
| Parsing mechanisms | Cases exercising recursion, precedence and associativity, lexical context, indentation, contextual syntax, embedded languages, Unicode, recovery, and resource/progress boundaries. |
| Authoring difficulty | Straightforward, awkward, or blocked authoring, supported by a representative rule excerpt, duplicated logic or workaround, diagnostic experience, and an improvement owner where needed. |
| Performance | Separate cold construction, warm reuse, and document-parsing measurements over representative and adversarial inputs. |
| Confidence | Pinned oracle/corpus, source revision, reproducible command, proof scope, and remaining untested boundaries. |

Untried cases stay **unassessed**. A passing parser can still be awkward to write; an untested feature is not
evidence of a missing capability. A finite corpus also cannot prove that every possible parsing task is covered.
Completion claims will name the admitted inventory and the precise evidence supporting it.

For example, a parser might pass its expression corpus but repeat substantial precedence-handling logic. Its
conformance result can be passing while authoring remains awkward, linked to the relevant excerpt and an
improvement task. If a minimized input instead demonstrates an incorrect AST, that case records a defect and its
repair owner. These are examples of future reporting, not assessments of current LinkedSpec capabilities.

The language track will first select representative syntax families and pin versions, dialects, preprocessing
boundaries, corpus authority, and usable licensing. Operator precedence, indentation, context-dependent token
interpretation, comments/trivia, and mixed embedded languages are selection pressures, not a promised language
list. Each selected parser receives bounded task ownership before implementation and follows the same neutral
contract and all-current-backend proof as the format parsers. Parsing source to AST does not implicitly add
evaluation, typechecking, module loading, or execution.

Every confirmed gap will retain a minimal reproduction and an owning repair task. Diagnosis must distinguish a
grammar defect, an engine defect, a missing general mechanism, an authoring/documentation problem, and a
performance limit. A missing general mechanism follows the existing neutral-contract and all-backend rollout
before the affected parser resumes. The matrix will link the original difficulty to the repair and its verified
result, so recording a problem leads to accountable follow-through.

The durable routes are `STRUCTURED-TEXT-FORMAT-PROGRAM.2.8` for the matrix and rubric and `.12` for language
coverage; `.0.1` records this approval. ADR `0034` carries the dated planning addendum. Readiness `.1` remains the
activation gate. The September language-readiness work above is now the immediate feature direction; separately
owned startup defects remain queued and must be resolved when they block a selected objective.

## One dynamic parser source

For each format, the composed `.spec` files are the sole executable source of truth for grammar, parser
orchestration, AST construction, and recovery behavior. A backend loads the same `.spec` graph, dynamically
constructs or compiles the parser in memory, and can immediately apply it to documents for that format.

There is no separately maintained Perl, Rust, Dart, Julia, or Lua parser. If a backend emits host source or stores
a compiled parser cache, that artifact is a reproducible derivative keyed by the complete `.spec`/import graph,
the LinkedSpec language-contract version, and behavior-relevant options. It may accelerate startup but cannot
become a second grammar or define behavior independently.

The standards and external conformance suites remain the correctness oracles. They say what the format means;
the `.spec` graph is the single parser implementation that must satisfy them on every backend. Performance proof
therefore measures three distinct paths: cold dynamic parser construction, warm cache reuse, and document parsing.

## Optional native acceleration

After a realistic dynamic format parser is complete and measured, LinkedSpec may optionally derive a faster
backend-native artifact from its normalized compiled state. This is a third deployment tier after immediate
dynamic construction and warm cache reuse, not a replacement parser. Loading `foo.spec` must still produce a
usable parser without a native compiler or prebuilt artifact, and the dynamic route remains the correctness oracle
and fallback.

Generated-source artifacts supply important foundations—deterministic identity, independently loadable host source,
normalized state, trace roles, and interpreter-first equivalence—but does not itself claim optimizing compilation
or higher speed. A native accelerator must separately match ASTs, spans, diagnostics, Unicode behavior, recovery,
limits, and trace semantics; correlate compile/runtime behavior back to `.spec` rules; use complete deterministic
fingerprints and invalidation; isolate explicit toolchain/trust boundaries; and demonstrate an objective benefit
including build/load and break-even costs. Strategies may differ internally by backend. Acceleration is not a
format-support or semantic-parity requirement, and Perl need not provide it. ADR `0038` and the separate
`NATIVE-PARSER-ACCELERATOR` task tree govern this non-blocking horizon.

## Observe what was built and what ran

A dynamic parser must be explainable from its first `.spec` load through its final AST. The normal native API must
accept one trace configuration/emitter across spec resolution and imports, validation, function and staged parsing,
contract/dependency planning, cache fingerprint and hit/miss decisions, compilation, and document execution.
Runtime events must expose rule entry/exit, parsing and branch decisions, cursor/capture transitions, AST/value
emission, recovery, and diagnostics where applicable. Stable spec-graph/cache identity and rule/source/position
fields correlate the constructed parser with its execution.

The existing `none`, `low`, `medium`, `high`, `full`, and `debug` levels and quiet/stdout/routed/mirrored behavior
remain the base contract. ADR `0037` adds a future exact rule-label allowlist for focused diagnosis. Global pipeline
scopes remain visible, while rule-owned events are emitted only for selected labels. This filter changes emission
only: traced and untraced construction, parsing, ASTs, recovery, diagnostics, and caches must remain identical.
Payloads and excerpts use explicit limits/redaction controls so debug tracing remains safe for large or adversarial
documents. `STRUCTURED-TEXT-FORMAT-PROGRAM.2.7` owns the shared executable contract after current backend parity.

## Terse, readable, and highly expressive

The format program also treats the quality of the `.spec` source as part of the result. A parser is not a success
if it passes a corpus only by turning its grammar into unreadable punctuation, repeated boilerplate, or opaque
format-specific escape hatches.

Here, **terse** means that redundant ceremony is absent. It does not mean that the shortest spelling always wins.
Names retain the words needed to communicate semantics. For example, `walk_leaves`, `map_leaves`, and
`reduce_leaves` deliberately keep `_leaves`: those methods recursively visit leaves, while plain `map` or
`reduce` would normally suggest immediate elements. Removing that suffix would save characters but lose meaning.

**Readable** means that rule structure, value flow, evaluation order, mutation, scope, and recovery remain visible
from the source and the documented contract. Equivalent concepts use equivalent forms; distinct concepts remain
distinguishable. Invalid or wrong-kind operations produce precise typed diagnostics instead of relying on hidden
coercion.

**Highly expressive** means that a small set of typed, orthogonal mechanisms can compose into difficult parsers.
It does not mean adding one built-in for every format. When HTML, YAML, CommonMark, or another format exposes a
missing capability, LinkedSpec extracts the reusable mechanism and proves it across every current backend.

Uniform value binding is the existing precedent. One identifier can hold scalar, array, harray, or codeblock;
runtime kind determines valid operations, and a wrong-kind mutation fails explicitly. Authors do not select a
parallel backend storage namespace. That design is concise because one abstraction composes uniformly while
preserving typed meaning.

Every later language proposal must therefore include representative format excerpts and ambiguous or invalid
boundaries. The review asks both whether the mechanism can express the format and whether the resulting `.spec`
is a clear, compact source of truth.

## Formats are requirements evidence

The catalog is not only a list of parsers to accumulate. Each authoritative format is an acceptance test for the
`.spec` language itself. When a format exposes a missing general mechanism, the format pauses while LinkedSpec:

1. identifies the reusable parsing mechanism rather than naming a format-specific exception;
2. specifies the smallest backend-neutral syntax, AST, runtime, diagnostic, and Unicode contract;
3. implements and verifies that contract on Perl, Rust, Dart, Julia, and Lua;
4. documents it with worked `.spec` examples; and
5. resumes the format parser using the newly portable capability.

For example, an HTML tree-construction case might expose a need for explicit token reprocessing or a structured
recovery event. YAML might expose indentation/context state. CommonMark might expose delimiter-run or controlled
backtracking requirements. Those become universal `.spec` features only when the mechanism is general and all
current backends agree. The difficult part may not be hidden in a Perl, Rust, Dart, Julia, or Lua callback.

## Reuse syntax foundations

Many catalog rows are serializations or vocabularies layered over a smaller number of syntax families. Their
parsers should compose rather than clone grammar code:

| Foundation | Examples that reuse it |
| --- | --- |
| JSON | JSON Lines, NDJSON, GeoJSON, JSON-LD, JSON Schema, OpenAPI JSON, FHIR JSON, SARIF |
| XML | XHTML, SVG, MathML, DocBook, DITA, RDF/XML, RSS, Atom, KML, GPX, FHIR XML, MusicXML |
| YAML | OpenAPI YAML, AsyncAPI YAML, SPDX YAML |
| CommonMark | GitHub Flavored Markdown and explicitly named generic-Markdown profiles |
| Turtle/RDF terms | TriG, SHACL Turtle, related RDF graph projections |
| HTML tree | RDFa and Microdata extraction stages |

Reuse does not erase format ownership. Every row still pins a specification/version, AST or projection, profile,
conformance evidence, Unicode behavior, examples, limitations, and re-verification command.

Conditional conventions need named profiles. There is no honest universal INI, dotenv, CSV, TSV, generic
Markdown, or JUnit XML grammar. LinkedSpec will identify the dialect it implements instead of turning one library's
behavior into an unstated standard.

## HTML is not XML

XHTML is XML and can reuse the XML foundation. Ordinary HTML requires the WHATWG tokenizer and tree-construction
algorithms: tokenizer states, character references, insertion modes, implied elements, token reprocessing, foster
parenting, active formatting elements, foreign SVG/MathML content, and defined error recovery. Full HTML support
must be proved with authoritative tokenizer and tree-construction corpora. Accepting only clean, well-nested
markup is not an HTML completion claim.

HTML is therefore one of seven early architecture-driving formats alongside JSON, XML, TOML, a named CSV profile,
CommonMark, and Turtle. It is an explicit stress test for the expressiveness and efficiency of `.spec`.

## Unicode and input boundaries

The parsers operate on Unicode text and expose source-aware ASTs. Their proof must cover, as applicable:

- strict malformed-input behavior;
- supplementary scalar values and combining sequences;
- escapes and character references;
- legal Unicode names and intentionally restricted identifier classes;
- byte, character, line, and column provenance;
- LF/CRLF and format-specific newline rules;
- BOM rules and normalization preservation; and
- Unicode data in every syntactic position where the format permits it.

Some formats, notably XML and HTML, can arrive in encodings other than UTF-8. A future format-native byte-decoder
or input layer must make that handling explicit and preserve source provenance. It must not reinterpret the
existing primary CLI or native spec-loading contracts, which remain strict UTF-8.

## Parsing is not evaluation

For CUE, Dhall, Jsonnet, Nickel, Pkl, and the Nix language, the program initially means source text to an accurate
AST. It does not automatically include imports, evaluation, normalization, typechecking, package loading, or host
execution. Likewise, parsing JSON Schema, XSD, GraphQL, Protocol Buffers schema text, or ASN.1 notation does not
by itself promise a validator, compiler, query engine, or binary codec.

Binary wire formats, databases, and packaged containers remain outside this text program. Examples include CBOR,
MessagePack, protobuf binary data, Avro object containers, Parquet, PDF, EPUB, OOXML, and glTF `.glb`.

## What completion means

A format is complete only when it has:

- a pinned authoritative specification and usable conformance corpus;
- a documented source-aware AST, trivia/raw-text policy, and typed diagnostic/recovery boundary;
- identical neutral fixtures on every current backend and supported execution route;
- correlated construction/runtime trace proof, exact rule-focused output, and traced/untraced semantic identity;
- Unicode adversarial and mutation/property proof;
- differential comparison with an independent implementation where practical;
- public examples and honest limitations; and
- correctness-preserving performance and resource measurements on representative, large, and adversarial input.

“Fast” is a measured result, not an assumption. “Supported” means the documented contract passes, not merely that
a friendly example was accepted.


### Registered functions inside Perl deferred codeblocks

A deferred codeblock can call a registered pure function using its existing signature. Registered
functions take precedence over same-named callable slots. Fixed arguments evaluate once in source order;
variadic calls receive a fresh rest array. Function callbacks use the function's fresh working frame:

```spec
fn decorate(text,prefix) { return(cat(prefix,uppercase(text))) }
Top:: I {
  cb={|| return(decorate("ab","!")) };
  return(cb())
}
```

Both native and fresh emitted execution return `"!AB"`. Variadic state belongs to each function call:

```spec
fn collect(...items) { push(items,"tag"); return(items) }
Top:: I {
  cb={|| first=collect("a"); second=collect(); return([first,second]) };
  return(cb())
}
```

The result is `[["a","tag"],["tag"]]`. Explicit, bound, parenthesized and attached final codeblocks
use the same callable contract as direct function calls. Arity and unsupported keyword arguments reject
before operand work; a wrong final value retains `final_argument_not_codeblock`. Unknown operations and
unsupported function bodies keep typed diagnostics. An unrelated unused unsupported definition does
not change the calling rule's readiness.

The compiler emits a private invocation table containing signatures, final-block metadata and callable
bodies produced by the existing central function lowerer. Runtime dispatch receives already evaluated
arguments; it neither recompiles source nor interprets a second function AST. The plain eight-field
codeblock record carries no callable closure, environment, registry or recursion field. Active function
state unwinds on success and failure. Callable aliases and published copies retain opaque identities
outside the record; independently constructed equal callbacks remain distinct. Recursive mixed calls
retain typed cycle diagnostics.

The combined regression executes 71 exact native/fresh emitted sources and 605 top-level tests. Native
checks retain actual rest/frame/slot/error identities, with deliberate alias controls. A fresh emitted
child independently checks rest separation, actual operand effects and handler entry counts, typed
exception identity and restored context. The existing 33 source rows remain byte-exact. All seven
original isolated composition controls now succeed on both producers.

The later `.0.2.1.3.1` repair protects callable signature pipes, including `x,y` and operator-named
rest parameters. The original frozen pipeline retains its historical infix failure; the explicit call-form
successor passes all seven normalization cases. Historical audit-input recovery `.0.4.2` is committed for the134 selected logs;
independent `.0.2.1.2` reconciles the bridge and these bounded prerequisites under
exact staged canonical acceptance. Deferred attached-control execution, residual
metadata ordering and nested raw-expression readiness remain separate repairs.
Startup32 argument/local-name shadowing, startup19/35/87 and other backend lanes retain their owners.
Recognized-source readiness does not prove runtime coverage.

### Independently checking the committed bridge

The closeout reviewer reruns the seven original public native/fresh controls, the
unchanged71-source bridge regression and six direct-dependent suites, and the
seven-case call-form normalization proof. It compares exact values and ordered
effects with the retained oracles and checks the unchanged bridge/compiler and
callable authorities. The actual runtime identity, recursion, slot and restoration
assertions stay in the tracked tests; serialized flags do not replace them.

```sh
bash tools/run_python_project_data.sh docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.2.1.2-review.py
```

The command writes only managed scratch logs and prints its complete observation.
It rejects altered control values/source identities, normalization event order,
quietness and typed rejection status. Historical producer bodies are checked from
retained source lines or exact Git blobs without executing old writers. Earlier
captures keep their original hashes and revisions; the new observation records
the current selected execution. The original infix fixture remains unchanged.

This reconciles the bounded function bridge, literal and source/durability
prerequisites. It does not close the dispatcher or establish full sixteen-case
runtime and semantic-mutant admission; those activities retain separate owners.

### Call grammar in the normalization loop

Arithmetic and numeric comparisons use ordinary calls. A counted loop can compose `count` with
`num_lt` and `num_add`:

```spec
Top:: I { pieces=["a","b"]; i=0; while(num_lt(i,count(pieces))) { i=num_add(i,1) }; return(i) }
```

This returns `2` on native Perl and independently loaded emitted source. The equivalent loop using
`lt(i,count(pieces))` and `add(i,1)`, or `<(i,count(pieces))` and `+(i,1)`, also returns `2`.
The [numeric helper reference](../dsl/value-container-flow-helper-reference.md#numeric-value-helpers)
defines these call forms and explicit nested grouping.

The original selected fixture instead contains `i < count(pieces)` and infix increments.
Its AST marks those expressions `raw_perl/unsupported_expression`; emitted Perl retains the barewords
and calls a host `count`, which fails at runtime. Direct `count(pieces)` returns `2`. Replacing only
that loop with admitted calls in a scratch source yields the selected nested `new:AB`/`new:CD`
result, count2 and restored caller text on both routes. `.0.4.1` binds that explicit successor fixture
and verifies all seven cases, preserving the original bytes and all selected oracles.

The diagnosis also exposes false portability telemetry: these raw nested expressions currently
report ready1/raw0/fallback0/unresolved0. For example, `i=2; i=i+1; return(i)` returns `1`, and
an infix `i < 1` condition selects its true branch, because the emitted bareword is not the bound
DSL variable. `.0.7` owns reporting those raw dependencies under ADR0003; source correction alone
does not close that defect. Complete D/P semantic-mutant admission and independent control/order/readiness
repairs remain with the subsequent owners.

### Reconstructing dated bridge probes from a fresh checkout

A hash identifies an instrument but does not retain it. The registered-function bridge checkpoint
`docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.2.1.1-verification.json` stores the exact probe
programs as source lines with hashes, an independently checked reconstruction recipe, and ordered
`replay_commands`. Its captured observations describe that implementation boundary. Later compiler
changes can change a dated observation; the tracked regression remains the current behavior check.

From the repository root, recover the programs and committed baseline modules on the repository volume:

```sh
bash tools/project_data_run.sh python3 - <<'PY'
import hashlib, json, subprocess
from pathlib import Path
root = Path.cwd().resolve()
record = json.loads(Path("docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.2.1.1-verification.json").read_text())
allowed = (root / ".linkedspec-data/scratch/selfcontain1330211").resolve()
assert allowed.is_relative_to(root)
plan = []
for producer in record["producer_sources"]:
    data = "".join(producer["source_lines"]).encode()
    assert hashlib.sha256(data).hexdigest() == producer["sha256"]
    target = (root / producer["path"]).resolve()
    assert target.is_relative_to(allowed)
    plan.append((target, data))
for source, expected in record["red"]["activation_modules"].items():
    assert source.startswith("perl/") and ".." not in Path(source).parts
    data = subprocess.check_output(["git", "show", record["activation_commit"] + ":" + source])
    assert hashlib.sha256(data).hexdigest() == expected
    target = (allowed / "baseline-perl" / source.removeprefix("perl/")).resolve()
    assert target.is_relative_to(allowed)
    plan.append((target, data))
for target, data in plan:
    target.parent.mkdir(parents=True, exist_ok=True)
    assert target.parent.stat().st_dev == root.stat().st_dev
    target.write_bytes(data)
print("validated producer sources and baseline modules reconstructed")
PY
```

The recipe validates every producer and baseline identity before writing, constrains destinations to
the declared scratch root, and checks the filesystem device. Run the checkpoint's replay commands in
order; its `red.command` uses the reconstructed old-module bootstrap. A deliberately corrupted producer
hash is rejected before any file write. Keep captured source identities distinct from current results.

### Preserving the earlier callable instruments

The scope diagnosis, scope repair and pre-bridge design checkpoints retain their original results.
Their standalone observers are now recoverable from
`docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.2.1.4.0-recovery.json`.
It stores exact source bodies, required literal inputs and Git-blob references for the historical
33-case regression and pre-repair lowering module. The current 71-case test is a different input.

Recover the archive into an owned scratch mirror without overwriting the retained originals:

```sh
bash tools/project_data_run.sh python3 - <<'PY'
import hashlib, json
from pathlib import Path
record = json.loads(Path("docs/checkpoints/SPEC-LANGUAGE-SELF-CONTAINMENT.1.3.3.0.2.1.4.0-recovery.json").read_text())
row = next(r for r in record["recoverable_inputs"] if r["path"].endswith("/recover.py"))
source = "".join(row["source_lines"])
assert hashlib.sha256(source.encode()).hexdigest() == row["sha256"]
exec(compile(source, "<archived-callable-recovery>", "exec"), {"__name__": "__main__"})
PY
```

The recovery validates the complete input plan before recovered file writes, checks the repository
filesystem and refuses escaping paths or symlinks. Its actual review restores 15 byte-exact inputs
and rejects six corrupted-input controls with zero file writes. This proves source recoverability;
it does not claim a new execution of the old runtime, RED, Phase 0 or canonical suites.

For historical execution, use the capture commit named for that claim and the original declared
relative input paths in an isolated repository-owned workspace. Follow the dependencies' published
integration instructions. The mirror does not assemble that workspace. The old review.py writes its
original tracked checkpoint and must not run in the current checkout. Current bridge tests and their
committed receipt remain the current behavior proof; policy adoption and the broader claim audit
retain separate task owners.

### Current Perl deferred conditional boundary

Perl executes attached `if`/`elseif`/`else` bodies inside callable literals through their typed
conditions and bodies. Conditions run once, in order, until a branch is selected; later conditions
and all unselected bodies are skipped. A return inside nested attached bodies exits the current
callable invocation. This complete example returns `hit` on native and fresh emitted routes:

```spec
Top:: I {  cb={|| if(true) { return("hit") }; return("miss") }; return(cb()) }
```

The original pattern-based composition also returns `ok`:

```spec
Top:: I {  cb={|x,y| if(matches(x,/ok/)) { return(x) }; return("miss") }; return(cb("ok","unused")) }
```

`when` and `otherwise` are the portable attached aliases. Perl also accepts attached `i` and `elif`;
those opposite-shape alias extensions remain narrower than the portable intersection.
Conditions use LinkedSpec truthiness: null, false, numeric zero and empty containers are false,
while the nonempty string `"0"` is true. Attached controls are statements, so their final body
expression does not become the callable's implicit result:

```spec
Top:: I {  cb={|| if(true) { "hit" } }; return(cb()) }
```

This returns null. A later ordinary expression can still supply the implicit result.
An eager expression block consumes its own early return, allowing the outer callback to continue:

```spec
Top:: I {  cb={|| value={ if(true) { return("inner") }; return("bad") }; return([value,"outer"]) }; return(cb()) }
```

The result is `["inner","outer"]`. Copied fixed/rest parameters restore their original caller
slots on success and failure; branch/helper failures retain the actual thrown typed object.
Earlier nonparameter effects remain visible. The plain callable record and scope contract are unchanged.

Marker `if`/`elseif`/`else`/`endif` also executes inside a Perl callable. The evaluator groups
matching typed statements, selects conditions once, skips unselected bodies and carries local
returns through nested marker or attached controls. This returns `hit`:

```spec
Top:: I {  cb={|| if(true); return("hit"); else(); return("miss"); endif() }; return(cb()) }
```

A marker group without an explicit return yields null, just like an attached conditional statement.
An eager expression block keeps its own early-return boundary:

```spec
Top:: I {  cb={|| value={ if(true); return("inner"); endif(); return("bad") }; return([value,"outer"]) }; return(cb()) }
```

The result is `["inner","outer"]`. Return propagation also preserves a typed false argument
and a null result; neither falls through to the later statement:

```spec
Top:: I { cb={|flag| if(true); return(flag); endif(); return("bad") }; return(cb(false)) }
```

This returns JSON `false`. The separate dynamic boolean-literal identity gap remains: writing
`return(false)` inside the callable currently produces numeric `0`; passing an existing typed
boolean preserves its kind. Marker conditions still use governed truthiness.

The portable marker aliases are `i` and `elif`. Perl additionally accepts marker `when` and
`otherwise`; these opposite-shape extensions are not new portable admission. Missing `endif`
and a branch after fallback reject before condition effects, with the typed opening/offending
span. Reached orphan controls also diagnose. An explicit return skips later statements, including
an unreachable trailing control; this grouping adds no whole-body syntax preflight.

Callable value conditionals now return the selected payload. They evaluate conditions once,
stop at the first true arm, and leave all unselected conditions and payloads unevaluated.
A missing matching arm returns null. These are value expressions; the statement result rules
above still apply. For example:

```spec
Top:: I {  cb={|| return(if(true,"hit",else("miss"))) }; return(cb()) }
```

```spec
Top:: I {  cb={|| return(if(false,"bad",elseif(false,"bad"),elseif(true,"hit"),elseif(unknown_helper(),"bad"),else(unknown_helper()))) }; return(cb()) }
```

```spec
Top:: I {  cb={|| return(if(false,"bad","hit")) }; return(cb()) }
```

```spec
Top:: I {  cb={|flag| return(if(true,flag,else("bad"))); unknown_helper() }; return(cb(false)) }
```

The first three examples return `"hit"`; the last returns JSON `false` and skips the later
unknown helper. An optional final `else(payload)` or plain final payload supplies fallback.
`elseif(condition,payload)` arms stay ordered. Existing leading bare scope labels on branch
wrappers remain supported. Branch order and wrapper arity validate before condition effects.
Value aliases are not admitted by this repair; use `if`, `elseif`, and `else`.

In Perl callable bodies, both `return()` and `return_undef()` now exit with null and skip
later statements. The selected return propagates through attached and marker branches.
An eager expression block consumes its own return, so its caller can continue:

```spec
Top:: I {  cb={|| return() }; return(cb()) }
```

```spec
Top:: I {  cb={|| return_undef() }; return(cb()) }
```

```spec
Top:: I {  cb={|| if(false); unknown_helper(); elseif(true); if(true) { return_undef() }; unknown_helper(); endif(); unknown_helper() }; return(cb()) }
```

```spec
Top:: I {  cb={|| value={ return_undef(); unknown_helper() }; return([value,"outer"]) }; return(cb()) }
```

The first three return null. The last returns `[null,"outer"]`. One-payload `return(value)`
keeps its existing behavior, including false and empty containers. The private executor accepts
zero or one payload for `return`, and zero for `return_undef`; the latter also retains the existing
optional bare scope-label spelling. Invalid arity rejects before argument effects.
`return_undef` is a statement exit here, so putting it inside an ordinary value-helper argument
remains unsupported. These callable results do not
admit general multi-value returns or change the compiler's raw/readiness boundaries.
The working explicit-null spelling skips the later unknown helper:

```spec
Top:: I { cb={|| if(true); return(undef); endif(); unknown_helper() }; return(cb()) }
```

This returns null on both routes.

Registered pure functions support the value-oriented alternative:

```spec
fn choose(x) { return(if(matches(x,/ok/),x,else("miss"))) }
Top:: I {
  cb={|| return(choose("ok")) };
  return(cb())
}
```

Both routes return `ok`. Attached statement-control function bodies exceed the current
function MVP. The callable statement-control repairs do not extend that MVP or value control,
loops, metadata ordering, nested raw-expression readiness or complete composed-format execution.

### Current Perl callable while boundary

Attached `while(condition) { statements }` now executes inside Perl callable bodies.
It checks the condition once before each body, including the final false check, using the
same truthiness as conditionals. A false condition skips the body. The loop is a statement
and yields null unless an explicit return exits the callable. Nested loops and selected
branches propagate that return; an eager expression block consumes its own return.

```spec
Top:: I {  cb={|| while(false) { "bad" }; return("after") }; return(cb()) }
```

```spec
Top:: I {  cb={|| text=""; while(matches(text,/^x{0,2}$/)) { text=cat(text,"x") }; return(text) }; return(cb()) }
```

```spec
Top:: I { effects=[]; condition_cb={|| push(effects,"condition"); return(matches(length(effects),/^(?:1|3)$/)) }; cb={|| while(condition_cb()) { push(effects,"body") }; return(effects) }; return(cb()) }
```

```spec
Top:: I {  cb={|| value={ while(true) { return("inner") }; unknown_helper() }; return([value,"outer"]) }; return(cb()) }
```

These return `"after"`, `"xxx"`, `["condition","body","condition","body","condition"]`,
and `["inner","outer"]`, respectively. The third example checks twice before bodies and
once more to stop. The fourth returns only from its eager block before the caller continues.
Null and false returns inside a loop keep their result kind and skip continuation. Fixed/rest
parameter slots restore on success or failure; nonparameter body effects remain visible.

The existing guard permits 10000 body executions. A false condition after body 10000 succeeds;
a true condition at the next check raises the typed `while_iteration_limit_exceeded` error
before body 10001. It retains `iteration_limit=10000`, `iterations_executed=10000` and the
typed while-node source span. Prior body effects remain visible. This matches the existing
Perl direct-action guard order; that direct route retains its existing host diagnostic.

This repair covers typed attached while in the private Perl executor. Numeric helpers inside
callables remain owned by startup87.3; the examples use supported matching/string helpers.
Portable `next()` and exact-limit Dart/Julia normalization retain backlog5 ownership.
Boolean literal kind, function statement MVP, descriptor ordering/readiness, dispatcher/full
execution and other-backend admission remain separate.

### What the Perl callable control composition covers

Attached and marker conditionals, value conditionals, null exits and attached while
now compose through the same private typed statement/value evaluator. Selected branches
and loop bodies preserve local returns, eager blocks keep their own return boundary, and
fixed/rest parameter slots restore while nonparameter effects remain live. The examples
above distinguish a null statement result from an explicit exit and a selected value payload.

This is bounded control coverage. It does not establish every helper or statement in
function bodies, numeric helpers in deferred bodies, portable next behavior, boolean
literal kind, complete-format self-containment or other-backend admission. Compiler
event ordering and nested raw-expression readiness still need independent correction;
working runtime results do not prove portable metadata.

### Stable residual metadata remains distinct from portable readiness

The bounded callable-control parent is canonically reconciled. The separate residual-order
repair preserves top-level/exclusive ownership and each remaining helper-scan occurrence.
Nine exact sources under three controlled seeds retain27 before/after native/fresh comparisons;
current full event records have one ordered sequence per source. Eleven focused suites pass
424 top-level TAP tests, including the15-assertion occurrence regression. The exact new Phase 0
child also runs; canonical acceptance of the staged compiler candidate gates landing.

The historical objective audit accepts only the exact new Phase 0 regression insertion.
Removing it recovers every prior byte; six corruption controls reject signature/plan drift,
unrelated edits, and missing, duplicate or altered recurrence. The isolated archived evidence
replay remains read-only toward original logs and tracked captures. It does not claim new
runtime execution of the historical objectives.

Source-identical substitutions, ASTs, dumps/emitted bytes, metadata populations/counts and
native/fresh values remain unchanged in the measured controls. Fifteen current lowering traces
retain their actual consumer decisions; ten evidence corruptions reject. Scan precedence is
not global source order or arbitrary-overlap equivalence.

The quoted string `"return(inner); if(true)"` still executes as data yet creates false
helper/control metadata. P1 `.0.7.2` owns that repair. Nested raw-expression reporting now
counts uncovered source occurrences and exposes action-unit provenance. Nested block
coordinates now index the enclosing action, and exact compiler-generated marker slots
retain their prior fallback diagnostics. Original host behavior and unsupported deferred-body
failures remain unchanged. Source comments have
their own `.0.7.3` classification repair. See the [ActionIR order explanation](../dsl/actionir-lowering-mental-model.md#canonical-event-order-and-execution)
for exact executed examples. Stable order does not close readiness, dispatcher/full composition
or another backend's behavior.

## Historical evidence after private factory capture

Historical replay admits only the exact committed factory source succession.
The Contracts audit now recognizes the accepted dependency-binding and native
constructor changes at `be7d7071` and `33e57dee`. It proves their source parents
join the earlier decoder revision, requires the complete current file to match
the accepted constructor commit, and restores the earlier bytes before applying
the decoder inverse. An unrelated edit, missing private binding or changed
registration is rejected; a future source change needs its own reviewed inverse.

This checks the integrity of earlier evidence. It preserves the original source,
checkpoint and archived-log hashes and does not rerun or extend historical runtime
claims. Fresh private capture behavior remains bounded by its own fixtures and
consumers. The isolated recovery proof exercises actual source denials and forbids
healthy original-log reads or tracked writes. See the [historical replay workflow](../development/documentation-workflow.md#replaying-historical-evidence-after-a-repair).
