package LinkedSpec::ActionIR::MethodExpr;

use 5.010;
BEGIN {
 require File::Basename;
 my $module_dir = (File::Basename::fileparse(__FILE__))[1];
 my $linked_spec_dir = File::Basename::dirname($module_dir);
 my $perl_root = File::Basename::dirname($linked_spec_dir);
 unshift @INC, $perl_root unless grep { defined($_) && $_ eq $perl_root } @INC;
}
use LinkedSpec::OwnerDispatch ();
use Scalar::Util ();

our ($_source_csv_recorder, $_source_method_recorder, $_input_capture_scope);

# Select by retained occurrence index. Changed values lose only their own frame;
# copied arrays and foreign source are rejected by the surrounding collector.
sub _select_argument_frames {
 my ($arguments, $frames) = @_;
 return [] unless ref($arguments) eq 'ARRAY';
 my @selected;
 for my $index (0 .. $#$arguments) {
  my $frame = $frames->[$index];
  my $value = $arguments->[$index];
  push @selected, defined($frame) && defined($value) && !ref($value)
   && $frame->{raw} eq $value ? $frame : undef;
 }
 return \@selected
}

# Private sidecars leave the callback's actual return untouched. Local recorders
# restore an enclosing invocation on both successful and exceptional returns.
sub _split_csv_with_source_frames {
 my ($callback, @args) = @_;
 return _collect_csv_source_frames($callback, \@args)
}

sub _collect_csv_source_frames {
 my ($callback, $args) = @_;
 return LinkedSpec::OwnerDispatch::call_preserving_err(sub {
  my $source = $args->[0];
  my @recorded;
  local $_source_csv_recorder = sub { push @recorded, $_[0] };
  my $arguments = $callback->(@$args);
  my $frames = [];
  if (ref($arguments) eq 'ARRAY' && defined($source) && !ref($source)) {
   for my $batch (@recorded) {
    next unless Scalar::Util::refaddr($batch->{arguments}) == Scalar::Util::refaddr($arguments)
     && defined($batch->{source}) && !ref($batch->{source}) && $batch->{source} eq $source;
    $frames = _select_argument_frames($arguments, $batch->{source_frames});
    last;
   }
  }
  return {arguments => $arguments, source_frames => $frames}
 })
}

sub _parse_method_with_source_frames {
 my ($callback, @args) = @_;
 return _collect_method_source_frames($callback, \@args)
}

sub _collect_method_source_frames {
 my ($callback, $args) = @_;
 return LinkedSpec::OwnerDispatch::call_preserving_err(sub {
  my $source = $args->[0];
  my @recorded;
  local $_source_method_recorder = sub { push @recorded, $_[0] };
  my $call = $callback->(@$args);
  my $frames = [];
  if (ref($call) eq 'HASH' && ref($call->{args}) eq 'ARRAY'
      && defined($source) && !ref($source)) {
   for my $batch (@recorded) {
    next unless Scalar::Util::refaddr($batch->{call}) == Scalar::Util::refaddr($call)
     && Scalar::Util::refaddr($batch->{arguments}) == Scalar::Util::refaddr($call->{args})
     && defined($batch->{source}) && !ref($batch->{source}) && $batch->{source} eq $source
     && defined($call->{source}) && !ref($call->{source}) && $call->{source} eq $batch->{trimmed}
     && defined($call->{method}) && !ref($call->{method}) && $call->{method} eq $batch->{method}
     && defined($call->{source_method}) && !ref($call->{source_method})
     && $call->{source_method} eq $batch->{source_method};
    $frames = _select_argument_frames($call->{args}, $batch->{source_frames});
    last;
   }
  }
  return {call => $call, source_frames => $frames}
 })
}

# Input captures retain actual objects only for the enclosing private scope.
# Legacy wrappers above keep their copied arguments; direct captures preserve
# the original aliases through a reference to their remaining @_ entries.
sub _with_input_captures {
 my ($work) = @_;
 local $_input_capture_scope = {captures => {}};
 local ($_source_csv_recorder, $_source_method_recorder);
 if (!defined wantarray) { $work->(); return }
 return $work->()
}

sub _same_input_reference {
 my ($left, $right) = @_;
 return ref($left) && ref($right)
  && Scalar::Util::refaddr($left) == Scalar::Util::refaddr($right)
}

sub _copy_input_frame {
 my ($frame) = @_;
 return undef unless ref($frame) eq 'HASH';
 return {source => $frame->{source}, raw => $frame->{raw},
         source_span => {%{$frame->{source_span}}}}
}

sub _retain_input_capture {
 my ($callback, $framed, $mode) = @_;
 my $value = $framed->{$mode eq 'method' ? 'call' : 'arguments'};
 my $capture = {value => $value};
 if (ref($_input_capture_scope) eq 'HASH') {
  my $arguments = $mode eq 'method'
   ? (ref($value) eq 'HASH' ? $value->{args} : undef) : $value;
  $_input_capture_scope->{captures}{Scalar::Util::refaddr($capture)} = {
   capture => $capture, callback => $callback, value => $value, mode => $mode,
   arguments => $arguments, count => ref($arguments) eq 'ARRAY' ? scalar(@$arguments) : undef,
   fields => $mode eq 'method' && ref($value) eq 'HASH'
    ? {map { $_ => $value->{$_} } qw(method source_method source)} : {},
   frames => [map { _copy_input_frame($_) } @{$framed->{source_frames}}],
  };
 }
 return $capture
}

sub _capture_csv_input {
 my $callback = shift;
 my $framed = _collect_csv_source_frames($callback, \@_);
 return _retain_input_capture($callback, $framed, 'csv')
}

sub _capture_method_input {
 my $callback = shift;
 my $framed = _collect_method_source_frames($callback, \@_);
 return _retain_input_capture($callback, $framed, 'method')
}

# An equal description, callback name or copied array cannot select a frame.
# Changed argument values decline individually; a changed array shape declines
# the whole capture because its original occurrence indices no longer apply.
sub _argument_input_for {
 my ($capture, $callback, $arguments, $index) = @_;
 return undef unless ref($_input_capture_scope) eq 'HASH' && ref($capture) eq 'HASH'
  && ref($callback) eq 'CODE' && ref($arguments) eq 'ARRAY'
  && defined($index) && !ref($index) && $index =~ /\A(?:0|[1-9][0-9]*)\z/;
 my $record = $_input_capture_scope->{captures}{Scalar::Util::refaddr($capture)};
 return undef unless ref($record) eq 'HASH'
  && _same_input_reference($record->{capture}, $capture)
  && _same_input_reference($record->{callback}, $callback)
  && _same_input_reference($record->{value}, $capture->{value})
  && _same_input_reference($record->{arguments}, $arguments)
  && @$arguments == $record->{count} && $index < @$arguments;
 if ($record->{mode} eq 'method') {
  my $value = $record->{value};
  return undef unless _same_input_reference($value->{args}, $arguments);
  for my $field (qw(method source_method source)) {
   return undef unless defined($value->{$field}) && !ref($value->{$field})
    && defined($record->{fields}{$field}) && !ref($record->{fields}{$field})
    && $value->{$field} eq $record->{fields}{$field};
  }
 }
 my $frame = $record->{frames}[$index];
 my $value = $arguments->[$index];
 return undef unless ref($frame) eq 'HASH' && defined($value) && !ref($value)
  && $value eq $frame->{raw};
 return _copy_input_frame($frame)
}

# Derive edge trimming from the original piece boundary, never a text search.
sub _frame_for_csv_piece {
 my ($source, $start, $end, $trimmed) = @_;
 return undef unless defined($source) && !ref($source) && defined($trimmed) && !ref($trimmed);
 my $piece = substr($source, $start, $end - $start);
 my ($leading) = $piece =~ /\A(\s*)/;
 my ($trailing) = $piece =~ /(\s*)\z/;
 $start += length($leading);
 $end -= length($trailing);
 return undef if $start > $end || substr($source, $start, $end - $start) ne $trimmed;
 return {source => $source, raw => $trimmed, source_span => {start => $start, end => $end}}
}

sub _trim_method_expr_value {
 my ($value) = @_;
 return undef unless defined $value;
 $value =~ s/^\s*|\s*$//go;
 return $value
}

sub _normalize_method_name {
 my ($method) = @_;
 return undef unless defined $method;
 return $method
}

sub _slash_literal_end {
 my ($text, $start) = @_;
 my $len = length($text);
 for (my $pos = $start + 1; $pos < $len; ++$pos) {
  my $char = substr($text, $pos, 1);
  if ($char eq '\\') { ++$pos; next }
  next unless $char eq '/';
  ++$pos;
  ++$pos while $pos < $len && substr($text, $pos, 1) =~ /[A-Za-z]/o;
  return $pos;
 }
 return undef;
}

sub _pattern_stays_in_operand {
 my ($text, $start, $end) = @_;
 my $call_end = _slash_symbol_call_end_at($text, $start);
 return 1 unless defined $call_end;
 my $close = $end - 1;
 --$close while substr($text, $close, 1) =~ /[A-Za-z]/o;
 return 0 if $close < $call_end;
 my $after = $call_end;
 ++$after while $after < length($text) && substr($text, $after, 1) =~ /\s/o;
 return 0 if $after == length($text) || substr($text, $after, 1) =~ /[;\)\]]/o;
 return 1 unless substr($text, $after, 1) =~ /[,\.]/o;
 my @closers;
 my %closer = ('(' => ')', '[' => ']', '{' => '}');
 for (my $pos = $call_end; $pos < $close; ++$pos) {
  my $char = substr($text, $pos, 1);
  if ($char eq '\\') { ++$pos; next }
  if ($char eq '"' || $char eq "'") {
   my $quote_end = $pos + 1;
   while ($quote_end < length($text)) {
    my $quoted = substr($text, $quote_end, 1);
    if ($quoted eq '\\') { $quote_end += 2; next }
    last if $quoted eq $char;
    ++$quote_end;
   }
   if ($quote_end < length($text) && $quote_end > $close) {
    my $after_quote = $quote_end + 1;
    ++$after_quote while $after_quote < length($text) && substr($text, $after_quote, 1) =~ /\s/o;
    # The opening quote of a later replacement is not a numeric string's
    # terminator when the resulting token runs straight into its contents.
    return 0 if $after_quote == length($text)
     || substr($text, $after_quote, 1) =~ /[,\)\]\};.\-+*\/%&|^?:]/o;
   }
   $pos = $quote_end if $quote_end < $close;
   next;
  }
  if (exists $closer{$char}) { push @closers, $closer{$char}; next }
  return 0 if $char =~ /[\)\]\}]/o && (!@closers || pop(@closers) ne $char);
 }
 return 1;
}

# Do not discover DSL calls inside an explicit host quote operator. Parenthesis
# delimiters remain with ordinary call parsing; the host forms protected here
# have an unambiguous non-call delimiter (q|...|, qr/.../, s{...}{...}, etc.).
sub _host_quote_end {
 my ($text, $start) = @_;
 my $open = substr($text, $start, 1);
 # Square brackets belong to DSL indexed reads, including q[index], m[index]
 # and qr[index]. Treating those names as host quote operators hides calls in
 # the index expression from the helper-context scan.
 return undef unless $open =~ m{[/|\{<]}o;
 my $prefix = substr($text, 0, $start);
 return undef unless $prefix =~ /(?:\A|[^\w\$:\.])(?<op>q[qwxr]?|m|s|tr|y)\s*\z/o;
 my $segments = $+{op} =~ /\A(?:s|tr|y)\z/o ? 2 : 1;
 my %paired = ('{' => '}', '<' => '>');
 my $close = $paired{$open} // $open;
 my $pos = $start;
 for my $segment (1 .. $segments) {
  my $depth = 1;
  while (++$pos < length($text)) {
   my $char = substr($text, $pos, 1);
   if ($char eq '\\') { ++$pos; next }
   ++$depth if exists($paired{$open}) && $char eq $open;
   last if $char eq $close && --$depth == 0;
  }
  if ($segment < $segments && exists($paired{$open})) {
   ++$pos while $pos + 1 < length($text) && substr($text, $pos + 1, 1) =~ /\s/o;
   return length($text) unless substr($text, $pos + 1, 1) eq $open;
   ++$pos;
  }
 }
 return $pos + 1;
}

# This recognizer admits a complete regex token in a helper's pattern position.
# In particular, an array argument may contain both /(14,2) and host arithmetic
# such as 14/cos; merging those into one /.../cos token changes accepted values.
sub _helper_pattern_tail {
 my ($text, $end, $frame) = @_;
 return 0 unless $frame && $frame->{open} eq '(';
 my $method = $frame->{method} // '';
 $method =~ s/\A__array_value_(split_each|filter_match)\z/$1/o;
 my $argument = scalar(@{$frame->{args}});
 my $receiver = $frame->{receiver};
 my $tail = substr($text, $end);
 if ($method eq 'matches') {
  return $argument == ($receiver ? 0 : 1) && $tail =~ /\A\s*\)/o;
 }
 if ($method eq 'split' || $method eq 'split_each' || $method eq 'filter_match') {
  my $position = $receiver ? $argument == 0 : ($argument == 1 || $argument == 2);
  return $position && $tail =~ /\A\s*\)/o;
 }
 if ($method eq 'regex_subst' || $method eq 'substr') {
  return 0 if $receiver || ($argument != 1 && $argument != 2);
  return 0 if grep { $_ !~ /\A:?\w+\z/o } @{$frame->{args}};
  # The existing substitution contract requires a literal replacement and a
  # separate flags argument. A slash in another numeric argument cannot supply
  # the pattern terminator by consuming that replacement.
  return $tail =~ /\A\s*,\s*(?:"(?:\\.|[^"])*"|'(?:\\.|[^'])*'|\/(?:\\.|[^\/])*\/)\s*,\s*\w*\s*\)/so;
 }
 return 0;
}

sub _helper_pattern_ranges {
 my ($text, $callable_signatures) = @_;
 my @ranges;
 return \@ranges if index($text, '/') < 0
  || $text !~ /\b(?:matches|split|(?:__array_value_)?(?:split_each|filter_match)|regex_subst|substr)\s*\(/o;
 my @scopes;
 my $len = length($text);
 my $in_callable_signature = 0;
 for (my $pos = 0; $pos < $len; ++$pos) {
  my $char = substr($text, $pos, 1);
  # Compiler membership opts in to the splitter's exact unquoted {| pipes.
  # Genuine host quotes consume their payload before either pipe is reached.
  # Keep the default structural/operand query's lexical policy unchanged.
  if ($callable_signatures && $char eq '|') {
   if ($in_callable_signature) {
    $in_callable_signature = 0;
    next;
   }
   if ($pos > 0 && substr($text, $pos - 1, 1) eq '{') {
    $in_callable_signature = 1;
    next;
   }
  }
  my $host_end = _host_quote_end($text, $pos);
  if (defined($host_end)) { $pos = $host_end - 1; next }
  if ($char eq '"' || $char eq "'" || $char eq '`') {
   my $quote = $char;
   while (++$pos < $len) {
    my $quoted = substr($text, $pos, 1);
    if ($quoted eq '\\') { ++$pos; next }
    last if $quoted eq $quote;
   }
   next;
  }
  if ($char eq '#') {
   ++$pos while $pos < $len && substr($text, $pos, 1) ne "\n";
   next;
  }
  if ($char eq '/') {
   my $frame = @scopes ? $scopes[-1] : undef;
   my $at_argument = $frame && $frame->{open} eq '('
    && substr($text, $frame->{argument_start}, $pos - $frame->{argument_start}) =~ /\A\s*\z/o;
   my $end = _slash_literal_end($text, $pos);
   if ($at_argument && defined($end) && _helper_pattern_tail($text, $end, $frame)
       && _pattern_stays_in_operand($text, $pos, $end)) {
    push @ranges, [$pos, $end];
    $pos = $end - 1;
    next;
   }
   my $prefix = substr($text, 0, $pos);
   if (defined($end) && !_looks_like_slash_symbol_call_at($text, $pos, 1)
       && $prefix =~ /(?:\A\s*|[\(\[,=~!]\s*)\z/o) {
    $pos = $end - 1;
    next;
   }
  }
  if ($char =~ /[\(\[\{]/o) {
   my $prefix = substr($text, 0, $pos);
   my ($receiver, $method) = $prefix =~ /(\.\s*)?([A-Za-z_]\w*)\s*\z/o;
   push @scopes, { open => $char, method => $method, receiver => defined($receiver),
    argument_start => $pos + 1, args => [] };
   next;
  }
  if ($char =~ /[\)\]\}]/o) {
   my %opening = (')' => '(', ']' => '[', '}' => '{');
   if (@scopes && $scopes[-1]{open} eq $opening{$char}) { pop @scopes }
   else { @scopes = () }
   next;
  }
  if ($char eq ',' && @scopes && $scopes[-1]{open} eq '(') {
   my $frame = $scopes[-1];
   push @{$frame->{args}}, _trim_method_expr_value(
    substr($text, $frame->{argument_start}, $pos - $frame->{argument_start}));
   $frame->{argument_start} = $pos + 1;
  }
 }
 return \@ranges;
}

sub _helper_pattern_view {
 my ($text) = @_;
 my $view = $text;
 for my $range (@{_helper_pattern_ranges($text)}) {
  my ($start, $end) = @$range;
  my $mask = substr($text, $start, $end - $start);
  $mask =~ s/[^\r\n]/ /g;
  substr($mask, 0, 1) = '0';
  substr($view, $start, $end - $start) = $mask;
 }
 return $view;
}

sub _slash_symbol_call_end_at {
 my ($text, $idx) = @_;
 return undef unless defined $text;
 my $len = length($text);
 return undef if $idx < 0 || $idx >= $len || substr($text, $idx, 1) ne '/';

 my $cursor = $idx + 1;
 ++$cursor while $cursor < $len && substr($text, $cursor, 1) =~ /\s/o;
 return undef unless $cursor < $len && substr($text, $cursor, 1) eq '(';

 my $depth = 0;
 my $in_single_quote = 0;
 my $in_double_quote = 0;
 my $escape_next = 0;

 for (my $pos = $cursor; $pos < $len; ++$pos) {
  my $char = substr($text, $pos, 1);

  if ($in_single_quote) {
   if ($escape_next) {
    $escape_next = 0;
   } elsif ($char eq '\\') {
    $escape_next = 1;
   } elsif ($char eq "'") {
    $in_single_quote = 0;
   }
   next;
  }
  if ($in_double_quote) {
   if ($escape_next) {
    $escape_next = 0;
   } elsif ($char eq '\\') {
    $escape_next = 1;
   } elsif ($char eq '"') {
    $in_double_quote = 0;
   }
   next;
  }

  if ($char eq "'") {
   $in_single_quote = 1;
   next;
  }
  if ($char eq '"') {
   $in_double_quote = 1;
   next;
  }
  if ($char eq '\\') {
   ++$pos;
   next;
  }
  if ($char eq '(') {
   ++$depth;
   next;
  }
  if ($char eq ')') {
   --$depth if $depth > 0;
   next unless $depth == 0;

   return $pos + 1;
  }
 }

 return undef
}

sub _looks_like_slash_symbol_call_at {
 my ($text, $idx, $numeric_only) = @_;
 my $after = _slash_symbol_call_end_at($text, $idx);
 return 0 unless defined $after;
 my $len = length($text);
 ++$after while $after < $len && substr($text, $after, 1) =~ /\s/o;
 if (!$numeric_only && $after < $len && substr($text, $after, 1) =~ /[,\.]/o) {
  return 0 if grep { $_->[0] == $idx } @{_helper_pattern_ranges($text)};
 }
 return 1 if $after >= $len || substr($text, $after, 1) =~ /[,;\.\)\]]/o;
 return 0;
}

#------------------------------------------------------------------------------
# Function: _split_top_level_csv
# Purpose : Split comma-separated argument lists while honoring nested scopes
#           and quoted-string regions.
# Args    : ($text, $method?) — a leading dot marks receiver-call context
# Returns : arrayref of trimmed argument strings
#------------------------------------------------------------------------------
sub _split_top_level_csv {
 my ($text, $method) = @_;
 return [] unless defined $text;

 my $prefix = defined($method) ? "$method(" : '';
 my $view = _helper_pattern_view($prefix . $text . (length($prefix) ? ')' : ''));
 $view = substr($view, length($prefix), length($text));

 my @parts;
 my @source_frames;
 my $current = '';
 my $paren_depth = 0;
 my $brace_depth = 0;
 my $bracket_depth = 0;
 my $in_single_quote = 0;
 my $in_double_quote = 0;
 my $in_slash_quote = 0;
 my $slash_escape_next = 0;
 my $escape_next = 0;
 my $idx = -1;
 my $piece_start = 0;

 foreach my $char (split //, $view) {
  ++$idx;
  if ($in_slash_quote) {
   $current .= $char;
   if ($slash_escape_next) {
    $slash_escape_next = 0;
   } elsif ($char eq '\\') {
    $slash_escape_next = 1;
   } elsif ($char eq '/') {
    $in_slash_quote = 0;
   }
   next;
  }
  if ($in_single_quote) {
   $current .= $char;
   if ($escape_next) {
    $escape_next = 0;
   } elsif ($char eq '\\') {
    $escape_next = 1;
   } elsif ($char eq "'") {
    $in_single_quote = 0;
   }
   next;
  }

  if ($in_double_quote) {
   $current .= $char;
   if ($escape_next) {
    $escape_next = 0;
   } elsif ($char eq '\\') {
    $escape_next = 1;
   } elsif ($char eq '"') {
    $in_double_quote = 0;
   }
   next;
  }

  if ($char eq "'") {
   $in_single_quote = 1;
   $current .= $char;
   next;
  }
  if ($char eq '"') {
   $in_double_quote = 1;
   $current .= $char;
   next;
  }
  if ($char eq '/') {
   my $current_context = $current;
   $current_context =~ s/\s+$//o;
   if (!length($current_context) && !_looks_like_slash_symbol_call_at($text, $idx)) {
    $in_slash_quote = 1;
    $slash_escape_next = 0;
    $current .= $char;
    next;
   }
  }
  if ($char eq '(') {
   ++$paren_depth;
   $current .= $char;
   next;
  }
  if ($char eq ')') {
   --$paren_depth if $paren_depth > 0;
   $current .= $char;
   next;
  }
  if ($char eq '{') {
   ++$brace_depth;
   $current .= $char;
   next;
  }
  if ($char eq '}') {
   --$brace_depth if $brace_depth > 0;
   $current .= $char;
   next;
  }
  if ($char eq '[') {
   ++$bracket_depth;
   $current .= $char;
   next;
  }
  if ($char eq ']') {
   --$bracket_depth if $bracket_depth > 0;
   $current .= $char;
   next;
  }
  if ($char eq ',' && $paren_depth == 0 && $brace_depth == 0 && $bracket_depth == 0) {
   my $trimmed = _trim_method_expr_value(substr($text, $piece_start, $idx - $piece_start));
   if (defined($trimmed) && length($trimmed)) {
    push @parts, $trimmed;
    push @source_frames, _frame_for_csv_piece($text, $piece_start, $idx, $trimmed)
     if ref($_source_csv_recorder) eq 'CODE';
   }
   $piece_start = $idx + 1;
   $current = '';
   next;
  }
  $current .= $char;
 }

 my $trimmed = _trim_method_expr_value(substr($text, $piece_start));
 if (defined($trimmed) && length($trimmed)) {
  push @parts, $trimmed;
  push @source_frames, _frame_for_csv_piece($text, $piece_start, length($text), $trimmed)
   if ref($_source_csv_recorder) eq 'CODE';
 }
 $_source_csv_recorder->({arguments => \@parts, source => $text, source_frames => \@source_frames})
  if ref($_source_csv_recorder) eq 'CODE';
 return \@parts
}

#------------------------------------------------------------------------------
# Function: _parse_method_function_expr
# Purpose : Parse `method(arg1, arg2, ...)` expressions with nested-paren args.
# Args    : ($expr, $receiver?)
# Returns : hashref { method => ..., args => [...] } or undef
#------------------------------------------------------------------------------
sub _parse_method_function_expr {
 my ($expr, $receiver) = @_;
 return undef unless defined $expr;
 my $trimmed = _trim_method_expr_value($expr);
 return undef unless defined($trimmed) && length($trimmed);
 my $view = _helper_pattern_view(($receiver ? '.' : '') . $trimmed);
 $view = substr($view, 1) if $receiver;
 return undef unless $view =~ /^(?<method>\w+|==|!=|>=|<=|=|[+\-*\/%<>])\s*(?<PAREN>\((?:[^\(\)\"']++|\"(?:\\.|[^\"])*\"|'(?:\\.|[^'])*'|(?&PAREN))*\))$/o;
 my $source_method = $+{method};
 my $payload_start = $-[2] + 1;
 my $method = _normalize_method_name($source_method);

 my $payload = substr($trimmed, $-[2], $+[2] - $-[2]);
 $payload =~ s/^\(|\)$//go;
 my $framed = ref($_source_method_recorder) eq 'CODE'
  ? _split_csv_with_source_frames(\&_split_top_level_csv, $payload, ($receiver ? '.' : '') . $method)
  : undef;
 my $call = {
  method        => $method,
  source_method => $source_method,
  source        => $trimmed,
  args          => $framed ? $framed->{arguments}
                   : _split_top_level_csv($payload, ($receiver ? '.' : '') . $method),
 };
 if (ref($_source_method_recorder) eq 'CODE') {
  my @frames;
  if (defined($expr) && !ref($expr)) {
   my ($leading) = $expr =~ /\A(\s*)/;
   my $base = length($leading);
   my $exact = substr($expr, $base, length($trimmed)) eq $trimmed;
   for my $frame (@{$framed->{source_frames}}) {
    if (!$exact || !defined($frame)) { push @frames, undef; next }
    my $start = $base + $payload_start + $frame->{source_span}{start};
    my $end = $base + $payload_start + $frame->{source_span}{end};
    push @frames, substr($expr, $start, $end - $start) eq $frame->{raw}
     ? {source => $expr, raw => $frame->{raw}, source_span => {start => $start, end => $end}} : undef;
   }
  }
  $_source_method_recorder->({call => $call, arguments => $call->{args}, source => $expr,
                             trimmed => $trimmed, method => $method, source_method => $source_method,
                             source_frames => \@frames});
 }
 return $call
}

#------------------------------------------------------------------------------
# Function: _is_bare_method_scope_token
# Purpose : Check whether token is a bare scope label candidate.
# Args    : ($token)
# Returns : boolean
#------------------------------------------------------------------------------
sub _is_bare_method_scope_token {
 my ($token) = @_;
 return 0 unless defined $token;
 $token = _trim_method_expr_value($token);
 return defined($token) && $token =~ /^[A-Za-z_]\w*$/o ? 1 : 0
}

#------------------------------------------------------------------------------
# Function: _normalize_method_args_with_optional_scope
# Purpose : Normalize method argument lists by stripping optional leading scope
#           token when present and validating min/max arity. Current value
#           helpers may request authored-value precedence: an already-valid
#           argument list is then returned intact before scope fallback.
# Args    : ($args, $min_arity, $max_arity, $authored_values_take_precedence)
# Returns : arrayref effective args or undef
#------------------------------------------------------------------------------
sub _normalize_method_args_with_optional_scope {
 my ($args, $min_arity, $max_arity, $authored_values_take_precedence) = @_;
 return undef unless ref($args) eq 'ARRAY';

 $min_arity = 0 unless defined $min_arity;
 $max_arity = 10**9 unless defined $max_arity;

 my $authored_count = scalar(@$args);
 if (
  $authored_values_take_precedence
  && $authored_count >= $min_arity
  && $authored_count <= $max_arity
 ) {
  return [@$args];
 }

 my @effective = @$args;
 if (
  @effective >= ($min_arity + 1) &&
  @effective <= ($max_arity + 1) &&
  _is_bare_method_scope_token($effective[0])
 ) {
  my @without_scope = @effective;
  shift @without_scope;
  if (@without_scope >= $min_arity && @without_scope <= $max_arity) {
   @effective = @without_scope;
  }
 }

 return undef unless @effective >= $min_arity && @effective <= $max_arity;
 return \@effective
}

1;
