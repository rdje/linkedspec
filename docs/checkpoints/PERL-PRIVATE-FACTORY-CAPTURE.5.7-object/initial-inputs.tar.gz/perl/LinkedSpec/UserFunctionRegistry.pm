#------------------------------------------------------------------------------
# Package: LinkedSpec::UserFunctionRegistry
# Purpose: Temporary Perl-reference bridge for top-level user function
#          definitions while specs/spec.spec remains the permanent grammar owner.
#------------------------------------------------------------------------------
package LinkedSpec::UserFunctionRegistry;

use 5.010;
BEGIN {
 require File::Basename;
 my $module_dir = (File::Basename::fileparse(__FILE__))[1];
 my $perl_root = File::Basename::dirname($module_dir);
 unshift @INC, $perl_root unless grep { defined($_) && $_ eq $perl_root } @INC;
}

use LinkedSpec::OwnerDispatch ();

my $__function_definition_parser;
my $__loading_function_definition_parser = 0;

sub empty_function_registry {
 return {
  kind => 'user_function_registry',
  version => 1,
  order => [],
  by_name => {},
 }
}

sub is_user_function_registry {
 my ($value) = @_;
 return 0 unless ref($value) eq 'HASH';
 return 0 unless defined($value->{kind}) && $value->{kind} eq 'user_function_registry';
 return 0 unless defined($value->{version}) && $value->{version} == 1;
 return 0 unless ref($value->{order}) eq 'ARRAY';
 return 0 unless ref($value->{by_name}) eq 'HASH';
 return 1
}

sub function_registry_count {
 my ($registry) = @_;
 return 0 unless is_user_function_registry($registry);
 return scalar(@{$registry->{order}})
}

sub function_registry_order {
 my ($registry) = @_;
 return [] unless is_user_function_registry($registry);
 return [@{$registry->{order}}]
}

sub function_registry_by_name {
 my ($registry) = @_;
 return {} unless is_user_function_registry($registry);
 return { %{$registry->{by_name}} }
}

sub extract_and_strip_spec_source {
 my ($spec_content_ref) = @_;
 die "(LinkedSpec::UserFunctionRegistry::extract_and_strip_spec_source) -E- expected SCALAR ref\n"
  unless ref($spec_content_ref) eq 'SCALAR';

 my $source = $$spec_content_ref;
 my $registry = empty_function_registry();
 return { stripped_source => $source, registry => $registry }
  if $__loading_function_definition_parser;

 my $definitions = _parse_function_definition_asts($spec_content_ref);
 my $stripped = $source;
 foreach my $node (@$definitions) {
  _die_function_definition_error_node($source, $node)
   if _is_function_definition_error_node($node);
  _canonicalize_codeblock_definition_ast($node);
  my $definition = _normalize_function_definition_ast($source, $node, scalar(@{$registry->{order}}));
  _record_function_definition($registry, $definition);
  my $span = $definition->{source_span};
  substr($stripped, $span->{start}, $span->{end} - $span->{start})
   = _blank_preserving_newlines(substr($source, $span->{start}, $span->{end} - $span->{start}));
 }

 return {
  stripped_source => $stripped,
  registry => $registry,
 }
}

sub _canonicalize_codeblock_definition_ast {
 my ($node) = @_;
 return unless ref($node) eq 'HASH' && exists($node->{codeblock_param});
 die "Invalid codeblock parameter declaration: version 1 is required\n"
  unless defined($node->{version}) && !ref($node->{version}) && $node->{version} == 1;

 my $fixed = _require_identifier_array_field($node, 'fixed_params');
 my $codeblock_param = _require_identifier_field($node, 'codeblock_param');
 my @params = (@$fixed, $codeblock_param);
 _normalize_parameter_kinds($node->{parameter_kinds}, \@params, 'function definition');

 foreach my $field (qw(body_payload body_parse_job)) {
  my $record = $node->{$field};
  die "Invalid user function definition AST: $field must be HASH\n"
   unless ref($record) eq 'HASH';
  my $record_fixed = _require_identifier_array_field($record, 'fixed_params');
  my $record_codeblock_param = _require_identifier_field($record, 'codeblock_param');
  die "Invalid user function definition AST: $field fixed_params mismatch\n"
   unless _arrays_equal($record_fixed, $fixed);
  die "Invalid user function definition AST: $field codeblock_param mismatch\n"
   unless $record_codeblock_param eq $codeblock_param;
  _normalize_parameter_kinds($record->{parameter_kinds}, \@params, $field);
  $record->{params} = [@params];
  $record->{arity} = scalar(@params);
  delete $record->{fixed_params};
  delete $record->{codeblock_param};
 }

 $node->{params} = [@params];
 $node->{arity} = scalar(@params);
 delete $node->{fixed_params};
 delete $node->{codeblock_param};
}

sub validate_registry_against_rule_labels {
 my ($registry, $rule_labels) = @_;
 return 1 unless is_user_function_registry($registry);
 $rule_labels = [] unless ref($rule_labels) eq 'ARRAY';
 my %rule_label = map { defined($_) && !ref($_) && length($_) ? ($_ => 1) : () } @$rule_labels;
 foreach my $name (@{$registry->{order}}) {
  next unless $rule_label{$name};
  my $definition = $registry->{by_name}{$name};
  _die_definition_error(
   $definition,
   "User function '$name' collides with rule label '$name'",
   'Choose a function name that does not reuse a rule label',
  );
 }
 return 1
}

sub _parse_function_definition_asts {
 my ($spec_content_ref) = @_;
 my $parser = _function_definition_parser();
 my $input = $$spec_content_ref;
 my $ast = eval { $parser->(\$input) };
 my $error = $@;
 if ($error) {
  die "Invalid user function definition parser failure: $error";
 }
 return [] unless defined $ast;
 die "Invalid user function definition parser result: expected ARRAY AST\n"
  unless ref($ast) eq 'ARRAY';
 return $ast
}

sub _function_definition_parser {
 return $__function_definition_parser
  if ref($__function_definition_parser) eq 'CODE';
 die "Recursive user function definition parser load\n"
  if $__loading_function_definition_parser;

 my $previous_loading_state = $__loading_function_definition_parser;
 $__loading_function_definition_parser = 1;
 my ($spec_source, $parser);
 my $load_ok = eval {
  $spec_source = _load_function_definition_spec_source();
  $parser = LinkedSpec::OwnerDispatch::dispatch_owner_call(
   __PACKAGE__,
   'LinkedSpec',
   'Get',
   \$spec_source,
   top_rule => 'user_function_definitions',
  );
  1
 };
 my $load_error = $@;
 $__loading_function_definition_parser = $previous_loading_state;
 die $load_error unless $load_ok;
 die "Could not compile specs/user_function_definition.spec into a parser\n"
  unless ref($parser) eq 'CODE';
 $__function_definition_parser = $parser;
 return $__function_definition_parser
}

sub _load_function_definition_spec_source {
 my $path = _function_definition_spec_path();
 open my $fh, '<', $path
  or die "Could not read user function definition spec '$path': $!\n";
 local $/;
 return <$fh>
}

sub _function_definition_spec_path {
 require Cwd;
 require File::Basename;
 require File::Spec;
 my $module_file = Cwd::abs_path(__FILE__) || __FILE__;
 my $module_dir = (File::Basename::fileparse($module_file))[1];
 my $perl_root = File::Basename::dirname($module_dir);
 my $repo_root = File::Basename::dirname($perl_root);
 return File::Spec->catfile($repo_root, 'specs', 'user_function_definition.spec')
}

sub _normalize_function_definition_ast {
 my ($source, $node, $ordinal) = @_;
 die "Invalid user function definition AST: expected HASH node\n"
  unless ref($node) eq 'HASH';
 die "Invalid user function definition AST: expected type=function_definition\n"
  unless ($node->{type} // '') eq 'function_definition';
 die "Invalid user function definition AST: expected kind=user_function_definition\n"
  unless ($node->{kind} // '') eq 'user_function_definition';

 my $name = _require_identifier_field($node, 'name');
 my $version = _require_integer_field($node, 'version');
 die "Invalid user function definition AST for '$name': unsupported version $version\n"
  unless $version == 1 || $version == 2;

 my ($params, $arity, $signature, $parameter_kinds);
 if ($version == 1) {
  $params = _require_identifier_array_field($node, 'params');
  $arity = _require_integer_field($node, 'arity');
  die "Invalid user function definition AST for '$name': arity does not match params\n"
   unless $arity == scalar(@$params);
  $parameter_kinds = _normalize_parameter_kinds($node->{parameter_kinds}, $params, "function '$name'")
   if exists($node->{parameter_kinds});
 } else {
  die "Invalid user function definition AST for '$name': version 2 uses signature instead of params/arity\n"
   if exists($node->{params}) || exists($node->{arity});
  $signature = _normalize_callable_signature($node->{signature}, "function '$name'");
  $params = $signature->{positional_params};
  $arity = $signature->{min_arity};
 }

 my $source_span = _require_span_field($node, 'source_span');
 my $body_span = _require_span_field($node, 'body_span');
 my $body_source = _require_string_field($node, 'body_source');
 my $body_payload = _normalize_body_payload($node->{body_payload}, $name, $version, $params, $arity, $signature, $parameter_kinds, $body_source, $body_span, $ordinal);
 my $body_parse_job = _normalize_body_parse_job($node->{body_parse_job}, $name, $version, $params, $arity, $signature, $parameter_kinds, $body_source, $body_span, $ordinal);
 _validate_function_body_action_surface($name, $body_source, $source, $source_span);

 my %seen;
 foreach my $param (@$params) {
  _die_parse_error_at_span($source, $source_span, "duplicate parameter '$param' in function '$name'")
   if $seen{$param}++;
 }
 if ($version == 2) {
  my $rest_param = $signature->{rest_param};
  _die_parse_error_at_span($source, $source_span, "duplicate parameter '$rest_param' in function '$name'")
   if $seen{$rest_param}++;
 }

 my $definition = {
  kind => 'user_function_definition',
  version => $version,
  name => $name,
  source_text => defined($node->{source_text}) && !ref($node->{source_text}) ? $node->{source_text} : '',
  source_span => $source_span,
  body_span => $body_span,
  body_source => $body_source,
  body_payload => $body_payload,
  body_parse_job => $body_parse_job,
  body_ast => _parse_function_body_ast($name, $body_parse_job, $source, $source_span),
 };
 if ($version == 1) {
  $definition->{params} = [@$params];
  $definition->{arity} = $arity;
  $definition->{parameter_kinds} = { %$parameter_kinds } if ref($parameter_kinds) eq 'HASH';
 } else {
  $definition->{signature} = _clone_plain($signature);
 }

 _validate_function_name($definition);
 foreach my $param (@$params) {
  _validate_parameter_name($definition, $param);
 }
 _validate_parameter_name($definition, $signature->{rest_param})
  if $version == 2;
 return $definition
}

sub _normalize_body_payload {
 my ($payload, $name, $version, $params, $arity, $signature, $parameter_kinds, $body_source, $body_span, $ordinal) = @_;
 die "Invalid user function definition AST: body_payload must be HASH\n"
  unless ref($payload) eq 'HASH';
 die "Invalid user function definition AST: body_payload.kind must be staged_payload\n"
  unless ($payload->{kind} // '') eq 'staged_payload';
 die "Invalid user function definition AST: body_payload.node_kind must be function_definition\n"
  unless ($payload->{node_kind} // '') eq 'function_definition';
 die "Invalid user function definition AST: body_payload.payload_kind must be function_body\n"
  unless ($payload->{payload_kind} // '') eq 'function_body';

 my $payload_name = _require_string_field($payload, 'function_name');
 die "Invalid user function definition AST: body_payload function name mismatch\n"
  unless $payload_name eq $name;
 if ($version == 1) {
  my $payload_params = _require_identifier_array_field($payload, 'params');
  die "Invalid user function definition AST: body_payload params mismatch\n"
   unless _arrays_equal($payload_params, $params);
  my $payload_arity = _require_integer_field($payload, 'arity');
  die "Invalid user function definition AST: body_payload arity mismatch\n"
   unless $payload_arity == $arity;
  if (ref($parameter_kinds) eq 'HASH') {
   my $payload_kinds = _normalize_parameter_kinds($payload->{parameter_kinds}, $params, 'body_payload');
   die "Invalid user function definition AST: body_payload parameter kinds mismatch\n"
    unless _parameter_kinds_equal($payload_kinds, $parameter_kinds);
  } elsif (exists($payload->{parameter_kinds})) {
   die "Invalid user function definition AST: untyped body_payload has parameter_kinds\n";
  }
 } else {
  die "Invalid user function definition AST: version 2 body_payload uses signature instead of params/arity\n"
   if exists($payload->{params}) || exists($payload->{arity});
  my $payload_signature = _normalize_callable_signature($payload->{signature}, 'body_payload');
  die "Invalid user function definition AST: body_payload signature mismatch\n"
   unless _callable_signatures_equal($payload_signature, $signature);
 }
 my $payload_text = _require_string_field($payload, 'text');
 die "Invalid user function definition AST: body_payload text mismatch\n"
  unless $payload_text eq $body_source;
 my $payload_span = _require_span_field($payload, 'source_span');
 die "Invalid user function definition AST: body_payload span mismatch\n"
  unless _spans_equal($payload_span, $body_span);

 my $out = _clone_plain($payload);
 $out->{parent_ast_path} = _body_parent_ast_path($ordinal);
 return $out
}

sub _normalize_body_parse_job {
 my ($job, $name, $version, $params, $arity, $signature, $parameter_kinds, $body_source, $body_span, $ordinal) = @_;
 die "Invalid user function definition AST: body_parse_job must be HASH\n"
  unless ref($job) eq 'HASH';
 die "Invalid user function definition AST: body_parse_job.kind must be parse_job\n"
  unless ($job->{kind} // '') eq 'parse_job';
 die "Invalid user function definition AST: body_parse_job.node_kind must be function_definition\n"
  unless ($job->{node_kind} // '') eq 'function_definition';
 die "Invalid user function definition AST: body_parse_job.payload_kind must be function_body\n"
  unless ($job->{payload_kind} // '') eq 'function_body';

 my $job_id = _require_string_field($job, 'job_id');
 die "Invalid user function definition AST: body_parse_job.job_id must be non-empty\n"
  unless length($job_id);
 my $parent_path = _require_string_array_field($job, 'parent_ast_path');
 die "Invalid user function definition AST: body_parse_job parent path must target functions[*].body_source\n"
  unless @$parent_path == 3 && $parent_path->[0] eq 'functions' && $parent_path->[2] eq 'body_source';
 my $job_name = _require_string_field($job, 'function_name');
 die "Invalid user function definition AST: body_parse_job function name mismatch\n"
  unless $job_name eq $name;
 if ($version == 1) {
  my $job_params = _require_identifier_array_field($job, 'params');
  die "Invalid user function definition AST: body_parse_job params mismatch\n"
   unless _arrays_equal($job_params, $params);
  my $job_arity = _require_integer_field($job, 'arity');
  die "Invalid user function definition AST: body_parse_job arity mismatch\n"
   unless $job_arity == $arity;
  if (ref($parameter_kinds) eq 'HASH') {
   my $job_kinds = _normalize_parameter_kinds($job->{parameter_kinds}, $params, 'body_parse_job');
   die "Invalid user function definition AST: body_parse_job parameter kinds mismatch\n"
    unless _parameter_kinds_equal($job_kinds, $parameter_kinds);
  } elsif (exists($job->{parameter_kinds})) {
   die "Invalid user function definition AST: untyped body_parse_job has parameter_kinds\n";
  }
 } else {
  die "Invalid user function definition AST: version 2 body_parse_job uses signature instead of params/arity\n"
   if exists($job->{params}) || exists($job->{arity});
  my $job_signature = _normalize_callable_signature($job->{signature}, 'body_parse_job');
  die "Invalid user function definition AST: body_parse_job signature mismatch\n"
   unless _callable_signatures_equal($job_signature, $signature);
 }
 my $job_text = _require_string_field($job, 'text');
 die "Invalid user function definition AST: body_parse_job text mismatch\n"
  unless $job_text eq $body_source;
 my $job_span = _require_span_field($job, 'source_span');
 die "Invalid user function definition AST: body_parse_job span mismatch\n"
  unless _spans_equal($job_span, $body_span);
 die "Invalid user function definition AST: body_parse_job.parser_spec_id must be actionir-body.spec\n"
  unless _require_string_field($job, 'parser_spec_id') eq 'actionir-body.spec';
 die "Invalid user function definition AST: body_parse_job.top_rule must be action_block\n"
  unless _require_string_field($job, 'top_rule') eq 'action_block';
 die "Invalid user function definition AST: body_parse_job.result_policy must be replace_field\n"
  unless _require_string_field($job, 'result_policy') eq 'replace_field';
 die "Invalid user function definition AST: body_parse_job.result_field must be body_ast\n"
  unless _require_string_field($job, 'result_field') eq 'body_ast';
 die "Invalid user function definition AST: body_parse_job.failure_policy must be fail\n"
  unless _require_string_field($job, 'failure_policy') eq 'fail';
 die "Invalid user function definition AST: body_parse_job.diagnostic_owner must be function_body\n"
  unless _require_string_field($job, 'diagnostic_owner') eq 'function_body';

 my $out = _clone_plain($job);
 $out->{parent_ast_path} = _body_parent_ast_path($ordinal);
 $out->{job_id} = _body_parse_job_id($out->{parent_ast_path}, $out->{payload_kind}, $out->{parser_spec_id}, $out->{top_rule}, $job_span);
 return $out
}

sub _normalize_parameter_kinds {
 my ($kinds, $params, $owner) = @_;
 $owner = 'parameter_kinds' unless defined($owner) && length($owner);
 die "Invalid user function definition AST: $owner parameter_kinds must be HASH\n"
  unless ref($kinds) eq 'HASH';
 die "Invalid user function definition AST: $owner must declare exactly one parameter kind\n"
  unless keys(%$kinds) == 1;
 die "Invalid user function definition AST: $owner codeblock parameter must be final\n"
  unless ref($params) eq 'ARRAY' && @$params;
 my $name = $params->[-1];
 die "Invalid user function definition AST: $owner final parameter must have kind codeblock\n"
  unless ($kinds->{$name} // '') eq 'codeblock';
 return { $name => 'codeblock' }
}

sub _parameter_kinds_equal {
 my ($left, $right) = @_;
 return 0 unless ref($left) eq 'HASH' && ref($right) eq 'HASH';
 return 0 unless keys(%$left) == keys(%$right);
 foreach my $name (keys %$left) {
  return 0 unless exists($right->{$name}) && ($left->{$name} // '') eq ($right->{$name} // '');
 }
 return 1
}

sub _normalize_callable_signature {
 my ($signature, $owner) = @_;
 $owner = 'callable signature' unless defined($owner) && length($owner);
 die "Invalid user function definition AST: $owner signature must be HASH\n"
  unless ref($signature) eq 'HASH';
 die "Invalid user function definition AST: $owner signature kind must be callable_signature\n"
  unless ($signature->{kind} // '') eq 'callable_signature';
 die "Invalid user function definition AST: $owner signature version must be 1\n"
  unless _require_integer_field($signature, 'version') == 1;

 my $params = _require_identifier_array_field($signature, 'positional_params');
 my $rest_param = _require_identifier_field($signature, 'rest_param');
 my $min_arity = _require_integer_field($signature, 'min_arity');
 die "Invalid user function definition AST: $owner signature min_arity mismatch\n"
  unless $min_arity == scalar(@$params);
 die "Invalid user function definition AST: $owner signature missing max_arity\n"
  unless exists($signature->{max_arity});
 die "Invalid user function definition AST: $owner variadic max_arity must be null\n"
  if defined($signature->{max_arity});

 return {
  kind => 'callable_signature',
  version => 1,
  positional_params => [@$params],
  rest_param => $rest_param,
  min_arity => $min_arity,
  max_arity => undef,
 }
}

sub _callable_signatures_equal {
 my ($left, $right) = @_;
 return 0 unless ref($left) eq 'HASH' && ref($right) eq 'HASH';
 return 0 unless ($left->{kind} // '') eq ($right->{kind} // '');
 return 0 unless ($left->{version} // '') eq ($right->{version} // '');
 return 0 unless _arrays_equal($left->{positional_params}, $right->{positional_params});
 return 0 unless ($left->{rest_param} // '') eq ($right->{rest_param} // '');
 return 0 unless ($left->{min_arity} // '') eq ($right->{min_arity} // '');
 return 0 if defined($left->{max_arity}) || defined($right->{max_arity});
 return 1
}

sub _body_parent_ast_path {
 my ($ordinal) = @_;
 return ['functions', "$ordinal", 'body_source']
}

sub _body_parse_job_id {
 my ($parent_path, $payload_kind, $parser_spec_id, $top_rule, $span) = @_;
 my $path_text = join('.', @$parent_path);
 return join(':',
  'parse_job',
  $payload_kind,
  $path_text,
  $parser_spec_id,
  $top_rule,
  ($span->{start} // 0).'-'.($span->{end} // 0),
 )
}

sub _record_function_definition {
 my ($registry, $definition) = @_;
 die "(LinkedSpec::UserFunctionRegistry::_record_function_definition) -E- invalid registry\n"
  unless is_user_function_registry($registry);
 die "(LinkedSpec::UserFunctionRegistry::_record_function_definition) -E- invalid function definition\n"
  unless ref($definition) eq 'HASH' && ($definition->{kind} // '') eq 'user_function_definition';
 my $name = $definition->{name};
 if (exists $registry->{by_name}{$name}) {
  _die_definition_error(
   $definition,
   "Duplicate user function definition '$name'",
   'Remove the duplicate function or rename one of them',
  );
 }
 push @{$registry->{order}}, $name;
 $registry->{by_name}{$name} = $definition;
 return 1
}

sub _parse_function_body_ast {
 my ($name, $body_parse_job, $source, $source_span) = @_;
 my $body_ast = eval {
  return LinkedSpec::OwnerDispatch::dispatch_owner_call(
   __PACKAGE__,
   'LinkedSpec::StagedParserRegistry',
   'execute_parse_job',
   $body_parse_job,
  )
 };
 my $error = $@;
 if ($error) {
  _die_parse_error_at_span($source, $source_span, "could not dispatch staged body parse job for function '$name': $error");
 }
 return $body_ast
}

sub _validate_function_body_action_surface {
 my ($name, $body_source, $source, $source_span) = @_;
 my $ok = eval {
  LinkedSpec::OwnerDispatch::dispatch_owner_call(
   __PACKAGE__,
   'LinkedSpec::ActionIR::RewritePipeline',
   '_reject_removed_aggregate_selectors_in_action_code',
   $body_source,
  );
  1
 };
 return 1 if $ok;
 my $error = $@;
 _die_parse_error_at_span(
  $source,
  $source_span,
  "invalid ActionIR body for function '$name': $error",
 )
}

sub _is_function_definition_error_node {
 my ($node) = @_;
 return ref($node) eq 'HASH' && ($node->{type} // '') eq 'function_definition_error'
}

sub _die_function_definition_error_node {
 my ($source, $node) = @_;
 my $span = ref($node->{source_span}) eq 'HASH'
  ? _span_or_default($node->{source_span})
  : { start => 0, end => 0, line_start => 1, line_end => 1 };
 my $message = defined($node->{message}) && !ref($node->{message}) && length($node->{message})
  ? $node->{message}
  : 'invalid user function definition';
 my $text = defined($node->{source_text}) && !ref($node->{source_text}) ? $node->{source_text} : '';
 my $header = $text;
 $header =~ s/\{.*\z//s;
 $message = 'codeblock_declaration_has_no_argument_list'
  if $header =~ /:\s*codeblock\s*\(/;
 $message = 'codeblock_parameter_must_be_final'
  if $header =~ /:\s*codeblock\s*,/;
 $message = 'invalid_codeblock_parameter_name'
  if $header =~ /\(\s*:\s*codeblock\b/;
 $message = 'unknown_parameter_type'
  if $header =~ /:\s*(?!codeblock\b)[A-Za-z_][A-Za-z0-9_]*\b/;
 _die_parse_error_at_span($source, $span, $message);
}

sub _validate_function_name {
 my ($definition) = @_;
 my $name = $definition->{name};
 _die_definition_error($definition, "Invalid user function name '$name'", 'Use a valid identifier')
  unless _is_identifier($name);
 if (_is_reserved_runtime_symbol($name)) {
  _die_definition_error($definition, "User function '$name' uses a reserved runtime symbol", 'Choose a non-reserved function name');
 }
 if (_is_lifecycle_marker_name($name)) {
  _die_definition_error($definition, "User function '$name' collides with lifecycle marker '$name'", 'Choose a non-lifecycle function name');
 }
 my $known = _known_actionir_call_name($name);
 if (defined($known) && length($known)) {
  _die_definition_error($definition, "User function '$name' collides with built-in helper/control name '$name'", 'Choose a function name outside the built-in helper surface');
 }
 return 1
}

sub _validate_parameter_name {
 my ($definition, $param) = @_;
 _die_definition_error($definition, "User function '$definition->{name}' has invalid parameter '$param'", 'Use valid parameter identifiers')
  unless _is_identifier($param);
 if (_is_reserved_runtime_symbol($param) || _is_lifecycle_marker_name($param) || _is_function_keyword($param)) {
  _die_definition_error($definition, "User function '$definition->{name}' parameter '$param' is reserved", 'Choose a non-reserved parameter name');
 }
 return 1
}

sub _known_actionir_call_name {
 my ($name) = @_;
 return undef unless defined($name) && length($name);
 return LinkedSpec::OwnerDispatch::call_preserving_err(sub {
  LinkedSpec::OwnerDispatch::require_pkg(__PACKAGE__, 'LinkedSpec::ActionIR::MethodLowering');
  no strict 'refs';
  return LinkedSpec::ActionIR::MethodLowering::_actionir_ast_known_value_call_method($name);
 })
}

sub _is_function_keyword {
 my ($name) = @_;
 return 0 unless defined($name);
 state %reserved = map { $_ => 1 } qw(fn return);
 return $reserved{$name} ? 1 : 0
}

sub _is_lifecycle_marker_name {
 my ($name) = @_;
 return 0 unless defined($name);
 state %markers = map { $_ => 1 } qw(I LS LE E EX IT LX);
 return $markers{$name} ? 1 : 0
}

sub _is_reserved_runtime_symbol {
 my ($name) = @_;
 return 0 unless defined($name);
 state %reserved = map { $_ => 1 } qw(
  STRING descr minfo LSPOS LEPOS LMATCH LSMATCH IMATCH
  IMATCH_LIST LMATCH_LIST IMATCH_HASH LMATCH_HASH
  SELF this ctx runtime_ctx
 );
 return $reserved{$name} ? 1 : 0
}

sub _is_identifier {
 my ($value) = @_;
 return defined($value) && !ref($value) && $value =~ /\A[A-Za-z_][A-Za-z0-9_]*\z/o ? 1 : 0
}

sub _require_identifier_field {
 my ($node, $field) = @_;
 my $value = _require_string_field($node, $field);
 die "Invalid user function definition AST: field '$field' is not an identifier\n"
  unless _is_identifier($value);
 return $value
}

sub _require_string_field {
 my ($node, $field) = @_;
 die "Invalid user function definition AST: missing field '$field'\n"
  unless ref($node) eq 'HASH' && exists($node->{$field});
 die "Invalid user function definition AST: field '$field' must be scalar text\n"
  if ref($node->{$field});
 return defined($node->{$field}) ? "$node->{$field}" : ''
}

sub _require_integer_field {
 my ($node, $field) = @_;
 die "Invalid user function definition AST: missing integer field '$field'\n"
  unless ref($node) eq 'HASH' && exists($node->{$field});
 my $value = $node->{$field};
 die "Invalid user function definition AST: field '$field' must be integer\n"
  unless defined($value) && !ref($value) && $value =~ /\A\d+\z/o;
 return 0 + $value
}

sub _require_identifier_array_field {
 my ($node, $field) = @_;
 die "Invalid user function definition AST: missing array field '$field'\n"
  unless ref($node) eq 'HASH' && exists($node->{$field});
 die "Invalid user function definition AST: field '$field' must be ARRAY\n"
  unless ref($node->{$field}) eq 'ARRAY';
 my @values;
 foreach my $value (@{$node->{$field}}) {
  die "Invalid user function definition AST: field '$field' contains a non-identifier\n"
   unless _is_identifier($value);
  push @values, "$value";
 }
 return \@values
}

sub _require_string_array_field {
 my ($node, $field) = @_;
 die "Invalid user function definition AST: missing array field '$field'\n"
  unless ref($node) eq 'HASH' && exists($node->{$field});
 die "Invalid user function definition AST: field '$field' must be ARRAY\n"
  unless ref($node->{$field}) eq 'ARRAY';
 my @values;
 foreach my $value (@{$node->{$field}}) {
  die "Invalid user function definition AST: field '$field' contains a non-scalar value\n"
   if ref($value);
  push @values, defined($value) ? "$value" : '';
 }
 return \@values
}

sub _require_span_field {
 my ($node, $field) = @_;
 die "Invalid user function definition AST: missing span field '$field'\n"
  unless ref($node) eq 'HASH' && exists($node->{$field});
 die "Invalid user function definition AST: field '$field' must be HASH span\n"
  unless ref($node->{$field}) eq 'HASH';
 return _span_or_default($node->{$field}, $field)
}

sub _span_or_default {
 my ($span, $field) = @_;
 my %out;
 foreach my $key (qw(start end line_start line_end)) {
  die "Invalid user function definition AST: span '$field' missing '$key'\n"
   unless exists($span->{$key});
  die "Invalid user function definition AST: span '$field' '$key' must be integer\n"
   unless defined($span->{$key}) && !ref($span->{$key}) && $span->{$key} =~ /\A\d+\z/o;
  $out{$key} = 0 + $span->{$key};
 }
 return \%out
}

sub _arrays_equal {
 my ($left, $right) = @_;
 return 0 unless ref($left) eq 'ARRAY' && ref($right) eq 'ARRAY';
 return 0 unless @$left == @$right;
 for (my $i = 0; $i < @$left; ++$i) {
  return 0 unless (defined($left->[$i]) ? $left->[$i] : '') eq (defined($right->[$i]) ? $right->[$i] : '');
 }
 return 1
}

sub _spans_equal {
 my ($left, $right) = @_;
 return 0 unless ref($left) eq 'HASH' && ref($right) eq 'HASH';
 foreach my $key (qw(start end line_start line_end)) {
  return 0 unless ($left->{$key} // '') eq ($right->{$key} // '');
 }
 return 1
}

sub _clone_plain {
 my ($value) = @_;
 return [map { _clone_plain($_) } @$value] if ref($value) eq 'ARRAY';
 if (ref($value) eq 'HASH') {
  my %copy;
  foreach my $key (keys %$value) {
   $copy{$key} = _clone_plain($value->{$key});
  }
  return \%copy
 }
 return $value
}

sub _blank_preserving_newlines {
 my ($text) = @_;
 $text = '' unless defined $text;
 $text =~ s/[^\n]/ /go;
 return $text
}

sub _line_number_at {
 my ($source, $idx) = @_;
 $idx = 0 unless defined $idx;
 $idx = 0 if $idx < 0;
 $idx = length($source) if $idx > length($source);
 my $prefix = substr($source, 0, $idx);
 return 1 + ($prefix =~ tr/\n//)
}

sub _die_parse_error_at_span {
 my ($source, $span, $reason) = @_;
 my $line = (ref($span) eq 'HASH' && $span->{line_start})
  ? $span->{line_start}
  : _line_number_at($source, 0);
 die "Invalid user function definition at line $line: $reason\n";
}

sub _die_definition_error {
 my ($definition, $summary, $suggestion) = @_;
 my $line = (ref($definition) eq 'HASH' && ref($definition->{source_span}) eq 'HASH')
  ? ($definition->{source_span}{line_start} || 0)
  : 0;
 my $detail = $summary;
 $detail .= " at line $line" if $line;
 $detail .= ". $suggestion" if defined($suggestion) && length($suggestion);
 die "$detail\n";
}

1;
