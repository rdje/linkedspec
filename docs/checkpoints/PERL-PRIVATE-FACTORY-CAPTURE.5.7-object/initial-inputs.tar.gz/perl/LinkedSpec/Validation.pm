#------------------------------------------------------------------------------
# Package: LinkedSpec::Validation
# Purpose: Frontend validation owner for early `.spec` envelope, rule-paragraph,
#          edge-target, and reference diagnostics before bootstrap/runtime work.
#------------------------------------------------------------------------------
package LinkedSpec::Validation;

use 5.010;
BEGIN {
 require File::Basename;
 my $module_dir = (File::Basename::fileparse(__FILE__))[1];
 my $perl_root = File::Basename::dirname($module_dir);
 unshift @INC, $perl_root unless grep { defined($_) && $_ eq $perl_root } @INC;
}
use LinkedSpec::OwnerDispatch ();

# Each full-source syntax attempt owns its diagnostics. A rejected lexical
# alternative must not notify callers or write misleading trace errors.
our $syntax_trial;

use constant {
 DUMP_NONE => 0,
 DUMP_LOW  => 100,
};

sub _call_compiler_state {
 my ($subname, @args) = @_;
 return LinkedSpec::OwnerDispatch::dispatch_owner_call(__PACKAGE__, 'LinkedSpec::CompilerState', $subname, @args)
}

sub _trace_log_output {
 my @args = @_;
 if ($syntax_trial) {
  push @{$syntax_trial->{events}}, ['trace', \@args];
  return;
 }
 return LinkedSpec::OwnerDispatch::call_preserving_err(sub {
  LinkedSpec::OwnerDispatch::require_pkg(__PACKAGE__, 'LinkedSpec::Trace');
  return LinkedSpec::Trace::log_output(@args)
 })
}

sub _looks_like_slash_symbol_call_at {
 my ($fragment, $idx) = @_;
 return LinkedSpec::OwnerDispatch::call_preserving_err(sub {
  LinkedSpec::OwnerDispatch::require_pkg(__PACKAGE__, 'LinkedSpec::ActionIR::MethodExpr');
  return LinkedSpec::ActionIR::MethodExpr::_looks_like_slash_symbol_call_at($fragment, $idx)
 })
}

sub _parse_rule_label_line {
 my ($line) = @_;
 return undef unless defined $line;
 return undef unless $line =~ /\A\s*(?<LABEL>\w+)\s*(?<COLON>::|:)(?<TAIL>.*)\z/o;

 my $label = $+{LABEL};
 my $is_top = $+{COLON} eq '::' ? 1 : 0;
 my $tail = defined($+{TAIL}) ? $+{TAIL} : '';
 $tail =~ s/^\s+//o;

 my ($mode, $rhs, $invalid_mode) = ('', $tail, 0);

 if ($tail =~ /\A(?<MODE>OR\s*\{[^}]+\}|AND\s*\{[^}]+\})(?<REST>\s.*|\z)/o) {
  ($mode, $rhs) = ($+{MODE}, defined($+{REST}) ? $+{REST} : '');
  my $normalized = $mode;
  $normalized =~ s/\s+//go;
  if ($normalized =~ /\A(?<KIND>OR|AND)\{(?<BODY>[^}]*)\}\z/o) {
   my $body = $+{BODY};
   if ($body =~ /\A\d+\z/o) {
    $invalid_mode = 0;
   } elsif ($body =~ /\A\d*,\d*\z/o && $body ne ',') {
    my ($min, $max) = split /,/, $body, 2;
    $min = length($min) ? $min : 0;
    $max = length($max) ? $max : 10**9;
    $invalid_mode = $max < $min ? 1 : 0;
   } else {
    $invalid_mode = 1;
   }
  }
 } elsif ($tail =~ /\A(?<MODE>AND\+|AND|OR\+|OR)(?<REST>\s.*|\z)/o) {
  ($mode, $rhs) = ($+{MODE}, defined($+{REST}) ? $+{REST} : '');
 } elsif ($tail =~ /\A(?:AND|OR)\w/o) {
  $invalid_mode = 1;
 } elsif ($tail =~ /\A(?<MODE>[&|\+\*\?])(?<REST>\s.*|\z)/o) {
  ($mode, $rhs) = ($+{MODE}, defined($+{REST}) ? $+{REST} : '');
 } elsif ($tail =~ /\A:/o) {
  $invalid_mode = 1;
 } elsif ($tail =~ /\A(?:[&|\+\*\?]|AND(?:\b|\{|\+)|OR(?:\b|\{|\+))/o) {
  $invalid_mode = 1;
 }

 return {
  label        => $label,
  is_top       => $is_top,
  mode         => $mode,
  rhs          => defined($rhs) ? $rhs : '',
  invalid_mode => $invalid_mode ? 1 : 0,
 }
}

sub _looks_like_malformed_rule_label_line {
 my ($line) = @_;
 my $parsed = _parse_rule_label_line($line);
 return ref($parsed) eq 'HASH' && $parsed->{invalid_mode} ? 1 : 0
}

sub get_dsl_context {
 my ($spec_content, $position) = @_;

 my $before_pos = substr($$spec_content, 0, $position);
 my $line_number = 1 + ($before_pos =~ tr/\n//);

 my @lines = split(/\n/, $$spec_content);
 my $current_line = $lines[$line_number - 1] || "";

 my $prev_line = $line_number > 1 ? $lines[$line_number - 2] : "";
 my $next_line = $line_number < @lines ? $lines[$line_number - 1] : "";

 return {
  line_number => $line_number,
  current_line => $current_line,
  prev_line => $prev_line,
  next_line => $next_line,
  position => $position
 };
}

sub _build_dsl_error_message {
 my ($spec_content, $position, $error_msg, $suggestion) = @_;

 my $context = get_dsl_context($spec_content, $position);

 my $error = "DSL Error at line $context->{line_number}:\n";
 $error .= "  $error_msg\n";
 $error .= "  Line: $context->{current_line}\n";

 if ($context->{prev_line}) {
  $error .= "  Previous: $context->{prev_line}\n";
 }
 if ($context->{next_line}) {
  $error .= "  Next: $context->{next_line}\n";
 }

 if ($suggestion) {
  $error .= "  Suggestion: $suggestion\n";
 }

 return $error;
}

sub report_dsl_error {
 my ($spec_content, $position, $error_msg, $suggestion) = @_;
 my $error = _build_dsl_error_message($spec_content, $position, $error_msg, $suggestion);

 _trace_log_output(DUMP_NONE, $error, "DSL validation failed");
 return undef
}

sub validate_spec_content {
 my ($spec_content, $option) = @_;
 $option = {} unless ref($option) eq 'HASH';

 unless (ref($spec_content) eq 'SCALAR') {
  _trace_log_output(DUMP_NONE, "Invalid spec content type", "Expected SCALAR reference, got " . ref($spec_content));
  return 0;
 }

 unless (length($$spec_content) > 0) {
  _report_dsl_validation_failure($spec_content, 0,
   "Spec file must define at least one rule",
   "Add a rule like 'RuleName:' or 'RuleName::'",
   $option,
   stage => 'validate_spec',
   code => 'no_rules_defined',
   summary => 'Spec file must define at least one rule',
  );
  return 0;
 }

 my @lines = split(/\n/, $$spec_content);
 my $found_rule = 0;
 my $first_significant_line_seen = 0;

 foreach my $line (@lines) {
  next if $line =~ /^\s*$/;
  next if $line =~ /^\s*#/;

   unless ($first_significant_line_seen) {
    $first_significant_line_seen = 1;
   my $first_rule = _parse_rule_label_line($line);
    unless ($first_rule && !$first_rule->{invalid_mode}) {
     my $position = index($$spec_content, $line);
     if (_looks_like_malformed_rule_label_line($line)) {
      _report_dsl_validation_failure($spec_content, $position,
       "Malformed rule label syntax",
       "Use a supported rule label like 'RuleName:', 'RuleName::', 'RuleName:AND+', 'RuleName:OR+', or 'RuleName:OR{2,4}'",
       $option,
       summary => 'Malformed rule label syntax',
       rule_label => (ref($first_rule) eq 'HASH' ? $first_rule->{label} : undef),
      );
     } else {
      _report_dsl_validation_failure($spec_content, $position,
       "Spec file must start with a rule definition",
       "Make the first non-comment line a rule like 'RuleName:' or 'RuleName::'",
       $option,
       summary => 'Spec file must start with a rule definition',
      );
     }
     return 0;
    }
   }

  my $parsed = _parse_rule_label_line($line);
  if ($parsed) {
   $found_rule = 1;
   last;
  }
 }

 unless ($found_rule) {
  _report_dsl_validation_failure($spec_content, 0,
   "Spec file must define at least one rule",
   "Add a rule like 'RuleName:' or 'RuleName::'",
   $option,
   stage => 'validate_spec',
   code => 'no_rules_defined',
   summary => 'Spec file must define at least one rule',
  );
  return 0;
 }

 return 1;
}

sub validate_rule_definition {
 my ($rule_name, $rule_def) = @_;

 unless (ref($rule_def) eq 'HASH') {
  _trace_log_output(DUMP_NONE, "Invalid rule definition for '$rule_name'", "Expected HASH reference, got " . ref($rule_def));
  return 0;
 }

 unless (exists $rule_def->{handler}) {
  _trace_log_output(DUMP_NONE, "Rule '$rule_name' missing required 'handler' field", "All rules must define handler code");
  return 0;
 }

 if (exists $rule_def->{re}) {
  unless (ref($rule_def->{re}) eq 'ARRAY') {
   _trace_log_output(DUMP_NONE, "Rule '$rule_name' 're' field must be an array", "Got " . ref($rule_def->{re}));
   return 0;
  }

  for my $i (0..$#{$rule_def->{re}}) {
   my $regex = $rule_def->{re}[$i];
   eval { qr/$regex/ } or do {
    _trace_log_output(DUMP_NONE, "Invalid regex in rule '$rule_name' at index $i", "Error: $@");
    return 0;
   };
  }
 }

 return 1;
}

sub _notify_dependency_regex_validation_failure {
 my ($option, %info) = @_;
 return undef unless ref($option) eq 'HASH';
 my $cb = $option->{on_failure};
 return undef unless ref($cb) eq 'CODE';
 return $cb->(%info)
}

sub _notify_dsl_validation_failure {
 my ($option, %info) = @_;
 return undef unless ref($option) eq 'HASH';
 my $cb = $option->{on_failure};
 return undef unless ref($cb) eq 'CODE';
 return $cb->(%info)
}

sub _report_dsl_validation_failure {
 my ($spec_content, $position, $error_msg, $suggestion, $option, %info) = @_;
 my $detail = _build_dsl_error_message($spec_content, $position, $error_msg, $suggestion);
 my %payload = %info;
 $payload{summary} = defined($info{summary}) ? $info{summary} : $error_msg;
 $payload{detail} = $detail;
 _notify_dsl_validation_failure(
  $option,
  %payload,
 );
 return report_dsl_error($spec_content, $position, $error_msg, $suggestion)
}

sub _describe_validation_value_kind {
 my ($value) = @_;

 return 'undef' unless defined($value);
 return ref($value) ? ref($value) : 'SCALAR';
}

sub _new_dependency_regex_validation_view {
 my (%args) = @_;
 my $dependency_regex_rows = (ref($args{dependency_regex_rows}) eq 'ARRAY')
  ? $args{dependency_regex_rows}
  : [];
 return {
  kind => 'dependency_regex_validation_view',
  version => 1,
  dependency_regex_rows => $dependency_regex_rows,
  rule_rows => (ref($args{rule_rows}) eq 'ARRAY') ? $args{rule_rows} : [],
  rules_by_label => (ref($args{rules_by_label}) eq 'HASH') ? $args{rules_by_label} : {},
 }
}

sub _is_dependency_regex_validation_view {
 my ($value) = @_;
 return 0 unless ref($value) eq 'HASH';
 return 0 unless defined($value->{kind}) && $value->{kind} eq 'dependency_regex_validation_view';
 return 0 unless defined($value->{version}) && $value->{version} == 1;
 return 0 unless ref($value->{dependency_regex_rows}) eq 'ARRAY';
 return 0 unless ref($value->{rule_rows}) eq 'ARRAY';
 return 0 unless ref($value->{rules_by_label}) eq 'HASH';
 return 1
}

sub _build_legacy_dependency_regex_validation_view {
 my ($dependency_regex_map, $rules_by_label, $option) = @_;
 unless (ref($dependency_regex_map) eq 'HASH') {
  my $detail = "Expected HASH reference, got " . _describe_validation_value_kind($dependency_regex_map);
  _notify_dependency_regex_validation_failure(
   $option,
   summary => 'Invalid dependency-regex structure',
   detail => $detail,
  );
  _trace_log_output(DUMP_NONE, "Invalid dependency-regex structure", $detail);
  return undef;
 }

 unless (ref($rules_by_label) eq 'HASH') {
  my $detail = "Expected HASH reference, got " . _describe_validation_value_kind($rules_by_label);
  _notify_dependency_regex_validation_failure(
   $option,
   summary => 'Invalid spec structure',
   detail => $detail,
  );
  _trace_log_output(DUMP_NONE, "Invalid spec structure", $detail);
  return undef;
 }

 return _new_dependency_regex_validation_view(
  dependency_regex_rows => [map { [$_, $dependency_regex_map->{$_}] } sort keys %$dependency_regex_map],
  rule_rows => [map { [$_, $rules_by_label->{$_}] } sort keys %$rules_by_label],
  rules_by_label => { %$rules_by_label },
 );
}

sub _validate_dependency_regex_validation_view {
 my ($validation_view, $option) = @_;

 unless (_is_dependency_regex_validation_view($validation_view)) {
  my $detail = 'Expected dependency_regex_validation_view HASH reference, got '
   . _describe_validation_value_kind($validation_view);
  _notify_dependency_regex_validation_failure(
   $option,
   summary => 'Invalid dependency-regex validation view',
   detail => $detail,
  );
  _trace_log_output(DUMP_NONE, 'Invalid dependency-regex validation view', $detail);
  return 0;
 }

 my $rules_by_label = $validation_view->{rules_by_label};
 my $dependency_regex_rows = $validation_view->{dependency_regex_rows};

 for my $row (@$dependency_regex_rows) {
  my ($rule_name, $dependency_regex_entry) = @$row;

  unless (exists $rules_by_label->{$rule_name}) {
   my $summary = "Dependency regex references non-existent rule '$rule_name'";
   my $detail = 'Rule not found in spec';
   _notify_dependency_regex_validation_failure(
    $option,
    summary => $summary,
    detail => $detail,
    rule_label => $rule_name,
   );
   _trace_log_output(DUMP_NONE, $summary, $detail);
   return 0;
  }

  unless (ref($dependency_regex_entry) eq 'Regexp') {
   my $summary = "Invalid dependency regex entry for rule '$rule_name'";
   my $detail = "Expected compiled regex, got " . ref($dependency_regex_entry);
   _notify_dependency_regex_validation_failure(
    $option,
    summary => $summary,
    detail => $detail,
    rule_label => $rule_name,
   );
   _trace_log_output(DUMP_NONE, $summary, $detail);
   return 0;
  }
 }

 for my $row (@{$validation_view->{rule_rows}}) {
  my ($rule_name, $rule_def) = @$row;

  my $rule_valid = eval { validate_rule_definition($rule_name, $rule_def) };
  my $validate_rule_definition_error = $@;
  if ($validate_rule_definition_error) {
   _notify_dependency_regex_validation_failure(
    $option,
    summary => "Rule definition validation failed for rule '$rule_name'",
    detail => $validate_rule_definition_error,
    rule_label => $rule_name,
   );
   die $validate_rule_definition_error;
  }

  unless ($rule_valid) {
   _notify_dependency_regex_validation_failure(
    $option,
    summary => "Invalid rule definition for rule '$rule_name'",
    detail => "validate_rule_definition returned false for rule '$rule_name'",
    rule_label => $rule_name,
   );
   return 0;
  }

  if (exists $rule_def->{dependency_refs} && ref($rule_def->{dependency_refs}) eq 'ARRAY') {
   for my $i (0..$#{$rule_def->{dependency_refs}}) {
    my $element = $rule_def->{dependency_refs}[$i];
    unless (ref($element) eq 'HASH' && exists $element->{label} && exists $element->{idx}) {
     my $summary = "Invalid dependency entry at index $i for rule '$rule_name'";
     my $detail = "Expected HASH with 'label' and 'idx' keys";
     _notify_dependency_regex_validation_failure(
      $option,
      summary => $summary,
      detail => $detail,
      rule_label => $rule_name,
     );
     _trace_log_output(DUMP_NONE, $summary, $detail);
     return 0;
    }

    my $ref_rule = $element->{label};
    unless (exists $rules_by_label->{$ref_rule}) {
      my $summary = "Dependency entry references non-existent rule '$ref_rule'";
      my $detail = "Rule '$rule_name' references missing dependency rule '$ref_rule'";
      _notify_dependency_regex_validation_failure(
       $option,
       summary => $summary,
       detail => $detail,
       rule_label => $rule_name,
      );
      _trace_log_output(DUMP_NONE, $summary, $detail);
      return 0;
    }

    my $ref_idx = $element->{idx};
    my $ref_rule_def = $rules_by_label->{$ref_rule};
    unless (exists $ref_rule_def->{re} && $ref_idx < @{$ref_rule_def->{re}}) {
     my $summary = "Invalid regex index $ref_idx for rule '$ref_rule'";
     my $detail = "Rule '$rule_name' references out-of-bounds regex index $ref_idx on rule '$ref_rule'";
     _notify_dependency_regex_validation_failure(
      $option,
      summary => $summary,
      detail => $detail,
      rule_label => $rule_name,
     );
     _trace_log_output(DUMP_NONE, $summary, $detail);
     return 0;
    }
   }
  }
 }

 return 1;
}

sub _validate_compiled_descriptor_state_native {
 my ($descriptor_state, $option) = @_;
 my $validation_view = _call_compiler_state('compiled_descriptor_state_validation_view', $descriptor_state);

 unless (_call_compiler_state('is_compiled_descriptor_state_validation_view', $validation_view)) {
  my $detail = 'Expected compiled_descriptor_state_validation_view HASH reference, got '
   . _describe_validation_value_kind($validation_view);
  _notify_dependency_regex_validation_failure(
   $option,
   summary => 'Invalid compiled descriptor validation view',
   detail => $detail,
  );
  _trace_log_output(DUMP_NONE, 'Invalid compiled descriptor validation view', $detail);
  return 0;
 }

 return _validate_dependency_regex_validation_view(
  _new_dependency_regex_validation_view(
   dependency_regex_rows => $validation_view->{dependency_regex_rows},
   rule_rows => $validation_view->{rule_rows},
   rules_by_label => $validation_view->{rules_by_label},
  ),
  $option,
 );
}

sub validate_compiled_descriptor_state {
 my ($descriptor_state, $option) = @_;
 $option = {} unless ref($option) eq 'HASH';

 unless (_call_compiler_state('is_compiled_descriptor_state', $descriptor_state)) {
  my $detail = 'Expected compiled_descriptor_state HASH reference, got '
   . _describe_validation_value_kind($descriptor_state);
  _notify_dependency_regex_validation_failure(
   $option,
   summary => 'Invalid compiled descriptor state',
   detail => $detail,
  );
  _trace_log_output(DUMP_NONE, 'Invalid compiled descriptor state', $detail);
  return 0;
 }

 return _validate_compiled_descriptor_state_native($descriptor_state, $option);
}

sub validate_dependency_regex_references {
 my ($dependency_regex_map, $spec, $option) = @_;
 $option = {} unless ref($option) eq 'HASH';
 my $validation_view = _build_legacy_dependency_regex_validation_view($dependency_regex_map, $spec, $option);
 return 0 unless defined $validation_view;
 return _validate_dependency_regex_validation_view($validation_view, $option);
}

sub _inter_match_gap_line_failure {
 my ($spec_content, $position, $option, %args) = @_;
 return _report_dsl_validation_failure(
  $spec_content,
  $position,
  $args{summary},
  $args{suggestion},
  $option,
  %args,
  source_id => $option->{source_id},
 )
}

sub _inter_match_gap_execution_shape {
 my ($mode, $action_count, $blind_count) = @_;
 $mode = '' unless defined $mode;
 if ($mode =~ /AND/o) {
  return $blind_count ? 'and_call_loop'
   : $action_count == 1 ? 'single_match'
   : 'and_sequence_loop';
 }
 if ($mode eq '|') {
  return $blind_count ? 'or_call_loop' : 'or_choice_dispatch';
 }
 if ($mode =~ /\A(?:[+*?]|OR(?:\+|\s*\{|\z))/o) {
  return 'repeat_loop';
 }
 return 'default_scan_loop'
}

# Structural validation is line-oriented, but helper patterns and their quoted
# subjects can cross a line. Hide complete multiline literals within expression
# scopes in a length-preserving view. Compilation and diagnostics keep original
# source; assignment-position slash calls keep their physical-line decision.
sub _helper_pattern_validation_view {
 my ($source) = @_;
 my $view = $source;
 my @scopes;
 my $length = length($source);
 my $line_start = 0;
 my $line_end = index($source, "\n");
 $line_end = $length if $line_end < 0;
 for (my $i = 0; $i < $length; ++$i) {
  while ($i >= $line_end) {
   $line_start = $line_end + 1;
   $line_end = index($source, "\n", $line_start);
   $line_end = $length if $line_end < 0;
  }
  my $char = substr($source, $i, 1);
  if ($char eq q{'} || $char eq q{"}) {
   my $quote = $char;
   my $start = $i;
   while (++$i < $length) {
    my $inner = substr($source, $i, 1);
    if ($inner eq "\\") { ++$i; next }
    last if $inner eq $quote;
   }
   # Do not erase a bare string at rule level or an unterminated token. Both
   # must remain visible to the existing structural/compiler diagnostics.
   if (@scopes && $i < $length) {
    my $token = substr($source, $start, $i - $start + 1);
    if ($token =~ /\n/) {
     $token =~ s/[^\r\n]/ /g;
     substr($view, $start, $i - $start + 1, $token);
    }
   }
   next;
  }
  if ($char eq '#' && substr($source, $line_start, $i - $line_start) =~ /^\s*$/) {
   $i = $line_end - 1;
   next;
  }
  if ($char eq '/') {
   my $previous = $i - 1;
   --$previous while $previous >= 0 && substr($source, $previous, 1) =~ /\s/;
   my $argument = @scopes && $scopes[-1] eq '(' && $previous >= 0
    && substr($source, $previous, 1) =~ /[(,]/;
   if ($argument) {
    my $end = _consume_slash_construct($source, $i, $length);
    my $token_end = _consume_slash_segment($source, $i, $length);
    my $after = $end // $length;
    ++$after while $after < $length && substr($source, $after, 1) =~ /\s/;
    if (defined($end) && $token_end <= $length
        && substr($source, $token_end - 1, 1) eq '/'
        && $after < $length && substr($source, $after, 1) =~ /[,\)\]]/) {
     my $token = substr($source, $i, $end - $i);
     if ($token =~ /\n/) {
      $token =~ s/[^\r\n]/ /g;
      substr($view, $i, $end - $i, $token);
     }
     $i = $end - 1;
     next;
    }
   }
   my $line = substr($source, $line_start, $line_end - $line_start);
   my $end = _consume_slash_construct($line, $i - $line_start, length($line), scalar(@scopes));
   if (defined $end) {
    $i = $line_start + $end - 1;
    next;
   }
  }
  if ($char =~ /[({\[]/) {
   push @scopes, $char;
  } elsif ($char =~ /[)}\]]/) {
   pop @scopes if @scopes;
  }
 }
 return $view;
}

sub _validate_inter_match_gap_authored_metadata {
 my ($spec_content, $option, $validation_view) = @_;
 LinkedSpec::OwnerDispatch::require_pkg(__PACKAGE__, 'LinkedSpec::UnicodeXIDContinue');

 $validation_view //= _helper_pattern_validation_view($$spec_content);
 my @lines = split(/\n/, $validation_view, -1);
 my @positions;
 my $offset = 0;
 for my $line (@lines) {
  push @positions, $offset;
  $offset += length($line) + 1;
 }

 my (%rules, @selectors);
 my $current;
 my $depth = 0;
 for my $idx (0 .. $#lines) {
  my $line = $lines[$idx];
  my $line_number = $idx + 1;
  my $position = $positions[$idx];
  my $fragment = $line;

  if ($depth == 0) {
   my $header = _parse_rule_label_line($line);
   if ($header) {
    $current = {
     label => $header->{label},
     mode => $header->{mode},
     slots => [],
     slot_first_line => {},
     directives => [],
     legacy_markers => [],
     action_count => 0,
     blind_count => 0,
    };
    $rules{$header->{label}} = $current;
    $fragment = $header->{rhs};
   }
  }
  next unless $current;
  next if $depth == 0 && $fragment =~ /^\s*(?:#.*)?$/o;

  my @slot_tokens;
  my $standalone_named = 0;
  # Preserve the established diagnostics for whole-line invalid names, even
  # when a name contains a structural delimiter that cannot start a member.
  if ($depth == 0
      && $fragment =~ /^\s*(?<NAME>[^\s=]+)\s*=\s*\/(?<PATTERN>(?:\\.|[^\/\\])*?)(?<!\\)\/\s*$/o) {
   push @slot_tokens, { name => $+{NAME}, pattern => $+{PATTERN} };
   $standalone_named = 1;
  }

  if ($depth == 0 && $fragment =~ /^\s*\@capture_gaps\s*$/o) {
   if (@{$current->{directives}}) {
    return _inter_match_gap_line_failure(
     $spec_content,
     $position,
     $option,
     code => 'capture_gaps_duplicate_directive',
     stage => 'parse_directive',
     summary => 'Duplicate capture-gaps directive',
     suggestion => 'Keep exactly one capture-gaps directive in the owning rule',
     rule_label => $current->{label},
     line => $line_number,
     first_line => $current->{directives}[0]{line},
    );
   }
   push @{$current->{directives}}, { line => $line_number, position => $position };
   next;
  }

  if ($depth == 0
      && $fragment =~ /^\s*\@\s*(capture_slice|capture_from_here|move_pos)\b/o) {
   push @{$current->{legacy_markers}}, {
    marker => '@' . $1,
    line => $line_number,
   };
  }

  my $edge_scan = $standalone_named
   ? { edges => [], depth => 0 }
   : _scan_rule_edges_in_fragment($fragment, $depth, \@slot_tokens);
  for my $slot (@slot_tokens) {
   my ($name, $pattern) = @{$slot}{qw(name pattern)};
   unless (defined $name) {
    push @{$current->{slots}}, {
     regex_index => scalar(@{$current->{slots}}),
     slot_id => undef,
    };
    next;
   }
   unless (LinkedSpec::UnicodeXIDContinue::is_xid_continue_string($name)
       && $name !~ /\A[0-9]+\z/o) {
    return _inter_match_gap_line_failure(
     $spec_content,
     $position,
     $option,
     code => 'regex_slot_name_invalid',
     stage => 'parse_declaration',
     summary => 'Invalid named regex-slot declaration',
     suggestion => 'Use one or more pinned Unicode-17 XID_Continue scalars; ASCII digit-only names are reserved',
     rule_label => $current->{label},
     line => $line_number,
     slot_name => $name,
    );
   }
   if (exists $current->{slot_first_line}{$name}) {
    return _inter_match_gap_line_failure(
     $spec_content,
     $position,
     $option,
     code => 'regex_slot_duplicate_name',
     stage => 'resolve_declaration',
     summary => 'Duplicate named regex-slot declaration',
     suggestion => 'Give every named regex slot a unique exact name within its owning rule',
     rule_label => $current->{label},
     line => $line_number,
     slot_name => $name,
     first_line => $current->{slot_first_line}{$name},
    );
   }
   eval { qr/$pattern/ } or return _inter_match_gap_line_failure(
    $spec_content,
    $position,
    $option,
    summary => "Invalid regex pattern: /$pattern/",
    suggestion => 'Check the regex syntax and ensure proper escaping',
    rule_label => $current->{label},
    line => $line_number,
   );
   $current->{slot_first_line}{$name} = $line_number;
   push @{$current->{slots}}, {
    regex_index => scalar(@{$current->{slots}}),
    slot_id => $name,
   };
  }
  if (!$edge_scan->{error}) {
   for my $edge (@{$edge_scan->{edges} || []}) {
    if (($edge->{kind} // '') eq 'action') {
     ++$current->{action_count};
     push @selectors, {
      owner => $current->{label},
      target_rule => $edge->{label},
      selector_kind => $edge->{selector_kind},
      authored_selector => $edge->{authored_selector},
      line => $line_number,
      position => $position,
     };
    } elsif (($edge->{kind} // '') eq 'blind_call') {
     ++$current->{blind_count};
    }
   }
   $depth = $edge_scan->{depth} // 0;
  }
 }

 for my $selector (@selectors) {
  my $target = $rules{$selector->{target_rule}};
  next unless $target;
  my $slots = $target->{slots};
  next if ($selector->{selector_kind} // '') eq 'unindexed';
  if (($selector->{selector_kind} // '') eq 'named') {
   my $name = $selector->{authored_selector};
   unless (LinkedSpec::UnicodeXIDContinue::is_xid_continue_string($name)
       && $name !~ /\A[0-9]+\z/o) {
    return _inter_match_gap_line_failure(
     $spec_content,
     $selector->{position},
     $option,
     code => 'regex_slot_selector_invalid',
     stage => 'parse_selector',
     summary => 'Invalid named regex-slot selector',
     suggestion => 'Use one exact pinned Unicode-17 XID_Continue slot name inside brackets',
     rule_label => $selector->{owner},
     line => $selector->{line},
     target_rule => $selector->{target_rule},
     authored_selector => $name,
    );
   }
   my ($slot) = grep {
    defined($_->{slot_id}) && $_->{slot_id} eq $name
   } @$slots;
   unless ($slot) {
    return _inter_match_gap_line_failure(
     $spec_content,
     $selector->{position},
     $option,
     code => 'regex_slot_unknown_name',
     stage => 'resolve_selector',
     summary => 'Unknown named regex-slot selector',
     suggestion => 'Declare the exact named slot in the target rule before selecting it',
     rule_label => $selector->{owner},
     line => $selector->{line},
     target_rule => $selector->{target_rule},
     authored_selector => $name,
    );
   }
  } else {
   my $regex_index = ($selector->{selector_kind} // '') eq 'numeric'
    ? 0 + $selector->{authored_selector}
    : 0;
   if ($regex_index >= @$slots) {
    return _inter_match_gap_line_failure(
     $spec_content,
     $selector->{position},
     $option,
     code => 'regex_slot_index_out_of_range',
     stage => 'resolve_selector',
     summary => 'Regex-slot selector index is out of range',
     suggestion => 'Select an existing zero-based target regex slot',
     rule_label => $selector->{owner},
     line => $selector->{line},
     target_rule => $selector->{target_rule},
     regex_index => $regex_index,
     regex_count => scalar(@$slots),
    );
   }
  }
 }

 for my $rule (values %rules) {
  next unless @{$rule->{directives}};
  my $directive = $rule->{directives}[0];
  if (@{$rule->{legacy_markers}}) {
   my $legacy = $rule->{legacy_markers}[0];
   return _inter_match_gap_line_failure(
    $spec_content,
    $directive->{position},
    $option,
    code => 'capture_gaps_legacy_marker_conflict',
    stage => 'validate_directive',
    summary => 'Capture-gaps directive conflicts with a legacy split marker',
    suggestion => 'Remove the legacy marker before enabling rule-level gap capture',
    rule_label => $rule->{label},
    line => $directive->{line},
    marker => $legacy->{marker},
    marker_line => $legacy->{line},
   );
  }
  my $family = ($rule->{mode} // '') =~ /AND/o ? 'and' : 'or_default';
  my $cursor_policy = $family eq 'and' ? 'consume' : 'seek';
  my $edge_ownership = $rule->{action_count} && $rule->{blind_count} ? 'mixed'
   : $rule->{action_count} ? 'action'
   : $rule->{blind_count} ? 'blind'
   : 'none';
  my $execution_shape = _inter_match_gap_execution_shape(
   $rule->{mode},
   $rule->{action_count},
   $rule->{blind_count},
  );
  my $eligible = $family eq 'or_default'
   && $cursor_policy eq 'seek'
   && $edge_ownership eq 'action'
   && ($execution_shape eq 'default_scan_loop' || $execution_shape eq 'repeat_loop')
   && $rule->{action_count} >= 1;
  next if $eligible;
  return _inter_match_gap_line_failure(
   $spec_content,
   $directive->{position},
   $option,
   code => 'capture_gaps_rule_ineligible',
   stage => 'validate_directive',
   summary => 'Capture-gaps directive is ineligible for this rule shape',
   suggestion => 'Use an OR/default seek rule with a loop and at least one static action edge',
   rule_label => $rule->{label},
   line => $directive->{line},
   family => $family,
   cursor_policy => $cursor_policy,
   edge_ownership => $edge_ownership,
   execution_shape => $execution_shape,
  );
 }
 return 1
}

sub validate_dsl_syntax {
 my ($spec_content, $option) = @_;
 $option = {} unless ref($option) eq 'HASH';

 # Preserve every source accepted by the established regex interpretation.
 # Only a failed full-source parse with a final-call candidate may retry.
 my $selected = _dsl_syntax_trial($spec_content, $option, 0);
 if (!$selected->{valid} && $selected->{has_final_slash}) {
  my $alternative = _dsl_syntax_trial($spec_content, $option, 1);
  $selected = $alternative if $alternative->{valid};
 }
 for my $event (@{$selected->{events}}) {
  if ($event->[0] eq 'trace') {
   _trace_log_output(@{$event->[1]});
  } else {
   _notify_dsl_validation_failure($option, %{$event->[1]});
  }
 }
 return $selected->{valid};
}

sub _dsl_syntax_trial {
 my ($spec_content, $option, $allow_final_slash) = @_;
 local $syntax_trial = { allow_final_slash => $allow_final_slash, events => [] };
 my %trial_option = (%$option, on_failure => sub {
  push @{$syntax_trial->{events}}, ['failure', { @_ }];
 });
 $syntax_trial->{valid} = _validate_dsl_syntax_body($spec_content, \%trial_option);
 return $syntax_trial;
}

sub _validate_dsl_syntax_body {
 my ($spec_content, $option) = @_;

 my $validation_view = _helper_pattern_validation_view($$spec_content);
 return 0 unless _validate_inter_match_gap_authored_metadata($spec_content, $option, $validation_view);

 my @lines = split(/\n/, $validation_view);
 my @source_lines = split(/\n/, $$spec_content);
 my @line_positions;
 my $offset = 0;
 for my $line (@source_lines) {
  push @line_positions, $offset;
  $offset += length($line) + 1;
 }
 my @defined_rules = ();
 my @used_rules = ();
 my %seen_defined_rules;
 my $current_rule;
 my $seen_first_rule = 0;

 for my $line_index (0 .. $#lines) {
  my $line = $lines[$line_index];
  my $source_line = $source_lines[$line_index];
 next if $line =~ /^\s*$/;
 next if $line =~ /^\s*#/;

  my $at_rule_top_level = !($current_rule && (($current_rule->{edge_scan_depth} // 0) > 0));
  my $rule_label = $at_rule_top_level ? _parse_rule_label_line($line) : undef;
  if ($rule_label) {
   $seen_first_rule = 1;
   if ($current_rule && $current_rule->{acode_count} && $current_rule->{bcode_count}) {
 return _report_mixed_rule_action_modes(
  $current_rule->{label},
  $current_rule->{acode_count},
  $current_rule->{bcode_count},
  $option,
 );
}

   if ($rule_label->{invalid_mode}) {
    my $position = $line_positions[$line_index];
    _report_dsl_validation_failure($spec_content, $position,
     "Malformed rule label syntax",
     "Use a supported rule label like 'RuleName:', 'RuleName::', 'RuleName:AND+', 'RuleName:OR+', or 'RuleName:OR{2,4}'",
     $option,
     summary => 'Malformed rule label syntax',
    );
    return 0;
  }
  my $rule_name = $rule_label->{label};
  push @defined_rules, $rule_name;

  if ($seen_defined_rules{$rule_name}++) {
    my $position = $line_positions[$line_index];
    _report_dsl_validation_failure($spec_content, $position,
     "Duplicate rule definition: '$rule_name'",
     "Remove the duplicate rule or rename one of them",
     $option,
     summary => "Duplicate rule definition: '$rule_name'",
     rule_label => $rule_name,
    );
    return 0;
   }

   unless (_validate_rule_header_rhs_start($spec_content, $source_line, $rule_label->{rhs}, $option, $rule_name, $line_positions[$line_index])) {
    return 0;
   }

   my $edge_scan = _scan_rule_edges_in_fragment($rule_label->{rhs});
   if ($edge_scan->{error}) {
    my $position = $line_positions[$line_index];
    return _report_edge_target_syntax_error($spec_content, $position, $edge_scan->{error}, $option, $rule_name);
   }
   my ($acode_count, $bcode_count) = _count_rule_edge_kinds_in_fragment($rule_label->{rhs}, $edge_scan);
   my $lifecycle_item_open = 0;
   if ($rule_label->{rhs} =~ /^\s*(?:I\s*)?\{/o) {
    my $close_offset = _lifecycle_block_close_offset($rule_label->{rhs}, 0);
    if (defined $close_offset) {
     my $remainder = substr($rule_label->{rhs}, $close_offset + 1);
     if ($remainder !~ /^\s*(?:#.*)?$/o
         && !_looks_like_supported_rule_paragraph_member_line($remainder)) {
      return _report_unsupported_lifecycle_block_remainder(
       $spec_content,
       $source_line,
       index($line, $rule_label->{rhs}) + $close_offset,
       $option,
       $rule_name,
       $line_positions[$line_index],
      );
     }
    } else {
     $lifecycle_item_open = 1;
    }
   }
   push @used_rules, map { $_->{label} } @{$edge_scan->{edges} || []};
   $current_rule = {
    label => $rule_name,
    acode_count => $acode_count,
    bcode_count => $bcode_count,
    edge_scan_depth => $edge_scan->{depth} // 0,
    lifecycle_item_open => $lifecycle_item_open,
   };
  } elsif ($at_rule_top_level && _looks_like_malformed_rule_label_line($line)) {
   my $position = $line_positions[$line_index];
   _report_dsl_validation_failure($spec_content, $position,
    "Malformed rule label syntax",
    "Use a supported rule label like 'RuleName:', 'RuleName::', 'RuleName:AND+', 'RuleName:OR+', or 'RuleName:OR{2,4}'",
    $option,
    summary => 'Malformed rule label syntax',
   );
   return 0;
  } elsif (!$seen_first_rule) {
   my $position = $line_positions[$line_index];
   _report_dsl_validation_failure($spec_content, $position,
    "Spec file must start with a rule definition",
    "Make the first non-comment line a rule like 'RuleName:' or 'RuleName::'",
    $option,
    summary => 'Spec file must start with a rule definition',
   );
   return 0;
  } elsif ($current_rule) {
   my $start_depth = $current_rule->{edge_scan_depth} // 0;
   my $continuing_lifecycle_item = $current_rule->{lifecycle_item_open} ? 1 : 0;
   my $starting_lifecycle_item = $start_depth == 0 && $line =~ /^\s*(?:I\s*)?\{/o ? 1 : 0;
   if ($start_depth > 0 && _parse_rule_label_line($line)) {
    my $position = $line_positions[$line_index];
    _report_dsl_validation_failure($spec_content, $position,
     "Rule definition not allowed inside open block",
     "Close the preceding block with '}' before starting the next rule",
     $option,
     summary => 'Rule definition inside open block',
     rule_label => $current_rule->{label},
    );
    return 0;
   }
   if ($start_depth == 0 && _looks_like_split_marker_prefix($line) && !_looks_like_supported_split_marker_start($line)) {
    my $position = $line_positions[$line_index];
    return _report_split_marker_syntax_error($spec_content, $position, $option, $current_rule->{label});
   }
   if ($start_depth == 0 && (my $targets = _bare_group_targets_without_block($line))) {
    my $position = $line_positions[$line_index];
    return _report_bare_group_without_block($spec_content, $position, $option, $current_rule->{label}, $targets);
   }
   if ($start_depth == 0 && !_looks_like_supported_rule_paragraph_member_line($line)) {
    my $position = $line_positions[$line_index];
    _report_dsl_validation_failure($spec_content, $position,
     "Unsupported top-level rule paragraph content",
     "After a rule start, use regexes, lifecycle/code blocks, action edges, blind calls, split markers, or start the next rule",
     $option,
     summary => 'Unsupported top-level rule paragraph content',
     rule_label => $current_rule->{label},
    );
    return 0;
   }

   my $edge_scan = _scan_rule_edges_in_fragment($line, $start_depth);
   if ($edge_scan->{error}) {
    my $position = $line_positions[$line_index];
    return _report_edge_target_syntax_error($spec_content, $position, $edge_scan->{error}, $option, $current_rule->{label});
   }
   my ($acode_count, $bcode_count) = _count_rule_edge_kinds_in_fragment($line, $edge_scan);
   $current_rule->{acode_count} += $acode_count;
   $current_rule->{bcode_count} += $bcode_count;
   $current_rule->{edge_scan_depth} = $edge_scan->{depth} // 0;
   if ($continuing_lifecycle_item || $starting_lifecycle_item) {
    my $close_offset = _lifecycle_block_close_offset($line, $start_depth);
    if (defined $close_offset) {
     my $remainder = substr($line, $close_offset + 1);
     if ($remainder !~ /^\s*(?:#.*)?$/o
         && !_looks_like_supported_rule_paragraph_member_line($remainder)) {
      return _report_unsupported_lifecycle_block_remainder(
       $spec_content,
       $source_line,
       $close_offset,
       $option,
       $current_rule->{label},
       $line_positions[$line_index],
      );
     }
     $current_rule->{lifecycle_item_open} = 0;
    } else {
     $current_rule->{lifecycle_item_open} = 1;
    }
   }
   push @used_rules, map { $_->{label} } @{$edge_scan->{edges} || []};
   if ($current_rule->{acode_count} && $current_rule->{bcode_count}) {
    return _report_mixed_rule_action_modes(
     $current_rule->{label},
     $current_rule->{acode_count},
     $current_rule->{bcode_count},
     $option,
    );
   }
  }

 }

if ($current_rule && $current_rule->{acode_count} && $current_rule->{bcode_count}) {
 return _report_mixed_rule_action_modes(
  $current_rule->{label},
  $current_rule->{acode_count},
  $current_rule->{bcode_count},
  $option,
 );
}

 if ($current_rule && (($current_rule->{edge_scan_depth} // 0) > 0)) {
  return _report_unclosed_rule_block_error($spec_content, length($$spec_content), $option, $current_rule->{label});
 }

my $regex_depth = 0;
 for my $line_index (0 .. $#lines) {
  my $line = $lines[$line_index];
  my $source_line = $source_lines[$line_index];
  next if $line =~ /^\s*$/;
  next if $line =~ /^\s*#/;

  my $rule_label = $regex_depth == 0 ? _parse_rule_label_line($line) : undef;
  my $regex_fragment = $rule_label ? $rule_label->{rhs} : $line;
  my @regex_literals = $regex_depth == 0
   ? _extract_leading_regex_literals_from_fragment($regex_fragment)
   : ();

  for my $regex_literal (@regex_literals) {
   my $regex_pattern = $regex_literal;
   $regex_pattern =~ s{^/|/$}{}g;

   eval { qr/$regex_pattern/ } or do {
    my $position = $line_positions[$line_index];
    _report_dsl_validation_failure($spec_content, $position,
     "Invalid regex pattern: $regex_literal",
     "Check the regex syntax and ensure proper escaping",
     $option,
     summary => "Invalid regex pattern: $regex_literal",
     rule_label => $current_rule ? $current_rule->{label} : undef,
    );
    return 0;
   };
  }

  my $regex_scan = _scan_rule_edges_in_fragment($regex_fragment, $regex_depth);
  $regex_depth = $regex_scan->{depth} // 0;
 }

 my %defined_rules = map { $_ => 1 } @defined_rules;
 my %used_rules = map { $_ => 1 } @used_rules;

 my @unused_rules = grep { !$used_rules{$_} } @defined_rules;
 if (@unused_rules) {
  _trace_log_output(DUMP_LOW, "Warning: Unused rules detected", "Rules defined but never used: " . join(", ", @unused_rules));
 }

 my @undefined_rules = grep { !$defined_rules{$_} } @used_rules;
 if (@undefined_rules) {
  my @unique_undefined = do { my %seen; grep { !$seen{$_}++ } @undefined_rules };
  _trace_log_output(DUMP_LOW, "Warning: Undefined rules referenced", "Rules referenced but not defined: " . join(", ", @unique_undefined));
 }

	 if ($option->{strict_syntax}) {
	  if (@undefined_rules) {
	   my @unique_undefined = do { my %seen; grep { !$seen{$_}++ } @undefined_rules };
	   _report_dsl_validation_failure($spec_content, length($$spec_content),
	    "Undefined rule reference(s): " . join(", ", @unique_undefined),
	    "Define the referenced rules or remove the references to them",
	    $option,
	    summary => 'Undefined rule references in strict mode',
	    rule_label => $current_rule ? $current_rule->{label} : undef,
	   );
	   return 0;
	  }
	  if (@unused_rules) {
	   _report_dsl_validation_failure($spec_content, length($$spec_content),
	    "Unused rule(s): " . join(", ", @unused_rules),
	    "Reference the unused rules or remove them from the spec",
	    $option,
	    summary => 'Unused rules detected in strict mode',
	    rule_label => $current_rule ? $current_rule->{label} : undef,
	   );
	   return 0;
	  }
	 }

 return 1;
}

sub _looks_like_supported_rule_paragraph_member_line {
 my ($line) = @_;
 return 0 unless defined $line;
 while (1) {
  return 1 if $line =~ /^\s*$/o;
  return 1 if $line =~ /^\s*#/o;
  return 1 if _parse_rule_label_line($line);
  $line =~ /\A\s*/o;
  my $slot = _rule_regex_slot_at($line, $+[0]);
  last unless $slot && defined($slot->{name});
  # A complete declaration does not authorize arbitrary trailing text. Check
  # its next member just as a lifecycle block checks its own remainder.
  $line = substr($line, $slot->{end});
 }
 return 1 if $line =~ /^\s*\/(?:\\.|[^\/])*?(?<!\\)\//o;
 return 1 if $line =~ /^\s*->/o;
 return 1 if $line =~ /^\s*=>/o;
 return 1 if $line =~ /^\s*@\s*(?:(?:capture_gaps|capture_slice|capture_from_here|move_pos)\b|mark\s*\(\s*\w+\s*\))/o;
 return 1 if $line =~ /^\s*-\?\s+\w+\b/o;
 return 1 if $line =~ /^\s*\.\s*\w/o;
 return 1 if $line =~ /^\s*\{/o;
 return 1 if $line =~ /^\s*\w+\s*\(/o;
 return 1 if $line =~ /^\s*\w+\s*\{/o;
 return 1 if $line =~ /^\s*\w+\s*\./o;
 return 1 if $line =~ /^\s*\w+(?:\s*\[\s*[^\]\s]+\s*\])?\s*$/o;
 return 1 if $line =~ /^\s*\w+(?:\s*\[\s*[^\]\s]+\s*\])?(?:\s*\|\s*\w+(?:\s*\[\s*[^\]\s]+\s*\])?)+(?:\s*\{|\s*$)/o;
 return 0;
}

sub _lifecycle_block_close_offset {
 my ($fragment, $start_depth) = @_;
 return undef unless defined $fragment;

 my $depth = $start_depth // 0;
 my $entered_block = $depth > 0 ? 1 : 0;
 my $length = length($fragment);
 my $cursor = 0;

 while ($cursor < $length) {
  my $char = substr($fragment, $cursor, 1);

  if ($char eq q{'}) {
   ++$cursor;
   while ($cursor < $length) {
    my $inner = substr($fragment, $cursor, 1);
    if ($inner eq "\\") {
     $cursor += 2;
     next;
    }
    ++$cursor;
    last if $inner eq q{'};
   }
   next;
  }

  if ($char eq q{"}) {
   ++$cursor;
   while ($cursor < $length) {
    my $inner = substr($fragment, $cursor, 1);
    if ($inner eq "\\") {
     $cursor += 2;
     next;
    }
    ++$cursor;
    last if $inner eq q{"};
   }
   next;
  }

  if ($char eq q{/}) {
   my $slash_cursor = _consume_slash_construct($fragment, $cursor, $length, $depth);
   if (defined $slash_cursor) {
    $cursor = $slash_cursor;
    next;
   }
  }

  if ($char eq '{' || $char eq '(' || $char eq '[') {
   ++$depth;
   $entered_block = 1;
   ++$cursor;
   next;
  }

  if ($char eq '}' || $char eq ')' || $char eq ']') {
   --$depth if $depth > 0;
   return $cursor if $entered_block && $depth == 0;
  }

  ++$cursor;
 }

 return undef;
}

sub _report_unsupported_lifecycle_block_remainder {
 my ($spec_content, $line, $close_offset, $option, $rule_label, $line_position) = @_;
 my $position = $line_position // index($$spec_content, $line);
 $position += $close_offset + 1 if $position >= 0;
 return _report_dsl_validation_failure(
  $spec_content,
  $position,
  'Unsupported lifecycle block remainder',
  'Remove the unsupported text or follow the block with a recognized rule-body item',
  $option,
  summary => 'Unsupported lifecycle block remainder',
  rule_label => $rule_label,
 );
}

sub _bare_group_targets_without_block {
 my ($line) = @_;
 return undef unless defined $line;
 return undef unless $line =~ /^\s*(\w+(?:\s*\[\s*[^\]\s]+\s*\])?(?:\s*\|\s*\w+(?:\s*\[\s*[^\]\s]+\s*\])?)+)\s*$/o;
 my $targets_text = $1;
 my @targets = $targets_text =~ /(\w+)\s*(?:\[\s*[^\]\s]+\s*\])?/go;
 return @targets > 1 ? \@targets : undef
}

sub _report_bare_group_without_block {
 my ($spec_content, $position, $option, $rule_label, $targets) = @_;
 return _report_dsl_validation_failure(
  $spec_content,
  $position,
  'Grouped action-edge targets require a shared code block',
  "Use '" . join(' | ', @$targets) . " { ... }' when grouped bare targets share action ownership",
  $option,
  summary => 'Grouped action-edge targets require a shared code block',
  rule_label => $rule_label,
  code => 'grouped_action_shared_block_required',
  stage => 'validate_rule',
  targets => $targets,
 )
}

sub _looks_like_split_marker_prefix {
 my ($fragment) = @_;
 return 0 unless defined $fragment;
 return $fragment =~ /^\s*@/o ? 1 : 0;
}

sub _looks_like_supported_split_marker_start {
 my ($fragment) = @_;
 return 0 unless defined $fragment;
 return $fragment =~ /^\s*@\s*(?:(?:capture_gaps|capture_slice|capture_from_here|move_pos)\b|mark\s*\(\s*\w+\s*\))/o ? 1 : 0;
}

sub _trim_leading_rule_header_regex_cluster {
 my ($fragment) = @_;
 return '' unless defined $fragment;

 my $trimmed = $fragment;
 $trimmed =~ s/^\s+//o;
 return '' unless length($trimmed);

 pos($trimmed) = 0;
 while ($trimmed =~ /\G\s*(\/(?:\\.|[^\/])*?(?<!\\)\/)/gc) {
 }

 my $offset = pos($trimmed);
 $offset = 0 unless defined $offset;
 my $rest = substr($trimmed, $offset);
 $rest =~ s/^\s+//o;
 return $rest;
}

sub _invalid_regex_token_prefix {
 my ($fragment) = @_;
 return '/' unless defined $fragment;

 if ($fragment =~ /^\s*(\/[^\s]*)/o) {
  return $1;
 }

 return '/';
}

sub _validate_rule_header_rhs_start {
 my ($spec_content, $line, $rhs, $option, $rule_label, $line_position) = @_;
 return 1 unless defined $rhs;

 my $trimmed_rhs = $rhs;
 $trimmed_rhs =~ s/^\s+//o;
 return 1 unless length($trimmed_rhs);

 my $remaining = _trim_leading_rule_header_regex_cluster($trimmed_rhs);

 if (length($remaining) && _looks_like_split_marker_prefix($remaining) && !_looks_like_supported_split_marker_start($remaining)) {
  my $position = $line_position // index($$spec_content, $line);
  return _report_split_marker_syntax_error($spec_content, $position, $option, $rule_label);
 }

 if (length($remaining) && $remaining =~ m{\A/}o) {
  my $position = $line_position // index($$spec_content, $line);
  my $bad_regex = _invalid_regex_token_prefix($remaining);
  _report_dsl_validation_failure($spec_content, $position,
   "Invalid regex pattern: $bad_regex",
   "Check the regex syntax and ensure proper escaping",
   $option,
   summary => "Invalid regex pattern: $bad_regex",
   rule_label => $rule_label,
  );
  return 0;
 }

 return 1 unless length($remaining);
 if (my $targets = _bare_group_targets_without_block($remaining)) {
  my $position = $line_position // index($$spec_content, $line);
  return _report_bare_group_without_block($spec_content, $position, $option, $rule_label, $targets);
 }
 return 1 if _looks_like_supported_rule_paragraph_member_line($remaining);

 my $position = $line_position // index($$spec_content, $line);
 _report_dsl_validation_failure($spec_content, $position,
  "Unsupported same-line rule header content",
  "After a rule start or leading regex cluster, use regexes, lifecycle/code blocks, action edges, blind calls, split markers, or end the line",
  $option,
  summary => 'Unsupported same-line rule header content',
  rule_label => $rule_label,
 );
 return 0;
}

# One rule-level regex member, never an expression's regex operand. Structural
# delimiters cannot be part of its name: otherwise I{rx=/x/} could be mistaken
# for a declaration before the scanner enters the code block. Invalid complete
# names still reach the pinned identifier validator, not a host \w classifier.
sub _rule_regex_slot_at {
 my ($fragment, $offset) = @_;
 pos($fragment) = $offset;
 return undef unless $fragment =~ /\G(?:(?<NAME>[^ \t=\r\n{}()\[\]\/"']+)[ \t]*=[ \t]*)?\/(?<PATTERN>(?:\\.|[^\/\\])*?)(?<!\\)\//gc;
 return { name => $+{NAME}, pattern => $+{PATTERN}, end => pos($fragment) };
}

#------------------------------------------------------------------------------
# Function: _scan_rule_edges_in_fragment
# Purpose : Scan one rule fragment for action/blind-call edges while tracking
#           cross-line block depth and reporting malformed target/balance state.
# Args    : ($fragment, $start_depth, optional slot-token arrayref)
# Returns : hashref with `edges`, `depth`, and optional `error`
#------------------------------------------------------------------------------
sub _scan_rule_edges_in_fragment {
 my ($fragment, $start_depth, $slot_tokens) = @_;
 my @edges;
 return { edges => \@edges } unless defined $fragment;

 my $len = length($fragment);
 my $depth = $start_depth // 0;
 my $i = 0;

 while ($i < $len) {
  my $ch = substr($fragment, $i, 1);

  # A rule-level comment cannot declare slots. Keep the existing structural
  # scan independent; disabling this optional observer lasts only this line.
  $slot_tokens = undef if $depth == 0 && $ch eq '#';
  if ($depth == 0 && $slot_tokens
      && ($ch eq '/' || $i == 0 || substr($fragment, $i - 1, 1) =~ /[\s}\)\]\/]/o)) {
   my $slot = _rule_regex_slot_at($fragment, $i);
   if ($slot) {
    push @$slot_tokens, $slot;
    $i = $slot->{end};
    next;
   }
  }

  if ($ch eq q{'}) {
   ++$i;
   while ($i < $len) {
    my $inner = substr($fragment, $i, 1);
    if ($inner eq q{\\}) {
     $i += 2;
     next;
    }
    ++$i;
    last if $inner eq q{'};
   }
   next;
  }

  if ($ch eq q{"}) {
   ++$i;
   while ($i < $len) {
    my $inner = substr($fragment, $i, 1);
    if ($inner eq q{\\}) {
     $i += 2;
     next;
    }
    ++$i;
    last if $inner eq q{"};
   }
   next;
  }

  if ($ch eq q{/}) {
   my $slash_cursor = _consume_slash_construct($fragment, $i, $len, $depth);
   if (defined $slash_cursor) {
    $i = $slash_cursor;
    next;
   }
  }

  if ($ch eq '{' || $ch eq '(' || $ch eq '[') {
   ++$depth;
   ++$i;
   next;
  }

  if ($ch eq '}' || $ch eq ')' || $ch eq ']') {
   if ($depth > 0) {
    --$depth;
    ++$i;
    next;
   }

   return {
    error => {
     kind   => 'structure',
     reason => 'unexpected_closer',
     closer => $ch,
    },
   };
  }

  if ($depth == 0 && (substr($fragment, $i, 2) eq '->' || substr($fragment, $i, 2) eq '=>')) {
   my $kind = substr($fragment, $i, 2) eq '->' ? 'action' : 'blind_call';
   my $cursor = $i + 2;
   my @edge_targets;

   my $parse_target = sub {
    my ($target_cursor) = @_;

    ++$target_cursor while $target_cursor < $len && substr($fragment, $target_cursor, 1) =~ /\s/;
    my $label_start = $target_cursor;
    ++$target_cursor while $target_cursor < $len && substr($fragment, $target_cursor, 1) =~ /\w/;

    if ($target_cursor == $label_start) {
     return {
      error => {
       kind   => $kind,
       reason => 'missing_target',
      },
     };
    }

    my $label = substr($fragment, $label_start, $target_cursor - $label_start);
    my $suffix_cursor = $target_cursor;
    ++$target_cursor while $target_cursor < $len && substr($fragment, $target_cursor, 1) =~ /\s/;

    if ($target_cursor < $len && substr($fragment, $target_cursor, 1) eq '[') {
     if ($kind eq 'blind_call') {
      my $index_cursor = $target_cursor + 1;
      ++$index_cursor while $index_cursor < $len && substr($fragment, $index_cursor, 1) =~ /\s/o;
      my $selector_start = $index_cursor;
      ++$index_cursor while $index_cursor < $len && substr($fragment, $index_cursor, 1) ne ']';
      my $selector = $index_cursor > $selector_start
       ? substr($fragment, $selector_start, $index_cursor - $selector_start)
       : undef;
      $selector =~ s/^\s+|\s+$//go if defined $selector;
      my $regex_index = defined($selector) && $selector =~ /\A\d+\z/o
       ? 0 + $selector
       : undef;
      return {
       error => {
        kind   => $kind,
        reason => 'indexed_target_not_supported',
        label  => $label,
        regex_index => $regex_index,
       },
      };
     }

     my $index_cursor = $target_cursor + 1;
     ++$index_cursor while $index_cursor < $len && substr($fragment, $index_cursor, 1) =~ /\s/o;
     my $selector_start = $index_cursor;
     ++$index_cursor while $index_cursor < $len
      && substr($fragment, $index_cursor, 1) ne ']'
      && substr($fragment, $index_cursor, 1) ne '{';
     my $selector = substr($fragment, $selector_start, $index_cursor - $selector_start);
     $selector =~ s/^\s+|\s+$//go;

     if (!length($selector) || $selector =~ /\s/o
         || $index_cursor >= $len || substr($fragment, $index_cursor, 1) ne ']') {
      return {
       error => {
        kind   => $kind,
        reason => 'malformed_selector',
        label  => $label,
        authored_selector => $selector,
       },
      };
     }

     my $selector_kind = $selector =~ /\A\d+\z/o ? 'numeric' : 'named';
     $target_cursor = $index_cursor + 1;
     $suffix_cursor = $target_cursor;
     ++$target_cursor while $target_cursor < $len && substr($fragment, $target_cursor, 1) =~ /\s/;
     return {
      label => $label,
      cursor => $target_cursor,
      suffix_cursor => $suffix_cursor,
      selector_kind => $selector_kind,
      authored_selector => $selector_kind eq 'numeric' ? 0 + $selector : $selector,
     };
    }

    return {
     label         => $label,
     cursor        => $target_cursor,
     suffix_cursor => $suffix_cursor,
     selector_kind => 'unindexed',
     authored_selector => undef,
    };
   };

   my $first_target = $parse_target->($cursor);
   return { error => $first_target->{error} } if $first_target->{error};
   if ($first_target->{suffix_cursor} < $len) {
    my $immediate_suffix = substr($fragment, $first_target->{suffix_cursor}, 1);
    my $immediate_ok = $immediate_suffix =~ /\s/o || $immediate_suffix eq '{' || $immediate_suffix eq '.';
    $immediate_ok = 1 if $kind eq 'action' && $immediate_suffix eq '|';
    unless ($immediate_ok) {
     return {
      error => {
       kind   => $kind,
       reason => 'malformed_target_suffix',
       label  => $first_target->{label},
      },
     };
    }
   }
   push @edge_targets, {
    kind => $kind,
    label => $first_target->{label},
    selector_kind => $first_target->{selector_kind},
    authored_selector => $first_target->{authored_selector},
   };
   $cursor = $first_target->{cursor};

   if ($kind eq 'action') {
    while (1) {
     my $pipe_cursor = $cursor;
     ++$pipe_cursor while $pipe_cursor < $len && substr($fragment, $pipe_cursor, 1) =~ /\s/;
     last unless $pipe_cursor < $len && substr($fragment, $pipe_cursor, 1) eq '|';

     my $next_target = $parse_target->($pipe_cursor + 1);
     return { error => $next_target->{error} } if $next_target->{error};
     push @edge_targets, {
      kind => $kind,
      label => $next_target->{label},
      selector_kind => $next_target->{selector_kind},
      authored_selector => $next_target->{authored_selector},
     };
     $cursor = $next_target->{cursor};
    }
   }

   my $lookahead = $cursor;
   ++$lookahead while $lookahead < $len && substr($fragment, $lookahead, 1) =~ /\s/;

   if (@edge_targets > 1) {
    if ($lookahead >= $len || substr($fragment, $lookahead, 1) ne '{') {
     return {
      error => {
       kind   => $kind,
       reason => 'grouped_targets_require_block',
       label  => $edge_targets[0]{label},
       targets => [map { $_->{label} } @edge_targets],
      },
     };
    }
   } elsif ($lookahead < $len && substr($fragment, $lookahead, 1) eq '.') {
    my $fluent_cursor = $lookahead + 1;
    ++$fluent_cursor while $fluent_cursor < $len && substr($fragment, $fluent_cursor, 1) =~ /\s/o;
    unless ($fluent_cursor < $len && substr($fragment, $fluent_cursor, 1) =~ /\w/o) {
     return {
      error => {
       kind   => $kind,
        reason => 'malformed_fluent_suffix',
        label  => $edge_targets[0]{label},
      },
     };
    }
   } elsif ($kind eq 'blind_call' && $lookahead < $len && substr($fragment, $lookahead, 1) eq '|') {
    return {
     error => {
      kind   => $kind,
      reason => 'malformed_target_suffix',
      label  => $edge_targets[0]{label},
     },
    };
   }

   push @edges, @edge_targets;
   $i = $lookahead;
   next;
  }

  ++$i;
 }

 return { edges => \@edges, depth => $depth };
}

# A final action statement needs no semicolon. Keep the shared slash predicate's
# closing-brace exclusion, but let the alternative outer structural scan count
# a block closer after a complete numeric call, even before another member on
# that line. Full-source validation preserves the existing regex interpretation
# first; explicit host quote operators never take this alternative.
sub _slash_call_before_final_block_closers {
 my ($fragment, $i, $len, $depth) = @_;
 return 0 unless $depth;
 my $end = LinkedSpec::OwnerDispatch::call_preserving_err(sub {
  LinkedSpec::OwnerDispatch::require_pkg(__PACKAGE__, 'LinkedSpec::ActionIR::MethodExpr');
  return LinkedSpec::ActionIR::MethodExpr::_slash_symbol_call_end_at($fragment, $i)
 });
 return defined($end) && $end < $len
  && substr($fragment, $end, $len - $end) =~ /\A[ \t]*\}/o;
}

sub _consume_slash_construct {
 my ($fragment, $i, $len, $depth) = @_;
 return undef unless defined $fragment;
 $len = length($fragment) unless defined $len;
 return undef if $i >= $len || substr($fragment, $i, 1) ne q{/};
 return undef if _looks_like_slash_symbol_call_at($fragment, $i);

 my $prev_immediate = $i > 0 ? substr($fragment, $i - 1, 1) : '';
 my $prev_nonspace_idx = $i - 1;
 --$prev_nonspace_idx while $prev_nonspace_idx >= 0 && substr($fragment, $prev_nonspace_idx, 1) =~ /\s/o;
 my $prev_nonspace = $prev_nonspace_idx >= 0 ? substr($fragment, $prev_nonspace_idx, 1) : '';

 my $mode = '';
 my $bare = 0;
 if ($prev_nonspace eq 's' && ($prev_nonspace_idx == 0 || substr($fragment, $prev_nonspace_idx - 1, 1) !~ /[\w\$]/o)) {
  $mode = 'substitute';
 } elsif ($prev_nonspace eq 'y' && ($prev_nonspace_idx == 0 || substr($fragment, $prev_nonspace_idx - 1, 1) !~ /[\w\$]/o)) {
  $mode = 'translate';
 } elsif ($prev_nonspace eq 'r'
       && $prev_nonspace_idx > 0
       && substr($fragment, $prev_nonspace_idx - 1, 1) eq 't'
       && ($prev_nonspace_idx == 1 || substr($fragment, $prev_nonspace_idx - 2, 1) !~ /[\w\$]/o)) {
  $mode = 'translate';
 } elsif ($prev_nonspace eq 'r'
       && $prev_nonspace_idx > 0
       && substr($fragment, $prev_nonspace_idx - 1, 1) eq 'q'
       && ($prev_nonspace_idx == 1 || substr($fragment, $prev_nonspace_idx - 2, 1) !~ /[\w\$]/o)) {
  $mode = 'regex';
 } elsif ($prev_nonspace eq 'm' && ($prev_nonspace_idx == 0 || substr($fragment, $prev_nonspace_idx - 1, 1) !~ /[\w\$]/o)) {
  $mode = 'regex';
 } elsif ($i == 0 || $prev_immediate =~ /\s/o || $prev_nonspace =~ /[=~!,;:\(\[\{]/o) {
  $mode = 'regex';
  $bare = 1;
 } else {
  return undef;
 }

 if ($bare && _slash_call_before_final_block_closers($fragment, $i, $len, $depth)) {
  return undef unless $syntax_trial;
  $syntax_trial->{has_final_slash} = 1;
  return undef if $syntax_trial->{allow_final_slash};
 }

 my $cursor = _consume_slash_segment($fragment, $i, $len);
 return $len if $cursor >= $len;

 if ($mode eq 'substitute' || $mode eq 'translate') {
  $cursor = _consume_until_next_unescaped_slash($fragment, $cursor, $len);
  return $len if $cursor >= $len;
 }

 ++$cursor while $cursor < $len && substr($fragment, $cursor, 1) =~ /[A-Za-z]/o;
 return $cursor;
}

sub _consume_slash_segment {
 my ($fragment, $i, $len) = @_;
 return $i unless defined $fragment;
 $len = length($fragment) unless defined $len;
 ++$i;
 while ($i < $len) {
  my $inner = substr($fragment, $i, 1);
  if ($inner eq q{\\}) {
   $i += 2;
   next;
  }
  ++$i;
  last if $inner eq q{/};
 }
 return $i;
}

sub _consume_until_next_unescaped_slash {
 my ($fragment, $i, $len) = @_;
 return $i unless defined $fragment;
 $len = length($fragment) unless defined $len;
 while ($i < $len) {
  my $inner = substr($fragment, $i, 1);
  if ($inner eq q{\\}) {
   $i += 2;
   next;
  }
  ++$i;
  last if $inner eq q{/};
 }
 return $i;
}

sub _count_rule_edge_kinds_in_fragment {
 my ($fragment, $edge_scan) = @_;
 my ($acode_count, $bcode_count) = (0, 0);
 return ($acode_count, $bcode_count) unless defined $fragment;
 $edge_scan ||= _scan_rule_edges_in_fragment($fragment);
 for my $edge (@{$edge_scan->{edges} || []}) {
  if (($edge->{kind} || '') eq 'action') {
   ++$acode_count;
  } elsif (($edge->{kind} || '') eq 'blind_call') {
   ++$bcode_count;
  }
 }

 return ($acode_count, $bcode_count);
}

#------------------------------------------------------------------------------
# Function: _report_edge_target_syntax_error
# Purpose : Convert low-level edge-scan syntax/balance failures into one
#           user-facing DSL diagnostic with targeted guidance.
# Args    : ($spec_content, $position, $error_hashref)
# Returns : undef/false through report_dsl_error
#------------------------------------------------------------------------------
sub _report_edge_target_syntax_error {
 my ($spec_content, $position, $error, $option, $rule_label) = @_;
 my $kind = $error->{kind} || 'action';
 my $reason = $error->{reason} || '';

 if ($reason eq 'unexpected_closer') {
  my $closer = $error->{closer} || '?';
  return _report_dsl_validation_failure(
   $spec_content,
   $position,
   "Unexpected closing delimiter '$closer' in rule paragraph",
   "Remove the stray '$closer' or add the matching opening delimiter earlier in the same rule paragraph",
   $option,
   summary => "Unexpected closing delimiter '$closer' in rule paragraph",
   rule_label => $rule_label,
  );
 }

 if ($kind eq 'blind_call' && $reason eq 'missing_target') {
  return _report_dsl_validation_failure(
   $spec_content,
   $position,
   "Blind-call edge is missing a target rule",
   "Use '=> RuleName' or '=> RuleName { ... }'; blind calls must name a child rule explicitly",
   $option,
   summary => 'Blind-call edge is missing a target rule',
   rule_label => $rule_label,
  );
 }

 if ($kind eq 'action' && $reason eq 'missing_target') {
 return _report_dsl_validation_failure(
   $spec_content,
   $position,
   "Action edge is missing a target rule",
   "Use '-> RuleName', '-> RuleName[idx]', '-> RuleA | RuleB { ... }', or '-> RuleName { ... }'; action edges must name target rule(s) explicitly",
   $option,
   summary => 'Action edge is missing a target rule',
   rule_label => $rule_label,
  );
 }

 if ($kind eq 'action' && $reason eq 'grouped_targets_require_block') {
  return _report_dsl_validation_failure(
   $spec_content,
   $position,
   "Grouped action-edge targets require a shared code block",
   "Use '-> RuleA | RuleB { ... }' when multiple action-edge targets need to share one code block",
   $option,
   summary => 'Grouped action-edge targets require a shared code block',
   rule_label => $rule_label,
   code => 'grouped_action_shared_block_required',
   stage => 'validate_rule',
   targets => $error->{targets} || [$error->{label}],
  );
 }

 if ($kind eq 'blind_call' && $reason eq 'indexed_target_not_supported') {
  return _report_dsl_validation_failure(
   $spec_content,
   $position,
   "Blind-call targets do not support regex-slot indexing",
   "Use '=> RuleName' for blind calls, or use '-> RuleName[idx]' when you need a regex-slot action edge",
   $option,
   summary => 'Blind-call targets do not support regex-slot indexing',
   rule_label => $rule_label,
   code => 'blind_call_index_forbidden',
   stage => 'validate_rule',
   target => $error->{label},
   regex_index => $error->{regex_index},
  );
 }

 if ($kind eq 'blind_call' && $reason eq 'malformed_target_suffix') {
  return _report_dsl_validation_failure(
   $spec_content,
   $position,
   "Malformed blind-call target syntax",
   "Use '=> RuleName' or '=> RuleName { ... }'; blind-call target names use word characters only and cannot have glued punctuation suffixes",
   $option,
   summary => 'Malformed blind-call target syntax',
   rule_label => $rule_label,
  );
 }

 if ($kind eq 'blind_call' && $reason eq 'malformed_fluent_suffix') {
  return _report_dsl_validation_failure(
   $spec_content,
   $position,
   "Malformed blind-call fluent suffix syntax",
   "Use '=> RuleName.method(...)', '=> RuleName .method(...)', or '=> RuleName { ... }'; the '.' must be followed by a method name",
   $option,
   summary => 'Malformed blind-call fluent suffix syntax',
   rule_label => $rule_label,
  );
 }

 if ($kind eq 'action' && $reason eq 'malformed_target_suffix') {
 return _report_dsl_validation_failure(
  $spec_content,
  $position,
  "Malformed action-edge target syntax",
   "Use '-> RuleName', '-> RuleName[idx]', '-> RuleA | RuleB { ... }', '-> RuleName { ... }', or a supported fluent suffix like '-> RuleName.method'; action-edge target names use word characters only",
  $option,
  summary => 'Malformed action-edge target syntax',
  rule_label => $rule_label,
  );
 }

 if ($kind eq 'action' && $reason eq 'malformed_fluent_suffix') {
  return _report_dsl_validation_failure(
   $spec_content,
   $position,
   "Malformed action-edge fluent suffix syntax",
   "Use a method-style continuation like '-> RuleName.method' or '-> RuleName.method(args)'; the '.' must be followed by a method name",
   $option,
   summary => 'Malformed action-edge fluent suffix syntax',
   rule_label => $rule_label,
  );
 }

 if ($kind eq 'action' && $reason eq 'malformed_selector') {
  my $context = get_dsl_context($spec_content, $position);
  return _report_dsl_validation_failure(
   $spec_content,
   $position,
   'Malformed regex-slot selector syntax',
   "Close the selector for '$error->{label}' with ']' and use one numeric index or exact named slot",
   $option,
   summary => 'Malformed regex-slot selector syntax',
   rule_label => $rule_label,
   code => 'regex_slot_selector_invalid',
   stage => 'parse_selector',
   source_id => $option->{source_id},
   line => $context->{line_number},
   target_rule => $error->{label},
   authored_selector => $error->{authored_selector},
  );
 }

 return _report_dsl_validation_failure(
  $spec_content,
  $position,
  "Malformed action-edge target syntax",
  "Use '-> RuleName', '-> RuleName[0]', or '-> RuleName { ... }'; regex-slot indexes must be unsigned integers in brackets",
  $option,
  summary => 'Malformed action-edge target syntax',
  rule_label => $rule_label,
 );
}

sub _report_split_marker_syntax_error {
 my ($spec_content, $position, $option, $rule_label) = @_;
 return _report_dsl_validation_failure(
  $spec_content,
  $position,
  "Malformed split marker syntax",
  q{Use '@capture_gaps' for eligible rule-level gap capture; use '@capture_slice', '@mark(name)', or compatibility aliases '@capture_from_here' / '@move_pos' for split boundaries},
  $option,
  summary => 'Malformed split marker syntax',
  rule_label => $rule_label,
 );
}

sub _report_unclosed_rule_block_error {
 my ($spec_content, $position, $option, $rule_label) = @_;
 $position = 0 unless defined $position;
 while ($position > 0 && substr($$spec_content, $position - 1, 1) eq "\n") {
  --$position;
 }
 return _report_dsl_validation_failure(
  $spec_content,
  $position,
  "Unclosed rule block before end of file",
  "Close the still-open '{', '(', or '[' construct before the end of the spec",
  $option,
  summary => 'Unclosed rule block before end of file',
  rule_label => $rule_label,
 );
}

sub _report_mixed_rule_action_modes {
 my ($label, $acode_count, $bcode_count, $option) = @_;
 my $error_msg = "Rule '$label': Cannot mix ACTION (->) and BLIND CALL (=>) code blocks";
 my $context = "ACTION blocks: ".($acode_count // 0)." found, BLIND CALL blocks: ".($bcode_count // 0)." found";
 my $detail = join(
  "\n",
  $context,
  "  Solution: Use either ACTION blocks OR BLIND CALL blocks, not both",
  "  Example: Use '-> rule_name { code }' OR '=> function_name { code }'",
 );
 _notify_dsl_validation_failure(
  $option,
  summary => $error_msg,
  detail => $detail,
  rule_label => $label,
  code => 'mixed_edge_ownership',
  stage => 'validate_rule',
  ownerships => ['action', 'blind'],
 );
 _trace_log_output(DUMP_NONE, $error_msg, $context);
 print "  Solution: Use either ACTION blocks OR BLIND CALL blocks, not both\n";
 print "  Example: Use '-> rule_name { code }' OR '=> function_name { code }'\n";
 return 0;
}

sub _extract_leading_regex_literals_from_fragment {
 my ($fragment) = @_;
 my @regex_literals;
 return @regex_literals unless defined $fragment;

 pos($fragment) = 0;
 while ($fragment =~ /\G\s*(\/(?:\\.|[^\/])*?(?<!\\)\/)/gc) {
  push @regex_literals, $1;
 }

 return @regex_literals;
}

sub extract_regex_literals_from_rule_rhs {
 my ($rhs) = @_;
 my @regex_literals;

 while ($rhs =~ /(?<!\\)\/(?:\\.|[^\/])*?(?<!\\)\//g) {
  push @regex_literals, $&;
 }

 return @regex_literals;
}

1;
