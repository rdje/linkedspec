# Multi branching IS NOT to be used when connecting INPUT Pins of component
# But ONLY for having the same output pin of a component instance driving
# more than one SINK, i.e, internal signal (OUT-pin -------< IN-pins) and OUT-port(s)
portmap::
-> bare_bit_slice .push
-> concatenation  .push

LX {
	if(num_eq(count(portmap), 1))
		return(portmap.first());
	else()
		return(array("?multi:", copy(portmap)));
	endif()
}


concatenation: /\{/ /\}/
-> concatenation  .push
-> bare_bit_slice .push
-> concatenation[1]    {return(array("?concatenation:", copy(concatenation)))}
bare_bit_slice: /([[:alpha:]]\w*)(?:\[(?:(\d+)(?::(\d+))?|(\?[[:alpha:]]\w+))\])?|(?i)(0x[0-9a-f]+|0b[01]+|\d+\'\d+)/ I {
	entry_parts = [];
	set(entry_parts, entry_groups());
	if(matches(entry_text(), /:/))
		return(array("?slice:", array(flat_array(entry_parts))));
	elseif(or(str_eq(entry_group(1), "0"), is_nonempty(entry_group(1))))
		return(array("?bit:", array(flat_array(entry_parts))));
	elseif(matches(entry_group(0), /^\d/io))
		return(array("?constant:", array(flat_array(entry_parts))));
	else()
		return(array("?bare:", array(flat_array(entry_parts))));
	endif()
}
