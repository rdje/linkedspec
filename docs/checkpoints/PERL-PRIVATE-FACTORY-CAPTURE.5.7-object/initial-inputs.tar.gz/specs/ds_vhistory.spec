# --------------------------------------------
#  Parses the output of 
#
#  dssc vhistory -all -report verbose
# --------------------------------------------

vhistory::  I {
vhistory_items = [];
capt = [];
object_hier = [];
cur_object = undef;
first_capt = undef;
entry_tag = undef;
current_object_name = undef
}
LX  {
 if(is_nonempty(capt));
  first_capt = capt.first();
  if(str_eq(first_capt[0], "?branch:"));
   entry_tag = "?branch_entry:";
  else();
   entry_tag = "?version_entry:";
  endif();
  push(object_hier, array(entry_tag, copy(capt)));
 endif();

 if(is_nonempty(object_hier));
  current_object_name = cur_object[1];
  push(vhistory_items, array("?object:", current_object_name, copy(object_hier)));
 endif();

 return(array("?ds_vhistory:", copy(vhistory_items)))
} 

-> object             {
  if(is_nonempty(capt));
   first_capt = capt.first();
   if(str_eq(first_capt[0], "?branch:"));
    entry_tag = "?branch_entry:";
   else();
    entry_tag = "?version_entry:";
   endif();
   push(object_hier, array(entry_tag, copy(capt)));
   set(capt, array());

  endif();

  if(is_nonempty(object_hier));
   current_object_name = cur_object[1];
   push(vhistory_items, array("?object:", current_object_name, copy(object_hier)));
   set(object_hier, array());
  endif();

  cur_object = call(object);
  print("\tObject   ", cur_object[1], "\n")
}


-> separator          {
  if(is_nonempty(capt));
   first_capt = capt.first();
   if(str_eq(first_capt[0], "?branch:"));
    entry_tag = "?branch_entry:";
   else();
    entry_tag = "?version_entry:";
   endif();
   push(object_hier, array(entry_tag, copy(capt)));
   set(capt, array());
  endif();
}


-> branch             {push(capt, call(branch))}
-> version            {push(capt, call(version))}
-> branch_tags        {push(capt, call(branch_tags))}
-> version_tags       {push(capt, call(version_tags))}
-> date               {push(capt, call(date))}
-> author             {push(capt, call(author))}
-> comment            {push(capt, call(comment))}
-> manifest           {push(capt, call(manifest))}
-> derived_from       {push(capt, call(derived_from))}



separator:    /-{20,}/
object:       /(?i)\nobject:\s+(\S+)/                                             I.return(array("?object:", flat_array(entry_groups())))
branch:       /(?i)\nbranch:\s+(\S+)/                                             I.return(array("?branch:", flat_array(entry_groups())))
branch_tags:  /(?is)\nbranch\s+tags:\s+(?:([^:]+?),\s*(.+?)\s*,\s*(\w+)|(\S+))/   I.return(array("?branch_tags:", flat_array(entry_groups())))
version_tags: /(?is)\nversion\s+tags:\s+(?:([^:]+?),\s*(.+?)\s*,\s*(\w+)|(\S+))/  I.return(array("?version_tags:", flat_array(entry_groups())))
version:      /(?i)\nversion:\s+(\S+)/                                            I.return(array("?version:", flat_array(entry_groups())))
date:         /(?i)\ndate:\s+(.+)/                                                I.return(array("?date:", flat_array(entry_groups())))
comment:      /(?i)\ncomment:\s+(.+)/                                             I.return(array("?comment:", flat_array(entry_groups())))
author:       /(?i)\nauthor:\s+(.+)/                                              I.return(array("?author:", flat_array(entry_groups())))
derived_from: /(?i)\nderived_from:\s+(\S+)/                                       I.return(array("?derived_from:", flat_array(entry_groups())))
manifest:     /(?is)\nmanifest:\s+.+?\n\n/                                        I.return(array("?manifest:"))
