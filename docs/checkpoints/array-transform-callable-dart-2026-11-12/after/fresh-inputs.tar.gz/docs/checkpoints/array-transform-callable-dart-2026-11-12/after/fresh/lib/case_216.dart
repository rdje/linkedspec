// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-transform-callable-result-guard/own_signature_variadic_missing_composed.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS10cmFuc2Zvcm0tY2FsbGFibGUtcmVzdWx0LWd1YXJkL293bl9zaWduYXR1cmVfdmFyaWFkaWNfbWlzc2luZ19jb21wb3NlZC5zcGVjIiwiZnVuY3Rpb25zIjpbeyJuYW1lIjoiY29sbGVjdCIsInNpZ25hdHVyZSI6eyJraW5kIjoiY2FsbGFibGVfc2lnbmF0dXJlIiwidmVyc2lvbiI6MSwicG9zaXRpb25hbF9wYXJhbXMiOlsiaGVhZCJdLCJyZXN0X3BhcmFtIjoicmVzdCIsIm1pbl9hcml0eSI6MSwibWF4X2FyaXR5IjpudWxsfSwiYm9keV9zb3VyY2UiOiJyZXR1cm4oW2hlYWRdKSIsImJvZHlfcGF5bG9hZCI6eyJraW5kIjoic3RhZ2VkX3BheWxvYWQiLCJ2ZXJzaW9uIjoxLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwiZnVuY3Rpb25fbmFtZSI6ImNvbGxlY3QiLCJzaWduYXR1cmUiOnsia2luZCI6ImNhbGxhYmxlX3NpZ25hdHVyZSIsInZlcnNpb24iOjEsInBvc2l0aW9uYWxfcGFyYW1zIjpbImhlYWQiXSwicmVzdF9wYXJhbSI6InJlc3QiLCJtaW5fYXJpdHkiOjEsIm1heF9hcml0eSI6bnVsbH0sInRleHQiOiJyZXR1cm4oW2hlYWRdKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyNiwiZW5kIjo0MCwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwcm92ZW5hbmNlIjpbeyJraW5kIjoic291cmNlX3NsaWNlIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjI2LCJlbmQiOjQwLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XX0sImJvZHlfcGFyc2Vfam9iIjp7ImtpbmQiOiJwYXJzZV9qb2IiLCJ2ZXJzaW9uIjoxLCJqb2JfaWQiOiJwYXJzZV9qb2I6ZnVuY3Rpb25fYm9keTpmdW5jdGlvbnMuMC5ib2R5X3NvdXJjZTphY3Rpb25pci1ib2R5LnNwZWM6YWN0aW9uX2Jsb2NrOjI2LTQwIiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsImZ1bmN0aW9uX25hbWUiOiJjb2xsZWN0Iiwic2lnbmF0dXJlIjp7ImtpbmQiOiJjYWxsYWJsZV9zaWduYXR1cmUiLCJ2ZXJzaW9uIjoxLCJwb3NpdGlvbmFsX3BhcmFtcyI6WyJoZWFkIl0sInJlc3RfcGFyYW0iOiJyZXN0IiwibWluX2FyaXR5IjoxLCJtYXhfYXJpdHkiOm51bGx9LCJ0ZXh0IjoicmV0dXJuKFtoZWFkXSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjYsImVuZCI6NDAsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicGFyc2VyX3NwZWNfaWQiOiJhY3Rpb25pci1ib2R5LnNwZWMiLCJ0b3BfcnVsZSI6ImFjdGlvbl9ibG9jayIsInJlc3VsdF9wb2xpY3kiOiJyZXBsYWNlX2ZpZWxkIiwicmVzdWx0X2ZpZWxkIjoiYm9keV9hc3QiLCJmYWlsdXJlX3BvbGljeSI6ImZhaWwiLCJkaWFnbm9zdGljX293bmVyIjoiZnVuY3Rpb25fYm9keSJ9LCJib2R5X2FzdCI6eyJraW5kIjoiYWN0aW9uX2Jsb2NrIiwic291cmNlIjoicmV0dXJuKFtoZWFkXSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxNH0sInN0YXRlbWVudHMiOlt7ImtpbmQiOiJhY3Rpb25fc3RtdCIsInNvdXJjZSI6InJldHVybihbaGVhZF0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTR9LCJleHByIjp7ImtpbmQiOiJjYWxsIiwic291cmNlIjoicmV0dXJuKFtoZWFkXSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxNH0sIm5hbWUiOiJyZXR1cm4iLCJzb3VyY2VfbWV0aG9kIjoicmV0dXJuIiwiYXJncyI6W3sia2luZCI6ImFycmF5X2xpdGVyYWwiLCJzb3VyY2UiOiJbaGVhZF0iLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6NywiZW5kIjoxM30sIml0ZW1zIjpbeyJraW5kIjoidmFyaWFibGUiLCJzb3VyY2UiOiJoZWFkIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjgsImVuZCI6MTJ9LCJuYW1lIjoiaGVhZCJ9XX1dfSwiZHJvcHNfdmFsdWUiOnRydWV9XX0sInNvdXJjZSI6ImZuIGNvbGxlY3QoaGVhZCwuLi5yZXN0KSB7cmV0dXJuKFtoZWFkXSl9Iiwic291cmNlX3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJib2R5X3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV0sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7b3JkZXI9XCJcIjtvdXQ9Y29sbGVjdCgpLnRha2UoMSkuc2V0X2tleSh7b3JkZXI9Y2F0KG9yZGVyLFwiS1wiKTtcImtcIn0se29yZGVyPWNhdChvcmRlcixcIlZcIik7MX0pLndpdGgoKXtvcmRlcj1jYXQob3JkZXIsXCJXXCIpO3JldHVybihcInJhblwiKX07cmV0dXJuKFtvdXQsb3JkZXJdKX0iLCJsaW5lIjozfSwiYm9keSI6W3sia2luZCI6eyJraW5kIjoiY29kZV9ibG9jayIsImxpZmVjeWNsZSI6IkkiLCJjb2RlIjoib3JkZXI9XCJcIjtvdXQ9Y29sbGVjdCgpLnRha2UoMSkuc2V0X2tleSh7b3JkZXI9Y2F0KG9yZGVyLFwiS1wiKTtcImtcIn0se29yZGVyPWNhdChvcmRlcixcIlZcIik7MX0pLndpdGgoKXtvcmRlcj1jYXQob3JkZXIsXCJXXCIpO3JldHVybihcInJhblwiKX07cmV0dXJuKFtvdXQsb3JkZXJdKSJ9LCJzb3VyY2UiOiJJIHtvcmRlcj1cIlwiO291dD1jb2xsZWN0KCkudGFrZSgxKS5zZXRfa2V5KHtvcmRlcj1jYXQob3JkZXIsXCJLXCIpO1wia1wifSx7b3JkZXI9Y2F0KG9yZGVyLFwiVlwiKTsxfSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKFwicmFuXCIpfTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
