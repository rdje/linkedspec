// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-transform-callable-result-guard/slice_free_hash_guard.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS10cmFuc2Zvcm0tY2FsbGFibGUtcmVzdWx0LWd1YXJkL3NsaWNlX2ZyZWVfaGFzaF9ndWFyZC5zcGVjIiwiZnVuY3Rpb25zIjpbeyJuYW1lIjoic3VwcGx5IiwicGFyYW1zIjpbInNlZWQiXSwiYXJpdHkiOjEsImJvZHlfc291cmNlIjoicmV0dXJuKHNlZWQpIiwiYm9keV9wYXlsb2FkIjp7ImtpbmQiOiJzdGFnZWRfcGF5bG9hZCIsInZlcnNpb24iOjEsIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJmdW5jdGlvbl9uYW1lIjoic3VwcGx5IiwicGFyYW1zIjpbInNlZWQiXSwiYXJpdHkiOjEsInRleHQiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MTcsImVuZCI6MjksImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicHJvdmVuYW5jZSI6W3sia2luZCI6InNvdXJjZV9zbGljZSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxNywiZW5kIjoyOSwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV19LCJib2R5X3BhcnNlX2pvYiI6eyJraW5kIjoicGFyc2Vfam9iIiwidmVyc2lvbiI6MSwiam9iX2lkIjoicGFyc2Vfam9iOmZ1bmN0aW9uX2JvZHk6ZnVuY3Rpb25zLjAuYm9keV9zb3VyY2U6YWN0aW9uaXItYm9keS5zcGVjOmFjdGlvbl9ibG9jazoxNy0yOSIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJmdW5jdGlvbl9uYW1lIjoic3VwcGx5IiwicGFyYW1zIjpbInNlZWQiXSwiYXJpdHkiOjEsInRleHQiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MTcsImVuZCI6MjksImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicGFyc2VyX3NwZWNfaWQiOiJhY3Rpb25pci1ib2R5LnNwZWMiLCJ0b3BfcnVsZSI6ImFjdGlvbl9ibG9jayIsInJlc3VsdF9wb2xpY3kiOiJyZXBsYWNlX2ZpZWxkIiwicmVzdWx0X2ZpZWxkIjoiYm9keV9hc3QiLCJmYWlsdXJlX3BvbGljeSI6ImZhaWwiLCJkaWFnbm9zdGljX293bmVyIjoiZnVuY3Rpb25fYm9keSJ9LCJib2R5X2FzdCI6eyJraW5kIjoiYWN0aW9uX2Jsb2NrIiwic291cmNlIjoicmV0dXJuKHNlZWQpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MTJ9LCJzdGF0ZW1lbnRzIjpbeyJraW5kIjoiYWN0aW9uX3N0bXQiLCJzb3VyY2UiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxMn0sImV4cHIiOnsia2luZCI6ImNhbGwiLCJzb3VyY2UiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxMn0sIm5hbWUiOiJyZXR1cm4iLCJzb3VyY2VfbWV0aG9kIjoicmV0dXJuIiwiYXJncyI6W3sia2luZCI6InZhcmlhYmxlIiwic291cmNlIjoic2VlZCIsInNvdXJjZV9zcGFuIjp7InN0YXJ0Ijo3LCJlbmQiOjExfSwibmFtZSI6InNlZWQifV19LCJkcm9wc192YWx1ZSI6dHJ1ZX1dfSwic291cmNlIjoiZm4gc3VwcGx5KHNlZWQpIHtyZXR1cm4oc2VlZCl9Iiwic291cmNlX3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJib2R5X3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV0sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7b3JkZXI9XCJcIjtvdXQ9c2xpY2Uoc3VwcGx5KFtcImhlYWRcIixcInRhaWxcIixcIm90aGVyXCJdKSwxLDEpLnNldF9rZXkoe29yZGVyPWNhdChvcmRlcixcIktcIik7XCJrXCJ9LHtvcmRlcj1jYXQob3JkZXIsXCJWXCIpOzF9KTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJvcmRlcj1cIlwiO291dD1zbGljZShzdXBwbHkoW1wiaGVhZFwiLFwidGFpbFwiLFwib3RoZXJcIl0pLDEsMSkuc2V0X2tleSh7b3JkZXI9Y2F0KG9yZGVyLFwiS1wiKTtcImtcIn0se29yZGVyPWNhdChvcmRlcixcIlZcIik7MX0pO3JldHVybihbb3V0LG9yZGVyXSkifSwic291cmNlIjoiSSB7b3JkZXI9XCJcIjtvdXQ9c2xpY2Uoc3VwcGx5KFtcImhlYWRcIixcInRhaWxcIixcIm90aGVyXCJdKSwxLDEpLnNldF9rZXkoe29yZGVyPWNhdChvcmRlcixcIktcIik7XCJrXCJ9LHtvcmRlcj1jYXQob3JkZXIsXCJWXCIpOzF9KTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
