// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-transform-callable-result-guard/own_initial_null_drop_front_receiver_with.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS10cmFuc2Zvcm0tY2FsbGFibGUtcmVzdWx0LWd1YXJkL293bl9pbml0aWFsX251bGxfZHJvcF9mcm9udF9yZWNlaXZlcl93aXRoLnNwZWMiLCJmdW5jdGlvbnMiOlt7Im5hbWUiOiJzdXBwbHkiLCJwYXJhbXMiOlsic2VlZCJdLCJhcml0eSI6MSwiYm9keV9zb3VyY2UiOiJyZXR1cm4oc2VlZCkiLCJib2R5X3BheWxvYWQiOnsia2luZCI6InN0YWdlZF9wYXlsb2FkIiwidmVyc2lvbiI6MSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sImZ1bmN0aW9uX25hbWUiOiJzdXBwbHkiLCJwYXJhbXMiOlsic2VlZCJdLCJhcml0eSI6MSwidGV4dCI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxNywiZW5kIjoyOSwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwcm92ZW5hbmNlIjpbeyJraW5kIjoic291cmNlX3NsaWNlIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjE3LCJlbmQiOjI5LCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XX0sImJvZHlfcGFyc2Vfam9iIjp7ImtpbmQiOiJwYXJzZV9qb2IiLCJ2ZXJzaW9uIjoxLCJqb2JfaWQiOiJwYXJzZV9qb2I6ZnVuY3Rpb25fYm9keTpmdW5jdGlvbnMuMC5ib2R5X3NvdXJjZTphY3Rpb25pci1ib2R5LnNwZWM6YWN0aW9uX2Jsb2NrOjE3LTI5IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsImZ1bmN0aW9uX25hbWUiOiJzdXBwbHkiLCJwYXJhbXMiOlsic2VlZCJdLCJhcml0eSI6MSwidGV4dCI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxNywiZW5kIjoyOSwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwYXJzZXJfc3BlY19pZCI6ImFjdGlvbmlyLWJvZHkuc3BlYyIsInRvcF9ydWxlIjoiYWN0aW9uX2Jsb2NrIiwicmVzdWx0X3BvbGljeSI6InJlcGxhY2VfZmllbGQiLCJyZXN1bHRfZmllbGQiOiJib2R5X2FzdCIsImZhaWx1cmVfcG9saWN5IjoiZmFpbCIsImRpYWdub3N0aWNfb3duZXIiOiJmdW5jdGlvbl9ib2R5In0sImJvZHlfYXN0Ijp7ImtpbmQiOiJhY3Rpb25fYmxvY2siLCJzb3VyY2UiOiJyZXR1cm4oc2VlZCkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MCwiZW5kIjoxMn0sInN0YXRlbWVudHMiOlt7ImtpbmQiOiJhY3Rpb25fc3RtdCIsInNvdXJjZSI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjEyfSwiZXhwciI6eyJraW5kIjoiY2FsbCIsInNvdXJjZSI6InJldHVybihzZWVkKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjEyfSwibmFtZSI6InJldHVybiIsInNvdXJjZV9tZXRob2QiOiJyZXR1cm4iLCJhcmdzIjpbeyJraW5kIjoidmFyaWFibGUiLCJzb3VyY2UiOiJzZWVkIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MTF9LCJuYW1lIjoic2VlZCJ9XX0sImRyb3BzX3ZhbHVlIjp0cnVlfV19LCJzb3VyY2UiOiJmbiBzdXBwbHkoc2VlZCkge3JldHVybihzZWVkKX0iLCJzb3VyY2Vfc3BhbiI6eyJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sImJvZHlfc3BhbiI6eyJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XSwicnVsZXMiOlt7ImhlYWRlciI6eyJsYWJlbCI6IlZhbHVlIiwiaXNfdG9wIjp0cnVlLCJtb2RlIjoiRGVmYXVsdCIsInJlc3QiOiJJIHtvcmRlcj1cIlwiO291dD1zdXBwbHkodW5kZWYpLmRyb3BfZnJvbnQoMSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKHZhbHVlLmNvdW50KCkpfTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJvcmRlcj1cIlwiO291dD1zdXBwbHkodW5kZWYpLmRyb3BfZnJvbnQoMSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKHZhbHVlLmNvdW50KCkpfTtyZXR1cm4oW291dCxvcmRlcl0pIn0sInNvdXJjZSI6Ikkge29yZGVyPVwiXCI7b3V0PXN1cHBseSh1bmRlZikuZHJvcF9mcm9udCgxKS53aXRoKCl7b3JkZXI9Y2F0KG9yZGVyLFwiV1wiKTtyZXR1cm4odmFsdWUuY291bnQoKSl9O3JldHVybihbb3V0LG9yZGVyXSl9IiwibGluZSI6M31dfV19';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
