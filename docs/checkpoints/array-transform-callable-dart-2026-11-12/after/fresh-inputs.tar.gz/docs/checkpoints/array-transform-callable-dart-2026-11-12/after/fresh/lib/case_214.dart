// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-transform-callable-result-guard/own_signature_fixed_extra_composed.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS10cmFuc2Zvcm0tY2FsbGFibGUtcmVzdWx0LWd1YXJkL293bl9zaWduYXR1cmVfZml4ZWRfZXh0cmFfY29tcG9zZWQuc3BlYyIsImZ1bmN0aW9ucyI6W3sibmFtZSI6InBhaXIiLCJwYXJhbXMiOlsibGVmdCIsInJpZ2h0Il0sImFyaXR5IjoyLCJib2R5X3NvdXJjZSI6InJldHVybihbbGVmdCxyaWdodF0pIiwiYm9keV9wYXlsb2FkIjp7ImtpbmQiOiJzdGFnZWRfcGF5bG9hZCIsInZlcnNpb24iOjEsIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJmdW5jdGlvbl9uYW1lIjoicGFpciIsInBhcmFtcyI6WyJsZWZ0IiwicmlnaHQiXSwiYXJpdHkiOjIsInRleHQiOiJyZXR1cm4oW2xlZnQscmlnaHRdKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoyMSwiZW5kIjo0MSwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwcm92ZW5hbmNlIjpbeyJraW5kIjoic291cmNlX3NsaWNlIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjIxLCJlbmQiOjQxLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XX0sImJvZHlfcGFyc2Vfam9iIjp7ImtpbmQiOiJwYXJzZV9qb2IiLCJ2ZXJzaW9uIjoxLCJqb2JfaWQiOiJwYXJzZV9qb2I6ZnVuY3Rpb25fYm9keTpmdW5jdGlvbnMuMC5ib2R5X3NvdXJjZTphY3Rpb25pci1ib2R5LnNwZWM6YWN0aW9uX2Jsb2NrOjIxLTQxIiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsImZ1bmN0aW9uX25hbWUiOiJwYWlyIiwicGFyYW1zIjpbImxlZnQiLCJyaWdodCJdLCJhcml0eSI6MiwidGV4dCI6InJldHVybihbbGVmdCxyaWdodF0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjIxLCJlbmQiOjQxLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInBhcnNlcl9zcGVjX2lkIjoiYWN0aW9uaXItYm9keS5zcGVjIiwidG9wX3J1bGUiOiJhY3Rpb25fYmxvY2siLCJyZXN1bHRfcG9saWN5IjoicmVwbGFjZV9maWVsZCIsInJlc3VsdF9maWVsZCI6ImJvZHlfYXN0IiwiZmFpbHVyZV9wb2xpY3kiOiJmYWlsIiwiZGlhZ25vc3RpY19vd25lciI6ImZ1bmN0aW9uX2JvZHkifSwiYm9keV9hc3QiOnsia2luZCI6ImFjdGlvbl9ibG9jayIsInNvdXJjZSI6InJldHVybihbbGVmdCxyaWdodF0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MjB9LCJzdGF0ZW1lbnRzIjpbeyJraW5kIjoiYWN0aW9uX3N0bXQiLCJzb3VyY2UiOiJyZXR1cm4oW2xlZnQscmlnaHRdKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjIwfSwiZXhwciI6eyJraW5kIjoiY2FsbCIsInNvdXJjZSI6InJldHVybihbbGVmdCxyaWdodF0pIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MjB9LCJuYW1lIjoicmV0dXJuIiwic291cmNlX21ldGhvZCI6InJldHVybiIsImFyZ3MiOlt7ImtpbmQiOiJhcnJheV9saXRlcmFsIiwic291cmNlIjoiW2xlZnQscmlnaHRdIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MTl9LCJpdGVtcyI6W3sia2luZCI6InZhcmlhYmxlIiwic291cmNlIjoibGVmdCIsInNvdXJjZV9zcGFuIjp7InN0YXJ0Ijo4LCJlbmQiOjEyfSwibmFtZSI6ImxlZnQifSx7ImtpbmQiOiJ2YXJpYWJsZSIsInNvdXJjZSI6InJpZ2h0Iiwic291cmNlX3NwYW4iOnsic3RhcnQiOjEzLCJlbmQiOjE4fSwibmFtZSI6InJpZ2h0In1dfV19LCJkcm9wc192YWx1ZSI6dHJ1ZX1dfSwic291cmNlIjoiZm4gcGFpcihsZWZ0LHJpZ2h0KSB7cmV0dXJuKFtsZWZ0LHJpZ2h0XSl9Iiwic291cmNlX3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJib2R5X3NwYW4iOnsibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV0sInJ1bGVzIjpbeyJoZWFkZXIiOnsibGFiZWwiOiJWYWx1ZSIsImlzX3RvcCI6dHJ1ZSwibW9kZSI6IkRlZmF1bHQiLCJyZXN0IjoiSSB7b3JkZXI9XCJcIjtvdXQ9cGFpcihcImhlYWRcIixcInRhaWxcIix7b3JkZXI9Y2F0KG9yZGVyLFwiWFwiKTtcImV4dHJhXCJ9KS50YWtlKDEpLnNldF9rZXkoe29yZGVyPWNhdChvcmRlcixcIktcIik7XCJrXCJ9LHtvcmRlcj1jYXQob3JkZXIsXCJWXCIpOzF9KS53aXRoKCl7b3JkZXI9Y2F0KG9yZGVyLFwiV1wiKTtyZXR1cm4oXCJyYW5cIil9O3JldHVybihbb3V0LG9yZGVyXSl9IiwibGluZSI6M30sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6Im9yZGVyPVwiXCI7b3V0PXBhaXIoXCJoZWFkXCIsXCJ0YWlsXCIse29yZGVyPWNhdChvcmRlcixcIlhcIik7XCJleHRyYVwifSkudGFrZSgxKS5zZXRfa2V5KHtvcmRlcj1jYXQob3JkZXIsXCJLXCIpO1wia1wifSx7b3JkZXI9Y2F0KG9yZGVyLFwiVlwiKTsxfSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKFwicmFuXCIpfTtyZXR1cm4oW291dCxvcmRlcl0pIn0sInNvdXJjZSI6Ikkge29yZGVyPVwiXCI7b3V0PXBhaXIoXCJoZWFkXCIsXCJ0YWlsXCIse29yZGVyPWNhdChvcmRlcixcIlhcIik7XCJleHRyYVwifSkudGFrZSgxKS5zZXRfa2V5KHtvcmRlcj1jYXQob3JkZXIsXCJLXCIpO1wia1wifSx7b3JkZXI9Y2F0KG9yZGVyLFwiVlwiKTsxfSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKFwicmFuXCIpfTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjN9XX1dfQ==';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
