// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "hash-value-result-guard/extra_merge_hash_receiver.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJoYXNoLXZhbHVlLXJlc3VsdC1ndWFyZC9leHRyYV9tZXJnZV9oYXNoX3JlY2VpdmVyLnNwZWMiLCJmdW5jdGlvbnMiOltdLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge29yZGVyPVwiXCI7b3V0PXtvcmRlcj1jYXQob3JkZXIsXCJTXCIpO3tcImFcIjoxfX0ubWVyZ2VfaGFzaCh7XCJiXCI6Mn0se29yZGVyPWNhdChvcmRlcixcIkFcIik7MH0pLnRha2Uoe29yZGVyPWNhdChvcmRlcixcIlRcIik7MX0pLndpdGgoKXtvcmRlcj1jYXQob3JkZXIsXCJXXCIpO3JldHVybihcInJhblwiKX07cmV0dXJuKFtvdXQsb3JkZXJdKX0iLCJsaW5lIjoxfSwiYm9keSI6W3sia2luZCI6eyJraW5kIjoiY29kZV9ibG9jayIsImxpZmVjeWNsZSI6IkkiLCJjb2RlIjoib3JkZXI9XCJcIjtvdXQ9e29yZGVyPWNhdChvcmRlcixcIlNcIik7e1wiYVwiOjF9fS5tZXJnZV9oYXNoKHtcImJcIjoyfSx7b3JkZXI9Y2F0KG9yZGVyLFwiQVwiKTswfSkudGFrZSh7b3JkZXI9Y2F0KG9yZGVyLFwiVFwiKTsxfSkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKFwicmFuXCIpfTtyZXR1cm4oW291dCxvcmRlcl0pIn0sInNvdXJjZSI6Ikkge29yZGVyPVwiXCI7b3V0PXtvcmRlcj1jYXQob3JkZXIsXCJTXCIpO3tcImFcIjoxfX0ubWVyZ2VfaGFzaCh7XCJiXCI6Mn0se29yZGVyPWNhdChvcmRlcixcIkFcIik7MH0pLnRha2Uoe29yZGVyPWNhdChvcmRlcixcIlRcIik7MX0pLndpdGgoKXtvcmRlcj1jYXQob3JkZXIsXCJXXCIpO3JldHVybihcInJhblwiKX07cmV0dXJuKFtvdXQsb3JkZXJdKX0iLCJsaW5lIjoxfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
