// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "hash-value-result-guard/drop_keys_compatible.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJoYXNoLXZhbHVlLXJlc3VsdC1ndWFyZC9kcm9wX2tleXNfY29tcGF0aWJsZS5zcGVjIiwiZnVuY3Rpb25zIjpbXSwicnVsZXMiOlt7ImhlYWRlciI6eyJsYWJlbCI6IlZhbHVlIiwiaXNfdG9wIjp0cnVlLCJtb2RlIjoiRGVmYXVsdCIsInJlc3QiOiJJIHtyZXR1cm4oW2Ryb3Bfa2V5cyh7XCJhXCI6MSxcImJcIjoyfSxcImFcIikuY291bnRfa2V5cygpLHtcImFcIjoxLFwiYlwiOjJ9LmRyb3Bfa2V5cyhcImFcIikuc29ydGVkX2tleXMoKS5qb2luX3ZhbHVlcyhcIixcIildKX0iLCJsaW5lIjoxfSwiYm9keSI6W3sia2luZCI6eyJraW5kIjoiY29kZV9ibG9jayIsImxpZmVjeWNsZSI6IkkiLCJjb2RlIjoicmV0dXJuKFtkcm9wX2tleXMoe1wiYVwiOjEsXCJiXCI6Mn0sXCJhXCIpLmNvdW50X2tleXMoKSx7XCJhXCI6MSxcImJcIjoyfS5kcm9wX2tleXMoXCJhXCIpLnNvcnRlZF9rZXlzKCkuam9pbl92YWx1ZXMoXCIsXCIpXSkifSwic291cmNlIjoiSSB7cmV0dXJuKFtkcm9wX2tleXMoe1wiYVwiOjEsXCJiXCI6Mn0sXCJhXCIpLmNvdW50X2tleXMoKSx7XCJhXCI6MSxcImJcIjoyfS5kcm9wX2tleXMoXCJhXCIpLnNvcnRlZF9rZXlzKCkuam9pbl92YWx1ZXMoXCIsXCIpXSl9IiwibGluZSI6MX1dfV19';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
