#[path = "generated/receiver_input_profile.rs"] pub mod case_receiver_input_profile;
#[path = "generated/receiver_null_with_profile.rs"] pub mod case_receiver_null_with_profile;
