fn main() {
let result = hash_view_result_rust_fresh::case_receiver_input_profile::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("HASH_VIEW_RUST_FRESH receiver_input_profile {}", observed);
let result = hash_view_result_rust_fresh::case_receiver_null_with_profile::execute("x");
let observed = match result { Ok(value) => serde_json::json!({"value": value}), Err(error) => serde_json::json!({"error": error.to_string()}) };
println!("HASH_VIEW_RUST_FRESH receiver_null_with_profile {}", observed);
}
