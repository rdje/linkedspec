function _generated_source_test_spec()
    value = string("λ:", Char(0x24))
    source = "Top::\n /é/\n E { return(" * String(JSON3.write(value)) * ") }\n"
    return compile_spec(parse_spec(source)), value
end

function _generated_source_host_process(scratch, runner, generated, private_depot)
    separator = Sys.iswindows() ? ';' : ':'
    parent_depot = get(ENV, "JULIA_DEPOT_PATH", "")
    depot_path = isempty(parent_depot) ?
        private_depot : string(private_depot, separator, parent_depot)
    load_path = join(
        [scratch, joinpath(REPO_ROOT, "julia"), "@stdlib"],
        separator,
    )
    command = `$(Base.julia_cmd()) --project=$scratch --startup-file=no --history-file=no --compiled-modules=no $runner $generated`
    environment = copy(ENV)
    environment["JULIA_DEPOT_PATH"] = depot_path
    environment["JULIA_LOAD_PATH"] = load_path
    environment["JULIA_PKG_OFFLINE"] = "true"
    output = IOBuffer()
    process = run(
        pipeline(ignorestatus(setenv(command, environment)); stdout = output, stderr = output),
    )
    return success(process), String(take!(output))
end

const _GENERATED_FAMILY_MATRIX_SOURCE = raw"""
DefaultRoot::
 I { set(words, []) }
 /hello[ \t]+(\w+)/
 LE { push(words, match_group(0)) }
 E { return(copy(words)) }

OrAcode:|
 /go/ -> OrDone { return("or-acode") }
OrDone: /go/

AndSingle:AND
 /one/ -> AndSingleDone { return("and-single") }
AndSingleDone: /one/

AndSeq:AND
 /a/ -> AndSeqFirst
 /[ \t]+b/ -> AndSeqSecond { return("and-seq") }
AndSeqFirst: /a/
AndSeqSecond: /[ \t]+b/

AndBcode:AND
 => AndBlindA
 => AndBlindB
 E { return("and-bcode") }
AndBlindA: /a/
AndBlindB: /[ \t]+b/

OrBcode:|
 => OrBlindA
 => OrBlindB
 E { return(cat("or-bcode:", retv)) }
OrBlindA: /a/ E { return("A") }
OrBlindB: /b/ E { return("B") }

RepAcode:OR{2,3}
 I { set(rep_acode, []) }
 /a/ -> RepA { push(rep_acode, match_text()) }
 /b/ -> RepB { push(rep_acode, match_text()) }
 E { return(copy(rep_acode)) }
RepA: /a/
RepB: /b/

RepBcode:OR{2,3}
 I { set(rep_bcode, []) }
 => RepBlindA
 => RepBlindB
 LE { push(rep_bcode, retv) }
 E { return(copy(rep_bcode)) }
RepBlindA:& /a/ LE { return("A") }
RepBlindB:& /b/ LE { return("B") }

RepAndAcode:AND{2}
 I { set(rep_and_acode, []); set(rep_and_acode_pair, []) }
 /a/ -> RepAndA { push(rep_and_acode_pair, match_text()) }
 /b/ -> RepAndB { push(rep_and_acode_pair, match_text()) }
 IT { push(rep_and_acode, copy(rep_and_acode_pair)); set(rep_and_acode_pair, []) }
 E { return(copy(rep_and_acode)) }
RepAndA: /a/
RepAndB: /b/

RepAndBcode:AND{2}
 I { set(rep_and_bcode, []); set(rep_and_bcode_group, []) }
 => RepAndBlindA { push(rep_and_bcode_group, retv) }
 => RepAndBlindB { push(rep_and_bcode_group, retv) }
 IT { push(rep_and_bcode, copy(rep_and_bcode_group)); set(rep_and_bcode_group, []) }
 E { return(copy(rep_and_bcode)) }
RepAndBlindA:& /a/ LE { return("A") }
RepAndBlindB:& /b/ LE { return("B") }
"""

const _GENERATED_FAMILY_CASES = [
    (label = "DefaultRoot", family = "default", input = "hello one hello two"),
    (label = "OrAcode", family = "or_acode", input = "go"),
    (label = "AndSingle", family = "and_single_acode", input = "one"),
    (label = "AndSeq", family = "and_acode_seq", input = "a b"),
    (label = "AndBcode", family = "and_bcode", input = "a b"),
    (label = "OrBcode", family = "or_bcode", input = "a"),
    (label = "RepAcode", family = "rep_acode", input = "abab"),
    (label = "RepBcode", family = "rep_bcode", input = "abab"),
    (label = "RepAndAcode", family = "rep_and_acode", input = "abab"),
    (label = "RepAndBcode", family = "rep_and_bcode", input = "abab"),
]

function _generated_plan_failure(call)
    try
        call()
    catch error
        return error
    end
    return nothing
end

const JULIA_GENERATED_SOURCE_ACCEPTED_SUBSET_COUNT = 8

function _parse_generated_corpus_spec(source)
    try
        return parse_spec(source)
    catch error
        if error isa SpecParseException
            return parse_spec_with_staged_user_function_definitions(source)
        end
        rethrow()
    end
end

@testset "Generated Julia source matches contract accepted subset" begin
    contract_path = joinpath(
        REPO_ROOT,
        "capability_conformance",
        "generated_source_contract.json",
    )
    contract = JSON3.read(read(contract_path, String), Dict{String,Any})
    accepted_subset = String[
        String(name) for name in contract["corpus_proof"]["accepted_subset"]
    ]
    @test length(accepted_subset) == JULIA_GENERATED_SOURCE_ACCEPTED_SUBSET_COUNT

    corpus_root = joinpath(REPO_ROOT, "rust", "linkedspec-runtime", "tests", "corpus")
    validation = load_corpus_fixtures(corpus_root)
    fixtures = Dict(fixture.name => fixture for fixture in validation.fixtures)
    @test all(name -> haskey(fixtures, name), accepted_subset)

    scratch = mktempdir()
    private_depot = joinpath(scratch, "depot")
    mkpath(private_depot)
    try
        write(
            joinpath(scratch, "Project.toml"),
            "name = \"GeneratedSubsetHost\"\n" *
            "uuid = \"646d7ef1-f5fe-4f66-9fcc-2aee85c02fed\"\n" *
            "version = \"0.1.0\"\n",
        )
        cases = Dict{String,Any}[]
        for (index, case_name) in enumerate(accepted_subset)
            fixture = fixtures[case_name]
            spec = _parse_generated_corpus_spec(fixture.spec_source)
            compiled = compile_spec(spec)
            interpreter_value = runtime_execute(
                LinkedSpecRuntimeEngine(compiled),
                fixture.input_text,
            ).value
            @test interpreter_value == fixture.expected_json

            identity = "generated-source/julia-subset/$case_name.spec"
            generated_path = joinpath(scratch, "case_$index.jl")
            write(generated_path, emit_julia_source_v2(compiled, identity))
            push!(cases, Dict(
                "name" => case_name,
                "path" => generated_path,
                "input" => fixture.input_text,
                "expected" => fixture.expected_json,
                "identity" => identity,
                "plan" => [to_json(row) for row in build_generated_rule_plan(compiled)],
            ))
        end
        write(joinpath(scratch, "subset.json"), JSON3.write(Dict("cases" => cases)))
        runner_path = joinpath(scratch, "runner.jl")
        write(
            runner_path,
            """
import JSON3
import LinkedSpecJulia

normalize(value) = value
normalize(value::AbstractVector) = [normalize(item) for item in value]
normalize(value::AbstractDict) = Dict(String(key) => normalize(item) for (key, item) in value)
latest_binding(owner::Module, name::Symbol) =
    Base.invokelatest(() -> Core.getglobal(owner, name))

function main()
subset = JSON3.read(read(joinpath(dirname(ARGS[1]), "subset.json"), String))
values = Dict{String,Any}()
metadata = Dict{String,Any}()
plans = Dict{String,Any}()
first_parser = nothing
first_input = nothing
for (index, case) in enumerate(subset["cases"])
    host = Module(Symbol("GeneratedSubsetCase", index))
    Base.include(host, String(case["path"]))
    parser = Base.invokelatest(() -> getfield(host, :LinkedSpecGeneratedParser))
    plan_function = latest_binding(parser, :plan)
    validate_function = latest_binding(parser, :validate_plan)
    execute_function = latest_binding(parser, :execute)
    metadata_function = latest_binding(parser, :metadata)
    case_plan = Base.invokelatest(plan_function)
    Base.invokelatest(validate_function, case_plan)
    name = String(case["name"])
    values[name] = normalize(Base.invokelatest(execute_function, String(case["input"])))
    metadata[name] = normalize(LinkedSpecJulia.to_json(Base.invokelatest(metadata_function)))
    plans[name] = normalize([LinkedSpecJulia.to_json(row) for row in case_plan])
    @assert values[name] == normalize(case["expected"])
    @assert metadata[name] == Dict(
        "contract_id" => "linkedspec-generated-source-v2",
        "format_version" => 2,
        "source_identity" => String(case["identity"]),
    )
    @assert plans[name] == normalize(case["plan"])
    if index == 1
        first_parser = parser
        first_input = String(case["input"])
    end
end
trace_io = IOBuffer()
Base.invokelatest(
    latest_binding(first_parser, :execute_with_trace),
    first_input,
    LinkedSpecJulia.trace_config_enabled("low");
    stdout_io = trace_io,
)
trace = String(take!(trace_io))
@assert occursin("generated_rule_enter", trace)
@assert occursin("generated_family_decision", trace)
@assert occursin("generated_rule_exit", trace)
@assert occursin("generated-source/julia-subset", trace)
print("generated-subset-host-ok")
end

main()
""",
        )
        passed, output = _generated_source_host_process(
            scratch,
            runner_path,
            first(cases)["path"],
            private_depot,
        )
        @test passed
        @test output == "generated-subset-host-ok"
    finally
        rm(scratch; recursive = true, force = true)
    end
    @test !ispath(scratch)
end

@testset "Generated Julia family plan and direct execution" begin
    compiled = compile_spec(parse_spec(_GENERATED_FAMILY_MATRIX_SOURCE))
    identity = "generated-source/julia-family-matrix.spec"
    plan = build_generated_rule_plan(compiled)
    plan_by_label = Dict(row.label => row.family for row in plan)

    @test [plan_by_label[case.label] for case in _GENERATED_FAMILY_CASES] ==
          [case.family for case in _GENERATED_FAMILY_CASES]
    @test Set(case.family for case in _GENERATED_FAMILY_CASES) ==
          Set(generated_rule_family_name(family) for family in instances(GeneratedRuleFamily))
    @test validate_generated_rule_plan_v2(compiled, plan, identity) == plan_by_label

    cursor_contract = JSON3.read(
        read(
            joinpath(REPO_ROOT, "capability_conformance", "rule_local_cursor_contract.json"),
            String,
        ),
        Dict{String,Any},
    )["generated_source_v2"]
    @test Dict(
        generated_rule_family_name(family) => (
            LinkedSpecJulia._generated_family_cursor_policy(
                generated_rule_family_name(family),
            ) == SeekParseMode ? "seek" : "consume"
        ) for family in instances(GeneratedRuleFamily)
    ) == merge(
        Dict(String(family) => "seek" for family in cursor_contract["seek_families"]),
        Dict(String(family) => "consume" for family in cursor_contract["consume_families"]),
    )

    version_failure = _generated_plan_failure(() -> validate_generated_rule_plan_v2(
        compiled,
        plan,
        identity;
        actual_contract = "linkedspec-generated-source-v1",
    ))
    @test version_failure isa GeneratedSourceException
    @test version_failure.stage == ValidateGeneratedPlanStage
    @test version_failure.code == GeneratedSourceContractVersionMismatchCode
    @test to_json(version_failure) == Dict(
        "type" => "generated_source_error",
        "stage" => "validate_generated_plan",
        "code" => "generated_source_contract_version_mismatch",
        "summary" => "Generated source contract does not match the active validator",
        "source_identity" => identity,
        "detail" => "regenerate the generated artifact from its .spec source",
        "expected_contract" => "linkedspec-generated-source-v2",
        "actual_contract" => "linkedspec-generated-source-v1",
    )

    generated_v2_results = Dict{String,Any}()
    for case in _GENERATED_FAMILY_CASES
        native = runtime_execute(
            LinkedSpecRuntimeEngine(compiled),
            case.input;
            top_rule = case.label,
        ).value
        generated_v2_results[case.label] = native
        @test execute_generated_parser_v2(
            compiled,
            plan,
            case.input,
            identity;
            top_rule = case.label,
        ) == native
    end

    mutations = [
        (plan[1:(end - 1)], GeneratedPlanRowCountMismatchCode),
        ([GeneratedPlanRow("Wrong", plan[1].family); plan[2:end]], GeneratedPlanLabelMismatchCode),
        ([GeneratedPlanRow(plan[1].label, "or_acode"); plan[2:end]], GeneratedPlanFamilyMismatchCode),
        ([GeneratedPlanRow(plan[1].label, "invented"); plan[2:end]], GeneratedPlanUnknownFamilyCode),
    ]
    for (mutated, expected_code) in mutations
        failure = _generated_plan_failure(
            () -> validate_generated_rule_plan_v2(compiled, mutated, identity),
        )
        @test failure isa GeneratedSourceException
        @test failure.stage == ValidateGeneratedPlanStage
        @test failure.code == expected_code
    end

    generated = emit_julia_source_v2(compiled, identity)
    mktempdir() do scratch
        private_depot = joinpath(scratch, "depot")
        mkpath(private_depot)
        write(
            joinpath(scratch, "Project.toml"),
            "name = \"GeneratedFamilyHost\"\n" *
            "uuid = \"bbd21f80-f220-41f6-ab13-8beabf6a251f\"\n" *
            "version = \"0.1.0\"\n",
        )
        generated_path = joinpath(scratch, "generated_parser.jl")
        runner_path = joinpath(scratch, "runner.jl")
        manifest_path = joinpath(scratch, "matrix.json")
        write(generated_path, generated)
        write(
            manifest_path,
            JSON3.write(Dict(
                "cases" => [
                    Dict(
                        "label" => case.label,
                        "family" => case.family,
                        "input" => case.input,
                        "expected" => generated_v2_results[case.label],
                    )
                    for case in _GENERATED_FAMILY_CASES
                ],
            )),
        )
        write(
            runner_path,
            """
import JSON3
import LinkedSpecJulia
include(ARGS[1])
const Parser = LinkedSpecGeneratedParser
matrix = JSON3.read(read(joinpath(dirname(ARGS[1]), "matrix.json"), String))
plan = Dict(row.label => row.family for row in Parser.plan())
Parser.validate_plan(Parser.plan())
for case in matrix["cases"]
    label = String(case["label"])
    @assert plan[label] == String(case["family"])
    @assert Parser.execute(String(case["input"]); top_rule = label) == case["expected"]
end
trace_io = IOBuffer()
first_case = first(matrix["cases"])
Parser.execute_with_trace(
    String(first_case["input"]),
    LinkedSpecJulia.trace_config_enabled("low");
    top_rule = String(first_case["label"]),
    stdout_io = trace_io,
)
trace = String(take!(trace_io))
@assert occursin("generated_rule_enter", trace)
@assert occursin("generated_family_decision", trace)
@assert occursin("generated_rule_exit", trace)
@assert occursin("generated-source/julia-family-matrix.spec", trace)
print("generated-family-host-ok")
""",
        )
        passed, output = _generated_source_host_process(
            scratch,
            runner_path,
            generated_path,
            private_depot,
        )
        @test passed
        @test output == "generated-family-host-ok"
    end
end

@testset "Generated Julia source scaffold" begin
    compiled, expected_value = _generated_source_test_spec()
    identity = string("generated/λ", Char(0x24), ".spec")
    generated = emit_julia_source_v2(compiled, identity)
    inline_generated = emit_julia_source(compiled)

    @test generated == emit_julia_source_v2(compiled, identity)
    @test generated != emit_julia_source_v2(compiled, "generated/other.spec")
    @test generated == replace(
        inline_generated,
        bytes2hex(codeunits("<inline>")) => bytes2hex(codeunits(identity)),
    )
    @test occursin("module LinkedSpecGeneratedParser", generated)
    @test occursin("diagnostic_output_sink = nothing", generated)
    @test occursin(bytes2hex(codeunits(identity)), generated)
    @test occursin(bytes2hex(codeunits(expected_value)), generated)
    @test !occursin(identity, generated)
    @test !occursin("cursor_policy", generated)

    metadata = GeneratedSourceMetadata(identity)
    @test to_json(metadata) == Dict(
        "contract_id" => "linkedspec-generated-source-v2",
        "format_version" => 2,
        "source_identity" => identity,
    )

    empty_identity_error = try
        emit_julia_source_v2(compiled, "")
        nothing
    catch error
        error
    end
    @test empty_identity_error isa GeneratedSourceException
    @test to_json(empty_identity_error) == Dict(
        "type" => "generated_source_error",
        "stage" => "emit_source",
        "code" => "generated_source_emit_failed",
        "summary" => "Generated Julia source identity must not be empty",
        "source_identity" => "",
        "detail" => "source_identity is required",
    )

    compile_error = generated_source_compile_failed(identity, ArgumentError("broken payload"))
    @test generated_source_stage_name(compile_error.stage) ==
          "compile_or_load_generated_source"
    @test generated_source_code_name(compile_error.code) ==
          "generated_source_compile_failed"
    @test sprint(showerror, compile_error) ==
          "Generated Julia source failed to compile or load: ArgumentError: broken payload"

    mktempdir() do scratch
        private_depot = joinpath(scratch, "depot")
        mkpath(private_depot)
        write(
            joinpath(scratch, "Project.toml"),
            "name = \"GeneratedSourceHost\"\n" *
            "uuid = \"4096c05b-8f48-4ee1-89a1-52480dbf986d\"\n" *
            "version = \"0.1.0\"\n",
        )
        generated_path = joinpath(scratch, "generated_parser.jl")
        legacy_corrupt_path = joinpath(scratch, "legacy_v1_corrupt.jl")
        runner_path = joinpath(scratch, "runner.jl")
        write(generated_path, generated)
        corrupted_payload = replace(
            generated,
            r"const _COMPILED_SPEC_JSON_HEX = \"[^\"]+\"" =>
                "const _COMPILED_SPEC_JSON_HEX = \"not-hex\"",
        )
        write(
            legacy_corrupt_path,
            replace(
                corrupted_payload,
                "linkedspec-generated-source-v2" => "linkedspec-generated-source-v1",
            ),
        )
        write(
            runner_path,
            """
import LinkedSpecJulia

legacy_failure = try
    Base.include(
        Module(:LegacyGeneratedSourceHost),
        joinpath(dirname(ARGS[1]), "legacy_v1_corrupt.jl"),
    )
    nothing
catch error
    error
end
legacy_failure = legacy_failure isa LoadError ? legacy_failure.error : legacy_failure
@assert legacy_failure isa LinkedSpecJulia.GeneratedSourceException
@assert LinkedSpecJulia.to_json(legacy_failure) == Dict(
    "type" => "generated_source_error",
    "stage" => "validate_generated_plan",
    "code" => "generated_source_contract_version_mismatch",
    "summary" => "Generated source contract does not match the active validator",
    "source_identity" => string("generated/λ", Char(0x24), ".spec"),
    "detail" => "regenerate the generated artifact from its .spec source",
    "expected_contract" => "linkedspec-generated-source-v2",
    "actual_contract" => "linkedspec-generated-source-v1",
)

include(ARGS[1])

const Parser = LinkedSpecGeneratedParser
expected_identity = string("generated/λ", Char(0x24), ".spec")
expected_value = string("λ:", Char(0x24))
@assert Parser.LINKEDSPEC_GENERATED_SOURCE_CONTRACT == "linkedspec-generated-source-v2"
@assert Parser.LINKEDSPEC_GENERATED_SOURCE_FORMAT == 2
@assert LinkedSpecJulia.to_json(Parser.metadata()) == Dict(
    "contract_id" => "linkedspec-generated-source-v2",
    "format_version" => 2,
    "source_identity" => expected_identity,
)
@assert Parser.execute("é") == expected_value

execution_error = try
    Parser.execute("é"; top_rule = "Missing")
    nothing
catch error
    error
end
@assert execution_error isa LinkedSpecJulia.GeneratedSourceException
@assert LinkedSpecJulia.generated_source_stage_name(execution_error.stage) == "select_entry_rule"
@assert LinkedSpecJulia.generated_source_code_name(execution_error.code) == "entry_rule_not_found"
@assert execution_error.entry_rule == "Missing"
@assert execution_error.rule_label == "Missing"
print("generated-host-ok")
""",
        )

        passed, output = _generated_source_host_process(
            scratch,
            runner_path,
            generated_path,
            private_depot,
        )
        @test passed
        @test output == "generated-host-ok"

        corrupt_path = joinpath(scratch, "corrupt_parser.jl")
        corrupt_source = replace(
            generated,
            r"const _COMPILED_SPEC_JSON_HEX = \"[0-9a-f]+\"" =>
                "const _COMPILED_SPEC_JSON_HEX = \"00\"",
        )
        @test corrupt_source != generated
        write(corrupt_path, corrupt_source)
        write(
            runner_path,
            """
import LinkedSpecJulia
failure = try
    include(ARGS[1])
    nothing
catch error
    while error isa LoadError
        error = error.error
    end
    error
end
@assert failure isa LinkedSpecJulia.GeneratedSourceException
projection = LinkedSpecJulia.to_json(failure)
@assert projection["type"] == "generated_source_error"
@assert projection["stage"] == "compile_or_load_generated_source"
@assert projection["code"] == "generated_source_compile_failed"
@assert projection["source_identity"] == string("generated/λ", Char(0x24), ".spec")
print("generated-failure-ok")
""",
        )
        failed_as_expected, failure_output = _generated_source_host_process(
            scratch,
            runner_path,
            corrupt_path,
            private_depot,
        )
        @test failed_as_expected
        @test failure_output == "generated-failure-ok"
    end
end

# The shared source-aware nesting fixture has independent value/kind/span oracles.
include(joinpath(REPO_ROOT, "tests", "language-readiness", "nested-tree", "julia_checks.jl"))

function _nested_tree_variants(source)
    prefix = " if(matches(input_slice(0, cursor_pos()), /[^ \\t\\r\\n\\f\\x0B]/));\n" *
        "  exit_now(1);\n endif();\n"
    gap = " -> Invalid { exit_now(1) }\n"
    span = "[start, cursor_pos()]"
    @test length(findall(prefix, source)) == 1
    @test length(findall(gap, source)) == 2
    @test length(findall(span, source)) == 1
    return [
        "original" => source,
        "prefix" => replace(source, prefix => ""),
        "gap" => replace(source, gap => ""),
        "span" => replace(source, span => "[cursor_pos(), cursor_pos()]"),
    ]
end

function _context_name_variants(source)
    comparison = "  if(str_ne(match_group(0), name));\n   exit_now(2);\n  endif();\n"
    recursive_edge = " -> Element { push(children, call(Element)) }\n"
    corrupt_edge = " -> Element { push(children, call(Element)); name = \"lost\" }\n"
    span = "[start, cursor_pos()]"
    @test length(findall(comparison, source)) == 1
    @test length(findall(recursive_edge, source)) == 1
    @test length(findall(span, source)) == 1
    return [
        "original" => source,
        "comparison" => replace(source, comparison => ""),
        "state" => replace(source, recursive_edge => corrupt_edge),
        "span" => replace(source, span => "[cursor_pos(), cursor_pos()]"),
    ]
end

function _verify_readiness_fixture(name, make_variants, labels, options)
    fixture = joinpath(REPO_ROOT, "tests", "language-readiness", name)
    executions = 2 * (options.accepted_count + 2 * options.rejected_count)
    source = read(joinpath(fixture, "grammar.spec"), String)
    cases = JSON3.read(read(joinpath(fixture, "cases.json"), String), Dict{String,Any})
    variants = make_variants(source)
    emitted = Dict{String,String}()
    for (id, variant_source) in variants
        parsed = parse_spec_with_staged_user_function_definitions(variant_source)
        validate_spec(parsed)
        reconstructed = from_json(SpecFile, JSON3.read(JSON3.write(to_json(parsed)), Dict{String,Any}))
        validate_spec(reconstructed)
        for spec in (parsed, reconstructed)
            compiled = compile_spec(spec)
            plan = build_generated_rule_plan(compiled)
            validate_generated_rule_plan_v2(compiled, plan, id)
            @test [row.label for row in plan] == labels
            engine = LinkedSpecRuntimeEngine(compiled)
            # Only these two native routes retain an engine across the sequence.
            @test NestedTreeChecks.variant(id, cases, input -> runtime_parse(engine, input).value; options...)
            # The supported generated API constructs an engine for each invocation.
            @test NestedTreeChecks.variant(id, cases,
                input -> execute_generated_parser_v2(compiled, plan, input, id); options...)
        end
        emitted[id] = emit_julia_source_v2(compile_spec(parsed), "$name/$id")
    end

    scratch_path = Ref("")
    mktempdir() do scratch
        scratch_path[] = scratch
        private_depot = joinpath(scratch, "depot")
        mkpath(private_depot)
        write(joinpath(scratch, "Project.toml"),
            "name = \"NestedTreeGeneratedHost\"\nuuid = \"d80d8a84-f81a-4c4a-9d45-823368f38fe6\"\nversion = \"0.1.0\"\n")
        cp(joinpath(fixture, "cases.json"), joinpath(scratch, "cases.json"))
        cp(joinpath(REPO_ROOT, "tests", "language-readiness", "nested-tree", "julia_checks.jl"),
            joinpath(scratch, "checks.jl"))
        write(joinpath(scratch, "config.json"), JSON3.write(Dict(
            "name" => name, "ids" => first.(variants), "options" => options,
            "executions" => executions,
        )))
        for (id, generated) in emitted
            write(joinpath(scratch, "$id.jl"), generated)
        end
        runner = joinpath(scratch, "runner.jl")
        write(runner, raw"""
using LinkedSpecJulia, JSON3
include(joinpath(ARGS[1], "checks.jl"))
latest_binding(owner::Module, name::Symbol) =
    Base.invokelatest(() -> Core.getglobal(owner, name))
function main()
    cases = JSON3.read(read(joinpath(ARGS[1], "cases.json"), String), Dict{String,Any})
    config = JSON3.read(read(joinpath(ARGS[1], "config.json"), String), Dict{String,Any})
    name = config["name"]
    settings = config["options"]
    options = (
        accepted_count = settings["accepted_count"], rejected_count = settings["rejected_count"],
        recovery_id = settings["recovery_id"], span_case = settings["span_case"],
        span_end = settings["span_end"],
    )
    modules = 0
    for id in config["ids"]
        host = Module(gensym(:NestedTreeGenerated))
        Base.include(host, joinpath(ARGS[1], "$id.jl"))
        parser = latest_binding(host, :LinkedSpecGeneratedParser)
        metadata = Base.invokelatest(latest_binding(parser, :metadata))
        NestedTreeChecks.exact_json(to_json(metadata), Dict(
            "contract_id" => "linkedspec-generated-source-v2",
            "format_version" => 2,
            "source_identity" => "$name/$id",
        ))
        plan = Base.invokelatest(latest_binding(parser, :plan))
        Base.invokelatest(latest_binding(parser, :validate_plan), plan)
        execute = latest_binding(parser, :execute)
        @assert NestedTreeChecks.variant(id, cases, input -> Base.invokelatest(execute, input); options...)
        modules += 1
    end
    print(JSON3.write(Dict("modules" => modules, "original_executions" => config["executions"], "mutations" => 3)))
end
main()
""")
        passed, output = _generated_source_host_process(scratch, runner, scratch, private_depot)
        @test passed
        if passed
            @test NestedTreeChecks.exact_json(JSON3.read(output, Dict{String,Any}),
                Dict("modules" => 4, "original_executions" => executions, "mutations" => 3))
        else
            @error "readiness emitted child failed" name output
        end
    end
    @test !ispath(scratch_path[])
end

@testset "Bounded nesting across public Julia carriers" begin
    _verify_readiness_fixture("nested-tree", _nested_tree_variants,
        ["Top", "List", "Atom", "Space", "Invalid"],
        (accepted_count = 6, rejected_count = 7, recovery_id = "nested_state",
            span_case = "nested_state", span_end = 9))
end

@testset "Bounded context names across public Julia carriers" begin
    _verify_readiness_fixture("context-names", _context_name_variants,
        ["Top", "Element", "Text", "Space", "Invalid"],
        (accepted_count = 11, rejected_count = 17, recovery_id = "siblings_restore_parent",
            span_case = "nested_distinct", span_end = 17))
end

include(joinpath(REPO_ROOT, "tests", "language-readiness", "lossless-child", "julia_carriers.jl"))

function _with_lossless_readiness_workspace(action::Function)
    scratch_path = Ref("")
    mktempdir() do scratch
        scratch_path[] = scratch
        action(scratch)
    end
    @test !ispath(scratch_path[])
end

@testset "Bounded lossless and actual child Julia carriers" begin
    LosslessChildCarriers.verify(REPO_ROOT, _with_lossless_readiness_workspace, _generated_source_host_process)
end
