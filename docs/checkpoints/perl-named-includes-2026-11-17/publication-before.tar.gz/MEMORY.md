# MEMORY

- activation_commit: `5909a0253a4ead9a1a430ba64d0de4836709641f` — clean named-include activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.1.0` — Perl145 lexical loader/caller census.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.1.1.0` (active); task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: PNT; continue after each clean leaf.
- next_action: Freeze and qualify fourteen named include expressions/targets and their suite/support/caller-plan roles before the remaining fixed and constructed IO expansion.
- in_flight_uncommitted: Named Perl include qualification; no background job.
- evidence: docs/checkpoints/perl-loader-token-census-2026-11-17/REVIEW.md; readonly review.py/optional --current; optional --relex reruns only the retained static lexer. PPI145 roundtrip/unknown0/stderr0/current162; overlapping groups IO122/eval143/helpers84/nonWord127/nonblock-do3. Four specimens/promoted-source RED/compiler255; no capture replay or LinkedSpec test execution.
- findings: Word tokens are not necessarily builtin calls; non-Word/heredoc payloads may interpolate or execute later. Three do-containing sources include AST assigned-regex, scalar-copy probes and eleven callable includes. Resolve exact target/caller/conditional roles in child1, generated/inline2 and full semantic reconciliation before admission.
- limits: Fixed/constructed1/generated-inline2, excluded/computed/transitive/semantic, generated Dart/frozen-input and default-literal/repeated ActionIR registration remain open. External PPI/Perl/library/native/outer-first-use/per-read/source-origin/physical4.2/SESSION5 and the original Lua reader-epoch gap remain explicit.
- publication: Activation/cached4683555e estimate1,488,917,566 bytes/126 ahead/11,082,434-byte margin to director1.5GB excludes this slice. Selected telemetry will be retained; raw pack/full tables ignored; independent size30/native4.2 gaps. All prerequisites/exact canonical proof remain.
- locality: Only this repository writable; submodules black boxes. Same-volume serial jobs/shared24GB/director90-percent rising trend policy. Last cleanup November16 10:59UTC remains under24h; nothing removed. Normal hooks remain mandatory.
