// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "array-pipeline-result-guard/needed_delimiter_receiver.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJhcnJheS1waXBlbGluZS1yZXN1bHQtZ3VhcmQvbmVlZGVkX2RlbGltaXRlcl9yZWNlaXZlci5zcGVjIiwiZnVuY3Rpb25zIjpbXSwicnVsZXMiOlt7ImhlYWRlciI6eyJsYWJlbCI6IlZhbHVlIiwiaXNfdG9wIjp0cnVlLCJtb2RlIjoiRGVmYXVsdCIsInJlc3QiOiJJIHtvcmRlcj1cIlwiO3JldHVybihbXCJoZWFkOnRhaWxcIl0uc3BsaXRfZWFjaCh7aXRlbXM9XCJiYWRcIjtpdGVtcys9MTtcIjpcIn0pLnNldF9rZXkoe29yZGVyPWNhdChvcmRlcixcIktcIik7XCJrXCJ9LDEpLmNvYWxlc2NlKFwibWFza2VkXCIpKX0iLCJsaW5lIjoxfSwiYm9keSI6W3sia2luZCI6eyJraW5kIjoiY29kZV9ibG9jayIsImxpZmVjeWNsZSI6IkkiLCJjb2RlIjoib3JkZXI9XCJcIjtyZXR1cm4oW1wiaGVhZDp0YWlsXCJdLnNwbGl0X2VhY2goe2l0ZW1zPVwiYmFkXCI7aXRlbXMrPTE7XCI6XCJ9KS5zZXRfa2V5KHtvcmRlcj1jYXQob3JkZXIsXCJLXCIpO1wia1wifSwxKS5jb2FsZXNjZShcIm1hc2tlZFwiKSkifSwic291cmNlIjoiSSB7b3JkZXI9XCJcIjtyZXR1cm4oW1wiaGVhZDp0YWlsXCJdLnNwbGl0X2VhY2goe2l0ZW1zPVwiYmFkXCI7aXRlbXMrPTE7XCI6XCJ9KS5zZXRfa2V5KHtvcmRlcj1jYXQob3JkZXIsXCJLXCIpO1wia1wifSwxKS5jb2FsZXNjZShcIm1hc2tlZFwiKSl9IiwibGluZSI6MX1dfV19';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
