# Plugin Registry and Legacy Transition

> **Perl reference backend, deprecated.** This entire surface is specific to the Perl reference backend and is on a documented retirement path. The plugin registry, the shipped `.plg` files, and the `PPlugin` runtime are legacy machinery that predates the backend-neutral `.spec` contract; they are **not** part of that contract, and a new backend does not need to implement any of it. This chapter is kept for users of existing Perl `.plg`-based code.

LinkedSpec exposes plugin registration and lookup methods on the public facade. These methods support the plugin system used by shipped `.plg` plugin files and the legacy `PPlugin` runtime.

## Registry maintenance

### `register_plugin($name, $plugin_ref)`

Registers a single plugin by name. `$plugin_ref` is a coderef handler.

```perl
LinkedSpec::register_plugin('my_plugin', $plugin_instance);
```

### `register_plugins(%plugins)`

Registers multiple plugins at once. Keys are plugin names, values are coderef handlers.

```perl
LinkedSpec::register_plugins(
  plugin_a => $p_a,
  plugin_b => $p_b,
);
```

### `clear_registered_plugins()`

Removes all registered plugins. Called when a fresh plugin state is needed.

```perl
LinkedSpec::clear_registered_plugins();
```

## Legacy transition surface

These methods exist on the public facade for compatibility with existing plugin-using code. They delegate to `LinkedSpec::PluginBridge`, which routes through `PPlugin`.

### `run_plugin($name, @args)`

Runs a registered plugin by name with the given arguments. Returns the plugin's result.

### `get_plugin($name)`

Returns the registered coderef handler for the given name, or `undef` if not found.

### `dispatch_plugin_autoload_name($name)`

Resolves and dispatches an autoloaded plugin name. Used by the plugin autoloader mechanism.

### `AUTOLOAD`

Perl `AUTOLOAD` handler that catches unresolved method calls on `LinkedSpec` and attempts to route them through registered plugins. This is legacy compatibility behavior.

**Status note:** All seven legacy transition-surface methods (`run_plugin`, `get_plugin`, `dispatch_plugin_autoload_name`, `AUTOLOAD`, `register_plugin`, `register_plugins`, `clear_registered_plugins`) are **DEPRECATED** as of the PLUGIN-MODERNIZATION tree (completed 2026-05-17). The root `plugin/` corpus is gone, and the 13 surviving legacy `.plg` files now live under `noncore/plugin/`; they are parked outside the active backend-neutral product tree. These facade methods remain only as Perl-reference compatibility shims, and new code must use canonical package owners directly. The retirement path is to migrate or delete the remaining noncore `.plg` actions, retire `PPlugin`, reduce/delete `PluginBridge`, and remove the deprecated facade methods.

## Relationship to the compile/runtime surface

The plugin system is separate from the main compile/runtime pipeline (`Get`, `get_parser`). Plugins provide domain-specific functionality (timing analysis, table filtering, etc.) rather than parser compilation. The two surfaces share the same `LinkedSpec` facade but dispatch to different owner trees:

- Compile/runtime → `Compiler`, `SpecEntry`, `Runtime`, `RuntimeContext`
- Plugin registry → `PluginRegistry`, `PluginBridge`, `PPlugin`
