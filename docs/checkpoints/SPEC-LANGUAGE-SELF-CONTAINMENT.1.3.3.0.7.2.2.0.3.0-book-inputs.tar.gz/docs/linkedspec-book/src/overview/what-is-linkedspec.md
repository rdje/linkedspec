# What LinkedSpec Is

LinkedSpec is a progressive extraction parser DSL. The `.spec` language is its universal contract; a LinkedSpec *backend* compiles those `.spec` files into ready-to-call parsers. The Perl implementation is the reference backend (the canonical behavioral oracle), and additional backends (such as Rust) run the same `.spec` files with identical semantics.

A `.spec` file is a compact, rule-paragraph language. A backend compiles it into a runnable parser (a coderef in the Perl reference backend). Those parsers match structured input, extract meaningful regions, and return AST payloads defined by the spec author.

## What LinkedSpec is good at

LinkedSpec compiles `.spec` files into parsers that excel at:

- recursive and nested structures (Lisp-like forms, config languages, hardware descriptions)
- coarse-to-fine extraction flows (find interesting regions first, then parse inside them)
- regex-anchored parsing (anchor on strong tokens/signatures, recurse downward)
- fast parser prototyping (write rules, add actions, invoke — no code generation step)

It is intentionally not trying to be a strict, textbook EBNF parser-generator clone. The design center is practical extraction and recognition, not exhaustive ambiguity resolution.

LinkedSpec's larger model is **staged linked parsing**. A first `.spec` can parse the
outer structure that has clear anchors, return AST nodes that carry source-provenance
text islands, and route those islands to later `.spec` parsers that understand their
inner grammar. One stage may spawn several different next-stage parsers because different
payload fields can have different sublanguages. This makes LinkedSpec a parse graph
rather than only a single up-front grammar.

That staged model is implementation-language neutral. Perl5, Raku, Rust, Julia, Lua,
Dart, Zig, Go, or another backend can implement it, but none of those languages defines
the contract. The contract is `.spec` source, typed AST payloads, parse jobs, descriptors,
diagnostics, and deterministic parser entry points.

The reserved design for marking such payloads is `parse_job(text_expr, options)`: a
future portable helper that records parser identity, source span, parent AST path, result
insertion policy, and failure policy as metadata. Current shipped parsers do not yet
accept or execute that helper.

The reserved dispatch design resolves those jobs through a deterministic parser registry,
caches compiled next-stage parsers by content/capability fingerprints, and runs jobs in a
stable queue. Current shipped parsers implement only the first narrow
`body_parse_job` path for top-level user-function bodies: `actionir-body.spec` resolves
through a built-in provider, runs top rule `action_block`, and stitches the returned
body AST into `body_ast`. General public parse-job authoring, provider search, and
recursive staged queues remain future work.

LinkedSpec also has a reserved design for spec-file composition. Future file-scope
directives such as `import "common/atoms.spec" as atoms` and
`include "common/lifecycle.spec"` compose grammar material. They are not the same as
staged parse jobs: imports and includes shape the grammar graph, while parse jobs refine
runtime text payloads that an earlier parser extracted. Current shipped parsers do not
yet accept those directives.

## How it works at a glance

A `.spec` file is organized as rule paragraphs. Each rule has:

- a label and mode (e.g., `Top::` for the entry point, `Child:AND+` for repeated matching)
- optional regex anchors (`/pattern/`)
- action edges (`-> ChildRule { ... }`) or blind-call edges (`=> helper { ... }`)
- lifecycle blocks (`I`, `E`, `EX`, `IT`, `LS`, `LE`, `LX`) for setup, teardown, and state management

A backend's compiler parses the `.spec`, builds compiled rule state, derives dependency-regex dispatch data, optionally builds a compiled descriptor for introspection, and returns a runnable parser. Callers invoke that parser with input text and get back AST data structures. (In the Perl reference backend the entry point is `LinkedSpec::Get(\$spec)`; other backends expose an equivalent entry point.)

## Example: a minimal key/value parser

```text
top::
 -> pair .push

LX { return(copy(top)) }

pair:
 /(\w+)=(\w+)/ I {
   return(hash("key", entry_group(0), "val", entry_group(1)));
 }
```

This is a two-rule spec — the **recommended idiom** for stream-of-records parsing (a
`::` dispatch loop plus a normal rule that carries the regex):

- The **entry rule** `top::` carries **no regex of its own**. It is the dispatch loop: it repeatedly hands off to `pair` and `.push`es each result onto its accumulator, then `LX` returns a snapshot of that accumulator when the input is exhausted.
- The **`pair` rule** carries the regex. On each match it returns a hash built from the two capture groups — `entry_group(0)` is the first group, `entry_group(1)` the second (group numbering is 0-based and captures-only; see [Regex in `.spec`](../user-model/regex-in-spec.md)).

For input `foo=bar baz=qux` the parser returns `[{"key":"foo","val":"bar"},{"key":"baz","val":"qux"}]` — one hash per matched pair, collected by the entry rule. (In this idiom the regex lives on the normal `:` rule, not the `::` entry rule. That is a style choice, not a rule: `::` is an authored *default-entry marker*, and a marked rule is otherwise an ordinary rule that may carry a regex, take a mode, or recurse. An explicit selector may enter any declared rule instead — see [.spec Files and Rule Paragraphs](../user-model/spec-files-and-rule-paragraphs.md).)

## Where LinkedSpec fits

LinkedSpec is especially useful when:

- you want to parse a language or format without building a full compiler frontend
- your inputs have recognizable anchors that let you skip uninteresting regions
- you need structured AST output from parser rules, not just a match/no-match result
- you want to prototype parser behavior quickly and iterate on rules
- the real-world structure of your inputs matters more than formal grammar compliance

## What comes out of it

The normal outcome of compiling a `.spec` is a runnable parser. Call it with input text to get AST output. (In the Perl reference backend that parser is a coderef returned by `LinkedSpec::Get(...)` or `LinkedSpec::get_parser(...)`; other backends return the equivalent runnable parser for their language.)

The compiler can also expose a compiled descriptor — a structured data payload containing rule tables, dependency-regex maps, and metadata — for tooling, diagnostics, and introspection.

Parser compilation, the public API, and descriptor introspection are covered in detail later in the book.
