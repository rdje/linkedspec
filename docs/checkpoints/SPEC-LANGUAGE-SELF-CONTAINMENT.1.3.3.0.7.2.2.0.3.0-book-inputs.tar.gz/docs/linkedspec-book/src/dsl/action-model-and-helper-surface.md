# Action Model and Helper Surface

LinkedSpec is in the middle of a long-term shift from older raw-Perl-shaped action habits toward a cleaner helper-driven DSL and canonical ActionIR lowering.

## The direction

The direction is:

- less raw embedded Perl
- more explicit helper contracts
- clearer lowering semantics
- better backend portability

The short version:

```text
old direction:  write parser actions as convenient embedded Perl
new direction:  write parser actions as explicit LinkedSpec helper DSL
```

The helper DSL still emits Perl today, but the intent is bigger than Perl. The helper surface describes parser intent in a way that can be lowered through ActionIR and eventually carried to other backends.

## Why this matters

The action surface is where a lot of parser power lives, but it is also where accidental complexity can creep in fast.

Treating the helper DSL as a real language surface, with explicit semantics and documentation, makes LinkedSpec easier to trust and easier to evolve.

## A tiny before/after

Older specs often needed raw Perl-shaped code to name a child result, push data, or return a structured node.

A helper-oriented rule should make the intent visible:

```text
Top::
 -> Value .push
 LX { return(copy(Top)) }

Value: /name=(\w+)/
 I {
   name = entry_group(0);
   return(hash("kind", "assignment", "name", name));
 }
```

That reads as:

- assign a fresh working scalar from the entry match capture group
- return a structured hash payload

The important part is not the exact emitted Perl. The important part is that the parser action expresses a portable semantic operation.

## Main helper families

The current helper surface is broad, but it is easier to learn in families. Each family serves a distinct purpose in the parser action lifecycle.

### Value and container helpers

Construct and transform values during parsing:

- `name` — read the named typed working value (scalar, array, harray, or codeblock)
- `array(IDENTIFIER)` / `hash(IDENTIFIER)` — removed aggregate-selector forms. All five backends reject them before
  execution. Use the bare typed binding.
- `flat_array(...)` — flatten arguments into an array
- `flat_hash(...)` — flatten key/value arguments into a hash
- `copy(...)` — shallow-copy a container
- `join_values(...)` — join array elements into a string
- `split_tagged_records(...)` — split a string into tagged records

Detailed reference: [Value, Container, and Flow Helper Reference](value-container-flow-helper-reference.md).

### Working variables

Working variables auto-exist when they are first used through a typed position:

- `name = value` — bind the typed RHS value to `name`
- `items = []` — bind an array value to `items`
- `meta = { "kind" : value }` — bind a hash value to `meta`
- `items += value` or `push(items, value)` — append to an array binding
- `meta[key] = value` — mutate a hash

Working-variable setup policy is documented in [Working Variables and Setup](declaration-helper-reference.md).
New examples should use the terse forms above.

### Assignment and mutation helpers

Write values into declared variables or containers:

- `set(target, value)` — write a value and yield the post-assignment typed target value; `target = value` is the preferred operator form
- `name = value` — terse assignment operator; scalar, array, and hash RHS values all bind as the current typed value of `name`
- `=(name, value)` — operator-call spelling for the same assignment value expression
- `items += value` — terse array append operator; in value positions it yields the updated array value
- `push(container, value)` — append to an array
- `push(name, value)` — append to the bare array binding; if `name` is a statically registered rule, child-rule
  dispatch keeps precedence
- `if(is_nonempty(value)) { push(name, value) }` — named-binding push with an explicit non-empty filter
- `split(name, source, delimiter)` — replace the bare array binding and yield the updated value; the two-argument
  `split(source, delimiter)` remains pure
- `set_key(name, key, value)` — set one key in a named working hash
- `name[key] = value` — terse typed-path assignment operator; in value positions it yields the updated root snapshot. On all five backends, an evaluated string selector has the same field-update effect as `set_key`, while a nonnegative integer selects an array
- `payload["items"][0]["name"] = value` — nested value-path assignment into a scalar-held array/harray payload; all five backends create an absent root and unambiguous missing intermediates from evaluated string/integer selectors, reject wrong-kind coercion and sparse array gaps, and publish no partial structural path

### Capture and mark helpers

Control parser cursor boundaries and capture text spans:

- `capture_slice()` — capture from the anonymous boundary to the current match start
- `capture_until_boundary(rule[, ...])` — capture from the live cursor to the next named structural boundary without consuming that boundary
- `capture_take()` — capture and advance the boundary
- `mark_here(name)` — place a named durable mark at the current position
- `capture_from(name)` — capture from a named mark to the current match start
- `capture_between(start_mark, end_mark)` — capture between two named marks
- `capture_rest_from(name)` — capture from a named mark to end of input

Detailed reference: [Capture, Marks, and Source Locations](capture-marks-and-source-locations.md) and [Source Boundary Helper Reference](source-boundary-helper-reference.md).

### Source-location helpers

Read the parser's current position in the input:

- `cursor_line()` — current line number
- `cursor_col()` — current column
- `cursor_pos()` — current cursor position (an offset into the input)
- `entry_start_pos()` — start position of the entry match
- `match_end_col()` — end column of the current match

### Input and match readers

Access the input text and match data:

- `input_text()` — the full input string
- `entry_text()` — the text of the match that entered this rule
- `entry_group(index)` — a specific capture group from the entry match
- `match_text()` — the text of the current local match

### Control-flow helpers

Structured branching within action bodies:

- `if(condition) { ... }` / `elseif(condition) { ... }` / `else { ... }` / `endif`
- `when(condition) { ... }` / `otherwise { ... }` as attached-block aliases for `if` / `else`
- `switch(value) { case("x") { ... } default { ... } }`
- `coalesce(...)` — return the first defined, non-empty value
- `is_defined(...)` / `has_key(...)` — existence checks

### Flow and method-chain helpers

Chain operations fluently on values:

- `.trim()`, `.lowercase()`, `.uppercase()` — string transforms
- `.coalesce()` — fluent fallback chaining
- `.length()` — string or array length
- Method chains use `.method(args)` syntax on action-edge targets and values.

Detailed reference: [Value, Container, and Flow Helper Reference](value-container-flow-helper-reference.md).

### Logical value helpers

Compose real boolean values without borrowing a host language's truth or short-circuit operators:

- `and(value, ...)` — at least one operand; true only when every operand is truthful;
- `or(value, ...)` — at least one operand; true when any operand is truthful;
- `not(value)` — exactly one operand; negates its typed truth.

After arity succeeds, every logical operand evaluates once from left to right. A decisive false `and` operand or
true `or` operand does not skip later effects. Empty `and`/`or`, empty `not`, and multi-argument `not` raise
`helper_arity_mismatch` before any operand runs. Null, false, numeric zero, empty strings, and empty aggregates are
false; all nonempty strings (including `"0"` and `"false"`), nonzero finite numbers, nonempty aggregates, and
typed codeblocks are true. Testing a codeblock does not invoke it.

```text
seen = []
eager = or(true, { push(seen, "still-runs"); return(false) })
selected = if(eager, { return(not(false)) }, { push(seen, "skipped"); return(false) })
```

`seen` is `["still-runs"]` and `selected` is true. `if`, `switch`, and `while` use the same truthiness but remain
lazy controls. ADR `0043` and `linkedspec-logical-helper-v1` govern this behavior on all five backends and every
current native/generated execution role. See [Value, Container, and Flow Helper
Reference](value-container-flow-helper-reference.md#boolean-composition) for the complete
truth table, generated entrypoints, and recurring proof command.

### Diagnostic output helpers

Emit caller-owned `RuntimeDiagnosticOutputEvent` values during parsing:

- `say(value, ...)` — one event containing concatenated scalar text plus one newline;
- `print(value, ...)` — one event containing concatenated scalar text;
- `print_each(array, prefix, suffix?)` — one event per item in source order.

These helpers do not write host stdout/stderr directly. The embedding API installs an optional caller-owned sink
for one invocation; without it, valid calls still evaluate but delivery is quiet. `print`/`say` require one or
more arguments, `print_each` requires two or three, and arity rejects before effects. Rich events remain outside
parse results, native/generated trace, and the primary CLI. See [Value, Container, and Flow Helper
Reference](value-container-flow-helper-reference.md#debug-output-helpers) for the exact ADR `0042` contract and
five host-language examples.

### Rule-dispatch helpers

Invoke child rules and handle results:

- `call(RuleName)` — call a child rule and capture its return value
- Combined with `retv = call(Child)` to store child results

## How helpers reach emitted code

Every helper call passes through the ActionIR lowering pipeline (see [ActionIR Lowering Mental Model](actionir-lowering-mental-model.md)):

1. `Scanner` discovers which contracts are present
2. `StatementSplit` splits compound action text into individual statements
3. `CanonicalEvents` normalizes each helper call into a canonical ActionIR event
4. The appropriate lowering owner (`MethodExpr`, `FlowExpr`, `ValueExpr`, `ControlFlow`, `MethodLowering`, `DeclareMethod`, `ArrayPipeline`, `Diagnostics`) lowers the event to emitted code
5. The final emitted Perl is generated — but the lowering pipeline is designed so that other backends can substitute their own final stage

This is why writing `name = entry_group(0)` is fundamentally different from writing raw Perl: the helper form is inspectable, validatable, and retargetable. Raw Perl is opaque to the lowering pipeline.

The linked chapters below introduce these families in public-facing terms. The repo-root ActionIR guides remain the exhaustive working references while the book continues growing.

## What to pair with this chapter

The repo’s ActionIR-focused guides remain the deeper working references while this book grows:

- `USER_GUIDE_ActionIR_Contracts.md`
- `USER_GUIDE_ActionIR_MethodLowering.md`
- `USER_GUIDE_ActionIR_EmittedPerlReference.md`

The long-term goal is for this book to absorb that surface in progressively clearer public-facing chapters.
