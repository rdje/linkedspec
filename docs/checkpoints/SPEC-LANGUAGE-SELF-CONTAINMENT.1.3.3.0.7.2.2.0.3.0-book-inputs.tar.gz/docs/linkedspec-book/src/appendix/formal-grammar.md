# Formal `.spec` Grammar

This appendix defines the `.spec` file syntax with enough precision for an independent
implementation in any language (Rust, Dart, Julia, Lua, etc.). It does **not** describe how
the Perl backend parses — it describes **what** constitutes valid `.spec` syntax and
**what** each construct means.

Every shipped LinkedSpec backend must accept exactly the language defined here.
Backends must parse that language into typed AST/IR before lowering or execution;
textual helper rewrites directly into host-language source are legacy implementation
debt, not part of the contract.

An optional EBNF-like authoring profile is an accepted future direction under ADR 0064, not current syntax. It
will be a lossless frontend to this same canonical semantic model, not a separate grammar runtime or a claim that
LinkedSpec cursor/capture/state/action semantics are standard EBNF. Its contract must publish those differences and
explicit extensions, preserve original-source spans and diagnostics, and prove canonical/runtime equivalence on
all backends before the profile can be described here as implemented.

## 1. File and Paragraph Model

A `.spec` file is a sequence of top-level **function definitions** and **rule paragraphs**,
not a line-oriented grammar. A rule paragraph starts with a **rule header** and continues
until the next rule header or end of file after top-level function definitions have been
removed for the current bootstrap bridge. Everything between two rule headers belongs to
the first rule's paragraph.

Rule headers are recognized **only at top level**: a line matching a rule-label
pattern inside an open `{ }` block is block content, not a new rule.
Function definitions are also recognized only at top level.

```text
Top::
 -> Next .push
 LX { return(array("?Top:", copy(Top))) }

Next: /a/
 I { return(array("?Next:", entry_text())) }
```

Here `return(...)` is block content inside `Top`, and `Next:` starts a new paragraph.

### 1.1 Leading Whitespace, Comments, and Blank Lines

Before the first rule paragraph, a `.spec` file may contain:
- Blank lines (zero or more)
- Comment lines starting with `#` (zero or more)

After the first rule paragraph, blank lines and comment lines between paragraphs
are **not** part of any rule.

### 1.2 Top-Level Function Definitions

Top-level user-function definitions use this syntax:

```text
fn name(param1, param2) {
 action statements or value expressions
}

fn no_args() {
 return("ok")
}
```

The first implementation accepts explicit parentheses for every arity, including zero
arity. Parameter names are comma-separated identifiers. A definition's body is parsed as
an ActionIR action block, so it uses the same helper/value/block DSL described in §7.

Function definitions are file-level declarations. They are not rule paragraphs, not rule
labels, and not valid inside action/lifecycle blocks. They may appear at top level before
or between ordinary rule paragraphs. Active backends extract them by executing
`specs/user_function_definition.spec`, then strip those source spans before ordinary rule
parsing while preserving line numbers for diagnostics.

As of `SPEC-FORMAT-TERSE.4.2.3`, the Perl reference validates and records functions in the
descriptor registry and executes registered exact-arity calls in value positions and
standalone discard statements. A call such as `return(normalize(" x "))` evaluates the
argument first, binds it to the function's parameter in a fresh function-local scope, and
returns the body result. A standalone `normalize(" x ")` computes that value and discards it
through the canonical `VALUE_DROP` path. Calls can feed helper arguments and compatible
receiver-dot chains. Recursive and unsupported function-body forms are fenced as
diagnostics with zero raw fallback on the Perl reference, and Rust directly diagnoses
recursive user-function calls. Rust now validates, compiles, and executes the same MVP
function surface after consuming the same spec-returned definition AST, including value
calls, compatible receiver chains, standalone discard, and fresh function-local scope.

The registry rejects:

- duplicate function names
- invalid or duplicate parameters
- reserved runtime/lifecycle/function symbols
- names that collide with built-in helper/control names, including numeric word aliases such as `add`
- names that collide with rule labels

The finalized MVP function surface is deliberately narrow. The only accepted definition
spelling is top-level `fn name(args) { ... }`, with explicit parentheses for every
arity and a braced body. Zero-argument functions therefore use `fn name() { ... }`;
`fn name { ... }` is not part of the language. Function bodies are value-oriented:
they may use the supported helper/value/block DSL and function-local working variables,
then return the final expression or an explicit `return(expr)` payload.

The following are deferred extension topics, not accepted syntax or semantics:

- alternate definition spellings such as `function name(args) ... endfunction` or
  `fn name(args) ... endfn`
- optional zero-argument parentheses
- brace-less or single-expression body forms
- functions whose observable purpose is caller-state, parser-state, or persistent
  side-effect mutation rather than a returned value
- direct or mutual recursive user functions
- closures, lambdas, currying, partial application, or implicit caller-scope capture
- future namespace/module features for functions

The one exception now adopted as a versioned next surface is a final rest parameter:

```text
fn collect(prefix, ...items) {
 return(items)
}

fn all_values(...items) {
 return(items)
}
```

The exact token is `...IDENTIFIER` with no whitespace between marker and name. It may appear once and only at the
end of the parameter list. Calls remain positional; fixed prefix parameters bind first and all extras bind as one
fresh typed array, empty when there are no extras. Fixed functions remain exact-arity. This syntax and its
version-2 signature record are adopted by ADR 0030 and the neutral callable-signature contract. Perl, Rust, Dart,
Julia, and Lua implement the syntax and native execution now; Lua's exact outward descriptor joined the shared
union in `LUA-BACKEND-PARITY.5.3.1`. Generated preservation/execution remains `.8.1-.4`, so portable six-runtime
generated specs must wait for those admissions.

On Perl, Rust, Dart, and Julia, these calls illustrate the binding boundary:

```text
all_values()                  # items = []
all_values(1, [2], false)     # items = [1, [2], false]
collect("head")               # prefix = "head", items = []
collect("head", "a", "b")   # prefix = "head", items = ["a", "b"]
```

### Callable-codeblock literal and dynamic call (five-backend construction and invocation)

ADR 0031 adopts callable literals; ADR 0032 adds a final contextual-codeblock parameter declaration:

```text
codeblock_literal := "{|" callable_parameters? "|" action_statements "}"
codeblock_parameter := IDENTIFIER ":" "codeblock"  # final parameter only

cb = {|left, right| return(cat(left, right)) }
empty = {|| return("ok") }
result = cb("a", "b")
fn apply(value, callback: codeblock) { return(callback()) }
```

The `{|` opener is exact. A final `...rest` is allowed. `{}` and `{ key : value }` remain harrays; nonempty
`{ statements }` remains an immediately evaluated block expression. Literal construction captures no environment.
`cb(args)` executes later in dynamic caller context with temporary copied parameter/rest bindings and block-local
return. `callback: codeblock` declares only the value kind; explicit literals own their `{|params| ...}` signature,
and a contextual `{ ... }` argument takes zero positional args while reading dynamic context. Lexical closure
capture is excluded from version 1. Neutral contract `.11.2` locks this grammar, AST schema,
diagnostics, and fixture. Perl `.11.3.1` preserves the eight-field typed record through generated source and
`.11.3.2` executes bound variable calls with the specified dynamic context, restoration, result, and failure
semantics. ADR 0032 declaration `.11.3.3.1` is adopted and Perl generic normalization `.11.3.3.2` is implemented
for metadata-declared helper, user-function, and receiver forms. Rust `.11.4.1` now preserves the same literal,
signature, body, source, Unicode-coordinate spans, compiled/serialized state, generated source, and semantic
codeblock shape without executing it. Rust `.11.4.2` executes bound-variable calls with the same once-only
arguments, dynamic caller stores, copied/restored fixed/rest bindings, local result, static precedence, structured
failures, and direct/mutual recursion rejection across native/reconstructed/generated/emitted roles. Rust
`.11.4.3` also normalizes attached and parenthesized helper, typed-user-function, and receiver final blocks through
one metadata registry to the same zero-positional `codeblock_argument`, while preserving eager blocks and attached
controls. Dart `.11.5.1` preserves the same inert eight-field literal, fixed/rest signature, typed body, containing
Unicode-character spans, compiled/generated/emitted state, user-function transport, and semantic codeblock shape
without executing or capturing the body. Dart `.11.5.2` executes bound calls with the same once-only arguments,
dynamic caller stores, copied/restored fixed/rest bindings, local result access/chaining, static precedence,
structured failures, and ordered direct/mutual recursion rejection across native/reconstructed/generated/emitted
roles. Dart `.11.5.3` now preserves exact final-only declaration/staged/registry/descriptor metadata and
normalizes attached/parenthesized helper, typed-user-function, receiver `with`, and tree-traversal blocks through
one metadata owner to the same zero-positional `codeblock_argument`. Ordinary eager blocks, controls, explicit
literal signatures, and harrays remain distinct. Julia `.11.6.1` now preserves the same inert eight-field literal,
fixed/final-rest signature, typed body, containing Unicode-character spans, user-function transport,
compiled/generated/emitted state, and semantic codeblock shape. Julia `.11.6.2` now executes bound calls with the
same ordered arguments, dynamic caller stores, copied/restored fixed/rest bindings, local return/result access,
static precedence, typed failures, and ordered recursion rejection across native/reconstructed/generated/emitted
roles. Julia `.11.6.3` preserves exact final-only typed metadata and applies one post-registry contract pass to
equivalent attached/parenthesized helper, typed-user-function, receiver, and tree blocks. The normalized
zero-positional record executes through the same evaluator in native/reconstructed/generated/emitted roles while
eager blocks, controls, explicit signatures, and harrays remain distinct. Lua `.11.8.1` preserves the same exact literal, nullable fixed/final-rest
signature, typed deferred body, source text, containing Unicode-character spans, inert runtime/function copies,
compiled/generated/emitted effective state, and semantic codeblock shape on PUC Lua and LuaJIT. Lua `.11.8.2`
adds the same ordered dynamic caller-frame invocation, copied/restored fixed/rest bindings, live nonparameters,
typed result access, static precedence, exact failures, and ordered recursion rejection through the shared
interpreter. Lua `.11.8.3` proves canonical reconstruction, generated-plan, and independently loaded emitted-route
identity through that same record/executor. Five-backend callable recurring/public admission is complete under
`.11.8.4`; both Lua ABIs execute the same consumer and lexical capture remains outside version 1.

Arguments evaluate once from left to right before any parameter is bound. Nested arrays/harrays, booleans,
`undef`, and codeblocks remain individual rest-array values rather than being flattened or coerced.

## 2. Rule Header

A rule header is a single token at the start of a line (after optional leading
whitespace on that line):

```
rule_label  :  [mode]  [rest-of-line]
rule_label  :: [mode]  [rest-of-line]
```

### 2.1 Rule Labels

A rule label is a nonempty sequence of Unicode 17.0.0 `XID_Continue` characters. The same class applies at every
position, including the first. This deliberately preserves the complete historical ASCII surface
`[A-Za-z0-9_]+`, including labels beginning with a digit or underscore, while admitting labels such as `Töp`,
`Δelta`, `變體`, and `a·b`.

Label identity is the exact decoded Unicode scalar sequence: it is case-sensitive and normalization-sensitive.
No normalization or case folding is performed. For example, precomposed `Töp`, decomposed `To\u{0308}p`, and
lowercase `töp` are three different labels. Source bytes must first pass the strict UTF-8 boundary; malformed
UTF-8 is rejected rather than replaced. This contract is generated from the repository-pinned Unicode Character
Database rather than a host language's `\w` behavior. See ADR `0051` and
`capability_conformance/unicode_rule_label_contract.json`.

The first-authoritative self-hosted grammar, `specs/spec.spec`, consumes the generated literal class at all 12
rule-label sites: headers and every action, blind-call, and bare-edge block/fluent/plain target position. Function
names, helper names, lifecycle markers, fluent method names, and mark names retain their separate identifier
grammars; the rule-label expansion does not broaden them.

The Dart native frontend consumes the corresponding generated scalar classifier and prefix scanner. Its exact-
identity proof covers every positive neutral fixture and both distinct pairs through compiled maps/order, JSON,
descriptors, generated plans and emitted source, reconstruction, selectors, diagnostics, traces, strict loading,
and primary commands. These layers preserve the decoded label as an immutable string; they do not normalize or
case-fold it. All eight negative neutral labels fail the complete-label predicate for programmatic and reconstructed
declarations plus action/blind/bare targets. Function names/parameters, helper callees, lifecycle markers, fluent
methods, and named-mark variables keep their existing narrower grammars; Unicode rule-label membership does not
authorize a spelling on those surfaces. Complete Dart/package/primary/corpus and canonical composition close this
native label prerequisite without admitting the separate semantic-introspection adapter.

The shared PUC Lua/LuaJIT native frontend now consumes its own generated Lua-5.1-compatible form of the same 806
ranges. One strict byte decoder and prefix scanner owns declaration headers, header-looking body termination, and
action, blind, and bare targets; one validator then checks declarations and all three target kinds before raw,
structural, or target-resolution checks. Invalid complete labels report portable `invalid_rule_label` at
`validate_rule_labels`, invalid edge suffixes remain raw rather than truncating, and `Top:::` is rejected as a
header. The generated ranges remain private, root `linkedspec` exports no classifier API, and the generic ASCII
word scanner continues to own unrelated identifiers. Classifier and native-route suites run unchanged on both Lua
ABIs; later proof owns exact identity through every compiled/runtime artifact and exhaustive adjacent isolation.

Exact artifact and runtime identity is now proved as well. Ten unique byte strings derived from all nine positive
fixtures and both distinct pairs remain exact through parsed and reconstructed ASTs, compiled order/maps/JSON,
descriptors, generated plans, strict loading, native and generated execution, in-process and fresh emitted modules,
selectors, portable diagnostics, native/generated trace, and inline/file primary commands. The precomposed and
decomposed labels remain separate keys and rules; loader paths and host table identities do not enter portable
artifacts. One 359-assertion suite runs unchanged on PUC Lua and LuaJIT. Exhaustive negative trust routes and
unrelated-identifier isolation remain separately owned. Their behavior-free audit found one older body-fluent
whole-token defect outside the Unicode classifier: `.Töp()` validated as ASCII method `T`, and `.A·B()` as method
`A`, because the body adapter discarded the suffix already returned by its fluent parser. PUC Lua and LuaJIT
agreed byte-for-byte. The adapter now propagates that remainder. An unrecognized suffix becomes a raw body element,
so validation rejects the complete malformed line without making fluent method names Unicode-aware.

For example, this source is invalid on both Lua ABIs:

```spec
Root::
 .Töp()
```

The parser retains the established ASCII fluent prefix `.T` and also retains the exact raw tail `öp()`; validation
then reports `rule 'Root': unrecognized body syntax at line 2: öp()`. The same rule applies to `.A·B()` and to
hyphen, space, emoji, colon, or slash suffixes after `.Top`. Valid ASCII `_method9`, multiple dotted calls,
empty/dollar/no-prefix and newline controls, comments, and recognized same-line lifecycle, regex, and action-edge
continuations keep their prior grammar. One 166-assertion suite proves those rejection and preservation boundaries
unchanged on PUC Lua and LuaJIT.

The exhaustive proof is now complete. It reads all eight invalid labels from the neutral contract and applies them
to declaration, action, blind, and bare roles through both programmatic and JSON-reconstructed ASTs. Every case
fails with the exact portable `invalid_rule_label` diagnostic before compile, descriptor, or generated-plan
construction. Source parsing, loaded/reconstructed/generated execution, in-process and fresh emitted modules,
selectors, diagnostics, traces, strict loaders, and inline/file primary commands preserve the same rejection.
Portable evidence contains no resolved path, Lua table address, or userdata spelling.

For example, neither a valid prefix nor a transport boundary rescues this invalid edge:

```spec
Root::
 /x/ -> Top-Rule
```

It remains malformed as a complete target rather than becoming target `Top` plus a suffix. By contrast, a newline
is a real token boundary: `Top` and a following `Rule` are handled as separate source tokens. Function names,
parameters/rest parameters, ActionIR variables/calls/helpers, fluent methods, lifecycle words, split/mark
variables, conditionals, bounded mode, loader names, and regex syntax keep their own narrower grammars. The same
1,542 assertions pass unchanged on PUC Lua and LuaJIT, closing negative/isolation `.10.7.1.3`. No-change
recomposition `.10.7.1.4` reruns every committed owner, complete Lua, the cross-backend primary matrix, all Unicode
legs, and canonical CI without adding a replacement implementation or test. The Lua Unicode prerequisite is now
composition-closed; semantic source/outcome planning follows separately.

The self-hosted structural tokens also own exact physical-line boundaries. A rule header begins only at the start
of a physical line after optional horizontal whitespace; the scanner cannot recover a valid suffix from an invalid
prefix such as `Top-Rule::`, `Top Rule::`, or `$Top::`, and an extra colon such as `Top:::` is not part of a valid
header token. Bare `-> Label` and `=> Label` references must occupy the complete physical line after optional
leading/trailing horizontal whitespace. Thus `-> Top-Rule`, `=> Top😀`, and `-> Top:` are rejected as whole bare
references instead of silently producing target `Top`. A newline is a real token boundary: `-> Top\nRule` is the
valid action target `Top` followed by a separate bare target `Rule`, not one label containing a newline.

```spec
Töp::
 /x/
 -> Δοκιμή
 => 規則
 𐐀Rule[1]
```

Here `Töp`, `Δοκιμή`, `規則`, and the supplementary-plane label `𐐀Rule` use the same pinned membership rule.
An index such as `[1]` and the edge punctuation are outside the label itself.

The pinned generator also emits `unicode_case/unicode_rule_label_regex_class.txt`, a UTF-8 literal-range class
whose endpoints encode all 806 merged ranges. The checker reconstructs and byte-compares it independently, so the
self-hosted grammar can consume exact repository data without a host property lookup. The artifact is generated
authority; all four checked-in `spec_spec_*` corpus inputs must remain byte-identical to canonical
`specs/spec.spec`, and freshness is enforced by the same checker.

Perl, Rust, Dart, Julia, and Lua now execute one byte-exact positive/negative/distinct/boundary projection through
the current canonical self-hosted grammar in both default and POSIX command environments. This proves the shared
executable grammar, not every backend's separate native parser. Rust implements the pinned label contract across
its native headers/references/validation/selectors/artifacts/loaders/traces. Dart and Julia complete the same native
contract through every identity and isolation route. Lua now routes native headers plus action, blind, and bare
targets through the generated 806-range scanner and applies the same complete-label predicate to parsed,
reconstructed, and programmatic ASTs. Its scanner preserves one-based UTF-8 byte boundaries under PUC Lua and
LuaJIT, including supplementary scalars, and invalid suffixes cannot silently truncate to a valid prefix. Exact
Lua exact artifact/runtime identity is complete; exhaustive negative/trust-route and adjacent-grammar isolation
remains separately owned before semantic v1 admission.

- **Single colon** (`rule_name:`): an ordinary rule — it may appear anywhere in the file and may be selected as
  the entry rule.
- **Double colon** (`rule_name::`): an ordinary rule carrying an authored **default-entry marker**. A `.spec` may
  define multiple marked rules.

ADR `0046` and `linkedspec-root-rule-selection-v1` ratify the exact target order:

1. an explicit selector such as `--top-rule NAME` wins and may name any declared rule;
2. otherwise the first authored `::` in definition order wins;
3. otherwise the first authored rule wins.

At rollout 7 complete / 0 pending, the neutral contract, composed Perl, Rust, Dart, Julia, dual-ABI Lua, and final
recurring/public no-drift are admitted. `bash tools/check_root_rule_selection_five_backend.sh` reruns the exact
cross-backend composition. All five accept markerless one-or-more-rule sources and apply the exact precedence
above across native, loaded/reconstructed, generated direct/traced, and primary execution, reject an unknown
explicit selector at `select_entry_rule` before invoking user code, and publish definition order plus immutable
per-rule `is_top` identity. The 66-case shared primary manifest locks first-marker, markerless, explicit, unknown,
and request-trace bytes twice on each admitted backend.

Rust now applies the same ordered resolver across native, loaded, serialized/reconstructed, generated direct/
traced, emitted direct/traced, and primary-command routes. Generated Rust keeps existing entrypoints and adds
option-bearing siblings that take per-invocation `ExecutionOptions`; the selector never enters the minimal family
plan or rewrites descriptor `is_top`. Typed zero/unknown generated failures retain `no_rules_defined` /
`validate_spec` and `entry_rule_not_found` / `select_entry_rule`, while stale generated v1 artifacts still fail at
their earlier contract boundary. One omission-sensitive 15-role Rust consumer topology-locks all neutral/native/
loaded/reconstructed/generated/emitted/descriptor/diagnostic/trace/primary roles, and exact primary proof is 65x2.
Dart accepts markerless sources and applies the same resolver across native, loaded/reconstructed,
generated/emitted direct/traced, and primary execution. It reports portable zero/unknown failures, publishes
immutable descriptor identity, retains generated v2/format-2 identity, traces the selection basis, and composes
all 15 contract-declared admission roles exactly once. Julia core `.9.1.1.2.4.1` now accepts markerless
one-or-more-rule source and applies the same resolver for native/primary execution before runtime context or user
code. Zero rules fail with `no_rules_defined` / `validate_spec` before an explicit selector is considered; an
unknown selector fails with `entry_rule_not_found` / `select_entry_rule` and the requested `entry_rule` field.
Definition order and authored `is_top` remain immutable, and strict-unused still counts authored edges only.
Julia cursor implementation through `.9.1.6.5` removes the legacy help/usage/trace projection while preserving
entry selection, so exact shared primary is 65/65 in both environments. Root admission `.4.3` composes all 15
declared roles once; its authored marked/markerless selection fixtures use `I` returns to prove entered-rule
identity directly. Focused admission is 137, package proof is 3,428, corpus is 105/105, and the checker rejects 39
mutations. Lua core `.5.1` accepts markerless source on both ABIs, resolves the same order before runtime
context/user code, returns portable zero/unknown failures, preserves authored descriptor identity, and passes 99
focused assertions per ABI. Route `.5.2` proves loaded/normalized and generated-v1/emitted direct/traced reuse,
portable loader/generated failures, plan-first ordering, and low selection trace in 101 assertions per ABI without
widening the minimal plan. Cursor `.9.1.7` advances emitted source to v2 and closes the former 33 primary
mismatches. Exact admission `.5.3` then runs one 15-role source on both ABIs at 139/139x2, package 177/177x2,
primary 65/65x4, corpus 105/105x2, and 44 rejected mutations. Pass an explicit selector when identity matters;
otherwise first marker then first rule is now backend-admitted behavior.

Perl keeps authored identity separate from execution state. Bootstrap preserves source order and distinguishes
each `Rule::`; compiled rule metadata now carries `is_top`, while one ordered resolver chooses the effective entry.
An explicit selection of an ordinary rule does not rewrite that rule as marked or clear any authored marker.
Strict-unused validation is also separate: only authored rule edges count as references, and selection or `::`
contributes neither a reference nor an exemption.

The double colon is purely authored default-selection metadata. A marked rule is otherwise an **ordinary rule** —
it may carry a regex, take any rule
mode (§2.2), and be recursive (§5.4), exactly like a body rule. The common "no regex on
the top rule, dispatch to body rules that carry the regex" two-rule shape is recommended
**idiom**, not a constraint a backend enforces.

### 2.2 Rule Modes

The mode suffix, if present, immediately follows the colon(s) with no space:

| Mode | Meaning | Typical placement |
|---|---|---|
| *(no suffix)* | Repeated choice (default). Equivalent to `:OR+`. Handled by `:*`. | Any rule (top or body) |
| `:AND` | Ordered sequence. Each child regex matched in order. | Body rule (idiom) |
| `:OR` | Repeated choice across alternatives. | Body rule (idiom) |
| `:&` | Ordered sequence (equivalent to `:AND`). | Body rule (idiom) |
| `:\|` | Single choice — one successful alternative wins (`:OR{1}`). | Body rule (idiom) |
| `:+` | One-or-more repeated choice (`:OR{1,}`). Equivalent to `:*` bounded. | Body rule (idiom) |
| `:*` | Zero-or-more repeated choice (`:OR{0,}`). | Body rule (idiom) |
| `:?` | Zero-or-one choice (`:OR{0,1}`). | Body rule (idiom) |
| `:OR+` | Unbounded repeated choice (one or more). | Body rule (idiom) |
| `:AND+` | Unbounded repeated ordered sequence (one or more). | Body rule (idiom) |
| `:AND{N}` | Ordered sequence repeated exactly N times. | Body rule (idiom) |
| `:AND{N,M}` | Ordered sequence repeated N to M times. | Body rule (idiom) |
| `:AND{N,}` | Ordered sequence repeated N or more times. | Body rule (idiom) |
| `:AND{,M}` | Ordered sequence repeated up to M times. | Body rule (idiom) |
| `:OR{N}` | Repeated choice exactly N times. | Body rule (idiom) |
| `:OR{N,M}` | Repeated choice N to M times. | Body rule (idiom) |
| `:OR{N,}` | Repeated choice N or more times. | Body rule (idiom) |
| `:OR{,M}` | Repeated choice up to M times. | Body rule (idiom) |

Where `N` and `M` are non-negative integers.

The **Typical placement** column records the recommended **idiom**, not a backend
restriction. Because a top (`::`) rule is an ordinary rule that is merely entered first
(§2.1), a mode suffix may appear after either colon form — `Top::AND`, `Stream::OR+`,
and `Pair::&` are all valid. Body-rule placement is the convention; the engine does not
reject a mode on a top rule.

**Semantics**:
- **AND modes** match child regexes sequentially, in order, exactly once per repetition.
- **OR modes** try each alternative independently on each repetition; the first match
  wins. On the next repetition, all alternatives are retried from the new position.
- **Bounded repetition** loops the specified number of times. The loop terminates when
  the bound is reached or when a child fails to match (for `{N,}` and `{N,M}` forms).
- **Zero-progress guard**: repeated modes refuse to loop infinitely when a child
  succeeds but consumes zero input. The parser detects zero-progress and terminates
  the loop to prevent a hang.

### 2.3 Rest-of-Line After Header

Any text on the same line after the rule label + colon(s) + optional mode is the
**header rest**. The header rest may carry:
- A regex cluster (the rule's first regex anchor)
- Body elements on the same line (compact style)

Same-line body elements are semantically equivalent to body elements on subsequent
lines — the paragraph model is unchanged.

## 3. Rule Body Elements

After the rule header, the rule paragraph contains zero or more **body elements**.
Body elements may span multiple lines. The following body element types exist:

### 3.1 Regex Clusters

```
/pattern/flags
```

A regex literal delimited by `/`. The pattern body may contain escaped forward
slashes (`\/`). Flags are expressed **inline**, inside the pattern, using modifier
groups such as `(?i)`, `(?m)`, `(?s)`, or scoped forms like `(?s:…)` — the `.spec`
layer adds no flag system of its own beyond what the host regex engine supports.

**Semantics**: A regex cluster anchors the parser at a specific input position.
In `consume` mode (`\G`-anchored), the regex must match contiguously from the
current position. In `seek` mode (ungrounded `//gcp`), the regex may match
anywhere. ADR `0044` fixes one semantic authority: AND-family rules consume and
OR/default-family rules seek. All five backends implement this family-derived cursor policy, reject the retired
caller-global override, and close rollout at 8 complete / 0 pending.

Multiple regex clusters in a row form an ordered sequence for AND-mode rules
or a set of alternatives for OR-mode rules. When clusters are combined as
alternatives, the engine records **which** alternative matched (0-based) and uses
that to drive dispatch.

All five backends accept a stable rule-local name on a regex member:

```text
name=/pattern/
name = /pattern/
```

Only horizontal spacing around `=` is insignificant. Every name scalar uses the repository-pinned Unicode 17
`XID_Continue` class; identity is exact, case-sensitive, and normalization-sensitive. ASCII digit-only names are
reserved for positional selectors. Named and anonymous regex members may mix in one authored zero-based sequence.
The named-slot and inter-match-gap language/runtime contract is current through Perl, Rust, Dart, Julia, PUC Lua,
and LuaJIT. All routes preserve authored/static/compiled metadata, invocation-local gap execution, normalized
reconstruction, compatible descriptor projections, generated-v2 execution, and independently loaded emitted
source. Outward facade and schema surfaces remain intentionally unchanged.

On Perl, named and anonymous members retain their authored order and identity
when they share a line with lifecycle blocks, including the header rest. Code
patterns, strings and comments do not add slots. See the complete
[same-line selection example](../public-api/integration-perl.md#regex-and-division-in-action-code)
for named/numeric equivalence and a mismatching-selector control.

**Capture groups**: A `(...)` group is a **numbered** capture; a `(?<name>...)`
group is a **named** capture. Action code reads them with `entry_group(N)` /
`match_group(N)` (numbered) and `entry_named(name)` / `match_named(name)` (named).
Numbered groups are **0-based over the captured groups** — index `0` is the *first*
capture group, not the whole match (the whole match is `entry_text()` /
`match_text()`) — and the numbered list is **compacted**, so a group that did not
participate in the match is dropped and shifts the indices after it. Named groups
are keyed by name and are not affected by compaction. The
[Regex in `.spec`](../user-model/regex-in-spec.md) chapter gives the full mental
model with worked examples, and states the regex feature set a backend must support.

### 3.2 Action Edges

```
-> TargetRule       (shorthand for -> TargetRule[0])
-> TargetRule[N]    (selects regex slot N of TargetRule)
-> TargetRule[name] (selects the stable named regex slot of TargetRule)
```

An action edge binds the current rule to a child rule via an **action code block**.
After the regex cluster(s) match, the parser transfers to `TargetRule` and executes
its associated action code.

- **Whitespace**: spaces or tabs after `->` are optional. Examples use `-> Rule`
  for readability, but `->Rule` and compact header-rest forms such as
  `Top::->Rule.push` are valid spellings.
- **Target indexing**: `-> rule` means entry slot `[0]`. `-> rule[N]` selects a
  positional regex slot; `-> rule[name]` selects stable rule-local identity. A numeric selector may resolve a
  named declaration, but it remains positional provenance. Named selection is current on all five backends and
  six runtime routes.
- **Grouped targets**: `-> RuleA | RuleB { ... }` binds one shared action code
  block to multiple target rules.
- **Grouped-target boundary**: the shared block is mandatory. `-> RuleA | RuleB`
  without `{ ... }` is invalid; use separate action edges when there is no shared
  block to factor.

### 3.3 Blind-Call Edges

```
=> ChildRule
```

A blind-call edge delegates to `ChildRule` **without** an action code block. The
child rule's own action code runs. This is used for parser orchestration where the
parent rule controls dispatch but does not transform the child's result.

- **Whitespace**: spaces or tabs after `=>` are optional. Examples use `=> Child`
  for readability, but `=>Child` is valid.

Blind-call behavior follows the **rule label mode**, not the edge alone. Explicit
`:AND` on the child rule is required for sequential blind-call dispatch. A bare
`rule:` label with blind-call edges still behaves as repeated choice.

#### 3.3.1 Bare-edge normalization

ADR `0044` defines this line-level source grammar. Bare-edge normalization is complete at 8 complete / 0 pending,
and all five backends implement it before typed validation:

```text
BareEdgeLine ::= TargetRule BareSuffix?
BareSuffix   ::= ActionBlock | FluentChain
```

The member must begin a physical rule-paragraph line and `TargetRule` must be a
declared rule (forward declarations are valid). It normalizes before typed
validation:

- AND family: `Child...` becomes `=> Child...`;
- OR/default family: `Child...` becomes `-> Child...`.

Explicit markers remain authoritative and legal across families. An indexed
bare target in AND is invalid; write `-> Child[N]`. Grouped bare targets are
valid only in OR/default and require the same shared block as grouped explicit
action edges. Lifecycle words `I`, `LS`, `LE`, `LX`, `E`, `EX`, and `IT` take
lexical precedence; use an explicit marker to call a same-named rule. After
normalization, action and blind edge ownership still cannot coexist in one
rule.

### 3.4 Code Blocks (Action / Lifecycle)

```
{ code }
```

A `{ }` block contains **action code** or **lifecycle code**. The block's context
determines how the code is interpreted:

- **After an action edge** (`-> rule { ... }`): the block is the **action code** for
  that edge. It runs after the child rule completes. The block can declare variables,
  read captures, transform results, and return values.

- **After a blind-call edge** (`=> rule { ... }`): deprecated but accepted as
  compatibility syntax. Prefer lifecycle blocks for blind-call rules.

- **Standalone lifecycle block**: on all five backends, this is exact shorthand for `I { ... }` at the same
  authored position. Parsing preserves the authored block source/opening line and gives its interior the explicit
  twin's ActionIR semantics and spans. Multiple explicit/shorthand blocks execute in authored order. New source
  parsing never emits `PlainBlock`; legacy programmatic/serialized plain carriers remain readable and inert.

Blocks nest: `{ ... { ... } ... }`. Opening brackets `{`, `(`, `[` inside a block
must be balanced by their closing counterparts. A rule paragraph with an unclosed
block at end of file is invalid.

### 3.5 Split Markers

```
@capture_slice
@capture_from_here       (compatibility alias for @capture_slice)
@move_pos                (compatibility alias for @capture_slice)
@mark(name)
```

Split markers control anonymous and named capture boundaries during parsing:
- `@capture_slice`: moves the anonymous capture-start cursor to the current position.
- `@mark(name)`: stores the current absolute position under a named mark for later
  retrieval via `capture_from(name)`, `capture_between(...)`, etc.

### 3.6 Lifecycle Markers

```
I
LS
LE
E
EX
IT
LX
```

Lifecycle markers define **when** code blocks execute relative to the rule's
children:

| Marker | Meaning |
|---|---|
| `I` | Initialization — runs before any child is attempted. |
| `LS` | Loop start — runs before each repetition of a repeated rule. |
| `LE` | Loop end — runs after each child match in a repeated rule. |
| `E` | Exit — runs after all children complete successfully. |
| `EX` | Exit (extended) — runs after E, can observe the final result. |
| `IT` | Iteration — per-child iteration context. |
| `LX` | Loop exit — runs after a repeated rule's loop terminates. |

Lifecycle markers are **semicolon-light structured authoring**: a marker followed by
`{ code }` is a lifecycle block. Portable branch control includes statement markers,
attached-block `if` forms, attached `switch`, attached `while`, and inline-composite `if`/`switch` value
expressions in supported value positions.
Within structured blocks, newlines separate top-level helper statements implicitly.
A semicolon separates adjacent top-level helper statements that share one physical line;
the final statement does not require a trailing semicolon. Plain same-line whitespace is
not a statement separator, and semicolons inside nested expressions or literal payloads
remain protected.
For Perl's current final slash-call boundaries, remaining parsing limitations and
runnable examples, see [Regex and division in action code](../public-api/integration-perl.md#regex-and-division-in-action-code).
Lifecycle blocks are not expression-valued blocks: ordinary final statement values are
discarded, and only an explicit top-level `return(expr)` writes the rule return channel.

In value positions, a non-empty `{ ... }` payload without a top-level hash pair separator is an
expression-valued block on every current native backend. It returns the final
expression unless a `return(expr)` statement is reached earlier; that `return(expr)`
exits only the expression-valued block, skips later statements in that block, and
yields `expr` as the block value. Empty `{}` and top-level hash-pair forms such as `{ key : value }`
remain hash literals. Direct hash literals use `:` as their key/value separator; old `{ key => value }`
ActionIR value syntax is retired and diagnoses as `hash_literal_use_colon`. Because the block is a value expression, it may also be the
receiver of a compatible receiver-dot chain, such as `{ [3, 1, 2] }.sorted().join_values(",")`
or `{ " a-b " }.trim().split("-").count()`.
Ordinary assignment evaluates this form immediately; deferred first-class codeblocks use `{|params| ...}`.

### 3.7 Fluent Chains

```
.method1(arg).method2(arg2).method3()
```

A fluent chain on an action edge or inside a lifecycle block uses dot-method syntax.
Each method is a helper from the ActionIR helper families (§7). For ordinary helper statements,
compact lifecycle-marker receiver chains and structured block forms are equivalent. Cross-backend
portability is guaranteed for structured marker/attached-block forms, receiver-fluent
`when/otherwise` block chains on action-edge and lifecycle-marker surfaces, action-edge
`.push` / `.return(expr)` / `.return_undef()` continuations, explicit action-edge
`.push(target)` / `.push(child,target)` child-return appends, statement-control fluent chains that
gate those calls, and compact lifecycle-marker chains such as `I.return(expr)` or
`I.set(...).return(...)`.

Rule-edge and lifecycle fluent control-flow markers accept bare-keyword suffix form:
```
.else   .endif   .default   .endcase   .endswitch
```

These suffixes are equivalent to their parenthesized forms `.else()`, `.endif()`, etc. The Perl, Rust, Dart, Julia,
and Lua typed ActionIR parsers accept standalone bare `else`, `endif`, `default`, `endcase`, `endswitch`, and
`next`, plus a final zero-argument receiver segment such as `.trim`. Parenthesized standalone markers and generic
receiver calls remain valid.

ADR 0033 deliberately keeps the exception narrow. Calls with arguments, general helper/user-function calls,
intermediate generic receiver segments, and condition-bearing headers keep parentheses. In particular,
`if condition { ... }` and `while condition { ... }` are not accepted aliases for `if(condition) { ... }` and
`while(condition) { ... }`; that separate design idea remains deferred pending an ambiguity audit.

The adopted neutral contract makes the intended equivalences and boundaries executable before backend rollout:

```text
else                         == else()
endif                        == endif()
next                         == next()
text.trim                    == text.trim()
values.sorted().first        == values.sorted().first()
```

Here `sorted()` remains parenthesized because it is not the final segment. A terminal method that requires an
argument still receives zero authored arguments and therefore has exactly the same contract outcome as its
parenthesized zero-argument spelling: `values.contains` equals `values.contains()`, not
`values.contains("x")`. The following do not become calls under ADR 0033:

```text
return value                 # general helper call still requires return(value)
values.sorted.count()        # generic bare intermediate segment is not admitted
value.with { ... }           # contextual final block keeps .with() { ... }
if flag { ... }              # condition header keeps if(flag) { ... }
while flag { ... }           # condition header keeps while(flag) { ... }
```

The versioned source of truth is
`capability_conformance/punctuation_light_zero_arg_contract.json`, checked independently by
`tools/check_punctuation_light_zero_arg_contract.py`. Perl consumes it through
`t/punctuation_light_zero_arg_contract.t`; Rust consumes its syntax/AST and execution cases through
`rust/linkedspec-runtime/tests/punctuation_light_zero_arg_contract.rs`; Dart consumes it through
`dart/test/punctuation_light_zero_arg_contract_test.dart`; Julia consumes it through
`julia/test/punctuation_light_zero_arg_contract_test.jl`; Lua consumes it inside `lua/test/run.lua` on both ABIs.
Rust, Dart, Julia, and Lua's pre-existing zero-argument `.contains()` outcomes are separately owned by helper-
normalization backlog `.5`. Lua proves public SpecFile JSON reconstruction rather than nonexistent generated
source; `LUA-BACKEND-PARITY.8.1-.8.4` owns its future emitter. The current syntax is admitted by `.16.7`; the
recurring five-backend/two-Lua-ABI proof is `bash tools/check_punctuation_light_five_backend.sh`.

### 3.8 Conditional Markers

```
-? word
```

A conditional marker is a hyphen-question prefix followed by a word. It carries
metadata about optional or conditional dispatch — recognized structurally but its
semantics are determined by the consuming rule.

### 3.9 Word-Based Body Code

```
word(args...) { ... }
method(args...)
```

A word followed by parenthesized arguments and optionally a code block. This
covers helper calls, declarations, control flow, and raw compatibility code.
See §7 for the canonical helper families.

## 4. Lifecycle Execution Model

For a rule with children (edges), execution follows a fixed lifecycle order:

1. **I** — initialization block runs once.
2. For each repetition (repeated rules only):
   a. **LS** — loop-start block runs.
   b. Child regexes are matched.
   c. Action or blind-call code runs for matched children.
   d. **LE** — loop-end block runs (receives child result).
3. **IT** — per-child iteration context runs.
4. **E** — exit block runs.
5. **EX** — extended exit block runs.
6. **LX** — loop-exit block runs (repeated rules only, after loop termination).

For non-repeated rules, LS, LE, and LX are skipped.

## 5. Parse Modes

### 5.1 Seek Mode

The default parse mode for OR-type rules. The regex is matched ungrounded (`//gcp` —
match anywhere in the remaining input). Each repetition finds the next match position.
Use `seek` when children may appear in any order or at variable positions.

### 5.2 Consume Mode

Used for AND-type rules and explicit `consume` directives. The regex is `\G`-anchored —
it must match contiguously from the current position. Use `consume` for ordered
sequences where input must be consumed in exact order.

### 5.3 Explicit Cursor Controls

LinkedSpec exposes explicit cursor controls:

- `save_cursor()` pushes the live cursor onto the cursor stack.
- `restore_cursor()` pops the cursor stack and restores the live cursor when a
  saved position exists.
- `rewind_match_start()` rewinds to the start of the current local match.
- `rewind_entry_start()` rewinds to the start of the initial/entry match for
  the current context; this is the same initial-match context exposed to the `I`
  lifecycle.
- `capture_until_boundary(rule[, ...])` captures from the live cursor to the
  earliest named structural boundary and leaves that boundary unconsumed.

These are local cursor operations only. LinkedSpec does not maintain a search
tree, unwind partial rule matches, or restore alternative-choice state.

### 5.4 Recursion and Forward-Progress Termination

A rule may recurse: an action edge (`-> rule` / `-> rule[N]`) or a `call(rule)`
expression (§7.10) may re-enter the same rule, directly or through a cycle of rules.
Recursion may re-enter the **top rule** as well — the top rule is an ordinary rule
(§2.1), so a single recursive document can be parsed by a recursive top rule directly.

The one requirement is **forward progress (consume before you recurse)**: every
recursive cycle must consume input before it recurses. Idiomatic recursion does this
naturally — a parenthesis rule matches `(`, recurses, then matches `)`, so each level
advances the cursor.

A backend **must** guarantee termination of a non-progressing cycle: if a rule is
re-entered at an input position already active on its own recursion stack (no input was
consumed since that entry), the re-entry is **cut** — it yields `undef` — so the parser
terminates instead of recursing without bound. This is a hard requirement, not an
optimization: a backend that recurses natively without this guard can exhaust its call
stack on a no-consume cycle. The cut fires **only** on genuine non-progress, so
legitimate consume-before-recurse recursion (which advances the position before each
re-entry) is never affected.

A recursive rule used **as the top rule** is still an ordinary accumulating rule, so it
needs a loop-exit (`LX`) block to surface its accumulator at end of input, exactly like
any accumulating top rule. Without the `LX` it returns `undef` at end of input (the
missing-`LX` authoring case), not a partial result.

## 6. Comments

```
# comment text
```

A `#` at the beginning of a line (after optional whitespace) starts a comment.
Comments are not part of any rule paragraph. Comments inside rule paragraphs
(after the header line) are not supported.

## 7. Helper DSL Families

Inside `{ }` code blocks and on fluent chains, `.spec` authoring uses a
backend-neutral method-like helper DSL. This section catalogs the canonical
families. For the full behavioral contract per helper, see the
[Helper Contract Catalog](helper-contract-catalog.md).

Primitive value literals are accepted anywhere an explicit value expression is
accepted:

```text
"text" / 'text'   — string
42 / -1 / 3.14    — number
true / false      — typed boolean
undef             — undefined/null
```

`true` and `false` are boolean values, not strings. Literal recognition is exact:
`trueword`, `false_alarm`, and `undefine` are identifiers, not literals. In supported
scalar read slots such as `return(trueword)` and `items += trueword`, those identifiers
are working-variable reads.

Helper calls use the uniform `callee(args)` shape. Whitespace between the callee
name and the opening parenthesis is accepted (`set (name, value)` is the same call
as `set(name, value)`), but the parentheses are still mandatory; no-parenthesis
spellings such as `set name, value` or `return scalar name` are not helper calls.

Direct nested access is a value-expression form:

```text
direct_access : name direct_segment+
direct_segment : '[' quoted_string ']'
               | '[' bare_identifier ']'
               | '[' explicit_index_expr ']'
nested_assignment : direct_access '=' expr
```

The base `name` is a working value that holds a structured array/hash payload.
Quoted string segments (`["field"]` or `['field']`) are hash-key reads. Numeric
segments and helper/value expressions (`[0]`, `[i]`, `[add(1, 2)]`) are
array-index reads. Non-reserved bare path atoms such as `[i]` are also scalar
array-index reads of working variable `i`. Primitive literals and engine
locals are not claimed as bare path atoms.

When `direct_access` is used as `nested_assignment` on any backend, every segment is retained as an ordinary typed
expression. Its evaluated string/nonnegative-integer kind selects harray/array, so an absent root and unambiguous
missing intermediates may be created. Existing null/wrong kinds are not coerced; array indexes replace or append
exactly at length and gaps fail. Segments then RHS evaluate before isolated structural work; typed failures commit
no partial path. Read semantics remain non-creating on every backend.

Bare scalar reads and typed assignment:

```text
name                         — read working variable name in scalar value positions
set(name, [value])            — bind the array payload as the typed value of name
```

Use the bare spelling when the value must visibly come from a working variable.
Bare direct-shape assignment binds the typed value to the bare variable:
`set(name, [value])` stores an array value in `name`.
Use `set(name, ...)` with an array or harray RHS when that typed value is intended.

### 7.1 Working-Variable Helpers
```
name = value                — bind a typed value to a working variable
items = []                  — bind an array value to items
meta = {}                   — bind a hash value to meta
set(name, value)            — helper form of assignment
return(name)                — read and return a scalar working variable
```

### 7.2 Scalar Helpers
```
base["key"][0]                 — direct nested access into scalar-held payloads
container[key]          — read a scalar entry from an array or hash
cat(args...)                 — concatenate strings
coalesce(a, b, ...)             — first defined non-null value
coalesce_nonempty(a, b, ...)    — first defined non-empty value
is_defined(expr)                — true if expr is not undef
is_undefined(expr)              — true if expr is undef
trim(s)                         — remove leading/trailing whitespace
lowercase(s)                    — lowercase
uppercase(s)                    — uppercase
length(s)                       — string/array length
matches(s, /pattern/)           — regex match predicate
starts_with(s, prefix)          — prefix check
ends_with(s, suffix)            — suffix check
contains_substr(s, needle)      — substring check
replace_substr(s, old, new)     — literal string replacement
rm_prefix(s, prefix)            — remove prefix
rm_suffix(s, suffix)            — remove suffix
substr(s, start, len?)          — substring from zero-based start
substr(target, /re/, repl, flags)
regex_subst(target, /re/, repl, flags)
                        — regex substitution mutating a scalar target
string_expr.trim().lowercase()
                        — receiver-dot string value chain over compatible pure scalar helpers
string_expr.split(delim).trim_each().join_values(delim)
                        — explicit string-to-array receiver-chain bridge
```

### 7.3 Array Helpers
```
name            — read array working variable name when name is bare
array(e1, e2, ...)     — construct an array; prefer [...] for terse literals
copy(arr)        — shallow copy
array_values(arr)      — retired alias of copy(do not use; see Helper Contract Catalog §Compatibility-Aliases)
flat_array(arr)        — flatten into list context for insertion
concat_arrays(a1, a2)  — concatenate arrays
push(arr, child)        — append child to accumulator
push(arr, child, index) — append child at index
push(arr, value)  — append value to accumulator
push_nonempty(arr, val) — retired on current Perl/Rust runtimes; prefer val = expr; if(is_nonempty(val)) { push(arr, val) }
target.push_back(value) — append to named array; value form returns updated snapshot
target.push_front(value) — prepend to named array; value form returns updated snapshot
target.pop_back()       — remove last item; value form returns updated snapshot
target.pop_front()      — remove first item; value form returns updated snapshot
count(arr)              — number of elements
first(arr)              — first element
last(arr)               — last element
take(arr, n)            — first n elements (default 1)
take_last(arr, n)       — last n elements (default 1)
drop_front(arr, n)      — all but first n (default 1; alias: tail)
drop_back(arr, n)       — all but last n (default 1; alias: drop_last)
slice(arr, start, n)    — subarray from start, n elements
sorted(arr)             — sorted ascending
reversed(arr)           — reversed order
arr.sorted().first()    — receiver-dot array value chain over compatible pure array helpers
{ [3, 1, 2] }.sorted().join_values(delim)
                        — expression-valued block yielding an array as a receiver
sorted_keys(hash)       — keys sorted by name, as array
sorted_values(hash)     — values sorted by key name, as array
hash_expr.set_key(k, v).sorted_keys().join_values(delim)
                        — receiver-dot hash value chain over compatible pure hash/array helpers
hash_expr.map_leaves() { return(value) }
                        — hash-tree receiver block traversal over non-hash leaves
array_expr.map_leaves() { return(value) }
                        — array-tree receiver block traversal over scalar/hash leaves; Perl/Rust/Dart current
binding_identifier.map_leaves!() { block }
                        — five-backend current receiver mutation; one bare existing harray/array binding, dedicated
                          bang AST, callback-result leaf replacement, original-shape traversal, atomic rebind
contains(arr, needle)   — array membership test
index_of(arr, needle)   — first index of needle
is_empty(arr)           — true if array/hash is empty
is_nonempty(arr)        — true if array/hash has elements
join_values(delim, arr) — join array elements with delimiter
split(s, delim)         — split string into array
split(target, source, delim)
                        — replace target array with split source pieces
split_each(arr, delim)  — split each element
trim_each(arr)          — trim each element
filter_nonempty(arr)    — remove empty elements
filter_match(arr, /re/) — keep elements matching regex
uniq(arr)               — remove duplicates
lowercase_each(arr)     — lowercase each element
uppercase_each(arr)     — uppercase each element
print_each(arr, prefix[, suffix]) — emit one caller-owned diagnostic event per element
```

### 7.4 Hash Helpers
```
name              — read hash working variable name when name is bare
hash(k1, v1, k2, v2)    — construct a hash from flat key/value pairs
flat_hash(h)             — flatten hash into list context
copy(h)             — shallow copy
merge_hash(h1, h2)       — merge h2 into h1 (returns new hash)
set_key(h, key, val)     — set key to value (returns new hash)
rename_key(h, old, new)  — rename key (returns new hash)
drop_keys(h, k1, k2...)  — remove keys (returns new hash)
pick_keys(h, k1, k2...)  — keep only named keys (returns new hash)
has_key(h, key)          — key presence test
count_keys(h)            — number of keys
hash_expr.walk_leaves() { block }
                        — visit every non-hash leaf for side effects, returns original hash
hash_expr.map_leaves() { block }
                        — replace every non-hash leaf with block result, returns new hash
hash_expr.reduce_leaves(initial) { block }
                        — fold every non-hash leaf into acc, returns final accumulator
array_expr.walk_leaves() { block }
                        — visit every scalar/hash leaf for side effects, returns original array tree
array_expr.map_leaves() { block }
                        — replace every scalar/hash leaf with block result, returns new array tree
array_expr.reduce_leaves(initial) { block }
                        — fold every scalar/hash leaf into acc, returns final accumulator
binding_identifier.map_leaves!() { block }
                        — five-backend current; callback binds value, path (also @path on Perl), depth, and key or
                          index; direct callback mutation of the receiver identity is rejected
```

The bang suffix above belongs only to the exact `map_leaves!` method token; it is not part of identifier grammar.
The receiver cannot be a literal, temporary, helper result, property, or bracket access. Function-form
`map_leaves!(binding)`, `walk_leaves!`, `reduce_leaves!`, bang continuation, and arbitrary user-defined bang names
are excluded. Shared Lua accepts the exact form on PUC Lua and LuaJIT; `.19.7` admits the exact portable capability
row, `.19.8` completes exact six-runtime recurrence, and `.19.9` closes public no-drift for this exact grammar.

### 7.5 Numeric Helpers
```
num_add(a, b)            — addition
num_sub(a, b)            — subtraction
num_mul(a, b)            — multiplication
num_div(a, b)            — division (undef on divide-by-zero)
num_mod(a, b)            — modulo (undef on divide-by-zero or non-integer)
num_abs(x)               — absolute value
num_floor(x)             — floor
num_ceil(x)              — ceiling
num_round(x)             — round to nearest integer
num_min(a, b)            — minimum (also reducer: num_min(arr))
num_max(a, b)            — maximum (also reducer: num_max(arr))
num_clamp(x, lo, hi)     — clamp to [lo, hi] range
num_sum(arr)             — sum of array elements
num_avg(arr)             — average of array elements
num_median(arr)          — median of array elements
num_range(arr)           — max - min of array elements

abs(x), floor(x), ceil(x), round(x)      — aliases for the matching num_* helpers
add(a, b), sub(a, b), mul(a, b)          — aliases for num_add/num_sub/num_mul
div(a, b), mod(a, b), clamp(x, lo, hi)   — aliases for num_div/num_mod/num_clamp
min(...), max(...), sum(arr)             — aliases for num_min/num_max/num_sum
avg(arr), median(arr), range(arr)        — aliases for num_avg/num_median/num_range
arr.sum(), arr.avg(), arr.median()       — terminal array receiver reducer methods
arr.range(), arr.min(), arr.max()        — terminal array receiver reducer methods
+(a, b), -(a, b), *(a, b)                — aliases for num_add/num_sub/num_mul
/(a, b), %(a, b)                         — aliases for num_div/num_mod
eq(a, b), ne(a, b), gt(a, b)             — aliases for num_eq/num_ne/num_gt
ge(a, b), lt(a, b), le(a, b)             — aliases for num_ge/num_lt/num_le
==(a, b), !=(a, b), >(a, b)              — aliases for num_eq/num_ne/num_gt
>=(a, b), <(a, b), <=(a, b)              — aliases for num_ge/num_lt/num_le

number_expr.abs().ceil().add(n).mul(n)  — receiver-dot number helper chain
number_expr.gt(n)                       — terminal receiver-dot numeric comparison
```

The terse function aliases above are ordinary calls, not infix operators, so
they do not introduce precedence. Write nested calls such as `+(*(a, b), c)` when
you need grouping. Comparison word aliases are numeric calls over the matching
`num_*` helpers, and comparison symbol aliases are the same ordinary call shape.
The task-tree-owned comparison migration also added the explicit
string-comparison bridge names `str_eq`, `str_ne`, `str_gt`, `str_ge`, `str_lt`,
and `str_le`; use those shipped names for lexical string comparisons.

### 7.6 Control Flow Helpers
```
if(cond, then, elseif(cond2, then2), else(default))    — portable lazy value form
if(cond); ... elseif(cond2); ... else(); ... endif()
if(cond) { ... } elseif(cond2) { ... } else { ... }
when(cond) { ... } otherwise { ... }
switch(expr, case(val, body), default(body))           — portable lazy value form
case(val, body)
default(body)
exit_now(status)         — exit parser immediately
next()                   — skip to next repetition (consume/recognize without append; Perl also accepts bare next)
return(value)            — return value (canonical form)
return_undef()           — return undef
return(array(...))       — return array
```

`i`/`elif` are aliases only for the marker statement family, and `when`/`otherwise` only for the attached-block
family; they are not aliases for inline value-form calls. Perl, Dart, and Julia currently accept additional
alias/shape combinations that Rust rejects. Those are backend extensions, not portable grammar; backlog `.5`
owns alignment.

### 7.7 Capture/Mark Helpers
```
capture_slice()                    — text from anonymous start cursor to current position
capture_slice_len()                — length of capture_slice
capture_until_cursor_from(name)    — text from named mark to current cursor
capture_rest_from(name)            — text from named mark to end of input
capture_between(start, end)        — text between two named marks
capture_from(name)                 — text from named mark to current position
capture_take_len_from(name)        — take length from named mark
start_capture_slice()              — move anonymous capture-start cursor to current pos
mark_input_start(name)             — mark absolute input-start boundary
mark_input_end(name)               — mark absolute input-end boundary
mark_copy(name)                    — copy a named mark
```

### 7.8 Entry/Match Helpers
```
entry_text()          — full text of the current match entry
entry_group(index)     — capture group by index
entry_groups()         — all capture groups as flat array
entry_named(name)      — named capture group
entry_has(name)        — does named group exist
entry_map()            — named groups as hash (alias: entry_named_map)
entry_len()            — length of matched text
entry_start_pos()      — absolute start position
entry_end_pos()        — absolute end position
entry_end_line()       — line number of end position
entry_end_col()        — column of end position
match_text()           — full text of local match
match_group(index)      — local match capture group
match_groups()          — all local match groups
match_named(name)       — local named capture
match_has(name)         — does local named group exist
match_map()             — local named groups as hash
match_len()             — length of local match
match_start_pos()       — local match start position
match_end_pos()         — local match end position
```

### 7.9 Input Helpers
```
input_text()            — entire current input
input_slice(start, len) — substring of current input
input_len()             — length of current input
input_end_line()        — line number of input end
input_end_col()         — column of input end
```

### 7.10 Call Expression
```
call(child_rule)         — call a child rule directly from action code
```

## 8. Authoring Styles

`.spec` files support two equivalent authoring styles:

The lifecycle blocks (`I`/`LS`/`LE`/`E`/`EX`/`IT`/`LX`) are top-level rule-paragraph
members — siblings of the `->`/`=>` edges, never nested inside an edge's `{ … }`. The
two styles below differ only in how the **edge's own action code** is written.

### 8.1 Structured Block Form
```
Top::
 I { results = [] }
 -> Child {
   push(results, call(Child))
 }
 LX { return(copy(results)) }
```

### 8.2 Fluent Chain Form
```
Top::
 I { results = [] }
 -> Child .push(results, call(Child))
 LX { return(copy(results)) }
```

Both forms lower to identical ActionIR and produce identical parser behavior.
The choice is stylistic.
In either form, structured block bodies use the same statement separator rule: newline
between top-level helper statements is enough, while adjacent helper statements on one
physical line require a semicolon between them, not after the last statement.

## 9. Attached-Block Control Flow

Within lifecycle blocks, portable branch control includes attached-block `if`, marker statements, and inline
composite expressions. Marker-style `if` is implemented on the Perl reference and Rust backend:

```
I {
 if(matches(value, /^yes$/));
 result = "confirmed";
 elseif(matches(value, /^no$/));
 result = "rejected";
 else();
 result = "unknown";
 endif()
}
```

Inline-composite `if(...)` and `switch(...)` are portable value expressions in supported value positions:

```
E {
 return(if(is_nonempty(type),
   "typed",
   else("missing")
 ))
}
```

```
E {
 return(switch(type,
   case("regex", "regular expression"),
   case("edge", "edge"),
   default("other")
 ))
}
```

Attached and inline structured controls are current on all five backends. Perl, Rust, Dart, Julia, and Lua accept attached-block
`if(...) { ... } elseif(...) { ... } else { ... }`, including compact same-line continuations;
attached-block `when(...) { ... } otherwise { ... }` as aliases for `if(...) { ... } else { ... }`;
and attached-block `switch(...) { case(...) { ... } default { ... } }` with first-match/default semantics.
Each backend normalizes attached branch forms through its statement-control runtime and accepts attached
`while(...) { ... }` with condition re-evaluation and a deterministic 10000-iteration loop-safety guard.
Inline value-form `if(...)` and `switch(...)` are portable on all five backends in supported value-consuming slots:
`return(...)`, assignment RHS, and fluent `.return(...)`.
Zero-argument markers that are already implemented, such as `else`/`endif`,
accept bare-keyword form in addition to parenthesized form.

## 10. Constraints and Validation

A valid `.spec` file must satisfy the following current portable checks:

1. At least one rule exists. Perl, Rust, Dart, Julia, and Lua validation accept a markerless file. Root selection
   is current at 7 complete / 0 pending across Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT: an explicit selector
   wins, otherwise the first authored `Rule::` wins, otherwise the first authored ordinary `Rule:` wins. A
   zero-rule executable spec is always invalid. Implemented loader/generated routes report portable
   `no_rules_defined` / `validate_spec` before considering either default or explicit selection.
2. Every rule declaration and edge target satisfies the Unicode rule-label contract in §2.1.
3. Every rule label is unique. Duplicate labels are rejected by exact scalar-sequence identity.
4. Every function name is unique and must not collide with any rule label or built-in helper/control name, including numeric word aliases such as `add`.
5. Function parameters must be unique valid identifiers and must not use reserved runtime/lifecycle/function symbols.
6. Rule and function definitions must not appear inside open `{ }` blocks.
7. Every `{ }` block opened inside a rule paragraph or function body must be closed before end of file.
8. Every `->` edge target must reference an existing rule.
9. Every regex cluster must be a compilable regex literal.
10. Rule mode suffixes must use exact supported spellings (§2.2).
11. Stray preamble text before the first rule paragraph or top-level function definition (after blank/comment lines) is
   rejected.
12. Action edges and blind-call edges must not be mixed in a single rule (mixed-edge
   detection). A rule with both `->` and `=>` edges is invalid.

## 11. Compatibility Surface

The following are **legacy compatibility constructs** recognized for migration
tracking but not recommended for new `.spec` authoring:

- Raw Perl expressions and ad hoc operators outside the documented helper/operator slots
- `return_a`, `return_m`, `return_ma`, `return_imatch`/`return_im` (retired)
- `declare(...)` and declaration aliases — use auto-existing variables, assignment, and typed aggregate resets
- `assign(...)` — use `target = value` or `set(target, value)`
- `array_copy(...)`, `hash_copy(...)` — use `copy(...)`
- former `concat` spelling — use `cat(...)`
- `push_value(...)` — use `push(...)`
- `push_nonempty(...)` — use an explicit `is_nonempty(...)` guard plus `push(...)`
- `s(...)`, `a(...)`, `h(...)` — use bare scalar reads, `array(...)`, `hash(...)`
- `array_values(...)` — use `copy(...)`
- `flatten(...)` — use `flat(...)`
- `tail(...)` — use `drop_front(...)`
- `drop_last(...)` — use `drop_back(...)`
- `capture_slice_here()` — use `start_capture_slice()`
- `capture_from_rule_start()` — use `capture_slice()`
- `capture_len_from_rule_start()` — use `capture_slice_len()`
- `capture_slice_length()` — use `capture_slice_len()`
- `capture_rest_length()` — use `capture_rest_len()`
- Bare `return`, bare `exit` — use `return_undef()`, `exit_now(1)`

All shipped `.spec` files compile with zero compatibility-surface rules.
New `.spec` files must maintain this invariant.

## 12. Complete Example

```text
# A complete .spec file showing all major constructs
DemoParser::
 I  { results = [] }
 LS { retv = undef }
 -> Child {
   retv = call(Child);
   push(results, retv);
   next();
 }
 LE { retv = undef }
 LX { return(array("?result:", copy(results))) }

Child: /\s*hello[ \t]+(\w+)/
 I { name = entry_group(0); return(name) }

SecondChild:OR+
 /\s*(\w+)/ -> SecondChild[0] { return(match_group(0)) }

ThirdChild:AND
 -> First .push
 -> Second .push
 LX { return(array("?third:", copy(ThirdChild))) }

First: /first/
 I { return(entry_text()) }

Second: /\s*second/
 I { return(trim(entry_text())) }
```

This grammar:
- `DemoParser::` is a no-regex top rule with one action edge to `Child` plus lifecycle blocks.
- `Child:` is a body rule with a single regex and an explicit return.
- `SecondChild:OR+` is a repeated-choice rule that returns each matched word.
- `ThirdChild:AND` is an ordered-sequence rule with two defined child edges.
