// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "count-copy/noncreating_missing_source.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJjb3VudC1jb3B5L25vbmNyZWF0aW5nX21pc3Npbmdfc291cmNlLnNwZWMiLCJmdW5jdGlvbnMiOltdLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge2JveD17fTtvdXQ9W2NvdW50KGNvcHkoYm94W1wibWlzc2luZ1wiXSkpLGNvcHkoYm94W1wibWlzc2luZ1wiXSkuY291bnQoKV07cmV0dXJuKFtvdXQsY291bnRfa2V5cyhib3gpXSl9IiwibGluZSI6MX0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6ImJveD17fTtvdXQ9W2NvdW50KGNvcHkoYm94W1wibWlzc2luZ1wiXSkpLGNvcHkoYm94W1wibWlzc2luZ1wiXSkuY291bnQoKV07cmV0dXJuKFtvdXQsY291bnRfa2V5cyhib3gpXSkifSwic291cmNlIjoiSSB7Ym94PXt9O291dD1bY291bnQoY29weShib3hbXCJtaXNzaW5nXCJdKSksY29weShib3hbXCJtaXNzaW5nXCJdKS5jb3VudCgpXTtyZXR1cm4oW291dCxjb3VudF9rZXlzKGJveCldKX0iLCJsaW5lIjoxfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
