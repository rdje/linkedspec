// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "count-copy/function_copy_scope.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJjb3VudC1jb3B5L2Z1bmN0aW9uX2NvcHlfc2NvcGUuc3BlYyIsImZ1bmN0aW9ucyI6W3sibmFtZSI6Im1lYXN1cmUiLCJwYXJhbXMiOlsiaXRlbXMiXSwiYXJpdHkiOjEsImJvZHlfc291cmNlIjoicmV0dXJuKGNvcHkoY291bnQoaXRlbXMpKS5hZGQoMSkpIiwiYm9keV9wYXlsb2FkIjp7ImtpbmQiOiJzdGFnZWRfcGF5bG9hZCIsInZlcnNpb24iOjEsIm5vZGVfa2luZCI6ImZ1bmN0aW9uX2RlZmluaXRpb24iLCJwYXlsb2FkX2tpbmQiOiJmdW5jdGlvbl9ib2R5IiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJmdW5jdGlvbl9uYW1lIjoibWVhc3VyZSIsInBhcmFtcyI6WyJpdGVtcyJdLCJhcml0eSI6MSwidGV4dCI6InJldHVybihjb3B5KGNvdW50KGl0ZW1zKSkuYWRkKDEpKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxOSwiZW5kIjo1MiwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9LCJwcm92ZW5hbmNlIjpbeyJraW5kIjoic291cmNlX3NsaWNlIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjE5LCJlbmQiOjUyLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX19XX0sImJvZHlfcGFyc2Vfam9iIjp7ImtpbmQiOiJwYXJzZV9qb2IiLCJ2ZXJzaW9uIjoxLCJqb2JfaWQiOiJwYXJzZV9qb2I6ZnVuY3Rpb25fYm9keTpmdW5jdGlvbnMuMC5ib2R5X3NvdXJjZTphY3Rpb25pci1ib2R5LnNwZWM6YWN0aW9uX2Jsb2NrOjE5LTUyIiwicGFyZW50X2FzdF9wYXRoIjpbImZ1bmN0aW9ucyIsIjAiLCJib2R5X3NvdXJjZSJdLCJub2RlX2tpbmQiOiJmdW5jdGlvbl9kZWZpbml0aW9uIiwicGF5bG9hZF9raW5kIjoiZnVuY3Rpb25fYm9keSIsImZ1bmN0aW9uX25hbWUiOiJtZWFzdXJlIiwicGFyYW1zIjpbIml0ZW1zIl0sImFyaXR5IjoxLCJ0ZXh0IjoicmV0dXJuKGNvcHkoY291bnQoaXRlbXMpKS5hZGQoMSkpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjE5LCJlbmQiOjUyLCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInBhcnNlcl9zcGVjX2lkIjoiYWN0aW9uaXItYm9keS5zcGVjIiwidG9wX3J1bGUiOiJhY3Rpb25fYmxvY2siLCJyZXN1bHRfcG9saWN5IjoicmVwbGFjZV9maWVsZCIsInJlc3VsdF9maWVsZCI6ImJvZHlfYXN0IiwiZmFpbHVyZV9wb2xpY3kiOiJmYWlsIiwiZGlhZ25vc3RpY19vd25lciI6ImZ1bmN0aW9uX2JvZHkifSwiYm9keV9hc3QiOnsia2luZCI6ImFjdGlvbl9ibG9jayIsInNvdXJjZSI6InJldHVybihjb3B5KGNvdW50KGl0ZW1zKSkuYWRkKDEpKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjMzfSwic3RhdGVtZW50cyI6W3sia2luZCI6ImFjdGlvbl9zdG10Iiwic291cmNlIjoicmV0dXJuKGNvcHkoY291bnQoaXRlbXMpKS5hZGQoMSkpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MzN9LCJleHByIjp7ImtpbmQiOiJjYWxsIiwic291cmNlIjoicmV0dXJuKGNvcHkoY291bnQoaXRlbXMpKS5hZGQoMSkpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6MzN9LCJuYW1lIjoicmV0dXJuIiwic291cmNlX21ldGhvZCI6InJldHVybiIsImFyZ3MiOlt7ImtpbmQiOiJmbHVlbnRfY2hhaW4iLCJzb3VyY2UiOiJjb3B5KGNvdW50KGl0ZW1zKSkuYWRkKDEpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MzJ9LCJyZWNlaXZlciI6eyJraW5kIjoiY2FsbCIsInNvdXJjZSI6ImNvcHkoY291bnQoaXRlbXMpKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0Ijo3LCJlbmQiOjI1fSwibmFtZSI6ImNvcHkiLCJzb3VyY2VfbWV0aG9kIjoiY29weSIsImFyZ3MiOlt7ImtpbmQiOiJjYWxsIiwic291cmNlIjoiY291bnQoaXRlbXMpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjEyLCJlbmQiOjI0fSwibmFtZSI6ImNvdW50Iiwic291cmNlX21ldGhvZCI6ImNvdW50IiwiYXJncyI6W3sia2luZCI6InZhcmlhYmxlIiwic291cmNlIjoiaXRlbXMiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MTgsImVuZCI6MjN9LCJuYW1lIjoiaXRlbXMifV19XX0sImNhbGxzIjpbeyJtZXRob2QiOiJhZGQiLCJzb3VyY2VfbWV0aG9kIjoiYWRkIiwiYXJncyI6W3sia2luZCI6Im51bWJlciIsInNvdXJjZSI6IjEiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MzAsImVuZCI6MzF9LCJ2YWx1ZSI6MX1dLCJzb3VyY2UiOiJhZGQoMSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MjYsImVuZCI6MzJ9fV19XX0sImRyb3BzX3ZhbHVlIjp0cnVlfV19LCJzb3VyY2UiOiJmbiBtZWFzdXJlKGl0ZW1zKSB7cmV0dXJuKGNvcHkoY291bnQoaXRlbXMpKS5hZGQoMSkpfSIsInNvdXJjZV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwiYm9keV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge2l0ZW1zPVwiY2FsbGVyXCI7cmV0dXJuKFttZWFzdXJlKFtcImFcIl0pLGl0ZW1zXSl9IiwibGluZSI6Mn0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6Iml0ZW1zPVwiY2FsbGVyXCI7cmV0dXJuKFttZWFzdXJlKFtcImFcIl0pLGl0ZW1zXSkifSwic291cmNlIjoiSSB7aXRlbXM9XCJjYWxsZXJcIjtyZXR1cm4oW21lYXN1cmUoW1wiYVwiXSksaXRlbXNdKX0iLCJsaW5lIjoyfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
