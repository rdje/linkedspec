// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "count-copy/count_copy_zero.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJjb3VudC1jb3B5L2NvdW50X2NvcHlfemVyby5zcGVjIiwiZnVuY3Rpb25zIjpbXSwicnVsZXMiOlt7ImhlYWRlciI6eyJsYWJlbCI6IlZhbHVlIiwiaXNfdG9wIjp0cnVlLCJtb2RlIjoiRGVmYXVsdCIsInJlc3QiOiJJIHtvcmRlcj1cIlwiO291dD1bY29weShjb3VudChbXSkpLmNvYWxlc2NlKHtvcmRlcj1jYXQob3JkZXIsXCJGXCIpOzd9KS5hZGQoMSksY291bnQoW10pLmNvcHkoKS5jb2FsZXNjZSh7b3JkZXI9Y2F0KG9yZGVyLFwiUlwiKTs3fSkuYWRkKDEpXTtyZXR1cm4oW291dCxvcmRlcl0pfSIsImxpbmUiOjF9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJvcmRlcj1cIlwiO291dD1bY29weShjb3VudChbXSkpLmNvYWxlc2NlKHtvcmRlcj1jYXQob3JkZXIsXCJGXCIpOzd9KS5hZGQoMSksY291bnQoW10pLmNvcHkoKS5jb2FsZXNjZSh7b3JkZXI9Y2F0KG9yZGVyLFwiUlwiKTs3fSkuYWRkKDEpXTtyZXR1cm4oW291dCxvcmRlcl0pIn0sInNvdXJjZSI6Ikkge29yZGVyPVwiXCI7b3V0PVtjb3B5KGNvdW50KFtdKSkuY29hbGVzY2Uoe29yZGVyPWNhdChvcmRlcixcIkZcIik7N30pLmFkZCgxKSxjb3VudChbXSkuY29weSgpLmNvYWxlc2NlKHtvcmRlcj1jYXQob3JkZXIsXCJSXCIpOzd9KS5hZGQoMSldO3JldHVybihbb3V0LG9yZGVyXSl9IiwibGluZSI6MX1dfV19';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
