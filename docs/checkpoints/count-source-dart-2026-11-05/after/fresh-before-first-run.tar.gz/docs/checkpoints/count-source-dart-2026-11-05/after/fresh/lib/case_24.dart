// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "count-copy/function_boolean_count_scope.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJjb3VudC1jb3B5L2Z1bmN0aW9uX2Jvb2xlYW5fY291bnRfc2NvcGUuc3BlYyIsImZ1bmN0aW9ucyI6W3sibmFtZSI6Im1lYXN1cmUiLCJwYXJhbXMiOlsiZmxhZyJdLCJhcml0eSI6MSwiYm9keV9zb3VyY2UiOiJyZXR1cm4oZmxhZy5jb3VudCgpLmFkZCgxKSkiLCJib2R5X3BheWxvYWQiOnsia2luZCI6InN0YWdlZF9wYXlsb2FkIiwidmVyc2lvbiI6MSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJwYXJlbnRfYXN0X3BhdGgiOlsiZnVuY3Rpb25zIiwiMCIsImJvZHlfc291cmNlIl0sImZ1bmN0aW9uX25hbWUiOiJtZWFzdXJlIiwicGFyYW1zIjpbImZsYWciXSwiYXJpdHkiOjEsInRleHQiOiJyZXR1cm4oZmxhZy5jb3VudCgpLmFkZCgxKSkiLCJzb3VyY2Vfc3BhbiI6eyJzdGFydCI6MTgsImVuZCI6NDUsImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwicHJvdmVuYW5jZSI6W3sia2luZCI6InNvdXJjZV9zbGljZSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxOCwiZW5kIjo0NSwibGluZV9zdGFydCI6MSwibGluZV9lbmQiOjF9fV19LCJib2R5X3BhcnNlX2pvYiI6eyJraW5kIjoicGFyc2Vfam9iIiwidmVyc2lvbiI6MSwiam9iX2lkIjoicGFyc2Vfam9iOmZ1bmN0aW9uX2JvZHk6ZnVuY3Rpb25zLjAuYm9keV9zb3VyY2U6YWN0aW9uaXItYm9keS5zcGVjOmFjdGlvbl9ibG9jazoxOC00NSIsInBhcmVudF9hc3RfcGF0aCI6WyJmdW5jdGlvbnMiLCIwIiwiYm9keV9zb3VyY2UiXSwibm9kZV9raW5kIjoiZnVuY3Rpb25fZGVmaW5pdGlvbiIsInBheWxvYWRfa2luZCI6ImZ1bmN0aW9uX2JvZHkiLCJmdW5jdGlvbl9uYW1lIjoibWVhc3VyZSIsInBhcmFtcyI6WyJmbGFnIl0sImFyaXR5IjoxLCJ0ZXh0IjoicmV0dXJuKGZsYWcuY291bnQoKS5hZGQoMSkpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjE4LCJlbmQiOjQ1LCJsaW5lX3N0YXJ0IjoxLCJsaW5lX2VuZCI6MX0sInBhcnNlcl9zcGVjX2lkIjoiYWN0aW9uaXItYm9keS5zcGVjIiwidG9wX3J1bGUiOiJhY3Rpb25fYmxvY2siLCJyZXN1bHRfcG9saWN5IjoicmVwbGFjZV9maWVsZCIsInJlc3VsdF9maWVsZCI6ImJvZHlfYXN0IiwiZmFpbHVyZV9wb2xpY3kiOiJmYWlsIiwiZGlhZ25vc3RpY19vd25lciI6ImZ1bmN0aW9uX2JvZHkifSwiYm9keV9hc3QiOnsia2luZCI6ImFjdGlvbl9ibG9jayIsInNvdXJjZSI6InJldHVybihmbGFnLmNvdW50KCkuYWRkKDEpKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjowLCJlbmQiOjI3fSwic3RhdGVtZW50cyI6W3sia2luZCI6ImFjdGlvbl9zdG10Iiwic291cmNlIjoicmV0dXJuKGZsYWcuY291bnQoKS5hZGQoMSkpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6Mjd9LCJleHByIjp7ImtpbmQiOiJjYWxsIiwic291cmNlIjoicmV0dXJuKGZsYWcuY291bnQoKS5hZGQoMSkpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjAsImVuZCI6Mjd9LCJuYW1lIjoicmV0dXJuIiwic291cmNlX21ldGhvZCI6InJldHVybiIsImFyZ3MiOlt7ImtpbmQiOiJmbHVlbnRfY2hhaW4iLCJzb3VyY2UiOiJmbGFnLmNvdW50KCkuYWRkKDEpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MjZ9LCJyZWNlaXZlciI6eyJraW5kIjoidmFyaWFibGUiLCJzb3VyY2UiOiJmbGFnIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjcsImVuZCI6MTF9LCJuYW1lIjoiZmxhZyJ9LCJjYWxscyI6W3sibWV0aG9kIjoiY291bnQiLCJzb3VyY2VfbWV0aG9kIjoiY291bnQiLCJhcmdzIjpbXSwic291cmNlIjoiY291bnQoKSIsInNvdXJjZV9zcGFuIjp7InN0YXJ0IjoxMiwiZW5kIjoxOX19LHsibWV0aG9kIjoiYWRkIiwic291cmNlX21ldGhvZCI6ImFkZCIsImFyZ3MiOlt7ImtpbmQiOiJudW1iZXIiLCJzb3VyY2UiOiIxIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjI0LCJlbmQiOjI1fSwidmFsdWUiOjF9XSwic291cmNlIjoiYWRkKDEpIiwic291cmNlX3NwYW4iOnsic3RhcnQiOjIwLCJlbmQiOjI2fX1dfV19LCJkcm9wc192YWx1ZSI6dHJ1ZX1dfSwic291cmNlIjoiZm4gbWVhc3VyZShmbGFnKSB7cmV0dXJuKGZsYWcuY291bnQoKS5hZGQoMSkpfSIsInNvdXJjZV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfSwiYm9keV9zcGFuIjp7ImxpbmVfc3RhcnQiOjEsImxpbmVfZW5kIjoxfX1dLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge2l0ZW1zPVwiY2FsbGVyXCI7cmV0dXJuKFttZWFzdXJlKGZhbHNlKSxtZWFzdXJlKHRydWUpLGl0ZW1zXSl9IiwibGluZSI6Mn0sImJvZHkiOlt7ImtpbmQiOnsia2luZCI6ImNvZGVfYmxvY2siLCJsaWZlY3ljbGUiOiJJIiwiY29kZSI6Iml0ZW1zPVwiY2FsbGVyXCI7cmV0dXJuKFttZWFzdXJlKGZhbHNlKSxtZWFzdXJlKHRydWUpLGl0ZW1zXSkifSwic291cmNlIjoiSSB7aXRlbXM9XCJjYWxsZXJcIjtyZXR1cm4oW21lYXN1cmUoZmFsc2UpLG1lYXN1cmUodHJ1ZSksaXRlbXNdKX0iLCJsaW5lIjoyfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
