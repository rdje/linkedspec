// Generated LinkedSpec parser library.
// Contract id: linkedspec-generated-source-v2.
// Source format: linkedspec_dart source_emitter v2.
// Source identity: linkedspecGeneratedSourceIdentity.

import 'dart:convert';

import 'package:linkedspec_dart/linkedspec_dart.dart';
import 'package:linkedspec_dart/src/runtime/bounded_child_parse_authority.dart';
import 'package:linkedspec_dart/src/runtime/staged_ast_enrichment.dart';

const linkedspecGeneratedSourceContract =
    'linkedspec-generated-source-v2';
const linkedspecGeneratedSourceFormat = 2;
const linkedspecRegexSlotIdentityContract =
    'linkedspec-duplicate-regex-slot-identity-v1';
const linkedspecGeneratedSourceIdentity = "count-copy/produced_boolean_count_rejection.spec";
const _compiledSpecJsonBase64 = 'eyJzb3VyY2VfaWQiOiJjb3VudC1jb3B5L3Byb2R1Y2VkX2Jvb2xlYW5fY291bnRfcmVqZWN0aW9uLnNwZWMiLCJmdW5jdGlvbnMiOltdLCJydWxlcyI6W3siaGVhZGVyIjp7ImxhYmVsIjoiVmFsdWUiLCJpc190b3AiOnRydWUsIm1vZGUiOiJEZWZhdWx0IiwicmVzdCI6Ikkge29yZGVyPVwiXCI7b3V0PWFuZCh7b3JkZXI9Y2F0KG9yZGVyLFwiU1wiKTtmYWxzZX0pLmNvdW50KCkud2l0aCgpe29yZGVyPWNhdChvcmRlcixcIldcIik7cmV0dXJuKFwicmFuXCIpfTtyZXR1cm4oW291dCxvcmRlcixvcih0cnVlKS5jb3VudCgpLG5vdChmYWxzZSkuY291bnQoKV0pfSIsImxpbmUiOjF9LCJib2R5IjpbeyJraW5kIjp7ImtpbmQiOiJjb2RlX2Jsb2NrIiwibGlmZWN5Y2xlIjoiSSIsImNvZGUiOiJvcmRlcj1cIlwiO291dD1hbmQoe29yZGVyPWNhdChvcmRlcixcIlNcIik7ZmFsc2V9KS5jb3VudCgpLndpdGgoKXtvcmRlcj1jYXQob3JkZXIsXCJXXCIpO3JldHVybihcInJhblwiKX07cmV0dXJuKFtvdXQsb3JkZXIsb3IodHJ1ZSkuY291bnQoKSxub3QoZmFsc2UpLmNvdW50KCldKSJ9LCJzb3VyY2UiOiJJIHtvcmRlcj1cIlwiO291dD1hbmQoe29yZGVyPWNhdChvcmRlcixcIlNcIik7ZmFsc2V9KS5jb3VudCgpLndpdGgoKXtvcmRlcj1jYXQob3JkZXIsXCJXXCIpO3JldHVybihcInJhblwiKX07cmV0dXJuKFtvdXQsb3JkZXIsb3IodHJ1ZSkuY291bnQoKSxub3QoZmFsc2UpLmNvdW50KCldKX0iLCJsaW5lIjoxfV19XX0=';
const _generatedPlan = <GeneratedPlanRow>[
  GeneratedPlanRow(label: "Value", family: "default"),
];

GeneratedSourceMetadata metadata() {
  return const GeneratedSourceMetadata(
    sourceIdentity: linkedspecGeneratedSourceIdentity,
  );
}

CompiledSpec _loadCompiledSpec() {
  try {
    final decoded = jsonDecode(
      utf8.decode(base64Decode(_compiledSpecJsonBase64), allowMalformed: false),
    );
    if (decoded is! Map<String, Object?>) {
      throw const FormatException('generated spec payload must be an object');
    }
    return compileSpec(SpecFile.fromJson(decoded));
  } on GeneratedSourceException {
    rethrow;
  } on Object catch (error) {
    throw GeneratedSourceException.compileFailed(
      linkedspecGeneratedSourceIdentity,
      error,
    );
  }
}

final _compiledSpec = _loadCompiledSpec();

List<GeneratedPlanRow> plan() => _generatedPlan;

void validatePlan(List<GeneratedPlanRow> actual) {
  validatePlanForContract(actual, linkedspecGeneratedSourceContract);
}

void validatePlanForContract(
  List<GeneratedPlanRow> actual,
  String actualContract,
) {
  validateGeneratedSourceContractV2(
    actualContract,
    linkedspecGeneratedSourceIdentity,
  );
  validateGeneratedRulePlanV2(
    _compiledSpec,
    actual,
    linkedspecGeneratedSourceIdentity,
    actualContract: actualContract,
  );
}

Object? execute(
  String input, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
  ProgressiveExecutionSeed? boundedChildParseAuthority,
  StagedAstEnrichmentSeed? stagedAstEnrichmentSeed,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserV2(
    _compiledSpec,
    _generatedPlan,
    input,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
    boundedChildParseAuthority: boundedChildParseAuthority,
    stagedAstEnrichmentSeed: stagedAstEnrichmentSeed,
  );
}

Object? executeWithTrace(
  String input,
  LinkedSpecTraceConfig traceConfig, {
  String? topRule,
  RuntimeDiagnosticOutputSink? diagnosticOutputSink,
  RuntimeSemanticObservationSink? semanticObservationSink,
}) {
  validateGeneratedSourceContractV2(
    linkedspecGeneratedSourceContract,
    linkedspecGeneratedSourceIdentity,
  );
  return executeGeneratedParserWithTraceV2(
    _compiledSpec,
    _generatedPlan,
    input,
    traceConfig,
    linkedspecGeneratedSourceIdentity,
    topRule: topRule,
    actualContract: linkedspecGeneratedSourceContract,
    diagnosticOutputSink: diagnosticOutputSink,
    semanticObservationSink: semanticObservationSink,
  );
}
