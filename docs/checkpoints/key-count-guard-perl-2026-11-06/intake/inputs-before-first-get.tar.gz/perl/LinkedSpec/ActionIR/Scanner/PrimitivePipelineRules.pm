package LinkedSpec::ActionIR::Scanner::PrimitivePipelineRules;

use 5.010;
BEGIN {
 require File::Basename;
 my $module_dir = (File::Basename::fileparse(__FILE__))[1];
 my $action_ir_dir = File::Basename::dirname($module_dir);
 my $linked_spec_dir = File::Basename::dirname($action_ir_dir);
 my $perl_root = File::Basename::dirname($linked_spec_dir);
 unshift @INC, $perl_root unless grep { defined($_) && $_ eq $perl_root } @INC;
}
use LinkedSpec::ActionIR::ScannerCore ();
use LinkedSpec::OwnerDispatch ();

sub try_scan_contract_ir_events {
 my ($id, $code) = @_;
 my %dispatch = (
  'print_foreach_iterable' => \&_scan_contract_print_foreach_iterable,
  'split_trim_filter_assignment' => \&_scan_contract_split_trim_filter_assignment,
  'push' => \&_scan_contract_push,
  'set_value' => \&_scan_contract_set_value,
  'scalar_assignment_operator' => \&_scan_contract_scalar_assignment_operator,
  'array_append_operator' => \&_scan_contract_array_append_operator,
  'array_end_mutation_method' => \&_scan_contract_array_end_mutation_method,
  'hash_index_assignment_operator' => \&_scan_contract_hash_index_assignment_operator,
  'set_key_statement' => \&_scan_contract_set_key_statement,
  'regex_subst' => \&_scan_contract_regex_subst,
  'split_array' => \&_scan_contract_split_array,
  'split_each' => \&_scan_contract_split_each,
  'trim_each' => \&_scan_contract_trim_each,
  'filter_nonempty' => \&_scan_contract_filter_nonempty,
  'lowercase_each' => \&_scan_contract_lowercase_each,
  'uppercase_each' => \&_scan_contract_uppercase_each,
  'uniq_array' => \&_scan_contract_uniq_array,
  'filter_match' => \&_scan_contract_filter_match,
  'value_drop_statement' => \&_scan_contract_value_drop_statement,
 );
 my $handler = $dispatch{$id};
 return undef unless $handler;
 return $handler->($code)
}

sub _is_primitive_literal_token {
 my ($expr) = @_;
 my $trimmed = _trim_action_ir_value($expr);
 return 0 unless defined($trimmed) && length($trimmed);
 return 1 if $trimmed =~ /^-?\d+(?:\.\d+)?$/o;
 return 1 if $trimmed =~ /^\"(?:\\.|[^\"])*\"$/s || $trimmed =~ /^'(?:\\.|[^'])*'$/s;
 return 1 if $trimmed eq 'undef' || $trimmed eq 'true' || $trimmed eq 'false';
 return 0
}

sub _is_nonliteral_reserved_bare_token {
 my ($expr) = @_;
 my $trimmed = _trim_action_ir_value($expr);
 return 0 unless defined($trimmed) && length($trimmed);
 return 0 unless $trimmed =~ /^[A-Za-z_][A-Za-z0-9_]*$/o;
 return 0 if _is_primitive_literal_token($trimmed);
 return $trimmed =~ /^(?:descr|STRING|info|minfo|IMATCH|IMATCH_LIST|IMATCH_HASH|IINDEX|IPOS|LMATCH|LMATCH_LIST|LMATCH_HASH|LINDEX|LSPOS|CAPTURE)$/o ? 1 : 0
}

sub _scan_contract_print_foreach_iterable {
 my ($code) = @_;
 my @events;
 my $framed = ref($LinkedSpec::ActionIR::ScannerCore::_source_event_recorder) eq 'CODE'
  ? LinkedSpec::ActionIR::ScannerCore::_split_scanner_statements_with_source_frames(\&_split_action_ir_statements, $code)
  : undef;
 my $statements = $framed ? $framed->{statements} : _split_action_ir_statements($code);
 my $statement_index = 0;
foreach my $statement (@$statements) {
 my $frame = $framed ? $framed->{source_frames}[$statement_index++] : undef;
 my $trimmed = _trim_action_ir_value($statement);
 next unless defined($trimmed) && length($trimmed);
 next unless $trimmed =~ /^print\s+.+\s+foreach\s*\(\s*\@(?<iterable>\w+)\s*\)$/s;
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({raw => $trimmed, args => {iterable => $+{iterable}}}, $frame);
}
 return \@events
}

sub _scan_contract_split_trim_filter_assignment {
 my ($code) = @_;
 my @events;
 my $framed = ref($LinkedSpec::ActionIR::ScannerCore::_source_event_recorder) eq 'CODE'
  ? LinkedSpec::ActionIR::ScannerCore::_split_scanner_statements_with_source_frames(\&_split_action_ir_statements, $code)
  : undef;
 my $statements = $framed ? $framed->{statements} : _split_action_ir_statements($code);
 my $statement_index = 0;
foreach my $statement (@$statements) {
 my $frame = $framed ? $framed->{source_frames}[$statement_index++] : undef;
 my $trimmed = _trim_action_ir_value($statement);
 next unless defined($trimmed) && length($trimmed);
 next unless $trimmed =~ /^my\s+\@(?<target>\w+)\s*=\s*grep\s*\{\s*length\(\$_\)\s*\}\s*map\s*\{\s*my\s+\$v\s*=\s*\$_\s*;\s*\$v\s*=~\s*s\/(?:\\.|[^\/])*\/(?:\\.|[^\/])*\/[a-z]*\s*;\s*\$v\s*\}\s*split\s*(?<delimiter>\/(?:\\.|[^\/])*\/[a-z]*)\s*,\s*\$(?<source>\w+)$/o;
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({
  raw  => $trimmed,
  args => {
   target    => $+{target},
   source    => $+{source},
   delimiter => $+{delimiter},
   transforms => ['split', 'trim_each', 'filter_nonempty'],
   scope     => 'my',
  },
 }, $frame);
}
 return \@events
}

sub _scan_contract_push {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>push\s*(?<PAREN>\((?:[^\(\)\"\\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $call = _parse_method_function_expr($raw_expr);
 next unless $call && $call->{method} eq 'push';
 my $raw_args = $call->{args} || [];
 my $effective_args;
 if (@$raw_args == 2) {
  $effective_args = $raw_args;
 } elsif (@$raw_args == 3) {
  my $scoped_target_expr = _trim_action_ir_value($raw_args->[1]);
  next unless defined($scoped_target_expr)
           && $scoped_target_expr =~ /^(?:[A-Za-z_][A-Za-z0-9_]*|array\s*\(\s*[A-Za-z_][A-Za-z0-9_]*\s*\))$/o;
  $effective_args = [ $raw_args->[1], $raw_args->[2] ];
 } else {
  next;
 }
 my $first_expr = _trim_action_ir_value($effective_args->[0]);
 my $second_expr = _trim_action_ir_value($effective_args->[1]);
 next if defined($first_expr) && defined($second_expr)
      && $first_expr =~ /^\w+$/o && $second_expr =~ /^\w+$/o
      && !_is_primitive_literal_token($second_expr);
 next unless $effective_args;
 my $target_expr = _trim_action_ir_value($effective_args->[0]);
 my $value_expr = _trim_action_ir_value($effective_args->[1]);
 next unless defined($target_expr) && length($target_expr);
 next unless defined($value_expr) && length($value_expr);
 my ($target_symbol) = $target_expr =~ /^array\s*\(\s*(\w+)\s*\)$/o;
 if (!defined($target_symbol) && $target_expr =~ /^(\w+)$/o) {
  $target_symbol = $1;
 }
 next unless defined($target_symbol) && length($target_symbol);
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event(
  {raw => $raw_expr, args => {target => $target_symbol, value => $value_expr}},
  $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_set_value {
 my ($code) = @_;
 my @events;
 while ($code =~ /\b(?<expr>set\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
  my ($start, $end) = ($-[0], $+[0]);
  my $expr = $+{expr};
  my $call = _parse_method_function_expr($expr);
  next unless $call && $call->{method} eq 'set';
 my $effective_args = _normalize_method_args_with_optional_scope($call->{args} || [], 2, 2);
 next unless $effective_args;
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event({
  raw => $expr,
  args => {
   target => _trim_action_ir_value($effective_args->[0]),
   source => _trim_action_ir_value($effective_args->[1]),
  },
 }, $code, $start, $end);
}
 return \@events
}

sub _scan_contract_scalar_assignment_operator {
 my ($code) = @_;
 my @events;
 my $framed = ref($LinkedSpec::ActionIR::ScannerCore::_source_event_recorder) eq 'CODE'
  ? LinkedSpec::ActionIR::ScannerCore::_split_scanner_statements_with_source_frames(\&_split_action_ir_statements, $code)
  : undef;
 my $statements = $framed ? $framed->{statements} : _split_action_ir_statements($code);
 my $statement_index = 0;
foreach my $statement (@$statements) {
 my $frame = $framed ? $framed->{source_frames}[$statement_index++] : undef;
 my $trimmed = _trim_action_ir_value($statement);
 next unless defined($trimmed) && length($trimmed);
 next unless $trimmed =~ /^([A-Za-z_][A-Za-z0-9_]*)\s*=(?!=|>)\s*(.+)$/s;
 my ($target_expr, $source_expr) = ($1, _trim_action_ir_value($2));
 next unless defined($source_expr) && length($source_expr);
 next if $source_expr =~ /\A(?:observe_recognition|recognition_checkpoint|recognize_once|recognition_commit)\s*\(/o;
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({
  raw => $trimmed,
  args => {
   target => $target_expr,
   source => $source_expr,
  },
 }, $frame);
}
 return \@events
}

sub _scan_contract_array_append_operator {
 my ($code) = @_;
 my @events;
 my $framed = ref($LinkedSpec::ActionIR::ScannerCore::_source_event_recorder) eq 'CODE'
  ? LinkedSpec::ActionIR::ScannerCore::_split_scanner_statements_with_source_frames(\&_split_action_ir_statements, $code)
  : undef;
 my $statements = $framed ? $framed->{statements} : _split_action_ir_statements($code);
 my $statement_index = 0;
foreach my $statement (@$statements) {
 my $frame = $framed ? $framed->{source_frames}[$statement_index++] : undef;
 my $trimmed = _trim_action_ir_value($statement);
 next unless defined($trimmed) && length($trimmed);
 next unless $trimmed =~ /^([A-Za-z_][A-Za-z0-9_]*)\s*\+=\s*(.+)$/s;
 my ($target_expr, $value_expr) = ($1, _trim_action_ir_value($2));
 next unless defined($value_expr) && length($value_expr);
 next if _is_nonliteral_reserved_bare_token($value_expr);
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({
  raw => $trimmed,
  args => {
   target => $target_expr,
   value  => $value_expr,
  },
 }, $frame);
}
 return \@events
}

sub _parse_array_end_mutation_method_statement {
 my ($statement) = @_;
 my $trimmed = _trim_action_ir_value($statement);
 return undef unless defined($trimmed) && length($trimmed);

 my ($paren_depth, $bracket_depth, $brace_depth) = (0, 0, 0);
 my ($in_single_quote, $in_double_quote, $escape_next) = (0, 0, 0);
 my ($receiver_expr, $call_expr);
 my $len = length($trimmed);
 for (my $idx = 0; $idx < $len; ++$idx) {
  my $ch = substr($trimmed, $idx, 1);
  if ($in_single_quote) {
   if ($escape_next) { $escape_next = 0; }
   elsif ($ch eq '\\') { $escape_next = 1; }
   elsif ($ch eq "'") { $in_single_quote = 0; }
   next;
  }
  if ($in_double_quote) {
   if ($escape_next) { $escape_next = 0; }
   elsif ($ch eq '\\') { $escape_next = 1; }
   elsif ($ch eq '"') { $in_double_quote = 0; }
   next;
  }
  if ($ch eq "'") { $in_single_quote = 1; next; }
  if ($ch eq '"') { $in_double_quote = 1; next; }
  if ($ch eq '(') { ++$paren_depth; next; }
  if ($ch eq ')') { --$paren_depth if $paren_depth > 0; next; }
  if ($ch eq '[') { ++$bracket_depth; next; }
  if ($ch eq ']') { --$bracket_depth if $bracket_depth > 0; next; }
  if ($ch eq '{') { ++$brace_depth; next; }
  if ($ch eq '}') { --$brace_depth if $brace_depth > 0; next; }
  next unless $ch eq '.';
  next unless $paren_depth == 0 && $bracket_depth == 0 && $brace_depth == 0;
  $receiver_expr = _trim_action_ir_value(substr($trimmed, 0, $idx));
  $call_expr = _trim_action_ir_value(substr($trimmed, $idx + 1));
  last;
 }
 return undef unless defined($receiver_expr) && length($receiver_expr);
 return undef unless defined($call_expr) && length($call_expr);
 return undef unless $receiver_expr =~ /^(?:[A-Za-z_][A-Za-z0-9_]*|array\s*\()/o;

 my ($target_symbol) = defined($receiver_expr)
  ? ($receiver_expr =~ /^array\s*\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)$/o)
  : ();
 if (!defined($target_symbol) && defined($receiver_expr) && $receiver_expr =~ /^([A-Za-z_][A-Za-z0-9_]*)$/o) {
  $target_symbol = $1;
 }
 return undef unless defined($target_symbol) && length($target_symbol);

 my $call = _parse_method_function_expr($call_expr);
 return undef unless $call && ($call->{method} // '') =~ /^(?:push_front|push_back|pop_front|pop_back)$/o;
 my $args = $call->{args} || [];
 return undef if $call->{method} =~ /^push_/o && @$args != 1;
 return undef if $call->{method} =~ /^pop_/o && @$args != 0;
 my $value_expr;
 if ($call->{method} =~ /^push_/o) {
  $value_expr = _trim_action_ir_value($args->[0]);
  return undef unless defined($value_expr) && length($value_expr);
  return undef if _is_nonliteral_reserved_bare_token($value_expr);
 }

 return {
  target => $target_symbol,
  method => $call->{method},
  value  => $value_expr,
 };
}

sub _scan_contract_array_end_mutation_method {
 my ($code) = @_;
 my @events;
 my $framed = ref($LinkedSpec::ActionIR::ScannerCore::_source_event_recorder) eq 'CODE'
  ? LinkedSpec::ActionIR::ScannerCore::_split_scanner_statements_with_source_frames(\&_split_action_ir_statements, $code)
  : undef;
 my $statements = $framed ? $framed->{statements} : _split_action_ir_statements($code);
 my $statement_index = 0;
 foreach my $statement (@$statements) {
  my $frame = $framed ? $framed->{source_frames}[$statement_index++] : undef;
  my $trimmed = _trim_action_ir_value($statement);
  next unless defined($trimmed) && length($trimmed);
  my $parsed = _parse_array_end_mutation_method_statement($trimmed);
  next unless $parsed;
  my %args = (
   target => $parsed->{target},
   method => $parsed->{method},
  );
  $args{value} = $parsed->{value} if defined $parsed->{value};
  push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({raw => $trimmed, args => \%args}, $frame);
 }
 return \@events
}

sub _parse_hash_index_assignment_operator_statement {
 my ($statement) = @_;
 my $trimmed = _trim_action_ir_value($statement);
 return undef unless defined($trimmed) && length($trimmed);
 return undef unless $trimmed =~ /\G([A-Za-z_][A-Za-z0-9_]*)/gc;
 my $target = $1;
 $trimmed =~ /\G\s*/gc;
 return undef unless substr($trimmed, pos($trimmed) || 0, 1) eq '[';
 pos($trimmed) = (pos($trimmed) || 0) + 1;

 my $key = '';
 my @stack = (']');
 my ($in_single_quote, $in_double_quote, $escape_next) = (0, 0, 0);
 while ((pos($trimmed) || 0) < length($trimmed) && @stack) {
  my $idx = pos($trimmed) || 0;
  my $ch = substr($trimmed, $idx, 1);
  pos($trimmed) = $idx + 1;

  if ($in_single_quote) {
   $key .= $ch;
   if ($escape_next) { $escape_next = 0 }
   elsif ($ch eq '\\') { $escape_next = 1 }
   elsif ($ch eq "'") { $in_single_quote = 0 }
   next;
  }
  if ($in_double_quote) {
   $key .= $ch;
   if ($escape_next) { $escape_next = 0 }
   elsif ($ch eq '\\') { $escape_next = 1 }
   elsif ($ch eq '"') { $in_double_quote = 0 }
   next;
  }
  if ($ch eq "'") {
   $in_single_quote = 1;
   $key .= $ch;
   next;
  }
  if ($ch eq '"') {
   $in_double_quote = 1;
   $key .= $ch;
   next;
  }
  if ($ch eq '(') { push @stack, ')'; $key .= $ch; next; }
  if ($ch eq '[') { push @stack, ']'; $key .= $ch; next; }
  if ($ch eq '{') { push @stack, '}'; $key .= $ch; next; }
  if ($ch eq $stack[-1]) {
   if (@stack == 1) {
    pop @stack;
    last;
   }
   pop @stack;
   $key .= $ch;
   next;
  }
  $key .= $ch;
 }
 return undef if @stack;

 my $after_idx = pos($trimmed) || 0;
 my $after = substr($trimmed, $after_idx);
 return undef unless $after =~ /^\s*=(?!=|>)\s*(.+)$/s;
 my $value = _trim_action_ir_value($1);
 $key = _trim_action_ir_value($key);
 return undef unless defined($key) && length($key);
 return undef unless defined($value) && length($value);
 return undef if _is_nonliteral_reserved_bare_token($value);
 return {
  target => $target,
  key    => $key,
  value  => $value,
 };
}

sub _scan_contract_hash_index_assignment_operator {
 my ($code) = @_;
 my @events;
 my $framed = ref($LinkedSpec::ActionIR::ScannerCore::_source_event_recorder) eq 'CODE'
  ? LinkedSpec::ActionIR::ScannerCore::_split_scanner_statements_with_source_frames(\&_split_action_ir_statements, $code)
  : undef;
 my $statements = $framed ? $framed->{statements} : _split_action_ir_statements($code);
 my $statement_index = 0;
foreach my $statement (@$statements) {
 my $frame = $framed ? $framed->{source_frames}[$statement_index++] : undef;
 my $trimmed = _trim_action_ir_value($statement);
 next unless defined($trimmed) && length($trimmed);
 my $parsed = _parse_hash_index_assignment_operator_statement($trimmed);
 if ($parsed) {
  push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({
   raw => $trimmed,
   args => {
    target => $parsed->{target},
    key    => $parsed->{key},
    value  => $parsed->{value},
   },
  }, $frame);
  next;
 }
 my $node;
 eval {
  require LinkedSpec::ActionIR::AST;
  $node = LinkedSpec::ActionIR::AST::parse_action_expr($trimmed, {});
  1;
 } or next;
 next unless ref($node) eq 'HASH' && ($node->{kind} // '') eq 'assign_nested_access';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({
  raw => $trimmed,
  args => {
   target => $node->{base},
   path_segment_count => scalar(@{$node->{segments} || []}),
   value => ref($node->{value}) eq 'HASH' ? ($node->{value}{source} // '') : '',
  },
 }, $frame);
}
 return \@events
}

sub _scan_contract_set_key_statement {
 my ($code) = @_;
 my @events;
 my $framed = ref($LinkedSpec::ActionIR::ScannerCore::_source_event_recorder) eq 'CODE'
  ? LinkedSpec::ActionIR::ScannerCore::_split_scanner_statements_with_source_frames(\&_split_action_ir_statements, $code)
  : undef;
 my $statements = $framed ? $framed->{statements} : _split_action_ir_statements($code);
 my $statement_index = 0;
foreach my $statement (@$statements) {
 my $frame = $framed ? $framed->{source_frames}[$statement_index++] : undef;
 my $trimmed = _trim_action_ir_value($statement);
 next unless defined($trimmed) && length($trimmed);
 my $call = _parse_method_function_expr($trimmed);
 next unless $call && $call->{method} eq 'set_key';
 my $effective_args = _normalize_method_args_with_optional_scope($call->{args} || [], 3, 3);
 next unless $effective_args;
 my $target_expr = _trim_action_ir_value($effective_args->[0]);
 my $key_expr = _trim_action_ir_value($effective_args->[1]);
 my $value_expr = _trim_action_ir_value($effective_args->[2]);
 next unless defined($target_expr) && length($target_expr);
 my ($target_symbol) = $target_expr =~ /^hash\s*\(\s*(\w+)\s*\)$/o;
 if (!defined($target_symbol) && $target_expr =~ /^(\w+)$/o) {
  $target_symbol = $1;
 }
 next unless defined($target_symbol) && length($target_symbol);
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({
  raw => $trimmed,
  args => {
   target => $target_symbol,
   key    => $key_expr,
   value  => $value_expr,
  },
 }, $frame);
}
 return \@events
}

sub _scan_contract_regex_subst {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?:substr|regex_subst)\s*\(\s*(?:(?<scope>\w+)\s*,\s*)?(?<target>:\w+|\w+)\s*,\s*(?<pattern>(?:\"(?:\\.|[^\"])*\"|'(?:\\.|[^'])*'|\/(?:\\.|[^\/])*\/))\s*,\s*(?<replacement>(?:\"(?:\\.|[^\"])*\"|'(?:\\.|[^'])*'|\/\/|\/(?:\\.|[^\/])*\/))\s*,\s*(?<flags>\w*)\s*\)/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event({
  raw => $&,
  args => {
   scope => $+{scope}, target => $+{target}, pattern => $+{pattern},
   replacement => $+{replacement}, flags => $+{flags},
  },
 }, $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_split_array {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>split\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $pipeline = _build_array_pipeline_plan_from_expr($raw_expr);
 next unless $pipeline && @{$pipeline->{ops} || []};
 my $last_op = $pipeline->{ops}[-1];
 next unless $last_op->{op} && $last_op->{op} eq 'split';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event({
  raw => $raw_expr,
  args => {
   target    => $pipeline->{target_symbol},
   source    => $last_op->{source_expr} // $last_op->{source_symbol},
   delimiter => $last_op->{delimiter_expr},
  },
 }, $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_split_each {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>split_each\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $pipeline = _build_array_pipeline_plan_from_expr($raw_expr);
 next unless $pipeline && @{$pipeline->{ops} || []};
 my $last_op = $pipeline->{ops}[-1];
 next unless $last_op->{op} && $last_op->{op} eq 'split_each';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event({
  raw => $raw_expr,
  args => {
   target    => $pipeline->{target_symbol},
   delimiter => $last_op->{delimiter_expr},
  },
 }, $code, $source_start, $source_end);
}
 return \@events
}
sub _scan_contract_trim_each {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>trim_each\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $pipeline = _build_array_pipeline_plan_from_expr($raw_expr);
 next unless $pipeline && @{$pipeline->{ops} || []};
 my $last_op = $pipeline->{ops}[-1];
 next unless $last_op->{op} && $last_op->{op} eq 'trim_each';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event(
  {raw => $raw_expr, args => {target => $pipeline->{target_symbol}}},
  $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_filter_nonempty {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>filter_nonempty\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $pipeline = _build_array_pipeline_plan_from_expr($raw_expr);
 next unless $pipeline && @{$pipeline->{ops} || []};
 my $last_op = $pipeline->{ops}[-1];
 next unless $last_op->{op} && $last_op->{op} eq 'filter_nonempty';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event(
  {raw => $raw_expr, args => {target => $pipeline->{target_symbol}}},
  $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_lowercase_each {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>lowercase_each\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $pipeline = _build_array_pipeline_plan_from_expr($raw_expr);
 next unless $pipeline && @{$pipeline->{ops} || []};
 my $last_op = $pipeline->{ops}[-1];
 next unless $last_op->{op} && $last_op->{op} eq 'lowercase_each';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event(
  {raw => $raw_expr, args => {target => $pipeline->{target_symbol}}},
  $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_uppercase_each {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>uppercase_each\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $pipeline = _build_array_pipeline_plan_from_expr($raw_expr);
 next unless $pipeline && @{$pipeline->{ops} || []};
 my $last_op = $pipeline->{ops}[-1];
 next unless $last_op->{op} && $last_op->{op} eq 'uppercase_each';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event(
  {raw => $raw_expr, args => {target => $pipeline->{target_symbol}}},
  $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_uniq_array {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>uniq\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $pipeline = _build_array_pipeline_plan_from_expr($raw_expr);
 next unless $pipeline && @{$pipeline->{ops} || []};
 my $last_op = $pipeline->{ops}[-1];
 next unless $last_op->{op} && $last_op->{op} eq 'uniq';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event(
  {raw => $raw_expr, args => {target => $pipeline->{target_symbol}}},
  $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_filter_match {
 my ($code) = @_;
 my @events;
while ($code =~ /\b(?<expr>filter_match\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\)))/g) {
 my ($source_start, $source_end) = ($-[0], $+[0]);
 my $raw_expr = $+{expr};
 my $pipeline = _build_array_pipeline_plan_from_expr($raw_expr);
 next unless $pipeline && @{$pipeline->{ops} || []};
 my $last_op = $pipeline->{ops}[-1];
 next unless $last_op->{op} && $last_op->{op} eq 'filter_match';
 push @events, LinkedSpec::ActionIR::ScannerCore::_record_scanned_source_event({
  raw => $raw_expr,
  args => {
   target  => $pipeline->{target_symbol},
   pattern => $last_op->{pattern_expr},
  },
 }, $code, $source_start, $source_end);
}
 return \@events
}

sub _scan_contract_value_drop_statement {
 my ($code) = @_;
 my @events;
 my $mark_statement_re = LinkedSpec::OwnerDispatch::dispatch_owner_call(
  __PACKAGE__, 'LinkedSpec::ActionIR::Contracts', '_named_mark_statement_method_re');
 my $value_call_re = qr/(?:s|a|h|trim|lowercase|uppercase|length|substr|replace_substr|rm_prefix|rm_suffix|cat|str_eq|str_ne|str_gt|str_ge|str_lt|str_le|starts_with|ends_with|contains_substr|matches|coalesce|coalesce_nonempty|num_abs|num_floor|num_ceil|num_round|num_add|num_sub|num_mul|num_div|num_mod|num_clamp|num_min|num_max|num_eq|num_ne|num_gt|num_ge|num_lt|num_le|abs|floor|ceil|round|sum|avg|median|range|add|sub|mul|div|mod|clamp|min|max|eq|ne|gt|ge|lt|le|array|hash|copy|flat|flat_array|flat_hash|count|first|last|drop_front|take|slice|take_last|drop_back|concat_arrays|split|split_tagged_records|sorted|reversed|contains|index_of|split_each|trim_each|filter_nonempty|lowercase_each|uppercase_each|uniq|filter_match|count_keys|sorted_keys|sorted_values|has_key|merge_hash|rename_key|drop_keys|pick_keys|join_values|entry_named|entry_has|match_named|match_has|entry_groups|match_groups|entry_map|entry_named_map|match_map|match_named_map|num_sum|num_avg|num_median|num_range)/;
 my $receiver_method_re = qr/(?:trim|lowercase|uppercase|length|sorted|reversed|count|first|last|is_empty|is_nonempty|flat_hash|count_keys|sorted_keys|sorted_values|abs|floor|ceil|round)/;
 my $literal_receiver_re = qr/(?:"(?:\\.|[^\"])*"|'(?:\\.|[^'])*'|-?\d+(?:\.\d+)?|[A-Za-z_][A-Za-z0-9_]*(?!\s*\())/;
 my $framed = ref($LinkedSpec::ActionIR::ScannerCore::_source_event_recorder) eq 'CODE'
  ? LinkedSpec::ActionIR::ScannerCore::_split_scanner_statements_with_source_frames(\&_split_action_ir_statements, $code)
  : undef;
 my $statements = $framed ? $framed->{statements} : _split_action_ir_statements($code);
 my $statement_index = 0;
 foreach my $statement (@$statements) {
  my $frame = $framed ? $framed->{source_frames}[$statement_index++] : undef;
  my $trimmed = _trim_action_ir_value($statement);
  next unless defined($trimmed) && length($trimmed);
  if ($trimmed =~ /^(?:$value_call_re|$mark_statement_re)\s*(?<PAREN>\((?:[^\(\)\"\']++|\"(?:\\.|[^\"])*\"|\'(?:\\.|[^\'])*\'|(?&PAREN))*\))\z/so) {
   push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({raw => $trimmed, args => {expr => $trimmed}}, $frame);
   next;
  }
  if ($trimmed =~ /^(?:$literal_receiver_re)\s*\.\s*(?:$receiver_method_re)\s*\(\s*\)\z/so) {
   push @events, LinkedSpec::ActionIR::ScannerCore::_record_statement_source_event({raw => $trimmed, args => {expr => $trimmed}}, $frame);
  }
 }
 return \@events
}

1;
