---
id: dart-core-spec-parser
title: Dart core spec parser produces source ASTs for rule paragraphs
answers:
  - does Dart parse spec files yet
  - where is the Dart spec parser
  - what does parseSpec support
  - does Dart parse shipped specs
  - does Dart parse corpus input specs
  - are Dart function definitions parsed yet
  - what is the Dart parser validation boundary
  - does Dart validation exist after parsing
date: 2026-07-09
status: current
tags: [dart, parser, ast, corpus, shipped-specs]
evidence: "DART-BACKEND-PARITY.2.2 adds dart/lib/src/parser/spec_parser.dart and dart/test/spec_parser_test.dart. Tests cover focused Rust-compatible parser seams, all checked-in specs/*.spec files, and corpus input.spec files that do not start with top-level fn definitions. DART-BACKEND-PARITY.2.3 adds validateSpec(...) as the next source-AST validation layer. DART-BACKEND-PARITY.2.4 keeps parseSpec(...) rule-only while adding a separate spec-returned function-definition projection path."
reverify: "cd dart && bash ../tools/run_dart_project_data.sh test test/spec_parser_test[.]dart test/spec_validator_test.dart && bash ../tools/run_dart_project_data.sh analyze --fatal-infos --fatal-warnings"
---

Dart `parseSpec(...)` lives in `dart/lib/src/parser/spec_parser.dart` and is
exported from `dart/lib/linkedspec_dart.dart`. It parses core `.spec` rule
paragraphs into the source AST types from `dart/lib/src/ast/spec_ast.dart`.

Supported parser shapes include rule headers, rule modes, header-rest body
elements, regex literals, lifecycle blocks, action and blind-call edges,
action-edge fluent continuations, receiver-fluent `when/otherwise` blocks,
split/conditional markers, comments, raw fallback lines, and nested block
boundaries.

The parser deliberately mirrors the Rust core parser boundary: it is permissive
source parsing, with `validateSpec(...)` providing the next validation layer.
It still does not raw-scan top-level `fn name(args) { ... }` definitions from
source. Dart function definitions now enter through the separate
`parseSpecWithUserFunctionDefinitionAsts(...)` projection path, which consumes
the node shape returned by `specs/user_function_definition.spec`.

Related facts: [[dart-frontend-ast-json-contract]], [[dart-backend-scaffold-package]],
[[dart-frontend-validation]], [[dart-function-definition-shell-projection]],
[[text-to-ast-backend-doctrine]].

## 2026-09-09 — body collection reading and unsupported-suffix qualification

`DART-STARTUP-READING.1.11` reads source lines 1-744: line/header/mode parsing, body collection,
fluent continuation, inline/body loops and element selection through the split prefix.
Permissive parsing can only defer validation for source retained in the AST. Fourteen direct
controls confirm that regex and lifecycle-E suffixes can instead disappear: both header and
body variants of `@unexpected` compile, while own-line/I/edge variants retain Raw and reject.
[[dart-body-suffix-omission]] owns exact source locations, replay and gated repair .2.6.
This qualifies the older general validation-boundary description without claiming a source fix.

Sixteen existing spec-parser/strict-stdio tests pass at this checkpoint. The current focused
parser-only command is
`cd dart && bash ../tools/run_dart_project_data.sh test test/spec_parser_test.dart`.
The remaining spec-parser source begins at line 745; its broad later mechanisms are not newly
credited by this range.

## 2026-09-09 — remaining source reading and lexical boundaries

`DART-STARTUP-READING.1.12` completes lines 745-1567 through EOF. It covers bare/action/blind
target parsing, typed action selectors versus numeric blind/bare indexes, legal edge remainders,
block/when-otherwise collection and origin tracking, compact fluent completeness/extraction,
and quote/regex lexical helpers. Seventeen existing parser/staged-registry tests pass.

Ten source/AST/compiler/native controls expose two independent lexical boundaries:
quoted parentheses corrupt compact fluent extraction, while regex closing braces truncate outer
lifecycle collection. Six positive controls retain their values. Exact reproduction and the
new .2.7/existing .2.2.2 repair ownership live in [[dart-spec-lexical-boundary-defects]].
This completes physical spec-parser reading without repairing these or the earlier suffix gap.

## September 11 parser and validator consumer reading complete

Dart .1.50 reads spec_parser_test.dart1-256 and spec_validator_test.dart1-244.
The shipped-file loops parse and validate their sources. Corpus loops skip any
source whose first significant line starts fn and require more than80 parsed
rule files; those loops do not establish complete runtime corpus execution.
Focused cases retain raw fallback, mode/edge/lifecycle/fluent shapes, target/slot
validation, strict unused-rule policy and function registry collision/parameter
checks. The two AST tests also preserve detached JSON field/mode structure.
All54 selected tests pass; prior suffix omission, quoted-parenthesis and regex-brace
defects remain separately owned. This reading changes no frontend behavior.
