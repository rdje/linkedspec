---
id: dart-shipped-corpus-smoke-split
title: Dart shipped-spec parser-smoke corpus window is split by failure cluster
answers:
  - "what does DART-BACKEND-PARITY.6.2.4.0 prove"
  - "why is the Dart shipped corpus smoke batch split"
  - "which Dart shipped-spec corpus failures are known"
  - "what is the next Dart corpus frontier after the middle batch"
  - "what split follows DART-BACKEND-PARITY.6.2.4.3"
  - "what is the Dart shipped-spec parser-smoke boundary after hlink parity"
  - "what is the Dart shipped-spec parser-smoke boundary after helper mutation parity"
  - "what is the Dart shipped-spec parser-smoke boundary after regdef parity"
  - "what is the next Dart shipped-spec parser-smoke boundary after ds_vhistory split"
  - "what is the Dart shipped-spec parser-smoke boundary after ds_vhistory parity"
  - "what is the Dart shipped-spec parser-smoke frontier after no-drift closeout"
  - "what is the Dart shipped-spec parser-smoke boundary after structural PCRE parity"
  - "what is the next Dart corpus frontier after shipped-spec parser-smoke closes"
date: 2026-07-09
status: current
tags: [dart, corpus, shipped-specs, regex, DART-BACKEND-PARITY]
evidence: "DART-BACKEND-PARITY.6.2.4.0 runs `dart run bin/corpus_runner.dart --corpus ../rust/linkedspec-runtime/tests/corpus --execute --offset 68 --limit 31`. The window started 2/31 green (`pplugin_empty`, `tkgui_empty`). Failures clustered into Dart regex-dialect incompatibilities, missing helper/action surfaces, recursive/default-mode output mismatches, and residual shipped-spec smoke parity. DART-BACKEND-PARITY.6.2.4.1 closes the basic regex-dialect bridge; .6.2.4.2 closes the missing helper/action bridge; .6.2.4.3 closes tclite/default-mode action-edge dispatch and recursive rule-local aggregate reset semantics. .6.2.4.4.0 splits remaining non-PCRE parser-smoke work. .6.2.4.4.1 closes the portmap/action-edge child result shape leaf through Dart `array(flat*)` list-context splicing, and `vhdl_library_use` also passes. .6.2.4.4.2 closes hlink delimiter/capture parity through `retv` refresh and scalar-held array append, and `tablegrep_simple_term` also passes. .6.2.4.4.3 closes helper mutation/text-normalization parity through statement-form scalar regex mutation, explicit split target replacement, and entry/local line helpers; `simenv_multiline_value`, `lib_reader_sattribute`, and `lib_reader_cattribute` pass. .6.2.4.4.4 closes `regdef_nested_register_fields` through the `push(Child)` current-accumulator convention. .6.2.4.4.5 splits `ds_vhistory_version_entry` with public-parser, descriptor-handler, scalar-held indexed-read, and leading-newline evidence rather than weakening Dart direct access. .6.2.4.4.6 closes that boundary by mirroring Perl's public-parser leading blank/comment-line skip in Dart. .6.2.4.5 closes final parser-smoke no-drift for the non-PCRE residual group. .6.2.4.6 closes the seven structural PCRE fixtures with bounded Dart matchers and action-edge `push(child, index)` parity. The window is now 31/31 green, `.6.2.4` is closed, `.6.2.5` closes the routed top-level fn corpus fixtures, `.6.3` closes the full Dart corpus gate at 99/99, and `.6.4` wires the green Dart corpus gate into focused local verification."
reverify: "cd dart && bash ../tools/run_dart_project_data.sh run bin/corpus_runner.dart --corpus ../rust/linkedspec-runtime/tests/corpus --execute --offset 68 --limit 31"
---

`DART-BACKEND-PARITY.6.2.4.0` is a planning split, not a runtime fix.

The owned final corpus window starts at manifest offset 68 and has 31 fixtures:
the tclite, Lispish, recursive top-rule, hlink, portmap, EBNF, spec.spec,
regdef, tablegrep, simenv, VHDL/library, history, plugin, and library smoke
fixtures.

The first diagnostic run is useful because it separates early blockers:

- Regex dialect translation blocks many shipped-spec smokes before Dart can
  measure runtime semantics.
- Missing helper/action surfaces block hlink, tablegrep, and simenv style
  fixtures.
- Tclite, Lispish, and recursive top-rule cases need a separate
  recursion/output-semantics pass.
- Residual shipped-spec output parity should wait until those lower blockers
  are removed.

`DART-BACKEND-PARITY.6.2.4.1` closes the basic regex-dialect bridge,
`DART-BACKEND-PARITY.6.2.4.2` closes the missing helper/action bridge, and
`DART-BACKEND-PARITY.6.2.4.3` closes the tclite/default-mode and recursive
top-rule value gap. `DART-BACKEND-PARITY.6.2.4.4.1` closes the portmap result
shape gap by adding Dart list-context splicing for explicit `flat*` calls inside
`array(...)`; `vhdl_library_use` also passes from the same fix. The diagnostic
window is then 13/31 green. `DART-BACKEND-PARITY.6.2.4.4.2` closes hlink
delimiter/capture parity through Dart `retv` refresh and scalar-held array
append behavior; `tablegrep_simple_term` also passes from the same append fix.
`DART-BACKEND-PARITY.6.2.4.4.3` closes helper mutation/text-normalization
parity through statement-form scalar regex mutation, explicit split target
replacement, and entry/local line helpers; `simenv_multiline_value`,
`lib_reader_sattribute`, and `lib_reader_cattribute` pass. The diagnostic
window is then 22/31 green. `DART-BACKEND-PARITY.6.2.4.4.4` closes
`regdef_nested_register_fields` by restoring the `push(Child)` current-rule
accumulator convention. `DART-BACKEND-PARITY.6.2.4.4.5` then splits
`ds_vhistory_version_entry` with public-parser, descriptor-handler,
scalar-held indexed-read, and leading-newline evidence. `DART-BACKEND-PARITY.6.2.4.4.6`
then closes the boundary by mirroring Perl's public-parser leading
blank/comment-line skip before the top rule, so `ds_vhistory_version_entry`
passes. The diagnostic window is now 24/31 green. Remaining regex
`FormatException` cases are deeper PCRE structural features and are routed to
`DART-BACKEND-PARITY.6.2.4.6`. `DART-BACKEND-PARITY.6.2.4.5` closes final
parser-smoke no-drift for the non-PCRE residual group; the next implementation
leaf is `.6.2.4.6`. `DART-BACKEND-PARITY.6.2.4.6` then closes those seven
structural PCRE fixtures with bounded matchers and action-edge
`push(child, index)` parity. The diagnostic window is now 31/31 green.
`DART-BACKEND-PARITY.6.2.5` then closes routed top-level `fn` corpus fixtures,
and `DART-BACKEND-PARITY.6.3` closes the full checked-in Dart corpus gate at
99/99. `DART-BACKEND-PARITY.6.4` then wires the green Dart corpus gate into the
focused local verification path.

Related facts: [[dart-middle-corpus-batch]], [[dart-controlled-corpus-execution]],
[[dart-regex-dialect-bridge]], [[dart-helper-action-surface-bridge]],
[[dart-recursive-dispatch-rule-local-scope]], [[dart-residual-parser-smoke-split]],
[[dart-array-flat-list-context-splice]], [[dart-hlink-scalar-held-array-append]],
[[dart-statement-helper-mutation-parity]], [[dart-legacy-structural-accumulator-parity]],
[[ds-vhistory-leading-newline-oracle-boundary]], [[dart-structural-pcre-parser-smoke-parity]],
[[rust-perl-output-oracle]].
