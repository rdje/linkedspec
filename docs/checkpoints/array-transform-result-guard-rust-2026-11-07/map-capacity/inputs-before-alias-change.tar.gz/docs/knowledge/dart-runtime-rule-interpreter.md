---
id: dart-runtime-rule-interpreter
title: Dart runtime rule interpreter executes compiled rules through dispatch, lifecycle, returns, retv, and accumulators
answers:
  - where is the Dart runtime interpreter
  - does Dart execute compiled rules yet
  - does Dart support action-edge dispatch
  - does Dart support blind-call dispatch
  - does Dart run lifecycle blocks
  - does Dart support retv and accumulators
  - does Dart guard recursion and zero-progress repetition
date: 2026-07-09
status: current
tags: [dart, runtime, interpreter, dispatch, lifecycle, DART-BACKEND-PARITY]
evidence: "DART-BACKEND-PARITY.4.2 adds dart/lib/src/runtime/interpreter.dart and exports LinkedSpecRuntimeEngine, RuntimeParseResult, RuntimeLifecycleEvent, and RuntimeInterpreterException. test/runtime_interpreter_test.dart covers regex repetition, action-edge fluent .push, blind AND/OR dispatch, bounded repetition, zero-progress cutoff, and lifecycle order."
reverify: "cd dart && bash ../tools/run_dart_project_data.sh test test/runtime_interpreter_test.dart && bash ../tools/run_dart_project_data.sh analyze --fatal-infos --fatal-warnings"
---

Dart runtime rule execution lives in `dart/lib/src/runtime/interpreter.dart`.

`LinkedSpecRuntimeEngine` consumes `CompiledSpec` and the `.4.1` match-state
primitives to execute compiled rules. It returns `RuntimeParseResult`, which
records the top rule value, Rust-style one-element output wrapper, cursor
offsets, match success, and lifecycle events.

The first interpreter layer covers default, AND, OR, and repetition rule
families; action-edge and blind-call child dispatch; entry/local match handoff;
explicit `return(...)` and `return_undef()`; `retv`; accumulator collection;
bounded repetition; zero-progress cutoffs; and recursion cutoffs.

The `.4.2` embedded ActionIR evaluator was deliberately narrow and
dispatch-facing. `DART-BACKEND-PARITY.4.3.1` through `.4.3.5` later extended it
with core value/store behavior, capture readers, string/number helpers, array
helpers, hash helpers, value blocks, structured controls, with-blocks, and tree
traversal callbacks.

Related facts: [[dart-runtime-matching-state]], [[dart-compiled-spec-state]],
[[dart-rule-local-cursor-execution]],
[[dart-runtime-core-value-capture-helpers]], [[dart-runtime-value-control-tree-helpers]],
[[dart-backend-interpreter-first-plan]].

## 2026-09-09 — interpreter entry and generated plan reading

`DART-STARTUP-READING.1.15` reads interpreter lines 1-674 plus all 68 generated-plan lines.
The ten generated families derive seek/consume and blind dispatch from the validated family;
ordered plan rows retain only label/family and value equality. Existing cursor authority
remains [[dart-rule-local-cursor-execution]].

Runtime entry validates compiled regex-slot and serialized mutation state, resolves the
entry rule, creates an execution context and skips leading blank/comment lines. After rule
execution it completes optional staged enrichment, builds result/cursor/lifecycle records
and emits the optional semantic observation. Diagnostic and semantic sink failures preserve
their original error/stack; exits and runtime diagnostics keep separate trace boundaries.

Rule entry checks the selected generated family, builds the label/regex-index/cursor
recursion key, and establishes fresh match registers plus binding/recognition scopes.
This range ends at the execution try block; .1.16 owns its body and cleanup.
The 82 selected progressive/interpreter/cursor/emitter tests pass, including emitted source.
Known nested private-authority composition limits are separately preserved in
[[dart-progressive-nested-authority-gap]]; no runtime repair is made by this reading slice.

## 2026-09-09 — rule execution through initial value-block flow

`DART-STARTUP-READING.1.16` reads lines 675-2174. Rule initialization and blind/regex
selection retain terminal results/errors for recognition exit, then restore binding scope,
rule stack, registers and recursion identity through nested cleanup. Blind AND collects
implicit successful child values; repetition checks counts and progress around lifecycle
hooks. Capture-enabled regex loops select/install before LS and commit after LE before IT;
unflagged loops retain their own order. Slot identity checks precede typed observation and
trace. Action edges track prior dispatch and collect repeated explicit returns where owned.

Lifecycle I records initializer binding ownership before execution. The statement dispatcher
separates attached/marker if and switch, attached while, structural markers and expressions.
The range ends during local-return handling in value-block flow; .1.17 owns its continuation.
Existing switch omission .2.1 and effect integration .2.4 remain unresolved.

All 100 selected interpreter/cursor/recognition/observation/gap/repeated-result/slot tests pass,
including emitted and gap-primary consumers. Six native callback probes nevertheless expose
the action-block semantic failure translation documented in
[[dart-semantic-observer-action-failure-wrapping]]; new .2.8 owns repair and carrier proof.

## 2026-09-09 — value control, callbacks and expression entry

`DART-STARTUP-READING.1.17` reads lines 2175-3674. Marker selectors retain nested
boundaries and lazy branch evaluation. The full value-block dispatcher preserves local
return flow for attached controls, but its marker-range counterpart has the mixed-control
gap in [[dart-mixed-control-value-block-gap]]; new .2.9 owns it after startup gates.

Helper/receiver with and tree callbacks copy values and restore temporary bindings in
finally blocks. Hash traversal follows sorted keys through maps; array traversal follows
indexes through lists, treating the other aggregate as a leaf. Expression dispatch handles
typed literals/aggregates, cached codeblocks, writes/reads and recognition/staged/progressive
delegation. This range ends inside observe-recognition child execution; .1.18 continues it.

All 124 selected interpreter/ActionIR/callable/binding/write/mutation tests pass, including
their existing emitted/CLI consumers. Ten new native/SpecFile-JSON controls establish four
escaping returns and one skipped else, alongside five successful locality controls.

## 2026-09-09 — observation completion, mutation and helper dispatch

`DART-STARTUP-READING.1.18` reads lines 3675-5174. Observations bind before return or
typed rethrow. Receiver mutation snapshots the original root, checks binding/kind, holds
its identity guard through copied callback traversal and releases after one commit before
continuation. The existing [[map-leaves-mutation-dart-runtime]] remains its authority.

Helper dispatch separates statement mutations, registered calls, logical arity, lazy
controls, source/capture/cursor projection, diagnostic sinks and bound callable fallback.
Codeblocks restore temporary parameters; functions run with fresh stores then restore the
caller. The range ends at _callSet; .1.19 continues helpers. Source absence behavior remains
[[dart-nullable-match-state-preserves-absence]], including one-based line/column defaults.

The 140 selected interpreter/callable/variadic/mutation/observation/source/logical/diagnostic
tests pass with existing emitted/CLI consumers. Nine native/reconstructed controls expose
helper-name recursion collisions in [[dart-callback-helper-recursion-identity-gap]];
new .2.10 owns repair. Previously owned effect/observer/mixed-control gaps remain open.

## 2026-09-09 — helper implementations and constructor splice intake

`DART-STARTUP-READING.1.19` reads lines 5175-6674. Write helpers guard identity before
operands; push distinguishes explicit targets from implicit rule/edge accumulators.
Array construction expands explicit splices; hash construction pairs raw values before
a second map merge. Fluent receivers use copied typed views. Capture operations project
through source authority before mark/cursor updates; boundary capture chooses the earliest
valid rule match. Logical arguments are eager; coalesce remains lazy. Passive action-child
tracing continues in .1.20.

All 122 selected interpreter/binding/source/logical/diagnostic/mutation tests pass,
including existing emitted/CLI consumers. [[dart-hash-splice-pairing-gap]] retains nine
Dart native/reconstructed cases and nine Perl facade/source comparisons; new .2.11 owns
Dart repair alongside FUTURE-PARITY-BACKLOG.5's already-owned helper-context decisions.
The three dropped standalone array-transform rebindings remain owned by that backlog.

## 2026-09-09 — supporting value helpers and runtime context entry

`DART-STARTUP-READING.1.20` reads 6675-8174: action-child completion, explicit splice
classifiers, copied array/hash transforms, scalar/rune helpers and strict numeric adapters.
Runtime context initializes source/progressive/staged/recognition authorities. Invocation
frames restore marks during cleanup and preserve original failures while recording
accepted/failed/aborted/rejected observations; .1.21 resumes after noteRecognitionMatch.

The corrected complete selection passes 111 tests, including exact numeric/text fixtures
and existing emitted/CLI consumers; neutral numeric passes 55/18. New exact paired controls
own [[dart-large-number-helper-corruption]] (.2.12, eleven cases),
[[dart-helper-unicode-order-gap]] (.2.13, eight cases) and [[dart-slice-end-overflow]]
(.2.14, six cases). Each includes native/reconstructed and Perl facade/source evidence.
No source repair or new emitted defect result is claimed; prior ownership remains.

## 2026-09-09 — context, source projections and binding snapshots

`DART-STARTUP-READING.1.21` reads 8175-9674. Gap/observation payloads use typed source
and recognition authorities. Observation binding's caller guards receiver mutation before
child execution at 3663; the direct store in bindRecursiveObservation is not a bypass.
Recognition rollback restores cursor, boundary and marks. Typed source projection catches
SourceLocationException as absence. Rule-local, callback and whole-store snapshots restore
copied stores and binding identities; active outer guards remain identity-based while
function parameter bindings are fresh. Cursor anchors validate source boundaries; copied
binding views retain presence/kind and legacy stores. .1.22 continues legacy _assignHashIndex.

All 124 selected runtime tests and six contract tests pass, including existing emitted/CLI
consumers. [[dart-input-slice-boundary-gaps]] retains nine exact paired controls: typed
input overflow extends .2.14, while documented arity/late reference failure belongs to
new .2.15. Prior repair owners and all source bytes remain unchanged.

## 2026-09-09 — interpreter reading complete

`DART-STARTUP-READING.1.22` reads 9675-10274 through EOF. Legacy hash-index writes
finish before shared mutation diagnostics and the typed nested-write authority.
Selectors and RHS evaluate before root capture; copied missing containers are
created densely and published once. Existing null/wrong-kind roots reject with
typed path/span diagnostics. [[write-vivification-dart-runtime]] retains this
contract and detached results. Callable decoding checks record/signature shape;
ordinary maps/lists copy recursively, and logical truth uses the typed policy.

The slice also reads matching 1-900; 132 selected tests and the 31-case structural
corpus window pass, including existing generated/emitted/CLI consumers. No new
defect or repair is claimed. Numeric conversion inventory stays .2.12; all
earlier interpreter findings remain owned under .2.1-.2.15 and startup owners.

## September 10 interpreter-consumer prefix reading

`DART-STARTUP-READING.1.45` reads consumer lines 1-407, while its full file executes
in the passing 75-test selection. The prefix covers lifecycle collection and child
push/index conventions; leading-trivia behavior; scalar indexed reads; self-close
slots; recursive rule-local aggregates and caller-visible undeclared mutations;
sequential blind returns; isolated marks and BMP multibyte capture; OR miss,
bounds and zero-progress stopping. The repetition lifecycle assertion continues
after line 407. Passing the full test file grants no reading credit for that suffix
and does not close any previously owned interpreter defect.

## September 10 interpreter-consumer reading complete

`DART-STARTUP-READING.1.46` reads 408-1821 through EOF. All 68 interpreter/matching
tests pass. The suffix covers lifecycle order, cursor stack and anchor rewinds,
non-consuming boundaries, capture slices, dense nested writes and typed snapshots,
helper families, 55-case numeric contract, pure/mutating collection boundaries,
value and marker controls, tree callbacks and restored bindings, registered-function
isolation/recursion/arity, exact diagnostics and governed helper/capture fixtures.
These are native execution consumers. Ordinary numeric, BMP position, switch and
callback examples do not close the already owned extreme-value/astral/control/
callback-identity defects. The old core-helper missing-path claim is corrected under
this leaf with historical prose retained and current write authority linked.
