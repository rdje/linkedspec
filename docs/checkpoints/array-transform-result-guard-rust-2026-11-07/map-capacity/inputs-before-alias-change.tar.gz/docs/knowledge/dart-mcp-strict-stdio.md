---
id: dart-mcp-strict-stdio
title: Dart MCP strict stdio is bounded, duplicate-safe, canonical, and caller-owned
answers:
  - "is Dart MCP strict stdio implemented"
  - "how does Dart MCP frame stdio"
  - "how does Dart MCP reject duplicate JSON keys"
  - "does Dart MCP close caller streams or sinks"
  - "how does Dart MCP handle input output or flush failures"
  - "how does Dart MCP cancellation interact with response flush"
  - "which file owns the Dart MCP wire"
date: 2026-07-29
status: strict stdio implemented, admitted through the exact Dart MCP consumer, and parent-closed
tags: [dart, mcp, stdio, json, framing, cancellation, io, security]
evidence: dart/lib/src/mcp/mcp_wire.dart; dart/lib/src/mcp/mcp_server.dart; dart/test/mcp_server_dart_stdio_test.dart; dart/test/mcp_server_dart_admission_test.dart; docs/decisions/0059-dart-native-mcp-server-seams.md; docs/tasks/FUTURE-PARITY-BACKLOG.md leaf .10.9.4.3; tools/check_mcp_implementation_admission.py; tools/run_ci_local.sh
reverify: "cd dart && bash ../tools/run_dart_project_data.sh analyze --fatal-infos --fatal-warnings && bash ../tools/run_dart_project_data.sh test test/mcp_contract_dart_binding_test.dart test/mcp_server_dart_dispatch_test.dart test/mcp_server_dart_stdio_test.dart test/mcp_server_dart_admission_test.dart && cd .. && bash tools/run_python_project_data.sh tools/check_mcp_implementation_admission.py"
---

# Dart MCP Strict Stdio

`FUTURE-PARITY-BACKLOG.10.9.4.2` implements public `McpServer.serveStdio` over a caller-owned
`Stream<List<int>>`, borrowed output `IOSink`, and optional distinct borrowed log `IOSink`. The server never closes
those objects. It validates authorization before consuming input, accepts LF, CRLF, or one final complete frame at
EOF, retains at most the 1,048,576-byte payload limit plus a possible CR, and drains an overlong line without
unbounded growth.

Private `mcp_wire.dart` performs iterative depth-64 token preflight before `jsonDecode`. It rejects invalid UTF-8,
BOMs, malformed JSON and numbers, non-finite decoded values, arrays/non-object roots, invalid request-id token
kinds or safe-range values, incomplete escapes or surrogate pairs, and duplicate decoded object keys including
escape-equivalent spellings. Canonical output recursively sorts object keys, preserves list and Unicode scalar
content, uses UTF-8, and appends exactly one LF.

An accepted request id remains active through successful output flush. Cancellation observed at the deterministic
pre-emission boundary suppresses the prepared response; a flushed response is final. Graceful EOF flushes and
releases every registered index. Input, add, or flush failure performs the same shutdown, emits at most the fixed
`linkedspec_mcp_io_failure` code to the optional log, and throws the sanitized typed
`linkedspec_mcp_io_failure` error. The production authority surface imports only `dart:io show IOSink`; it gains no
file, process, socket, HTTP, isolate, parser, compiler, runtime, trace, emitter, cache, or CLI authority.

Focused binding/decoded/stdio/admission proof is 16/16 and the complete Dart package is 353/353 with clean
analysis. Exact `.10.9.4.3` admits the unchanged four Dart production owners through one twelve-role consumer;
the ledger is now 3/5 implementations and 3/6 runtimes with shared rollout still pending.
No-change `.10.9.4.4` recomposes that committed proof without changing the wire, production owners, consumer,
contract, or ledger, closes the Dart parent, and hands off to Julia `.10.9.5`.

Related facts: [[dart-mcp-decoded-server]], [[dart-native-mcp-server-plan]],
[[mcp-2026-07-28-stdio-contract]], and [[mcp-implementation-admission-ledger]].

## 2026-09-09 — complete wire reading and bounded current proof

`DART-STARTUP-READING.1.11` reads server lines 1020-1092 and wire lines 1-683 through EOF.
The detached-copy helper tracks active ancestors by identity, rejects cycles, non-finite
numbers, non-string keys and excessive depth, and permits shared acyclic objects.
Wire token preflight independently validates decoded duplicate keys, surrogate pairing, lexical
numeric-ID kinds and safe ranges before decoding. LF framing strips one delimiter CR; final EOF
does not strip it and explicitly rechecks payload length before decode. That source check
differs from the Rust final-EOF omission owned by startup .65; no fresh EOF boundary probe
or Rust outcome is claimed here. Prepared response emission, cancellation, flush and shutdown
balance caller-owned streams/sinks and sanitize I/O failures.

The existing strict-stdio and spec-parser selection passes 16 tests. The older admission totals
above remain dated evidence, not a fresh complete package or ledger result. Wire serialization
calls the canonical helper whose uncovered Unicode ordering boundary was established in
[[dart-mcp-unicode-key-order-gap]] under .1.10. Reading that call does not supply a new wire
Unicode execution result; .2.5 retains affected-route proof and repair.

## September 10 complete stdio-consumer reading

`DART-STARTUP-READING.1.41` reads all 575 stdio-test lines. The full selected MCP
binding/admission/dispatch/stdio group passes seventeen tests. Neutral transport is
35/10/10/76 and the current admission ledger is 5/5 plus 6/6 complete/141; the older
3/5 and 3/6 figures above are historical, not current rollout status.

The pre-emission hook actually dispatches cancellation, proves zero output bytes and
zero remaining active requests. A later wire cancellation leaves the flushed response
intact. Focused sources also cover duplicate decoded keys, invalid surrogate/numeric
forms, safe integer and UTF-8 ID budgets, the exact CRLF line maximum, overlong recovery,
final EOF, split chunks, release and fixed I/O privacy. Sink failure uses consumer
`addStream`; a separate flush-only fault is not injected by this suite. Admission's
textual cancellation sentinel is backed by a separately executed consumer.
Known Unicode canonical ordering remains owned by [[dart-mcp-unicode-key-order-gap]].
