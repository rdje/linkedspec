---
id: count-result-source-guards
title: Count source composition needs typed blocks and canonical rejection guards
answers:
  - "why does count run with after an incompatible consumer"
  - "why does a block-valued count source fail generated Perl compilation"
  - "why does count report ready when its emitted Perl fails to load"
  - "which task owns Count copy source-domain and rejection effects"
  - "where is the existing count length normal and its expected fixture"
date: 2026-11-06
status: all bounded primary and six concrete P1 Count source/copy/logical repairs focused-checked; full admission open
tags: [count, array, numeric, guards, source, copy, composition]
evidence: "TYPE-REFERENCE-BOOK.1.2.23.1.34; count-guard-selection-intake.json.gz retains actual public19, canonical4/excluded18/typed-source3 AST-lowerings, exact source owner mechanisms and setup qualification."
reverify: "Recover public observers/cases into new project-local outputs with project-data wrappers; qualify native context errors/readiness/fresh loading separately. Historical activation/freeze writers one-shot never replay."
---

Historical selection34, before typed-source73.0, freezes canonical count source/prefix guards73 from nineteen public Get/descriptor/substitution/full emission/native-fresh controls. Primary16 has ten matching observations, including one explicitly unready receiver bridge with unresolved with, and six gaps: free/receiver container guards, free/receiver rejected-with, compile-failing needed source error and function scope. Primitive numeric0/counts, scalar/default/Array bridges, source-consumer snapshot2!/SC/calls1 and valid zero/null/empty/Array with controls stay. Extra rejected-copy chain runs ran/W; push-yielding source also fails compilation. Both compilation controls report ready1 but fresh-load0 with warnings and native rule_handler_compile context errors, never executable success. Three public AST/lowering controls retain block_value free/receiver sources while emitting raw braces into $__ls_count. MethodLowering typed aggregate block handling includes contains/index_of only; legacy count fallback7644-7660 reconstructs source. Existing typed value-block ownership is the bounded producer model. Missing canonical count source/with/actual-kind roles lose rejection; selected Count results can fall into Array/Hash fallback consumers. Source-domain diagnostic returns six zeros for free/direct null-String-Hash count and null for copied-null receiver count. Preserve original observations and Count source-kind/free-signature policies; ADR0138/existing Count zero fallback require independent P1 copy/source/rejection assessment73.6 after primary guards, with concrete owners before any follow-up production. No generic nullable Array policy or silent source-domain normalization. Four canonical/eighteen excluded public syntax snapshots preserve malformed/named/unknown/deferred/traversal/other-helper boundaries. All declared public/syntax/operand source/producer/case/authority identities exact; production unchanged, no peer failure or complete family inference. Freeze shared16/excluded18 and detailed73: Perl typed-source producer73.0 first, independently baselined guards73.1-.5, mandatory copy/source/rejection assessment73.6.0 before unrelated selection. Actual producers/templates/inputs/raw channels/compile traces/diagnosis and authority-name setup qualification retained in count-guard-selection-intake.json.gz. Actual existing count/length normal is t/count_length_receiver_contract.t with inline spec/expectations. Book/card/map/target/task/roadmap/live/resume/history align. Full23.4/pressure/registration/input-custody/task-evidence/general isolation remain separate; no full suite or push.

The actual existing normal is t/count_length_receiver_contract.t; its source and expected JSON are inline, so do not invent a companion fixture filename. At the selection34 baseline, aggregate typed block handling covered contains/index_of and legacy Count reconstructed raw target text while the public AST retained block_value. Typed-source73.0 repaired that path; the selection diagnostics remain historical. The concrete73.6 follow-ups are now focused-checked, with no silent policy normalization or full admission inference.

Historical primary rollout: Rust73.2 added Count to direct/trailing-block actual-kind guards with focused
native/restored/generated-plan and compiled emitted proof. Initial source behavior
remains frozen, including Rust's `count("text")` and `"text".count()` returning4
against Perl's0. Mandatory73.6.0 owns that source-domain discrepancy before unrelated
selection; full generation-input custody/registration/admission remain separate.
Mechanism and reverify routes: [[rust-count-result-source-guards]].
Dart73.3 now passes native/restored/plan and independently compiled emitted
controls, preserving the initial-source policy and scalar-result guards. Its
source-domain diagnostic matches the reference; direct generated host inputs
are retained before execution, without a complete transitive-closure claim.
Mechanism and reverify routes: [[dart-count-result-source-guards]].
Julia73.4 now passes strict native/restored/plan/fresh Module controls with the
same reference domain diagnostic. Its initial source/scalar-result rules and
separate Array-end mutation gate stay intact. Route-specific observed error
fields freeze before production; uniform class/code assumptions were observer
setup errors, not Count guard defects. Mechanism/reverify:
[[julia-count-result-source-guards]]. Installed Lua73.5 now passes independent
PUC5.5.1/LuaJIT2.1.1788460057 native/restored/plan/fresh controls with frozen
source/domain/observed error fields and selected direct consumers. Existing
namespace/scalar-result/mutation restrictions stay. Mechanism/reverify:
[[lua-count-result-source-guards]]. All bounded primary73 outcomes are recorded;
P1 assessment73.6.0 is now frozen. It owns Perl plain-copy1/logical6,
Rust non-array source2 and peer Boolean source3/4/5 repairs before unrelated
selection. Current diagnosis, actual first-run input custody and readonly review:
[[count-copy-source-assessment]].

## Current Perl typed-source repair

Current Count follow-up: all six concrete P1 repairs are focused-checked on their
recorded routes/hosts: Perl copy73.6.1/logical73.6.6, Rust source73.6.2 and Boolean
source Dart73.6.3/Julia73.6.4/installed Lua73.6.5. Canonical Julia/Lua nodes confirm
completion; no P1 remains from that finite assessment. See [[count-copy-source-assessment]],
[[perl-count-copy-rejection]], [[perl-count-logical-rejection]],
[[julia-count-result-source-guards]] and [[lua-count-result-source-guards]].
Full admission remains separate. The original selection, primary rollout and
producer records retain their historical boundaries below. The same typed owner
now also covers CountKeys under75.0.1: [[perl-key-count-typed-source]].

Perl73.0 preserves canonical Count block sources through existing typed value ownership. Independent unchanged fourteen native/fresh groups6PASS8RED become14PASS, with a retained12PASS2RED intermediate exposing direct terminal receiver bypass. Seven values/seven structured needed-source errors now satisfy target; five healthy value observations and the already working receiver/default error remain exact. All fourteen ready/raw0/fallback0/unresolved0/warning-free and actually fresh-loaded; required errors occur at rule_handler_eval/execute_generated, not compilation. Add count to the existing contains/index_of typed block-argument branch. Canonical zero-extra/non-trailing terminal count on block_value delegates to the same typed free Count call, preserving the original receiver/source span. Legacy emitter, source-kind/non-array-zero/free-signature/copy/other-helper/context/parser/schema policies stay. Mutation-yielding Array sources count1; source-once snapshots and bound/function sources stay. Three final input-bound public lowerings retain identical original AST/source and eliminate raw-brace Count targets without warnings. Intermediate public transport0 still contained one raw receiver and its semantic assertion failed, explicitly retained without all-pass credit. Original/intermediate/final owner bytes/deltas and phase hashes are distinct. Nearest count-length5/index-producer15/push8=28, original eighteen source fences before/intermediate/final and owner-normal syntax pass. Three actual runtime fixture inputs/inline count-length-push programs/104 other activation inputs/phase identities exact, not complete transitive generation closure. Actual producers/templates/inputs/raw phases and intermediate qualification retained in count-block-source-perl-intake.json.gz. Book/card/map/target/task/roadmap/live/resume/history align; new normal14/source18/shared14 registration remains23.4.1-owned. Regenerate emitted Perl. Independent Perl source guards73.1 next, then peer guards and mandatory P1 copy/source73.6. General isolation/full23.4/pressure/input-custody/task-evidence separate; no full suite or push.

The historical raw Count source failure is repaired for ordinary canonical free Count block arguments and zero-extra/non-trailing terminal Count block receivers. The latter delegates to the same typed call node, avoiding compatibility-bridge reconstruction without changing the legacy emitter. Receiver/default was already healthy; its complete error observation stays exact. Source guards and copy/source-domain follow-up remain independently owned.

## Historical Perl source/prefix73.1 repair record

Perl Count continuations now use the existing actual-kind and rejection guards. Incompatible Array/Hash consumers skip operands and later with bodies while retaining valid source effects, numeric zero, scalar/default/Array bridges, legitimate null, source-once snapshots and function isolation. The initial Count non-array-zero fallback applies only outside existing emitted-result owners, preserving copied-null behavior and copy folding. Primary16 baseline10PASS6RED becomes16PASS; an intermediate16PASS/diagnosticRED is retained, and the corrected separate six-zero/one-null diagnostic passes. Three public lowerings confirm guards/rejection state; source18, Count/length5, selected producer5 and copied-null index1 pass. Runtime source errors stay structured at execution. Regenerate emitted Perl. The independent backend outcomes above now advance to the concrete P1 repair order1,6,2,3,4,5 from assessment73.6.0; At that primary checkpoint P1 copy/source/rejection73.6 remained open; its six concrete repairs are now focused-checked. Registration23.4.1, document pressure20.1 and full admission remain separately owned. No complete family/portable/full-CI claim or push.
