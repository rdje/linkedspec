---
id: aggregate-selector-public-admission
title: "Public LinkedSpec authoring admits bare typed bindings and classifies removed selector mentions"
answers:
  - "is aggregate selector retirement fully admitted"
  - "can public docs still show array name or hash name as current syntax"
  - "which checker prevents aggregate selector documentation drift"
  - "why are removed selector spellings still visible in some documentation"
date: 2026-09-27
status: current
tags: [language, bindings, retirement, documentation, capability, no-drift]
evidence: "FUTURE-PARITY-BACKLOG.12.1.9 adds tools/check_public_aggregate_selector_surface.py and registers it in canonical local CI. The checker scans 47 root/capability/mdBook public files, requires every exact selector-shaped mention to carry explicit removed/rejected/migrated historical context, forbids stale future/remaining-backend status, requires current bare set/push/copy examples, removes future.uniform_binding_selector_retirement from capability_conformance/manifest.json, and composes the five-backend runtime/source checker plus the 60/0/0 capability checker. On 2026-07-12 it classifies 31 removed/history references, reports zero current public examples, and passes canonical CLI 61x2 plus Phase 0 1031/1031 in 626 seconds."
evidence_update_2026_07_12_lua_array_closeout: "LUA-BACKEND-PARITY.4.3.4.6 reworded four formal-grammar array end-mutation comments from `named working array (statement)` to explicit updated-snapshot semantics. The public check's code-block recognizer had counted each prose fragment `array (statement)` as an exact selector shape, so the corrected inventory is 27 genuine removed/history references, not 31. The expected count and capability guide now lock 27; all 27 retain explicit negative context and current examples remain zero."
evidence_update_2026_07_29_readme_routing: "README-STABILITY-POLICY.1 removes two duplicate historical selector mentions from root README while keeping README in the discovered 59-file public scan. The exact current classified count becomes 25 with zero current examples; canonical migration history remains in the guide/mdBook/Knowledge owners."
evidence_update_2026_08_25_staged_ast_enrichment_page: "FUTURE-PARITY-BACKLOG.14.7.2 adds compiler/staged-ast-enrichment.md to the discovered mdBook surface. The public selector checker reviews the new chapter, advances the exact inventory to 60 files, and keeps classified/current selector counts at 25/0."
evidence_update_2026_08_29_codegen_inspector_page: "FUTURE-PARITY-BACKLOG.13.1 adds development/codegen-inspector.md to the discovered mdBook surface. The exact staged canonical gate catches the resulting cardinality change; the checker now locks 61 public files while classified/current selector counts remain 25/0."
evidence_update_2026_08_30_migration_contrasts: "FUTURE-PARITY-BACKLOG.23.1 restores two rejected selector examples plus five ordered old-to-new mappings that ac217f6c had mechanically collapsed. The checker now validates the uniquely bounded migration section through eleven in-memory contrast mutations and reports 61 public files / 32 classified historical references / zero current examples."
evidence_update_2026_09_02_macos_latency_page: "FUTURE-PARITY-BACKLOG.19.3.4.0 added development/macos-rust-launch-latency.md to the discovered mdBook surface. The exact staged canonical gate for .19.4.1 caught the stale cardinality guard; the checker now locks 62 public files while classified/current selector counts remain 32/0."
reverify: "bash tools/run_python_project_data.sh tools/check_public_aggregate_selector_surface.py"
---

# Aggregate-selector public admission

Uniform-binding selector retirement is fully admitted. Current `.spec` guidance uses bare typed bindings:
`set(items, [])`, `push(items, value)`, `copy(items)`, `items = [...]`, and `meta = {...}`. Exact one-bare-name
`array(...)` / `hash(...)` calls are not compatibility forms or typed reads; all five backends reject them before
execution with `aggregate_selector_removed`.

Public documentation may retain the removed spelling only to state a boundary, explain a migration, or preserve a
clearly historical milestone. It may not present the spelling as an accepted example, a remaining compatibility
surface, or future work. `tools/check_public_aggregate_selector_surface.py` enforces that distinction across the
root README/roadmaps/architecture state, capability guide, and every mdBook source page. Its exact current inventory
is 70 public files. It composes the runtime/source retirement checker so public and executable admission cannot
diverge. Its current inventory is 40 classified retired/history references and zero current examples. Seven concrete
retired spellings are confined to one uniquely bounded migration section: two rejected examples and five ordered
old-to-new contrasts guarded by eleven in-memory mutations. Four earlier counted occurrences were prose false
positives and two later duplicate root-README history mentions were routed to canonical owners.

The capability census already proves every current language surface on all four census backends at 64/0/0; the
separate Lua rejection proof is locked by the aggregate-retirement checker. Therefore selector retirement is no
longer listed under `excluded_or_future`.

Related facts: [[aggregate-selector-retirement-no-drift]],
[[spec-facing-aggregate-selector-retirement-inventory]], [[uniform-binding-neutral-contract]].

## September 13 Rust integration-page inventory

`BACKEND-INTEGRATION-GUIDES.2.1` adds exactly
`docs/linkedspec-book/src/public-api/integration-rust.md` to public discovery.
Focused preflight reproduces expected62/observed63 before the correction at
`tools/check_public_aggregate_selector_surface.py:14`. The checker changes only
that expected cardinality and the classified-reference count; all prior classifier,
migration, mutation and composed checker code remains byte-identical. The new page
adds no selector reference. Exact discovery also finds three existing references
in the Julia callable-validation limitation introduced by6308ff4e24: two inline
retired spellings and one invalid fenced example. A blank paragraph boundary
separates that fence from the surrounding invalid-language explanation, so
`sentence_at` correctly requires classification context inside the fence.

The full Julia example and open JULIA-STARTUP-READING.2.1 repair are retained. An
explicit invalid/retired comment classifies the fenced occurrence; the current
reference count is35. The original32 other references, zero current examples,
five contrasts and eleven contrast mutations remain intact. Earlier evidence
counts above are dated results, not the current public inventory. This is a
public documentation repair, not a Julia validator repair or new runtime proof.

## September 14 Perl integration-page review

`BACKEND-INTEGRATION-GUIDES.1.1` adds only the new Perl integration
chapter to public discovery. Preflight reproduces mutation expected64/observed65
and selector expected63/observed64. The reviewed correction changes only each
checker's expected file count and current census references. The selector's35
classified references, zero current examples and11 contrast mutations remain;
mutation's14 governed documents,11 example classes,10 denials and50 mutations
remain. Earlier dated evidence is preserved. Reverify with the existing command.

## September 19 Dart integration-page review

`BACKEND-INTEGRATION-GUIDES.3.1` adds the native Dart integration chapter.
Preflight reproduces mutation expected65/observed66 and selector expected64/observed65.
Only the two expected file counts and current census references advance. All
classifier logic, frozen authorities,35 selector references,zero current examples,
11 contrast mutations and mutation14/11/10/50 semantic checks remain unchanged.
Earlier dated evidence stays intact; reverify with the existing command.

## September 20 Julia integration-page review

`BACKEND-INTEGRATION-GUIDES.4.1` adds the native Julia integration chapter.
Preflight reproduces mutation expected66/observed67 and selector expected65/observed66.
Only the two expected file counts and current census references advance. Classifier
logic, frozen authorities,35 selector references,zero current examples,11 contrast
mutations and mutation14/11/10/50 checks remain unchanged. Earlier evidence stays
intact; reverify with the existing command.

## September 20 Lua integration-page review

`BACKEND-INTEGRATION-GUIDES.5.1` adds the native Lua integration chapter.
Preflight reproduces mutation expected67/observed68 and selector expected66/observed67.
Only the two expected file counts and current census references advance. Classifier
logic, frozen authorities,35 selector references,zero current examples,11 contrast
mutations and mutation14/11/10/50 checks remain unchanged. Earlier evidence stays
intact; reverify with the existing command.

## September27 admission census correction

`RGX-CONSUMER-BUILD-REPORTS.1.2` canonical admission exposes a stale count, not new
selector syntax. The maintained checker's matching rules find36 references in
both clean `7c2acb51` and the adoption candidate, versus35 at published `a8d34c845`.
The only addition is the explicitly rejected `array(value)` spelling in the
constructor guide, added by `49678a8c136ea2f824f6f0ed2ac0b1170f52087a` (startup
`.90`). Every earlier occurrence remains; the document-prefix repair adds none.
The correction advances only the expected classified count to36 and synchronizes
the current census prose. Classifier rules, negative-context requirements, five
ordered migration contrasts, eleven mutations, runtime rejection and executable
source checks remain unchanged. The earlier dated evidence retains its scope.

## September27 regression-fixture chapter registration

The first canonical run for SPEC-LANGUAGE-SELF-CONTAINMENT.1.1.3.1.2.2.6 stops at mutation expected70/observed71;
the selector preflight also rejects expected69/observed70. Comparing the complete public path set with clean
27a2168d finds only development/regression-fixtures.md, added by startup .92 at30b2cc3a0. Complete review finds
regression/fuzz/fallback guidance and no mutation or retired-selector example. Both expected file counts advance
by exactly one; classifiers, frozen authorities, mutation14/11/10/50 and selector36/0/5/11 controls remain intact.
Current census prose moves with registration. The failed partial canonical run is not acceptance evidence.
