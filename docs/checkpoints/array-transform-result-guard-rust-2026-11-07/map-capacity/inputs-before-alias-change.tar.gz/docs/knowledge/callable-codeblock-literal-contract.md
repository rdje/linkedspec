---
id: callable-codeblock-literal-contract
title: Callable codeblocks use brace-pipe literals and dynamic caller context
answers:
  - "how do I initialize a codeblock variable"
  - "what is the callable codeblock literal syntax"
  - "can I call a codeblock variable with cb parentheses"
  - "does a LinkedSpec codeblock capture lexical variables"
  - "how are codeblock literals distinguished from harray literals"
  - "what is the zero argument codeblock literal"
  - "can codeblock literals have a rest parameter"
  - "does with remain after callable codeblocks"
date: 2026-07-12
status: current
tags: [codeblock, callable, literal, dynamic-scope, harray, actionir, FUTURE-PARITY-BACKLOG]
evidence: "Director agreement on 2026-07-12 selects {|args| ...} and dynamic caller context; ADR 0031 defines literals/invocation, ADR 0032 defines final-only name: codeblock, and .11.2 adopts linkedspec-callable-codeblock-v1. Perl .11.3, Rust .11.4, Dart .11.5, and Julia .11.6 consume construction, invocation, and contextual equivalence. Lua .11.8.1-.2 now consume construction and general dynamic invocation; route identity/admission remain .11.8.3-.4."
evidence_update_2026_08_01_recurring_gate: "FUTURE-PARITY-BACKLOG.11.7.1 composes the four current backend consumers through one routed optional canonical matrix, rejects 17 topology/status mutations, corrects the mixed future exclusion to Lua-only .11.8 ownership, and leaves capability 80/0/0 unchanged."
evidence_update_2026_08_01_public_closeout: "FUTURE-PARITY-BACKLOG.11.7.2 omission-locks 23 public documents and nine stale-claim denials through three additional governance mutations; public no-drift closes parent `.11.7` while Lua explicit values/general calls remain `.11.8`."
evidence_update_2026_08_01_lua_construction: "FUTURE-PARITY-BACKLOG.11.8.1 implements the same inert eight-field literal/signature/body/span state on PUC Lua and LuaJIT while leaving general invocation and final admission pending."
evidence_update_2026_08_01_lua_invocation: "FUTURE-PARITY-BACKLOG.11.8.2 implements the same post-static dynamic caller-frame invocation, result access, exact failures, and ordered recursion on PUC Lua and LuaJIT; recurring admission remains pending."
evidence_update_2026_08_01_lua_emitted_identity: "FUTURE-PARITY-BACKLOG.11.8.3 proves the same typed state and executor across native, canonical effective-SpecFile reconstruction, generated-plan, and fresh emitted modules on both Lua ABIs; at that boundary recurring five-backend admission was still owned by .11.8.4."
evidence_update_2026_08_01_five_backend_admission: "FUTURE-PARITY-BACKLOG.11.8.4 makes recurring/public proof current on Perl, Rust, Dart, Julia, PUC Lua, and LuaJIT, removes the satisfied future.generic_final_codeblock exclusion, locks 25 public documents through 22 mutations, and preserves the established 80/0/0 backend census."
evidence_update_2026_08_01_public_count_guard: "FUTURE-PARITY-BACKLOG.24.0.2 preserves the existing 22 mutations and adds one exact sole-facing project-status count drift, making current governance 23 while the document inventory remains 25 and capability stays 80/0/0."
reverify: "bash tools/run_python_project_data.sh tools/check_callable_codeblock_contract.py && rg -n '0031|0032|name: codeblock|dynamic caller|FUTURE-PARITY-BACKLOG\\.11\\.[1-8]' docs/decisions/0031-callable-codeblock-literal-and-dynamic-context.md docs/decisions/0032-final-codeblock-parameter-declaration.md docs/tasks/FUTURE-PARITY-BACKLOG.md"
---

The accepted callable codeblock literal is:

```text
cb = {|left, right|
  return(cat(left, right))
}

result = cb("a", "b")
```

The opener is exactly `{|`. `{|| body }` declares no parameters. A final `...rest` reuses the callable-signature
rules from ADR 0030. Construction stores a typed signature/body/source value and does not execute the body.

This prefix is distinct from every current brace value: `{}` and `{ key : value }` are harrays, while a nonempty
`{ statements }` without a top-level hash pair remains an immediately evaluated block expression. A codeblock
literal therefore does not need to guess from colon/statement content and cannot silently become an harray.

`cb(args)` evaluates positional arguments once left-to-right. Copied parameter values and a fresh rest array bind
temporarily, then prior same-name bindings restore. The body resolves all other variables from the caller's current
stores at invocation time; it captures no lexical environment at construction. Nonparameter mutation remains
visible to the caller. `return(...)` is block-local and the final value can chain or be discarded.

Governed static helpers/controls and registered user functions retain call precedence over same-named variables.
Bound non-codeblocks diagnose as not callable; recursion is initially rejected. `with` remains an ordinary helper,
and generic attached/contextual final blocks normalize under callable signatures rather than name-gated parsing.
Lexical capture is explicitly deferred behind a new decision if a real need appears.

ADR 0032 declares only the receiving value kind: a final `callback: codeblock` parameter. It has no argument list;
explicit `{|params| ...}` values own their signatures, while contextual `{ ... }` values take zero positional
arguments and read dynamic context.

`linkedspec-callable-codeblock-v1` machine-locks seven literals, eleven valid calls, sixteen invalid syntax/call
cases, four invalid declarations, eight contextual forms, and one deterministic fixture. Perl `.11.3.1` implements typed literal
construction/preservation, `.11.3.2` executes `cb(args)` with the neutral dynamic-context behavior, and
`.11.3.3.2` normalizes declared helper/user-function/receiver contextual final blocks. Rust `.11.4.1` now preserves
the same inert literal/signature/body/source/span record through compiled JSON, user functions, semantic
descriptors, generated plans, and emitted source. Rust `.11.4.2` executes dynamic calls with the same ordered
arguments, copied/restored bindings, caller stores, local results, static precedence, typed failures, and
native/generated identity. Rust contextual equivalence is current through `.11.4.3`. Dart `.11.5.1-.2` now
preserve the inert literal record and execute dynamic calls with the same ordered arguments, caller stores,
copied/restored bindings, local results, typed failures/recursion, and native/reconstructed/generated/emitted
identity. Dart contextual behavior is current through `.11.5.3`. Julia `.11.6.1-.2` now preserves the same inert
record and executes bound calls with ordered arguments, copied/restored bindings, live caller stores, local
results/access, exact failures/recursion, and native/reconstructed/generated/emitted identity. Julia contextual
behavior is current through `.11.6.3`. Lua contextual final blocks, inert explicit construction, and general bound
calls are current through `.11.8.2`; independently loaded emitted-route identity is current under `.11.8.3`.
Five-backend callable recurring/public admission is complete under `.11.8.4`; PUC Lua and LuaJIT run the same
focused consumer, and lexical capture remains deferred.

Related facts: [[generic-trailing-codeblock-argument-correction]], [[variadic-user-function-contract]],
[[terse-expression-valued-blocks-ground-truth]], [[hash-literal-dynamic-key-contract]],
[[perl-generic-final-codeblock-normalization]], [[rust-callable-codeblock-dynamic-invocation]],
[[dart-callable-codeblock-literal-state]], [[dart-callable-codeblock-dynamic-invocation]],
[[julia-callable-codeblock-literal-state]], [[julia-callable-codeblock-dynamic-invocation]], and
[[lua-callable-codeblock-literal-state]], [[lua-callable-codeblock-dynamic-invocation]], and
[[lua-callable-codeblock-emitted-route-identity]], [[callable-codeblock-four-backend-recurring-gate]], and
[[callable-codeblock-five-backend-admission]].
