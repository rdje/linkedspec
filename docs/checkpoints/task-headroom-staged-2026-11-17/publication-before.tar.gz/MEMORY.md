# MEMORY

- activation_commit: `873003e8901e2b48fd0a289db2540e94bc4d5039` — clean staged-task epoch activation; derive current HEAD from Git.
- latest_completed_leaf: `TYPE-REFERENCE-BOOK.1.2.23.4.1.1.1.1.1.1.1.1.1.1.3.1.1.1.0` — literal Perl open paths and roles.
- active_work_unit: `TYPE-REFERENCE-BOOK.1.2.23.4.36` (active); task_owner: docs/tasks/TYPE-REFERENCE-BOOK.overview.md.
- run_state: PNT; continue after each clean leaf.
- next_action: Freeze and qualify STAGED-LINKED-PARSING closed commentary with existing epoch tools, retain every contract/tail and prove exact public recovery; then resume variable literal1/other IO and broader prerequisites.
- in_flight_uncommitted: Staged-task capacity renewal; no background job.
- evidence: docs/checkpoints/perl-literal-open-qualification-2026-11-17/REVIEW.md; readonly review.py/optional --current; all145 retained/191 open sites/literal34/input32/output2/unmatched157/current189. Five source specimens/eight controls/actual mode RED. Capture and separate reader first pass; never replay capture.
- findings: Literal input paths have exact prospective bytes/modes. Two declared output paths are not captured as inputs and have no production credit. Full unmatched157, non-open/support/library/generated IO and dynamic semantics remain follow-ups. No application tests or runtime IO.
- limits: Variable literals1/other literal IO2, constructed/helper/support/generated-inline, excluded/computed/transitive/independent semantics, generated Dart/frozen-input and registration remain open. Historical/native/PPI/Perl/outer-first-use/per-read/source-origin/physical4.2/SESSION5 and original Lua reader gap remain.
- publication: Activation/cached4683555e estimate1,491,724,655 bytes/128 ahead/8,275,345-byte margin to director1.5GB excludes this slice. Selected telemetry will be retained; independent size30/native4.2 gaps and all prerequisites remain.
- locality: Only this repository writable; submodules black boxes. Same-volume serial jobs/shared24GB/director90-percent rising trend policy. Last cleanup November16 10:59UTC remains under24h; nothing removed. Normal hooks mandatory.
- preceding_normal: .linkedspec-data/perl-literal-open-commit-retry.log is the complete all10/post-pointer PASS; first commit.log is the preserved failed/interrupted attempt.
