# Publication priority — director decision pending

Owner: TYPE-REFERENCE-BOOK.1.2.23.4.30.2; intake/handoff: TYPE-REFERENCE-BOOK.1.2.23.4.37.
Raised through the live user-input request on2026-11-17; no answer or approval received.

The director's early-push rule in `docs/knowledge/github-size-safe-publication.md`
requires preparation with margin and publication around1.5GB, independently of
batch cadence. The publication parent's Dependencies/Schedule and leaf30.2 in
`docs/tasks/TYPE-REFERENCE-BOOK.overview.md` also require unfinished canonical
discovery/registration and existing before-push prerequisites. Neither requirement
is silently waived. The current task scope remains the complete inherited source
population and every semantic/native/generated/registration owner.

The actual retained activation telemetry is in `telemetry/result.json`: committed
36428fa1 against cached4683555e, excluding this handoff slice. It is a serialized
estimate, not fresh remote or negotiated wire size. Continuing the broad source
work needs a priority decision before consuming the remaining preparation margin.

Choose one:

1. Allow a checkpoint push after full exact-candidate canonical CI and normal
   hooks, keeping discovery/registration explicitly open. This authorizes a
   checkpoint only; it does not admit unregistered tests or close source/native
   provenance gaps. Resume source work after successful publication.
2. Finish discovery/registration first, allowing the outgoing estimate to grow
   beyond the1.5GB target while still monitoring and staying safely below the
   GitHub hard limit. Resume nonadjacent literals and all subsequent owners.

The first option is recommended but is not approval. No push has been attempted.
The source frontier is held; completed work and the dated retention review are
committed before stopping. Full CI remains mandatory before any push in either
case. A fresh session reads `MEMORY.md` and this file, obtains the director's
choice, records it, then activates the corresponding task from clean Git.
